from __future__ import annotations

import argparse
import json
from pathlib import Path

from audit_knowledge_v625 import build_report as build_v625_report
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.knowledge_ontology import CANONICAL_RELATIONSHIP_TYPES
from dell_crawler_core.semantic_identity import GRAPH_NODE_TYPES
from dell_crawler_core.neo4j_projection import Neo4jSemanticProjection


def build_report(db: Path, knowledge: Path | None = None) -> dict:
    report = build_v625_report(db, knowledge)
    report["release"] = "v6.26"
    store = SQLiteKnowledgeGraph(db)
    allowed_nodes = tuple(sorted(GRAPH_NODE_TYPES))
    allowed_rels = tuple(sorted(CANONICAL_RELATIONSHIP_TYPES))
    with store.connect() as conn:
        commerce_rows = conn.execute(
            "SELECT node_type,COUNT(*) n FROM nodes WHERE node_type IN ('Warranty','FinancingOption','RewardProgram','DeliveryOption') GROUP BY node_type"
        ).fetchall()
        commerce_counts = {str(r["node_type"]): int(r["n"]) for r in commerce_rows}
        vision_sources = int(conn.execute(
            "SELECT COUNT(*) FROM sources WHERE CAST(COALESCE(json_extract(metadata_json,'$.vision_evidence_count'),0) AS INTEGER)>0"
        ).fetchone()[0])
        persisted_vision_rows = int(conn.execute(
            "SELECT COUNT(*) FROM extraction_evidence WHERE evidence_kind IN ('vision_bundle','vision_text','legacy_vision_text','legacy_vision_cache')"
        ).fetchone()[0])
        multimodal_lossless_gaps = int(conn.execute(
            """
            SELECT COUNT(*) FROM sources s
            WHERE CAST(COALESCE(json_extract(s.metadata_json,'$.vision_evidence_count'),0) AS INTEGER)>0
              AND NOT EXISTS (SELECT 1 FROM extraction_evidence e WHERE e.source_url=s.url AND e.evidence_kind IN ('vision_bundle','vision_text','legacy_vision_text','legacy_vision_cache'))
              AND NOT EXISTS (SELECT 1 FROM chunks c WHERE c.source_url=s.url AND c.text LIKE '%DELL AIA VISION EVIDENCE%')
            """
        ).fetchone()[0])
        pdf_sources = int(conn.execute(
            "SELECT COUNT(*) FROM sources WHERE LOWER(mime_type) LIKE '%pdf%' OR LOWER(url) LIKE '%.pdf%'"
        ).fetchone()[0])
        pdf_knowledge_gaps = int(conn.execute(
            """
            SELECT COUNT(*) FROM sources s
            WHERE (LOWER(s.mime_type) LIKE '%pdf%' OR LOWER(s.url) LIKE '%.pdf%')
              AND COALESCE(s.http_status,200) BETWEEN 200 AND 299
              AND NOT EXISTS (SELECT 1 FROM chunks c WHERE c.source_url=s.url AND LENGTH(TRIM(c.text))>0)
              AND NOT EXISTS (SELECT 1 FROM extraction_evidence e WHERE e.source_url=s.url AND e.evidence_kind IN ('vision_bundle','vision_text','legacy_vision_text','legacy_vision_cache'))
            """
        ).fetchone()[0])
        interaction_evidence = int(conn.execute(
            "SELECT COUNT(*) FROM extraction_evidence WHERE evidence_kind IN ('interaction_history_compacted','control_progress_compacted')"
        ).fetchone()[0])
        unknown_rel = int(conn.execute(
            "SELECT COUNT(*) FROM edges WHERE predicate NOT IN (%s) AND predicate<>'DUPLICATE_CONTENT_OF'" % ",".join("?" for _ in allowed_rels),
            allowed_rels,
        ).fetchone()[0])
        non_graph_nodes = int(conn.execute(
            "SELECT COUNT(*) FROM nodes WHERE node_type NOT IN (%s)" % ",".join("?" for _ in allowed_nodes),
            allowed_nodes,
        ).fetchone()[0])
        product_commerce = {}
        for field, rel in (("warranty","HAS_WARRANTY"),("financing","HAS_FINANCING"),("rewards","EARNS_REWARD"),("shipping","HAS_DELIVERY_OPTION")):
            total = int(conn.execute(
                f"SELECT COUNT(*) FROM nodes WHERE node_type='Product' AND COALESCE(json_extract(attributes_json,'$.{field}'),'')<>''"
            ).fetchone()[0])
            linked = int(conn.execute(
                f"""
                SELECT COUNT(DISTINCT p.id) FROM nodes p JOIN edges e ON e.source_id=p.id
                WHERE p.node_type='Product' AND e.predicate=?
                """, (rel,)
            ).fetchone()[0])
            product_commerce[field] = {"products_with_value": total, "products_with_graph_link": linked, "projection_gap": max(0, total-linked)}
    projection = Neo4jSemanticProjection(store).build()
    semantic = report["semantic_quality"]
    product_projection_gaps = sum(int(v["projection_gap"]) for v in product_commerce.values())
    ready = (
        bool(semantic.get("clean_for_semantic_sync"))
        and float(semantic.get("node_classification_coverage", 0)) >= 1.0
        and non_graph_nodes == 0
        and unknown_rel == 0
        and multimodal_lossless_gaps == 0
        and pdf_knowledge_gaps == 0
        and product_projection_gaps == 0
    )
    report["agentic_commerce_graph"] = {
        "ontology_version": "v6.26-agentic-commerce",
        "commerce_node_counts": commerce_counts,
        "product_commerce_projection": product_commerce,
        "non_graph_nodes": non_graph_nodes,
        "noncanonical_relationships": unknown_rel,
        "vision_sources": vision_sources,
        "persisted_multimodal_evidence_rows": persisted_vision_rows,
        "multimodal_lossless_gaps": multimodal_lossless_gaps,
        "pdf_sources": pdf_sources,
        "successful_pdf_knowledge_gaps": pdf_knowledge_gaps,
        "compacted_interaction_evidence_rows": interaction_evidence,
        "neo4j_projection_counts": projection["counts"],
        "agentic_commerce_ready": ready,
        "retrieval_contract": "Neo4j semantic graph + SQLite/evidence sidecar; PDF/image/UI evidence stays source-provenanced and queryable",
    }
    return report


def main() -> int:
    p = argparse.ArgumentParser(description="Audit Dell crawler v6.26 semantic + multimodal + agentic-commerce readiness.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--knowledge", default="knowledge")
    p.add_argument("--output", default="")
    p.add_argument("--require-clean", action="store_true")
    a = p.parse_args()
    db = Path(a.db).expanduser().resolve()
    knowledge = Path(a.knowledge).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    report = build_report(db, knowledge)
    text = json.dumps(report, indent=2, ensure_ascii=False, default=str)
    print(text)
    if a.output:
        Path(a.output).expanduser().write_text(text, encoding="utf-8")
    if a.require_clean and (
        report["integrity_check"].casefold() != "ok"
        or report["foreign_key_violations"]
        or not bool(report["semantic_quality"].get("clean_for_semantic_sync"))
        or not bool(report["agentic_commerce_graph"].get("agentic_commerce_ready"))
    ):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

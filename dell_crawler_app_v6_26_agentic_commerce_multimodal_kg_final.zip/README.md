# Dell Crawler v6.26 — Lossless Agentic-Commerce Knowledge Graph

**Use v6.26 for the current deployment.** It combines the v6.25 lossless single-drive storage model with a bounded, classified, Neo4j-ready commerce ontology and an agent retrieval layer that includes PDF/image/interaction evidence.

## What v6.26 guarantees

- No arbitrary JSON key/schema.org/LLM class becomes a Neo4j label.
- Stable canonical Product identity: order code → part number → exact Dell PDP → safe branded model fallback.
- Scattered duplicate semantic nodes are consolidated and relationships are rewired.
- Product specs remain rich properties/facts rather than hundreds of tiny nodes.
- Warranty, financing, Rewards and delivery are explicitly classified and graph-traversable.
- Full searchable source/document text is retained.
- PDF and image Dell AIA vision output is persisted as durable evidence before regenerable files/caches are removed.
- Safe dynamic UI interaction outcomes are compacted into durable evidence before runtime telemetry cleanup.
- Unmapped/uncertain observations are retained as evidence instead of silently discarded.
- New extractions automatically follow the same normalize → classify → validate → dedupe → persist pipeline.
- Neo4j receives a compact semantic projection; the agent combines graph traversal with lossless SQLite/evidence retrieval.

## Upgrade existing knowledge

```powershell
python .\repair_v626.py --db .\knowledge\dell_en_uk.db --knowledge .\knowledge
python .\audit_knowledge_v626.py --db .\knowledge\dell_en_uk.db --knowledge .\knowledge --require-clean
python .\release_verify_v626.py --db .\knowledge\dell_en_uk.db
python -m streamlit run .\app.py
```

Or run `upgrade_v626.ps1` / `upgrade_v626.bat`.

## Export for Neo4j

```powershell
python .\export_neo4j_v626.py --db .\knowledge\dell_en_uk.db --out .\knowledge\neo4j_v626
```

This writes canonical `nodes.jsonl`, `relationships.jsonl`, lossless `evidence.jsonl`, and a manifest. `NEO4J_ONTOLOGY_V626.json` defines the classification/identity contract and `neo4j_schema_v626.cypher` provides the Neo4j uniqueness/index schema.

## Agentic-commerce retrieval

```powershell
python .\agentic_commerce_query.py --db .\knowledge\dell_en_uk.db compare Dell products with warranty financing rewards and delivery
```

The bundle contains semantic graph context, Product facts/history, full text hits, PDF/image evidence, interaction context, source URLs and confidence/provenance.

See `V6_26_AGENTIC_COMMERCE_MULTIMODAL_KG.md`, `V6_25_LOSSLESS_EXTRACTED_KNOWLEDGE.md`, and `V6_24_SINGLE_DRIVE_STORAGE_AND_SEGMENTATION.md`.

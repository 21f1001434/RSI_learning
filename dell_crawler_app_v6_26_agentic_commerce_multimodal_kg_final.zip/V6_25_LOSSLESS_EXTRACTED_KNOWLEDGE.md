# v6.25 — Lossless Extracted-Knowledge Retention

v6.25 tightens the v6.24 single-drive cleanup contract: disk cleanup may remove
regenerable local artefacts after successful persistence, but it does not prune
unique extracted knowledge from the active SQLite database.

Preserved in the active DB:

- searchable source text/chunks (resegmented only; source content preserved)
- semantic nodes, edges and facts
- extraction evidence including unmapped/classification/LLM/vision evidence
- document-section and recommendation evidence
- link/discovery provenance
- every Product observation/history row
- Product aliases/enrichment state
- durable AgentQ/action policy memory
- source URL/content hashes and canonical provenance

Still removable/compactable:

- browser/PDF render caches and temporary downloads after extraction is persisted
- screenshots/raw render copies for completed sources (canonical extracted content remains in SQLite)
- runtime/debug/self-heal telemetry
- generated reports, old caches, test/Python caches
- bulky completed queue bookkeeping after compact suppression state is retained
- exact duplicate searchable chunk copies for byte-equivalent pages
- SQLite FTS duplication and free pages

Before any DB cleanup, v6.25 creates a compressed logical SQLite safety backup on
the same drive. This backup contains the pre-repair database state.

`repair_v625.py` always enables lossless extracted-knowledge mode. The older
aggressive pruning behaviour remains an internal opt-in for compatibility tests,
but is not used by the v6.25 repair/upgrade workflow.

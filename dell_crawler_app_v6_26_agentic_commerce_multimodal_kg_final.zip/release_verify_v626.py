from __future__ import annotations

import argparse
import compileall
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Any

ROOT = Path(__file__).resolve().parent


def _run(cmd: list[str]) -> dict[str, Any]:
    proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
    return {"command": cmd, "returncode": proc.returncode, "stdout_tail": proc.stdout[-8000:], "stderr_tail": proc.stderr[-8000:], "ok": proc.returncode == 0}


def _manifest_check() -> dict[str, Any]:
    path = ROOT / "MANIFEST_SHA256.json"
    if not path.exists():
        return {"ok": False, "status": "MISSING"}
    payload = json.loads(path.read_text(encoding="utf-8"))
    mismatches = []
    for item in payload.get("files", []):
        p = ROOT / str(item.get("path") or "")
        if not p.exists():
            mismatches.append({"path": str(item.get("path")), "reason": "missing"}); continue
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        if digest != item.get("sha256") or p.stat().st_size != int(item.get("size_bytes", p.stat().st_size)):
            mismatches.append({"path": str(item.get("path")), "reason": "hash_or_size_mismatch"})
    return {"ok": not mismatches and len(payload.get("files", [])) == int(payload.get("file_count", -1)), "declared_file_count": payload.get("file_count"), "checked_file_count": len(payload.get("files", [])), "mismatches": mismatches}


def main() -> int:
    p = argparse.ArgumentParser(description="Verify Dell Crawler v6.26 agentic-commerce/multimodal release.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--skip-tests", action="store_true")
    p.add_argument("--skip-manifest", action="store_true")
    p.add_argument("--output", default="reports/FINAL_VALIDATION_V626_RUNTIME.json")
    a = p.parse_args()
    imports_ok, import_error = True, ""
    try:
        import dell_crawler_core.agentic_commerce  # noqa
        import dell_crawler_core.neo4j_projection  # noqa
        import dell_crawler_core.dell_crawler  # noqa
        import dell_crawler_core.kg_store  # noqa
    except Exception as exc:
        imports_ok, import_error = False, f"{type(exc).__name__}: {exc}"
    compile_ok = bool(compileall.compile_dir(str(ROOT), quiet=1))
    tests = {"ok": True, "status": "SKIPPED"} if a.skip_tests else _run([sys.executable, "-m", "pytest", "-q"])
    db = Path(a.db).expanduser().resolve()
    if db.exists():
        from audit_knowledge_v626 import build_report
        audit = build_report(db, db.parent)
        db_ok = audit["integrity_check"].casefold() == "ok" and not audit["foreign_key_violations"] and bool(audit["agentic_commerce_graph"].get("agentic_commerce_ready"))
        db_result = {"ok": db_ok, "status": "CHECKED", "audit": audit}
    else:
        db_result = {"ok": True, "status": "NOT_PRESENT", "path": str(db)}
    manifest = {"ok": True, "status": "SKIPPED"} if a.skip_manifest else _manifest_check()
    report = {
        "release": "v6.26-agentic-commerce-multimodal-knowledge-graph",
        "python": {"version": sys.version, "supported": sys.version_info >= (3, 11)},
        "imports": {"ok": imports_ok, "error": import_error}, "compileall": {"ok": compile_ok},
        "tests": tests, "database": db_result, "manifest": manifest,
        "browser_prerequisites": {"node_found": bool(shutil.which("node")), "npx_found": bool(shutil.which("npx") or shutil.which("npx.cmd"))},
        "live_external_checks": {"dell_sso": "NOT_RUN_BY_RELEASE_VERIFIER", "dell_aia": "NOT_RUN_BY_RELEASE_VERIFIER", "dell_com": "NOT_RUN_BY_RELEASE_VERIFIER", "neo4j_instance": "NOT_RUN_BY_RELEASE_VERIFIER"},
    }
    report["ok"] = all([report["python"]["supported"], imports_ok, compile_ok, bool(tests.get("ok")), bool(db_result.get("ok")), bool(manifest.get("ok"))])
    out = ROOT / a.output; out.parent.mkdir(parents=True, exist_ok=True); out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

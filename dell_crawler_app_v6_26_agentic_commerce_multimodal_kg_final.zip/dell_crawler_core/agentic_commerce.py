from __future__ import annotations

"""Agent-ready retrieval over the lossless Dell knowledge store.

The semantic graph stays deliberately compact; rich PDF/image/dynamic evidence stays
in SQLite.  This module joins both layers so an agentic-commerce planner does not
have to choose between a clean Neo4j graph and complete extracted evidence.
"""

import json
import re
from pathlib import Path
from typing import Any, Iterable

from .kg_store import SQLiteKnowledgeGraph, _loads


COMMERCE_NODE_TYPES = frozenset({
    "Product", "ProductFamily", "Category", "Brand", "Offer", "Review",
    "Warranty", "FinancingOption", "RewardProgram", "DeliveryOption",
    "Compatibility", "Requirement", "Service", "Software", "Solution",
    "UseCase", "Workload", "Document", "SupportArticle", "FAQ", "Market",
    "AccountTopic", "Organization", "Page",
})


class AgenticCommerceKnowledge:
    """Build provenance-rich context for an agent without graph over-segmentation."""

    def __init__(self, db: str | Path | SQLiteKnowledgeGraph):
        self.store = db if isinstance(db, SQLiteKnowledgeGraph) else SQLiteKnowledgeGraph(Path(db))

    @staticmethod
    def _tokens(query: str) -> list[str]:
        return [t.casefold() for t in re.findall(r"[A-Za-z0-9][A-Za-z0-9+._-]*", query or "") if len(t) > 1][:12]

    def _source_metadata(self, urls: Iterable[str]) -> list[dict[str, Any]]:
        clean = list(dict.fromkeys(str(u) for u in urls if u))
        if not clean:
            return []
        placeholders = ",".join("?" for _ in clean)
        with self.store.connect() as conn:
            rows = conn.execute(
                f"SELECT url,title,page_type,fetched_at,mime_type,metadata_json FROM sources WHERE url IN ({placeholders})",
                tuple(clean),
            ).fetchall()
        result = []
        for row in rows:
            meta = _loads(row["metadata_json"], {})
            # Keep agent-useful interaction/discovery context; omit bulky runtime noise.
            interaction = {
                key: meta.get(key)
                for key in (
                    "safe_interactions_attempted", "safe_interaction_labels",
                    "repeatable_controls_complete", "repeatable_control_progress",
                    "coverage_contract", "review_metrics", "vision_evidence_count",
                    "product_records_extracted", "product_price_coverage", "product_spec_coverage",
                    "market", "locale", "currency",
                )
                if meta.get(key) not in (None, "", [], {})
            }
            result.append({
                "url": row["url"], "title": row["title"], "page_type": row["page_type"],
                "fetched_at": row["fetched_at"], "mime_type": row["mime_type"],
                "interaction_and_coverage": interaction,
            })
        return result

    def _evidence(self, query: str, source_urls: Iterable[str], limit: int) -> list[dict[str, Any]]:
        tokens = self._tokens(query)
        urls = list(dict.fromkeys(str(u) for u in source_urls if u))
        clauses: list[str] = []
        params: list[Any] = []
        if urls:
            clauses.append("source_url IN (%s)" % ",".join("?" for _ in urls))
            params.extend(urls)
        if tokens:
            token_parts = []
            for token in tokens:
                token_parts.append("(LOWER(payload_json) LIKE ? OR LOWER(reason) LIKE ? OR LOWER(evidence_kind) LIKE ?)")
                pattern = f"%{token}%"
                params.extend([pattern, pattern, pattern])
            # Evidence from already-retrieved sources is useful even when OCR/vision wording
            # differs from the user's query, so token matching is OR'd with source scoping.
            if urls:
                clauses.append("(" + " OR ".join(token_parts) + " OR source_url IN (%s))" % ",".join("?" for _ in urls))
                params.extend(urls)
            else:
                clauses.append("(" + " OR ".join(token_parts) + ")")
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        with self.store.connect() as conn:
            rows = conn.execute(
                f"SELECT source_url,evidence_kind,reason,payload_json,observed_at FROM extraction_evidence{where} ORDER BY observed_at DESC LIMIT ?",
                (*params, max(1, int(limit))),
            ).fetchall()
        return [
            {
                "source_url": row["source_url"], "evidence_kind": row["evidence_kind"],
                "reason": row["reason"], "payload": _loads(row["payload_json"], {}),
                "observed_at": row["observed_at"],
            }
            for row in rows
        ]

    def _runtime_interactions(self, source_urls: Iterable[str], limit: int = 120) -> list[dict[str, Any]]:
        urls = list(dict.fromkeys(str(u) for u in source_urls if u))
        if not urls:
            return []
        placeholders = ",".join("?" for _ in urls)
        with self.store.connect() as conn:
            try:
                rows = conn.execute(
                    f"SELECT source_url,label,role,action_kind,status,detail,observed_at FROM interactions WHERE source_url IN ({placeholders}) ORDER BY observed_at DESC LIMIT ?",
                    (*urls, max(1, int(limit))),
                ).fetchall()
            except Exception:
                rows = []
        return [dict(row) for row in rows]

    def _product_observations(self, node_keys: Iterable[str], limit: int = 80) -> list[dict[str, Any]]:
        keys = list(dict.fromkeys(k for k in node_keys if k))
        if not keys:
            return []
        placeholders = ",".join("?" for _ in keys)
        with self.store.connect() as conn:
            rows = conn.execute(
                f"""
                SELECT n.node_key AS product_node_key,o.source_url,o.observed_at,o.fields_json,o.observation_hash,
                       o.price,o.list_price,o.currency,o.model,o.order_code,o.completeness_score
                FROM product_observations o JOIN nodes n ON n.id=o.product_id
                WHERE n.node_key IN ({placeholders})
                ORDER BY o.observed_at DESC LIMIT ?
                """,
                (*keys, max(1, int(limit))),
            ).fetchall()
        return [
            {
                "product_node_key": row["product_node_key"], "source_url": row["source_url"],
                "observed_at": row["observed_at"], "attributes": _loads(row["fields_json"], {}),
                "observation_hash": row["observation_hash"], "price": row["price"],
                "list_price": row["list_price"], "currency": row["currency"],
                "model": row["model"], "order_code": row["order_code"],
                "completeness_score": float(row["completeness_score"] or 0),
            }
            for row in rows
        ]

    def context(self, query: str, *, limit: int = 12, evidence_limit: int = 24, graph_limit: int = 100) -> dict[str, Any]:
        search = self.store.search(query, limit=max(4, int(limit)))
        node_keys: list[str] = []
        source_urls: list[str] = []
        for item in search:
            if item.get("kind") == "node" and item.get("node_key"):
                node_keys.append(str(item["node_key"]))
            if item.get("source_url"):
                source_urls.append(str(item["source_url"]))
        # Page nodes anchor graph traversal for text/PDF/image search hits.
        node_keys.extend(f"url:{u}" for u in source_urls)
        node_keys = list(dict.fromkeys(node_keys))
        graph = self.store.graph_neighborhood(node_keys, limit=max(20, int(graph_limit)))
        for edge in graph:
            for key_name in ("source_key", "target_key"):
                key = str(edge.get(key_name) or "")
                if key:
                    node_keys.append(key)
            if edge.get("source_url"):
                source_urls.append(str(edge["source_url"]))
        node_keys = list(dict.fromkeys(node_keys))
        source_urls = list(dict.fromkeys(source_urls))
        facts = self.store.facts_for_nodes(node_keys, limit=max(40, int(graph_limit) * 2))
        source_urls.extend(str(f.get("source_url") or "") for f in facts if f.get("source_url"))
        source_urls = list(dict.fromkeys(source_urls))
        evidence = self._evidence(query, source_urls, max(1, int(evidence_limit)))
        observations = self._product_observations(node_keys, limit=max(40, int(graph_limit)))
        runtime_interactions = self._runtime_interactions(source_urls, limit=max(40, int(graph_limit)))
        sources = self._source_metadata(source_urls)
        return {
            "query": query,
            "retrieval_contract": "semantic_graph_plus_lossless_multimodal_evidence_v6.26",
            "search_results": search,
            "node_keys": node_keys,
            "graph_neighborhood": graph,
            "facts": facts,
            "product_observations": observations,
            "runtime_interactions": runtime_interactions,
            "extraction_evidence": evidence,
            "sources": sources,
            "agent_guidance": {
                "use_current_price_as_volatile": True,
                "customer_reviews_are_opinion_evidence": True,
                "vision_and_pdf_evidence_must_keep_source_url": True,
                "unmapped_evidence_is_not_a_verified_fact": True,
                "prefer_product_order_code_part_number_and_exact_pdp_for_identity": True,
            },
        }


def build_agentic_commerce_context(db: str | Path, query: str, **kwargs: Any) -> dict[str, Any]:
    return AgenticCommerceKnowledge(db).context(query, **kwargs)

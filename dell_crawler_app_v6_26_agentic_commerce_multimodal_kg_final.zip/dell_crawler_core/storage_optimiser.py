from __future__ import annotations

"""v6.24 single-drive storage optimiser.

The crawler is intentionally exhaustive, but durable knowledge should live in the
canonical SQLite graph/chunk store rather than in many copies of the same page,
screenshot, rendered PDF page, raw HTML dump, cache entry, or browser trace.

This module keeps extracted knowledge while pruning *regenerable* artefacts after
successful extraction and bounding runtime/browser/cache directories so a long
crawl cannot silently consume tens of gigabytes on a single C: drive.
"""

from pathlib import Path
from typing import Any, Iterable
import json
import os
import shutil
import sqlite3
import time

from .kg_store import SQLiteKnowledgeGraph


REGENERABLE_KNOWLEDGE_DIRS = (
    "raw",
    "screenshots",
    "visual_assets",
    "pdf_visual_pages",
    "browser_pdf_viewer",
    "document_quarantine",
    "dynamic_states",
    "text_cache",
    "vision_cache",
)

# Chromium/Edge profile folders that do not contain sign-in cookies/local storage.
# The SSO profile itself is retained; only caches/diagnostics are removed.
BROWSER_CACHE_NAMES = {
    "Cache",
    "Code Cache",
    "GPUCache",
    "DawnCache",
    "GrShaderCache",
    "ShaderCache",
    "GraphiteDawnCache",
    "Crashpad",
    "BrowserMetrics",
    "optimization_guide_model_store",
    "component_crx_cache",
}
BROWSER_CACHE_RELATIVE = (
    Path("Default") / "Service Worker" / "CacheStorage",
    Path("Default") / "Service Worker" / "ScriptCache",
    Path("Default") / "blob_storage",
)


def _bytes(path: Path) -> int:
    try:
        if path.is_file() or path.is_symlink():
            return int(path.stat().st_size)
        total = 0
        for child in path.rglob("*"):
            try:
                if child.is_file() and not child.is_symlink():
                    total += int(child.stat().st_size)
            except OSError:
                pass
        return total
    except OSError:
        return 0


def _under(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def _unlink(path: Path) -> int:
    size = _bytes(path)
    try:
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink(missing_ok=True)
        return size
    except OSError:
        return 0


def _iter_local_paths(value: Any) -> Iterable[str]:
    """Yield path-like strings embedded in crawler metadata recursively."""
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"path", "local_path", "raw_path", "screenshot_path"} and isinstance(item, str):
                if item.strip():
                    yield item.strip()
            elif key in {"screenshot_paths"} and isinstance(item, list):
                for part in item:
                    if isinstance(part, str) and part.strip():
                        yield part.strip()
            else:
                yield from _iter_local_paths(item)
    elif isinstance(value, list):
        for item in value:
            yield from _iter_local_paths(item)


def _scrub_local_paths(value: Any) -> Any:
    """Remove local file pointers from metadata after artefacts are intentionally pruned."""
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, item in value.items():
            if key in {"path", "local_path", "raw_path", "screenshot_path"} and isinstance(item, str):
                out[key] = ""
            elif key == "screenshot_paths" and isinstance(item, list):
                out[key] = []
            else:
                out[key] = _scrub_local_paths(item)
        return out
    if isinstance(value, list):
        return [_scrub_local_paths(item) for item in value]
    return value


def directory_inventory(root: Path) -> list[dict[str, Any]]:
    root = root.resolve()
    rows: list[dict[str, Any]] = []
    if not root.exists():
        return rows
    for child in root.iterdir():
        try:
            rows.append({
                "path": str(child),
                "name": child.name,
                "bytes": _bytes(child),
                "kind": "directory" if child.is_dir() else "file",
            })
        except OSError:
            continue
    rows.sort(key=lambda row: int(row.get("bytes", 0)), reverse=True)
    return rows


def prune_browser_profile_caches(root: Path) -> dict[str, Any]:
    """Remove Chromium caches while retaining cookies/storage required for Dell SSO."""
    root = root.resolve()
    profile_roots = [root / "browser_profile", root / "runtime" / "browser_profile"]
    deleted: list[dict[str, Any]] = []
    for profile in profile_roots:
        if not profile.exists():
            continue
        for path in list(profile.rglob("*")):
            if not path.exists() or not path.is_dir():
                continue
            if path.name in BROWSER_CACHE_NAMES:
                size = _unlink(path)
                if size:
                    deleted.append({"path": str(path), "bytes": size})
        for rel in BROWSER_CACHE_RELATIVE:
            path = profile / rel
            if path.exists():
                size = _unlink(path)
                if size:
                    deleted.append({"path": str(path), "bytes": size})
    return {
        "ok": True,
        "deleted": deleted,
        "bytes_deleted": sum(int(item["bytes"]) for item in deleted),
        "preserved": ["Cookies", "Local Storage", "Session Storage", "IndexedDB", "Preferences"],
    }


def _trim_directory_to_budget(path: Path, max_bytes: int, *, keep_newest: int = 25) -> dict[str, Any]:
    """Delete oldest files until a directory fits a byte budget."""
    path = path.resolve()
    if not path.exists() or max_bytes < 0:
        return {"path": str(path), "before_bytes": 0, "after_bytes": 0, "deleted": []}
    files: list[Path] = []
    for candidate in path.rglob("*"):
        try:
            if candidate.is_file() and not candidate.is_symlink():
                files.append(candidate)
        except OSError:
            pass
    files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    before = sum(_bytes(p) for p in files)
    current = before
    deleted: list[dict[str, Any]] = []
    protected_count = max(0, int(keep_newest))
    # Prefer deleting files outside the newest retention window first.
    for candidate in reversed(files[protected_count:]):
        if current <= max_bytes:
            break
        size = _unlink(candidate)
        if size:
            current -= size
            deleted.append({"path": str(candidate), "bytes": size})
    # The budget is a hard ceiling. If the newest retention window itself is
    # larger than the configured budget, trim the oldest members of that window
    # too instead of silently exceeding the disk limit.
    if current > max_bytes:
        for candidate in reversed(files[:protected_count]):
            if current <= max_bytes:
                break
            if not candidate.exists():
                continue
            size = _unlink(candidate)
            if size:
                current -= size
                deleted.append({"path": str(candidate), "bytes": size})
    # Drop now-empty directories from the bottom up.
    for folder in sorted((p for p in path.rglob("*") if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
        try:
            folder.rmdir()
        except OSError:
            pass
    return {"path": str(path), "before_bytes": before, "after_bytes": max(0, current), "deleted": deleted}


def _source_is_incomplete(conn: sqlite3.Connection, url: str, metadata: dict[str, Any]) -> bool:
    coverage = metadata.get("coverage_contract") if isinstance(metadata.get("coverage_contract"), dict) else {}
    if coverage and not bool(coverage.get("passed", False)):
        return True
    row = conn.execute("SELECT status FROM crawl_queue WHERE url=?", (url,)).fetchone()
    if row and str(row[0] or "").upper() in {
        "PENDING", "IN_PROGRESS", "FAILED", "DEFERRED", "DONE_INCOMPLETE", "BLOCKED_CONFIGURATION"
    }:
        return True
    enrichment = conn.execute(
        "SELECT COUNT(*) FROM product_enrichment_state WHERE source_url=? AND status NOT IN ('COMPLETE','EXHAUSTED_NO_GAIN','EXHAUSTED_ATTEMPTS','NO_USABLE_URL')",
        (url,),
    ).fetchone()
    return bool(enrichment and int(enrichment[0] or 0) > 0)


def prune_successfully_extracted_artifacts(
    store: SQLiteKnowledgeGraph,
    knowledge: Path,
    *,
    root: Path | None = None,
    retain_incomplete: bool = True,
    evidence_budget_mb: int = 256,
    cache_budget_mb: int = 256,
) -> dict[str, Any]:
    """Delete large local artefacts after their knowledge has been persisted.

    A source is eligible when it has searchable chunks and is not pending or
    incomplete. The canonical page/product/document knowledge remains in SQLite.
    This is the key v6.24 space policy for a machine with only one drive.
    """
    knowledge = knowledge.resolve()
    root = (root or knowledge.parent).resolve()
    allowed_roots = [
        (knowledge / name).resolve() for name in REGENERABLE_KNOWLEDGE_DIRS
    ] + [
        (knowledge / "documents").resolve(),
        (knowledge / "evidence").resolve(),
        (root / "evidence").resolve(),
    ]
    deleted: list[dict[str, Any]] = []
    retained_urls = 0
    compacted_urls = 0

    with store.connect() as conn:
        rows = conn.execute(
            """
            SELECT s.url,s.screenshot_path,s.raw_path,s.metadata_json,
                   EXISTS(SELECT 1 FROM chunks c WHERE c.source_url=s.url) AS has_chunks
            FROM sources s
            """
        ).fetchall()
        for row in rows:
            url = str(row[0])
            has_chunks = bool(row[4])
            try:
                metadata = json.loads(str(row[3] or "{}"))
                if not isinstance(metadata, dict):
                    metadata = {}
            except Exception:
                metadata = {}
            incomplete = retain_incomplete and _source_is_incomplete(conn, url, metadata)
            if not has_chunks or incomplete:
                retained_urls += 1
                continue

            candidates = [str(row[1] or ""), str(row[2] or "")]
            candidates.extend(_iter_local_paths(metadata))
            seen: set[str] = set()
            for raw in candidates:
                raw = str(raw or "").strip()
                if not raw or raw in seen:
                    continue
                seen.add(raw)
                try:
                    path = Path(raw).expanduser()
                    if not path.is_absolute():
                        path = (root / path).resolve()
                    else:
                        path = path.resolve()
                except Exception:
                    continue
                if not path.exists() or not path.is_file():
                    continue
                if not any(_under(path, safe_root) for safe_root in allowed_roots if safe_root.exists()):
                    continue
                size = _unlink(path)
                if size:
                    deleted.append({"path": str(path), "bytes": size, "source_url": url})

            clean_meta = _scrub_local_paths(metadata)
            clean_meta["storage_compacted"] = True
            clean_meta["storage_compaction_version"] = "v6.24"
            conn.execute(
                "UPDATE sources SET screenshot_path='',raw_path='',metadata_json=? WHERE url=?",
                (json.dumps(clean_meta, ensure_ascii=False, sort_keys=True, default=str), url),
            )
            compacted_urls += 1

    # Runtime/browser evidence and caches are bounded even if a few files are not
    # attached to a specific source row (MCP screenshots/traces are common here).
    budgets: list[dict[str, Any]] = []
    evidence_bytes = max(0, int(evidence_budget_mb)) * 1024 * 1024
    cache_bytes = max(0, int(cache_budget_mb)) * 1024 * 1024
    for path in (knowledge / "evidence", root / "evidence"):
        if path.exists():
            budgets.append(_trim_directory_to_budget(path, evidence_bytes, keep_newest=40))
    for path in (knowledge / "text_cache", knowledge / "vision_cache"):
        if path.exists():
            budgets.append(_trim_directory_to_budget(path, cache_bytes, keep_newest=100))

    return {
        "ok": True,
        "compacted_source_count": compacted_urls,
        "retained_source_count": retained_urls,
        "deleted_files": len(deleted),
        "bytes_deleted": sum(int(item["bytes"]) for item in deleted),
        "deleted": deleted,
        "bounded_directories": budgets,
    }


def runtime_prune_page_artifacts(
    store: SQLiteKnowledgeGraph,
    page: Any,
    *,
    root: Path,
    knowledge: Path,
    complete: bool,
    retain_success_artifacts: bool = False,
) -> dict[str, Any]:
    """Prune files created for one successfully persisted page/document.

    Called after ingest_extraction(), so model/vision evidence is already durable.
    Incomplete pages keep their artefacts for targeted revisits.
    """
    if retain_success_artifacts or not complete:
        return {"status": "retained", "bytes_deleted": 0, "deleted": []}
    root = root.resolve()
    knowledge = knowledge.resolve()
    allowed = [
        knowledge / "raw", knowledge / "screenshots", knowledge / "visual_assets",
        knowledge / "pdf_visual_pages", knowledge / "browser_pdf_viewer",
        knowledge / "documents", knowledge / "evidence", root / "evidence",
    ]
    candidates: list[str] = []
    for attr in ("screenshot_path",):
        candidates.append(str(getattr(page, attr, "") or ""))
    candidates.extend(str(v) for v in (getattr(page, "screenshot_paths", []) or []) if v)
    metadata = getattr(page, "metadata", {}) if isinstance(getattr(page, "metadata", {}), dict) else {}
    candidates.extend(_iter_local_paths(metadata))
    deleted: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in candidates:
        raw = str(raw or "").strip()
        if not raw or raw in seen:
            continue
        seen.add(raw)
        try:
            path = Path(raw)
            path = path.resolve() if path.is_absolute() else (root / path).resolve()
        except Exception:
            continue
        if not path.exists() or not path.is_file():
            continue
        if not any(_under(path, safe.resolve()) for safe in allowed if safe.exists()):
            continue
        size = _unlink(path)
        if size:
            deleted.append({"path": str(path), "bytes": size})

    url = str(getattr(page, "canonical_url", "") or getattr(page, "url", "") or "")
    if url:
        try:
            with store.connect() as conn:
                row = conn.execute("SELECT metadata_json FROM sources WHERE url=?", (url,)).fetchone()
                if row:
                    try:
                        source_meta = json.loads(str(row[0] or "{}"))
                        if not isinstance(source_meta, dict):
                            source_meta = {}
                    except Exception:
                        source_meta = {}
                    source_meta = _scrub_local_paths(source_meta)
                    source_meta["storage_compacted"] = True
                    source_meta["storage_compaction_version"] = "v6.24"
                    conn.execute(
                        "UPDATE sources SET screenshot_path='',raw_path='',metadata_json=? WHERE url=?",
                        (json.dumps(source_meta, ensure_ascii=False, sort_keys=True, default=str), url),
                    )
        except Exception:
            pass
    return {
        "status": "pruned",
        "bytes_deleted": sum(int(item["bytes"]) for item in deleted),
        "deleted": deleted,
    }


def storage_inventory(root: Path, knowledge: Path, db: Path) -> dict[str, Any]:
    root, knowledge, db = root.resolve(), knowledge.resolve(), db.resolve()
    usage = shutil.disk_usage(db.parent)
    return {
        "root": str(root),
        "knowledge": str(knowledge),
        "database": str(db),
        "database_bytes": _bytes(db),
        "disk": {"total": usage.total, "used": usage.used, "free": usage.free},
        "project_top_level": directory_inventory(root)[:30],
        "knowledge_top_level": directory_inventory(knowledge)[:30] if knowledge.exists() else [],
    }


def enforce_runtime_budgets(
    root: Path,
    knowledge: Path,
    *,
    evidence_budget_mb: int = 256,
    cache_budget_mb: int = 256,
) -> dict[str, Any]:
    """Bound regenerable runtime folders during a long crawl."""
    root, knowledge = root.resolve(), knowledge.resolve()
    evidence_budget = max(0, int(evidence_budget_mb)) * 1024 * 1024
    cache_budget = max(0, int(cache_budget_mb)) * 1024 * 1024
    rows: list[dict[str, Any]] = []
    for path in (knowledge / "evidence", root / "evidence"):
        if path.exists():
            rows.append(_trim_directory_to_budget(path, evidence_budget, keep_newest=40))
    for path in (knowledge / "text_cache", knowledge / "vision_cache"):
        if path.exists():
            rows.append(_trim_directory_to_budget(path, cache_budget, keep_newest=100))
    return {
        "ok": True,
        "directories": rows,
        "bytes_deleted": sum(
            sum(int(item.get("bytes", 0)) for item in row.get("deleted", []))
            for row in rows
        ),
    }


def _trim_paths_to_total_budget(paths: list[Path], max_bytes: int, *, keep_newest: int = 20) -> dict[str, Any]:
    files: list[Path] = []
    roots = [p.resolve() for p in paths if p.exists()]
    for root in roots:
        for candidate in root.rglob("*"):
            try:
                if candidate.is_file() and not candidate.is_symlink():
                    files.append(candidate)
            except OSError:
                pass
    files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    before = sum(_bytes(p) for p in files)
    current = before
    deleted: list[dict[str, Any]] = []
    protected_count = max(0, int(keep_newest))
    for candidate in reversed(files[protected_count:]):
        if current <= max_bytes:
            break
        size = _unlink(candidate)
        if size:
            current -= size
            deleted.append({"path": str(candidate), "bytes": size})
    if current > max_bytes:
        for candidate in reversed(files[:protected_count]):
            if current <= max_bytes:
                break
            if not candidate.exists():
                continue
            size = _unlink(candidate)
            if size:
                current -= size
                deleted.append({"path": str(candidate), "bytes": size})
    return {"before_bytes": before, "after_bytes": max(0, current), "deleted": deleted, "roots": [str(p) for p in roots]}


def enforce_runtime_budgets_v624(
    root: Path,
    knowledge: Path,
    *,
    evidence_budget_mb: int = 256,
    cache_budget_mb: int = 256,
    artifact_budget_mb: int = 1024,
) -> dict[str, Any]:
    """Bound all regenerable on-disk crawler artefacts during multi-day runs."""
    base = enforce_runtime_budgets(
        root, knowledge,
        evidence_budget_mb=evidence_budget_mb,
        cache_budget_mb=cache_budget_mb,
    )
    artifact_dirs = [
        knowledge / "raw",
        knowledge / "documents",
        knowledge / "document_quarantine",
        knowledge / "screenshots",
        knowledge / "visual_assets",
        knowledge / "pdf_visual_pages",
        knowledge / "browser_pdf_viewer",
        knowledge / "dynamic_states",
    ]
    artifact = _trim_paths_to_total_budget(
        artifact_dirs,
        max(0, int(artifact_budget_mb)) * 1024 * 1024,
        keep_newest=30,
    )
    base["artifact_budget"] = artifact
    base["artifact_budget_mb"] = int(artifact_budget_mb)
    base["bytes_deleted"] = int(base.get("bytes_deleted", 0)) + sum(int(x.get("bytes", 0)) for x in artifact.get("deleted", []))
    return base

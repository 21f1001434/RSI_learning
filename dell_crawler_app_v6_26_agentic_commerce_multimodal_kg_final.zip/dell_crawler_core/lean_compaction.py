from __future__ import annotations

"""Space-first logical compaction and safe SQLite compact-swap for v6.23.

The goal is to remove redundancy without deleting unique Dell knowledge.  The
module deliberately distinguishes durable semantic/search content from crawl
bookkeeping and duplicate provenance that can be regenerated.
"""

from pathlib import Path
from typing import Any
import os
import shutil
import sqlite3
import time

from .db_hygiene import purge_irrelevant_legacy_data, database_hygiene_report
from .kg_store import SQLiteKnowledgeGraph


def _file_size(path: Path) -> int:
    try:
        return int(path.stat().st_size)
    except OSError:
        return 0


def _db_space(conn: sqlite3.Connection) -> dict[str, int]:
    page_size = int(conn.execute("PRAGMA page_size").fetchone()[0])
    page_count = int(conn.execute("PRAGMA page_count").fetchone()[0])
    freelist = int(conn.execute("PRAGMA freelist_count").fetchone()[0])
    return {
        "page_size": page_size,
        "page_count": page_count,
        "freelist_count": freelist,
        "allocated_bytes": page_size * page_count,
        "estimated_live_bytes": page_size * max(0, page_count - freelist),
        "estimated_free_inside_db_bytes": page_size * freelist,
    }


def logical_lean_cleanup(
    store: SQLiteKnowledgeGraph,
    *,
    keep_crawl_runs: int = 1,
    keep_product_observations: int = 24,
    preserve_extracted_knowledge: bool = False,
) -> dict[str, Any]:
    """Delete redundant database content while preserving unique knowledge.

    Preserved:
    - sources/chunks (authoritative searchable page knowledge)
    - semantic nodes/edges/facts except section/recommendation duplicates
    - unmapped/classification evidence
    - current/recent product history
    - learned action policy memory
    - pending/retry/incomplete work

    Compacted:
    - terminal DONE queue rows -> crawl_suppression ledger
    - legacy runtime/orphan rows via db_hygiene

    When ``preserve_extracted_knowledge`` is True (v6.25 default repair mode),
    link provenance, extraction evidence, derived facts, and every Product
    observation are retained even when they look redundant.  This keeps the
    active DB lossless with respect to extracted knowledge while still allowing
    operational/runtime compaction and external artefact cleanup.
    """
    before = database_hygiene_report(store)
    deleted: dict[str, int] = {}
    moved: dict[str, int] = {}

    # v6.20 cleanup first, but no VACUUM.  This also removes runtime telemetry.
    base = purge_irrelevant_legacy_data(
        store,
        keep_crawl_runs=max(0, int(keep_crawl_runs)),
        purge_runtime_telemetry=True,
        vacuum=False,
    )
    if not base.get("ok"):
        return {"ok": False, "stage": "base_hygiene", "base": base}

    with store.connect() as conn:
        # Keep a compact terminal-URL suppression ledger so large historical
        # queue rows can be dropped without rediscovery/refetch.
        terminal_rows = conn.execute(
            """
            SELECT q.url,q.status,q.last_error,q.updated_at,
                   COALESCE((SELECT s.content_hash FROM sources s
                             WHERE s.url=q.url OR s.canonical_url=q.url
                             ORDER BY s.fetched_at DESC LIMIT 1),'') AS content_hash
            FROM crawl_queue q
            WHERE q.status IN ('DONE','SKIPPED_PERMANENT')
            """
        ).fetchall()
        for row in terminal_rows:
            conn.execute(
                """
                INSERT INTO crawl_suppression(url,status,reason,content_hash,updated_at)
                VALUES(?,?,?,?,?)
                ON CONFLICT(url) DO UPDATE SET
                  status=excluded.status,
                  reason=CASE WHEN excluded.reason<>'' THEN excluded.reason ELSE crawl_suppression.reason END,
                  content_hash=CASE WHEN excluded.content_hash<>'' THEN excluded.content_hash ELSE crawl_suppression.content_hash END,
                  updated_at=excluded.updated_at
                """,
                (str(row[0]), str(row[1]), str(row[2] or '')[:1000], str(row[4] or ''), str(row[3] or '')),
            )
        moved["terminal_queue_to_suppression"] = len(terminal_rows)
        cur = conn.execute("DELETE FROM crawl_queue WHERE status IN ('DONE','SKIPPED_PERMANENT')")
        deleted["terminal_queue_rows"] = max(0, int(cur.rowcount or 0))

        if preserve_extracted_knowledge:
            # v6.25 lossless-knowledge mode: these tables are extracted
            # knowledge/provenance, not disposable runtime telemetry.  Keep all
            # unique rows in the active DB even if another representation exists.
            deleted["materialized_link_evidence"] = 0
            deleted["redundant_extraction_evidence"] = 0
            deleted["chunk_duplicated_page_facts"] = 0
            deleted["old_product_observations"] = 0
        else:
            # Legacy space-first behaviour retained for explicit opt-in only.
            cur = conn.execute(
                """
                DELETE FROM link_evidence
                WHERE EXISTS (
                    SELECT 1
                    FROM nodes ns, nodes nt, edges e
                    WHERE ns.node_key=('url:' || link_evidence.source_url)
                      AND nt.node_key=('url:' || link_evidence.target_url)
                      AND e.source_id=ns.id
                      AND e.target_id=nt.id
                      AND e.predicate=link_evidence.relation
                )
                """
            )
            deleted["materialized_link_evidence"] = max(0, int(cur.rowcount or 0))

            cur = conn.execute(
                """
                DELETE FROM extraction_evidence
                WHERE evidence_kind IN ('document_section','recommendation','dell_aia_text_cache')
                  AND EXISTS (SELECT 1 FROM chunks c WHERE c.source_url=extraction_evidence.source_url)
                """
            )
            deleted["redundant_extraction_evidence"] = max(0, int(cur.rowcount or 0))

            cur = conn.execute(
                """
                DELETE FROM facts
                WHERE predicate IN ('SECTION_SUMMARY','RECOMMENDATION')
                  AND source_url<>''
                  AND EXISTS (SELECT 1 FROM chunks c WHERE c.source_url=facts.source_url)
                """
            )
            deleted["chunk_duplicated_page_facts"] = max(0, int(cur.rowcount or 0))

            # Optional aggressive mode: preserve the newest N observations.
            keep_obs = max(1, int(keep_product_observations))
            try:
                cur = conn.execute(
                    """
                    DELETE FROM product_observations
                    WHERE id IN (
                        SELECT id FROM (
                            SELECT id,
                                   ROW_NUMBER() OVER (
                                       PARTITION BY product_id
                                       ORDER BY observed_at DESC, id DESC
                                   ) AS rn
                            FROM product_observations
                        ) ranked
                        WHERE rn>?
                    )
                    """,
                    (keep_obs,),
                )
                deleted["old_product_observations"] = max(0, int(cur.rowcount or 0))
            except sqlite3.OperationalError:
                deleted["old_product_observations"] = 0

        # Remove queue rows for duplicate assets after their compact suppression
        # purpose has expired. They carry no unique extracted knowledge.
        cur = conn.execute("DELETE FROM crawl_queue WHERE status='SKIPPED_DUPLICATE_ASSET'")
        deleted["duplicate_asset_queue_rows"] = max(0, int(cur.rowcount or 0))

        conn.execute("PRAGMA optimize")
        space_after_delete = _db_space(conn)
        suppression_count = int(conn.execute("SELECT COUNT(*) FROM crawl_suppression").fetchone()[0])

    after = database_hygiene_report(store)
    return {
        "ok": True,
        "policy": "v6.25-lossless-knowledge-cleanup" if preserve_extracted_knowledge else "v6.23-lean-logical-cleanup",
        "preserve_extracted_knowledge": bool(preserve_extracted_knowledge),
        "base_hygiene": base,
        "moved": moved,
        "deleted": deleted,
        "crawl_suppression_rows": suppression_count,
        "before": before,
        "after": after,
        "sqlite_space_after_delete": space_after_delete,
    }


def _quote_sqlite_filename(path: Path) -> str:
    return "'" + str(path).replace("'", "''") + "'"


def compact_swap_database(
    db: Path,
    *,
    compact_dir: Path | None = None,
    retain_compact_copy: bool = False,
    safety_bytes: int = 64 * 1024 * 1024,
) -> dict[str, Any]:
    """Physically shrink SQLite using VACUUM INTO + verified replacement.

    Unlike plain VACUUM, the compact output may live on another drive.  This
    works for nearly-full C:/OneDrive repositories: build and verify the compact
    copy elsewhere, then replace the bloated source.  The source is never
    deleted until the compact copy passes integrity + FK checks.
    """
    db = db.resolve()
    if not db.exists():
        return {"ok": False, "status": "db_missing", "database": str(db)}

    with sqlite3.connect(db, timeout=180) as conn:
        conn.execute("PRAGMA foreign_keys=ON")
        integrity_before = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk_before = [tuple(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
        try:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:
            pass
        space = _db_space(conn)
    if integrity_before.casefold() != "ok" or fk_before:
        return {
            "ok": False,
            "status": "source_not_clean",
            "integrity_before": integrity_before,
            "foreign_keys_before": fk_before[:20],
        }

    destination_dir = (compact_dir or db.parent).resolve()
    destination_dir.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(destination_dir)
    estimated = max(16 * 1024 * 1024, int(space["estimated_live_bytes"] * 1.10))
    required = estimated + max(16 * 1024 * 1024, int(safety_bytes))
    if usage.free < required:
        return {
            "ok": True,
            "status": "logical_cleanup_only_insufficient_compact_space",
            "database_bytes": _file_size(db),
            "estimated_compact_bytes": estimated,
            "free_bytes_at_compact_dir": usage.free,
            "required_free_bytes": required,
            "compact_dir": str(destination_dir),
            "hint": "Use --compact-dir on a drive with free space to physically shrink the DB.",
        }

    stamp = time.strftime("%Y%m%dT%H%M%S")
    compact = destination_dir / f"{db.stem}.v623_compact_{stamp}{db.suffix}"
    if compact.exists():
        compact.unlink()

    try:
        conn = sqlite3.connect(db, timeout=300, isolation_level=None)
        try:
            conn.execute("PRAGMA busy_timeout=300000")
            conn.execute(f"VACUUM INTO {_quote_sqlite_filename(compact)}")
        finally:
            conn.close()
    except sqlite3.OperationalError as exc:
        msg = str(exc)
        try:
            compact.unlink(missing_ok=True)
        except OSError:
            pass
        if "disk is full" in msg.casefold() or "database or disk is full" in msg.casefold():
            return {
                "ok": True,
                "status": "logical_cleanup_only_disk_full_during_compact",
                "error": msg,
                "compact_dir": str(destination_dir),
            }
        return {"ok": False, "status": "vacuum_into_failed", "error": msg}

    with sqlite3.connect(compact, timeout=180) as conn:
        integrity_compact = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk_compact = [tuple(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
    if integrity_compact.casefold() != "ok" or fk_compact:
        return {
            "ok": False,
            "status": "compact_verification_failed",
            "compact_path": str(compact),
            "integrity": integrity_compact,
            "foreign_keys": fk_compact[:20],
        }

    original_bytes = _file_size(db)
    compact_bytes = _file_size(compact)
    same_volume = os.path.splitdrive(str(db))[0].casefold() == os.path.splitdrive(str(compact))[0].casefold()
    rollback = db.with_name(db.name + ".v623_swap_old")
    rollback.unlink(missing_ok=True)

    # No SQLite connections are open now. First rename original (cheap and
    # reversible). Same-volume compact can then be atomically moved in place.
    os.replace(db, rollback)
    try:
        if same_volume:
            os.replace(compact, db)
        else:
            # On another drive, removing the old file releases enough local
            # space before copying the verified compact DB back.
            rollback.unlink(missing_ok=True)
            shutil.copy2(compact, db)
        with sqlite3.connect(db, timeout=180) as conn:
            integrity_after = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
            fk_after = [tuple(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
        if integrity_after.casefold() != "ok" or fk_after:
            raise RuntimeError(f"replacement verification failed: integrity={integrity_after}, fk={fk_after[:10]}")
    except Exception as exc:
        # Same-volume rollback remains recoverable. Cross-volume compact itself
        # is a verified recovery copy even if copying back failed.
        try:
            if rollback.exists():
                db.unlink(missing_ok=True)
                os.replace(rollback, db)
        except OSError:
            pass
        return {
            "ok": False,
            "status": "replacement_failed",
            "error": f"{type(exc).__name__}: {exc}",
            "verified_compact_path": str(compact) if compact.exists() else "",
        }

    rollback.unlink(missing_ok=True)
    if not retain_compact_copy and compact.exists() and compact.resolve() != db.resolve():
        compact.unlink(missing_ok=True)

    return {
        "ok": True,
        "status": "completed",
        "database": str(db),
        "original_bytes": original_bytes,
        "compact_bytes": _file_size(db),
        "bytes_reclaimed": max(0, original_bytes - _file_size(db)),
        "estimated_live_bytes_before": space["estimated_live_bytes"],
        "internal_free_bytes_before": space["estimated_free_inside_db_bytes"],
        "compact_dir": str(destination_dir),
        "integrity_after": "ok",
        "foreign_keys_after": [],
    }


def _stitch_chunk_text(parts: list[str], *, max_overlap: int = 2000) -> str:
    """Reconstruct source text from historical overlapping chunks without duplicating overlap."""
    clean = [str(part or "").strip() for part in parts if str(part or "").strip()]
    if not clean:
        return ""
    out = clean[0]
    for part in clean[1:]:
        # Whole-part duplicate/containment is common after older retry paths.
        tail_window = out[-max(len(part) + 64, max_overlap * 2):]
        if part in tail_window:
            continue
        overlap = 0
        cap = min(max_overlap, len(out), len(part))
        for size in range(cap, 31, -1):
            if out[-size:] == part[:size]:
                overlap = size
                break
        remainder = part[overlap:].lstrip() if overlap else part
        if remainder:
            out = f"{out}\n{remainder}" if out else remainder
    return out.strip()


def consolidate_chunk_segments(
    store: SQLiteKnowledgeGraph,
    *,
    target_chars: int = 9000,
    overlap_chars: int = 0,
) -> dict[str, Any]:
    """Merge excessive historical search chunks while preserving source text.

    Older builds used ~3500 character chunks with overlap. Long Dell manuals and
    product pages could therefore create hundreds of rows. v6.24 reconstructs the
    persisted source text, removes overlap duplication, and resegments into larger
    heading-aware retrieval chunks. This changes storage granularity, not knowledge.
    """
    target_chars = max(5000, int(target_chars))
    overlap_chars = max(0, min(int(overlap_chars), 500))
    before_rows = 0
    after_rows = 0
    before_chars = 0
    after_chars = 0
    sources_resegmented = 0

    with store.connect() as conn:
        source_rows = conn.execute(
            "SELECT source_url,COUNT(*) AS n,SUM(LENGTH(text)) AS chars FROM chunks GROUP BY source_url HAVING COUNT(*)>1"
        ).fetchall()
        before_rows = int(conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0])
        before_chars = int(conn.execute("SELECT COALESCE(SUM(LENGTH(text)),0) FROM chunks").fetchone()[0])

        # Avoid repeatedly updating FTS for each delete/insert; rebuild once.
        fts_ok = True
        try:
            conn.executescript(
                """
                DROP TRIGGER IF EXISTS chunks_fts_ai;
                DROP TRIGGER IF EXISTS chunks_fts_ad;
                DROP TRIGGER IF EXISTS chunks_fts_au;
                """
            )
        except sqlite3.OperationalError:
            fts_ok = False

        for source_row in source_rows:
            source_url = str(source_row[0])
            rows = conn.execute(
                "SELECT heading,text FROM chunks WHERE source_url=? ORDER BY chunk_index,id",
                (source_url,),
            ).fetchall()
            parts = [str(row[1] or "") for row in rows]
            reconstructed = _stitch_chunk_text(parts)
            if not reconstructed:
                continue
            new_chunks = SQLiteKnowledgeGraph._chunk_text(
                reconstructed,
                max_chars=target_chars,
                overlap_chars=overlap_chars,
            )
            if len(new_chunks) >= len(rows):
                # Still rewrite if old overlap materially duplicated storage.
                old_chars = sum(len(p) for p in parts)
                new_chars = sum(len(text) for _, text in new_chunks)
                if new_chars >= old_chars * 0.97:
                    continue
            conn.execute("DELETE FROM chunks WHERE source_url=?", (source_url,))
            for index, (heading, text) in enumerate(new_chunks):
                import hashlib
                digest = hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()
                conn.execute(
                    "INSERT INTO chunks(source_url,chunk_index,heading,text,content_hash) VALUES(?,?,?,?,?)",
                    (source_url, index, heading, text, digest),
                )
            sources_resegmented += 1

        if fts_ok:
            try:
                conn.executescript(
                    """
                    CREATE TRIGGER chunks_fts_ai AFTER INSERT ON chunks BEGIN
                      INSERT INTO chunks_fts(rowid,text,heading,source_url)
                      VALUES(new.id,new.text,new.heading,new.source_url);
                    END;
                    CREATE TRIGGER chunks_fts_ad AFTER DELETE ON chunks BEGIN
                      INSERT INTO chunks_fts(chunks_fts,rowid,text,heading,source_url)
                      VALUES('delete',old.id,old.text,old.heading,old.source_url);
                    END;
                    CREATE TRIGGER chunks_fts_au AFTER UPDATE ON chunks BEGIN
                      INSERT INTO chunks_fts(chunks_fts,rowid,text,heading,source_url)
                      VALUES('delete',old.id,old.text,old.heading,old.source_url);
                      INSERT INTO chunks_fts(rowid,text,heading,source_url)
                      VALUES(new.id,new.text,new.heading,new.source_url);
                    END;
                    """
                )
                conn.execute("INSERT INTO chunks_fts(chunks_fts) VALUES('rebuild')")
            except sqlite3.OperationalError:
                pass

        after_rows = int(conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0])
        after_chars = int(conn.execute("SELECT COALESCE(SUM(LENGTH(text)),0) FROM chunks").fetchone()[0])
        conn.execute("PRAGMA optimize")

    return {
        "ok": True,
        "target_chars": target_chars,
        "overlap_chars": overlap_chars,
        "sources_resegmented": sources_resegmented,
        "chunk_rows_before": before_rows,
        "chunk_rows_after": after_rows,
        "chunk_rows_removed": max(0, before_rows - after_rows),
        "stored_chunk_chars_before": before_chars,
        "stored_chunk_chars_after": after_chars,
        "stored_chunk_chars_removed": max(0, before_chars - after_chars),
    }


def remove_exact_duplicate_source_chunks(store: SQLiteKnowledgeGraph) -> dict[str, Any]:
    """Keep chunks once per exact rendered-content hash and retain alias source metadata."""
    deleted_rows = 0
    duplicate_sources = 0
    with store.connect() as conn:
        groups = conn.execute(
            """
            SELECT json_extract(metadata_json,'$.semantic_content_hash') AS h,COUNT(*)
            FROM sources
            WHERE COALESCE(json_extract(metadata_json,'$.semantic_content_hash'),'')<>''
            GROUP BY h HAVING COUNT(*)>1
            """
        ).fetchall()
        for group in groups:
            digest = str(group[0] or "")
            rows = conn.execute(
                """
                SELECT s.url,s.fetched_at,s.metadata_json,
                       (SELECT COUNT(*) FROM chunks c WHERE c.source_url=s.url) AS chunk_count
                FROM sources s
                WHERE json_extract(s.metadata_json,'$.semantic_content_hash')=?
                ORDER BY chunk_count DESC,s.fetched_at ASC,s.url ASC
                """,
                (digest,),
            ).fetchall()
            if not rows:
                continue
            canonical = str(rows[0][0])
            if int(rows[0][3] or 0) <= 0:
                continue
            for row in rows[1:]:
                alias = str(row[0])
                count = int(row[3] or 0)
                if count <= 0:
                    continue
                cur = conn.execute("DELETE FROM chunks WHERE source_url=?", (alias,))
                deleted_rows += max(0, int(cur.rowcount or 0))
                duplicate_sources += 1
                try:
                    import json
                    metadata = json.loads(str(row[2] or "{}"))
                    if not isinstance(metadata, dict):
                        metadata = {}
                except Exception:
                    metadata = {}
                metadata["duplicate_content_of"] = canonical
                metadata["chunks_shared_with"] = canonical
                metadata["duplicate_chunks_removed_v624"] = True
                conn.execute(
                    "UPDATE sources SET metadata_json=? WHERE url=?",
                    (json.dumps(metadata, ensure_ascii=False, sort_keys=True, default=str), alias),
                )
        try:
            conn.execute("INSERT INTO chunks_fts(chunks_fts) VALUES('rebuild')")
        except sqlite3.OperationalError:
            pass
    return {
        "ok": True,
        "duplicate_sources_compacted": duplicate_sources,
        "duplicate_chunk_rows_deleted": deleted_rows,
    }

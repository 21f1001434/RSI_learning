from __future__ import annotations

"""Canonical ontology used by the crawler and downstream graph exporters.

The crawler deliberately preserves raw evidence, but graph labels and relationship
names must remain bounded.  Arbitrary JSON keys, schema.org classes and LLM-created
names therefore never become new graph labels or relationship types.
"""

import re
from typing import Any

CANONICAL_NODE_TYPES: tuple[str, ...] = (
    "Page",
    "Product",
    "ProductFamily",
    "Category",
    "Brand",
    "Offer",
    "Review",
    "Document",
    "Section",
    "SupportArticle",
    "FAQ",
    "Requirement",
    "Compatibility",
    "UseCase",
    "Workload",
    "Solution",
    "Service",
    "Software",
    "Organization",
    "Market",
    "AccountTopic",
    "Warranty",
    "FinancingOption",
    "RewardProgram",
    "DeliveryOption",
    "VisualAsset",
    "Concept",
)

CANONICAL_RELATIONSHIP_TYPES: tuple[str, ...] = (
    "MENTIONS",
    "LINKS_TO",
    "AVAILABLE_IN",
    "MADE_BY",
    "IN_CATEGORY",
    "IN_FAMILY",
    "HAS_OFFER",
    "HAS_REVIEW",
    "SUPPORTS_USE_CASE",
    "SUPPORTS_WORKLOAD",
    "PART_OF_SOLUTION",
    "PROVIDED_BY",
    "HAS_DOCUMENT",
    "HAS_SECTION",
    "HAS_FAQ",
    "HAS_REQUIREMENT",
    "COMPATIBLE_WITH",
    "HAS_ENDPOINT",
    "HAS_SUMMARY",
    "DESCRIBES",
    "HAS_WARRANTY",
    "HAS_FINANCING",
    "EARNS_REWARD",
    "HAS_DELIVERY_OPTION",
    "RECOMMENDED_WITH",
    "DUPLICATE_CONTENT_OF",
    "RELATED_TO",
)

_NODE_ALIASES: dict[str, str] = {
    # pages / documents
    "webpage": "Page", "page": "Page", "endpoint": "Page", "resource": "Page",
    "productcatalog": "Page", "offercatalog": "Page", "categorypage": "Page",
    "productpage": "Page", "homepage": "Page", "landingpage": "Page",
    "aisolutionpage": "Page", "solutionpage": "Page", "aboutpage": "Page",
    "accountpage": "AccountTopic", "myaccount": "AccountTopic", "accounttopic": "AccountTopic",
    "document": "Document", "pdf": "Document", "manual": "Document", "manualorsupport": "SupportArticle",
    "supportarticle": "SupportArticle", "supportpage": "SupportArticle", "knowledgebasearticle": "SupportArticle",
    "documentsection": "Section", "section": "Section", "documentsummary": "Section",
    # commerce entities
    "product": "Product", "accessory": "Product", "device": "Product", "computer": "Product",
    "productfamily": "ProductFamily", "family": "ProductFamily", "series": "ProductFamily",
    "category": "Category", "productcategory": "Category", "brand": "Brand", "manufacturer": "Brand",
    "offer": "Offer", "deal": "Offer", "coupon": "Offer", "promotion": "Offer",
    "review": "Review", "productreview": "Review", "customerreview": "Review", "aggregaterating": "Review",
    # solution / service knowledge
    "usecase": "UseCase", "use_case": "UseCase", "workload": "Workload",
    "solution": "Solution", "aisolution": "Solution", "service": "Service", "software": "Software",
    "organization": "Organization", "company": "Organization", "market": "Market",
    "faq": "FAQ", "question": "FAQ", "requirement": "Requirement",
    "compatibilityitem": "Compatibility", "compatibility": "Compatibility",
    "warranty": "Warranty", "warrantyoption": "Warranty", "protectionplan": "Warranty", "supportplan": "Warranty",
    "financing": "FinancingOption", "financingoption": "FinancingOption", "paymentplan": "FinancingOption", "monthlypayment": "FinancingOption",
    "rewardprogram": "RewardProgram", "rewardsprogram": "RewardProgram", "loyaltyprogram": "RewardProgram", "dellrewards": "RewardProgram",
    "deliveryoption": "DeliveryOption", "shippingoption": "DeliveryOption", "delivery": "DeliveryOption", "shipping": "DeliveryOption",
    "visualasset": "VisualAsset", "imageobject": "VisualAsset", "image": "VisualAsset",
    # noisy schema/attribute classes should never become labels
    "attribute": "Concept", "propertyvalue": "Concept", "battery": "Concept", "colour": "Concept",
    "color": "Concept", "audio": "Concept", "benefit": "Concept", "claim": "Concept",
    "breadcrumblist": "Concept", "itemlist": "Concept", "listitem": "Concept",
    "thing": "Concept", "entity": "Concept", "unknown": "Concept", "recommendation": "Concept",
}

_REL_ALIASES: dict[str, str] = {
    "HAS_PRODUCT_DETAIL": "DESCRIBES",
    "DESCRIBES_PRODUCT": "DESCRIBES",
    "LISTS_PRODUCT": "MENTIONS",
    "HAS_COMPATIBILITY": "COMPATIBLE_WITH",
    "REQUIRES": "HAS_REQUIREMENT",
    "HAS_RECOMMENDATION": "RELATED_TO",
    "SUPPORTS": "RELATED_TO",
    "RELATED": "RELATED_TO",
    "PART_OF": "RELATED_TO",
    "BELONGS_TO": "RELATED_TO",
    "HAS_BRAND": "MADE_BY",
    "BRAND": "MADE_BY",
    "HAS_CATEGORY": "IN_CATEGORY",
    "CATEGORY": "IN_CATEGORY",
    "HAS_FAMILY": "IN_FAMILY",
    "FAMILY": "IN_FAMILY",
    "WARRANTY": "HAS_WARRANTY",
    "HAS_PROTECTION_PLAN": "HAS_WARRANTY",
    "FINANCING": "HAS_FINANCING",
    "HAS_PAYMENT_PLAN": "HAS_FINANCING",
    "REWARDS": "EARNS_REWARD",
    "HAS_REWARD": "EARNS_REWARD",
    "DELIVERY": "HAS_DELIVERY_OPTION",
    "SHIPPING": "HAS_DELIVERY_OPTION",
    "RECOMMENDS": "RECOMMENDED_WITH",
    "RECOMMENDED_FOR": "RECOMMENDED_WITH",
}


def _token(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())


def canonical_node_type(raw_type: Any, *, context: str = "entity") -> str:
    raw = str(raw_type or "").strip()
    token = _token(raw)
    mapped = _NODE_ALIASES.get(token)
    if mapped:
        # A raw crawler page must remain a page-like node even if the page classifier
        # called it Product/Offer/etc.; semantic Product/Offer nodes are extracted separately.
        if context == "page" and mapped in {"Product", "Offer", "Review", "UseCase", "Workload", "Solution", "Service", "Software", "Warranty", "FinancingOption", "RewardProgram", "DeliveryOption"}:
            return "Page"
        return mapped
    if raw in CANONICAL_NODE_TYPES:
        return raw
    # Conservative keyword fallbacks; otherwise preserve evidence as Concept.
    lower = raw.casefold()
    if "product" in lower and context != "page":
        return "Product"
    if "review" in lower or "rating" in lower:
        return "Review"
    if "support" in lower or "knowledge" in lower:
        return "SupportArticle" if context != "page" else "SupportArticle"
    if "document" in lower or "manual" in lower or "pdf" in lower:
        return "Document"
    if "solution" in lower:
        return "Solution" if context != "page" else "Page"
    if "service" in lower:
        return "Service" if context != "page" else "Page"
    if "software" in lower:
        return "Software" if context != "page" else "Page"
    if "offer" in lower or "deal" in lower or "coupon" in lower:
        return "Offer" if context != "page" else "Page"
    if "warrant" in lower or "protection plan" in lower:
        return "Warranty" if context != "page" else "Page"
    if "financ" in lower or "payment plan" in lower or "installment" in lower:
        return "FinancingOption" if context != "page" else "Page"
    if "reward" in lower or "loyalty" in lower:
        return "RewardProgram" if context != "page" else "Page"
    if "deliver" in lower or "shipping" in lower or "fulfillment" in lower:
        return "DeliveryOption" if context != "page" else "Page"
    return "Concept" if context != "page" else "Page"


def canonical_relationship_type(raw_type: Any) -> str:
    raw = re.sub(r"[^A-Z0-9_]+", "_", str(raw_type or "RELATED_TO").upper()).strip("_") or "RELATED_TO"
    if raw in CANONICAL_RELATIONSHIP_TYPES:
        return raw
    if raw in _REL_ALIASES:
        return _REL_ALIASES[raw]
    if raw.startswith("LINK") or raw in {"NAVIGATES_TO", "DISCOVERED", "DISCOVERED_FROM"}:
        return "LINKS_TO"
    if "OFFER" in raw or "DEAL" in raw or "COUPON" in raw:
        return "HAS_OFFER"
    if "REVIEW" in raw or "RATING" in raw:
        return "HAS_REVIEW"
    if "FAQ" in raw:
        return "HAS_FAQ"
    if "REQUIRE" in raw:
        return "HAS_REQUIREMENT"
    if "COMPAT" in raw:
        return "COMPATIBLE_WITH"
    if "CATEGORY" in raw:
        return "IN_CATEGORY"
    if "BRAND" in raw or "MANUFACTUR" in raw:
        return "MADE_BY"
    if "FAMILY" in raw or "SERIES" in raw:
        return "IN_FAMILY"
    if "USE_CASE" in raw or "USECASE" in raw:
        return "SUPPORTS_USE_CASE"
    if "WORKLOAD" in raw:
        return "SUPPORTS_WORKLOAD"
    if "WARRANT" in raw or "PROTECTION" in raw:
        return "HAS_WARRANTY"
    if "FINANC" in raw or "PAYMENT_PLAN" in raw:
        return "HAS_FINANCING"
    if "REWARD" in raw or "LOYALTY" in raw:
        return "EARNS_REWARD"
    if "DELIVERY" in raw or "SHIPPING" in raw:
        return "HAS_DELIVERY_OPTION"
    if "RECOMMEND" in raw or "BUNDLE" in raw:
        return "RECOMMENDED_WITH"
    if "DOCUMENT" in raw or "MANUAL" in raw:
        return "HAS_DOCUMENT"
    if "SECTION" in raw:
        return "HAS_SECTION"
    return "RELATED_TO"


def canonical_fact_key(raw: Any) -> str:
    """Bound a property/fact name without turning it into a graph schema token."""
    value = re.sub(r"[^A-Z0-9_]+", "_", str(raw or "OBSERVATION").upper()).strip("_")
    return value[:120] or "OBSERVATION"

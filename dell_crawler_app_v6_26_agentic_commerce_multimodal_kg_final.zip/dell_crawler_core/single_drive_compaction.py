from __future__ import annotations

"""Single-drive SQLite compaction for v6.24.

When C: is the only volume and nearly full, VACUUM/VACUUM INTO may be unable to
create a second full database. This module creates a compressed logical safety
archive, removes the bloated SQLite file only after that archive is verified,
and restores the canonical tables into a fresh compact database on the same
path. FTS indexes are deliberately rebuilt from authoritative chunks/nodes.
"""

from pathlib import Path
from typing import Any
import gzip
import hashlib
import os
import shutil
import sqlite3
import time

from .kg_store import SQLiteKnowledgeGraph


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def drop_rebuildable_fts(db: Path) -> dict[str, Any]:
    """Drop only regenerable FTS indexes/triggers to reduce logical backup size."""
    db = db.resolve()
    with sqlite3.connect(db, timeout=180, isolation_level=None) as conn:
        conn.execute("PRAGMA busy_timeout=180000")
        try:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:
            pass
        conn.executescript(
            """
            DROP TRIGGER IF EXISTS chunks_fts_ai;
            DROP TRIGGER IF EXISTS chunks_fts_ad;
            DROP TRIGGER IF EXISTS chunks_fts_au;
            DROP TRIGGER IF EXISTS nodes_fts_ai;
            DROP TRIGGER IF EXISTS nodes_fts_ad;
            DROP TRIGGER IF EXISTS nodes_fts_au;
            DROP TABLE IF EXISTS chunks_fts;
            DROP TABLE IF EXISTS nodes_fts;
            """
        )
        conn.execute("PRAGMA optimize")
    return {"ok": True, "status": "dropped_rebuildable_fts"}


def create_compressed_logical_backup(db: Path, destination: Path) -> dict[str, Any]:
    """Stream sqlite3.iterdump() through gzip; needs far less free space than a DB copy."""
    db, destination = db.resolve(), destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.with_suffix(destination.suffix + ".part")
    tmp.unlink(missing_ok=True)
    statements = 0
    uncompressed_bytes = 0
    with sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True, timeout=180) as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
        if integrity.casefold() != "ok" or fk:
            return {"ok": False, "status": "source_not_clean", "integrity": integrity, "foreign_keys": fk[:20]}
        with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=6, newline="\n") as handle:
            handle.write("-- DELL_CRAWLER_V624_LOGICAL_BACKUP\n")
            for statement in conn.iterdump():
                text = str(statement)
                handle.write(text)
                handle.write("\n")
                statements += 1
                uncompressed_bytes += len(text.encode("utf-8", errors="ignore")) + 1
    os.replace(tmp, destination)
    # Full gzip read verifies CRC/truncation before the original DB can ever be removed.
    line_count = 0
    has_begin = has_commit = False
    with gzip.open(destination, "rt", encoding="utf-8") as handle:
        for line in handle:
            line_count += 1
            upper = line.strip().upper()
            has_begin = has_begin or upper.startswith("BEGIN TRANSACTION")
            has_commit = has_commit or upper == "COMMIT;"
    if not has_begin or not has_commit:
        return {"ok": False, "status": "logical_backup_incomplete", "path": str(destination)}
    return {
        "ok": True,
        "status": "created",
        "path": str(destination),
        "compressed_bytes": destination.stat().st_size,
        "uncompressed_sql_bytes": uncompressed_bytes,
        "statements": statements,
        "lines": line_count,
        "sha256": _sha256(destination),
    }


def _restore_sql_gzip(archive: Path, target: Path) -> dict[str, Any]:
    target = target.resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.unlink(missing_ok=True)
    for suffix in ("-wal", "-shm", "-journal"):
        Path(str(target) + suffix).unlink(missing_ok=True)

    conn = sqlite3.connect(target, timeout=300, isolation_level=None)
    try:
        conn.execute("PRAGMA journal_mode=DELETE")
        conn.execute("PRAGMA synchronous=OFF")
        buffer = ""
        executed = 0
        with gzip.open(archive, "rt", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("-- DELL_CRAWLER_V624_LOGICAL_BACKUP"):
                    continue
                buffer += line
                if sqlite3.complete_statement(buffer):
                    statement = buffer.strip()
                    buffer = ""
                    if not statement:
                        continue
                    try:
                        conn.execute(statement)
                    except sqlite3.OperationalError as exc:
                        # sqlite_sequence may be emitted before AUTOINCREMENT has
                        # created it on some SQLite builds. It is safe to skip; the
                        # following INSERTs recreate correct sequences naturally.
                        if "sqlite_sequence" in statement and "no such table" in str(exc).casefold():
                            continue
                        raise
                    executed += 1
        if buffer.strip():
            conn.execute(buffer)
            executed += 1
    finally:
        conn.close()

    # Recreate compact external-content FTS indexes and current schema migrations.
    store = SQLiteKnowledgeGraph(target)
    with store.connect() as check:
        integrity = str(check.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(r) for r in check.execute("PRAGMA foreign_key_check").fetchall()]
        try:
            check.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:
            pass
        check.execute("PRAGMA optimize")
    return {
        "ok": integrity.casefold() == "ok" and not fk,
        "executed_statements": executed,
        "integrity": integrity,
        "foreign_keys": fk[:20],
        "database_bytes": target.stat().st_size if target.exists() else 0,
    }


def single_drive_compact_rebuild(db: Path, archive: Path) -> dict[str, Any]:
    """Physically shrink a near-full same-drive DB using the verified gzip dump."""
    db, archive = db.resolve(), archive.resolve()
    if not db.exists() or not archive.exists():
        return {"ok": False, "status": "missing_source_or_archive"}
    original_bytes = db.stat().st_size
    archive_hash = _sha256(archive)
    # Verify archive CRC immediately before destructive swap.
    try:
        with gzip.open(archive, "rb") as handle:
            for _ in iter(lambda: handle.read(4 * 1024 * 1024), b""):
                pass
    except Exception as exc:
        return {"ok": False, "status": "archive_verification_failed", "error": f"{type(exc).__name__}: {exc}"}

    for suffix in ("-wal", "-shm", "-journal"):
        Path(str(db) + suffix).unlink(missing_ok=True)
    db.unlink()
    restore = _restore_sql_gzip(archive, db)
    if not restore.get("ok"):
        # Keep archive and the failed DB for forensic recovery; do not delete the
        # only verified logical backup.
        return {
            "ok": False,
            "status": "restore_failed_archive_retained",
            "archive": str(archive),
            "archive_sha256": archive_hash,
            "restore": restore,
        }
    final_bytes = db.stat().st_size
    return {
        "ok": True,
        "status": "completed_single_drive_logical_rebuild",
        "database": str(db),
        "archive": str(archive),
        "archive_sha256": archive_hash,
        "original_bytes": original_bytes,
        "compact_bytes": final_bytes,
        "bytes_reclaimed": max(0, original_bytes - final_bytes),
        "restore": restore,
    }


def compact_on_single_drive(
    db: Path,
    backup_dir: Path,
    *,
    prefer_vacuum_into: bool = True,
) -> dict[str, Any]:
    """Choose safest available same-drive compaction strategy automatically."""
    from .lean_compaction import compact_swap_database

    db, backup_dir = db.resolve(), backup_dir.resolve()
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%dT%H%M%S")
    logical = backup_dir / f"{db.stem}.pre_v624_{stamp}.sql.gz"

    # Search indexes are regenerable and can make a logical archive needlessly large.
    drop_rebuildable_fts(db)
    backup = create_compressed_logical_backup(db, logical)
    if not backup.get("ok"):
        return {"ok": False, "status": "logical_backup_failed", "backup": backup}

    # Re-initialize FTS before trying the non-destructive VACUUM INTO route.
    SQLiteKnowledgeGraph(db)
    if prefer_vacuum_into:
        compact = compact_swap_database(db, compact_dir=db.parent, safety_bytes=32 * 1024 * 1024)
        if compact.get("ok") and compact.get("status") == "completed":
            compact["logical_backup"] = backup
            compact["strategy"] = "same_drive_vacuum_into"
            return compact

    rebuild = single_drive_compact_rebuild(db, logical)
    rebuild["logical_backup"] = backup
    rebuild["strategy"] = "single_drive_compressed_logical_rebuild"
    return rebuild

from __future__ import annotations

"""Canonical Neo4j export for the Dell crawler.

The export is intentionally semantic, not a dump of every crawler row.  Rich facts,
PDF/image evidence and provenance remain attached as properties/sidecar evidence so
Neo4j does not become fragmented into thousands of Attribute/Section/Image nodes.
"""

import hashlib
import json
from pathlib import Path
from typing import Any

from .kg_store import SQLiteKnowledgeGraph, _loads
from .knowledge_ontology import CANONICAL_RELATIONSHIP_TYPES
from .semantic_identity import GRAPH_NODE_TYPES


ONTOLOGY_VERSION = "v6.26-agentic-commerce"


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _scalar(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, list) and all(isinstance(v, (str, int, float, bool)) or v is None for v in value):
        return [v for v in value if v is not None]
    return _json(value)


def _safe_properties(attrs: dict[str, Any]) -> dict[str, Any]:
    return {str(k): _scalar(v) for k, v in attrs.items() if v not in (None, "", [], {})}


class Neo4jSemanticProjection:
    def __init__(self, db: str | Path | SQLiteKnowledgeGraph):
        self.store = db if isinstance(db, SQLiteKnowledgeGraph) else SQLiteKnowledgeGraph(Path(db))

    def build(self) -> dict[str, Any]:
        nodes: list[dict[str, Any]] = []
        relationships: list[dict[str, Any]] = []
        evidence_rows: list[dict[str, Any]] = []
        source_facts: dict[str, list[dict[str, Any]]] = {}
        with self.store.connect() as conn:
            facts = conn.execute(
                """
                SELECT n.node_key,f.predicate,f.value,f.unit,f.qualifiers_json,f.source_url,
                       f.confidence,f.observed_at,f.valid_from,f.valid_to
                FROM facts f JOIN nodes n ON n.id=f.subject_id
                ORDER BY n.node_key,f.predicate,f.observed_at
                """
            ).fetchall()
            facts_by_node: dict[str, list[dict[str, Any]]] = {}
            for row in facts:
                item = {
                    "predicate": row["predicate"], "value": row["value"], "unit": row["unit"],
                    "qualifiers": _loads(row["qualifiers_json"], {}), "source_url": row["source_url"],
                    "confidence": float(row["confidence"]), "observed_at": row["observed_at"],
                    "valid_from": row["valid_from"], "valid_to": row["valid_to"],
                }
                facts_by_node.setdefault(str(row["node_key"]), []).append(item)
                if row["source_url"]:
                    source_facts.setdefault(str(row["source_url"]), []).append(item)

            node_rows = conn.execute("SELECT * FROM nodes ORDER BY id").fetchall()
            for row in node_rows:
                node_type = str(row["node_type"] or "")
                if node_type not in GRAPH_NODE_TYPES:
                    continue
                key = str(row["node_key"])
                attrs = _loads(row["attributes_json"], {})
                node_facts = facts_by_node.get(key, [])
                source_urls = sorted({str(x.get("source_url") or "") for x in node_facts if x.get("source_url")})
                if attrs.get("source_url"):
                    source_urls.append(str(attrs["source_url"]))
                source_urls = sorted(set(source_urls))
                latest: dict[str, Any] = {}
                for fact in node_facts:
                    latest[str(fact["predicate"])] = fact["value"]
                props = {
                    "node_key": key,
                    "name": str(row["name"] or ""),
                    "canonical_class": node_type,
                    "ontology_version": ONTOLOGY_VERSION,
                    "first_seen": row["first_seen"],
                    "last_seen": row["last_seen"],
                    "source_urls": source_urls,
                    "fact_count": len(node_facts),
                    "facts_json": _json(node_facts),
                    **_safe_properties(attrs),
                }
                # Selected latest facts are flattened for simple Cypher/agent access.
                for pred, value in latest.items():
                    field = "fact__" + "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in pred.casefold())[:100]
                    props[field] = _scalar(value)
                nodes.append({"id": key, "labels": ["SemanticEntity", node_type], "properties": props})

            edge_rows = conn.execute(
                """
                SELECT s.node_key source_key,t.node_key target_key,e.predicate,e.attributes_json,
                       e.source_url,e.confidence,e.first_seen,e.last_seen,s.node_type source_type,t.node_type target_type
                FROM edges e JOIN nodes s ON s.id=e.source_id JOIN nodes t ON t.id=e.target_id
                ORDER BY e.id
                """
            ).fetchall()
            for row in edge_rows:
                if row["source_type"] not in GRAPH_NODE_TYPES or row["target_type"] not in GRAPH_NODE_TYPES:
                    continue
                rel = str(row["predicate"] or "RELATED_TO")
                if rel not in CANONICAL_RELATIONSHIP_TYPES and rel != "DUPLICATE_CONTENT_OF":
                    rel = "RELATED_TO"
                relationships.append({
                    "source": row["source_key"], "type": rel, "target": row["target_key"],
                    "properties": {
                        **_safe_properties(_loads(row["attributes_json"], {})),
                        "source_url": row["source_url"], "confidence": float(row["confidence"]),
                        "first_seen": row["first_seen"], "last_seen": row["last_seen"],
                        "ontology_version": ONTOLOGY_VERSION,
                    },
                })

            evidence = conn.execute(
                "SELECT source_url,evidence_kind,evidence_hash,payload_json,reason,observed_at FROM extraction_evidence ORDER BY id"
            ).fetchall()
            for row in evidence:
                evidence_rows.append({
                    "source_url": row["source_url"], "evidence_kind": row["evidence_kind"],
                    "evidence_hash": row["evidence_hash"], "payload": _loads(row["payload_json"], {}),
                    "reason": row["reason"], "observed_at": row["observed_at"],
                })
            # Include current-run read-only UI interaction evidence too. After a
            # repair these rows are compacted into extraction_evidence, but a live
            # export should already be complete without waiting for another repair.
            try:
                interaction_rows = conn.execute(
                    "SELECT source_url,label,role,action_kind,status,detail,observed_at FROM interactions ORDER BY id"
                ).fetchall()
            except Exception:
                interaction_rows = []
            for row in interaction_rows:
                payload = dict(row)
                evidence_rows.append({
                    "source_url": row["source_url"], "evidence_kind": "live_interaction",
                    "evidence_hash": hashlib.sha256(_json(payload).encode()).hexdigest(),
                    "payload": payload, "reason": "current_run_read_only_interaction",
                    "observed_at": row["observed_at"],
                })

        node_ids = {n["id"] for n in nodes}
        relationships = [r for r in relationships if r["source"] in node_ids and r["target"] in node_ids]
        return {
            "ontology_version": ONTOLOGY_VERSION,
            "node_types": sorted(GRAPH_NODE_TYPES),
            "relationship_types": sorted(CANONICAL_RELATIONSHIP_TYPES),
            "counts": {"nodes": len(nodes), "relationships": len(relationships), "evidence_rows": len(evidence_rows)},
            "nodes": nodes,
            "relationships": relationships,
            "evidence": evidence_rows,
        }

    def export(self, output_dir: str | Path) -> Path:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        payload = self.build()
        files = {
            "nodes.jsonl": payload["nodes"],
            "relationships.jsonl": payload["relationships"],
            "evidence.jsonl": payload["evidence"],
        }
        digests: dict[str, str] = {}
        for name, rows in files.items():
            path = out / name
            with path.open("w", encoding="utf-8") as handle:
                for row in rows:
                    handle.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
            digests[name] = hashlib.sha256(path.read_bytes()).hexdigest()
        manifest = {
            "ontology_version": payload["ontology_version"],
            "node_types": payload["node_types"],
            "relationship_types": payload["relationship_types"],
            "counts": payload["counts"],
            "files": digests,
            "contract": {
                "semantic_nodes_only": True,
                "unclassified_observations": "evidence.jsonl",
                "pdf_and_image_vision_evidence": "evidence.jsonl and facts_json/source properties",
                "neo4j_identity": "SemanticEntity.node_key",
                "agent_retrieval": "combine Neo4j semantic graph with SQLite/evidence sidecar for lossless context",
            },
        }
        (out / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
        return out

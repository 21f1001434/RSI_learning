from __future__ import annotations

"""Pre-repair repository cleanup for low-disk-space upgrades.

This module deliberately removes only regenerable repository/runtime artifacts
before a database repair starts. Durable crawl knowledge, evidence, browser
profiles, credentials, the active SQLite database, and crawler learning memory
are never deleted here.
"""

from pathlib import Path
from typing import Any, Iterable
import os
import shutil
import sqlite3
import time


CACHE_DIR_NAMES = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "htmlcov"}
TEMP_SUFFIXES = (".tmp", ".part", ".download", ".crdownload")


def _size(path: Path) -> int:
    try:
        if path.is_file() or path.is_symlink():
            return int(path.stat().st_size)
        total = 0
        for child in path.rglob("*"):
            try:
                if child.is_file() and not child.is_symlink():
                    total += int(child.stat().st_size)
            except OSError:
                pass
        return total
    except OSError:
        return 0


def _safe_under(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def _delete_path(path: Path, *, root: Path, deleted: list[dict[str, Any]]) -> None:
    if not path.exists() or not _safe_under(path, root):
        return
    size = _size(path)
    try:
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink(missing_ok=True)
        deleted.append({"path": str(path), "bytes": size})
    except OSError as exc:
        deleted.append({"path": str(path), "bytes": 0, "error": f"{type(exc).__name__}: {exc}"})


def _iter_old_backups(db: Path) -> list[Path]:
    parent = db.parent
    stem = db.stem
    suffix = db.suffix
    candidates: set[Path] = set()
    for pattern in (
        f"{stem}.pre_v*{suffix}",
        f"{stem}.pre_v*{suffix}.bak",
        f"{stem}.backup*{suffix}",
        f"{stem}.*backup*{suffix}",
    ):
        candidates.update(parent.glob(pattern))
    candidates.discard(db)
    return sorted(candidates, key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)


def checkpoint_active_database(db: Path) -> dict[str, Any]:
    """Best-effort WAL checkpoint before backup/repair; never deletes WAL manually."""
    if not db.exists():
        return {"status": "db_missing"}
    try:
        conn = sqlite3.connect(db, timeout=60, isolation_level=None)
        try:
            conn.execute("PRAGMA busy_timeout=60000")
            mode = str(conn.execute("PRAGMA journal_mode").fetchone()[0])
            row = conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            return {"status": "ok", "journal_mode": mode, "wal_checkpoint": tuple(row) if row else ()}
        finally:
            conn.close()
    except Exception as exc:
        return {"status": "nonfatal_failure", "error": f"{type(exc).__name__}: {exc}"}


def clean_repository_before_repair(
    root: Path,
    db: Path,
    *,
    keep_old_backups: int = 1,
    temp_age_seconds: int = 900,
    clear_reports: bool = True,
    clear_runtime: bool = True,
) -> dict[str, Any]:
    """Delete regenerable repository data before touching semantic knowledge.

    Protected by policy:
    - active SQLite database and its WAL/SHM/journal files;
    - ``knowledge/text_cache`` and ``knowledge/vision_cache``;
    - ``evidence`` and ``browser_profile`` trees;
    - ``.env`` and any credentials;
    - durable source/graph content inside SQLite.
    """
    root = root.resolve()
    db = db.resolve()
    deleted: list[dict[str, Any]] = []
    before = shutil.disk_usage(db.parent)

    # Code/test caches are always regenerable. Skip .venv and protected data trees.
    protected_top = {".venv", "browser_profile", "evidence", "knowledge"}
    for current, dirs, files in os.walk(root, topdown=True):
        cur = Path(current)
        if cur == root:
            dirs[:] = [d for d in dirs if d not in protected_top]
        for name in list(dirs):
            if name in CACHE_DIR_NAMES:
                _delete_path(cur / name, root=root, deleted=deleted)
                dirs.remove(name)
        if cur == root and ".coverage" in files:
            _delete_path(cur / ".coverage", root=root, deleted=deleted)

    # Runtime/reports contain generated diagnostics only. Keep .gitkeep.
    for folder_name, enabled in (("runtime", clear_runtime), ("reports", clear_reports)):
        folder = root / folder_name
        if enabled and folder.exists():
            for child in list(folder.iterdir()):
                if child.name == ".gitkeep":
                    continue
                _delete_path(child, root=root, deleted=deleted)

    # Stale partial downloads/temp files are safe to remove when the crawler has
    # already been confirmed stopped by repair_v622. Durable evidence, browser
    # profile state and expensive text/vision caches remain protected.
    cutoff = time.time() - max(0, int(temp_age_seconds))
    protected_trees = [
        (root / "browser_profile").resolve(),
        (root / "evidence").resolve(),
        (db.parent / "text_cache").resolve(),
        (db.parent / "vision_cache").resolve(),
    ]
    for base in (root, db.parent):
        if not base.exists():
            continue
        for path in base.rglob("*"):
            try:
                resolved = path.resolve()
                if any(_safe_under(resolved, tree) for tree in protected_trees if tree.exists()):
                    continue
                if not path.is_file() or path == db:
                    continue
                # Never touch active SQLite sidecars; SQLite owns recovery.
                if str(path).startswith(str(db)) and path.suffix in {".db-wal", ".db-shm", ".db-journal"}:
                    continue
                if path.name.endswith(TEMP_SUFFIXES) and path.stat().st_mtime <= cutoff:
                    _delete_path(path, root=root, deleted=deleted)
            except OSError:
                pass

    # Keep only the newest N old DB backups initially. A caller may prune the
    # last retained backup later if more room is required for the fresh backup.
    backups = _iter_old_backups(db)
    keep = max(0, int(keep_old_backups))
    for old in backups[keep:]:
        _delete_path(old, root=root, deleted=deleted)
        for sidecar in (Path(str(old) + "-wal"), Path(str(old) + "-shm"), Path(str(old) + "-journal")):
            _delete_path(sidecar, root=root, deleted=deleted)

    checkpoint = checkpoint_active_database(db)
    after = shutil.disk_usage(db.parent)
    return {
        "policy": "v6.22-clean-first",
        "root": str(root),
        "database": str(db),
        "deleted": deleted,
        "deleted_count": len([x for x in deleted if not x.get("error")]),
        "bytes_reclaimed_estimate": max(0, int(after.free) - int(before.free)),
        "disk_before": {"total": before.total, "used": before.used, "free": before.free},
        "disk_after": {"total": after.total, "used": after.used, "free": after.free},
        "retained_old_backups": [str(p) for p in _iter_old_backups(db)[:keep]],
        "wal_checkpoint": checkpoint,
        "protected": [
            str(db), str(root / ".env"), str(root / "browser_profile"),
            str(root / "evidence"), str(db.parent / "text_cache"), str(db.parent / "vision_cache"),
        ],
    }


def ensure_space_for_fresh_backup(
    root: Path,
    db: Path,
    *,
    backup_dir: Path | None = None,
    safety_bytes: int = 128 * 1024 * 1024,
) -> dict[str, Any]:
    """Ensure enough free space for a fresh SQLite backup.

    If necessary, the final retained *old* pre-v6.x backup is removed. The
    active DB is never touched. This happens before the fresh v6.22 backup is
    created and before semantic repair starts.
    """
    root = root.resolve()
    db = db.resolve()
    destination = (backup_dir or db.parent).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    db_bytes = _size(db)
    required = db_bytes + max(int(safety_bytes), int(db_bytes * 0.10))
    usage = shutil.disk_usage(destination)
    deleted_old: list[str] = []

    if usage.free < required and destination == db.parent:
        # We already pruned all but the newest old backup. Delete remaining old
        # backups one by one until there is enough room for a current backup.
        for old in _iter_old_backups(db):
            if usage.free >= required:
                break
            if old == db or not _safe_under(old, root):
                continue
            try:
                old.unlink(missing_ok=True)
                deleted_old.append(str(old))
                for suffix in ("-wal", "-shm", "-journal"):
                    Path(str(old) + suffix).unlink(missing_ok=True)
            except OSError:
                pass
            usage = shutil.disk_usage(destination)

    usage = shutil.disk_usage(destination)
    return {
        "database_bytes": db_bytes,
        "backup_dir": str(destination),
        "required_free_bytes": required,
        "free_bytes": usage.free,
        "enough_space": usage.free >= required,
        "old_backups_deleted_for_space": deleted_old,
    }


def safe_final_vacuum(db: Path, *, enabled: bool = True) -> dict[str, Any]:
    """VACUUM only when the filesystem can safely hold SQLite's rewrite.

    Low disk space is reported as a clean skip, not a failed repair. This is the
    key difference from v6.20/v6.21 behavior seen in real repositories.
    """
    db = db.resolve()
    if not enabled:
        return {"status": "disabled", "ok": True}
    db_bytes = _size(db)
    usage = shutil.disk_usage(db.parent)
    # SQLite VACUUM can require roughly one extra DB plus journal/temp overhead.
    required = db_bytes + max(256 * 1024 * 1024, int(db_bytes * 0.25))
    if usage.free < required:
        return {
            "status": "skipped_low_disk_space",
            "ok": True,
            "database_bytes": db_bytes,
            "free_bytes": usage.free,
            "required_free_bytes": required,
        }
    try:
        conn = sqlite3.connect(db, timeout=180, isolation_level=None)
        try:
            conn.execute("PRAGMA busy_timeout=180000")
            try:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except Exception:
                pass
            conn.execute("VACUUM")
            conn.execute("PRAGMA optimize")
        finally:
            conn.close()
        usage_after = shutil.disk_usage(db.parent)
        return {
            "status": "completed",
            "ok": True,
            "database_bytes_after": _size(db),
            "free_bytes_after": usage_after.free,
        }
    except sqlite3.OperationalError as exc:
        message = str(exc)
        if "disk is full" in message.casefold() or "database or disk is full" in message.casefold():
            return {"status": "skipped_disk_full_during_vacuum", "ok": True, "error": message}
        return {"status": "vacuum_failed", "ok": False, "error": message}


def clean_regenerable_knowledge_artifacts(
    knowledge: Path,
    *,
    preserve_text_cache: bool = False,
    preserve_vision_cache: bool = False,
) -> dict[str, Any]:
    """Remove regenerable crawler artifacts that often dominate OneDrive space.

    This intentionally does NOT touch the SQLite DB, raw downloaded documents,
    screenshots/evidence, browser profile, or semantic knowledge. Text/vision
    response caches and PDF render pages are accelerators only and can be
    reconstructed from retained source/document evidence when needed.
    """
    knowledge = knowledge.resolve()
    deleted: list[dict[str, Any]] = []
    if not knowledge.exists():
        return {"ok": True, "knowledge": str(knowledge), "deleted": [], "bytes_deleted": 0}

    cache_dirs: list[str] = ["pdf_visual_pages", "dynamic_states", "document_quarantine"]
    if not preserve_text_cache:
        cache_dirs.append("text_cache")
    if not preserve_vision_cache:
        cache_dirs.append("vision_cache")
    for name in cache_dirs:
        path = knowledge / name
        if path.exists():
            _delete_path(path, root=knowledge, deleted=deleted)

    diagnostic_patterns = (
        "*_FAILURES.jsonl", "*_RECOVERIES.jsonl", "*_SUCCESSES.jsonl",
        "*_TRANSCRIPT_EVENTS.jsonl", "*_EVENTS.jsonl", "*_DEBUG*.jsonl",
        "FRONTIER_COVERAGE_REPORT*.json", "*_COVERAGE_REPORT*.json",
    )
    for pattern in diagnostic_patterns:
        for path in knowledge.glob(pattern):
            _delete_path(path, root=knowledge, deleted=deleted)

    return {
        "ok": not any(item.get("error") for item in deleted),
        "knowledge": str(knowledge),
        "deleted": deleted,
        "deleted_count": len([x for x in deleted if not x.get("error")]),
        "bytes_deleted": sum(int(x.get("bytes", 0)) for x in deleted if not x.get("error")),
        "preserved": ["active SQLite DB", "raw source files", "screenshots", "evidence", "visual_assets"],
    }

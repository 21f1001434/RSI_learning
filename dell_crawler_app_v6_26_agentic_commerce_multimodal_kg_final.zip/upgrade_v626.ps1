param(
    [string]$Db = ".\knowledge\dell_en_uk.db",
    [string]$Knowledge = ".\knowledge"
)
$ErrorActionPreference = "Stop"
python .\repair_v626.py --db $Db --knowledge $Knowledge
python .\audit_knowledge_v626.py --db $Db --knowledge $Knowledge --require-clean
python .\release_verify_v626.py --db $Db
python .\export_neo4j_v626.py --db $Db --out "$Knowledge\neo4j_v626"
python -m streamlit run .\app.py

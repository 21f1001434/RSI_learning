@echo off
python repair_v625.py --db knowledge\dell_en_uk.db --knowledge knowledge || exit /b 1
python audit_knowledge_v625.py --db knowledge\dell_en_uk.db --knowledge knowledge --require-clean || exit /b 1
python release_verify_v625.py --db knowledge\dell_en_uk.db || exit /b 1
python -m streamlit run app.py

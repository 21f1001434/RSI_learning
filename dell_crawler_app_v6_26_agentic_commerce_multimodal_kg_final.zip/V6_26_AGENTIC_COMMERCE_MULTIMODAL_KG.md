# v6.26 — Agentic Commerce + Multimodal Knowledge Graph

v6.26 keeps the v6.25 lossless/single-drive guarantees and makes the semantic projection explicitly ready for an agentic-commerce experience.

## Bounded semantic ontology

The graph admits only canonical semantic classes. In addition to Product/Brand/Category/ProductFamily/Offer/Review/Document/Support/FAQ/Solution/Service/Software/UseCase/Workload/Compatibility/Requirement/Market/Account topics, v6.26 adds bounded commerce classes:

- `Warranty`
- `FinancingOption`
- `RewardProgram`
- `DeliveryOption`

and bounded relationships:

- `HAS_WARRANTY`
- `HAS_FINANCING`
- `EARNS_REWARD`
- `HAS_DELIVERY_OPTION`
- `RECOMMENDED_WITH`

CPU, GPU, RAM, storage, display, OS, colors, battery and other specifications remain Product facts/properties rather than exploding into standalone node labels.

## Rich evidence is not thrown away

The semantic graph is intentionally compact, but the agent retrieval layer combines it with:

- full source/document chunks;
- all Product observations/history;
- facts and provenance;
- PDF text;
- PDF-page/image Dell AIA vision JSON;
- visual text summaries;
- compacted safe UI interaction outcomes;
- unmapped evidence;
- link/discovery provenance.

This means graph de-segmentation does **not** mean information loss.

## New extraction is classified automatically

Every new extraction goes through normalisation, semantic validation, stable identity resolution, duplicate consolidation and bounded relationship mapping before graph persistence. Uncertain objects stay in `extraction_evidence` rather than becoming arbitrary Neo4j labels.

Product attributes are also deterministically projected into commerce nodes when available, so warranty/financing/reward/delivery knowledge remains graph-traversable even if the LLM emitted it only as Product attributes.

## Neo4j export contract

Run:

```powershell
python .\export_neo4j_v626.py --db .\knowledge\dell_en_uk.db --out .\knowledge\neo4j_v626
```

Before import, apply `neo4j_schema_v626.cypher`; `NEO4J_ONTOLOGY_V626.json` is the machine-readable ontology contract.

Output:

- `nodes.jsonl` — canonical semantic nodes with stable `node_key`, specific label + `SemanticEntity`, Product properties and complete fact history JSON;
- `relationships.jsonl` — bounded canonical relationships with provenance/confidence;
- `evidence.jsonl` — lossless multimodal/unmapped evidence sidecar for the agent;
- `manifest.json` — ontology/version/count/hash contract.

The recommended agent pattern is Neo4j for semantic traversal plus the SQLite/evidence sidecar for full-fidelity retrieval.

## Agent retrieval

```powershell
python .\agentic_commerce_query.py --db .\knowledge\dell_en_uk.db show products with 32GB memory financing warranty and delivery
```

The returned bundle includes search hits, semantic neighborhood, facts, Product observations, PDF/image evidence, source metadata and provenance.

## Upgrade

```powershell
python .\repair_v626.py --db .\knowledge\dell_en_uk.db --knowledge .\knowledge
python .\audit_knowledge_v626.py --db .\knowledge\dell_en_uk.db --knowledge .\knowledge --require-clean
python .\release_verify_v626.py --db .\knowledge\dell_en_uk.db
python .\export_neo4j_v626.py --db .\knowledge\dell_en_uk.db --out .\knowledge\neo4j_v626
python -m streamlit run .\app.py
```

The repair stages legacy vision cache results and UI interaction outcomes before v6.25-style storage cleanup, then restores them into durable extraction evidence. This lets a C:-only deployment reclaim disk without discarding previously extracted multimodal knowledge.

// Dell Crawler v6.26 canonical semantic graph schema
CREATE CONSTRAINT semantic_entity_node_key IF NOT EXISTS
FOR (n:SemanticEntity) REQUIRE n.node_key IS UNIQUE;

CREATE INDEX product_order_code_v626 IF NOT EXISTS
FOR (p:Product) ON (p.order_code);

CREATE INDEX product_part_number_v626 IF NOT EXISTS
FOR (p:Product) ON (p.part_number);

CREATE INDEX product_model_v626 IF NOT EXISTS
FOR (p:Product) ON (p.model);

CREATE INDEX product_name_v626 IF NOT EXISTS
FOR (p:Product) ON (p.name);

CREATE INDEX semantic_name_v626 IF NOT EXISTS
FOR (n:SemanticEntity) ON (n.name);

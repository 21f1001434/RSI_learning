from __future__ import annotations

import argparse
import compileall
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
from typing import Any

ROOT = Path(__file__).resolve().parent


def _run(cmd: list[str]) -> dict[str, Any]:
    proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
    return {"command": cmd, "returncode": proc.returncode, "stdout_tail": proc.stdout[-8000:], "stderr_tail": proc.stderr[-8000:], "ok": proc.returncode == 0}


def _manifest_check() -> dict[str, Any]:
    path = ROOT / "MANIFEST_SHA256.json"
    if not path.exists():
        return {"ok": False, "status": "MISSING"}
    payload = json.loads(path.read_text(encoding="utf-8"))
    mismatches = []
    for item in payload.get("files", []):
        p = ROOT / str(item.get("path") or "")
        if not p.exists():
            mismatches.append({"path": str(item.get("path")), "reason": "missing"})
            continue
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        if digest != item.get("sha256") or p.stat().st_size != int(item.get("size_bytes", p.stat().st_size)):
            mismatches.append({"path": str(item.get("path")), "reason": "hash_or_size_mismatch"})
    return {"ok": not mismatches and len(payload.get("files", [])) == int(payload.get("file_count", -1)), "declared_file_count": payload.get("file_count"), "checked_file_count": len(payload.get("files", [])), "mismatches": mismatches}


def _db_check(db: Path) -> dict[str, Any]:
    if not db.exists():
        return {"ok": True, "status": "NOT_PRESENT", "path": str(db)}
    from audit_knowledge_v625 import build_report
    report = build_report(db, db.parent)
    seg = report["segmentation_quality"]
    storage = report["storage_compaction"]
    ok = (
        report["integrity_check"].casefold() == "ok"
        and not report["foreign_key_violations"]
        and bool(report["semantic_quality"].get("clean_for_semantic_sync"))
        and int(seg["oversegmented_sources"]) == 0
        and int(seg["exact_duplicate_content_groups_with_multiple_chunk_copies"]) == 0
        and int(storage["compacted_sources_still_pointing_to_raw_or_screenshot"]) == 0
    )
    return {"ok": ok, "status": "CHECKED", "path": str(db), "audit": report}


def main() -> int:
    p = argparse.ArgumentParser(description="Verify Dell Crawler v6.25 lossless extracted-knowledge release/runtime prerequisites.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--skip-tests", action="store_true")
    p.add_argument("--skip-manifest", action="store_true")
    p.add_argument("--output", default="reports/FINAL_VALIDATION_V625_RUNTIME.json")
    a = p.parse_args()

    imports_ok, import_error = True, ""
    try:
        import dell_crawler_core.dell_crawler  # noqa
        import dell_crawler_core.kg_store  # noqa
        import dell_crawler_core.storage_optimiser  # noqa
        import dell_crawler_core.single_drive_compaction  # noqa
        import dell_crawler_core.lean_compaction  # noqa
    except Exception as exc:
        imports_ok, import_error = False, f"{type(exc).__name__}: {exc}"

    compile_ok = bool(compileall.compile_dir(str(ROOT), quiet=1))
    tests = {"ok": True, "status": "SKIPPED"} if a.skip_tests else _run([sys.executable, "-m", "pytest", "-q"])
    db_result = _db_check(Path(a.db).expanduser().resolve())
    manifest = {"ok": True, "status": "SKIPPED"} if a.skip_manifest else _manifest_check()
    report = {
        "release": "v6.25-lossless-extracted-knowledge-single-drive-final",
        "python": {"version": sys.version, "supported": sys.version_info >= (3, 11), "executable": sys.executable},
        "imports": {"ok": imports_ok, "error": import_error},
        "compileall": {"ok": compile_ok},
        "tests": tests,
        "database": db_result,
        "manifest": manifest,
        "browser_prerequisites": {"node_found": bool(shutil.which("node")), "npx_found": bool(shutil.which("npx") or shutil.which("npx.cmd"))},
        "live_external_checks": {"dell_sso": "NOT_RUN_BY_RELEASE_VERIFIER", "dell_aia": "NOT_RUN_BY_RELEASE_VERIFIER", "dell_com": "NOT_RUN_BY_RELEASE_VERIFIER"},
    }
    report["ok"] = all([report["python"]["supported"], imports_ok, compile_ok, bool(tests.get("ok")), bool(db_result.get("ok")), bool(manifest.get("ok"))])
    out = ROOT / a.output
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

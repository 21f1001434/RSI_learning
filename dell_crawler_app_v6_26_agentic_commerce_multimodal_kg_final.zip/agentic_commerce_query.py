from __future__ import annotations

import argparse
import json
from pathlib import Path

from dell_crawler_core.agentic_commerce import build_agentic_commerce_context


def main() -> int:
    p = argparse.ArgumentParser(description="Retrieve graph + PDF/image + provenance context for a Dell agentic-commerce agent.")
    p.add_argument("query", nargs="+", help="User intent / commerce question")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--limit", type=int, default=12)
    p.add_argument("--evidence-limit", type=int, default=24)
    a = p.parse_args()
    db = Path(a.db)
    if not db.is_file():
        raise SystemExit(f"Database not found: {db}")
    payload = build_agentic_commerce_context(db, " ".join(a.query), limit=a.limit, evidence_limit=a.evidence_limit)
    print(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

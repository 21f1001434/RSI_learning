param(
    [string]$Db = ".\knowledge\dell_en_uk.db",
    [string]$Knowledge = ".\knowledge"
)
$ErrorActionPreference = "Stop"
python .\repair_v624.py --db $Db --knowledge $Knowledge
python .\audit_knowledge_v624.py --db $Db --knowledge $Knowledge --require-clean
python .\release_verify_v624.py --db $Db
python -m streamlit run .\app.py

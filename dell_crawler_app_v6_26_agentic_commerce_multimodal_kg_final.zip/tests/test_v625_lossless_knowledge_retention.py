from __future__ import annotations

from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.lean_compaction import logical_lean_cleanup


def test_lossless_cleanup_preserves_extracted_knowledge_tables(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    a = "https://www.dell.com/en-us/p/a"
    b = "https://www.dell.com/en-us/p/b"
    for url in (a, b):
        store.upsert_source(url, url, "ProductPage", f"hash-{url[-1]}", 200)
        store.replace_chunks(url, f"Persisted source text for {url}")
        store.upsert_node(f"url:{url}", "Page", url, {"url": url})

    store.record_link_evidence(a, b, relation="LINKS_TO", label="Related")
    store.upsert_edge(f"url:{a}", "LINKS_TO", f"url:{b}", a)
    store.record_extraction_evidence(a, {"summary": "derived but extracted"}, evidence_kind="document_section")
    store.add_fact(f"url:{a}", "SECTION_SUMMARY", "Derived section summary", a)

    product_key = "product:order:ABC123"
    store.upsert_node(product_key, "Product", "Precision Test", {"order_code": "ABC123", "product_url": a})
    product = store.node_by_key(product_key)
    assert product is not None
    with store.connect() as conn:
        for i in range(15):
            conn.execute(
                """
                INSERT INTO product_observations(
                    product_id,source_url,observed_at,observation_hash,price,list_price,currency,
                    model,order_code,completeness_score,fields_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """,
                (int(product["id"]), a, f"2026-01-{i+1:02d}T00:00:00Z", f"obs-{i}", str(1000+i), "", "USD", "P", "ABC123", 1.0, "{}"),
            )

    with store.connect() as conn:
        before = {
            "link_evidence": conn.execute("SELECT COUNT(*) FROM link_evidence").fetchone()[0],
            "extraction_evidence": conn.execute("SELECT COUNT(*) FROM extraction_evidence").fetchone()[0],
            "facts": conn.execute("SELECT COUNT(*) FROM facts").fetchone()[0],
            "product_observations": conn.execute("SELECT COUNT(*) FROM product_observations").fetchone()[0],
        }

    result = logical_lean_cleanup(
        store,
        keep_product_observations=1,
        preserve_extracted_knowledge=True,
    )
    assert result["ok"] is True
    assert result["preserve_extracted_knowledge"] is True
    assert result["deleted"]["materialized_link_evidence"] == 0
    assert result["deleted"]["redundant_extraction_evidence"] == 0
    assert result["deleted"]["chunk_duplicated_page_facts"] == 0
    assert result["deleted"]["old_product_observations"] == 0

    with store.connect() as conn:
        after = {
            "link_evidence": conn.execute("SELECT COUNT(*) FROM link_evidence").fetchone()[0],
            "extraction_evidence": conn.execute("SELECT COUNT(*) FROM extraction_evidence").fetchone()[0],
            "facts": conn.execute("SELECT COUNT(*) FROM facts").fetchone()[0],
            "product_observations": conn.execute("SELECT COUNT(*) FROM product_observations").fetchone()[0],
        }
    assert after == before

from pathlib import Path
import json
import sqlite3

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.lean_compaction import consolidate_chunk_segments, remove_exact_duplicate_source_chunks
from dell_crawler_core.storage_optimiser import prune_successfully_extracted_artifacts, prune_browser_profile_caches, enforce_runtime_budgets_v624
from dell_crawler_core.single_drive_compaction import drop_rebuildable_fts, create_compressed_logical_backup, single_drive_compact_rebuild


def _source(store, url, text, meta=None, raw_path="", screenshot_path=""):
    store.upsert_source(url, url, url.rsplit('/', 1)[-1] or url, 'WebPage', 'hash-' + url[-4:], 200, screenshot_path, raw_path, 'text/html', meta or {})
    store.replace_chunks(url, text)


def test_v624_chunk_consolidation_and_exact_duplicate_alias(tmp_path: Path):
    db = tmp_path / 'knowledge.db'
    store = SQLiteKnowledgeGraph(db)
    text = '\n\n'.join(f'Section {i}\n' + ('Dell knowledge paragraph ' * 90) for i in range(18))
    # Simulate old fine segmentation explicitly.
    old_chunks = SQLiteKnowledgeGraph._chunk_text(text, max_chars=2200, overlap_chars=300)
    url1 = 'https://www.dell.com/en-us/shop/example'
    url2 = 'https://www.dell.com/en-us/shop/example?alias=1'
    meta = {'semantic_content_hash': 'same-rendered-hash'}
    store.upsert_source(url1, url1, 'Example', 'WebPage', 'a', 200, '', '', 'text/html', meta)
    store.upsert_source(url2, url2, 'Example alias', 'WebPage', 'b', 200, '', '', 'text/html', meta)
    with store.connect() as conn:
        for u in (url1, url2):
            for i, (heading, chunk) in enumerate(old_chunks):
                import hashlib
                conn.execute('INSERT INTO chunks(source_url,chunk_index,heading,text,content_hash) VALUES(?,?,?,?,?)', (u, i, heading, chunk, hashlib.sha256(chunk.encode()).hexdigest()))
    before = store.stats()['chunks']
    dedupe = remove_exact_duplicate_source_chunks(store)
    result = consolidate_chunk_segments(store, target_chars=9000, overlap_chars=0)
    after = store.stats()['chunks']
    assert dedupe['duplicate_sources_compacted'] == 1
    assert after < before
    assert result['chunk_rows_after'] <= result['chunk_rows_before']
    with store.connect() as conn:
        copies = conn.execute('SELECT COUNT(DISTINCT source_url) FROM chunks').fetchone()[0]
    assert copies == 1


def test_v624_prunes_success_artifacts_but_keeps_incomplete(tmp_path: Path):
    root = tmp_path / 'project'
    knowledge = root / 'knowledge'
    knowledge.mkdir(parents=True)
    db = knowledge / 'k.db'
    store = SQLiteKnowledgeGraph(db)

    raw = knowledge / 'raw'; raw.mkdir()
    shots = knowledge / 'screenshots'; shots.mkdir()
    ok_raw = raw / 'ok.txt'; ok_raw.write_text('x' * 2000)
    ok_shot = shots / 'ok.png'; ok_shot.write_bytes(b'x' * 3000)
    bad_raw = raw / 'bad.txt'; bad_raw.write_text('y' * 2000)

    good = 'https://www.dell.com/en-us/good'
    bad = 'https://www.dell.com/en-us/bad'
    _source(store, good, 'Useful extracted Dell knowledge ' * 300, {'coverage_contract': {'passed': True}, 'raw_path': str(ok_raw), 'visual_evidence': [{'path': str(ok_shot)}]}, str(ok_raw), str(ok_shot))
    _source(store, bad, 'Incomplete Dell knowledge ' * 300, {'coverage_contract': {'passed': False}, 'raw_path': str(bad_raw)}, str(bad_raw), '')

    result = prune_successfully_extracted_artifacts(store, knowledge, root=root, evidence_budget_mb=1, cache_budget_mb=1)
    assert result['bytes_deleted'] >= 5000
    assert not ok_raw.exists() and not ok_shot.exists()
    assert bad_raw.exists()
    with store.connect() as conn:
        row = conn.execute('SELECT raw_path,screenshot_path,metadata_json FROM sources WHERE url=?', (good,)).fetchone()
    assert row[0] == '' and row[1] == ''
    assert json.loads(row[2])['storage_compaction_version'] == 'v6.24'


def test_v624_browser_cache_cleanup_preserves_sso_state(tmp_path: Path):
    root = tmp_path
    profile = root / 'browser_profile' / 'dell_crawler' / 'Default'
    (profile / 'Cache').mkdir(parents=True)
    (profile / 'Cache' / 'blob').write_bytes(b'x' * 1000)
    (profile / 'Cookies').write_bytes(b'cookie-db')
    (profile / 'Local Storage').mkdir()
    (profile / 'Local Storage' / 'state').write_text('sso')
    result = prune_browser_profile_caches(root)
    assert result['bytes_deleted'] >= 1000
    assert not (profile / 'Cache').exists()
    assert (profile / 'Cookies').exists()
    assert (profile / 'Local Storage' / 'state').exists()


def test_v624_single_drive_logical_rebuild_compacts_and_restores(tmp_path: Path):
    db = tmp_path / 'large.db'
    store = SQLiteKnowledgeGraph(db)
    url = 'https://www.dell.com/en-us/knowledge'
    _source(store, url, ('Dell extracted data ' * 4000), {'semantic_content_hash': 'unique'})
    # Inflate and then delete rows to leave free pages in the SQLite file.
    with store.connect() as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS inflate(x TEXT)')
        conn.executemany('INSERT INTO inflate(x) VALUES(?)', [('z' * 4000,) for _ in range(400)])
    with store.connect() as conn:
        conn.execute('DELETE FROM inflate')
    before = db.stat().st_size
    drop_rebuildable_fts(db)
    archive = tmp_path / 'pre.sql.gz'
    backup = create_compressed_logical_backup(db, archive)
    assert backup['ok'] and archive.exists()
    result = single_drive_compact_rebuild(db, archive)
    assert result['ok']
    assert db.exists()
    assert db.stat().st_size < before
    with sqlite3.connect(db) as conn:
        assert conn.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert conn.execute('SELECT COUNT(*) FROM chunks').fetchone()[0] > 0


def test_v624_empty_semantic_graph_is_clean(tmp_path: Path):
    store = SQLiteKnowledgeGraph(tmp_path / "empty_graph.db")
    report = store.semantic_quality_report()
    assert report["semantic_nodes"] == 0
    assert report["node_classification_coverage"] == 1.0
    assert report["clean_for_semantic_sync"] is True


def test_v624_chunker_packs_long_paragraphs_without_heading_fragmentation():
    text = "\n\n".join(
        f"Section {i}\n" + ("Dell product specification processor memory storage support. " * 150)
        for i in range(12)
    )
    chunks = SQLiteKnowledgeGraph._chunk_text(text, max_chars=9000, overlap_chars=0)
    assert chunks
    assert max(len(chunk) for _, chunk in chunks) <= 9000
    assert sum(len(chunk) for _, chunk in chunks) / len(chunks) >= 6500
    assert not any(len(chunk) < 180 and chunk.startswith("Section ") for _, chunk in chunks)


def test_v624_runtime_artifact_budget_trims_orphan_files(tmp_path: Path):
    root = tmp_path / "project"
    knowledge = root / "knowledge"
    raw = knowledge / "raw"
    shots = knowledge / "screenshots"
    raw.mkdir(parents=True)
    shots.mkdir(parents=True)
    # More than 1 MiB total and enough files to get past the keep-newest guard.
    for i in range(40):
        target = raw if i % 2 == 0 else shots
        (target / f"artifact_{i:02d}.bin").write_bytes(b"x" * 64 * 1024)
    before = sum(p.stat().st_size for p in knowledge.rglob("*.bin"))
    result = enforce_runtime_budgets_v624(root, knowledge, evidence_budget_mb=1, cache_budget_mb=1, artifact_budget_mb=1)
    after = sum(p.stat().st_size for p in knowledge.rglob("*.bin"))
    assert before > 1024 * 1024
    assert after <= 1024 * 1024
    assert result["bytes_deleted"] > 0

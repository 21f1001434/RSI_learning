from __future__ import annotations

import json
from pathlib import Path

from dell_crawler_core.agentic_commerce import AgenticCommerceKnowledge
from dell_crawler_core.extraction_normalizer import normalize_extraction_payload
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.neo4j_projection import Neo4jSemanticProjection
from dell_crawler_core.semantic_identity import GRAPH_NODE_TYPES


def _store(tmp_path: Path) -> tuple[SQLiteKnowledgeGraph, str]:
    db = tmp_path / "test.db"
    store = SQLiteKnowledgeGraph(db)
    url = "https://www.dell.com/en-us/shop/test-product/spd/test"
    store.upsert_node(f"url:{url}", "Page", "Test product page", {"source_url": url})
    store.upsert_source(url, url, "Test product page", "ProductPage", "hash", 200, "", "", "text/html", {"vision_evidence_count": 1})
    return store, url


def test_new_commerce_classes_are_normalized_classified_and_linked(tmp_path: Path):
    store, url = _store(tmp_path)
    payload = normalize_extraction_payload({
        "entities": [{"key": "p1", "type": "Product", "name": "Dell Test 14", "attributes": {"order_code": "abc123", "product_url": url}}],
        "warranties": [{"name": "ProSupport 3 Years", "duration": "3 years", "coverage": "onsite", "product_key": "p1"}],
        "financing": [{"name": "Dell Pay", "term": "12 months", "apr": "0", "product_key": "p1"}],
        "rewards": [{"name": "Dell Rewards", "reward": "5%", "product_key": "p1"}],
        "shipping": [{"name": "Standard delivery", "eta": "3-5 days", "product_key": "p1"}],
    }, source_url=url)
    result = store.ingest_extraction(url, payload)
    assert result["nodes_created"] >= 5
    with store.connect() as conn:
        types = {r[0] for r in conn.execute("SELECT DISTINCT node_type FROM nodes")}
        predicates = {r[0] for r in conn.execute("SELECT DISTINCT predicate FROM edges")}
    assert {"Warranty", "FinancingOption", "RewardProgram", "DeliveryOption"}.issubset(types)
    assert {"HAS_WARRANTY", "HAS_FINANCING", "EARNS_REWARD", "HAS_DELIVERY_OPTION"}.issubset(predicates)


def test_vision_bundle_is_persisted_even_when_visual_file_can_be_removed(tmp_path: Path):
    store, url = _store(tmp_path)
    extraction = {
        "page": {}, "entities": [], "relations": [], "facts": [],
        "vision_text": "Architecture diagram shows CPU connected to GPU and storage.",
        "vision_evidence": [{"summary": "Architecture diagram", "visible_text": ["GPU", "Storage"], "evidence": {"page_number": 2}}],
    }
    store.ingest_extraction(url, extraction)
    with store.connect() as conn:
        kinds = {r[0] for r in conn.execute("SELECT evidence_kind FROM extraction_evidence WHERE source_url=?", (url,))}
    assert "vision_bundle" in kinds
    assert "vision_text" in kinds


def test_agentic_commerce_context_combines_graph_facts_search_and_visual_evidence(tmp_path: Path):
    store, url = _store(tmp_path)
    product_key = "product-order-code:abc123"
    store.upsert_node(product_key, "Product", "Dell Test 14", {"order_code": "abc123", "processor": "Intel Core Ultra", "source_url": url})
    store.upsert_edge(f"url:{url}", "MENTIONS", product_key, url)
    store.add_fact(product_key, "PROCESSOR", "Intel Core Ultra", url)
    store.record_extraction_evidence(url, {"summary": "Diagram shows Thunderbolt ports"}, evidence_kind="vision_bundle", reason="test")
    # Searchable source text anchors retrieval to the page.
    with store.connect() as conn:
        conn.execute("INSERT INTO chunks(source_url,chunk_index,heading,text,content_hash) VALUES(?,?,?,?,?)", (url, 0, "Ports", "Dell Test 14 includes Thunderbolt ports and Intel Core Ultra.", "c1"))
    context = AgenticCommerceKnowledge(store).context("Dell Test 14 Thunderbolt", limit=8)
    assert context["graph_neighborhood"]
    assert any(f.get("predicate") == "PROCESSOR" for f in context["facts"])
    assert any(e.get("evidence_kind") == "vision_bundle" for e in context["extraction_evidence"])
    assert url in {s.get("url") for s in context["sources"]}


def test_neo4j_projection_is_bounded_but_rich(tmp_path: Path):
    store, url = _store(tmp_path)
    pkey = "product-order-code:abc123"
    store.upsert_node(pkey, "Product", "Dell Test 14", {"order_code": "abc123", "memory": "32 GB", "source_url": url})
    store.upsert_edge(f"url:{url}", "MENTIONS", pkey, url)
    store.add_fact(pkey, "MEMORY", "32 GB", url)
    store.record_extraction_evidence(url, {"visible_text": ["32 GB memory"]}, evidence_kind="vision_bundle", reason="test")
    projection = Neo4jSemanticProjection(store).build()
    assert projection["nodes"]
    assert projection["evidence"]
    assert all(set(n["labels"]) <= ({"SemanticEntity"} | set(GRAPH_NODE_TYPES)) for n in projection["nodes"])
    product = next(n for n in projection["nodes"] if n["id"] == pkey)
    assert product["properties"]["fact__memory"] == "32 GB"
    assert "facts_json" in product["properties"]


def test_neo4j_export_files_are_jsonl_and_manifested(tmp_path: Path):
    store, url = _store(tmp_path)
    store.record_extraction_evidence(url, {"summary": "PDF image evidence"}, evidence_kind="vision_bundle", reason="test")
    out = Neo4jSemanticProjection(store).export(tmp_path / "neo4j")
    manifest = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["ontology_version"].startswith("v6.26")
    assert (out / "nodes.jsonl").is_file()
    assert (out / "relationships.jsonl").is_file()
    assert (out / "evidence.jsonl").is_file()


def test_structured_and_deterministic_commerce_projection_do_not_fragment_identity(tmp_path: Path):
    store, url = _store(tmp_path)
    payload = normalize_extraction_payload({
        "entities": [{
            "key": "p1", "type": "Product", "name": "Dell Test 14",
            "attributes": {
                "order_code": "abc123", "product_url": url,
                "warranty": "3 Year ProSupport",
                "financing": "$99/month for 12 months",
                "rewards": "Earn 5% Dell Rewards",
                "shipping": "Free standard delivery",
            },
        }],
        "warranties": [{"name": "3 Year ProSupport", "coverage": "3 Year ProSupport", "product_key": "p1"}],
        "financing_options": [{"name": "$99/month for 12 months", "financing": "$99/month for 12 months", "product_key": "p1"}],
        "reward_programs": [{"name": "Dell Rewards", "reward": "Earn 5% Dell Rewards", "product_key": "p1"}],
        "delivery_options": [{"name": "Dell delivery", "delivery": "Free standard delivery", "product_key": "p1"}],
    }, source_url=url)
    store.ingest_extraction(url, payload)
    with store.connect() as conn:
        counts = dict(conn.execute(
            "SELECT node_type, COUNT(*) FROM nodes WHERE node_type IN ('Warranty','FinancingOption','RewardProgram','DeliveryOption') GROUP BY node_type"
        ).fetchall())
    assert counts == {"DeliveryOption": 1, "FinancingOption": 1, "RewardProgram": 1, "Warranty": 1}

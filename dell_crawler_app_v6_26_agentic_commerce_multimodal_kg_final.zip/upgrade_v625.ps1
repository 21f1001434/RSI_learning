param(
    [string]$Db = ".\knowledge\dell_en_uk.db",
    [string]$Knowledge = ".\knowledge"
)
$ErrorActionPreference = "Stop"
python .\repair_v625.py --db $Db --knowledge $Knowledge
python .\audit_knowledge_v625.py --db $Db --knowledge $Knowledge --require-clean
python .\release_verify_v625.py --db $Db
python -m streamlit run .\app.py

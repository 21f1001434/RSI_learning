from __future__ import annotations

import argparse
from pathlib import Path
from dell_crawler_core.neo4j_projection import Neo4jSemanticProjection


def main() -> int:
    p = argparse.ArgumentParser(description="Export Dell crawler v6.26 canonical agentic-commerce projection for Neo4j ingestion.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--out", default="knowledge/neo4j_v626")
    a = p.parse_args()
    db = Path(a.db)
    if not db.is_file():
        raise SystemExit(f"Database not found: {db}")
    out = Neo4jSemanticProjection(db).export(a.out)
    print(f"Neo4j-ready projection written to: {out}")
    print(f"  {out / 'nodes.jsonl'}")
    print(f"  {out / 'relationships.jsonl'}")
    print(f"  {out / 'evidence.jsonl'}")
    print(f"  {out / 'manifest.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

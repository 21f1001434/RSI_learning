# v6.24 — Single-drive lean storage + consolidated segmentation

v6.24 is the first build designed explicitly for a workstation where the crawler project and the only usable free space are on **C:**.

## What changed

### 1. Preserve extracted knowledge, delete redundant local artefacts
After a page/document has been successfully extracted, its durable knowledge remains in SQLite (`sources`, `chunks`, semantic nodes, facts, relationships, product observations and unmapped evidence). Raw HTML dumps, successful screenshots, rendered PDF pages, downloaded visual assets, browser-viewer screenshots and already-consumed document files are treated as regenerable artefacts and can be deleted.

Incomplete sources retain their extracted chunks and are still eligible for live product/page revisits. The crawler does not need the old screenshot/raw file to revisit the live Dell URL.

### 2. Runtime storage budgets
Lean mode is on by default:

- runtime/MCP evidence: 256 MB
- Dell AIA text cache: 256 MB
- Dell AIA vision cache: 256 MB
- combined raw/document/screenshot/visual artefacts: 1 GB

The budgets are enforced at crawler checkpoints so the repository cannot silently grow to tens of GB again. Values are configurable from Streamlit.


### 2a. Existing 40+ GB repositories
The repair also applies the same hard budgets to **orphan/unreferenced** old raw HTML, documents, screenshots, PDF renders and visual assets. This matters because old versions could leave large files behind even after their source row was already compacted. The default combined artefact ceiling after repair is 1 GB; runtime evidence is 256 MB and each Dell AIA cache is 256 MB. These are regenerable copies—the searchable/extracted knowledge remains in SQLite.

The budget is a hard ceiling: the crawler prefers to retain the newest files, but if the retention window itself is larger than the configured ceiling it trims the oldest files within that window too rather than silently exceeding the budget.

### 3. Browser profile cleanup without losing SSO
Repair removes Chromium/Edge caches (`Cache`, `Code Cache`, `GPUCache`, `Service Worker/CacheStorage`, Crashpad, shader caches) but preserves Cookies, Local Storage, Session Storage, IndexedDB and Preferences used by Dell SSO.

### 4. Too much segmentation fixed
Older builds stored searchable text in ~3.5k-character chunks with overlap. Existing databases are reconstructed and re-segmented to heading-aware ~9k-character chunks with **zero DB overlap**. Exact duplicate rendered pages keep one chunk copy and retain their alias/source node and duplicate relationship.

Dell AIA long-form extraction defaults to 20k-character evidence chunks with only 300 characters of overlap. This reduces model calls and repeated text while retaining complete evidence coverage.

### 5. Single-drive physical compaction
v6.24 first tries a normal same-drive compact swap. If C: still cannot hold a second SQLite file, it automatically:

1. drops only rebuildable FTS indexes,
2. streams a verified gzip logical safety archive,
3. verifies gzip CRC and SQLite integrity,
4. deletes the bloated SQLite file only after the archive is safe,
5. restores canonical tables into a fresh compact DB on the same path,
6. rebuilds FTS from `chunks` and `nodes`,
7. runs integrity and foreign-key checks.

This means another D: drive is no longer required.

## Upgrade

```powershell
python .\repair_v624.py --db .\knowledge\dell_en_uk.db --knowledge .\knowledge
python .\audit_knowledge_v624.py --db .\knowledge\dell_en_uk.db --knowledge .\knowledge --require-clean
python .\release_verify_v624.py --db .\knowledge\dell_en_uk.db
python -m streamlit run .\app.py
```

Or:

```powershell
.\upgrade_v624.ps1
```

The repair writes `knowledge/DATABASE_REPAIR_V624.json` with before/after repository size, chunk reduction, artefact cleanup, compaction strategy and semantic quality.

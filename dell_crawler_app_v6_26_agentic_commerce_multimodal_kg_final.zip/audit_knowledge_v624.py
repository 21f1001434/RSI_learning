from __future__ import annotations

import argparse
import json
from pathlib import Path

from audit_knowledge_v623 import build_report as build_v623_report
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.storage_optimiser import storage_inventory


def build_report(db: Path, knowledge: Path | None = None) -> dict:
    report = build_v623_report(db)
    report["release"] = "v6.24"
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        sources = int(conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0])
        chunks = int(conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0])
        chars = int(conn.execute("SELECT COALESCE(SUM(LENGTH(text)),0) FROM chunks").fetchone()[0])
        oversegmented = int(conn.execute(
            """
            SELECT COUNT(*) FROM (
              SELECT source_url,COUNT(*) AS n,AVG(LENGTH(text)) AS avg_len
              FROM chunks GROUP BY source_url
              HAVING n>10 AND avg_len<4500
            )
            """
        ).fetchone()[0])
        duplicate_hash_chunk_groups = int(conn.execute(
            """
            SELECT COUNT(*) FROM (
              SELECT json_extract(s.metadata_json,'$.semantic_content_hash') AS h,
                     SUM(CASE WHEN EXISTS(SELECT 1 FROM chunks c WHERE c.source_url=s.url) THEN 1 ELSE 0 END) AS copies
              FROM sources s
              WHERE COALESCE(json_extract(s.metadata_json,'$.semantic_content_hash'),'')<>''
              GROUP BY h HAVING copies>1
            )
            """
        ).fetchone()[0])
        compacted_sources = int(conn.execute(
            "SELECT COUNT(*) FROM sources WHERE json_extract(metadata_json,'$.storage_compaction_version')='v6.24'"
        ).fetchone()[0])
        local_paths_after_compaction = int(conn.execute(
            """
            SELECT COUNT(*) FROM sources
            WHERE json_extract(metadata_json,'$.storage_compaction_version')='v6.24'
              AND (COALESCE(raw_path,'')<>'' OR COALESCE(screenshot_path,'')<>'')
            """
        ).fetchone()[0])
    report["segmentation_quality"] = {
        "sources": sources,
        "chunk_rows": chunks,
        "stored_chunk_chars": chars,
        "average_chunks_per_source": round(chunks / max(1, sources), 3),
        "oversegmented_sources": oversegmented,
        "exact_duplicate_content_groups_with_multiple_chunk_copies": duplicate_hash_chunk_groups,
        "db_chunk_target_chars": 9000,
        "db_chunk_overlap_chars": 0,
        "llm_chunk_chars_default": 20000,
        "llm_chunk_overlap_default": 300,
    }
    report["storage_compaction"] = {
        "compacted_sources": compacted_sources,
        "compacted_sources_still_pointing_to_raw_or_screenshot": local_paths_after_compaction,
    }
    if knowledge is not None:
        report["storage_inventory"] = storage_inventory(Path(__file__).resolve().parent, knowledge, db)
    return report


def main() -> int:
    p = argparse.ArgumentParser(description="Audit Dell crawler v6.24 single-drive storage + segmentation + semantic quality.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--knowledge", default="knowledge")
    p.add_argument("--output", default="")
    p.add_argument("--require-clean", action="store_true")
    a = p.parse_args()
    db = Path(a.db).expanduser().resolve()
    knowledge = Path(a.knowledge).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    report = build_report(db, knowledge)
    text = json.dumps(report, indent=2, ensure_ascii=False, default=str)
    print(text)
    if a.output:
        Path(a.output).expanduser().write_text(text, encoding="utf-8")
    if a.require_clean:
        q = report["semantic_quality"]
        seg = report["segmentation_quality"]
        storage = report["storage_compaction"]
        if (
            not bool(q.get("clean_for_semantic_sync"))
            or report["integrity_check"].casefold() != "ok"
            or report["foreign_key_violations"]
            or int(seg["oversegmented_sources"]) != 0
            or int(seg["exact_duplicate_content_groups_with_multiple_chunk_copies"]) != 0
            or int(storage["compacted_sources_still_pointing_to_raw_or_screenshot"]) != 0
        ):
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

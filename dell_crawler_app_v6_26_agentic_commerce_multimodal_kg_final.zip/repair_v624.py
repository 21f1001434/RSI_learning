from __future__ import annotations

"""v6.24 repair: single-C-drive storage recovery + chunk consolidation + semantic repair."""

import argparse
import json
from pathlib import Path
import shutil
import sqlite3
import time
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.lean_compaction import (
    logical_lean_cleanup,
    consolidate_chunk_segments,
    remove_exact_duplicate_source_chunks,
)
from dell_crawler_core.repository_cleanup import clean_repository_before_repair, clean_regenerable_knowledge_artifacts
from dell_crawler_core.storage_optimiser import (
    storage_inventory,
    prune_browser_profile_caches,
    prune_successfully_extracted_artifacts,
    enforce_runtime_budgets_v624,
)
from dell_crawler_core.single_drive_compaction import (
    drop_rebuildable_fts,
    create_compressed_logical_backup,
    compact_on_single_drive,
)
from repair_v610 import now, stamp, inspect_runtime_processes, clear_stale_profile_lease
from repair_v622 import repair as repair_v622


def _assert_stopped(root: Path, force_active: bool) -> dict[str, Any]:
    runtime = inspect_runtime_processes(root)
    profile = clear_stale_profile_lease(root)
    live = list(runtime.get("live_pids") or [])
    if profile.get("status") == "live_owner":
        pid = int(profile.get("owner_pid") or 0)
        if pid and pid not in live:
            live.append(pid)
    live = sorted(set(live))
    if live and not force_active:
        raise SystemExit(f"Refusing v6.24 repair while crawler/browser PID(s) {live} are alive. Use Graceful Stop first.")
    return {"runtime": runtime, "profile": profile, "live_pids": live}


def _make_pre_repair_logical_backup(db: Path, backup_dir: Path) -> dict[str, Any]:
    backup_dir.mkdir(parents=True, exist_ok=True)
    target = backup_dir / f"{db.stem}.pre_v624_{stamp()}.sql.gz"
    drop_rebuildable_fts(db)
    result = create_compressed_logical_backup(db, target)
    # Recreate FTS immediately; all canonical source data is untouched.
    SQLiteKnowledgeGraph(db)
    if not result.get("ok"):
        raise SystemExit(f"Could not create the compressed v6.24 safety backup: {result}")
    return result


def _prune_old_backups(backup_dir: Path, current: Path, keep: int = 1) -> dict[str, Any]:
    backups = sorted(backup_dir.glob("*.pre_v624_*.sql.gz"), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    deleted = []
    kept = 0
    for path in backups:
        if path.resolve() == current.resolve():
            kept += 1
            continue
        if kept < max(1, int(keep)):
            kept += 1
            continue
        try:
            size = path.stat().st_size
            path.unlink(missing_ok=True)
            deleted.append({"path": str(path), "bytes": size})
        except OSError:
            pass
    return {"deleted": deleted, "bytes_deleted": sum(x["bytes"] for x in deleted)}


def _prune_historical_repair_reports(knowledge: Path) -> dict[str, Any]:
    """Keep only the current v6.24 report; older migration diagnostics are reproducible noise."""
    deleted: list[dict[str, Any]] = []
    patterns = (
        "DATABASE_REPAIR_V6*.json",
        "SEMANTIC_KNOWLEDGE_REPAIR_V6*.json",
        "SEMANTIC_COLLISION_RECOVERY_V6*.json",
    )
    for pattern in patterns:
        for path in knowledge.glob(pattern):
            if path.name == "DATABASE_REPAIR_V624.json":
                continue
            try:
                size = path.stat().st_size
                path.unlink(missing_ok=True)
                deleted.append({"path": str(path), "bytes": size})
            except OSError:
                pass
    return {"deleted": deleted, "bytes_deleted": sum(int(x["bytes"]) for x in deleted)}


def repair(
    db: Path,
    knowledge: Path,
    *,
    force_active: bool = False,
    no_backup: bool = False,
    backup_dir: Path | None = None,
    keep_product_observations: int = 12,
    evidence_budget_mb: int = 256,
    cache_budget_mb: int = 256,
    artifact_budget_mb: int = 1024,
    chunk_target_chars: int = 9000,
) -> dict[str, Any]:
    root = Path(__file__).resolve().parent
    db, knowledge = db.resolve(), knowledge.resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge.mkdir(parents=True, exist_ok=True)
    backup_dir = (backup_dir or (knowledge / "backups")).resolve()

    process_state = _assert_stopped(root, force_active)
    inventory_before = storage_inventory(root, knowledge, db)

    # 1) Reclaim external filesystem space first. This is what v6.23 did not do
    # aggressively enough for repositories where screenshots/evidence/raw files
    # dominate the 40+ GB footprint.
    repo_cleanup = clean_repository_before_repair(root, db, keep_old_backups=0, clear_reports=True, clear_runtime=True)
    cache_cleanup = clean_regenerable_knowledge_artifacts(knowledge, preserve_text_cache=False, preserve_vision_cache=False)
    browser_cleanup = prune_browser_profile_caches(root)

    # 2) Create a compressed logical safety backup instead of another full SQLite
    # copy. This is designed specifically for a machine where C: is the only drive.
    backup = {"status": "disabled", "path": ""}
    if not no_backup:
        backup = _make_pre_repair_logical_backup(db, backup_dir)

    store = SQLiteKnowledgeGraph(db)

    # 3) Remove DB redundancy and over-segmentation *before* semantic repair.
    pre_lean = logical_lean_cleanup(store, keep_crawl_runs=1, keep_product_observations=keep_product_observations)
    if not pre_lean.get("ok"):
        raise SystemExit(f"v6.24 pre-repair lean cleanup failed: {pre_lean}")
    duplicate_chunks = remove_exact_duplicate_source_chunks(store)
    segmentation = consolidate_chunk_segments(store, target_chars=chunk_target_chars, overlap_chars=0)

    # 4) Apply the proven classification/dedup/node-key/product/market repair chain.
    base = repair_v622(
        db, knowledge,
        force_active=force_active,
        no_backup=True,
        keep_old_backups=0,
        keep_crawl_runs=1,
        keep_old_runtime_data=False,
        no_vacuum=True,
    )

    # 5) Consolidation can expose more duplicates/orphans. Compact those and then
    # prune local raw/screenshot/document artefacts once searchable chunks exist.
    # Incomplete/revisit sources keep their extracted DB knowledge and can refetch
    # the live Dell URL; old local artefact copies are not required for recovery.
    store = SQLiteKnowledgeGraph(db)
    post_duplicate_chunks = remove_exact_duplicate_source_chunks(store)
    post_segmentation = consolidate_chunk_segments(store, target_chars=chunk_target_chars, overlap_chars=0)
    post_lean = logical_lean_cleanup(store, keep_crawl_runs=1, keep_product_observations=keep_product_observations)
    artifact_cleanup = prune_successfully_extracted_artifacts(
        store, knowledge, root=root,
        retain_incomplete=False,
        evidence_budget_mb=evidence_budget_mb,
        cache_budget_mb=cache_budget_mb,
    )
    # Bound orphan/unreferenced regenerable artefacts too. These are a common
    # reason old repositories remain tens of GB even after source-linked files
    # have been pruned. Extracted/searchable knowledge remains in SQLite.
    runtime_budget_cleanup = enforce_runtime_budgets_v624(
        root, knowledge,
        evidence_budget_mb=evidence_budget_mb,
        cache_budget_mb=cache_budget_mb,
        artifact_budget_mb=artifact_budget_mb,
    )
    historical_report_cleanup = _prune_historical_repair_reports(knowledge)

    inventory_after_logical = storage_inventory(root, knowledge, db)

    # 6) Physical shrink. First try ordinary same-drive compact-swap if cleanup has
    # freed enough room; otherwise automatically fall back to compressed logical
    # rebuild, which deletes the bloated DB only after a verified gzip archive exists.
    physical = compact_on_single_drive(db, backup_dir, prefer_vacuum_into=True)
    if not physical.get("ok"):
        raise SystemExit(f"v6.24 single-drive physical compaction failed: {physical}")

    # The compaction helper creates a temporary post-repair logical archive. The
    # pre-repair safety backup is enough after the restored DB validates, so remove
    # the temporary archive if it is different to keep disk use bounded.
    temp_archive = Path(str((physical.get("logical_backup") or {}).get("path") or ""))
    pre_archive = Path(str(backup.get("path") or "")) if backup.get("path") else None
    if temp_archive.exists() and (pre_archive is None or temp_archive.resolve() != pre_archive.resolve()):
        try:
            physical["temporary_compaction_archive_bytes"] = temp_archive.stat().st_size
            temp_archive.unlink()
            physical["temporary_compaction_archive_deleted"] = True
        except OSError:
            physical["temporary_compaction_archive_deleted"] = False

    # Keep only one compressed pre-v6.24 backup.
    backup_prune = {"deleted": [], "bytes_deleted": 0}
    if pre_archive and pre_archive.exists():
        backup_prune = _prune_old_backups(backup_dir, pre_archive, keep=1)

    # 7) Final validation and storage report.
    store = SQLiteKnowledgeGraph(db)
    quality = store.semantic_quality_report()
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
        temp_rekeys = int(conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0])
        chunk_rows = int(conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0])
        chunk_chars = int(conn.execute("SELECT COALESCE(SUM(LENGTH(text)),0) FROM chunks").fetchone()[0])
        sources = int(conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0])
        duplicate_chunk_sources = int(conn.execute(
            "SELECT COUNT(*) FROM sources WHERE COALESCE(json_extract(metadata_json,'$.chunks_shared_with'),'')<>''"
        ).fetchone()[0])

    if integrity.casefold() != "ok" or fk or temp_rekeys or not bool(quality.get("clean_for_semantic_sync")):
        raise SystemExit(
            "v6.24 final validation failed: "
            f"integrity={integrity}, foreign_keys={fk[:10]}, temporary_rekeys={temp_rekeys}, "
            f"clean_for_semantic_sync={quality.get('clean_for_semantic_sync')}"
        )

    inventory_after = storage_inventory(root, knowledge, db)
    report = {
        "migration": "v6.x -> v6.24 single-drive lean + consolidated segmentation + canonical semantic crawler",
        "database": str(db),
        "process_state": process_state,
        "storage_before": inventory_before,
        "repository_cleanup": repo_cleanup,
        "cache_cleanup": cache_cleanup,
        "browser_profile_cache_cleanup": browser_cleanup,
        "backup": backup,
        "pre_repair_lean_cleanup": pre_lean,
        "duplicate_source_chunk_cleanup": duplicate_chunks,
        "chunk_segmentation_cleanup": segmentation,
        "v622_semantic_repairs": base,
        "post_duplicate_source_chunk_cleanup": post_duplicate_chunks,
        "post_chunk_segmentation_cleanup": post_segmentation,
        "post_repair_lean_cleanup": post_lean,
        "successful_source_artifact_cleanup": artifact_cleanup,
        "runtime_artifact_budget_cleanup": runtime_budget_cleanup,
        "historical_repair_report_cleanup": historical_report_cleanup,
        "storage_after_logical_cleanup": inventory_after_logical,
        "physical_compaction": physical,
        "backup_prune": backup_prune,
        "integrity_after": integrity,
        "foreign_key_violations": fk,
        "temporary_semantic_rekeys": temp_rekeys,
        "semantic_quality": quality,
        "segmentation_quality": {
            "sources": sources,
            "chunk_rows": chunk_rows,
            "stored_chunk_chars": chunk_chars,
            "average_chunks_per_source": round(chunk_rows / max(1, sources), 3),
            "exact_duplicate_sources_sharing_chunks": duplicate_chunk_sources,
            "target_chunk_chars": chunk_target_chars,
            "db_chunk_overlap_chars": 0,
            "llm_default_chunk_chars": 20000,
            "llm_default_overlap_chars": 300,
        },
        "storage_after": inventory_after,
        "finished_at": now(),
    }
    report_path = knowledge / "DATABASE_REPAIR_V624.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report["report_path"] = str(report_path)
    return report


def main() -> int:
    p = argparse.ArgumentParser(description="Dell Crawler v6.24: single-C-drive cleanup, data-preserving de-segmentation and semantic repair.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--knowledge", default="knowledge")
    p.add_argument("--force-active", action="store_true")
    p.add_argument("--no-backup", action="store_true")
    p.add_argument("--backup-dir", default="", help="Optional folder on C:. v6.24 uses compressed logical backups, not a second full DB.")
    p.add_argument("--keep-product-observations", type=int, default=12)
    p.add_argument("--evidence-budget-mb", type=int, default=256)
    p.add_argument("--cache-budget-mb", type=int, default=256)
    p.add_argument("--artifact-budget-mb", type=int, default=1024, help="Combined budget for raw/document/screenshot/visual artefacts after extracted knowledge is persisted.")
    p.add_argument("--chunk-target-chars", type=int, default=9000)
    a = p.parse_args()
    result = repair(
        Path(a.db).expanduser().resolve(),
        Path(a.knowledge).expanduser().resolve(),
        force_active=a.force_active,
        no_backup=a.no_backup,
        backup_dir=Path(a.backup_dir).expanduser().resolve() if a.backup_dir else None,
        keep_product_observations=a.keep_product_observations,
        evidence_budget_mb=a.evidence_budget_mb,
        cache_budget_mb=a.cache_budget_mb,
        artifact_budget_mb=a.artifact_budget_mb,
        chunk_target_chars=a.chunk_target_chars,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

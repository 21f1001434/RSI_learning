# V23 — Governed systemName/systemType + API Execution Report

## Why V23 exists

A LIVE TP Create exposed a dangerous mismatch: Excel carried `systemName = AIC - DCE`, but the payload/execution path could pair the identity with the wrong ownership/type or previously derived partner evidence. That can cause Dell to resolve the system against the wrong domain and return errors such as “not able to find system”. V23 makes System Name and System Type one governed identity pair and records the exact request/response evidence for every LIVE run.

## Exact system identity rule

The role-correct Excel System/System Name remains authoritative for `systemName`:

- Source/Sender TP -> Source System / Source System Name
- Target/Receiver TP -> Target System / Target System Name
- If both exist, explicit TP Role/Usage selects the side
- Partner name, account name, customer reference, ownership text and LLM output are never System Name sources

`systemType` is then derived only from that approved `systemName`:

```text
AIC - DCE / AIC-DCE / AIC DCE -> Dell Application
any other explicit systemName  -> Partner
```

Normalization is limited to punctuation/spacing/case for the exact `AICDCE` identity. There is no fuzzy “contains Dell/DCE/HIP” rule and no environment allowlist that can widen the classification.

## Defence in depth

The pair is checked at four boundaries:

1. **Analyze** — mapper selects the role-correct `systemName`, derives `systemType`, and records any conflicting Excel System Type as evidence.
2. **Stage** — the canonical payload must satisfy the rule; a signed/fingerprinted rule snapshot is stored with the stage.
3. **Preflight** — out-of-band changes to `systemName`, `systemType`, or the rule metadata block execution.
4. **LIVE** — the executor reconstructs the canonical request and checks the pair again immediately before `requests.request(...)`.

A legitimate human correction to `systemName` remains supported through **Apply value edits & revalidate**. Because `systemType` is contract-owned, the user changes only the name; the backend automatically rebuilds `systemType` from the corrected name. A contradictory manual ownership override returns `SYSTEM_TYPE_SYSTEM_NAME_LOCK`.

## API execution evidence

Every saved LIVE run now exposes:

- `GET /api/runs/{run_id}/execution-report.html`
- `GET /api/runs/{run_id}/execution-report.json`
- `GET /api/execution-report.html?run_ids=<run1,run2,...>` for batch evidence

The HTML report includes:

- run ID, Excel sheet/row, account, API
- endpoint + HTTP method/status
- exact stored/redacted request evidence, including `systemName` and `systemType`
- raw/parsed stored/redacted response received
- deterministic response classification
- Dell checking/audit verification evidence
- Dell AIA response interpretation (when enabled; advisory only)
- HTTP attempts and evidence hashes
- final `SUCCESS`, `EXISTING`, `FAILED`, or `PENDING` outcome

Configured password/token/certificate/secret fields remain redacted. Reports are read-only and never execute an API.

## Response semantics retained from V20/V21

- **SUCCESS**: new TP accepted and terminally verified when post-create checking is enabled.
- **EXISTING**: exact TP duplicate evidence and verification.
- **FAILED**: transport error, semantic failure (even inside HTTP 2xx), or terminal audit failure.
- **PENDING**: accepted but not terminally verified yet.

The optional Dell AIA `gpt-oss-120b` response interpreter may explain evidence but cannot change the deterministic verdict, payload, URL/method, or execute another request.

## Regression coverage

V23 adds tests for:

- AIC-DCE variants -> Dell Application
- every other systemName -> Partner, including misleading names containing “Dell”
- environment settings cannot widen the rule
- conflicting Excel System Type is corrected
- Source/Target role correctness when both systems are present
- human System Name edit automatically rebuilds System Type
- Preflight rejects stage-file System Type tampering
- mocked final HTTP boundary receives the correct `systemName` + `systemType`
- HTML/JSON/batch execution reports contain request and response evidence

All historical tests were retained, with three older V17/V18/V19 assertions updated because those assertions represented the superseded ownership-inference semantics.

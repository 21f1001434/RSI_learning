# Intelligent TP Excel Readiness, Governed System Identity, LIVE API Evidence, Verified Create, Migration & LLM-as-Judge Agent — V23

Standalone Transport Profile (TP) Excel mapping, readiness, HTML reporting, health diagnostics, governed staging/preflight, controlled parallel HIP TP API execution, and downloadable request/response evidence.

V23 hardens **systemName + systemType as one governed identity pair**. The role-correct System Name still comes only from Excel or an explicit human value edit. `systemType` is then derived deterministically from that approved System Name: **`AIC - DCE` (including punctuation/spacing variants such as `AIC-DCE`) = `Dell Application`; every other explicit systemName = `Partner`**. A conflicting Excel System Type, customer/reference pattern, partner name, account name, LLM suggestion, or runtime environment value cannot override that rule. The same rule is rechecked at Analyze, Stage, Preflight, and immediately before the real HTTP boundary.

V23 also adds a governed **API Execution Report** for every LIVE run and for batches. The report contains the stored/redacted request payload sent, method/URL/status, response body received, deterministic SUCCESS/EXISTING/FAILED/PENDING classification, Dell checking/audit verification, optional response-agent interpretation, attempts, and evidence hashes. It is downloadable from the LIVE result, batch result, or History.

> **V23 supersedes the older V17/V18 ownership inference rules.** U-HAUL/customer references and explicit System Type cells are evidence only; they never decide ownership against the approved systemName.

## V23 governed systemName/systemType identity + API execution evidence

For Source/Sender rows, the role-correct Source System/System Name becomes `systemName`. For Target/Receiver rows, the role-correct Target System/System Name becomes `systemName`. If both sides exist, an explicit TP Role/Usage selects the side; the opposite-side system is never borrowed.

The only automatic `systemType` rule is:

```text
normalize(systemName) == AICDCE  -> Dell Application
any other non-blank systemName   -> Partner
```

This rule is exact, not fuzzy. Names containing words such as `Dell`, `HIP`, `DCE`, `partner`, or `application` do not become Dell unless the normalized identity is exactly `AICDCE`. The rule is code-owned and intentionally cannot be widened from `.env`.

A human may correct `systemName` through **Apply value edits & revalidate**; the backend automatically rebuilds the locked `systemType` from the corrected name. Directly editing `systemType` to contradict the name is rejected with `SYSTEM_TYPE_SYSTEM_NAME_LOCK`. Out-of-band Stage tampering is blocked by Preflight/LIVE checks before any mutation reaches Dell.

LIVE evidence endpoints:

- `GET /api/runs/{run_id}/execution-report.html` — printable/downloadable HTML evidence
- `GET /api/runs/{run_id}/execution-report.json` — machine-readable saved run evidence
- `GET /api/execution-report.html?run_ids=<id1,id2,...>` — combined batch report

Configured secret/password/token/certificate fields stay redacted in stored/report evidence. The report itself is read-only and never triggers an API.

## V22 systemName anti-hallucination / provenance lock

`systemName` is now treated as a protected identity value with explicit provenance. For a Source/Sender TP it may come only from the role-correct Source System / Source System Name (or a safe generic System Name when no opposite-side system is present). For a Target/Receiver TP it follows the equivalent Target rule. Partner Name, HIP Account, Existing Account Name, ownership labels, U-HAUL reference values, and Dell AIA suggestions are **not valid systemName sources**.

The exact Excel value is carried into the analyzed action as `systemSourceValue` and into Stage as `systemNameProvenance.approvedValue`. Stage rejects any unreviewed mismatch. Preflight validates the same provenance again, and LIVE repeats the check before reconstructing the final HTTP payload. A legitimate human correction remains possible, but `systemName` must first be saved through **Apply value edits & revalidate**, which records `HUMAN_CONFIRMED_VALUE_EDIT` provenance before Stage.

The previous U-HAUL target reference no longer defaults a partner System Name. `HIP_UHAL_TARGET_SYSTEM_NAME` is optional and affects only the non-mutating smoke preview; normal TP execution always uses workbook/human provenance. An optional Excel `TP Role` / `Transport Profile Role` / `TP Usage` field is also recognized before heuristic role detection, preventing a row with both Source and Target systems from pairing the correct System Name with the wrong TP side.


## V21 separate interface-sheet team workbook

The packaged team workbook now provides one executable sheet per supported interface: `SFTP_HAFT`, `FTP`, `SFTP_SERVER`, `HTTPS`, `HTTPS_AS2`, `NAS`, and `RABBIT_MQ`. Row 6 is the real table header and executable team input starts at row 7. Filter arrows and governed Excel dropdowns are present in each interface sheet. The explanatory/dummy rows above the header are not ingested. The app exposes the exact packaged workbook at `GET /api/tp/team-template.xlsx`.

`scan_all_sheets=true` can ingest populated rows across all seven interface sheets in one upload. The explicit `Interface Type` cell remains authoritative; sheet names never silently override a missing or contradictory interface value.

### V21 batch outcome summary

Parallel LIVE now reports `SUCCESS`, `EXISTING`, `FAILED`, and `PENDING` separately. `SUCCESS` means a newly created TP was verified by the Dell checking/audit API. `EXISTING` means Dell reported the exact TP already exists and checking verified it. `FAILED` covers request/semantic/audit failures. `PENDING` remains non-success until terminal verification arrives.

## V21 LIVE response intelligence

The LIVE path sends the exact staged canonical Transport Profile request to the configured Dell HIP endpoint only after Stage + Preflight + explicit human confirmation (`LIVE` or `LIVE ALL`) and runtime gates pass. The immediate HTTP response is not trusted blindly. V21 classifies both transport status and response semantics, then uses the Dell TP checking/audit API for the final outcome.

Final operator-facing outcomes are:

- **SUCCESS** — a new TP Create is terminally verified successful by the checking/audit API.
- **EXISTING** — Dell explicitly reports the exact TP already exists and the checking API verifies that TP. Duplicate Create is skipped when the pre-create validator already proves this state.
- **FAILED** — HTTP rejection, explicit failure/error/rejection evidence even inside a 2xx body, or terminal audit failure.
- **PENDING** — Dell accepted the request but terminal success/existing evidence is not yet verified. PENDING is intentionally retained so the system never lies by forcing an unverified request into SUCCESS or FAILED.

The optional Dell AIA response interpreter reads only redacted response/checking evidence. It can explain the outcome and provide an advisory classification, but **cannot override deterministic classification, mutate the payload, or execute an API**. A 2xx response such as `{"status":"FAILED"}` is therefore FAILED even if the LLM guesses SUCCESS.

The team workbook is bundled at `templates/HIP_TP_TEAM_INPUT_TEMPLATE_V21_INTERFACE_SHEETS_FILTERS_DROPDOWNS.xlsx` and includes dummy examples for all seven interfaces.


## V19 multi-Document-Type TP rows + System Name detection

V19 supports the Dell backend pattern where the **same Transport Profile appears on multiple Excel rows with different Document Types**. When TP identity and every non-document payload value agree, the rows are consolidated into one TP action and one Create payload. Each distinct Excel Document Type becomes another approved dictionary in `transportProfileDetails[0].documentTypeDetails`.

Example:

```json
"documentTypeDetails": [
  {
    "documentTypeName": "perf_poa_855_edf",
    "documentTypeVersion": "1.0",
    "dataFormatType": "EDIX12"
  },
  {
    "documentTypeName": "2BDoctype10.0",
    "documentTypeVersion": "1.0",
    "dataFormatType": "XML"
  },
  {
    "documentTypeName": "AGING_FLATFILE",
    "documentTypeVersion": "3.0",
    "dataFormatType": "FLAT"
  }
]
```

The merge is deliberately narrow. A difference outside `documentTypeDetails` (for example a different interface, account, Subscription Folder, or other TP value) remains a conflicting duplicate and is sent to human review instead of being silently merged. Exact duplicate Document Type dictionaries are de-duplicated. `Data Format Type` / `Data Format` Excel columns are mapped to `dataFormatType` when explicitly supplied.

The immutable-contract rule is preserved by materializing an exact per-action contract snapshot with the same number of `documentTypeDetails` items as the analyzed Excel evidence. Stage, Preflight and LIVE therefore accept the backend-approved repeated array without allowing arbitrary key/nesting/cardinality mutation afterward. Ownership rebuilds before Stage also preserve the complete multi-document array.

V19 also fixes false `systemName` missing results for grouped Excel headers. Exact and context-qualified TP fields such as `System Name`, `Source System Name`, `Target System Name`, and `Transport Profile Details > System Name` are now recognized while still preventing Source/Target cross-mapping and excluding unrelated columns such as `System Type` or ownership fields.


## V18 applied value edits + ownership immutability hardening

V18 closes the remaining value-editor gap. A TP that is `NEEDS_INPUT` because a required value is blank can now be corrected directly in the field editor or advanced JSON editor and then saved with **Apply value edits & revalidate**. The backend persists only value changes, rejects schema/key/nesting/cardinality mutations and locked selector changes, records human-edit provenance, reruns required-field checks, completeness scoring, deterministic rules, and LLM-as-Judge, then updates every mirrored analysis bucket so both single and batch Stage use the corrected payload.

Direction and ownership remain independent: **Source = Sender**, **Target = Receiver**, while either Sender or Receiver can be **Dell Application** or **Client/Partner**. The approved U-HAUL reference remains **Sender=Dell Application, Receiver=Client/Partner**. Human ownership confirmation rebuilds the conditional interface contract before Stage; after a Stage snapshot exists, ownership cannot be changed for that analyzed action, preserving staged-contract immutability.

## V17 editable values + flexible Sender/Receiver ownership

V17 separates message direction from party ownership. Source TP means Sender and Target TP means Receiver, but either side may be Dell Application or Client/Partner. U-HAUL remains an approved reference pattern (Sender=Dell, Receiver=Client), not a universal rule.

Ownership is resolved from explicit role-specific Excel ownership, explicit generic ownership, safe role-correct System evidence, the approved U-HAUL reference, or a human confirmation in the review UI when still ambiguous. Human confirmation rebuilds the approved interface contract before Stage and reruns readiness plus LLM-as-Judge.

The review UI now exposes a field-by-field canonical leaf value editor plus the exact JSON payload value editor. Only existing values may change; keys, nesting, array cardinality, method, URL, headers, role/interface selectors and the selected interface attribute set remain immutable.

## V15 independent LLM-as-Judge

V15 adds a separate Judge role around the deterministic TP pipeline. The Judge uses a dedicated system prompt and redacted evidence; it is **not permitted to mutate payloads or execute APIs**. Deterministic validation is always authoritative: a deterministic `BLOCK` can never be promoted to `PASS` by the Judge, while the Judge may make a decision more conservative (`PASS → REVIEW/BLOCK`).

The Judge evaluates four checkpoints:

1. **Mapping readiness** — Excel provenance, interface contract, blank/null/missing values, mapping confidence and deterministic blockers.
2. **Pre-LIVE Create** — immutable schema evidence, exact staged values, Dell pre-create validator result and execution gates.
3. **Post-Create verification** — Create result plus exact-TP audit/checking evidence before the run is considered verified.
4. **Pre/Post Migration** — immutable V130 migration request, source/target environments and target audit verification.

Default mode is advisory. To make the Judge a mandatory LIVE gate:

```text
LLM_JUDGE_ENABLED=true
LLM_JUDGE_MODEL=gpt-oss-120b
LLM_JUDGE_TEMPERATURE=0
LLM_JUDGE_REQUIRED_FOR_LIVE=true
LLM_JUDGE_FAIL_CLOSED=true
```

If the Judge is mandatory and unavailable, LIVE Create/Migration is blocked before the network call. Secrets are redacted before Judge prompts are built. The UI/report/history show deterministic readiness and Judge verdict separately so an operator can understand both.

## V12 Dell 400 / missing-value hardening

V12 changes the execution decision so a row is never sent to TP Create merely because local mapping looked complete. Before a mutating Create call, the exact staged values are sent to the non-mutating Dell endpoint `/api/transport-profiles/validate-unique-interface-detail`. A rejection blocks Create and the UI shows the Dell response.

For FILE interfaces (`SFTP HAFT` and `FTP`), `Subscription Folder` and `Existing Account Name` are mandatory readiness values in addition to the common TP requirements. Blank/null values are shown explicitly in the customer field matrix and preflight summary. Optional blanks reduce completeness score but do not create attributes or mutate the approved interface contract.

HTTP 400 from TP Create is recorded as **Dell reached / request rejected**, with a redacted response summary in the batch table and execution history.

## V14 verified Create + Transport Profile Migration

V14 closes the execution loop in two places. First, an HTTP 2xx from TP Create is only **Create accepted**; the app polls the V130 checking/audit API `GET /api/transport-profiles/audits` for the exact TP and environment and marks success only when a new terminal-success audit record is observed. Second, a staged, preflight-passed TP can be migrated with the exact Dev-published V130 endpoint:

```text
POST /api/migration/orchestration/transport-profile
```

Exact immutable migration attributes:

```text
sourceEnvironment
targetEnvironment
transportProfileName
transportProfileInterfaceType
transportProfileInterfaceParameters
```

`transportProfileInterfaceParameters` is copied from the already-selected immutable TP interface contract. The Migration flow cannot invent, rename, remove, or re-nest parameter attributes. Source environment defaults to the active HIP environment; target environment must be explicitly configured or entered by the human operator.

Governed flow:

`Excel → map/score → Dell pre-create validator → Stage → TP Preflight → LIVE Create → post-create audit verification → VERIFIED CREATED → Migration Preflight → type MIGRATE / MIGRATE ALL → V130 TP Migration → target-environment audit verification → VERIFIED MIGRATED`

The UI supports single and parallel batch Migration. A batch can contain different TP interface families; each request reuses its own locked interface parameter shape.

### U-HAUL reference guidance

U-HAUL remains a governed SFTP HAFT reference. Dell AIA/reference logic may suggest `SFTP HAFT` for ambiguous SFTP-family evidence and explain that U-HAUL is the approved reference, but the suggestion is advisory. It does not mutate the selected interface contract, inject attributes, or bypass human Stage/Preflight.

## Supported TP interface contracts

The application can analyze, map, stage, preflight and execute Source/Sender and Target/Receiver TP Create requests for:

| Excel/API Interface | Contract family | LIVE Create |
|---|---|---|
| SFTP / SFTP HAFT | FILE / SFTP HAFT | Yes |
| **SFTP Server** | **V130 SFTP Server conditional contract** | **Yes** |
| FTP | FILE / FTP | Yes |
| HTTPS / REST | HTTPS | Yes |
| AS2 / HTTPS-AS2 | HTTPS-AS2 | Yes |
| NAS | NAS | Yes |
| Rabbit MQ | Rabbit MQ | Yes |

The interface is selected only from the authoritative Excel Interface Type cell. The LLM cannot infer an interface from TP name, hostname, Directory, port, delivery type, or other workbook clues.

## End-to-end flow

`Excel with multiple customers / TPs → detect TP rows → read explicit Interface Type → select + lock exact approved interface contract → map Excel evidence into values only → apply conditional interface rules → blank/null-aware completeness score → GOOD TO GO / NEEDS INPUT / NOT READY → rich UI + reports → Stage → Preflight → Dell TP validator → LIVE / LIVE ALL → real Dell HIP TP Create → checking/audit API verification → VERIFIED CREATED → optional Migration Preflight → MIGRATE / MIGRATE ALL → V130 TP Migration → target audit verification → VERIFIED MIGRATED`

### V11 immutable LIVE boundary

V11/V21 does not allow the agent or human payload editor to mutate TP attributes after an interface contract is selected. It locks JSON keys, nesting, method, resolved route, protected header names, TP role/interface selectors, contract version, and list cardinality **after analysis**. The one governed exception is `documentTypeDetails`: V19 derives its cardinality from repeated same-TP Excel rows during analysis, materializes that exact array length into the per-action canonical contract, and then locks it like every other array. Only permitted leaf values may change afterward. Before sending LIVE, the server reconstructs the outgoing request from the canonical selected-interface schema plus the staged scalar values.

Attributes **can differ across interfaces** because every interface has its own pre-approved contract. If an SFTP Server condition (for example Linux → Windows or Password → Key) requires a different conditional attribute set, the record must be re-analyzed so that the new contract shape is created and locked; the editor cannot mutate the existing staged shape.

Non-mutating diagnostics are available at `/api/runtime/live-readiness` and `/api/stages/{stage_id}/live-plan`.

## V130 SFTP Server rules

The Dev-team SFTP Server contract is implemented from the V130 R1 source and the supplied screenshots.

Base interface:

```json
{
  "interfaceType": "SFTP Server",
  "interfaceRole": "Primary",
  "parameters": {
    "Server Type": "Linux",
    "Server Name": "...",
    "Server Path": "...",
    "File Filtering Pattern": "...",
    "Post File Transfer Action": "Delete",
    "Polling Interval": "Cron Expression",
    "Are Input Files Compressed?": "True",
    "SPA URL": "",
    "Api Name": "",
    "Server Port": "22",
    "Login Authentication Type": "Password",
    "Username": "...",
    "Password": "...",
    "Cron Expression": "...",
    "Compression Format": "ZIP"
  }
}
```

Conditional behavior is schema locked:

- Dell Application: Server Type may be `Linux` or `Windows`.
- Partner: Server Type is `Linux` only.
- Linux: send `Server Port` + `Login Authentication Type`.
- Windows: send only Windows login-authentication fields; Linux auth fields are pruned.
- Login Authentication Type: `Password` or `Key`.
- Password auth: send `Username` + `Password`.
- Key auth: send `SSH Username` and fixed `SSH Key = haft_aut_sftp_server_private_key`.
- Windows Login Authentication Type: `Password`; send Windows username/password.
- Sender only: File Filtering Pattern, Post File Transfer Action, Polling Interval.
- Rename action: requires `Rename` (`Timestamp (yyyyddMMhhmmss)` or `Random Text`).
- Linux + Move To Archive: requires `Archive File Path`.
- Cron polling: requires `Cron Expression`.
- Compressed input: requires `Compression Format` (`GZIP`, `ZIP`, `TAR`).
- Partner only: `Is EBCDIC enabled?`; when true requires approved `Code Page`.
- Inactive conditional fields are omitted from the final HTTP payload, not sent as misleading blanks.

For SFTP Server only, approved Excel aliases include:

- `SFTP Server` → `Server Name`
- `Directory` → `Server Path`
- `Port` → `Server Port`
- authentication/user/password fields → the corresponding SFTP Server parameter

This is intentionally different from SFTP HAFT. For **SFTP HAFT**, `Directory` still never becomes `Subscription Folder`.

## Team mapping corrections retained

Core TP fields are provenance locked:

- `systemName`
- `transportProfileName`
- `interfaceType`
- `documentTypeName`
- `documentTypeVersion`
- `dataFormatType` when supplied by Excel
- FILE `Subscription Folder`
- FILE `Existing Account Name`

Important rules:

- Exact generic `Interface Type` wins over legacy Source/Target Interface Type columns when present.
- `SFTP Server` remains `SFTP Server`; it is not normalized to SFTP HAFT.
- `SFTP` / `SFTP HAFT` canonicalize to API `SFTP HAFT`.
- `Directory` is evidence-only for FILE/SFTP HAFT but maps to `Server Path` for the distinct SFTP Server contract.
- HIP Account never becomes FILE `Existing Account Name`.
- Grouped duplicate Excel headers retain parent context so `Transport Profile Details > Account` can be distinguished from unrelated Account columns.
- `transportProfileName` may come from Transport Profile Name / Source TP / Target TP / DEV-Transport Profile Name aliases; `LENS TP Name` is reference evidence only.
- If Document Type is absent, name/version remain blank. No fabricated `1` or `1.0`.
- If Excel contains `NAME(1.0)`, name/version are split into separate API fields; an explicit version column takes precedence.
- Repeated rows with the same TP identity and different Document Types become one TP payload with multiple `documentTypeDetails` dictionaries; differences outside that collection are not auto-merged.
- Grouped/contextual `System Name` headers are accepted when their final leaf is exactly `System` or `System Name`; fuzzy system-related columns are not used.

## Blank/null-aware score

Execution readiness and completeness are separate.

A TP can be `GOOD TO GO` when all mandatory execution conditions pass while scoring below 100 because optional values are absent.

Missing values include:

- `null` / `None`
- empty string / whitespace
- `N/A`, `NA`, `NaN`, `<NA>`, `none`
- empty list/object

Numeric `0` and boolean `false` remain valid populated values.

Scoring weights:

- required populated field: weight 3
- required blank/null field: 0 credit and may block
- optional populated field: weight 1
- optional blank/null field: 0 credit

The UI/report shows populated fields, blank/null count, blank required count, blank optional count, and score basis.

## Per-customer mapping and reports

Every TP action exposes:

- workbook sheet + row
- customer/application/HIP account
- Source or Target role
- exact Excel interface value and source column
- canonical API interface
- complete TP API field matrix
- Excel source column/value for each mapping
- runtime/default/canonicalized values
- missing fields
- readiness checklist
- warnings/blockers
- evidence-only columns
- redacted final payload

Master HTML report:

`GET /api/tp/analyses/{analysisId}/report.html`

Individual TP report:

`GET /api/tp/analyses/{analysisId}/actions/{actionId}/report.html`

## UI and loading states

The application includes:

- TP Readiness Queue
- interface/role/status/search filters
- customer-by-customer payload mapping drawer
- master and individual HTML report download
- Agent/API health dashboard
- supported-interface catalog
- loading spinner/overlay for analyze, health tests, stage, preflight and LIVE execution
- selected Good-to-Go bulk actions

## Agent/API health

The Runtime & Governance page checks:

- FastAPI backend
- Dell AIA model availability
- HIP OAuth
- Source TP service
- Target TP service

The U-HAUL smoke test uses the non-mutating TP validation endpoint rather than sending unsupported OPTIONS to the Create route.

## Governed LIVE execution

For a real DEV/SIT call, copy `.env.live.example` to `.env`, replace the credential/requester placeholders, keep the Dell host allowlist correct, and verify:

```text
HIP_LIVE_API_EXECUTION=true
HIP_TP_VALIDATE_BEFORE_CREATE=true
HIP_TP_POST_CREATE_CHECK_ENABLED=true
HIP_TP_RESPONSE_AGENT_ENABLED=true
```

The UI still requires the operator to type `LIVE` for one TP or `LIVE ALL` for bulk execution. Merely starting the app never sends a Create request. PROD additionally requires `PRODUCTION_EXECUTION_CONFIRMATION=YES` and a `CHANGE_TICKET`.


Single action:

`GOOD TO GO → Stage → optional approval → Preflight → type LIVE → TP Create`

Bulk:

`Select Good TPs → Stage Selected → optional bulk approval → Preflight Selected → type LIVE ALL → parallel TP Create`

Independent requests execute concurrently with the effective worker cap:

`min(HIP_BULK_MAX_WORKERS, HIP_PARALLEL_CONFIG_WORKERS, HIP_AUTOGEN_MAX_STABLE_AGENTS)`

The supplied V130/V122 defaults cap at 4 workers.

Each item retains independent PASS/FAIL/skipped evidence. One failed TP does not erase successful independent results.

## Environment compatibility

V15 retains every environment key from the uploaded V130/V122 codebase and adds only standalone governance/bulk controls. OAuth ownership remains compatible with that codebase:

- Account API → `ACCOUNT_*`
- Partner API → `PARTNER_*`
- System API → `SYSTEM_*`
- Document Type/Map/Rule/TP/Flow/Migration → `HIP_*`
- Dell AIA → `DELL_AIA_*`

For this TP-focused app, Transport Profile execution uses the `HIP_*` OAuth/runtime settings.

Copy `.env.example` to `.env` and place the same working local values used by the V130/V122 application. Do not commit credentials.

## Manual Windows / PowerShell run

```powershell
cd "C:\path\INTELLIGENT_TP_EXCEL_READINESS_PARALLEL_AGENT_V23_SYSTEM_TYPE_RULE_API_EXECUTION_REPORT_FULL_E2E_FINAL"
py -3.11 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
python -m uvicorn app.main:app --host 127.0.0.1 --port 8088
```

Open `http://127.0.0.1:8088`.

For analysis-only testing, keep:

```text
HIP_LIVE_API_EXECUTION=false
HIP_BULK_LIVE_EXECUTION=false
```

For approved LIVE testing, the relevant contract must remain approved/live-enabled and local environment gates/host allowlist must also be enabled.

## Validation

V23 automated coverage includes all previous coverage plus:

- exact identity rule: `AIC - DCE` / `AIC-DCE` / `AIC DCE` => `Dell Application`; every other explicit systemName => `Partner`
- the identity rule cannot be widened by a runtime environment variable
- when both Source and Target systems exist, the explicit TP role selects the correct systemName and its corresponding systemType
- conflicting Excel System Type values are corrected from the governed systemName rather than sent LIVE
- human systemName edits automatically rebuild the locked systemType; contradictory direct ownership overrides are blocked
- Stage/Preflight/LIVE detect out-of-band systemType tampering before network execution
- the real executor boundary test proves `requests.request(...)` receives both the governed systemName and systemType
- per-run HTML/JSON and combined batch API execution reports preserve redacted request + response + classification + verification evidence
- **173 / 173 automated tests pass**

V22 coverage retained underneath includes:

- exact Excel `systemName` provenance is preserved (`AIC - DCE` cannot be replaced by a partner/account/reference value)
- Stage blocks unreviewed `systemName` substitution
- Preflight blocks out-of-band staged `systemName` tampering
- LIVE rechecks the protected identity immediately before the real HTTP boundary
- an explicit governed human value edit is the only supported override path
- U-HAUL target smoke/reference payload has no stale default partner System Name
- all previous V9 mapping, readiness, reporting, health and governance tests
- every Source/Sender interface maps Good-to-Go with complete required evidence
- every Target/Receiver interface maps Good-to-Go with complete required evidence
- every Source interface passes Stage → Preflight → mocked LIVE TP Create
- every Target interface passes Stage → Preflight → mocked LIVE TP Create
- a seven-interface workbook passes bulk Stage → batch Preflight → parallel mocked LIVE ALL
- V130 SFTP Server Linux/Windows, Password/Key, Sender-only, Partner-only, rename/archive/cron/compression/EBCDIC conditions
- SFTP Server `Directory → Server Path` while SFTP HAFT `Directory` never becomes Subscription Folder
- supported interface catalog exposes all seven as LIVE Create capable
- value-only Stage accepts customer value changes but rejects added/removed/re-nested attributes
- interface/role/runtime selector values are contract-owned and immutable after selection
- Preflight fingerprints the actual Dell execution boundary
- LIVE reconstructs the outgoing JSON from the canonical interface schema before the real HTTP call
- URL/method/schema/selector drift after Preflight is blocked
- PROD requires V130 confirmation and change ticket
- LIVE-readiness and staged LIVE-plan diagnostics are non-mutating
- Create HTTP 2xx is not final success: a new exact-TP audit/check record is required when post-create verification is enabled
- the exact V130 TP Migration method/path/attribute set is regression-locked
- Source and Target migration payloads for all seven interface families preserve their exact selected interface parameter schema
- seven different interface families can be migration-preflighted and migrated in one parallel governed batch
- Migration uses explicit source/target environments, immutable request structure, host allowlist, OAuth, PROD guard and human `MIGRATE` / `MIGRATE ALL` confirmation
- optional post-Migration target-environment audit verification distinguishes accepted vs verified migrated

- independent LLM-as-Judge role with redacted evidence and dedicated prompt/model setting
- deterministic `BLOCK` cannot be promoted by an LLM `PASS`
- Judge may make a deterministic decision more conservative
- mandatory Judge gate blocks LIVE before network execution when verdict is not PASS / Judge is unavailable
- mapping, pre-LIVE, post-Create, pre-Migration and post-Migration Judge evidence is exposed in UI/report/history
- Judge cannot mutate TP attributes, selectors, methods, URLs, headers or directly execute Create/Migration

When the configured LIVE gates are enabled, production code makes a real `requests.request(...)` call to the resolved Dell HIP endpoint. No authenticated Dell HIP Create mutation is performed by automated release tests; external HTTP is mocked only at the final network boundary.

See `UPGRADE_V23_SYSTEM_TYPE_RULE_API_EXECUTION_REPORT.md` and `V23_FINAL_VALIDATION.md` for the current release summary. V22 and older upgrade notes remain for change history.

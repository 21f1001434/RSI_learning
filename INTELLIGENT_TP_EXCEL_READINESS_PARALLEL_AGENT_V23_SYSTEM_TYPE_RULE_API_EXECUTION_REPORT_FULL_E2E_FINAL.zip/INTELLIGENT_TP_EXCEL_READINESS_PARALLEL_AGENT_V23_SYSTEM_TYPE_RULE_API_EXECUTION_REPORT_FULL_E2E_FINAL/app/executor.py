from __future__ import annotations

import os
import re
import json
import threading
import time
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, Mapping
from urllib.parse import urlparse

import requests

from .catalog import read_path, schema_locked
from .governance import (
    fingerprint, identity_fingerprint, redact, validate_field_rules,
    schema_fingerprint, project_values_onto_schema,
    validate_locked_values, locked_values_fingerprint,
)
from .runtime_config import (
    bulk_live_enabled,
    credential_profile,
    host_allowed,
    live_enabled,
    oauth_settings,
    parallel_workers,
    request_timeout,
    request_verify,
    resolve_contract_url,
    retry_attempts_default,
    runtime_summary,
    production_guard,
    tp_post_create_check_enabled,
    tp_audit_poll_interval_seconds,
    tp_audit_poll_timeout_seconds,
)
from .workbook import blank
from .judge import judge_required_for_live
from .tp_contracts import validate_interface_payload
from .tp_service import governed_system_type_for_name
from .uhal_reference import validation_payload as uhal_validation_payload
from .response_intelligence import agent_assess_response, classify_create_response, classify_final_outcome

_ENV_PATTERN = re.compile(r"\$\{([A-Z0-9_]+)\}")
_PAYLOAD_PATTERN = re.compile(r"\$\{payload:([^}]+)\}")
_CIRCUITS: Dict[str, Dict[str, Any]] = {}
_CIRCUIT_LOCK = threading.RLock()
_TOKEN_CACHE: Dict[str, tuple[str, float]] = {}
_TOKEN_LOCK = threading.RLock()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def four_eyes_required() -> bool:
    return str(os.getenv("FOUR_EYES_REQUIRED", "false")).strip().lower() in {"1", "true", "yes", "y"}


def remote_preflight_enabled() -> bool:
    return str(os.getenv("ENABLE_REMOTE_PREFLIGHT_CHECKS", "false")).strip().lower() in {"1", "true", "yes", "y"}




def tp_remote_validation_enabled() -> bool:
    """Whether staged TP values must pass the non-mutating Dell validator before Create.

    Default is true for LIVE-oriented V12. Set HIP_TP_VALIDATE_BEFORE_CREATE=false only
    when the target environment does not expose the validator route.
    """
    return str(os.getenv("HIP_TP_VALIDATE_BEFORE_CREATE", "true")).strip().lower() in {"1", "true", "yes", "y"}


def _response_summary(body: Any, status: int | None = None) -> str:
    """Produce a concise operator-facing Dell response summary without hiding evidence."""
    if isinstance(body, Mapping):
        candidates = []
        for key in ("message", "error", "errorMessage", "detail", "title", "reason", "description"):
            value = body.get(key)
            if value not in (None, "", [], {}):
                candidates.append(str(value))
        for key in ("errors", "violations", "details"):
            value = body.get(key)
            if value not in (None, "", [], {}):
                candidates.append(str(value))
        text = " | ".join(candidates) if candidates else str(dict(body))
    else:
        text = str(body or "")
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        text = "Dell API returned no response body"
    prefix = f"HTTP {status}: " if status is not None else ""
    return (prefix + text)[:2000]


def _response_text(body: Any) -> str:
    try:
        if isinstance(body, Mapping):
            return json.dumps(body, ensure_ascii=False, default=str).lower()
        return str(body or "").lower()
    except Exception:
        return str(body or "").lower()


def _is_tp_existing_response(body: Any, status: int | None = None) -> bool:
    """Recognize explicit same-TP duplicate/existing evidence from Dell.

    This is intentionally narrow: the response must talk about a Transport Profile
    (or transportProfileName) and explicitly say it already exists/pre-exists.
    Generic uniqueness failures for unrelated fields are NOT converted to EXISTING.
    """
    text = _response_text(body)
    tp_identity = any(x in text for x in ("transport profile", "transportprofile", "transport profile name"))
    existing = any(x in text for x in ("already exists", "already exist", "pre-existing", "preexisting", "object exists"))
    return bool(tp_identity and existing)


def _tp_validation_payload_from_create(payload: Mapping[str, Any]) -> Dict[str, Any]:
    """Build the non-mutating TP validator request from the exact staged Create values."""
    details = list(payload.get("transportProfileDetails") or [])
    detail = details[0] if details and isinstance(details[0], Mapping) else {}
    interfaces = list(detail.get("interfaceDetails") or []) if isinstance(detail, Mapping) else []
    iface = interfaces[0] if interfaces and isinstance(interfaces[0], Mapping) else {}
    return {
        "interfaceType": iface.get("interfaceType") or "",
        "propertyMap": deepcopy(iface.get("parameters") or {}),
        "transportProfileName": detail.get("transportProfileName") or "",
        "hipEnvironment": payload.get("hipEnvironment") or os.getenv("HIP_ENVIRONMENT", "DEV"),
    }


def validate_staged_tp_with_dell(payload: Mapping[str, Any], contract: Mapping[str, Any]) -> Dict[str, Any]:
    """Validate the exact staged TP values against Dell without creating a TP.

    A 2xx response is accepted. Any 4xx/5xx verdict is surfaced and blocks Create so
    an operator sees the exact Dell rejection before a mutating request is attempted.
    """
    if not contract.get("interface_family"):
        return {"configured": False, "enabled": False, "passed": True, "state": "NOT_APPLICABLE"}
    enabled = tp_remote_validation_enabled()
    if not enabled:
        return {"configured": True, "enabled": False, "passed": True, "state": "DISABLED", "message": "HIP_TP_VALIDATE_BEFORE_CREATE=false"}
    base = str(os.getenv("HIP_CONFIG_SERVICE_BASE_URL") or "https://apigtwtst.us.dell.com/hip-config-service").rstrip("/")
    url = base + "/api/transport-profiles/validate-unique-interface-detail"
    if not host_allowed(url):
        return {"configured": True, "enabled": True, "passed": False, "state": "BLOCKED", "url": url, "message": "TP validation host is not allowlisted"}
    validation_payload = _tp_validation_payload_from_create(payload)
    local_missing = [k for k in ("interfaceType", "transportProfileName") if blank(validation_payload.get(k))]
    if local_missing:
        return {
            "configured": True, "enabled": True, "passed": False, "state": "MISSING_VALUES", "url": url,
            "message": "TP validator cannot run because values are missing: " + ", ".join(local_missing),
            "request": redact(validation_payload),
        }
    try:
        bearer = _target_bearer_value(contract)
    except Exception as exc:
        return {"configured": True, "enabled": True, "passed": False, "state": "AUTH_FAILED", "url": url, "message": f"OAuth failed before staged TP validation: {type(exc).__name__}: {exc}", "request": redact(validation_payload)}
    headers = {"Accept": "application/json", "Content-Type": "application/json", "Authorization": bearer}
    requester = str(os.getenv("HIP_REQUESTED_BY") or "").strip()
    if requester:
        headers["x-requester-id"] = requester
    started = time.perf_counter()
    try:
        response = requests.request("POST", url, headers=headers, json=validation_payload, timeout=request_timeout(), verify=request_verify())
        try:
            body: Any = response.json()
        except Exception:
            body = response.text[:20000]
        status = int(response.status_code)
        already_exists = _is_tp_existing_response(body, status)
        passed = (200 <= status < 300) or already_exists
        state = "EXISTING" if already_exists else ("PASS" if passed else ("AUTH_FAILED" if status in {401, 403} else "REJECTED"))
        return {
            "configured": True, "enabled": True, "passed": passed, "state": state, "url": url,
            "statusCode": status, "elapsedMs": int((time.perf_counter()-started)*1000),
            "alreadyExists": already_exists,
            "message": (
                "Dell TP validator confirmed this Transport Profile already exists; duplicate Create will be skipped and the checking API will verify the existing TP"
                if already_exists else
                ("Dell TP validator accepted the staged values" if passed else "Dell TP validator rejected the staged values")
            ),
            "responseSummary": _response_summary(body, status),
            "response": redact(body), "request": redact(validation_payload), "mutating": False,
        }
    except requests.RequestException as exc:
        return {"configured": True, "enabled": True, "passed": False, "state": "DOWN", "url": url, "elapsedMs": int((time.perf_counter()-started)*1000), "message": f"{type(exc).__name__}: {exc}", "request": redact(validation_payload), "mutating": False}




_AUDIT_SUCCESS_STATUSES = {
    "SUCCESS", "SUCCEEDED", "COMPLETED", "COMPLETE", "DEPLOYED", "ACTIVE", "DONE", "FINISHED",
}
_AUDIT_FAILURE_STATUSES = {
    "FAIL", "FAILED", "FAILURE", "ERROR", "ERRORED", "REJECTED", "CANCELLED", "CANCELED",
    "ABORTED", "TERMINATED",
}
_AUDIT_STATUS_KEYS = {
    "status", "taskStatus", "operationStatus", "auditStatus", "deploymentStatus",
    "transportProfileStatus", "result", "state",
}


def _normalize_audit_status(value: Any) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", str(value or "").strip().upper()).strip("_")


def _tp_name_from_payload(payload: Mapping[str, Any]) -> str:
    details = list(payload.get("transportProfileDetails") or [])
    detail = details[0] if details and isinstance(details[0], Mapping) else {}
    return str(detail.get("transportProfileName") or "").strip()


def _tp_environment_from_payload(payload: Mapping[str, Any]) -> str:
    return str(payload.get("hipEnvironment") or os.getenv("HIP_ENVIRONMENT") or "DEV").strip()


def _audit_records(body: Any) -> list[Dict[str, Any]]:
    records: Any = body
    if isinstance(body, Mapping):
        records = body.get("data") or body.get("audits") or body.get("results") or []
    if not isinstance(records, list):
        return []
    return [dict(x) for x in records if isinstance(x, Mapping)]


def _record_tp_name(record: Mapping[str, Any]) -> str:
    for key in ("transportProfileName", "profileName", "tpName", "name"):
        value = record.get(key)
        if value not in (None, ""):
            return str(value).strip()
    for key in ("request", "payload", "transportProfile", "details"):
        nested = record.get(key)
        if isinstance(nested, Mapping):
            found = _record_tp_name(nested)
            if found:
                return found
    return ""


def _record_operation(record: Mapping[str, Any]) -> str:
    for key in ("operation", "operationType", "action", "transportProfileOperation"):
        value = record.get(key)
        if value not in (None, ""):
            return _normalize_audit_status(value)
    return ""


def _record_statuses(record: Mapping[str, Any]) -> set[str]:
    values: set[str] = set()
    def walk(node: Any) -> None:
        if isinstance(node, Mapping):
            for key, value in node.items():
                if key in _AUDIT_STATUS_KEYS and value not in (None, ""):
                    norm = _normalize_audit_status(value)
                    if norm:
                        values.add(norm)
                if isinstance(value, (Mapping, list)):
                    walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)
    walk(record)
    return values


def _record_identifier(record: Mapping[str, Any]) -> str:
    for key in ("transportProfileId", "profileId", "id", "auditId", "requestId", "correlationId"):
        value = record.get(key)
        if value not in (None, ""):
            return str(value)
    return ""


def _select_relevant_audit_record(records: list[Dict[str, Any]], tp_name: str) -> Dict[str, Any] | None:
    if not records:
        return None
    named = [r for r in records if not _record_tp_name(r) or _record_tp_name(r) == tp_name]
    candidates = named or records
    # The V130 TP audit API returns newest first. Prefer Create/Created records when
    # operation metadata is available, but never reorder the server-provided chronology.
    create_ops = {"CREATE", "CREATED"}
    for row in candidates:
        op = _record_operation(row)
        if op in create_ops:
            return row
    return candidates[0]


def _tp_audit_url() -> str:
    base = str(os.getenv("HIP_CONFIG_SERVICE_BASE_URL") or "https://apigtwtst.us.dell.com/hip-config-service").rstrip("/")
    return base + "/api/transport-profiles/audits"


def fetch_tp_audit_snapshot(payload: Mapping[str, Any], contract: Mapping[str, Any]) -> Dict[str, Any]:
    """Read the Dell TP audit/checking API once for the exact TP identity."""
    tp_name = _tp_name_from_payload(payload)
    environment = _tp_environment_from_payload(payload)
    url = _tp_audit_url()
    params = {"transportProfileName": tp_name, "hipEnvironment": environment}
    if not tp_name:
        return {"ok": False, "state": "MISSING_TP_NAME", "url": url, "params": params, "message": "transportProfileName is blank"}
    if not host_allowed(url):
        return {"ok": False, "state": "BLOCKED", "url": url, "params": params, "message": "TP checking API host is not allowlisted"}
    try:
        bearer = _target_bearer_value(contract)
    except Exception as exc:
        return {"ok": False, "state": "AUTH_FAILED", "url": url, "params": params, "message": f"OAuth failed before TP checking API: {type(exc).__name__}: {exc}"}
    headers = {"Accept": "application/json", "Authorization": bearer}
    requester = str(os.getenv("HIP_REQUESTED_BY") or "").strip()
    if requester:
        headers["x-requester-id"] = requester
    started = time.perf_counter()
    try:
        response = requests.request("GET", url, headers=headers, params=params, timeout=request_timeout(), verify=request_verify())
        status = int(response.status_code)
        try:
            body: Any = response.json()
        except Exception:
            body = response.text[:20000]
        records = _audit_records(body)
        latest = _select_relevant_audit_record(records, tp_name)
        statuses = sorted(_record_statuses(latest or {}))
        ok = 200 <= status < 300
        state = "REACHABLE" if ok else ("AUTH_FAILED" if status in {401, 403} else "ERROR")
        return {
            "ok": ok,
            "state": state,
            "url": url,
            "params": params,
            "statusCode": status,
            "elapsedMs": int((time.perf_counter() - started) * 1000),
            "recordsCount": len(records),
            "latestRecord": redact(latest) if latest else None,
            "latestRecordSha256": fingerprint(latest) if latest else "",
            "latestStatuses": statuses,
            "latestIdentifier": _record_identifier(latest or {}),
            "response": redact(body),
            "responseSummary": _response_summary(body, status),
            "message": "Dell TP checking API responded" if ok else "Dell TP checking API request failed",
            "mutating": False,
        }
    except requests.RequestException as exc:
        return {
            "ok": False, "state": "DOWN", "url": url, "params": params,
            "elapsedMs": int((time.perf_counter() - started) * 1000),
            "message": f"{type(exc).__name__}: {exc}", "mutating": False,
        }


def verify_existing_tp_with_dell(payload: Mapping[str, Any], contract: Mapping[str, Any]) -> Dict[str, Any]:
    """Confirm an already-existing TP using Dell's non-mutating audit/checking API.

    This path is used when Dell explicitly says the exact TP already exists. It
    avoids a duplicate Create mutation and requires checking-API evidence for the
    exact TP identity before the run is treated as successful/EXISTING.
    """
    snap = fetch_tp_audit_snapshot(payload, contract)
    if not snap.get("ok"):
        return {
            "enabled": True, "required": True, "verified": False, "passed": False,
            "state": "EXISTING_CHECK_FAILED",
            "message": snap.get("message") or "Dell TP checking API could not verify the existing Transport Profile",
            "auditUrl": snap.get("url"), "params": snap.get("params"),
            "responseSummary": snap.get("responseSummary"), "latestRecord": snap.get("latestRecord"),
            "latestStatuses": snap.get("latestStatuses") or [], "elapsedMs": snap.get("elapsedMs") or 0,
        }
    latest = snap.get("latestRecord")
    statuses = set(str(x) for x in (snap.get("latestStatuses") or []))
    if not latest:
        return {
            "enabled": True, "required": True, "verified": False, "passed": False,
            "state": "EXISTING_NOT_FOUND_IN_AUDIT",
            "message": "Dell validator reported the TP already exists, but the checking API returned no exact TP audit record",
            "auditUrl": snap.get("url"), "params": snap.get("params"),
            "responseSummary": snap.get("responseSummary"), "latestStatuses": sorted(statuses),
            "elapsedMs": snap.get("elapsedMs") or 0,
        }
    if statuses.intersection(_AUDIT_FAILURE_STATUSES):
        return {
            "enabled": True, "required": True, "verified": False, "passed": False,
            "state": "EXISTING_AUDIT_FAILED",
            "message": "Dell checking API found the TP but its latest audit evidence is a terminal failure",
            "auditUrl": snap.get("url"), "params": snap.get("params"),
            "responseSummary": snap.get("responseSummary"), "latestRecord": latest,
            "latestStatuses": sorted(statuses), "elapsedMs": snap.get("elapsedMs") or 0,
        }
    return {
        "enabled": True, "required": True, "verified": True, "passed": True,
        "state": "EXISTING_VERIFIED",
        "message": "Dell checking API verified the exact Transport Profile already exists",
        "auditUrl": snap.get("url"), "params": snap.get("params"),
        "responseSummary": snap.get("responseSummary"), "latestRecord": latest,
        "latestStatuses": sorted(statuses), "latestIdentifier": snap.get("latestIdentifier"),
        "elapsedMs": snap.get("elapsedMs") or 0,
    }


def verify_created_tp_with_dell(
    payload: Mapping[str, Any],
    contract: Mapping[str, Any],
    *,
    baseline: Mapping[str, Any] | None = None,
) -> Dict[str, Any]:
    """Poll Dell's TP audit/checking API until the new Create is terminal.

    The Create response is not treated as success on its own. A TP is successful only
    after the checking API returns a *new* audit event (different from the pre-Create
    baseline when one was available) with a terminal success status.
    """
    if not contract.get("interface_family"):
        return {"enabled": False, "required": False, "verified": True, "passed": True, "state": "NOT_APPLICABLE"}
    if not tp_post_create_check_enabled():
        return {
            "enabled": False, "required": False, "verified": False, "passed": True, "state": "DISABLED",
            "message": "HIP_TP_POST_CREATE_CHECK_ENABLED=false; Create response is not independently verified",
        }
    interval = tp_audit_poll_interval_seconds()
    timeout = tp_audit_poll_timeout_seconds()
    baseline_sha = str((baseline or {}).get("latestRecordSha256") or "")
    attempts: list[Dict[str, Any]] = []
    start = time.perf_counter()
    last: Dict[str, Any] = {}
    while True:
        snap = fetch_tp_audit_snapshot(payload, contract)
        last = snap
        latest_sha = str(snap.get("latestRecordSha256") or "")
        statuses = set(str(x) for x in (snap.get("latestStatuses") or []))
        changed = bool(latest_sha and (not baseline_sha or latest_sha != baseline_sha))
        attempts.append({
            "attempt": len(attempts) + 1,
            "statusCode": snap.get("statusCode"),
            "state": snap.get("state"),
            "recordsCount": snap.get("recordsCount"),
            "latestRecordSha256": latest_sha,
            "changedFromBaseline": changed,
            "statuses": sorted(statuses),
            "elapsedMs": snap.get("elapsedMs"),
        })
        if snap.get("ok"):
            if changed and statuses.intersection(_AUDIT_FAILURE_STATUSES):
                return {
                    "enabled": True, "required": True, "verified": False, "passed": False,
                    "state": "AUDIT_FAILED", "message": "Dell TP checking API reported terminal failure",
                    "auditUrl": snap.get("url"), "params": snap.get("params"), "attempts": attempts,
                    "latestStatuses": sorted(statuses), "latestRecord": snap.get("latestRecord"),
                    "latestIdentifier": snap.get("latestIdentifier"), "responseSummary": snap.get("responseSummary"),
                    "baselineLatestRecordSha256": baseline_sha, "elapsedMs": int((time.perf_counter()-start)*1000),
                }
            if changed and statuses.intersection(_AUDIT_SUCCESS_STATUSES):
                return {
                    "enabled": True, "required": True, "verified": True, "passed": True,
                    "state": "VERIFIED_CREATED", "message": "Dell TP checking API confirmed the new Transport Profile Create completed successfully",
                    "auditUrl": snap.get("url"), "params": snap.get("params"), "attempts": attempts,
                    "latestStatuses": sorted(statuses), "latestRecord": snap.get("latestRecord"),
                    "latestIdentifier": snap.get("latestIdentifier"), "responseSummary": snap.get("responseSummary"),
                    "baselineLatestRecordSha256": baseline_sha, "elapsedMs": int((time.perf_counter()-start)*1000),
                }
        elif snap.get("state") == "AUTH_FAILED":
            return {
                "enabled": True, "required": True, "verified": False, "passed": False,
                "state": "AUTH_FAILED", "message": snap.get("message") or "TP checking API authentication failed",
                "auditUrl": snap.get("url"), "params": snap.get("params"), "attempts": attempts,
                "responseSummary": snap.get("responseSummary"), "baselineLatestRecordSha256": baseline_sha,
                "elapsedMs": int((time.perf_counter()-start)*1000),
            }
        if (time.perf_counter() - start) >= timeout:
            break
        time.sleep(min(interval, max(0.0, timeout - (time.perf_counter() - start))))
    return {
        "enabled": True, "required": True, "verified": False, "passed": False,
        "state": "VERIFICATION_TIMEOUT", "message": "Create was accepted, but Dell TP checking API did not expose a new terminal SUCCESS/FAILURE event before timeout",
        "auditUrl": last.get("url") or _tp_audit_url(), "params": last.get("params"), "attempts": attempts,
        "latestStatuses": last.get("latestStatuses") or [], "latestRecord": last.get("latestRecord"),
        "latestIdentifier": last.get("latestIdentifier"), "responseSummary": last.get("responseSummary"),
        "baselineLatestRecordSha256": baseline_sha, "elapsedMs": int((time.perf_counter()-start)*1000),
    }

def resolve_env(value: Any, missing: set[str]) -> Any:
    if isinstance(value, dict):
        return {k: resolve_env(v, missing) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_env(v, missing) for v in value]
    if not isinstance(value, str):
        return value

    def repl(match: re.Match[str]) -> str:
        key = match.group(1)
        env = os.getenv(key)
        if env is None or env == "":
            missing.add(key)
            return match.group(0)
        return env

    return _ENV_PATTERN.sub(repl, value)


def resolve_payload_templates(value: Any, payload: Mapping[str, Any]) -> Any:
    if isinstance(value, dict):
        return {k: resolve_payload_templates(v, payload) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_payload_templates(v, payload) for v in value]
    if not isinstance(value, str):
        return value
    return _PAYLOAD_PATTERN.sub(
        lambda m: str(read_path(payload, m.group(1)) if read_path(payload, m.group(1)) is not None else ""), value
    )


def _extract_token(body: Any) -> str:
    if isinstance(body, dict):
        for key in ("access_token", "accessToken", "token", "bearerToken", "id_token"):
            value = body.get(key)
            if value:
                return str(value)
        nested = body.get("data")
        if isinstance(nested, dict):
            for key in ("access_token", "accessToken", "token", "bearerToken"):
                value = nested.get(key)
                if value:
                    return str(value)
    return ""


def _oauth_token_for_contract(contract: Mapping[str, Any]) -> str:
    profile = credential_profile(contract)
    settings = oauth_settings(profile)
    if not (settings["token_url"] and settings["client_id"] and settings["client_secret"]):
        raise ValueError(f"{profile} OAuth is not configured in the V122 environment")
    cache_key = f"{profile}:{settings['token_url']}:{settings['client_id']}:{settings['scope']}"
    with _TOKEN_LOCK:
        cached = _TOKEN_CACHE.get(cache_key)
        if cached and cached[1] > time.time() + 60:
            return cached[0]

    data: Dict[str, str] = {"grant_type": "client_credentials"}
    if settings["scope"]:
        data["scope"] = settings["scope"]
    headers = {
        "Accept": "application/json",
        "User-Agent": os.getenv("HIP_TOKEN_USER_AGENT", "PostmanRuntime/7.49.0"),
    }
    response = requests.post(
        settings["token_url"],
        data=data,
        auth=(settings["client_id"], settings["client_secret"]),
        headers=headers,
        timeout=request_timeout(),
        verify=request_verify(),
    )
    if response.status_code in {400, 401, 403}:
        response = requests.post(
            settings["token_url"],
            data={**data, "client_id": settings["client_id"], "client_secret": settings["client_secret"]},
            headers=headers,
            timeout=request_timeout(),
            verify=request_verify(),
        )
    response.raise_for_status()
    try:
        body: Any = response.json()
    except Exception:
        body = response.text.strip()
    token = _extract_token(body) if isinstance(body, dict) else str(body or "").strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    if not token:
        raise ValueError(f"{profile} OAuth response did not include an access token")
    expires = 1800
    if isinstance(body, dict):
        try:
            expires = int(body.get("expires_in") or 1800)
        except Exception:
            expires = 1800
    with _TOKEN_LOCK:
        _TOKEN_CACHE[cache_key] = (token, time.time() + max(120, expires))
    return token


def _target_bearer_value(contract: Mapping[str, Any]) -> str:
    # Compatibility direct token first, then exact V122 per-API OAuth profiles.
    authorization = str(os.getenv("HIP_AUTHORIZATION") or "").strip()
    if authorization:
        return authorization if authorization.lower().startswith("bearer ") else f"Bearer {authorization}"
    token = str(os.getenv("TARGET_API_BEARER_TOKEN") or os.getenv("HIP_BEARER_TOKEN") or "").strip()
    if token:
        return token if token.lower().startswith("bearer ") else f"Bearer {token}"
    return f"Bearer {_oauth_token_for_contract(contract)}"


def target_auth_diagnostics(contract: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    if contract is not None:
        profile = credential_profile(contract)
        settings = oauth_settings(profile)
        ready = bool(os.getenv("HIP_AUTHORIZATION") or os.getenv("TARGET_API_BEARER_TOKEN") or (settings["token_url"] and settings["client_id"] and settings["client_secret"]))
        return {"ready": ready, "profile": profile, "mode": "V122 profile OAuth" if ready else "not configured", "tokenUrlConfigured": bool(settings["token_url"])}
    rows = {}
    for profile in ("HIP", "ACCOUNT", "PARTNER", "SYSTEM"):
        s = oauth_settings(profile)
        rows[profile] = {
            "ready": bool(os.getenv("HIP_AUTHORIZATION") or os.getenv("TARGET_API_BEARER_TOKEN") or (s["token_url"] and s["client_id"] and s["client_secret"])),
            "tokenUrlConfigured": bool(s["token_url"]),
            "clientIdConfigured": bool(s["client_id"]),
        }
    return {"ready": all(v["ready"] for v in rows.values()), "mode": "V122 credential profiles", "profiles": rows}


def _resolve_execution_headers(
    raw_headers: Mapping[str, Any],
    missing: set[str],
    *,
    contract: Mapping[str, Any],
    payload: Mapping[str, Any],
    stage_account: str = "",
) -> Dict[str, str]:
    headers: Dict[str, str] = {}
    for key, raw in dict(raw_headers or {}).items():
        raw_text = str(raw).strip()
        if raw_text in {"${HIP_AUTHORIZATION}", "${TARGET_API_TOKEN}"}:
            try:
                headers[str(key)] = _target_bearer_value(contract)
            except Exception:
                missing.add(f"{credential_profile(contract)}_OAUTH")
            continue
        if raw_text in {"${HIP_ACCOUNT_NAME}", "${STAGE_ACCOUNT}"}:
            account_name = str(os.getenv("HIP_ACCOUNT_NAME") or stage_account or "").strip()
            if account_name:
                headers[str(key)] = account_name
            else:
                missing.add("HIP_ACCOUNT_NAME_OR_EXCEL_ACCOUNT")
            continue
        expanded = resolve_payload_templates(raw, payload)
        headers[str(key)] = str(resolve_env(expanded, missing))
    requester = str(os.getenv("HIP_REQUESTED_BY") or "").strip()
    if requester:
        headers.setdefault("x-requester-id", requester)
    return headers


def test_contract_oauth(contract: Mapping[str, Any]) -> Dict[str, Any]:
    """Actively test the exact V122 OAuth profile without exposing the token."""
    profile = credential_profile(contract)
    started = time.perf_counter()
    try:
        bearer = _target_bearer_value(contract)
        direct = bool(os.getenv("HIP_AUTHORIZATION") or os.getenv("TARGET_API_BEARER_TOKEN") or os.getenv("HIP_BEARER_TOKEN"))
        return {
            "ok": True,
            "state": "UP",
            "profile": profile,
            "elapsedMs": int((time.perf_counter() - started) * 1000),
            "tokenReceived": bool(bearer),
            "message": f"{profile} authentication material is available ({'direct bearer' if direct else 'V122 client-credentials OAuth'})",
        }
    except Exception as exc:
        return {
            "ok": False,
            "state": "DOWN",
            "profile": profile,
            "elapsedMs": int((time.perf_counter() - started) * 1000),
            "tokenReceived": False,
            "message": f"{type(exc).__name__}: {exc}",
        }


def probe_contract_endpoint(contract: Mapping[str, Any], *, authenticated: bool = True) -> Dict[str, Any]:
    """Non-mutating endpoint probe. OPTIONS is used; 4xx/405 still proves gateway reachability."""
    url = resolve_contract_url(contract)
    started = time.perf_counter()
    if not url:
        return {"ok": False, "state": "DOWN", "url": "", "message": "TP API URL is empty", "elapsedMs": 0}
    if not host_allowed(url):
        return {"ok": False, "state": "BLOCKED", "url": url, "message": "TP API host is not allowlisted", "elapsedMs": 0}
    headers = {"Accept": "application/json"}
    if authenticated:
        try:
            headers["Authorization"] = _target_bearer_value(contract)
        except Exception as exc:
            return {"ok": False, "state": "AUTH_FAILED", "url": url, "message": f"OAuth failed before API probe: {type(exc).__name__}: {exc}", "elapsedMs": int((time.perf_counter()-started)*1000)}
    try:
        response = requests.options(url, headers=headers, timeout=request_timeout(), verify=request_verify(), allow_redirects=True)
        status = int(response.status_code)
        if 200 <= status < 400:
            state = "UP"; ok = True; message = f"TP API/gateway responded HTTP {status} to safe OPTIONS probe"
        elif status in {401, 403}:
            state = "AUTH_FAILED"; ok = False; message = f"TP API/gateway responded HTTP {status}; network is reachable but authentication/authorization was not accepted"
        elif status in {400, 404, 405, 409, 415, 422}:
            state = "REACHABLE"; ok = True; message = f"TP API/gateway is reachable (HTTP {status}; OPTIONS may not be supported)"
        elif status == 429:
            state = "DEGRADED"; ok = False; message = "TP API/gateway returned HTTP 429 rate limit"
        elif status >= 500:
            # Create orchestration routes in V122 can return 500 to OPTIONS even when
            # authenticated POST traffic is healthy. Treat this probe as inconclusive,
            # never as proof that the TP API is down. Deep health uses the non-mutating
            # U-HAUL validation route for the actual service verdict.
            state = "INCONCLUSIVE"; ok = True; message = f"Create route returned HTTP {status} to OPTIONS; this method probe is inconclusive, not an API-down verdict"
        else:
            state = "DEGRADED"; ok = False; message = f"TP API/gateway returned HTTP {status}"
        return {"ok": ok, "state": state, "url": url, "statusCode": status, "elapsedMs": int((time.perf_counter()-started)*1000), "message": message}
    except Exception as exc:
        return {"ok": False, "state": "DOWN", "url": url, "elapsedMs": int((time.perf_counter()-started)*1000), "message": f"{type(exc).__name__}: {exc}"}


def probe_uhal_tp_validation(contract: Mapping[str, Any], role: str) -> Dict[str, Any]:
    """Run the V122 U-HAUL TP *validation* call as a non-mutating service smoke test.

    This tests the same HIP OAuth profile, host, TLS settings and TP interface payload
    family used by LIVE execution, without sending the orchestration/create request.
    Business validation responses (400/409/422) prove that the TP service is reachable;
    401/403 are auth failures and 5xx are genuine service/gateway failures.
    """
    started = time.perf_counter()
    base = str(os.getenv("HIP_CONFIG_SERVICE_BASE_URL") or "https://apigtwtst.us.dell.com/hip-config-service").rstrip("/")
    url = base + "/api/transport-profiles/validate-unique-interface-detail"
    if not host_allowed(url):
        return {"ok": False, "state": "BLOCKED", "url": url, "role": role, "message": "TP validation host is not allowlisted", "elapsedMs": 0}
    try:
        bearer = _target_bearer_value(contract)
    except Exception as exc:
        return {"ok": False, "state": "AUTH_FAILED", "url": url, "role": role, "message": f"OAuth failed before U-HAUL TP validation: {type(exc).__name__}: {exc}", "elapsedMs": int((time.perf_counter()-started)*1000)}
    headers = {"Accept": "application/json", "Content-Type": "application/json", "Authorization": bearer}
    requester = str(os.getenv("HIP_REQUESTED_BY") or "").strip()
    if requester:
        headers["x-requester-id"] = requester
    payload = uhal_validation_payload(role)
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=request_timeout(), verify=request_verify())
        status = int(response.status_code)
        if 200 <= status < 300:
            state, ok = "UP", True
            message = f"U-HAUL {role} TP validation responded HTTP {status}"
        elif status in {400, 404, 409, 415, 422}:
            # The validator ran and returned a business/request verdict. This is
            # sufficient to prove service + route reachability; surface the status
            # separately so the operator can inspect the validation semantics.
            state, ok = "REACHABLE", True
            message = f"U-HAUL {role} TP validation route is reachable (HTTP {status} business/request verdict)"
        elif status in {401, 403}:
            state, ok = "AUTH_FAILED", False
            message = f"U-HAUL {role} TP validation rejected authentication/authorization (HTTP {status})"
        elif status == 429:
            state, ok = "DEGRADED", False
            message = "U-HAUL TP validation returned HTTP 429 rate limit"
        else:
            state, ok = ("DOWN" if status >= 500 else "DEGRADED"), False
            message = f"U-HAUL {role} TP validation returned HTTP {status}"
        preview = ""
        try:
            body = response.json()
            preview = str(redact(body))[:600]
        except Exception:
            preview = str(response.text or "")[:600]
        return {
            "ok": ok, "state": state, "url": url, "role": role,
            "statusCode": status, "elapsedMs": int((time.perf_counter()-started)*1000),
            "message": message, "responsePreview": preview,
            "reference": "V122 developer-approved U-HAUL SFTP HAFT validation payload",
            "mutating": False,
        }
    except Exception as exc:
        return {"ok": False, "state": "DOWN", "url": url, "role": role, "elapsedMs": int((time.perf_counter()-started)*1000), "message": f"{type(exc).__name__}: {exc}", "mutating": False}

def _circuit_state(url: str) -> Dict[str, Any]:
    host = (urlparse(url).hostname or "unknown").lower()
    with _CIRCUIT_LOCK:
        row = _CIRCUITS.setdefault(host, {"failures": 0, "openedAt": 0.0})
        threshold = int(os.getenv("CIRCUIT_BREAKER_FAILURES", "5"))
        cooldown = int(os.getenv("CIRCUIT_BREAKER_COOLDOWN_SECONDS", "60"))
        open_now = row["failures"] >= threshold and (time.time() - row["openedAt"]) < cooldown
        if row["failures"] >= threshold and not open_now:
            row["failures"] = 0
            row["openedAt"] = 0.0
        return {"host": host, "open": open_now, **row}


def _record_circuit(url: str, success: bool) -> None:
    host = (urlparse(url).hostname or "unknown").lower()
    with _CIRCUIT_LOCK:
        row = _CIRCUITS.setdefault(host, {"failures": 0, "openedAt": 0.0})
        if success:
            row["failures"] = 0
            row["openedAt"] = 0.0
        else:
            row["failures"] += 1
            if row["failures"] >= int(os.getenv("CIRCUIT_BREAKER_FAILURES", "5")):
                row["openedAt"] = time.time()


def _run_remote_checks(payload: Mapping[str, Any], contract: Mapping[str, Any], stage_account: str = "") -> Dict[str, Any]:
    checks = list(contract.get("preflight_checks") or [])
    if not checks:
        return {"enabled": remote_preflight_enabled(), "configured": 0, "results": [], "passed": True}
    if not remote_preflight_enabled():
        return {"enabled": False, "configured": len(checks), "results": [], "passed": True, "note": "ENABLE_REMOTE_PREFLIGHT_CHECKS=false"}
    timeout = int(os.getenv("REMOTE_PREFLIGHT_TIMEOUT_SECONDS", "30"))
    results = []
    for check in checks:
        missing: set[str] = set()
        method = str(check.get("method") or "GET").upper()
        if method not in {"GET", "HEAD"}:
            results.append({"name": check.get("name", "check"), "passed": False, "error": "Only GET/HEAD preflight checks are permitted"})
            continue
        url = str(resolve_env(resolve_payload_templates(check.get("url") or "", payload), missing))
        if not host_allowed(url):
            results.append({"name": check.get("name", "check"), "passed": False, "error": "Preflight check host is not allowlisted"})
            continue
        headers = _resolve_execution_headers(
            resolve_payload_templates(check.get("headers") or contract.get("headers") or {}, payload),
            missing,
            contract=contract,
            payload=payload,
            stage_account=stage_account,
        )
        params = resolve_payload_templates(check.get("params") or {}, payload)
        if missing:
            results.append({"name": check.get("name", "check"), "passed": False, "error": "Missing env: " + ", ".join(sorted(missing))})
            continue
        try:
            resp = requests.request(method, url, headers={"Accept": "application/json", **headers}, params=params, timeout=timeout, verify=request_verify())
            expected = set(int(x) for x in (check.get("success_statuses") or check.get("successStatuses") or [200]))
            passed = resp.status_code in expected
            results.append({"name": check.get("name", "check"), "passed": passed, "statusCode": resp.status_code, "required": bool(check.get("required", True))})
        except Exception as exc:
            results.append({"name": check.get("name", "check"), "passed": False, "required": bool(check.get("required", True)), "error": f"{type(exc).__name__}: {exc}"})
    passed = all(r.get("passed") or not r.get("required", True) for r in results)
    return {"enabled": True, "configured": len(checks), "results": results, "passed": passed}



def _execution_plan_fingerprint(contract: Mapping[str, Any], payload: Mapping[str, Any], resolved_url: str | None = None) -> str:
    """Fingerprint the immutable LIVE HTTP boundary excluding rotating OAuth tokens."""
    url = resolved_url if resolved_url is not None else resolve_contract_url(contract)
    return fingerprint({
        "method": str(contract.get("method") or "POST").upper(),
        "resolvedUrl": str(url or ""),
        "requestKind": str(contract.get("request_kind") or "payload"),
        "contractSha256": contract.get("contract_sha256"),
        "schemaSha256": schema_fingerprint(contract.get("canonical_request") or {}),
        "lockedValuesSha256": locked_values_fingerprint(payload, contract.get("locked_value_paths") or []),
        "headerNames": sorted(str(k) for k in (contract.get("headers") or {}).keys()),
        "credentialProfile": credential_profile(contract),
    })

def _system_name_provenance_errors(stage: Mapping[str, Any], payload: Mapping[str, Any], contract: Mapping[str, Any]) -> list[str]:
    """Defence-in-depth for TP systemName provenance at Preflight/LIVE.

    V22 stages record the exact approved systemName source. If stage storage is
    manually changed, or an old/stale stage lacks provenance metadata, LIVE is
    blocked before any Dell mutation can occur.
    """
    if str(contract.get("key") or "") not in {"source_tp", "target_tp"}:
        return []
    if not bool(stage.get("systemNameProvenanceRequired")):
        return []
    prov = stage.get("systemNameProvenance")
    if not isinstance(prov, Mapping):
        return ["SYSTEM_NAME_PROVENANCE_LOCK: stage has no systemName provenance metadata; re-analyze and re-stage with V23"]
    expected_sha = str(stage.get("systemNameProvenanceSha256") or "")
    if expected_sha and expected_sha != fingerprint(dict(prov)):
        return ["SYSTEM_NAME_PROVENANCE_LOCK: provenance metadata changed after staging"]
    if bool(prov.get("autoSubstitutionAllowed")):
        return ["SYSTEM_NAME_PROVENANCE_LOCK: automatic systemName substitution must remain disabled"]
    actual = str(payload.get("systemName") or "").strip()
    approved = str(prov.get("approvedValue") or "").strip()
    if not actual:
        return ["SYSTEM_NAME_PROVENANCE_LOCK: staged systemName is blank"]
    if not approved:
        return ["SYSTEM_NAME_PROVENANCE_LOCK: no approved Excel/human source exists for staged systemName"]
    if actual != approved:
        return [f"SYSTEM_NAME_PROVENANCE_LOCK: staged systemName {actual!r} does not equal approved source {approved!r}"]
    return []




def _system_type_rule_errors(stage: Mapping[str, Any], payload: Mapping[str, Any], contract: Mapping[str, Any]) -> list[str]:
    """V23 defence-in-depth: systemType is a deterministic function of systemName."""
    if str(contract.get("key") or "") not in {"source_tp", "target_tp"}:
        return []
    if not bool(stage.get("systemTypeRuleRequired")):
        # Legacy/generic API staging did not opt into TP system identity governance.
        # V23 TP-only stages always set this flag and are checked fail-closed below.
        return []
    rule = stage.get("systemTypeRule")
    if not isinstance(rule, Mapping):
        return ["SYSTEM_TYPE_SYSTEM_NAME_LOCK: stage systemType rule metadata is missing"]
    expected_sha = str(stage.get("systemTypeRuleSha256") or "")
    if expected_sha and expected_sha != fingerprint(dict(rule)):
        return ["SYSTEM_TYPE_SYSTEM_NAME_LOCK: systemType rule metadata changed after staging"]
    name = str(payload.get("systemName") or "").strip()
    actual = str(payload.get("systemType") or "").strip()
    if not name:
        return []  # systemName provenance/required-path checks report the identity problem
    expected = governed_system_type_for_name(name)
    if not expected:
        return [f"SYSTEM_TYPE_SYSTEM_NAME_LOCK: cannot derive systemType from systemName {name!r}"]
    if actual != expected:
        return [f"SYSTEM_TYPE_SYSTEM_NAME_LOCK: systemName {name!r} requires systemType {expected!r}, but staged payload has {actual!r}"]
    recorded_name = str(rule.get("systemName") or "").strip()
    recorded_expected = str(rule.get("expectedSystemType") or "").strip()
    if recorded_name and recorded_name != name:
        return [f"SYSTEM_TYPE_SYSTEM_NAME_LOCK: staged systemName {name!r} differs from rule snapshot {recorded_name!r}"]
    if recorded_expected and recorded_expected != expected:
        return [f"SYSTEM_TYPE_SYSTEM_NAME_LOCK: governed systemType {expected!r} differs from staged rule snapshot {recorded_expected!r}"]
    return []

def preflight(stage: Mapping[str, Any], contract: Mapping[str, Any], duplicate_run: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    payload = stage.get("payload")
    base = contract.get("canonical_request")
    if not isinstance(payload, dict) or not isinstance(base, dict):
        errors.append("Staged request is not a JSON object")
    elif not schema_locked(base, payload):
        errors.append("Schema lock failed: API attributes/nesting/cardinality changed")
    if isinstance(payload, dict):
        errors.extend(_system_name_provenance_errors(stage, payload, contract))
        errors.extend(_system_type_rule_errors(stage, payload, contract))
    current_schema_sha = schema_fingerprint(payload or {})
    canonical_schema_sha = schema_fingerprint(base or {})
    if stage.get("schemaSha256") and stage.get("schemaSha256") != current_schema_sha:
        errors.append("TP attribute manifest changed after staging")
    if current_schema_sha != canonical_schema_sha:
        errors.append("TP payload attribute manifest does not match the selected interface contract")
    locked_findings = validate_locked_values(payload or {}, contract)
    if locked_findings:
        errors.extend([str(f.get("message") or f) for f in locked_findings])
    if stage.get("lockedValuesSha256") and stage.get("lockedValuesSha256") != locked_values_fingerprint(payload or {}, contract.get("locked_value_paths") or []):
        errors.append("Contract-owned selector/runtime values changed after staging")
    missing_required = [p for p in (contract.get("required_paths") or []) if blank(read_path(payload, p))]
    if missing_required:
        errors.append("Missing required values: " + ", ".join(missing_required))
    field_findings = validate_field_rules(payload or {}, contract)
    interface_findings = validate_interface_payload(payload or {}, contract) if contract.get("interface_family") else []
    field_findings = list(field_findings) + list(interface_findings)
    if field_findings:
        errors.extend([str(f.get("message") or f) for f in field_findings])
    if str(contract.get("lifecycle_status") or "APPROVED") != "APPROVED":
        errors.append(f"Contract lifecycle is {contract.get('lifecycle_status')}; APPROVED is required")
    if stage.get("contractSha256") and stage.get("contractSha256") != contract.get("contract_sha256"):
        errors.append("Contract snapshot hash changed since staging")
    if not contract.get("url"):
        errors.append("API URL is empty")
    if not contract.get("method"):
        errors.append("HTTP method is empty")
    execution_gate_errors: list[str] = []
    if not contract.get("allow_live", True):
        msg = "This contract is marked allow_live=false"
        warnings.append(msg)
        execution_gate_errors.append(msg)
    if stage.get("approvalStatus") == "REJECTED":
        errors.append("Stage was rejected by an approver")
    if four_eyes_required() and stage.get("approvalStatus") != "APPROVED":
        errors.append("Four-eyes approval is required before LIVE execution")

    resolved_url = resolve_contract_url(contract)
    missing_env: set[str] = set()
    _resolve_execution_headers(
        contract.get("headers") or {},
        missing_env,
        contract=contract,
        payload=payload or {},
        stage_account=str(stage.get("account") or ""),
    )
    if missing_env:
        msg = "Execution environment variables not configured: " + ", ".join(sorted(missing_env))
        warnings.append(msg); execution_gate_errors.append(msg)
    if resolved_url and not host_allowed(resolved_url):
        msg = "Remote host is not allowlisted; LIVE remains blocked"
        warnings.append(msg); execution_gate_errors.append(msg)
    if not live_enabled():
        msg = "HIP_LIVE_API_EXECUTION is false; LIVE remains blocked"
        warnings.append(msg); execution_gate_errors.append(msg)
    prod_guard = production_guard()
    if not prod_guard.get("passed"):
        execution_gate_errors.extend([str(x) for x in (prod_guard.get("errors") or [])])
        warnings.extend([str(x) for x in (prod_guard.get("errors") or [])])

    canonical_paths = [str(p) for p in (contract.get("paths") or [])]
    blank_canonical = [p for p in canonical_paths if blank(read_path(payload or {}, p))]
    required_set = set(str(p) for p in (contract.get("required_paths") or []))
    blank_optional = [p for p in blank_canonical if p not in required_set]

    # V12: before a mutating Create call, validate the exact staged TP values
    # against Dell's non-mutating TP validator. This turns opaque Create HTTP 400
    # failures into a preflight verdict with the real Dell response.
    dell_tp_validation: Dict[str, Any] = {"configured": bool(contract.get("interface_family")), "enabled": False, "passed": True, "state": "SKIPPED"}
    local_payload_clear = not errors
    runtime_can_validate = live_enabled() and bool(resolved_url and host_allowed(resolved_url))
    if contract.get("interface_family") and tp_remote_validation_enabled() and local_payload_clear and runtime_can_validate:
        dell_tp_validation = validate_staged_tp_with_dell(payload or {}, contract)
        if dell_tp_validation.get("alreadyExists"):
            warnings.append("Dell reports this exact Transport Profile already exists. LIVE will verify it with the checking API and skip duplicate Create.")
        elif not dell_tp_validation.get("passed"):
            msg = "Dell TP pre-create validation failed: " + str(dell_tp_validation.get("responseSummary") or dell_tp_validation.get("message") or "validation rejected")
            errors.append(msg)
    elif contract.get("interface_family") and tp_remote_validation_enabled() and not runtime_can_validate:
        dell_tp_validation = {"configured": True, "enabled": False, "passed": True, "state": "SKIPPED_RUNTIME_NOT_READY", "message": "Dell TP validator will run when LIVE runtime/host gates are ready"}

    duplicate_policy = str(contract.get("duplicate_policy") or "warn")
    duplicate = None
    if duplicate_run:
        duplicate = {"runId": duplicate_run.get("runId"), "executedAt": duplicate_run.get("executedAt"), "statusCode": duplicate_run.get("statusCode")}
        msg = f"A prior successful execution exists for the same object identity: {duplicate.get('runId')}"
        if duplicate_policy == "block":
            errors.append(msg)
        elif duplicate_policy == "warn":
            warnings.append(msg)

    remote = _run_remote_checks(payload or {}, contract, str(stage.get("account") or ""))
    if remote.get("configured") and not remote.get("enabled"):
        warnings.append("Remote read-only preflight checks are configured but disabled")
    if remote.get("enabled") and not remote.get("passed"):
        errors.append("One or more required remote preflight checks failed")
    circuit = _circuit_state(resolved_url) if resolved_url else {"open": False}
    if circuit.get("open"):
        errors.append(f"Circuit breaker is open for host {circuit.get('host')}")

    passed = not errors
    execution_ready = passed and not execution_gate_errors
    return {
        "passed": passed,
        "executionReady": execution_ready,
        "executionGateErrors": execution_gate_errors,
        "checkedAt": _now(),
        "errors": errors,
        "warnings": warnings,
        "missingRequiredPaths": missing_required,
        "blankCanonicalPaths": blank_canonical,
        "blankOptionalPaths": blank_optional,
        "blankCanonicalCount": len(blank_canonical),
        "blankOptionalCount": len(blank_optional),
        "fieldRuleFindings": field_findings,
        "dellTpValidation": dell_tp_validation,
        "tpAlreadyExists": bool(dell_tp_validation.get("alreadyExists")),
        "payloadSha256": fingerprint(payload),
        "identityFingerprint": identity_fingerprint(contract, payload or {}),
        "contractSha256": contract.get("contract_sha256"),
        "schemaSha256": current_schema_sha,
        "canonicalSchemaSha256": canonical_schema_sha,
        "lockedValuesSha256": locked_values_fingerprint(payload or {}, contract.get("locked_value_paths") or []),
        "executionPlanSha256": _execution_plan_fingerprint(contract, payload or {}, resolved_url),
        "schemaLocked": isinstance(payload, dict) and isinstance(base, dict) and schema_locked(base, payload),
        "attributeMutationBlocked": True,
        "lockedValueFindings": locked_findings,
        "liveEnabled": live_enabled(),
        "bulkLiveEnabled": bulk_live_enabled(),
        "hostAllowed": bool(resolved_url and host_allowed(resolved_url)),
        "resolvedUrl": resolved_url,
        "contractAllowsLive": bool(contract.get("allow_live", True)),
        "contractApproved": contract.get("lifecycle_status") == "APPROVED",
        "approvalStatus": stage.get("approvalStatus", "PENDING"),
        "fourEyesRequired": four_eyes_required(),
        "duplicate": duplicate,
        "duplicatePolicy": duplicate_policy,
        "remoteChecks": remote,
        "circuitBreaker": circuit,
        "targetAuth": target_auth_diagnostics(contract),
        "credentialProfile": credential_profile(contract),
        "runtime": runtime_summary(),
        "productionGuard": prod_guard,
    }


def _can_retry(method: str, contract: Mapping[str, Any]) -> bool:
    if method in {"GET", "HEAD", "PUT", "DELETE"}:
        return True
    return bool(contract.get("idempotency_header"))


def execute(stage: Mapping[str, Any], contract: Mapping[str, Any], confirmation: str, actor: str = "Human User") -> Dict[str, Any]:
    pf = stage.get("preflight") or {}
    if str(confirmation or "").strip() != "LIVE":
        raise ValueError("Type LIVE exactly to confirm execution")
    if not pf.get("passed"):
        raise ValueError("Agent preflight has not passed")
    if judge_required_for_live():
        judge_gate = pf.get("judgeGate") or {}
        if not judge_gate.get("passed"):
            raise ValueError("LLM Judge gate has not passed. Re-run preflight with a PASS judge verdict before LIVE")
    if pf.get("payloadSha256") != fingerprint(stage.get("payload")):
        raise ValueError("Staged payload changed after preflight; run preflight again")
    if pf.get("contractSha256") != contract.get("contract_sha256"):
        raise ValueError("API contract changed after preflight; stage/preflight again")
    candidate_payload = stage.get("payload") or {}
    if not schema_locked(contract.get("canonical_request") or {}, candidate_payload):
        raise ValueError("CANONICAL_TP_ATTRIBUTE_LOCK: TP attributes/nesting/cardinality changed after preflight")
    if pf.get("schemaSha256") != schema_fingerprint(candidate_payload):
        raise ValueError("CANONICAL_TP_ATTRIBUTE_LOCK: TP attribute manifest changed after preflight")
    locked_findings = validate_locked_values(candidate_payload, contract)
    if locked_findings:
        raise ValueError("CONTRACT_OWNED_VALUE_LOCK: " + " | ".join(str(x.get("message") or x) for x in locked_findings))
    if pf.get("lockedValuesSha256") != locked_values_fingerprint(candidate_payload, contract.get("locked_value_paths") or []):
        raise ValueError("CONTRACT_OWNED_VALUE_LOCK: selector/runtime value fingerprint changed after preflight")
    if four_eyes_required() and stage.get("approvalStatus") != "APPROVED":
        raise ValueError("Four-eyes approval has not been completed")
    if not live_enabled():
        raise ValueError("LIVE execution is disabled. Set HIP_LIVE_API_EXECUTION=true in the V122-style .env")
    if not contract.get("allow_live", True):
        raise ValueError("This API contract has allow_live=false")
    if contract.get("lifecycle_status") != "APPROVED":
        raise ValueError("Only APPROVED API contracts may execute LIVE")
    prod_guard = production_guard()
    if not prod_guard.get("passed"):
        raise ValueError("Dell PROD execution guard failed: " + " | ".join(str(x) for x in (prod_guard.get("errors") or [])))

    url = resolve_contract_url(contract)
    # Rebuild the final HTTP payload through the selected interface's immutable
    # canonical schema. This guarantees that only scalar values can vary at LIVE.
    payload = project_values_onto_schema(contract.get("canonical_request") or {}, candidate_payload)
    system_provenance_errors = _system_name_provenance_errors(stage, payload, contract)
    if system_provenance_errors:
        raise ValueError(" | ".join(system_provenance_errors))
    system_type_errors = _system_type_rule_errors(stage, payload, contract)
    if system_type_errors:
        raise ValueError(" | ".join(system_type_errors))
    if pf.get("executionPlanSha256") != _execution_plan_fingerprint(contract, payload, url):
        raise ValueError("LIVE execution boundary changed after preflight (URL/method/schema/contract selector)")
    live_interface_findings = validate_interface_payload(payload, contract) if contract.get("interface_family") else []
    if live_interface_findings:
        raise ValueError("TP interface conditional validation failed before LIVE: " + " | ".join(str(x.get("message") or x) for x in live_interface_findings))
    missing: set[str] = set()
    headers = _resolve_execution_headers(
        deepcopy(contract.get("headers") or {}),
        missing,
        contract=contract,
        payload=payload,
        stage_account=str(stage.get("account") or ""),
    )
    if missing:
        raise ValueError("Missing execution environment variables: " + ", ".join(sorted(missing)))
    if not host_allowed(url):
        raise ValueError("LIVE target host is not allowlisted")
    circuit = _circuit_state(url)
    if circuit.get("open"):
        raise ValueError(f"Circuit breaker is open for host {circuit.get('host')}")

    method = str(contract.get("method") or "POST").upper()
    request_kind = str(contract.get("request_kind") or "payload")
    request_headers = {"Accept": "application/json", **headers}
    if request_kind == "payload":
        request_headers.setdefault("Content-Type", "application/json")
    idem_header = str(contract.get("idempotency_header") or "").strip()
    if idem_header:
        request_headers[idem_header] = pf.get("identityFingerprint") or fingerprint(payload)

    # V13: take a non-mutating audit snapshot immediately before Create. The post-create
    # checker must observe a new terminal audit event, not merely reuse an older success.
    tp_audit_baseline = (
        fetch_tp_audit_snapshot(payload, contract)
        if contract.get("interface_family") and tp_post_create_check_enabled()
        else {"ok": False, "state": "DISABLED", "latestRecordSha256": ""}
    )

    # V16: explicit existing evidence is a successful reusable TP outcome. Do not
    # send a duplicate mutating Create; verify the exact TP with the checking API.
    preflight_validation = pf.get("dellTpValidation") or {}
    if preflight_validation.get("alreadyExists"):
        started_existing = time.perf_counter()
        existing_verification = verify_existing_tp_with_dell(payload, contract)
        verified_existing = bool(existing_verification.get("verified"))
        success_existing = verified_existing
        result_state = "EXISTING_VERIFIED" if verified_existing else "EXISTING_UNVERIFIED"
        response_summary = (
            str(preflight_validation.get("responseSummary") or "Dell validator: TP already exists")
            + " | TP audit: "
            + str(existing_verification.get("message") or existing_verification.get("state") or "")
        )
        create_classification = {
            "classification": "EXISTING",
            "acceptedForVerification": False,
            "existing": True,
            "failed": False,
            "httpAccepted": 200 <= int(preflight_validation.get("statusCode") or 200) < 300,
            "semanticFailure": False,
            "semanticSuccess": False,
            "semanticPending": False,
            "reason": "Dell pre-create validator explicitly reported that the exact Transport Profile already exists.",
            "evidence": [str(preflight_validation.get("responseSummary") or "TP already exists")],
            "deterministic": True,
        }
        final_classification = classify_final_outcome(create=create_classification, verification=existing_verification)
        response_agent = agent_assess_response(
            status_code=int(existing_verification.get("statusCode") or preflight_validation.get("statusCode") or 200),
            body=existing_verification.get("latestRecord") or preflight_validation.get("response") or {},
            create_classification=create_classification,
            verification=existing_verification,
            final_classification=final_classification,
        )
        return {
            "runId": "",
            "stageId": stage.get("stageId"), "analysisId": stage.get("analysisId"),
            "rowId": stage.get("rowId"), "excelRow": stage.get("excelRow"), "sheetName": stage.get("sheetName"),
            "account": stage.get("account"), "apiKey": contract.get("key"), "apiName": contract.get("name"),
            "apiVersion": contract.get("version"), "contractSha256": contract.get("contract_sha256"),
            "credentialProfile": credential_profile(contract), "actor": actor, "executedAt": _now(),
            "method": method, "url": url,
            "statusCode": existing_verification.get("statusCode") or preflight_validation.get("statusCode") or 200,
            "success": success_existing, "existing": True, "createSkipped": True,
            "createAccepted": False, "dellReached": True, "dellAccepted": True,
            "verifiedCreated": False, "verifiedExisting": verified_existing,
            "resultState": result_state, "outcomeClassification": final_classification.get("classification"),
            "responseClassification": create_classification, "responseAgent": response_agent,
            "responseSummary": response_summary,
            "createResponseSummary": str(preflight_validation.get("responseSummary") or ""),
            "elapsedMs": int((time.perf_counter() - started_existing) * 1000) + int(existing_verification.get("elapsedMs") or 0),
            "createElapsedMs": 0, "attempts": [],
            "tpAuditBaseline": redact(tp_audit_baseline), "postCreateVerification": redact(existing_verification),
            "payloadSha256": fingerprint(payload), "schemaSha256": schema_fingerprint(payload),
            "executionPlanSha256": pf.get("executionPlanSha256"), "attributeMutationBlocked": True,
            "lockedValuePaths": list(contract.get("locked_value_paths") or []),
            "identityFingerprint": pf.get("identityFingerprint") or identity_fingerprint(contract, payload),
            "request": {"kind": request_kind, "payload": redact(payload, contract.get("sensitive_paths") or [])},
            "response": redact(existing_verification.get("latestRecord") or {}),
        }

    retry = contract.get("retry_policy") or {}
    configured_attempts = int(retry.get("max_attempts", retry_attempts_default()))
    max_attempts = configured_attempts if retry.get("enabled") and _can_retry(method, contract) else 1
    max_attempts = max(1, min(max_attempts, retry_attempts_default()))
    statuses = set(retry.get("statuses") or [429, 502, 503, 504])
    backoff = float(retry.get("backoff_seconds", 1.0))
    attempt_rows = []
    response = None
    start_all = time.perf_counter()
    for attempt in range(1, max_attempts + 1):
        start = time.perf_counter()
        try:
            response = requests.request(
                method,
                url,
                headers=request_headers,
                params=payload if request_kind == "params" else None,
                json=payload if request_kind == "payload" else None,
                timeout=request_timeout(),
                verify=request_verify(),
            )
            elapsed = int((time.perf_counter() - start) * 1000)
            attempt_rows.append({"attempt": attempt, "statusCode": response.status_code, "elapsedMs": elapsed})
            if response.status_code not in statuses or attempt >= max_attempts:
                break
        except requests.RequestException as exc:
            elapsed = int((time.perf_counter() - start) * 1000)
            attempt_rows.append({"attempt": attempt, "error": f"{type(exc).__name__}: {exc}", "elapsedMs": elapsed})
            if attempt >= max_attempts:
                raise
        time.sleep(backoff * (2 ** (attempt - 1)))
    if response is None:
        raise ValueError("No HTTP response received")
    elapsed_ms = int((time.perf_counter() - start_all) * 1000)
    try:
        response_body: Any = response.json()
    except Exception:
        response_body = response.text[:20000]
    create_classification = classify_create_response(
        int(response.status_code),
        response_body,
        contract.get("success_statuses") or [200, 201, 202, 204],
    )
    create_accepted = bool(create_classification.get("acceptedForVerification"))
    create_existing = bool(create_classification.get("existing"))
    create_response_summary = _response_summary(response_body, int(response.status_code))

    post_create_verification: Dict[str, Any]
    if create_accepted:
        post_create_verification = verify_created_tp_with_dell(payload, contract, baseline=tp_audit_baseline)
    elif create_existing:
        post_create_verification = verify_existing_tp_with_dell(payload, contract)
    else:
        post_create_verification = {
            "enabled": tp_post_create_check_enabled(), "required": bool(contract.get("interface_family")),
            "verified": False, "passed": False, "state": "CREATE_REJECTED",
            "message": "Create was rejected; post-create checking API was not used to claim success",
        }

    verification_required = bool(post_create_verification.get("required"))
    verified_created = bool(post_create_verification.get("verified")) if create_accepted else False
    verified_existing = bool(post_create_verification.get("verified")) if create_existing else False
    success = bool(
        (create_accepted and (verified_created if verification_required else post_create_verification.get("passed", True)))
        or (create_existing and verified_existing)
    )
    if create_existing and success:
        result_state = "EXISTING_VERIFIED"
        response_summary = create_response_summary + " | TP audit: existing TP verified"
    elif create_existing:
        result_state = "EXISTING_UNVERIFIED"
        response_summary = create_response_summary + " | TP audit: " + str(post_create_verification.get("message") or "existing TP not verified")
    elif success:
        result_state = "VERIFIED_CREATED"
        response_summary = create_response_summary + " | TP audit: verified created successfully"
    elif not create_accepted:
        # Preserve REJECTED for ordinary non-2xx API rejections. A distinct state is
        # used only for the important case where HTTP looked successful but the body
        # itself explicitly says the TP operation failed.
        result_state = (
            "RESPONSE_CLASSIFIED_FAILED"
            if create_classification.get("semanticFailure") and create_classification.get("httpAccepted")
            else "REJECTED"
        )
        response_summary = create_response_summary
    elif post_create_verification.get("state") == "AUDIT_FAILED":
        result_state = "CREATE_ACCEPTED_AUDIT_FAILED"
        response_summary = create_response_summary + " | TP audit: FAILED · " + str(post_create_verification.get("responseSummary") or post_create_verification.get("message") or "")
    elif post_create_verification.get("state") == "VERIFICATION_TIMEOUT":
        result_state = "CREATE_ACCEPTED_VERIFICATION_PENDING"
        response_summary = create_response_summary + " | TP audit: verification pending/timeout"
    else:
        result_state = "CREATE_ACCEPTED_VERIFICATION_FAILED"
        response_summary = create_response_summary + " | TP audit: " + str(post_create_verification.get("message") or post_create_verification.get("state") or "not verified")

    final_classification = classify_final_outcome(create=create_classification, verification=post_create_verification)
    # When post-create verification is intentionally disabled, preserve the app's
    # legacy success boolean but never tell the operator the TP was VERIFIED.
    if create_accepted and not verification_required and success and final_classification.get("classification") == "PENDING":
        final_classification = {**final_classification, "reason": "Dell accepted the Create response; independent checking is disabled, so the outcome remains PENDING/unverified."}
    response_agent = agent_assess_response(
        status_code=int(response.status_code),
        body=response_body,
        create_classification=create_classification,
        verification=post_create_verification,
        final_classification=final_classification,
    )

    _record_circuit(url, bool(create_accepted or create_existing))
    return {
        "runId": "",
        "stageId": stage.get("stageId"),
        "analysisId": stage.get("analysisId"),
        "rowId": stage.get("rowId"),
        "excelRow": stage.get("excelRow"),
        "sheetName": stage.get("sheetName"),
        "account": stage.get("account"),
        "apiKey": contract.get("key"),
        "apiName": contract.get("name"),
        "apiVersion": contract.get("version"),
        "contractSha256": contract.get("contract_sha256"),
        "credentialProfile": credential_profile(contract),
        "actor": actor,
        "executedAt": _now(),
        "method": method,
        "url": url,
        "statusCode": response.status_code,
        "success": success,
        "existing": create_existing,
        "createSkipped": False,
        "createAccepted": create_accepted,
        "dellReached": True,
        "dellAccepted": bool(create_accepted or create_existing),
        "verifiedCreated": verified_created,
        "verifiedExisting": verified_existing,
        "resultState": result_state,
        "outcomeClassification": final_classification.get("classification"),
        "responseClassification": create_classification,
        "responseAgent": response_agent,
        "responseSummary": response_summary,
        "createResponseSummary": create_response_summary,
        "elapsedMs": elapsed_ms + int(post_create_verification.get("elapsedMs") or 0),
        "createElapsedMs": elapsed_ms,
        "attempts": attempt_rows,
        "tpAuditBaseline": redact(tp_audit_baseline),
        "postCreateVerification": redact(post_create_verification),
        "payloadSha256": fingerprint(payload),
        "schemaSha256": schema_fingerprint(payload),
        "executionPlanSha256": pf.get("executionPlanSha256"),
        "attributeMutationBlocked": True,
        "lockedValuePaths": list(contract.get("locked_value_paths") or []),
        "identityFingerprint": pf.get("identityFingerprint") or identity_fingerprint(contract, payload),
        "request": {"kind": request_kind, "payload": redact(payload, contract.get("sensitive_paths") or [])},
        "response": redact(response_body),
    }


__all__ = [
    "bulk_live_enabled",
    "execute",
    "four_eyes_required",
    "live_enabled",
    "parallel_workers",
    "preflight",
    "remote_preflight_enabled",
    "runtime_summary",
    "target_auth_diagnostics",
    "fetch_tp_audit_snapshot",
    "verify_created_tp_with_dell",
    "verify_existing_tp_with_dell",
]

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List, Mapping, Sequence, Tuple
import os
import re

from .catalog import read_path, write_path, schema_locked, normalize_contract
from .governance import fingerprint, identity_fingerprint, profile_records, validate_field_rules, validate_locked_values
from .mapper import evaluate_row, run_agents, validated_llm_hints
from .tp_contracts import dynamic_tp_contract, finalize_tp_contract, interface_family, interface_alias_info, superset_tp_contract, validate_interface_payload
from .workbook import blank, detect_header, display, headers_and_records, norm_text, read_workbook

TP_KEYS = {"source_tp", "target_tp"}

TP_NAME_PATH = "transportProfileDetails.0.transportProfileName"
SYSTEM_NAME_PATH = "systemName"
SYSTEM_TYPE_PATH = "systemType"
INTERFACE_TYPE_PATH = "transportProfileDetails.0.interfaceDetails.0.interfaceType"
DOC_NAME_PATH = "transportProfileDetails.0.documentTypeDetails.0.documentTypeName"
DOC_VERSION_PATH = "transportProfileDetails.0.documentTypeDetails.0.documentTypeVersion"
DOC_FORMAT_PATH = "transportProfileDetails.0.documentTypeDetails.0.dataFormatType"
SUBSCRIPTION_FOLDER_PATH = "transportProfileDetails.0.interfaceDetails.0.parameters.Subscription Folder"
EXISTING_ACCOUNT_PATH = "transportProfileDetails.0.interfaceDetails.0.parameters.Existing Account Name"

# These business-critical leaves are provenance locked. The LLM can explain and
# suggest optional mappings, but it cannot populate these from semantic guesses.
PROVENANCE_LOCKED_PATHS = {
    "systemName", TP_NAME_PATH, INTERFACE_TYPE_PATH, DOC_NAME_PATH, DOC_VERSION_PATH, DOC_FORMAT_PATH,
    SUBSCRIPTION_FOLDER_PATH, EXISTING_ACCOUNT_PATH,
}


def _value(values: Mapping[str, Any], *hints: str) -> Tuple[str, Any]:
    normalized = [(h, norm_text(h), v) for h, v in values.items()]
    for hint in hints:
        nh = norm_text(hint)
        for h, n, v in normalized:
            if n == nh and not blank(v): return h, v
    for hint in hints:
        nh = norm_text(hint)
        for h, n, v in normalized:
            if (nh in n or n in nh) and not blank(v): return h, v
    return "", ""


def _tp_sheet_score(headers: Sequence[str]) -> int:
    text = " | ".join(norm_text(h) for h in headers)
    signals = ["transport profile", "tp name", "interface type", "source system", "target system", "document type", "hip account", "lens tp"]
    return sum(2 if signal in text else 0 for signal in signals) + (2 if "transport" in text and "profile" in text else 0)


def _explicit_tp_name(values: Mapping[str, Any]) -> Tuple[str, Any]:
    # LENS TP Name is a customer/reference label in the supplied workbook. It is
    # never executable TP identity. LIVE TP identity must come from the explicit
    # DEV/Source/Target Transport Profile name columns.
    return _value(values, "DEV-Transport Profile Name", "DEV Transport Profile Name", "Source Transport Profile Name", "Target Transport Profile Name", "Transport Profile Name", "TP Name")


def _tp_name(values: Mapping[str, Any]) -> Tuple[str, Any]:
    header, value = _explicit_tp_name(values)
    if not blank(value):
        return header, value
    return _value(values, "LENS TP Name")


def _role_candidates(values: Mapping[str, Any], scope: str) -> Tuple[List[str], bool, str]:
    scope = str(scope or "BOTH").upper()
    if scope == "SOURCE": return ["source"], False, "User selected Source TP"
    if scope == "TARGET": return ["target"], False, "User selected Target TP"

    # V22 anti-hallucination role lock. If the workbook explicitly supplies the
    # Transport Profile role/usage, it is authoritative and wins before name or
    # Source/Target side heuristics. This prevents the correct System Name from
    # being paired with the wrong role when both endpoint columns are populated.
    role_header, role_raw = _exact_value(
        values,
        "TP Role", "Transport Profile Role", "TP Usage", "Transport Profile Usage",
        "Sender/Receiver", "Sender Receiver",
    )
    if role_header and not blank(role_raw):
        role_text = norm_text(role_raw)
        if role_text in {"source", "sender", "source sender", "src"}:
            return ["source"], False, f"Explicit Excel {role_header} resolved Source/Sender"
        if role_text in {"target", "receiver", "target receiver", "tgt"}:
            return ["target"], False, f"Explicit Excel {role_header} resolved Target/Receiver"
        return ["source", "target"], True, f"Explicit Excel {role_header} value {display(role_raw)!r} is not recognized; use Source/Sender or Target/Receiver"

    _, tp_name = _explicit_tp_name(values)
    name = str(tp_name or "").upper()
    tokens = set(re.findall(r"[A-Z0-9]+", name))
    if tokens & {"SRC", "SOURCE", "SENDER", "SNDR"}:
        return ["source"], False, "TP name contains source/sender role evidence"
    if tokens & {"TGT", "TARGET", "RECEIVER", "RCVR", "RECV"}:
        return ["target"], False, "TP name contains target/receiver role evidence"
    _, src_system = _value(values, "Source System")
    _, src_iface = _value(values, "Source Interface Type")
    _, tgt_system = _value(values, "Target System")
    _, tgt_iface = _value(values, "Target Interface Type")
    src = not blank(src_system) or not blank(src_iface)
    tgt = not blank(tgt_system) or not blank(tgt_iface)
    if src and not tgt: return ["source"], False, "Source-specific system/interface evidence"
    if tgt and not src: return ["target"], False, "Target-specific system/interface evidence"
    if src and tgt: return ["source", "target"], True, "Both Source and Target evidence are populated; both TP candidates require review unless role is encoded in TP name"
    return ["source", "target"], True, "No unambiguous Source/Target role evidence was found"


def _exact_value(values: Mapping[str, Any], *headers: str) -> Tuple[str, Any]:
    """Return only an explicitly named Excel column; never semantic/fuzzy inference."""
    lookup = {norm_text(h): h for h in values}
    for wanted in headers:
        actual = lookup.get(norm_text(wanted))
        if actual is not None and not blank(values.get(actual)):
            return actual, values.get(actual)
    return "", ""



def _reference_interface_suggestion(values: Mapping[str, Any], role: str, interface_raw: Any) -> Dict[str, Any] | None:
    """Advisory-only interface suggestion using approved reference patterns.

    U-HAUL is a validated SFTP HAFT reference.  The suggestion never changes the
    selected contract or payload by itself; explicit Excel input (or a future human
    acceptance workflow) remains the authority for contract selection.
    """
    if str(os.getenv("HIP_TP_AI_REFERENCE_SUGGESTIONS", "true")).strip().lower() not in {"1", "true", "yes", "y"}:
        return None
    info = interface_alias_info(interface_raw)
    raw = display(interface_raw)
    canonical = str(info.get("canonical") or "")
    if canonical == "SFTP HAFT":
        confidence = 0.99 if norm_text(raw) in {"sftp haft", "sftp-haft"} else 0.97
        return {
            "suggestedInterfaceType": "SFTP HAFT",
            "confidence": confidence,
            "reference": "U-HAUL approved SFTP HAFT reference",
            "reason": "The explicit Excel interface is in the approved SFTP HAFT alias family; U-HAUL is a validated reference using the same FILE/SFTP HAFT TP contract.",
            "requiresHumanConfirmation": False,
            "applied": True,
            "advisoryOnly": True,
        }
    if not blank(interface_raw):
        # Never reinterpret explicit SFTP Server or other recognized contracts as HAFT.
        return None

    # Missing interface: suggest SFTP HAFT only when HAFT-style evidence exists.
    # This suggestion does NOT make the row Good-to-Go and does not mutate the contract.
    evidence = []
    tp_header, tp_name = _tp_name(values)
    if "sftp" in norm_text(tp_name):
        evidence.append(f"{tp_header or 'TP name'} contains SFTP")
    sub_header, sub_value = _parameter_excel_value(values, SUBSCRIPTION_FOLDER_PATH)
    if sub_header and not blank(sub_value):
        evidence.append(f"{sub_header} is populated")
    acct_header, acct_value = _parameter_excel_value(values, EXISTING_ACCOUNT_PATH)
    if acct_header and not blank(acct_value):
        evidence.append(f"{acct_header} is populated")
    if len(evidence) >= 2:
        return {
            "suggestedInterfaceType": "SFTP HAFT",
            "confidence": 0.86,
            "reference": "U-HAUL approved SFTP HAFT reference",
            "reason": "HAFT-style workbook evidence resembles the approved U-HAUL SFTP HAFT pattern: " + "; ".join(evidence),
            "requiresHumanConfirmation": True,
            "applied": False,
            "advisoryOnly": True,
        }
    return None


def _interface_value(values: Mapping[str, Any], role: str) -> Tuple[str, Any]:
    """Interface selection is Excel-authoritative.

    The app may use the role-specific Interface Type column or an exact generic
    `Interface Type` column. It MUST NOT infer interface from TP names, server
    names, URLs, ports, authentication fields, delivery type, or the LLM.
    """
    # Team workbook correction: the generic ``Interface Type`` column is the
    # API-facing interface value. Legacy Source/Target Interface Type columns can
    # contain operational labels such as "Directory Monitor inbound" or
    # "MQ-Series Integration" and must not override it.
    generic = _exact_value(values, "Interface Type", "TP Interface Type", "API Interface Type")
    if generic[0]:
        return generic
    if role == "source":
        return _exact_value(values, "Source Interface Type")
    return _exact_value(values, "Target Interface Type")


def _system_leaf_name(header: Any) -> str:
    """Return the semantic leaf of a possibly grouped/duplicate Excel header.

    ``headers_and_records`` preserves parent context with ``>`` and may suffix
    duplicate labels with ``(2)``.  A workbook column such as
    ``Add > Transport Profile Details > System Name`` must still be recognized
    as the TP System Name rather than being reported as missing.
    """
    text = display(header)
    leaf = text.split(">")[-1].strip() if ">" in text else text
    leaf = re.sub(r"\s*\(\d+\)\s*$", "", leaf).strip()
    return norm_text(leaf)


def _role_specific_system_value(values: Mapping[str, Any], side: str) -> Tuple[str, Any]:
    side = "target" if str(side).lower().startswith("target") else "source"
    preferred = ("Source System", "Source System Name") if side == "source" else ("Target System", "Target System Name")
    header, value = _exact_value(values, *preferred)
    if header and not blank(value):
        return header, value
    other = "target" if side == "source" else "source"
    for h, v in values.items():
        if blank(v):
            continue
        n = norm_text(h)
        leaf = _system_leaf_name(h)
        if leaf not in {"system", "system name"}:
            continue
        if side in n and other not in n:
            return h, v
    return "", ""


def _role_system_value(values: Mapping[str, Any], role: str) -> Tuple[str, Any]:
    """Return systemName only from safe role-correct Excel evidence.

    V19 additionally recognizes context-qualified generic leaves such as
    ``Transport Profile Details > System Name``.  This fixes the false
    ``systemName missing`` result seen when the Excel value is present under a
    merged/grouped parent header.  Cross-role leakage remains blocked.
    """
    role = "target" if str(role).lower().startswith("target") else "source"
    header, value = _role_specific_system_value(values, role)
    if header:
        return header, value

    opposite = "source" if role == "target" else "target"
    opposite_h, opposite_v = _role_specific_system_value(values, opposite)

    # Exact generic headers remain supported.  They are safe only when an
    # opposite role-specific System value is not present in the same row.
    generic_h, generic_v = _exact_value(values, "System", "System Name")
    if generic_h and not blank(generic_v) and not (opposite_h and not blank(opposite_v)):
        return generic_h, generic_v

    # Grouped headers from the team workbook are not exact matches after parent
    # context is retained.  Match only the final leaf -- never fuzzy-match
    # ``System Type``, ownership, interface, or other system-related columns.
    for h, v in values.items():
        if blank(v):
            continue
        n = norm_text(h)
        if _system_leaf_name(h) not in {"system", "system name"}:
            continue
        if "source" in n or "target" in n:
            continue
        if opposite_h and not blank(opposite_v):
            continue
        return h, v
    return "", ""


def _lock_role_system_mapping(cmap: Dict[str, Dict[str, Any]], values: Mapping[str, Any], role: str) -> Tuple[Dict[str, Dict[str, Any]], str, Any]:
    """Remove any generic/fuzzy systemName mapping and inject role-correct evidence."""
    cmap = {h: meta for h, meta in cmap.items() if str(meta.get("path") or "") != SYSTEM_NAME_PATH}
    header, value = _role_system_value(values, role)
    if header and not blank(value):
        cmap[header] = {
            "path": SYSTEM_NAME_PATH,
            "confidence": 1.0,
            "method": "Role-locked Excel system provenance",
            "reason": f"{role.title()} TP systemName may only come from the {role.title()} System (or safe generic System) Excel evidence.",
        }
    return cmap, header, value


def system_name_provenance(action: Mapping[str, Any], payload: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    """Build the authoritative systemName provenance record used by Stage/LIVE.

    The agent is never allowed to invent/substitute ``systemName`` from partner,
    account, ownership, U-HAUL reference, LLM, or another role. The only allowed
    automatic value is the exact role-correct Excel System/System Name cell. A
    different value is allowed only after the human value-edit endpoint records
    ``systemName`` as an explicit human override.
    """
    candidate = payload if isinstance(payload, Mapping) else (action.get("proposedRequest") or {})
    actual = display(candidate.get("systemName")) if isinstance(candidate, Mapping) else ""
    human_paths = {str(x) for x in (action.get("humanValueEditPaths") or [])}
    human_override = SYSTEM_NAME_PATH in human_paths
    excel_value = display(action.get("systemSourceValue"))
    excel_column = str(action.get("systemSourceColumn") or "")
    mode = "HUMAN_CONFIRMED_VALUE_EDIT" if human_override else "EXPLICIT_EXCEL_SYSTEM_NAME"
    approved = actual if human_override else excel_value
    source_column = "Human value editor" if human_override else excel_column
    return {
        "mode": mode,
        "sourceColumn": source_column,
        "excelSourceColumn": excel_column,
        "excelSourceValue": excel_value,
        "approvedValue": approved,
        "payloadValue": actual,
        "humanOverride": human_override,
        "autoSubstitutionAllowed": False,
        "policy": "systemName must equal the exact role-correct Excel System/System Name value unless a human explicitly edits systemName through the governed value editor",
    }


def system_name_provenance_findings(action: Mapping[str, Any], payload: Mapping[str, Any] | None = None) -> List[Dict[str, Any]]:
    """Return blocking findings when systemName is missing or not provenance-safe."""
    prov = system_name_provenance(action, payload)
    actual = display(prov.get("payloadValue"))
    approved = display(prov.get("approvedValue"))
    findings: List[Dict[str, Any]] = []
    if blank(actual):
        findings.append({
            "path": SYSTEM_NAME_PATH,
            "code": "SYSTEM_NAME_MISSING",
            "message": "systemName is blank. Supply the role-correct Excel System/System Name value or explicitly set it with the human value editor.",
            "blocking": True,
        })
        return findings
    if not prov.get("humanOverride") and blank(approved):
        findings.append({
            "path": SYSTEM_NAME_PATH,
            "code": "SYSTEM_NAME_NO_EXCEL_PROVENANCE",
            "message": "systemName has no explicit role-correct Excel provenance. The agent is not allowed to infer it from partner/account/ownership/reference data.",
            "blocking": True,
        })
    elif approved != actual:
        findings.append({
            "path": SYSTEM_NAME_PATH,
            "code": "SYSTEM_NAME_PROVENANCE_MISMATCH",
            "message": f"systemName provenance mismatch: payload={actual!r}, approved source={approved!r}. Automatic substitution is blocked.",
            "blocking": True,
        })
    return findings



def _system_name_key(value: Any) -> str:
    """Normalize a system identity for governed ownership matching."""
    return re.sub(r"[^a-z0-9]+", "", str(value or "").strip().lower())


def governed_system_type_for_name(system_name: Any) -> str:
    """Return the only allowed TP systemType for a non-blank systemName.

    V23 business rule from the HIP team is intentionally exact and cannot be
    widened by the LLM, fuzzy matching, customer reference data, or runtime
    configuration:

      * AIC - DCE (punctuation/spacing variants) => Dell Application
      * every other explicit systemName => Partner

    Keeping this rule code-owned prevents a local environment setting from
    silently reclassifying a partner system as a Dell application immediately
    before LIVE execution.
    """
    if blank(system_name):
        return ""
    return "Dell Application" if _system_name_key(system_name) == _system_name_key("AIC - DCE") else "Partner"


def system_type_rule_record(payload: Mapping[str, Any]) -> Dict[str, Any]:
    name = display((payload or {}).get("systemName"))
    actual = display((payload or {}).get("systemType"))
    expected = governed_system_type_for_name(name)
    return {
        "systemName": name,
        "actualSystemType": actual,
        "expectedSystemType": expected,
        "passed": bool(name and expected and actual == expected),
        "rule": "AIC - DCE => Dell Application; every other explicit systemName => Partner",
        "fuzzyInferenceAllowed": False,
    }


def system_type_rule_findings(payload: Mapping[str, Any]) -> List[Dict[str, Any]]:
    record = system_type_rule_record(payload)
    name = record["systemName"]
    actual = record["actualSystemType"]
    expected = record["expectedSystemType"]
    findings: List[Dict[str, Any]] = []
    if blank(name):
        return findings  # systemName provenance has its own required-field blocker
    if not expected:
        findings.append({
            "path": SYSTEM_TYPE_PATH,
            "code": "SYSTEM_TYPE_RULE_UNRESOLVED",
            "message": "systemType could not be derived from the approved systemName rule.",
            "blocking": True,
        })
    elif actual != expected:
        findings.append({
            "path": SYSTEM_TYPE_PATH,
            "code": "SYSTEM_TYPE_SYSTEM_NAME_MISMATCH",
            "message": f"systemType mismatch for systemName {name!r}: payload={actual!r}, required={expected!r}.",
            "blocking": True,
        })
    return findings

def _canonical_system_type(value: Any) -> str:
    raw = norm_text(value)
    if raw in {"dell", "dell application", "internal", "application", "dell side", "dell owned"}:
        return "Dell Application"
    if raw in {"client", "customer", "partner", "external", "trading partner", "client side", "customer side", "partner side"}:
        return "Partner"
    return ""


def _role_system_ownership(values: Mapping[str, Any], role: str) -> Dict[str, Any]:
    """Derive systemType from the role-correct systemName using the V23 rule.

    Direction and ownership are still separate (Source=Sender, Target=Receiver),
    but ownership is no longer guessed from direction, U-HAUL, account names,
    partner names, or fuzzy tokens. Once a role-correct System/System Name exists:

      AIC - DCE -> Dell Application
      anything else -> Partner

    Explicit Excel System Type columns are retained as comparison evidence only.
    A conflicting explicit value is corrected by the governed name rule rather
    than being sent to the LIVE API.
    """
    role = "target" if str(role).lower().startswith("target") else "source"
    specific = (
        ("Source System Type", "Sender System Type", "Source Owner", "Sender Owner", "Source Party Type", "Sender Party Type", "Source Ownership", "Sender Ownership")
        if role == "source" else
        ("Target System Type", "Receiver System Type", "Target Owner", "Receiver Owner", "Target Party Type", "Receiver Party Type", "Target Ownership", "Receiver Ownership")
    )
    explicit_header, explicit_raw = _exact_value(values, *specific)
    explicit_type = _canonical_system_type(explicit_raw) if explicit_header else ""
    if not explicit_header:
        generic_header, generic_raw = _exact_value(values, "System Type", "System Owner", "System Ownership", "Party Type", "Owner Type")
        if generic_header:
            explicit_header, explicit_raw = generic_header, generic_raw
            explicit_type = _canonical_system_type(generic_raw)

    system_header, system_value = _role_system_value(values, role)
    if system_header and not blank(system_value):
        canonical = governed_system_type_for_name(system_value)
        mismatch = bool(explicit_header and explicit_type and explicit_type != canonical)
        explicit_note = (
            f" Excel {explicit_header}={display(explicit_raw)!r} conflicted with the governed systemName rule and was not used."
            if mismatch else
            (f" Excel {explicit_header} agrees with the governed rule." if explicit_header and explicit_type else "")
        )
        return {
            "resolved": True,
            "systemType": canonical,
            "sourceColumn": system_header,
            "rawValue": display(system_value),
            "method": "SYSTEM_NAME_GOVERNED_TYPE_RULE",
            "reason": f"systemType is deterministically derived from {system_header}: AIC - DCE => Dell Application; every other explicit systemName => Partner.{explicit_note}",
            "explicitOwnershipColumn": explicit_header,
            "explicitOwnershipValue": display(explicit_raw),
            "explicitOwnershipConflict": mismatch,
        }

    # No systemName means ownership cannot safely drive a LIVE TP. Keep any
    # explicit System Type only as review evidence; systemName provenance will
    # independently block staging until a real system identity exists.
    if explicit_header and explicit_type:
        return {
            "resolved": False,
            "systemType": explicit_type,
            "sourceColumn": explicit_header,
            "rawValue": display(explicit_raw),
            "method": "SYSTEM_NAME_REQUIRED_BEFORE_TYPE",
            "reason": "System Type was supplied, but systemName is missing. V23 requires a role-correct systemName before ownership is considered resolved.",
        }
    return {
        "resolved": False,
        "systemType": "Partner",
        "sourceColumn": "",
        "rawValue": "",
        "method": "SYSTEM_NAME_REQUIRED_BEFORE_TYPE",
        "reason": "No role-correct systemName exists. Supply System/System Name; then V23 derives Dell Application only for AIC - DCE and Partner for every other system.",
    }

def _field(values: Mapping[str, Any], *names: str) -> str:
    _, value = _value(values, *names)
    return display(value)


def _exact_field(values: Mapping[str, Any], *names: str) -> str:
    _, value = _exact_value(values, *names)
    return display(value)


def _hip_account(values: Mapping[str, Any]) -> str:
    # Avoid fuzzy generic "Account" matching (which produced values such as
    # Yes/Catalogues in V6). Only explicit HIP/account identity headers qualify.
    return _exact_field(values, "Hip Account names", "Hip Account name", "HIP Account", "Existing Account Name")


def _customer_label(values: Mapping[str, Any]) -> str:
    return _exact_field(values, "LENS TP Name", "Customer", "Customer Name", "Partner Name")


def _mapping_priority(header: str, path: str) -> int:
    h = norm_text(header)
    if "source interface type" in h or "target interface type" in h or h == "interface type": return 120
    if "source transport profile name" in h or "target transport profile name" in h: return 120
    if h == "transport profile name": return 118
    if "dev transport profile name" in h: return 112
    if "source system" in h or "target system" in h: return 108
    if "document type name" in h: return 106
    if "document type version" in h: return 104
    if "data format" in h: return 103
    if "lens tp name" in h: return 70
    return 90


def _contextual_tp_parameter_path(header: str, contract: Mapping[str, Any]) -> str:
    """Resolve grouped Excel headers that identify TP-specific parameters.

    Example: the source workbook has several columns named ``Account`` under
    different parent groups.  Only ``Add >Transport Profile Details > Account``
    is the FILE ``Existing Account Name``.
    """
    n = norm_text(header)
    paths = set(str(p) for p in contract.get("paths") or [])
    if "transport profile" in n and "account" in n and EXISTING_ACCOUNT_PATH in paths:
        return EXISTING_ACCOUNT_PATH
    if "transport profile" in n and "subscription folder" in n and SUBSCRIPTION_FOLDER_PATH in paths:
        return SUBSCRIPTION_FOLDER_PATH
    return ""


def _parameter_excel_value(values: Mapping[str, Any], path: str) -> Tuple[str, Any]:
    """Return only approved exact/contextual Excel evidence for sensitive FILE leaves."""
    if path == SUBSCRIPTION_FOLDER_PATH:
        header, value = _exact_value(values, "Subscription Folder", "TP Subscription Folder", "Transport Profile Subscription Folder")
        if header:
            return header, value
        for h, v in values.items():
            n = norm_text(h)
            if "transport profile" in n and "subscription folder" in n and not blank(v):
                return h, v
        return "", ""
    if path == EXISTING_ACCOUNT_PATH:
        header, value = _exact_value(values, "Existing Account Name", "TP Existing Account Name", "Transport Profile Account", "TP Account")
        if header:
            return header, value
        for h, v in values.items():
            n = norm_text(h)
            if "transport profile" in n and "account" in n and not blank(v):
                return h, v
        return "", ""
    return "", ""


def _strict_tp_column_map(headers: Sequence[str], values: Mapping[str, Any], contract: Mapping[str, Any], llm_hints: Mapping[Tuple[str, str], Mapping[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """TP-only mapper: approved exact aliases first, high-confidence LLM only as fallback.

    This intentionally avoids the generic fuzzy mapper because TP readiness must not
    become optimistic from unrelated workbook columns. Unknown fields remain evidence.
    """
    paths = set(str(p) for p in contract.get("paths") or [])
    # V11: contract-owned selectors/runtime leaves are never populated by Excel
    # aliases or Dell AIA hints.  Interface Type is re-injected below from the
    # authoritative Excel Interface Type cell after the interface contract has
    # already been selected.
    contract_owned = set(str(p) for p in (contract.get("locked_value_paths") or []))
    alias_lookup = {norm_text(k): v for k, v in (contract.get("header_aliases") or {}).items()}
    candidates: List[Tuple[int, str, str, Dict[str, Any]]] = []
    for header in headers:
        if blank(values.get(header)):
            continue
        target = alias_lookup.get(norm_text(header))
        if not target:
            target = _contextual_tp_parameter_path(header, contract)
        targets = [target] if isinstance(target, str) else target if isinstance(target, list) else []
        for path in targets:
            path = str(path)
            if path in paths and path not in contract_owned:
                candidates.append((_mapping_priority(header, path), header, path, {
                    "path": path, "confidence": 0.99, "method": "Approved TP Excel alias",
                    "reason": "Excel header exactly matches an approved TP field alias.",
                }))
                break
    candidates.sort(key=lambda x: x[0], reverse=True)
    out: Dict[str, Dict[str, Any]] = {}
    used: set[str] = set()
    for _, header, path, meta in candidates:
        if path in used:
            continue
        out[header] = meta; used.add(path)

    # LLM is advisory and only fills a still-unmapped approved leaf at very high confidence.
    for header in headers:
        if header in out or blank(values.get(header)):
            continue
        hint = llm_hints.get((str(contract.get("key") or ""), header))
        if not hint or float(hint.get("confidence") or 0) < 0.93:
            continue
        path = str(hint.get("path") or "")
        if path not in paths or path in used or path in contract_owned:
            continue
        # Core TP identity/provenance fields are never delegated to the LLM.
        # This prevents Directory→Subscription Folder, HIP Account→Existing
        # Account Name, LENS name→TP name, and similar optimistic mappings.
        if path in PROVENANCE_LOCKED_PATHS:
            continue
        out[header] = {
            "path": path, "confidence": round(float(hint.get("confidence") or 0), 3),
            "method": "Dell AIA high-confidence hint",
            "reason": str(hint.get("reason") or "High-confidence semantic match to an approved TP path")[:400],
        }
        used.add(path)
    return out


def _suggested_excel_columns(contract: Mapping[str, Any], path: str) -> List[str]:
    suggestions=[]
    for header, target in (contract.get("header_aliases") or {}).items():
        targets=[target] if isinstance(target,str) else target if isinstance(target,list) else []
        if path in [str(x) for x in targets]:
            suggestions.append(str(header))
    # Keep the report concise and stable.
    return suggestions[:6]


def _postprocess_v122_payload(row: Dict[str, Any], values: Mapping[str, Any]) -> None:
    """Normalize mapped values to the exact V122 TP request semantics.

    - split Document Type NAME(1.0) into documentTypeName + documentTypeVersion;
    - preserve an explicit Document Type Version column when supplied;
    - populate the fixed V122 customer/haftAccount tag values from workbook evidence.
    """
    payload = row.get("proposedRequest") or {}
    if not isinstance(payload, dict):
        return
    doc_name_path = "transportProfileDetails.0.documentTypeDetails.0.documentTypeName"
    doc_ver_path = "transportProfileDetails.0.documentTypeDetails.0.documentTypeVersion"
    doc_header, doc_raw = _exact_value(values, "Document Type Name", "Document Type")
    ver_header, ver_raw = _exact_value(values, "Document Type Version", "Doc Type Version")
    parsed_name = ""
    parsed_ver = ""
    if not blank(doc_raw):
        text = display(doc_raw).strip()
        match = re.match(r"^(.*?)\s*\(\s*([0-9]+(?:\.[0-9]+)*)\s*\)\s*$", text)
        if match:
            parsed_name = match.group(1).strip()
            parsed_ver = match.group(2).strip()
        else:
            parsed_name = text
    if parsed_name:
        write_path(payload, doc_name_path, parsed_name)
        existing = next((m for m in row.get("mappings") or [] if str(m.get("targetPath")) == doc_name_path), None)
        if existing:
            existing["mappedValue"] = parsed_name
            if parsed_ver:
                existing["method"] = "Approved TP Excel alias + V122 document name/version parser"
                existing["reason"] = "Document Type cell contained NAME(version); V122 sends name and version in separate fields."
    explicit_ver = display(ver_raw).strip() if not blank(ver_raw) else ""
    final_ver = explicit_ver or parsed_ver
    if final_ver:
        write_path(payload, doc_ver_path, final_ver)
        if not any(str(m.get("targetPath")) == doc_ver_path for m in row.get("mappings") or []):
            row.setdefault("mappings", []).append({
                "sourceColumn": ver_header or doc_header,
                "sourceValue": explicit_ver or display(doc_raw),
                "targetPath": doc_ver_path,
                "mappedValue": final_ver,
                "confidence": 1.0,
                "method": "Explicit document version" if explicit_ver else "Parsed V122 document version",
                "reason": "V122 Transport Profile orchestration requires documentTypeVersion as a separate field.",
            })
    # Hard provenance correction for FILE account/folder leaves.  Directory is
    # never Subscription Folder, and HIP Account is never Existing Account Name.
    for path in (SUBSCRIPTION_FOLDER_PATH, EXISTING_ACCOUNT_PATH):
        if read_path(payload, path) is None:
            continue
        header, raw_value = _parameter_excel_value(values, path)
        final_value = display(raw_value) if header and not blank(raw_value) else ""
        write_path(payload, path, final_value)
        # Remove any earlier mapping to this protected leaf and rebuild it only
        # from approved exact/contextual Excel evidence.
        row["mappings"] = [m for m in (row.get("mappings") or []) if str(m.get("targetPath")) != path]
        if header:
            row.setdefault("mappings", []).append({
                "sourceColumn": header,
                "sourceValue": raw_value,
                "targetPath": path,
                "mappedValue": final_value,
                "confidence": 1.0,
                "method": "Exact TP Excel provenance",
                "reason": "Mapped only from the explicit Transport Profile parameter field; semantic inference is disabled for this API leaf.",
            })

    # V122 reference always emits the two tags even when tag-change=false.
    detail = ((payload.get("transportProfileDetails") or [{}])[0]) if isinstance(payload, dict) else {}
    if isinstance(detail, dict):
        customer = _customer_label(values)
        params = (((detail.get("interfaceDetails") or [{}])[0]).get("parameters") or {}) if detail.get("interfaceDetails") else {}
        account = display(params.get("Existing Account Name")) if isinstance(params, dict) else ""
        tags = detail.get("tags")
        if isinstance(tags, list) and len(tags) >= 2:
            tags[0]["key"] = "customer"; tags[0]["value"] = customer
            tags[1]["key"] = "haftAccount"; tags[1]["value"] = account
    row["proposedRequest"] = payload
    row["mappedPaths"] = sorted({str(m.get("targetPath")) for m in row.get("mappings") or [] if m.get("targetPath")})
    row["mappedCount"] = len(row["mappedPaths"])


def _sync_row_to_final_contract(row: Dict[str, Any], contract: Mapping[str, Any], payload: Mapping[str, Any], conditional_findings: Sequence[Mapping[str, Any]]) -> None:
    """Replace the analyzed superset with the exact HTTP-boundary interface shape."""
    row["proposedRequest"] = deepcopy(payload)
    row["baseRequest"] = deepcopy(contract.get("canonical_request") or {})
    active_paths = set(str(p) for p in (contract.get("paths") or []))
    synced = []
    for m in row.get("mappings") or []:
        path = str(m.get("targetPath") or "")
        if path not in active_paths:
            continue
        mm = deepcopy(m)
        mm["mappedValue"] = read_path(payload, path)
        synced.append(mm)
    row["mappings"] = synced
    row["mappedPaths"] = sorted({str(m.get("targetPath")) for m in synced if m.get("targetPath")})
    row["mappedCount"] = len(row["mappedPaths"])
    row["interfaceConditionFindings"] = [dict(x) for x in (conditional_findings or [])]


def _reassess_after_postprocess(row: Dict[str, Any], contract: Mapping[str, Any]) -> None:
    """Recompute execution readiness after deterministic V122 value normalization.

    evaluate_row runs before the NAME(version) parser. V7 must therefore recompute
    required fields, identity, field rules, and status after the final payload has
    been normalized; otherwise a valid U-HAUL row can remain NEEDS_INPUT from a
    stale pre-normalization decision.
    """
    proposed = row.get("proposedRequest") or {}
    required = [str(p) for p in (contract.get("required_paths") or [])]
    identity = [str(p) for p in (contract.get("identity_paths") or [])]
    mapped_paths = [str(p) for p in (row.get("mappedPaths") or [])]
    missing = [p for p in required if blank(read_path(proposed, p))]
    structure_ok = schema_locked(contract.get("canonical_request") or {}, proposed)
    findings = validate_field_rules(proposed, contract) + list(row.get("interfaceConditionFindings") or []) + system_type_rule_findings(proposed)
    low = [m for m in (row.get("mappings") or []) if float(m.get("confidence") or 0) < 0.64]
    identity_from_excel = (not identity) or any(p in mapped_paths for p in identity)
    lifecycle = str(contract.get("lifecycle_status") or "APPROVED")

    warnings = [str(w) for w in (row.get("warnings") or [])]
    # Drop stale messages that can be made false by deterministic post-processing.
    warnings = [w for w in warnings if not w.startswith("API contract lifecycle is") and "field-rule" not in w.lower()]
    if not structure_ok:
        status = "DO_NOT_TRIGGER"
        if "Schema-lock violation detected" not in warnings:
            warnings.append("Schema-lock violation detected")
    elif lifecycle == "DEPRECATED":
        status = "DO_NOT_TRIGGER"
        if "API contract is DEPRECATED and cannot be recommended for new execution" not in warnings:
            warnings.append("API contract is DEPRECATED and cannot be recommended for new execution")
    elif not row.get("mappings"):
        status = "DO_NOT_TRIGGER"
        if "No workbook values could be mapped safely into this API" not in warnings:
            warnings.append("No workbook values could be mapped safely into this API")
    elif missing:
        status = "NEEDS_INPUT"
    elif lifecycle != "APPROVED":
        status = "NEEDS_INPUT"
        warnings.append(f"API contract lifecycle is {lifecycle}; APPROVED is required for a final trigger recommendation")
    elif findings:
        status = "NEEDS_INPUT"
        warnings.extend([str(f.get("message")) for f in findings[:8] if f.get("message")])
    elif not identity_from_excel:
        status = "NEEDS_INPUT"
        if "Object identity is inherited from the catalog template; map or confirm an identity value from this Excel row" not in warnings:
            warnings.append("Object identity is inherited from the catalog template; map or confirm an identity value from this Excel row")
    elif low:
        status = "NEEDS_INPUT"
        if "At least one mapping has low confidence and requires review" not in warnings:
            warnings.append("At least one mapping has low confidence and requires review")
    else:
        status = "GOOD_TO_TRIGGER"

    row["requiredPaths"] = required
    row["missingRequiredPaths"] = missing
    row["identityPaths"] = identity
    row["identityMappedFromExcel"] = identity_from_excel
    row["identityFingerprint"] = identity_fingerprint(contract, proposed)
    row["fieldRuleFindings"] = findings
    row["structureLocked"] = structure_ok
    row["status"] = status
    row["goodToTrigger"] = status == "GOOD_TO_TRIGGER"
    row["warnings"] = list(dict.fromkeys(warnings))


def _field_matrix(row: Mapping[str, Any], contract: Mapping[str, Any]) -> List[Dict[str, Any]]:
    proposed=row.get("proposedRequest") or {}
    base=contract.get("canonical_request") or {}
    mappings={str(m.get("targetPath")):m for m in row.get("mappings") or []}
    required=set(str(p) for p in contract.get("required_paths") or [])
    out=[]
    for path in contract.get("paths") or []:
        path=str(path); value=read_path(proposed,path); base_value=read_path(base,path); m=mappings.get(path)
        req=path in required
        if m:
            canonicalized = path.endswith(".interfaceType") and display(m.get("sourceValue")) != display(m.get("mappedValue"))
            source_type="EXCEL_CANONICALIZED" if canonicalized else "EXCEL"
            source_column=m.get("sourceColumn") or ""; source_value=m.get("sourceValue") or ""
            confidence=m.get("confidence"); method=m.get("method") or ""
        elif path == "requestedBy" and str(os.getenv("HIP_REQUESTED_BY") or "").strip():
            source_type="RUNTIME_ENV"; source_column="HIP_REQUESTED_BY"; source_value=os.getenv("HIP_REQUESTED_BY",""); confidence=1.0; method="V122 runtime"
        elif path == "hipEnvironment":
            source_type="RUNTIME_ENV"; source_column="HIP_ENVIRONMENT"; source_value=os.getenv("HIP_ENVIRONMENT", "DEV"); confidence=1.0; method="V122 runtime"
        elif path == "systemType":
            source_type="OWNERSHIP_DERIVED" if row.get("ownershipResolved") else "OWNERSHIP_REVIEW"
            source_column=row.get("ownershipSourceColumn") or "Human confirmation required"
            source_value=row.get("ownershipRawValue") or row.get("systemType") or display(value)
            confidence=1.0 if row.get("ownershipResolved") else None
            method=row.get("ownershipMethod") or "Sender/Receiver ownership is independent from TP direction"
        elif path.endswith(".transportProfileUsage"):
            source_type="ROLE_DERIVED"; source_column="TP role"; source_value=row.get("tpRole") or ""; confidence=1.0; method="Source=Sender / Target=Receiver; ownership is resolved separately"
        elif ".interfaceDetails.0.parameters." in path and not blank(value):
            source_type="INTERFACE_DEFAULT"; source_column="Approved interface contract"; source_value=display(value); confidence=1.0; method="V122 interface default"
        elif not blank(value):
            source_type="CONTRACT_FIXED"; source_column="Approved TP contract"; source_value=display(value); confidence=1.0; method="V122 canonical contract"
        elif req:
            source_type="MISSING_REQUIRED"; source_column=""; source_value=""; confidence=None; method="Required value missing"
        else:
            source_type="OPTIONAL_EMPTY"; source_column=""; source_value=""; confidence=None; method="Optional value not supplied"
        out.append({
            "path":path, "field":path.split(".")[-1], "required":req, "value":value, "baseValue":base_value,
            "sourceType":source_type, "sourceColumn":source_column, "sourceValue":source_value,
            "confidence":confidence, "method":method, "suggestedExcelColumns":_suggested_excel_columns(contract,path),
            "state":"MISSING" if req and blank(value) else ("OPTIONAL" if not req and blank(value) else "OK"),
        })
    return out


def _payload_completeness(row: Mapping[str, Any]) -> Dict[str, Any]:
    """Score actual payload value completeness.

    Blank/null/NaN-like values receive zero credit. Required leaves are weighted
    3x so a missing execution-critical value hurts the score more than a missing
    optional value. This score is deliberately independent of the trigger
    decision: GOOD_TO_TRIGGER means mandatory execution gates passed, not that
    every optional payload leaf was populated.
    """
    matrix = list(row.get("fieldMatrix") or [])
    total_weight = 0.0
    populated_weight = 0.0
    populated = 0
    blank_required = 0
    blank_optional = 0
    blank_fields: List[Dict[str, Any]] = []
    for item in matrix:
        required = bool(item.get("required"))
        weight = 3.0 if required else 1.0
        total_weight += weight
        value = item.get("value")
        if blank(value):
            if required:
                blank_required += 1
            else:
                blank_optional += 1
            blank_fields.append({
                "path": str(item.get("path") or ""),
                "field": str(item.get("field") or ""),
                "required": required,
                "sourceType": str(item.get("sourceType") or ""),
            })
        else:
            populated += 1
            populated_weight += weight
    score = int(round((populated_weight / total_weight) * 100)) if total_weight else 0
    return {
        "score": max(0, min(100, score)),
        "canonicalFieldCount": len(matrix),
        "populatedFieldCount": populated,
        "blankFieldCount": blank_required + blank_optional,
        "blankRequiredFieldCount": blank_required,
        "blankOptionalFieldCount": blank_optional,
        "blankFields": blank_fields,
        "weighting": "required=3x, optional=1x; blank/null/NaN/empty values=0 credit",
    }


def _refresh_readiness_diagnostics(row: Dict[str, Any]) -> None:
    missing=list(row.get("missingRequiredPaths") or [])
    contract=row.get("contractSnapshot") or {}
    friendly_missing=[]
    for path in missing:
        friendly_missing.append({"path":path,"field":str(path).split(".")[-1],"suggestedExcelColumns":_suggested_excel_columns(contract,str(path))})
    row["missingRequiredDetails"]=friendly_missing
    checks=[]
    def add(name:str, ok:bool, detail:str, blocking:bool=True, status_if_fail:str="FAIL"):
        checks.append({"name":name,"status":"PASS" if ok else status_if_fail,"detail":detail,"blocking":bool(blocking and not ok)})
    add("Interface provided in Excel", bool(row.get("interfaceProvidedByExcel")), f"{row.get('interfaceSourceColumn') or 'No Interface Type column'} = {row.get('interfaceRawValue') or 'blank'}")
    add("Interface recognized", bool(row.get("interfaceFamily") not in {"", "MISSING", "UNSUPPORTED"}), f"Excel {row.get('interfaceRawValue') or '—'} → API {row.get('interfaceType') or '—'}")
    add("TP role resolved", not bool(row.get("roleAmbiguous")), str(row.get("roleReason") or ""), blocking=True, status_if_fail="REVIEW")
    add(
        "Sender/Receiver system ownership resolved",
        bool(row.get("ownershipResolved")),
        f"{row.get('systemType') or '—'} · {row.get('ownershipReason') or 'Confirm Dell Application vs Client/Partner'}",
        blocking=True,
        status_if_fail="REVIEW",
    )
    type_rule = system_type_rule_record(row.get("proposedRequest") or {})
    add(
        "systemType matches governed systemName rule",
        bool(type_rule.get("passed")),
        f"systemName={type_rule.get('systemName') or '—'} → required systemType={type_rule.get('expectedSystemType') or '—'}; payload={type_rule.get('actualSystemType') or '—'}",
        blocking=True,
        status_if_fail="FAIL",
    )
    required_labels={
        "systemName":"System",
        TP_NAME_PATH:"transportProfileName",
        INTERFACE_TYPE_PATH:"Interface Type",
    }
    for path,label in required_labels.items():
        if path in (row.get("requiredPaths") or []):
            value=read_path(row.get("proposedRequest") or {},path)
            add(f"{label} mapped", not blank(value), f"{value if not blank(value) else 'Missing'}")
    doc_value = read_path(row.get("proposedRequest") or {}, DOC_NAME_PATH)
    checks.append({
        "name":"Document Type",
        "status":"PASS" if not blank(doc_value) else "MISSING_OPTIONAL",
        "detail":f"{doc_value}" if not blank(doc_value) else "Not supplied; kept empty by team rule. It does not block execution, but it lowers completeness score.",
        "blocking":False,
    })
    contract_paths = set(str(p) for p in contract.get("paths") or [])
    if SUBSCRIPTION_FOLDER_PATH in contract_paths:
        sub_map = next((m for m in row.get("mappings") or [] if str(m.get("targetPath")) == SUBSCRIPTION_FOLDER_PATH), None)
        sub_ok = not sub_map or norm_text(sub_map.get("sourceColumn")) != "directory"
        add("Subscription Folder provenance", sub_ok, "Directory is not used as Subscription Folder" if sub_ok else "Invalid provenance: Directory was mapped to Subscription Folder")
    if EXISTING_ACCOUNT_PATH in contract_paths:
        acct_map = next((m for m in row.get("mappings") or [] if str(m.get("targetPath")) == EXISTING_ACCOUNT_PATH), None)
        acct_source = norm_text(acct_map.get("sourceColumn")) if acct_map else ""
        acct_ok = not acct_map or "hip account" not in acct_source
        add("Existing Account Name provenance", acct_ok, "HIP Account is not used as Existing Account Name" if acct_ok else "Invalid provenance: HIP Account was mapped to Existing Account Name")
    param_missing=[p for p in missing if ".parameters." in str(p)]
    add("Required interface parameters", not param_missing, "All required interface parameters present" if not param_missing else "Missing: "+", ".join(str(p).split(".")[-1] for p in param_missing))
    add("Schema lock", bool(row.get("structureLocked")), "Payload attributes/nesting match the approved TP contract")
    findings=row.get("fieldRuleFindings") or []
    add("Field rules", not findings, "No field-rule violations" if not findings else "; ".join(str(x.get("message")) for x in findings[:3]))
    dup=bool(row.get("duplicateWorkbookIdentity"))
    add("Duplicate TP identity", not dup, "Unique in workbook" if not dup else "Also found at "+", ".join(row.get("duplicateWorkbookRows") or []), blocking=True, status_if_fail="REVIEW")
    low=[m for m in row.get("mappings") or [] if float(m.get("confidence") or 0)<0.90]
    add("Mapping confidence", not low, "All mappings are approved aliases / high confidence" if not low else f"{len(low)} mapping(s) require review", blocking=True, status_if_fail="REVIEW")

    completeness = _payload_completeness(row)
    blank_count = int(completeness["blankFieldCount"])
    checks.append({
        "name":"Payload value completeness",
        "status":"PASS" if blank_count == 0 else "INCOMPLETE",
        "detail":(
            f"{completeness['populatedFieldCount']}/{completeness['canonicalFieldCount']} canonical payload fields have values; "
            f"{completeness['blankRequiredFieldCount']} required and {completeness['blankOptionalFieldCount']} optional field(s) are blank/null. "
            "Blank/null values receive zero score credit."
        ),
        "blocking":False,
    })

    row["readinessChecks"]=checks
    blocking=[c for c in checks if c.get("blocking")]
    passed=len([c for c in checks if c.get("status")=="PASS"])
    row["failedCheckCount"]=len(blocking)
    row["passedCheckCount"]=passed
    row.update({k:v for k,v in completeness.items() if k != "score"})

    # V9: score is no longer forced to 100 for GOOD_TO_TRIGGER. Missing values
    # always reduce score. Status remains governed by mandatory hard checks.
    score = int(completeness["score"])
    if row.get("roleAmbiguous"):
        score -= 8
    if not row.get("ownershipResolved"):
        score -= 12
    score -= min(10, len(low) * 3)
    score -= min(16, len(findings) * 4)
    if not row.get("structureLocked"):
        score -= 25
    if row.get("status")=="NEEDS_INPUT":
        score=min(89, score)
    elif row.get("status")=="DO_NOT_TRIGGER":
        score=min(49, score)
    row["score"] = max(0, min(100, int(round(score))))
    row["completenessScore"] = int(completeness["score"])
    row["scoreBasis"] = "Payload value completeness: required fields weighted 3x, optional fields 1x; blank/null/NaN/empty values receive zero credit. Execution status is a separate hard-gate decision."

    if row.get("status")=="GOOD_TO_TRIGGER":
        if blank_count:
            reason=f"All mandatory execution checks passed; {blank_count} optional/null payload field(s) are not populated, so completeness score is {row['score']}/100."
        else:
            reason="All mandatory execution checks passed and all canonical payload values are populated."
    elif row.get("status")=="NEEDS_INPUT":
        reason="Input/review required: " + ("; ".join(c.get("detail") for c in blocking[:4]) if blocking else "review warnings")
    else:
        reason="Blocked: " + ("; ".join(c.get("detail") for c in blocking[:4]) if blocking else "; ".join(row.get("warnings") or [])[:500])
    row["decisionReason"]=reason

def _unmapped_details(row: Mapping[str, Any], values: Mapping[str, Any]) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    metadata_terms = ("application tracking", "lens tp", "hip account", "b2b", "biz input", "biz flow", "migration", "staging profile", "test profile", "action to take", "dell po", "data found")
    connectivity_terms = ("sftp server", "port", "directory", "authentication", "password", "private key", "contact", "sending account")
    for header in row.get("unmappedColumns") or []:
        value = display(values.get(header))
        n = norm_text(header)
        if any(x in n for x in metadata_terms):
            reason = "Reference/operational metadata; not an attribute in the approved TP Create payload."
            kind = "REFERENCE"
        elif any(x in n for x in connectivity_terms):
            reason = "Connectivity evidence is retained for review but is not injected into another TP field. In particular, Directory is never mapped to Subscription Folder."
            kind = "EVIDENCE_ONLY"
        else:
            reason = "No safe canonical TP payload path matched this Excel field; agent did not invent an attribute."
            kind = "UNMAPPED"
        rows.append({"column": str(header), "value": value, "classification": kind, "reason": reason})
    return rows


def _enrich(row: Dict[str, Any], values: Mapping[str, Any], *, sheet_name: str, role: str, role_ambiguous: bool, role_reason: str, interface_source: str, interface_raw: Any, contract: Mapping[str, Any], ownership: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    row["sheetName"] = sheet_name
    row["tpRole"] = "SOURCE / SENDER" if role == "source" else "TARGET / RECEIVER"
    row["tpRoleKey"] = role
    row["roleReason"] = role_reason
    row["roleAmbiguous"] = role_ambiguous
    own = dict(ownership or {})
    row["systemType"] = display((row.get("proposedRequest") or {}).get("systemType"))
    row["ownershipResolved"] = bool(own.get("resolved"))
    row["ownershipSourceColumn"] = str(own.get("sourceColumn") or "")
    row["ownershipRawValue"] = display(own.get("rawValue"))
    row["ownershipMethod"] = str(own.get("method") or "")
    row["ownershipReason"] = str(own.get("reason") or "")
    row["ownershipExplicitColumn"] = str(own.get("explicitOwnershipColumn") or "")
    row["ownershipExplicitValue"] = display(own.get("explicitOwnershipValue"))
    row["ownershipExplicitConflict"] = bool(own.get("explicitOwnershipConflict"))
    row["interfaceSourceColumn"] = interface_source
    row["interfaceRawValue"] = display(interface_raw)
    row["interfaceProvidedByExcel"] = bool(interface_source and not blank(interface_raw))
    row["interfaceInferenceUsed"] = False
    row["interfaceSelectionPolicy"] = "EXPLICIT_EXCEL_INTERFACE_TYPE_WITH_ADVISORY_REFERENCE_SUGGESTIONS"
    row["interfaceFamily"] = contract.get("interface_family")
    row["interfaceReference"] = contract.get("interface_reference")
    row["interfaceAlias"] = interface_alias_info(interface_raw)
    row["interfaceSuggestion"] = _reference_interface_suggestion(values, role, interface_raw)
    row["interfaceCanonicalized"] = display(interface_raw) != display(((row.get("proposedRequest") or {}).get("transportProfileDetails") or [{}])[0].get("interfaceDetails", [{}])[0].get("interfaceType", "")) if row.get("proposedRequest") else False
    payload = row.get("proposedRequest") or {}
    detail = ((payload.get("transportProfileDetails") or [{}])[0]) if isinstance(payload, dict) else {}
    iface = ((detail.get("interfaceDetails") or [{}])[0]) if isinstance(detail, dict) else {}
    doc = ((detail.get("documentTypeDetails") or [{}])[0]) if isinstance(detail, dict) else {}
    row["tpName"] = display(detail.get("transportProfileName"))
    row["systemName"] = display(payload.get("systemName")) if isinstance(payload, dict) else ""
    row["systemTypeRule"] = system_type_rule_record(payload if isinstance(payload, Mapping) else {})
    row["interfaceType"] = display(iface.get("interfaceType"))
    row["documentTypeName"] = display(doc.get("documentTypeName"))
    row["hipAccountName"] = _hip_account(values)
    row["customerName"] = _customer_label(values)
    row["applicationTracking"] = _exact_field(values, "Application Tracking")
    row["lensTpName"] = _exact_field(values, "LENS TP Name")
    row["unmappedDetails"] = _unmapped_details(row, values)
    row["contractSnapshot"] = {k: deepcopy(v) for k, v in contract.items()}
    if role_ambiguous and row.get("status") == "GOOD_TO_TRIGGER":
        row["status"] = "NEEDS_INPUT"; row["goodToTrigger"] = False; row["score"] = max(0, int(row.get("score") or 0) - 12)
        row.setdefault("warnings", []).append("Source/Target TP role is ambiguous. Confirm the role before LIVE execution.")
    if not row.get("ownershipResolved") and row.get("status") == "GOOD_TO_TRIGGER":
        row["status"] = "NEEDS_INPUT"; row["goodToTrigger"] = False
        row.setdefault("warnings", []).append("Sender/Receiver system ownership is not confirmed. Choose Dell Application or Client/Partner before LIVE execution.")
    # The API requires transportProfileName, not a DEV-prefixed Excel label.
    # DEV-Transport Profile Name remains only one accepted exact Excel alias.
    row["readinessLabel"] = "GOOD TO GO" if row.get("status") == "GOOD_TO_TRIGGER" else ("NEEDS INPUT" if row.get("status") == "NEEDS_INPUT" else "NOT READY")
    blockers = list(row.get("missingRequiredPaths") or []) + [f.get("message") for f in row.get("fieldRuleFindings") or []]
    if role_ambiguous: blockers.append("Confirm Source/Target TP role")
    row["blockers"] = [str(x) for x in blockers if x]
    row["fieldMatrix"] = _field_matrix(row, contract)
    _refresh_readiness_diagnostics(row)
    return row


def _unsupported(record: Mapping[str, Any], values: Mapping[str, Any], sheet_name: str, role: str, role_ambiguous: bool, role_reason: str, iface_header: str, iface_value: Any, message: str, *, missing_interface: bool = False) -> Dict[str, Any]:
    tp_header, tp = _tp_name(values)
    account = _hip_account(values) or _exact_field(values, "Application Tracking") or _customer_label(values) or display(tp) or f"Row {record.get('excelRow')}"
    suggestion = _reference_interface_suggestion(values, role, iface_value)
    return {
        "excelRow": int(record.get("excelRow") or 0), "sheetName": sheet_name, "account": account, "recordLabel": f"{sheet_name}!{record.get('excelRow')}",
        "apiKey": "source_tp" if role == "source" else "target_tp", "apiName": "Source TP orchestration create ONLY" if role == "source" else "Target TP orchestration create ONLY",
        "group":"Transport Profile", "method":"POST", "url":"", "requestKind":"payload", "status":"NEEDS_INPUT" if missing_interface else "DO_NOT_TRIGGER", "goodToTrigger":False, "readinessLabel":"NEEDS INPUT" if missing_interface else "NOT READY", "score":15 if missing_interface else 0,
        "mappings":[], "mappedCount":0, "mappedPaths":[], "requiredPaths":[], "missingRequiredPaths":["Supported interface type"], "identityPaths":[], "identityMappedFromExcel":False, "identityFingerprint":"",
        "fieldRuleFindings":[], "warnings":[message], "unmappedColumns":[h for h,v in values.items() if not blank(v)], "unmappedDetails":[], "baseRequest":{}, "proposedRequest":{}, "structureLocked":True,
        "tpRole":"SOURCE / SENDER" if role == "source" else "TARGET / RECEIVER", "tpRoleKey":role, "roleAmbiguous":role_ambiguous, "roleReason":role_reason,
        "interfaceSourceColumn":iface_header, "interfaceRawValue":display(iface_value), "interfaceProvidedByExcel":bool(iface_header and not blank(iface_value)), "interfaceInferenceUsed":False, "interfaceSelectionPolicy":"EXPLICIT_EXCEL_INTERFACE_TYPE_WITH_ADVISORY_REFERENCE_SUGGESTIONS", "interfaceFamily":"MISSING" if missing_interface else "UNSUPPORTED", "interfaceReference":"Interface is selected only from an explicit Excel Interface Type cell; AI/reference suggestions are advisory and never auto-mutate the contract", "interfaceSuggestion": suggestion,
        "tpName":display(tp), "systemName":"", "interfaceType":display(iface_value), "documentTypeName":_exact_field(values,"Document Type Name"), "hipAccountName":_hip_account(values), "customerName":_customer_label(values),
        "applicationTracking":_exact_field(values,"Application Tracking"), "lensTpName":_exact_field(values,"LENS TP Name"), "blockers":[message], "contractSnapshot":{},
        "fieldMatrix": [], "missingRequiredDetails": [{"path":"transportProfileDetails.0.interfaceDetails.0.interfaceType","field":"interfaceType","suggestedExcelColumns":["Source Interface Type" if role=="source" else "Target Interface Type","Interface Type"]}],
        "readinessChecks": [
            {"name":"Interface provided in Excel","status":"PASS" if (iface_header and not blank(iface_value)) else "FAIL","detail":f"{iface_header or 'No Interface Type column'} = {display(iface_value) or 'blank'}","blocking":not bool(iface_header and not blank(iface_value))},
            {"name":"Interface recognized","status":"FAIL","detail":message,"blocking":True},
            {"name":"TP role resolved","status":"REVIEW" if role_ambiguous else "PASS","detail":role_reason,"blocking":bool(role_ambiguous)},
        ],
        "failedCheckCount": 1 + int(not bool(iface_header and not blank(iface_value))) + int(bool(role_ambiguous)),
        "passedCheckCount": int(bool(iface_header and not blank(iface_value))) + int(not role_ambiguous),
        "decisionReason": message,
    }


def rebuild_action_ownership(action: Mapping[str, Any], base_contract: Mapping[str, Any], system_type: Any) -> Dict[str, Any]:
    """Rebuild one analyzed TP using a human-confirmed system owner.

    This is the safe way to support both Sender=Dell/Receiver=Client and
    Sender=Client/Receiver=Dell.  It rebuilds the approved interface contract
    before staging; it never mutates a staged contract in place.
    """
    canonical = _canonical_system_type(system_type)
    if not canonical:
        raise ValueError("System ownership must be Dell Application or Client/Partner")
    governed_name = display((action.get("proposedRequest") or {}).get("systemName"))
    governed_type = governed_system_type_for_name(governed_name)
    if governed_type and canonical != governed_type:
        raise ValueError(f"SYSTEM_TYPE_SYSTEM_NAME_LOCK: systemName {governed_name!r} requires systemType {governed_type!r}; manual ownership {canonical!r} is not allowed")
    role = "target" if str(action.get("tpRoleKey") or "").lower().startswith("target") else "source"
    interface_type = str(action.get("interfaceType") or read_path(action.get("proposedRequest") or {}, INTERFACE_TYPE_PATH) or "").strip()
    if not interface_type:
        raise ValueError("Interface Type is missing; choose an interface from Excel before ownership can be rebuilt")

    new_contract = dynamic_tp_contract(base_contract, role, interface_type, system_type=canonical)
    new_payload = deepcopy(new_contract.get("canonical_request") or {})
    old_payload = action.get("proposedRequest") or {}
    old_contract = action.get("contractSnapshot") or {}
    old_paths = set(str(x) for x in (old_contract.get("paths") or []))
    locked = set(str(x) for x in (new_contract.get("locked_value_paths") or []))
    for path in (new_contract.get("paths") or []):
        path = str(path)
        if path in locked or path == SYSTEM_TYPE_PATH or path not in old_paths:
            continue
        try:
            write_path(new_payload, path, deepcopy(read_path(old_payload, path)))
        except Exception:
            continue

    exact_contract, exact_payload, conditional_findings = finalize_tp_contract(new_contract, new_payload)
    # Preserve the analyzed repeatable Document Type collection when ownership
    # is confirmed/rebuilt before staging. Ownership changes contract selectors;
    # they must never collapse a multi-document TP back to one document.
    old_docs = _document_details(old_payload)
    if len(old_docs) > 1:
        exact_contract, exact_payload = _materialize_document_cardinality(exact_contract, exact_payload, old_docs)
    row = deepcopy(dict(action))
    _sync_row_to_final_contract(row, exact_contract, exact_payload, conditional_findings)
    row["interfaceConditionFindings"] = list(row.get("interfaceConditionFindings") or []) + validate_interface_payload(exact_payload, exact_contract)
    _reassess_after_postprocess(row, exact_contract)
    row["contractSnapshot"] = deepcopy(exact_contract)
    row["systemType"] = canonical
    row["ownershipResolved"] = True
    row["ownershipSourceColumn"] = "Human ownership override"
    row["ownershipRawValue"] = str(system_type)
    row["ownershipMethod"] = "HUMAN_CONFIRMED_OWNERSHIP_REBUILD"
    row["ownershipReason"] = f"Human confirmed that the {'Sender' if role == 'source' else 'Receiver'} system is {canonical}."
    row["warnings"] = [
        str(w) for w in (row.get("warnings") or [])
        if "ownership" not in str(w).lower() and "sender/receiver system" not in str(w).lower()
    ]
    _set_document_summary(row)
    row["fieldMatrix"] = _field_matrix(row, exact_contract)
    _refresh_readiness_diagnostics(row)
    return row



def rebuild_action_values(action: Mapping[str, Any], payload: Mapping[str, Any]) -> Dict[str, Any]:
    """Persist human value-only corrections into an analyzed TP and revalidate it.

    The selected interface schema, role selectors, ownership selector and other
    contract-owned values remain immutable.  This is intentionally different
    from staging: it updates only the analysis candidate, reruns readiness, and
    lets a previously NEEDS_INPUT row become GOOD_TO_TRIGGER when the human has
    supplied the missing values.  A later Stage freezes a new immutable snapshot.
    """
    snapshot = action.get("contractSnapshot") if isinstance(action.get("contractSnapshot"), dict) else None
    if not snapshot:
        raise ValueError("The selected TP has no immutable interface contract snapshot")
    contract = normalize_contract(snapshot)
    candidate = deepcopy(dict(payload or {}))
    canonical = contract.get("canonical_request") or {}
    if not schema_locked(canonical, candidate):
        raise ValueError("API attributes/nesting/cardinality changed. Only existing leaf values may be edited")
    if not schema_locked(action.get("baseRequest") or canonical, candidate):
        raise ValueError("Payload no longer matches the analyzed API schema")

    old_payload = deepcopy(action.get("proposedRequest") or {})
    old_system_name = display(old_payload.get("systemName"))
    new_system_name = display(candidate.get("systemName"))
    old_system_type = display(canonical.get("systemType"))
    candidate_system_type = display(candidate.get("systemType"))
    if candidate_system_type != old_system_type:
        raise ValueError("CONTRACT_OWNED_VALUE_LOCK: systemType is not directly editable; it is derived from systemName")
    governed_type = governed_system_type_for_name(new_system_name)
    if new_system_name != old_system_name and governed_type and governed_type != old_system_type:
        # Human changed systemName. Rebuild the immutable contract-owned systemType
        # deterministically from the new identity before validating/staging.
        contract_raw = deepcopy(contract)
        contract_raw["canonical_request"]["systemType"] = governed_type
        contract = normalize_contract(contract_raw)
        canonical = contract.get("canonical_request") or {}
        candidate["systemType"] = governed_type
    locked_findings = validate_locked_values(candidate, contract)
    if locked_findings:
        raise ValueError("CONTRACT_OWNED_VALUE_LOCK: " + " | ".join(str(x.get("message") or x) for x in locked_findings))
    type_findings = system_type_rule_findings(candidate)
    if type_findings:
        raise ValueError("SYSTEM_TYPE_SYSTEM_NAME_LOCK: " + " | ".join(str(x.get("message") or x) for x in type_findings))

    changed_paths: List[str] = []
    for path in contract.get("paths") or []:
        path = str(path)
        if read_path(old_payload, path) != read_path(candidate, path):
            changed_paths.append(path)

    row = deepcopy(dict(action))
    row["proposedRequest"] = candidate
    row["baseRequest"] = deepcopy(canonical)
    row["contractSnapshot"] = deepcopy(contract)

    # Human edits are first-class provenance.  This also makes an edited identity
    # field count as explicitly confirmed instead of remaining template-derived.
    mappings = [deepcopy(m) for m in (row.get("mappings") or [])]
    by_path = {str(m.get("targetPath") or ""): i for i, m in enumerate(mappings)}
    for path in changed_paths:
        new_value = deepcopy(read_path(candidate, path))
        previous = deepcopy(read_path(old_payload, path))
        evidence = {
            "sourceColumn": "Human value editor",
            "sourceValue": new_value,
            "targetPath": path,
            "mappedValue": new_value,
            "confidence": 1.0,
            "method": "HUMAN_CONFIRMED_VALUE_EDIT",
            "reason": "Human corrected an existing TP value; contract attributes and locked selectors were unchanged.",
            "previousValue": previous,
        }
        if path in by_path:
            old = mappings[by_path[path]]
            evidence["overrodeSourceColumn"] = old.get("sourceColumn")
            evidence["overrodeMethod"] = old.get("method")
            mappings[by_path[path]] = evidence
        else:
            by_path[path] = len(mappings)
            mappings.append(evidence)
    row["mappings"] = mappings
    row["mappedPaths"] = sorted({str(m.get("targetPath")) for m in mappings if m.get("targetPath")})
    row["mappedCount"] = len(row["mappedPaths"])
    row["humanValueEditPaths"] = sorted(set(str(x) for x in (row.get("humanValueEditPaths") or [])) | set(changed_paths))
    row["humanValueEditCount"] = len(row["humanValueEditPaths"])

    row["interfaceConditionFindings"] = validate_interface_payload(candidate, contract)
    _reassess_after_postprocess(row, contract)

    # Direction/ownership remain separate hard gates after value revalidation.
    if row.get("roleAmbiguous") and row.get("status") == "GOOD_TO_TRIGGER":
        row["status"] = "NEEDS_INPUT"
        row["goodToTrigger"] = False
        row.setdefault("warnings", []).append("Source/Target TP role is ambiguous. Confirm the role before LIVE execution.")
    if not row.get("ownershipResolved") and row.get("status") == "GOOD_TO_TRIGGER":
        row["status"] = "NEEDS_INPUT"
        row["goodToTrigger"] = False
        row.setdefault("warnings", []).append("Sender/Receiver system ownership is not confirmed. Choose Dell Application or Client/Partner before LIVE execution.")

    detail = ((candidate.get("transportProfileDetails") or [{}])[0]) if isinstance(candidate, dict) else {}
    iface = ((detail.get("interfaceDetails") or [{}])[0]) if isinstance(detail, dict) else {}
    doc = ((detail.get("documentTypeDetails") or [{}])[0]) if isinstance(detail, dict) else {}
    row["systemName"] = display(candidate.get("systemName")) if isinstance(candidate, dict) else ""
    row["systemType"] = display(candidate.get("systemType")) if isinstance(candidate, dict) else ""
    row["systemTypeRule"] = system_type_rule_record(candidate)
    if row["systemName"]:
        row["ownershipResolved"] = True
        row["ownershipSourceColumn"] = "systemName"
        row["ownershipRawValue"] = row["systemName"]
        row["ownershipMethod"] = "SYSTEM_NAME_GOVERNED_TYPE_RULE"
        row["ownershipReason"] = f"V23 governed rule derived {row['systemType']} from systemName {row['systemName']!r}."
    row["tpName"] = display(detail.get("transportProfileName")) if isinstance(detail, dict) else ""
    row["interfaceType"] = display(iface.get("interfaceType")) if isinstance(iface, dict) else ""
    row["documentTypeName"] = display(doc.get("documentTypeName")) if isinstance(doc, dict) else ""
    _set_document_summary(row)
    row["readinessLabel"] = "GOOD TO GO" if row.get("status") == "GOOD_TO_TRIGGER" else ("NEEDS INPUT" if row.get("status") == "NEEDS_INPUT" else "NOT READY")
    blockers = list(row.get("missingRequiredPaths") or []) + [f.get("message") for f in row.get("fieldRuleFindings") or []]
    if row.get("roleAmbiguous"):
        blockers.append("Confirm Source/Target TP role")
    if not row.get("ownershipResolved"):
        blockers.append("Confirm Sender/Receiver ownership: Dell Application or Client/Partner")
    row["blockers"] = [str(x) for x in blockers if x]
    row["fieldMatrix"] = _field_matrix(row, contract)
    row["systemNameProvenance"] = system_name_provenance(row, candidate)
    row["systemNameProvenanceFindings"] = system_name_provenance_findings(row, candidate)
    _refresh_readiness_diagnostics(row)
    return row

def _document_details(payload: Mapping[str, Any]) -> List[Dict[str, Any]]:
    try:
        detail = (payload.get("transportProfileDetails") or [])[0]
        docs = detail.get("documentTypeDetails") or []
    except Exception:
        return []
    return [deepcopy(x) for x in docs if isinstance(x, dict)]


def _document_is_meaningful(doc: Mapping[str, Any]) -> bool:
    # dataFormatType has an approved XML default, so format alone is not enough
    # evidence that Excel actually supplied a Document Type row.
    return not blank(doc.get("documentTypeName")) or not blank(doc.get("documentTypeVersion"))


def _payload_without_document_details(payload: Mapping[str, Any]) -> Dict[str, Any]:
    """Return the TP payload identity/body excluding the repeatable document array."""
    body = deepcopy(dict(payload or {}))
    try:
        body["transportProfileDetails"][0]["documentTypeDetails"] = []
    except Exception:
        pass
    return body


def _materialize_document_cardinality(
    contract: Mapping[str, Any], payload: Mapping[str, Any], documents: Sequence[Mapping[str, Any]]
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Create an immutable per-action contract with the exact document array size.

    ``documentTypeDetails`` is the one intentionally repeatable TP collection.
    The global attribute lock still applies to every object key/nesting level and
    to all other arrays.  By expanding the analyzed contract snapshot itself, the
    later Stage -> Preflight -> LIVE boundary remains schema-locked even when one
    TP legitimately carries multiple document type dictionaries.
    """
    raw = deepcopy(dict(contract))
    canonical = deepcopy(raw.get("canonical_request") or {})
    cdetail = ((canonical.get("transportProfileDetails") or [{}])[0]) if isinstance(canonical, dict) else {}
    template_docs = cdetail.get("documentTypeDetails") or [{}]
    template = deepcopy(template_docs[0] if template_docs and isinstance(template_docs[0], dict) else {})
    if not template:
        raise ValueError("TP contract has no documentTypeDetails template")

    final_docs: List[Dict[str, Any]] = []
    for item in documents:
        doc = deepcopy(dict(item or {}))
        if set(doc.keys()) != set(template.keys()):
            raise ValueError("documentTypeDetails attributes changed; only repeated dictionaries with the approved keys are allowed")
        if any(isinstance(doc.get(k), (dict, list)) for k in doc):
            raise ValueError("documentTypeDetails leaf values must remain scalar")
        final_docs.append(doc)
    if not final_docs:
        final_docs = [deepcopy(template)]

    cdetail["documentTypeDetails"] = [deepcopy(template) for _ in final_docs]
    candidate = deepcopy(dict(payload or {}))
    pdetail = ((candidate.get("transportProfileDetails") or [{}])[0]) if isinstance(candidate, dict) else {}
    pdetail["documentTypeDetails"] = final_docs
    raw["canonical_request"] = canonical
    return normalize_contract(raw), candidate


def _document_mappings_for_index(row: Mapping[str, Any], index: int) -> List[Dict[str, Any]]:
    prefix = "transportProfileDetails.0.documentTypeDetails.0."
    target_prefix = f"transportProfileDetails.0.documentTypeDetails.{index}."
    out: List[Dict[str, Any]] = []
    for mapping in row.get("mappings") or []:
        path = str(mapping.get("targetPath") or "")
        if not path.startswith(prefix):
            continue
        copied = deepcopy(mapping)
        copied["targetPath"] = target_prefix + path[len(prefix):]
        out.append(copied)
    return out


def _set_document_summary(row: Dict[str, Any]) -> None:
    docs = _document_details(row.get("proposedRequest") or {})
    names = [display(d.get("documentTypeName")) for d in docs if not blank(d.get("documentTypeName"))]
    row["documentTypeCount"] = len(docs) if names or any(_document_is_meaningful(d) for d in docs) else 0
    row["documentTypeNames"] = names
    row["documentTypeName"] = ", ".join(names)


def _consolidate_duplicate_evidence(actions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Consolidate workbook rows for the same TP, including repeatable documents.

    V19 rule:
      * same TP identity + same non-document payload + different Document Type
        evidence => ONE TP action with N dictionaries in documentTypeDetails;
      * exact duplicate rows => merge evidence only;
      * any conflict outside documentTypeDetails => keep the rows separate and
        require review exactly as before.
    """
    groups: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    passthrough: List[Dict[str, Any]] = []
    for row in actions:
        ident = str(row.get("identityFingerprint") or "")
        if not ident:
            passthrough.append(row)
            continue
        groups.setdefault((str(row.get("apiKey") or ""), ident), []).append(row)

    merged: List[Dict[str, Any]] = list(passthrough)
    for group in groups.values():
        if len(group) == 1:
            group[0]["duplicateWorkbookIdentity"] = False
            group[0]["duplicateWorkbookRows"] = []
            _set_document_summary(group[0])
            merged.append(group[0])
            continue

        labels = [f"{x.get('sheetName')}!{x.get('excelRow')}" for x in group]
        payload_groups: Dict[str, List[Dict[str, Any]]] = {}
        for row in group:
            payload_groups.setdefault(fingerprint(row.get("proposedRequest") or {}), []).append(row)

        if len(payload_groups) == 1:
            canonical = group[0]
            canonical["duplicateWorkbookIdentity"] = False
            canonical["duplicateWorkbookRows"] = []
            canonical["evidenceRows"] = labels
            canonical["mergedDuplicateEvidenceCount"] = len(group) - 1
            canonical.setdefault("warnings", []).append(
                f"Merged {len(group)} identical workbook evidence rows for the same TP identity: " + ", ".join(labels)
            )
            _set_document_summary(canonical)
            merged.append(canonical)
            continue

        # Different payload fingerprints are allowed only when ALL differences
        # are confined to documentTypeDetails. This is the backend-supported
        # repeated-array case shown by the Dell team.
        non_doc_groups: Dict[str, List[Dict[str, Any]]] = {}
        for row in group:
            non_doc_groups.setdefault(fingerprint(_payload_without_document_details(row.get("proposedRequest") or {})), []).append(row)

        if len(non_doc_groups) == 1:
            canonical = deepcopy(group[0])
            unique_docs: List[Dict[str, Any]] = []
            doc_sources: List[Dict[str, Any]] = []
            seen_docs: set[str] = set()
            for source_row in group:
                for doc in _document_details(source_row.get("proposedRequest") or {}):
                    if not _document_is_meaningful(doc):
                        continue
                    key = fingerprint(doc)
                    if key in seen_docs:
                        continue
                    seen_docs.add(key)
                    unique_docs.append(doc)
                    doc_sources.append(source_row)

            # If every row omitted Document Type, preserve the standard one-item
            # empty template rather than manufacturing multiple empty entries.
            if not unique_docs:
                unique_docs = _document_details(canonical.get("proposedRequest") or {})[:1]
                doc_sources = [group[0]] if unique_docs else []

            snapshot = canonical.get("contractSnapshot") or {}
            expanded_contract, expanded_payload = _materialize_document_cardinality(
                snapshot, canonical.get("proposedRequest") or {}, unique_docs
            )
            canonical["proposedRequest"] = expanded_payload
            canonical["baseRequest"] = deepcopy(expanded_contract.get("canonical_request") or {})
            canonical["contractSnapshot"] = deepcopy(expanded_contract)

            # Keep non-document evidence from the first canonical row and map
            # each Excel Document Type row into its matching array index.
            doc_prefix = "transportProfileDetails.0.documentTypeDetails."
            mappings = [deepcopy(m) for m in (canonical.get("mappings") or []) if doc_prefix not in str(m.get("targetPath") or "")]
            for index, source_row in enumerate(doc_sources):
                mappings.extend(_document_mappings_for_index(source_row, index))
            canonical["mappings"] = mappings
            canonical["mappedPaths"] = sorted({str(m.get("targetPath")) for m in mappings if m.get("targetPath")})
            canonical["mappedCount"] = len(canonical["mappedPaths"])

            _reassess_after_postprocess(canonical, expanded_contract)
            if canonical.get("roleAmbiguous") and canonical.get("status") == "GOOD_TO_TRIGGER":
                canonical["status"] = "NEEDS_INPUT"
                canonical["goodToTrigger"] = False
            if not canonical.get("ownershipResolved") and canonical.get("status") == "GOOD_TO_TRIGGER":
                canonical["status"] = "NEEDS_INPUT"
                canonical["goodToTrigger"] = False

            canonical["duplicateWorkbookIdentity"] = False
            canonical["duplicateWorkbookRows"] = []
            canonical["evidenceRows"] = labels
            canonical["documentTypeEvidenceRows"] = labels
            canonical["mergedDuplicateEvidenceCount"] = len(group) - 1
            canonical["mergedDocumentTypeRows"] = len(group)
            canonical.setdefault("warnings", []).append(
                f"Merged {len(group)} workbook rows for the same TP into one payload with {len(unique_docs)} documentTypeDetails entr{'y' if len(unique_docs) == 1 else 'ies'}: " + ", ".join(labels)
            )
            _set_document_summary(canonical)
            canonical["fieldMatrix"] = _field_matrix(canonical, expanded_contract)
            _refresh_readiness_diagnostics(canonical)
            canonical["readinessLabel"] = "GOOD TO GO" if canonical.get("status") == "GOOD_TO_TRIGGER" else ("NEEDS INPUT" if canonical.get("status") == "NEEDS_INPUT" else "NOT READY")
            canonical["blockers"] = [str(x) for x in (canonical.get("missingRequiredPaths") or [])]
            if canonical.get("roleAmbiguous"):
                canonical["blockers"].append("Confirm Source/Target TP role")
            if not canonical.get("ownershipResolved"):
                canonical["blockers"].append("Confirm Sender/Receiver ownership: Dell Application or Client/Partner")
            merged.append(canonical)
            continue

        # A same-identity difference outside Document Type is a real conflict.
        for row in group:
            row["duplicateWorkbookIdentity"] = True
            row["duplicateWorkbookRows"] = labels
            row["conflictingDuplicateIdentity"] = True
            row.setdefault("warnings", []).append("Conflicting payload values exist for the same TP identity at " + ", ".join(labels))
            if row.get("status") == "GOOD_TO_TRIGGER":
                row["status"] = "NEEDS_INPUT"
                row["goodToTrigger"] = False
                row["readinessLabel"] = "NEEDS INPUT"
            row.setdefault("blockers", []).append("Conflicting duplicate TP identity in workbook")
            _set_document_summary(row)
            merged.append(row)
    return merged

_TEMPLATE_NON_EXECUTION_SHEETS = {
    "readme", "interface matrix", "field guide", "allowed values", "dummy examples",
}


def _template_sheet_key(name: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(name or "").casefold()).strip()


def analyze_tp_workbook(*, filename: str, data: bytes, contracts: Sequence[Mapping[str, Any]], scope: str="BOTH", requested_sheet: str="", header_row: int=0, use_llm: bool=True, scan_all_sheets: bool=True) -> Dict[str, Any]:
    bases = {c["key"]: deepcopy(c) for c in contracts if c.get("key") in TP_KEYS}
    if "source_tp" not in bases or "target_tp" not in bases:
        raise ValueError("The API catalog must contain both source_tp and target_tp V122 Transport Profile Create contracts")
    workbook = read_workbook(filename, data)
    prepared = []
    ignored_template_sheets: List[str] = []
    for sheet in workbook.get("sheets") or []:
        sheet_name = str(sheet.get("name") or "")
        if requested_sheet and sheet_name != requested_sheet:
            continue
        # The universal team workbook intentionally carries reference and DUMMY
        # sheets. Never scan those as execution input unless a human explicitly
        # requests that exact sheet. This prevents safe examples from becoming
        # accidental LIVE Transport Profile candidates.
        if not requested_sheet and _template_sheet_key(sheet_name) in _TEMPLATE_NON_EXECUTION_SHEETS:
            ignored_template_sheets.append(sheet_name)
            continue
        rows = sheet.get("rows") or []
        if not rows: continue
        idx = max(0, header_row-1) if header_row else detect_header(rows)
        headers, records = headers_and_records(rows, idx)
        score = _tp_sheet_score(headers)
        if requested_sheet or not scan_all_sheets or score >= 6:
            prepared.append((sheet, idx, headers, records, score))
            if not scan_all_sheets and not requested_sheet: break
    if requested_sheet and not prepared: raise ValueError(f"Worksheet {requested_sheet!r} was not found or has no data")
    if not prepared:
        raise ValueError("No Transport Profile worksheet was detected. Expected TP/interface/system/document/account columns")

    all_headers: List[str] = []
    samples: List[Mapping[str, Any]] = []
    for _,_,headers,records,_ in prepared:
        for h in headers:
            if h not in all_headers: all_headers.append(h)
        samples.extend([r["values"] for r in records[:3]])
    supersets = [superset_tp_contract(bases["source_tp"],"source"), superset_tp_contract(bases["target_tp"],"target")]
    llm = run_agents(all_headers, samples[:8], supersets, use_llm)

    actions: List[Dict[str, Any]] = []
    sheet_meta=[]
    for sheet, idx, headers, records, score in prepared:
        sheet_name=str(sheet.get("name") or "Sheet")
        sheet_meta.append({"name":sheet_name,"headerRow":idx+1,"columnCount":len(headers),"dataRowCount":len(records),"tpScore":score})
        for record in records:
            values=record.get("values") or {}
            roles, ambiguous, role_reason = _role_candidates(values, scope)
            for role in roles:
                iface_header, iface_value = _interface_value(values, role)
                if blank(iface_value):
                    actions.append(_unsupported(record, values, sheet_name, role, ambiguous, role_reason, iface_header, iface_value, "Explicit Excel Interface Type is missing. Provide Source Interface Type / Target Interface Type (or exact Interface Type). The agent will not infer it from any other Excel field.", missing_interface=True)); continue
                family=interface_family(iface_value)
                if not family:
                    actions.append(_unsupported(record, values, sheet_name, role, ambiguous, role_reason, iface_header, iface_value, f"Interface type {display(iface_value)!r} is not registered in the V122 dev-approved TP interface catalog.")); continue
                base=bases["source_tp" if role=="source" else "target_tp"]
                ownership = _role_system_ownership(values, role)
                contract=dynamic_tp_contract(base, role, iface_value, system_type=ownership.get("systemType"))
                hints=validated_llm_hints(llm, headers, {contract["key"]:contract})
                cmap=_strict_tp_column_map(headers, values, contract, hints)
                # V16 hard system provenance lock: Source and Target TP systemName
                # can never cross-map each other.
                cmap, system_header, system_value = _lock_role_system_mapping(cmap, values, role)
                # Hard interface lock: interface contract selection and the interfaceType
                # payload leaf are sourced only from the explicit Excel interface cell.
                interface_path = "transportProfileDetails.0.interfaceDetails.0.interfaceType"
                cmap = {h: meta for h, meta in cmap.items() if str(meta.get("path")) != interface_path}
                cmap[iface_header] = {
                    "path": interface_path,
                    "confidence": 1.0,
                    "method": "Explicit Excel interface lock",
                    "reason": "Interface Type was explicitly provided in Excel; inference is disabled.",
                }
                row=evaluate_row(record, contract, cmap)
                _postprocess_v122_payload(row, values)
                exact_contract, exact_payload, conditional_findings = finalize_tp_contract(contract, row.get("proposedRequest") or {})
                _sync_row_to_final_contract(row, exact_contract, exact_payload, conditional_findings)
                # Re-run conditional validation on the exact shape used for staging/LIVE.
                row["interfaceConditionFindings"] = list(row.get("interfaceConditionFindings") or []) + validate_interface_payload(exact_payload, exact_contract)
                _reassess_after_postprocess(row, exact_contract)
                row=_enrich(row, values, sheet_name=sheet_name, role=role, role_ambiguous=ambiguous, role_reason=role_reason, interface_source=iface_header, interface_raw=iface_value, contract=exact_contract, ownership=ownership)
                row["systemSourceColumn"] = system_header
                row["systemSourceValue"] = display(system_value)
                row["systemRawValue"] = display(system_value)  # backward-compatible alias
                row["systemProvenancePolicy"] = "ROLE_LOCKED_EXCEL_SYSTEM_NO_AUTO_SUBSTITUTION"
                row["systemNameProvenance"] = system_name_provenance(row, row.get("proposedRequest") or {})
                row["systemNameProvenanceFindings"] = system_name_provenance_findings(row, row.get("proposedRequest") or {})
                row["systemTypeRule"] = system_type_rule_record(row.get("proposedRequest") or {})
                actions.append(row)
    actions = _consolidate_duplicate_evidence(actions)
    for action in actions:
        _refresh_readiness_diagnostics(action)

    # In BOTH mode an ambiguous record can generate two review candidates. Keep both visible,
    # but never allow them to be bulk-staged until a role has been confirmed (they are NEEDS_INPUT).
    good=sum(1 for r in actions if r.get("status")=="GOOD_TO_TRIGGER")
    needs=sum(1 for r in actions if r.get("status")=="NEEDS_INPUT")
    blocked=sum(1 for r in actions if r.get("status")=="DO_NOT_TRIGGER")
    unique_records={(r.get("sheetName"),r.get("excelRow")) for r in actions}
    accounts={r.get("hipAccountName") or r.get("account") for r in actions if (r.get("hipAccountName") or r.get("account"))}
    blocker_counts: Dict[str, int] = {}
    interface_counts: Dict[Tuple[str, str], int] = {}
    for r in actions:
        for check in r.get("readinessChecks") or []:
            if check.get("blocking"):
                key=str(check.get("name") or "Readiness blocker")
                blocker_counts[key]=blocker_counts.get(key,0)+1
        raw=display(r.get("interfaceRawValue")); canonical=display(r.get("interfaceType"))
        if raw:
            interface_counts[(raw,canonical)]=interface_counts.get((raw,canonical),0)+1
    diagnostics_summary={
        "mergedDuplicateEvidenceRows": sum(int(r.get("mergedDuplicateEvidenceCount") or 0) for r in actions),
        "topBlockers":[{"check":k,"count":v} for k,v in sorted(blocker_counts.items(), key=lambda x:(-x[1],x[0]))],
        "interfaceMappings":[{"excelValue":k[0],"apiValue":k[1],"count":v} for k,v in sorted(interface_counts.items(), key=lambda x:(-x[1],x[0][0]))],
    }
    return {
        "ok":True, "mode":"TRANSPORT_PROFILE_ONLY", "policy":"V122_TP_SCHEMA_LOCK_EXCEL_READINESS_HUMAN_STAGE_PARALLEL_LIVE",
        "file":{"name":filename,"format":workbook["format"],"size":len(data)},
        "sheet":{"name":prepared[0][0].get("name"),"headerRow":prepared[0][1]+1,"headers":prepared[0][2],"dataRowCount":len(prepared[0][3])},
        "sheets":sheet_meta, "ignoredTemplateSheets": ignored_template_sheets, "selectionMode":"TP_ONLY", "tpScope":scope,
        "summary":{"records":len(unique_records),"accounts":len(accounts),"tpActions":len(actions),"GOOD_TO_TRIGGER":good,"NEEDS_INPUT":needs,"DO_NOT_TRIGGER":blocked,"GOOD_API_ACTIONS":good,"rows":len(actions)},
        "diagnosticsSummary": diagnostics_summary,
        "results":deepcopy(actions), "allApiResults":deepcopy(actions), "tpActions":actions,
        "dataProfile": profile_records(all_headers, [{"values":{h:v for h,v in (sample or {}).items()}} for sample in samples]) if samples else {"rowCount":0,"columnCount":len(all_headers),"columns":[]},
        "llm":llm,
        "governance":{"tpOnly":True,"schemaImmutable":True,"agentCanEditSchema":False,"agentCanMapValuesOnly":True,"contractOwnedSelectorsLocked":True,"humanStageRequired":True,"preflightRequired":True,"parallelLiveSupported":True,"maxParallelWorkers":4},
        "notes":[
            "Only Source/Target Transport Profile Create contracts are evaluated in this phase; all seven approved built-in TP interface types use the same governed Create API path.",
            "Interface Type remains authoritative Excel input. AI/reference suggestions (including U-HAUL → SFTP HAFT) are advisory only and never mutate the selected TP contract without explicit user-controlled input.",
            "Directory is never Subscription Folder, and HIP Account is never Existing Account Name. These protected leaves require exact TP-specific Excel provenance.",
            "documentTypeName/documentTypeVersion are optional for this intake and remain empty when the workbook has no document type evidence.",
            "Each TP action is mapped against its exact Dev-approved interface schema: SFTP HAFT, SFTP Server (V130 conditional contract), FTP, HTTPS, HTTPS-AS2, NAS or Rabbit MQ.",
            "Excel evidence not present in the canonical TP payload is reported but never injected as a new API attribute.",
            "Bulk execution stages only GOOD_TO_TRIGGER TP actions and executes preflight-passed selections in parallel using the V122 worker cap.",
            "Universal-template reference sheets (README, INTERFACE_MATRIX, FIELD_GUIDE, ALLOWED_VALUES, DUMMY_EXAMPLES) are excluded from automatic execution scans so dummy examples cannot become LIVE candidates.",
        ],
    }

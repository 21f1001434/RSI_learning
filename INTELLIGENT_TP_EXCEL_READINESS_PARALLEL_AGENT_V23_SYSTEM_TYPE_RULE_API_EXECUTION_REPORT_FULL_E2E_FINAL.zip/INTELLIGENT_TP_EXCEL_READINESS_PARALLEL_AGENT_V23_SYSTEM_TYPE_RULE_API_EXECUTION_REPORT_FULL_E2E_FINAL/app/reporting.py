from __future__ import annotations

import html
import json
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Mapping

from .governance import redact


def _e(v: Any) -> str:
    return html.escape(str(v if v is not None else ""), quote=True)


def _status(row: Mapping[str, Any]) -> tuple[str, str]:
    s = str(row.get("status") or "")
    if s == "GOOD_TO_TRIGGER": return "GOOD TO GO", "good"
    if s == "NEEDS_INPUT": return "NEEDS INPUT", "needs"
    return "NOT READY", "blocked"


def _items(values: Iterable[Any]) -> str:
    rows = [str(x) for x in values if str(x or "").strip()]
    return "<ul>" + "".join(f"<li>{_e(x)}</li>" for x in rows) + "</ul>" if rows else '<span class="muted">None</span>'


def _mapping_rows(row: Mapping[str, Any]) -> str:
    sensitive = set(str(x) for x in ((row.get("contractSnapshot") or {}).get("sensitive_paths") or []))
    data = []
    for m in row.get("mappings") or []:
        path = str(m.get("targetPath") or "")
        source_value = "<redacted>" if path in sensitive else m.get("sourceValue")
        mapped_value = "<redacted>" if path in sensitive else m.get("mappedValue")
        data.append(
            "<tr>"
            f"<td><b>{_e(m.get('sourceColumn'))}</b><small>{_e(source_value)}</small></td>"
            f"<td><code>{_e(path)}</code></td>"
            f"<td>{_e(mapped_value)}</td>"
            f"<td>{round(float(m.get('confidence') or 0)*100)}%</td>"
            f"<td>{_e(m.get('method'))}</td>"
            "</tr>"
        )
    return "".join(data) or '<tr><td colspan="5" class="muted">No safe mappings.</td></tr>'


def _unmapped_rows(row: Mapping[str, Any]) -> str:
    details = row.get("unmappedDetails") or []
    return "".join(
        "<tr>"
        f"<td><b>{_e(x.get('column'))}</b><small>{_e(x.get('value'))}</small></td>"
        f'<td><span class="tag">{_e(x.get("classification"))}</span></td>'
        f"<td>{_e(x.get('reason'))}</td>"
        "</tr>" for x in details
    ) or '<tr><td colspan="3" class="muted">None.</td></tr>'


def _check_rows(row: Mapping[str, Any]) -> str:
    out=[]
    for x in row.get("readinessChecks") or []:
        status=str(x.get("status") or "")
        cls="good" if status == "PASS" else ("needs" if status in {"REVIEW", "OPTIONAL", "MISSING_OPTIONAL", "INCOMPLETE"} else "blocked")
        out.append(
            "<tr>"
            f"<td><b>{_e(x.get('name'))}</b></td>"
            f'<td><span class="status {cls}">{_e(status)}</span></td>'
            f"<td>{_e(x.get('detail'))}</td>"
            f"<td>{_e('YES' if x.get('blocking') else 'NO')}</td>"
            "</tr>"
        )
    return "".join(out) or '<tr><td colspan="4" class="muted">No readiness checks recorded.</td></tr>'


def _field_matrix_rows(row: Mapping[str, Any]) -> str:
    sensitive=set(str(x) for x in ((row.get("contractSnapshot") or {}).get("sensitive_paths") or []))
    out=[]
    for x in row.get("fieldMatrix") or []:
        path=str(x.get("path") or "")
        value="<redacted>" if path in sensitive else x.get("value")
        source_value="<redacted>" if path in sensitive else x.get("sourceValue")
        state=str(x.get("state") or "")
        cls="good" if state=="OK" else ("needs" if state=="MISSING" else "")
        suggestions=", ".join(str(v) for v in (x.get("suggestedExcelColumns") or []))
        out.append(
            "<tr>"
            f"<td><code>{_e(path)}</code><small>{_e(x.get('field'))}</small></td>"
            f"<td>{_e('YES' if x.get('required') else 'NO')}</td>"
            f"<td>{_e(value)}</td>"
            f"<td><span class=\"tag {cls}\">{_e(x.get('sourceType'))}</span><small>{_e(x.get('sourceColumn'))}{(' · '+_e(source_value)) if str(source_value or '') else ''}</small></td>"
            f"<td>{_e(suggestions)}</td>"
            "</tr>"
        )
    return "".join(out) or '<tr><td colspan="5" class="muted">No field inventory recorded.</td></tr>'




def _judge_html(row: Mapping[str, Any]) -> str:
    j = row.get("mappingJudge") or {}
    if not j:
        return '<span class="muted">No Judge evidence recorded.</span>'
    verdict = str(j.get("verdict") or "REVIEW").upper()
    cls = "good" if verdict == "PASS" else ("blocked" if verdict == "BLOCK" else "needs")
    reasons = _items(j.get("reasons") or [])
    concerns = _items(j.get("concerns") or [])
    return (
        f'<div class="callout"><h3>LLM-as-Judge <span class="status {cls}">{_e(verdict)}</span></h3>'
        f'<p><b>Judge score:</b> {_e(j.get("score"))}/100 · <b>confidence:</b> {_e(round(float(j.get("confidence") or 0)*100))}% · '
        f'<b>LLM used:</b> {_e("YES" if j.get("llmUsed") else "NO / deterministic fallback")}</p>'
        f'<p class="muted">Deterministic verdict: {_e(j.get("deterministicVerdict"))} · Model: {_e(j.get("model"))} · Judge cannot mutate payloads or execute APIs.</p>'
        f'<h4>Reasons</h4>{reasons}<h4>Concerns</h4>{concerns}</div>'
    )

def _diagnostic_summary(analysis: Mapping[str, Any]) -> str:
    diag=analysis.get("diagnosticsSummary") or {}
    blockers=diag.get("topBlockers") or []
    ifaces=diag.get("interfaceMappings") or []
    blocker_html="".join(f'<div class="diag-item"><b>{_e(x.get("count"))}</b><span>{_e(x.get("check"))}</span></div>' for x in blockers[:8]) or '<span class="muted">No blocking checks.</span>'
    iface_html="".join(f'<div class="diag-item"><b>{_e(x.get("count"))}</b><span>{_e(x.get("excelValue"))} → {_e(x.get("apiValue") or "unrecognized")}</span></div>' for x in ifaces[:8]) or '<span class="muted">No interface values.</span>'
    return f'<div class="two-col"><div class="callout"><h3>Top readiness blockers</h3><div class="diag-grid">{blocker_html}</div></div><div class="callout"><h3>Excel interface → API interface</h3><div class="diag-grid">{iface_html}</div></div></div>'


def render_tp_readiness_report(analysis: Mapping[str, Any]) -> str:
    summary = analysis.get("summary") or {}
    actions = analysis.get("tpActions") or analysis.get("allApiResults") or analysis.get("results") or []
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    file = analysis.get("file") or {}
    llm = analysis.get("llm") or {}
    source_rows = []
    details = []
    for idx, row in enumerate(actions, start=1):
        label, cls = _status(row)
        blockers = row.get("blockers") or row.get("missingRequiredPaths") or []
        source_rows.append(
            "<tr>"
            f"<td>{_e(row.get('sheetName'))}!{_e(row.get('excelRow'))}</td>"
            f"<td><b>{_e(row.get('customerName') or row.get('lensTpName'))}</b></td>"
            f"<td>{_e(row.get('applicationTracking'))}</td>"
            f"<td><b>{_e(row.get('hipAccountName') or row.get('account'))}</b></td>"
            f"<td>{_e(row.get('tpRole'))}</td>"
            f"<td><b>{_e(row.get('tpName'))}</b><small>{_e(row.get('lensTpName'))}</small></td>"
            f"<td>{_e(row.get('systemName'))}</td>"
            f"<td>{_e(row.get('interfaceType'))}<small>Excel: {_e(row.get('interfaceRawValue'))} · {_e(row.get('interfaceSourceColumn'))}</small></td>"
            f"<td>{_e(row.get('documentTypeName'))}</td>"
            f"<td>{_e(row.get('mappedCount'))}</td>"
            f"<td><b>{_e(row.get('score'))}</b>/100</td>"
            f'<td><span class="status {cls}">{label}</span></td>'
            f"<td>{_e('; '.join(str(x) for x in blockers[:3]))}</td>"
            "</tr>"
        )
        contract = row.get("contractSnapshot") or {}
        safe_payload = redact(row.get("proposedRequest") or {}, contract.get("sensitive_paths") or [])
        details.append(f"""
        <section class="detail-card" id="action-{idx}">
          <div class="detail-head">
            <div><span class="eyebrow">TP candidate {idx}</span><h2>{_e(row.get('hipAccountName') or row.get('account'))} · {_e(row.get('tpName') or 'Unnamed TP')}</h2>
              <p>{_e(row.get('sheetName'))}!{_e(row.get('excelRow'))} · {_e(row.get('tpRole'))} · {_e(row.get('interfaceType'))}</p></div>
            <span class="status {cls}">{label} · {_e(row.get('score'))}/100</span>
          </div>
          <div class="facts">
            <div><span>Customer</span><b>{_e(row.get('customerName') or row.get('lensTpName'))}</b></div>
            <div><span>Application</span><b>{_e(row.get('applicationTracking'))}</b></div>
            <div><span>System</span><b>{_e(row.get('systemName'))}</b></div>
            <div><span>Document type</span><b>{_e(row.get('documentTypeName'))}</b></div>
            <div><span>HIP account</span><b>{_e(row.get('hipAccountName'))}</b></div>
            <div><span>Interface from Excel</span><b>{_e(row.get('interfaceRawValue'))}</b><small>{_e(row.get('interfaceSourceColumn'))}</small></div>
            <div><span>Interface family</span><b>{_e(row.get('interfaceFamily'))}</b></div>
            <div><span>Payload fields with value</span><b>{_e(row.get('populatedFieldCount'))}/{_e(row.get('canonicalFieldCount'))}</b></div>
            <div><span>Blank / null fields</span><b>{_e(row.get('blankFieldCount'))}</b><small>required {_e(row.get('blankRequiredFieldCount'))} · optional {_e(row.get('blankOptionalFieldCount'))}</small></div>
            <div><span>Score basis</span><b>Payload completeness</b><small>Blank/null values = zero credit</small></div>
          </div>
          <div class="two-col">
            <div class="callout"><h3>Decision reasons / blockers</h3><p><b>{_e(row.get('decisionReason'))}</b></p>{_items(blockers)}</div>
            <div class="callout"><h3>Warnings</h3>{_items(row.get('warnings') or [])}</div>
          </div>
          {_judge_html(row)}
          <h3>Readiness checks</h3>
          <table><thead><tr><th>Check</th><th>Status</th><th>Detail</th><th>Blocking</th></tr></thead><tbody>{_check_rows(row)}</tbody></table>
          <h3>Excel → TP payload mapping</h3>
          <table><thead><tr><th>Excel evidence</th><th>Canonical TP path</th><th>Mapped value</th><th>Confidence</th><th>Mapper</th></tr></thead><tbody>{_mapping_rows(row)}</tbody></table>
          <h3>Complete TP API field coverage</h3>
          <p class="muted">Every canonical leaf is shown below, including values from Excel, V122 contract defaults, role-derived values, runtime values, optional blanks and missing required fields.</p>
          <div style="overflow:auto"><table><thead><tr><th>TP API field/path</th><th>Required</th><th>Final value</th><th>Value source</th><th>Expected Excel column(s)</th></tr></thead><tbody>{_field_matrix_rows(row)}</tbody></table></div>
          <h3>Excel fields not injected into TP payload</h3>
          <table><thead><tr><th>Excel evidence</th><th>Classification</th><th>Reason</th></tr></thead><tbody>{_unmapped_rows(row)}</tbody></table>
          <details><summary>Schema-locked proposed TP request</summary><pre>{_e(json.dumps(safe_payload, indent=2, ensure_ascii=False, default=str))}</pre></details>
          <p class="contract-note">Contract: {_e(row.get('apiKey'))} · v{_e(row.get('contractVersion'))} · {_e(row.get('interfaceReference'))}</p>
        </section>
        """)

    return f"""<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TP Readiness Report · {_e(analysis.get('analysisId'))}</title>
<style>
:root{{--ink:#172033;--muted:#667085;--line:#e4e7ec;--panel:#fff;--bg:#f7f9fc;--blue:#175cd3;--green:#027a48;--greenbg:#ecfdf3;--amber:#b54708;--amberbg:#fffaeb;--red:#b42318;--redbg:#fef3f2}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);font:14px/1.55 Inter,Segoe UI,Arial,sans-serif}} .page{{max-width:1500px;margin:auto;padding:36px}}
.hero{{background:linear-gradient(135deg,#101828,#1d2939 55%,#1849a9);color:white;border-radius:22px;padding:30px 34px;box-shadow:0 18px 45px #10182822}} .hero h1{{font-size:32px;margin:5px 0}} .hero p{{margin:0;color:#d0d5dd}}
.eyebrow{{font-size:11px;text-transform:uppercase;letter-spacing:.14em;font-weight:800;color:#84adff}} .metrics{{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:18px 0 24px}} .metric{{background:white;border:1px solid var(--line);border-radius:16px;padding:18px}} .metric span{{display:block;color:var(--muted);font-size:12px}} .metric b{{font-size:28px}} .metric.good b{{color:var(--green)}} .metric.needs b{{color:var(--amber)}} .metric.blocked b{{color:var(--red)}}
.panel,.detail-card{{background:white;border:1px solid var(--line);border-radius:18px;padding:22px;margin:18px 0;box-shadow:0 8px 25px #1018280a}} .panel h2,.detail-card h2{{margin:0 0 4px}} .muted,small{{display:block;color:var(--muted);font-size:12px}}
table{{width:100%;border-collapse:collapse;font-size:12px}} th{{text-align:left;color:#475467;background:#f9fafb;border-bottom:1px solid var(--line);padding:10px;white-space:nowrap}} td{{padding:10px;border-bottom:1px solid #f0f1f3;vertical-align:top}} code{{font-family:Consolas,monospace;font-size:11px}} .status{{display:inline-block;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:800;white-space:nowrap}} .status.good{{background:var(--greenbg);color:var(--green)}} .status.needs{{background:var(--amberbg);color:var(--amber)}} .status.blocked{{background:var(--redbg);color:var(--red)}}
.detail-head{{display:flex;justify-content:space-between;gap:20px;align-items:flex-start}} .detail-head p{{margin:0;color:var(--muted)}} .facts{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:16px 0}} .facts div{{background:#f9fafb;border:1px solid var(--line);border-radius:12px;padding:12px}} .facts span{{display:block;color:var(--muted);font-size:11px}} .two-col{{display:grid;grid-template-columns:1fr 1fr;gap:12px}} .callout{{background:#f9fafb;border-radius:12px;padding:12px 16px}} .callout h3{{margin:0 0 5px}} .callout ul{{margin:6px 0;padding-left:18px}} .tag{{font-size:10px;font-weight:800;background:#eef4ff;color:#3538cd;border-radius:999px;padding:4px 7px}} .tag.good{{background:var(--greenbg);color:var(--green)}} .tag.needs{{background:var(--amberbg);color:var(--amber)}} .diag-grid{{display:grid;gap:8px}} .diag-item{{display:flex;gap:10px;align-items:center;padding:8px 10px;border:1px solid var(--line);border-radius:10px;background:white}} .diag-item b{{min-width:34px;font-size:18px}} details{{margin-top:14px;border:1px solid var(--line);border-radius:12px;padding:10px 14px}} summary{{font-weight:700;cursor:pointer}} pre{{overflow:auto;background:#101828;color:#e4e7ec;border-radius:10px;padding:14px;font:11px/1.5 Consolas,monospace}} .contract-note{{color:var(--muted);font-size:11px}}
.footer{{color:var(--muted);font-size:11px;padding:18px 2px}} @media print{{body{{background:white}} .page{{max-width:none;padding:12px}} .hero,.panel,.detail-card{{box-shadow:none}} details{{break-inside:avoid}}}} @media(max-width:900px){{.metrics,.facts{{grid-template-columns:repeat(2,1fr)}}.two-col{{grid-template-columns:1fr}}.page{{padding:16px}}}}
</style></head><body><div class="page">
<section class="hero"><span class="eyebrow">Intelligent TP Excel Readiness Agent · V21 · Interface Sheets · LIVE Response Intelligence · V122/V130 contract parity</span><h1>Transport Profile Readiness Report</h1><p>Workbook: {_e(file.get('name'))} · Analysis: {_e(analysis.get('analysisId'))} · Generated {generated}</p></section>
<section class="metrics"><div class="metric"><span>TP candidates</span><b>{_e(summary.get('tpActions', summary.get('rows',0)))}</b></div><div class="metric"><span>Accounts</span><b>{_e(summary.get('accounts',0))}</b></div><div class="metric good"><span>Good to go</span><b>{_e(summary.get('GOOD_TO_TRIGGER',0))}</b></div><div class="metric needs"><span>Needs input</span><b>{_e(summary.get('NEEDS_INPUT',0))}</b></div><div class="metric blocked"><span>Not ready</span><b>{_e(summary.get('DO_NOT_TRIGGER',0))}</b></div></section>
<section class="panel"><h2>Why records are / are not ready</h2>{_diagnostic_summary(analysis)}</section>
<section class="panel"><h2>Executive readiness view</h2><p class="muted"><b>V9 scoring policy:</b> score measures actual payload value completeness. Blank, null, whitespace-only, NaN-like and empty values receive zero credit; required leaves are weighted 3× and optional leaves 1×. A record may still be Good to Go when all mandatory execution gates pass even if optional blanks reduce its score.</p><p class="muted"><b>Team-corrected provenance policy:</b> the API-facing Excel <code>Interface Type</code> is authoritative when present; legacy Source/Target Interface Type is only a fallback. <code>Directory</code> is never used as <code>Subscription Folder</code>. HIP Account is never used as FILE <code>Existing Account Name</code>. Document type stays empty when Excel has no document data. Only Good-to-Go TP actions should be staged for bulk execution.</p><div style="overflow:auto"><table><thead><tr><th>Excel</th><th>Customer</th><th>Application</th><th>HIP Account</th><th>TP role</th><th>TP name</th><th>System</th><th>Interface</th><th>Document type</th><th>Mapped</th><th>Score</th><th>Judge</th><th>Decision</th><th>Blocker / reason</th></tr></thead><tbody>{''.join(source_rows)}</tbody></table></div></section>
<section class="panel"><h2>Agent, Judge & governance evidence</h2><div class="facts"><div><span>Dell AIA mapper</span><b>{_e('Used' if llm.get('used') else 'Deterministic fallback')}</b></div><div><span>LLM-as-Judge</span><b>{_e((analysis.get('judgeSummary') or {}).get('PASS',0))} PASS · {_e((analysis.get('judgeSummary') or {}).get('REVIEW',0))} REVIEW · {_e((analysis.get('judgeSummary') or {}).get('BLOCK',0))} BLOCK</b></div><div><span>Schema policy</span><b>TP attributes immutable</b></div><div><span>Execution</span><b>Human stage + preflight + verification</b></div></div><p class="muted">Unmapped Excel evidence is retained in this report and is never converted into a new TP API attribute. Sensitive values are redacted from the HTML payload evidence.</p></section>
{''.join(details)}
<div class="footer">Generated by Intelligent TP Excel Readiness & Parallel Execution Agent. This report is decision evidence; LIVE execution remains governed by runtime allowlist, human staging, preflight and explicit confirmation.</div>
</div></body></html>"""


def render_api_execution_report(runs: Iterable[Mapping[str, Any]], *, title: str = "HIP Transport Profile API Execution Report") -> str:
    """Render immutable LIVE request/response evidence for one or more saved runs.

    The run store already redacts configured sensitive payload fields and common
    secret-looking response keys. This report intentionally preserves all
    non-sensitive fields, including systemName/systemType, so operators can see
    exactly which governed TP identity and ownership values reached the HTTP
    boundary and what Dell returned.
    """
    items = [dict(r) for r in runs if isinstance(r, Mapping)]
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    success = sum(1 for r in items if str(r.get("outcomeClassification") or "").upper() == "SUCCESS")
    existing = sum(1 for r in items if str(r.get("outcomeClassification") or "").upper() == "EXISTING")
    failed = sum(1 for r in items if str(r.get("outcomeClassification") or "").upper() == "FAILED")
    pending = sum(1 for r in items if str(r.get("outcomeClassification") or "").upper() == "PENDING")

    summary_rows = []
    detail_blocks = []
    for idx, run in enumerate(items, start=1):
        req = run.get("request") or {}
        payload = req.get("payload") if isinstance(req, Mapping) else {}
        payload = payload if isinstance(payload, Mapping) else {}
        response = run.get("response")
        verification = run.get("postCreateVerification") or {}
        classification = run.get("responseClassification") or {}
        response_agent = run.get("responseAgent") or {}
        outcome = str(run.get("outcomeClassification") or ("SUCCESS" if run.get("success") else "FAILED")).upper()
        css = "good" if outcome in {"SUCCESS", "EXISTING"} else ("needs" if outcome == "PENDING" else "blocked")
        summary_rows.append(
            "<tr>"
            f"<td><code>{_e(run.get('runId'))}</code></td>"
            f"<td>{_e(run.get('sheetName'))}!{_e(run.get('excelRow'))}</td>"
            f"<td><b>{_e(run.get('account'))}</b></td>"
            f"<td>{_e(payload.get('systemName'))}<small>{_e(payload.get('systemType'))}</small></td>"
            f"<td>{_e(run.get('apiName') or run.get('apiKey'))}</td>"
            f"<td>{_e(run.get('method'))} {_e(run.get('url'))}</td>"
            f"<td>{_e(run.get('statusCode'))}</td>"
            f"<td><span class=\"status {css}\">{_e(outcome)}</span><small>{_e(run.get('resultState'))}</small></td>"
            f"<td>{_e(run.get('responseSummary'))}</td>"
            "</tr>"
        )
        request_json = json.dumps(req, indent=2, ensure_ascii=False, default=str)
        response_json = json.dumps(response, indent=2, ensure_ascii=False, default=str)
        classify_json = json.dumps(classification, indent=2, ensure_ascii=False, default=str)
        verify_json = json.dumps(verification, indent=2, ensure_ascii=False, default=str)
        agent_json = json.dumps(response_agent, indent=2, ensure_ascii=False, default=str)
        attempts_json = json.dumps(run.get("attempts") or [], indent=2, ensure_ascii=False, default=str)
        detail_blocks.append(f"""
        <section class="detail-card">
          <div class="detail-head"><div><span class="eyebrow">LIVE run {idx}</span><h2>{_e(run.get('account') or 'Transport Profile')}</h2><p>{_e(run.get('apiName') or run.get('apiKey'))} · {_e(run.get('executedAt'))}</p></div><span class="status {css}">{_e(outcome)} · {_e(run.get('resultState'))}</span></div>
          <div class="facts">
            <div><span>Run ID</span><b>{_e(run.get('runId'))}</b></div>
            <div><span>HTTP</span><b>{_e(run.get('method'))} · {_e(run.get('statusCode'))}</b></div>
            <div><span>systemName sent</span><b>{_e(payload.get('systemName'))}</b></div>
            <div><span>systemType sent</span><b>{_e(payload.get('systemType'))}</b></div>
            <div><span>Dell reached</span><b>{_e(run.get('dellReached'))}</b></div>
            <div><span>Create accepted</span><b>{_e(run.get('createAccepted'))}</b></div>
            <div><span>Existing verified</span><b>{_e(run.get('verifiedExisting'))}</b></div>
            <div><span>Created verified</span><b>{_e(run.get('verifiedCreated'))}</b></div>
          </div>
          <p><b>Endpoint:</b> <code>{_e(run.get('url'))}</code></p>
          <p><b>Dell response / diagnosis:</b> {_e(run.get('responseSummary'))}</p>
          <div class="two-col">
            <div><h3>Request sent</h3><p class="muted">Exact stored HTTP request evidence. Configured secret/password/token/certificate fields are redacted.</p><pre>{_e(request_json)}</pre></div>
            <div><h3>Response received</h3><p class="muted">Raw/parsed Dell response captured at the Create boundary with common secret keys redacted.</p><pre>{_e(response_json)}</pre></div>
          </div>
          <div class="two-col">
            <div><h3>Deterministic response classification</h3><pre>{_e(classify_json)}</pre></div>
            <div><h3>Dell checking / audit verification</h3><pre>{_e(verify_json)}</pre></div>
          </div>
          <div class="two-col">
            <div><h3>Response agent interpretation</h3><pre>{_e(agent_json)}</pre></div>
            <div><h3>HTTP attempts</h3><pre>{_e(attempts_json)}</pre></div>
          </div>
          <div class="hashes"><b>Payload SHA-256</b> {_e(run.get('payloadSha256'))}<br><b>Schema SHA-256</b> {_e(run.get('schemaSha256'))}<br><b>Execution plan SHA-256</b> {_e(run.get('executionPlanSha256'))}</div>
        </section>
        """)

    return f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{_e(title)}</title>
<style>
:root{{--ink:#172033;--muted:#667085;--line:#e4e7ec;--bg:#f7f9fc;--good:#027a48;--goodbg:#ecfdf3;--amber:#b54708;--amberbg:#fffaeb;--red:#b42318;--redbg:#fef3f2}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 Inter,Segoe UI,Arial,sans-serif}}.page{{max-width:1500px;margin:auto;padding:32px}}.hero{{background:linear-gradient(135deg,#101828,#1d2939 60%,#1849a9);color:#fff;padding:28px 32px;border-radius:20px}}.hero h1{{margin:5px 0;font-size:30px}}.hero p{{margin:0;color:#d0d5dd}}.eyebrow{{font-size:11px;text-transform:uppercase;letter-spacing:.12em;font-weight:800;color:#84adff}}.metrics{{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:18px 0}}.metric{{background:white;border:1px solid var(--line);border-radius:14px;padding:15px}}.metric span{{display:block;color:var(--muted);font-size:11px}}.metric b{{font-size:24px}}.panel,.detail-card{{background:#fff;border:1px solid var(--line);border-radius:16px;padding:20px;margin:16px 0}}table{{width:100%;border-collapse:collapse;font-size:12px}}th{{background:#f9fafb;text-align:left;padding:9px;border-bottom:1px solid var(--line)}}td{{padding:9px;border-bottom:1px solid #f0f1f3;vertical-align:top}}small,.muted{{display:block;color:var(--muted);font-size:11px}}.status{{display:inline-block;border-radius:999px;padding:4px 8px;font-size:10px;font-weight:800}}.status.good{{background:var(--goodbg);color:var(--good)}}.status.needs{{background:var(--amberbg);color:var(--amber)}}.status.blocked{{background:var(--redbg);color:var(--red)}}.detail-head{{display:flex;justify-content:space-between;gap:16px}}.detail-head h2{{margin:3px 0}}.detail-head p{{margin:0;color:var(--muted)}}.facts{{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin:14px 0}}.facts div{{background:#f9fafb;border:1px solid var(--line);border-radius:10px;padding:10px}}.facts span{{display:block;color:var(--muted);font-size:10px}}.two-col{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}pre{{overflow:auto;max-height:520px;background:#101828;color:#e4e7ec;border-radius:10px;padding:13px;font:11px/1.5 Consolas,monospace}}code{{font-family:Consolas,monospace}}.hashes{{font:11px/1.7 Consolas,monospace;color:#475467}}@media(max-width:900px){{.metrics,.facts,.two-col{{grid-template-columns:1fr 1fr}}.page{{padding:14px}}}}@media print{{body{{background:#fff}}.page{{max-width:none;padding:10px}}.hero{{background:#101828!important;-webkit-print-color-adjust:exact}}}}
</style></head><body><div class="page"><section class="hero"><span class="eyebrow">V23 · Governed LIVE request / response evidence</span><h1>{_e(title)}</h1><p>Generated {generated} · {len(items)} recorded HTTP execution(s). Sensitive configured fields remain redacted.</p></section>
<section class="metrics"><div class="metric"><span>Runs</span><b>{len(items)}</b></div><div class="metric"><span>SUCCESS</span><b>{success}</b></div><div class="metric"><span>EXISTING</span><b>{existing}</b></div><div class="metric"><span>FAILED</span><b>{failed}</b></div><div class="metric"><span>PENDING</span><b>{pending}</b></div></section>
<section class="panel"><h2>Execution summary</h2><div style="overflow:auto"><table><thead><tr><th>Run</th><th>Excel</th><th>Account</th><th>System</th><th>API</th><th>HTTP boundary</th><th>HTTP</th><th>Outcome</th><th>Dell response / diagnosis</th></tr></thead><tbody>{''.join(summary_rows) or '<tr><td colspan="9">No runs found.</td></tr>'}</tbody></table></div></section>
{''.join(detail_blocks)}<div class="muted">This report is generated from saved LIVE execution evidence. It never triggers an API call.</div></div></body></html>"""

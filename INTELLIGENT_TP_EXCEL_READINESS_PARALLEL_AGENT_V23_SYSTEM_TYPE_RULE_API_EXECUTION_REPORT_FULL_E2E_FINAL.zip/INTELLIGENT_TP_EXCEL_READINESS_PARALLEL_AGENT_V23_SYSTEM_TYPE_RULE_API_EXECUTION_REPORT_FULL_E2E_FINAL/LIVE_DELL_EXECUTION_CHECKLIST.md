# Dell LIVE Transport Profile Create + Verify + Migration Checklist — V23

Use this checklist before real Dell HIP TP Create or TP Migration.

## 0. System identity provenance + type gate

Before Stage/LIVE, confirm the action shows the exact expected role-correct Excel System Name and source column. V23 records and checks `systemNameProvenance` at Stage, Preflight, and LIVE. If Excel says `AIC - DCE`, the outgoing payload must remain `AIC - DCE`; partner/account/reference values are not allowed to replace it automatically. If a human intentionally changes System Name, use **Apply value edits & revalidate** before staging.

Also confirm the code-owned V23 pair:

```text
AIC - DCE / AIC-DCE / AIC DCE -> systemType = Dell Application
any other explicit systemName  -> systemType = Partner
```

A contradictory Excel System Type is correction evidence, not an override. Direct systemType edits and stage-file tampering are blocked with `SYSTEM_TYPE_SYSTEM_NAME_LOCK`.


## 1. Environment

Copy the same working values from the V130/V122 environment into `.env`.

For TP Create:

```text
HIP_CONFIG_SERVICE_BASE_URL=<approved Dell HIP config-service base>
HIP_TOKEN_URL=<working HIP OAuth token URL>
HIP_CLIENT_ID=<client id>
HIP_CLIENT_SECRET=<client secret>
HIP_SCOPE=<scope if required>
HIP_REQUESTED_BY=<approved requester>
HIP_USER_ID=<user if required>
HIP_ENVIRONMENT=DEV|SIT|PROD
HIP_VERIFY_SSL=true
HIP_CA_BUNDLE=<corporate CA bundle if required>
HTTP_TIMEOUT_SECONDS=90
HTTP_RETRY_ATTEMPTS=3
ALLOWED_API_HOSTS=<approved Dell host>
HIP_LIVE_API_EXECUTION=true
HIP_STRICT_LIVE_PIPELINE=true
HIP_BULK_LIVE_EXECUTION=true
HIP_TP_VALIDATE_BEFORE_CREATE=true
HIP_TP_POST_CREATE_CHECK_ENABLED=true
```

For TP Migration:

```text
HIP_TP_MIGRATION_ENABLED=true
HIP_MIGRATION_SOURCE_ENVIRONMENT=DEV
HIP_MIGRATION_TARGET_ENVIRONMENT=<approved target>
HIP_TP_MIGRATION_POST_CHECK_ENABLED=true
```

For LLM-as-Judge advisory mode:

```text
LLM_JUDGE_ENABLED=true
LLM_JUDGE_MODEL=gpt-oss-120b
LLM_JUDGE_TEMPERATURE=0
LLM_JUDGE_REQUIRED_FOR_LIVE=false
```

For a mandatory fail-closed Judge gate:

```text
LLM_JUDGE_REQUIRED_FOR_LIVE=true
LLM_JUDGE_FAIL_CLOSED=true
```

For PROD also set:

```text
PRODUCTION_EXECUTION_CONFIRMATION=YES
CHANGE_TICKET=<approved change ticket>
```

## 2. Start

```powershell
.\.venv\Scripts\Activate.ps1
python -m uvicorn app.main:app --host 127.0.0.1 --port 8088
```

## 3. Non-mutating runtime verification

Verify:

- `GET /api/health`
- `POST /api/runtime/deep-health`
- `POST /api/runtime/uhal-tp-smoke`
- `GET /api/runtime/live-readiness`
- `GET /api/runtime/migration-readiness`
- `POST /api/judge/test`

The U-HAUL smoke test uses the TP validation route, never TP Create.

## 4. Excel analysis and Judge review

Upload the TP workbook. Explicit Excel Interface Type selects the approved immutable interface schema.

Review each TP:

- Source/Target role
- exact Excel → API provenance
- missing required values and optional blanks
- final redacted payload
- deterministic readiness
- LLM Judge verdict/reasons

Deterministic validation always wins. The Judge cannot promote deterministic `BLOCK` to executable and cannot mutate the payload.

## 5. Stage

Stage only an eligible TP. V15 rejects:

- added/removed/renamed attributes
- changed nesting/list cardinality
- changed interface/role/operation selectors
- method/URL/contract drift

Approved customer leaf values may change.

## 6. Create Preflight

Preflight checks:

1. immutable schema/selector fingerprints
2. required values
3. Dell non-mutating `validate-unique-interface-detail`
4. OAuth/host/LIVE/PROD gates
5. optional mandatory LLM Judge gate

When `LLM_JUDGE_REQUIRED_FOR_LIVE=true`, `judgeGate.passed=true` is required before any network mutation.

## 7. Execute Create and verify creation

Single: type `LIVE`.

Bulk: type `LIVE ALL`.

Create HTTP 2xx means **accepted**, not verified success. V15 then polls:

```text
GET /api/transport-profiles/audits
```

for a new audit record matching the exact TP/environment. Only a terminal successful audit becomes `VERIFIED_CREATED`.

## 8. Migration Preflight and execute

Migration uses the exact V130 endpoint:

```text
POST /api/migration/orchestration/transport-profile
```

with immutable attributes:

```text
sourceEnvironment
targetEnvironment
transportProfileName
transportProfileInterfaceType
transportProfileInterfaceParameters
```

Single: type `MIGRATE`.

Bulk: type `MIGRATE ALL`.

The interface parameters are copied from the already-locked TP interface schema; they cannot be reshaped by the mapper, editor, or Judge.

## 9. Verify migration

When enabled, target-environment TP audit checking runs after Migration. Only target verification becomes `VERIFIED_MIGRATED`.

## 10. Evidence

Execution History/report should retain:

- workbook sheet/row/customer/TP
- selected interface and role
- mapping/readiness evidence
- Judge verdicts for mapping, pre-LIVE, post-Create, pre-Migration, post-Migration
- method/resolved endpoint
- schema/contract/execution fingerprints
- redacted request payload actually sent + response body received
- `systemName` + `systemType` sent at the HTTP boundary
- deterministic response classification and optional response-agent interpretation
- downloadable per-run HTML/JSON execution report and combined batch report
- Create acceptance + post-create audit verification
- Migration acceptance + target verification

Secrets are redacted from stored evidence and Judge prompts.

## V20 response-intelligence checks

Before a real LIVE run, also confirm:

```text
HIP_TP_POST_CREATE_CHECK_ENABLED=true
HIP_TP_RESPONSE_AGENT_ENABLED=true   # optional explanation; deterministic classifier works without it
```

After execution, inspect these run fields:

```text
outcomeClassification = SUCCESS | EXISTING | FAILED | PENDING
responseClassification
responseAgent
postCreateVerification
resultState
responseSummary
```

Do not treat HTTP 200/201/202 alone as proof of success. V20 requires semantic consistency and, when checking is enabled, terminal TP audit evidence for `SUCCESS`. Exact duplicate TP evidence plus checking-API confirmation is surfaced as `EXISTING` rather than a newly created object.


## V23 API execution report checks

After each LIVE run, open the **API execution report** from the result or History and confirm:

```text
systemName sent
systemType sent
request.payload
HTTP method / resolved URL / status
response received
responseClassification
postCreateVerification
outcomeClassification
resultState
```

Machine-readable evidence is available at `/api/runs/{run_id}/execution-report.json`; printable evidence is at `/api/runs/{run_id}/execution-report.html`. Batch evidence is available through `/api/execution-report.html?run_ids=...`. Reports are read-only and cannot trigger an API.

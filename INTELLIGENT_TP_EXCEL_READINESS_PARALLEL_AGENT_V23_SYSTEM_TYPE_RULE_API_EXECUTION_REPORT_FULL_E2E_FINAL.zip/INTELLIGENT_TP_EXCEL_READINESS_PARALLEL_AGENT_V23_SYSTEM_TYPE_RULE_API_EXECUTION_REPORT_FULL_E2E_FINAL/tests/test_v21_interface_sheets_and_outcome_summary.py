from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from app.catalog import load_catalog
from app.main import app
from app.response_intelligence import summarize_outcomes
from app.tp_service import analyze_tp_workbook


EXPECTED_SHEETS = {
    "SFTP_HAFT", "FTP", "SFTP_SERVER", "HTTPS", "HTTPS_AS2", "NAS", "RABBIT_MQ"
}


def test_v21_packaged_template_detects_all_interface_sheets_at_row_6():
    root = Path(__file__).resolve().parents[1]
    p = root / "templates" / "HIP_TP_TEAM_INPUT_TEMPLATE_V21_INTERFACE_SHEETS_FILTERS_DROPDOWNS.xlsx"
    assert p.exists()
    out = analyze_tp_workbook(
        filename=p.name,
        data=p.read_bytes(),
        contracts=load_catalog(),
        scope="BOTH",
        use_llm=False,
        scan_all_sheets=True,
    )
    meta = {row["name"]: row for row in out.get("sheets") or []}
    assert EXPECTED_SHEETS.issubset(meta)
    for name in EXPECTED_SHEETS:
        assert meta[name]["headerRow"] == 6
        assert meta[name]["tpScore"] >= 6
    assert set(out.get("ignoredTemplateSheets") or []) >= {"README", "ALLOWED_VALUES"}


def test_v21_team_template_download_endpoint_returns_exact_packaged_workbook():
    client = TestClient(app)
    r = client.get("/api/tp/team-template.xlsx")
    assert r.status_code == 200
    assert "spreadsheetml.sheet" in r.headers.get("content-type", "")
    assert "HIP_TP_TEAM_INPUT_TEMPLATE_V21_INTERFACE_SHEETS_FILTERS_DROPDOWNS.xlsx" in r.headers.get("content-disposition", "")
    assert len(r.content) > 50000


def test_v21_batch_outcome_summary_keeps_existing_and_pending_separate():
    counts = summarize_outcomes([
        {"outcomeClassification": "SUCCESS", "success": True},
        {"outcomeClassification": "EXISTING", "success": True},
        {"outcomeClassification": "FAILED", "success": False},
        {"outcomeClassification": "PENDING", "success": False},
        {"success": False},
    ])
    assert counts == {"SUCCESS": 1, "EXISTING": 1, "FAILED": 2, "PENDING": 1}


def test_v21_bootstrap_advertises_team_template_and_final_response_outcomes():
    client = TestClient(app)
    r = client.get("/api/bootstrap")
    assert r.status_code == 200
    body = r.json()
    assert body["app"]["version"] == "23.0.0"
    assert body["teamTemplate"]["url"] == "/api/tp/team-template.xlsx"
    assert set(body["teamTemplate"]["interfaceSheets"]) == EXPECTED_SHEETS
    assert body["teamTemplate"]["headerRow"] == 6
    assert body["governance"]["liveResponseClassification"] == ["SUCCESS", "EXISTING", "FAILED", "PENDING"]


def test_v21_actual_separate_sheet_workbook_ingests_all_seven_interfaces_good_to_go():
    root = Path(__file__).resolve().parents[1]
    p = root / "tests" / "fixtures" / "V21_ALL_INTERFACE_SHEETS_FILLED_TEST.xlsx"
    out = analyze_tp_workbook(
        filename=p.name,
        data=p.read_bytes(),
        contracts=load_catalog(),
        scope="SOURCE",
        use_llm=False,
        scan_all_sheets=True,
    )
    assert out["summary"]["tpActions"] == 7
    assert out["summary"]["GOOD_TO_TRIGGER"] == 7
    assert out["summary"]["NEEDS_INPUT"] == 0
    assert out["summary"]["DO_NOT_TRIGGER"] == 0
    assert {row["interfaceType"] for row in out["tpActions"]} == {
        "SFTP HAFT", "FTP", "SFTP Server", "HTTPS", "HTTPS-AS2", "NAS", "Rabbit MQ"
    }
    assert {row["sheetName"] for row in out["tpActions"]} == EXPECTED_SHEETS


def test_v21_classifier_understands_structured_existing_and_string_success_flags():
    from app.response_intelligence import classify_create_response, classify_final_outcome
    existing = classify_create_response(409, {"transportProfileExists": True, "status": "ALREADY_EXISTS"})
    assert existing["classification"] == "EXISTING"
    failed = classify_create_response(200, {"success": "false", "message": "request rejected"})
    assert failed["classification"] == "FAILED"
    final = classify_final_outcome(create=existing, verification={"verified": False, "state": "EXISTING_AUDIT_FAILED"})
    assert final["classification"] == "FAILED"

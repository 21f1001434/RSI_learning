from __future__ import annotations

import csv
import io
from copy import deepcopy

from fastapi.testclient import TestClient

from app.catalog import load_catalog
from app.main import app
from app.state import STATE
from app.tp_service import analyze_tp_workbook, governed_system_type_for_name


def _csv(headers, rows) -> bytes:
    buf = io.StringIO(newline="")
    w = csv.writer(buf)
    w.writerow(headers)
    w.writerows(rows)
    return buf.getvalue().encode("utf-8")


def _tp_csv(system_name: str, *, role: str = "SOURCE", explicit_system_type: str = "") -> bytes:
    source = role.upper() == "SOURCE"
    headers = [
        "Customer Name",
        "Source System" if source else "Target System",
        "Source System Type" if source else "Target System Type",
        "Transport Profile Name",
        "Interface Type",
        "Document Type Name",
        "Document Type Version",
        "Data Format Type",
        "Existing Account Name",
        "Subscription Folder",
    ]
    row = [
        "V23 TEST",
        system_name,
        explicit_system_type,
        "TP_V23_SRC_IB" if source else "TP_V23_TGT_OB",
        "SFTP HAFT",
        "DOC_V23",
        "1.0",
        "XML",
        "acct-v23",
        "/v23",
    ]
    return _csv(headers, [row])


def _api_analyze(client: TestClient, system_name: str, *, role: str = "SOURCE", explicit_system_type: str = ""):
    r = client.post(
        "/api/tp/analyze",
        files={"workbook": ("v23.csv", _tp_csv(system_name, role=role, explicit_system_type=explicit_system_type), "text/csv")},
        data={"tp_scope": role, "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert len(body["allApiResults"]) == 1
    return body, body["allApiResults"][0]


def test_v23_governed_system_type_rule_is_exact_and_not_fuzzy():
    assert governed_system_type_for_name("AIC - DCE") == "Dell Application"
    assert governed_system_type_for_name("AIC-DCE") == "Dell Application"
    assert governed_system_type_for_name("AIC DCE") == "Dell Application"
    assert governed_system_type_for_name("dce-test-partner") == "Partner"
    assert governed_system_type_for_name("Some Dell Partner System") == "Partner"
    assert governed_system_type_for_name("HIP-CLIENT-01") == "Partner"


def test_v23_system_type_rule_cannot_be_widened_by_runtime_env(monkeypatch):
    monkeypatch.setenv("HIP_DELL_APPLICATION_SYSTEM_NAMES", "AIC - DCE,CUSTOMER-SYSTEM-42")
    assert governed_system_type_for_name("AIC - DCE") == "Dell Application"
    assert governed_system_type_for_name("CUSTOMER-SYSTEM-42") == "Partner"


def test_v23_role_correct_system_name_drives_type_when_both_sides_exist():
    data = _csv(
        [
            "TP Role", "Source System", "Target System", "Transport Profile Name",
            "Interface Type", "Document Type Name", "Document Type Version",
            "Data Format Type", "Existing Account Name", "Subscription Folder",
        ],
        [
            ["Sender", "AIC - DCE", "CLIENT-TARGET", "TP_BOTH_SRC_IB", "SFTP HAFT", "DOC_SRC", "1.0", "XML", "acct-src", "/src"],
            ["Receiver", "AIC - DCE", "CLIENT-TARGET", "TP_BOTH_TGT_OB", "SFTP HAFT", "DOC_TGT", "1.0", "XML", "acct-tgt", "/tgt"],
        ],
    )
    out = analyze_tp_workbook(
        filename="v23-both.csv", data=data, contracts=load_catalog(), scope="BOTH", use_llm=False
    )
    assert len(out["tpActions"]) == 2
    by_role = {r["tpRoleKey"]: r for r in out["tpActions"]}
    assert by_role["source"]["systemName"] == "AIC - DCE"
    assert by_role["source"]["systemType"] == "Dell Application"
    assert by_role["target"]["systemName"] == "CLIENT-TARGET"
    assert by_role["target"]["systemType"] == "Partner"


def test_v23_aic_dce_forces_dell_application_even_if_excel_system_type_is_wrong():
    out = analyze_tp_workbook(
        filename="v23.csv",
        data=_tp_csv("AIC - DCE", role="SOURCE", explicit_system_type="Partner"),
        contracts=load_catalog(),
        scope="SOURCE",
        use_llm=False,
    )
    row = out["tpActions"][0]
    assert row["systemName"] == "AIC - DCE"
    assert row["systemType"] == "Dell Application"
    assert row["proposedRequest"]["systemType"] == "Dell Application"
    assert row["ownershipMethod"] == "SYSTEM_NAME_GOVERNED_TYPE_RULE"
    assert row["ownershipExplicitConflict"] is True
    assert row["systemTypeRule"]["passed"] is True


def test_v23_any_non_aic_system_forces_partner_even_if_excel_says_dell():
    out = analyze_tp_workbook(
        filename="v23.csv",
        data=_tp_csv("CUSTOMER-SYSTEM-42", role="SOURCE", explicit_system_type="Dell Application"),
        contracts=load_catalog(),
        scope="SOURCE",
        use_llm=False,
    )
    row = out["tpActions"][0]
    assert row["systemName"] == "CUSTOMER-SYSTEM-42"
    assert row["systemType"] == "Partner"
    assert row["ownershipExplicitConflict"] is True
    assert row["status"] == "GOOD_TO_TRIGGER"


def test_v23_rule_is_direction_independent_target_aic_is_dell():
    out = analyze_tp_workbook(
        filename="v23.csv",
        data=_tp_csv("AIC-DCE", role="TARGET", explicit_system_type="Partner"),
        contracts=load_catalog(),
        scope="TARGET",
        use_llm=False,
    )
    row = out["tpActions"][0]
    assert row["tpRoleKey"] == "target"
    assert row["systemName"] == "AIC-DCE"
    assert row["systemType"] == "Dell Application"
    assert row["status"] == "GOOD_TO_TRIGGER"


def test_v23_human_system_name_edit_rebuilds_locked_system_type_automatically():
    client = TestClient(app)
    analyzed, row = _api_analyze(client, "AIC - DCE", explicit_system_type="Dell Application")
    payload = deepcopy(row["proposedRequest"])
    payload["systemName"] = "CUSTOMER-NEW-SYSTEM"
    # UI cannot directly change locked systemType; backend must rebuild it from the new name.
    assert payload["systemType"] == "Dell Application"
    edited = client.post(
        f"/api/tp/analyses/{analyzed['analysisId']}/actions/{row['actionId']}/values",
        json={"payload": payload, "actor": "V23 Reviewer"},
    )
    assert edited.status_code == 200, edited.text
    updated = edited.json()["action"]
    assert updated["systemName"] == "CUSTOMER-NEW-SYSTEM"
    assert updated["systemType"] == "Partner"
    assert updated["proposedRequest"]["systemType"] == "Partner"
    assert updated["contractSnapshot"]["canonical_request"]["systemType"] == "Partner"
    assert updated["systemTypeRule"]["passed"] is True
    assert updated["status"] == "GOOD_TO_TRIGGER"


def test_v23_preflight_blocks_out_of_band_system_type_tampering():
    client = TestClient(app)
    analyzed, row = _api_analyze(client, "AIC - DCE", explicit_system_type="Partner")
    staged = client.post(
        "/api/stage",
        json={"analysisId": analyzed["analysisId"], "rowId": row["actionId"], "payload": row["proposedRequest"], "reviewer": "V23 Reviewer"},
    )
    assert staged.status_code == 200, staged.text
    stage = staged.json()["stage"]
    assert stage["payload"]["systemType"] == "Dell Application"
    tampered = STATE.get_stage(stage["stageId"])
    tampered["payload"]["systemType"] = "Partner"
    STATE.save_stage(tampered)
    pf = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf.status_code == 200, pf.text
    errors = pf.json()["preflight"]["errors"]
    assert any("SYSTEM_TYPE_SYSTEM_NAME_LOCK" in e for e in errors)


def test_v23_live_sends_governed_system_name_and_type_and_report_captures_response(monkeypatch):
    captured = {}

    class Resp:
        status_code = 201
        text = '{"created":true,"message":"created by test"}'
        def json(self):
            return {"created": True, "message": "created by test", "transportProfileId": "tp-123"}

    def fake_request(method, url, **kwargs):
        captured["method"] = method
        captured["url"] = url
        captured["json"] = deepcopy(kwargs.get("json"))
        return Resp()

    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v23-test-token")
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_REQUESTED_BY", "v23-test@dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setenv("HIP_TP_VALIDATE_BEFORE_CREATE", "false")
    monkeypatch.setenv("HIP_TP_POST_CREATE_CHECK_ENABLED", "false")
    monkeypatch.setenv("HIP_TP_RESPONSE_AGENT_ENABLED", "false")
    monkeypatch.setattr("app.executor.requests.request", fake_request)

    client = TestClient(app)
    analyzed, row = _api_analyze(client, "AIC - DCE", explicit_system_type="Partner")
    assert row["systemType"] == "Dell Application"

    staged = client.post(
        "/api/stage",
        json={"analysisId": analyzed["analysisId"], "rowId": row["actionId"], "payload": row["proposedRequest"], "reviewer": "V23 Reviewer"},
    )
    assert staged.status_code == 200, staged.text
    stage = staged.json()["stage"]
    assert stage["systemTypeRule"]["expectedSystemType"] == "Dell Application"
    pf = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf.status_code == 200, pf.text
    assert pf.json()["preflight"]["executionReady"] is True

    live = client.post(
        f"/api/stages/{stage['stageId']}/execute",
        json={"confirmation": "LIVE", "actor": "V23 Reviewer"},
    )
    assert live.status_code == 200, live.text
    run = live.json()["run"]
    assert captured["method"] == "POST"
    assert captured["json"]["systemName"] == "AIC - DCE"
    assert captured["json"]["systemType"] == "Dell Application"
    assert run["request"]["payload"]["systemName"] == "AIC - DCE"
    assert run["request"]["payload"]["systemType"] == "Dell Application"
    assert run["response"]["message"] == "created by test"
    assert run["executionReportUrl"].endswith("/execution-report.html")

    html = client.get(run["executionReportUrl"] + "?download=false")
    assert html.status_code == 200, html.text
    assert "API Execution Report" in html.text
    assert "AIC - DCE" in html.text
    assert "Dell Application" in html.text
    assert "created by test" in html.text
    assert "Request sent" in html.text
    assert "Response received" in html.text

    j = client.get(run["executionReportJsonUrl"] + "?download=false")
    assert j.status_code == 200, j.text
    body = j.json()
    assert body["request"]["payload"]["systemName"] == "AIC - DCE"
    assert body["request"]["payload"]["systemType"] == "Dell Application"
    assert body["response"]["transportProfileId"] == "tp-123"

    batch_report = client.get(f"/api/execution-report.html?run_ids={run['runId']}&download=false")
    assert batch_report.status_code == 200, batch_report.text
    assert "Batch API Execution Report" in batch_report.text
    assert run["runId"] in batch_report.text

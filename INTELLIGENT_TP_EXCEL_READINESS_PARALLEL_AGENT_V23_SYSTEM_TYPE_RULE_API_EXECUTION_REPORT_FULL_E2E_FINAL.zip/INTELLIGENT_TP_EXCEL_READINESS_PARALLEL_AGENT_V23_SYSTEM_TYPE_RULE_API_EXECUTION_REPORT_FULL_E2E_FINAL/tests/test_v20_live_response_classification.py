from __future__ import annotations

import csv
import io
import json
from copy import deepcopy

from fastapi.testclient import TestClient

from app.main import app
from app.response_intelligence import (
    agent_assess_response,
    classify_create_response,
    classify_final_outcome,
)


def _env(monkeypatch):
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v20-test")
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_REQUESTED_BY", "v20-test@dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setenv("HIP_TP_VALIDATE_BEFORE_CREATE", "false")
    monkeypatch.setenv("HIP_TP_POST_CREATE_CHECK_ENABLED", "true")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_INTERVAL_SECONDS", "0.05")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_TIMEOUT_SECONDS", "1")
    monkeypatch.setenv("HIP_TP_RESPONSE_AGENT_ENABLED", "false")
    monkeypatch.setenv("LLM_JUDGE_ENABLED", "false")


def _analysis(client: TestClient, name: str):
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow([
        "Source System", "Transport Profile Name", "Interface Type",
        "Existing Account Name", "Subscription Folder",
        "Document Type", "Document Type Version", "Data Format Type",
    ])
    w.writerow(["AIC - DCE", name, "SFTP", "acct-v20", f"/{name}", "DOC_850", "1.0", "EDIX12"])
    r = client.post(
        "/api/tp/analyze",
        files={"workbook": ("tp.csv", out.getvalue().encode(), "text/csv")},
        data={"tp_scope": "SOURCE", "use_llm": "false"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    row = body["tpActions"][0]
    assert row["status"] == "GOOD_TO_TRIGGER", row
    return body, row


def _stage_preflight(client: TestClient, analysis: dict, row: dict):
    st = client.post("/api/stage", json={
        "analysisId": analysis["analysisId"],
        "rowId": row["actionId"],
        "payload": deepcopy(row["proposedRequest"]),
        "reviewer": "V20 Test",
    })
    assert st.status_code == 200, st.text
    stage = st.json()["stage"]
    pf = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf.status_code == 200, pf.text
    assert pf.json()["preflight"]["passed"] is True, pf.json()
    return stage


class Resp:
    def __init__(self, status: int, body):
        self.status_code = status
        self._body = body
        self.text = body if isinstance(body, str) else json.dumps(body)
    def json(self):
        if isinstance(self._body, str):
            raise ValueError("not json")
        return self._body


def test_v20_classifier_rejects_semantic_failure_inside_http_200():
    out = classify_create_response(200, {"status": "FAILED", "message": "Transport Profile creation failed"})
    assert out["classification"] == "FAILED"
    assert out["acceptedForVerification"] is False
    assert out["semanticFailure"] is True


def test_v20_classifier_does_not_call_generic_duplicate_existing_tp():
    out = classify_create_response(409, {"message": "System name already exists"})
    assert out["classification"] == "FAILED"
    assert out["existing"] is False


def test_v20_classifier_recognizes_exact_tp_existing_response():
    out = classify_create_response(409, {"message": "Transport Profile TP_X already exists in DEV"})
    assert out["classification"] == "EXISTING"
    assert out["existing"] is True


def test_v20_live_create_classified_success_only_after_checking_api(monkeypatch):
    _env(monkeypatch)
    client = TestClient(app)
    name = "TP_V20_SUCCESS_SRC_IB"
    analysis, row = _analysis(client, name)
    stage = _stage_preflight(client, analysis, row)
    audit_calls = {"n": 0}

    def fake_request(method, url, **kwargs):
        if url.endswith("/api/transport-profiles/audits"):
            audit_calls["n"] += 1
            if audit_calls["n"] == 1:
                return Resp(200, {"data": [{"auditId": "old-v20", "transportProfileName": name, "operation": "Create", "status": "SUCCESS"}]})
            return Resp(200, {"data": [{"auditId": "new-v20", "transportProfileName": name, "operation": "Create", "status": "SUCCESS"}]})
        if url.endswith("/api/transport-profiles/orchestration/create"):
            return Resp(201, {"status": "ACCEPTED", "message": "Transport Profile request accepted"})
        raise AssertionError(url)

    monkeypatch.setattr("app.executor.requests.request", fake_request)
    r = client.post(f"/api/stages/{stage['stageId']}/execute", json={"confirmation": "LIVE", "actor": "V20 Test"})
    assert r.status_code == 200, r.text
    run = r.json()["run"]
    assert run["createAccepted"] is True
    assert run["verifiedCreated"] is True
    assert run["success"] is True
    assert run["outcomeClassification"] == "SUCCESS"
    assert run["responseClassification"]["classification"] == "SUCCESS"
    assert run["responseAgent"]["classification"] == "SUCCESS"
    assert run["resultState"] == "VERIFIED_CREATED"


def test_v20_live_duplicate_is_classified_existing_and_verified(monkeypatch):
    _env(monkeypatch)
    client = TestClient(app)
    name = "TP_V20_EXISTING_SRC_IB"
    analysis, row = _analysis(client, name)
    stage = _stage_preflight(client, analysis, row)
    audit_calls = {"n": 0}

    def fake_request(method, url, **kwargs):
        if url.endswith("/api/transport-profiles/audits"):
            audit_calls["n"] += 1
            return Resp(200, {"data": [{"auditId": f"existing-{audit_calls['n']}", "transportProfileName": name, "operation": "Create", "status": "SUCCESS"}]})
        if url.endswith("/api/transport-profiles/orchestration/create"):
            return Resp(409, {"message": f"Transport Profile {name} already exists in DEV"})
        raise AssertionError(url)

    monkeypatch.setattr("app.executor.requests.request", fake_request)
    r = client.post(f"/api/stages/{stage['stageId']}/execute", json={"confirmation": "LIVE", "actor": "V20 Test"})
    assert r.status_code == 200, r.text
    run = r.json()["run"]
    assert run["createAccepted"] is False
    assert run["existing"] is True
    assert run["verifiedExisting"] is True
    assert run["success"] is True
    assert run["outcomeClassification"] == "EXISTING"
    assert run["responseClassification"]["classification"] == "EXISTING"
    assert run["resultState"] == "EXISTING_VERIFIED"


def test_v20_http_200_with_failed_body_is_final_failed_and_not_verified(monkeypatch):
    _env(monkeypatch)
    client = TestClient(app)
    name = "TP_V20_BODY_FAIL_SRC_IB"
    analysis, row = _analysis(client, name)
    stage = _stage_preflight(client, analysis, row)
    calls = []

    def fake_request(method, url, **kwargs):
        calls.append(url)
        if url.endswith("/api/transport-profiles/audits"):
            return Resp(200, {"data": [{"auditId": "old-only", "transportProfileName": name, "operation": "Create", "status": "SUCCESS"}]})
        if url.endswith("/api/transport-profiles/orchestration/create"):
            return Resp(200, {"success": False, "status": "FAILED", "message": "Transport Profile creation failed because request was rejected"})
        raise AssertionError(url)

    monkeypatch.setattr("app.executor.requests.request", fake_request)
    r = client.post(f"/api/stages/{stage['stageId']}/execute", json={"confirmation": "LIVE", "actor": "V20 Test"})
    assert r.status_code == 200, r.text
    run = r.json()["run"]
    assert run["statusCode"] == 200
    assert run["createAccepted"] is False
    assert run["success"] is False
    assert run["outcomeClassification"] == "FAILED"
    assert run["responseClassification"]["semanticFailure"] is True
    assert run["resultState"] == "RESPONSE_CLASSIFIED_FAILED"
    # Baseline audit is read before Create; semantic failure must not trigger a post-create success poll.
    assert sum(1 for u in calls if u.endswith("/api/transport-profiles/audits")) == 1


def test_v20_terminal_audit_failure_overrides_http_acceptance(monkeypatch):
    _env(monkeypatch)
    client = TestClient(app)
    name = "TP_V20_AUDIT_FAIL_SRC_IB"
    analysis, row = _analysis(client, name)
    stage = _stage_preflight(client, analysis, row)
    audits = {"n": 0}

    def fake_request(method, url, **kwargs):
        if url.endswith("/api/transport-profiles/audits"):
            audits["n"] += 1
            if audits["n"] == 1:
                return Resp(200, {"data": [{"auditId": "old", "transportProfileName": name, "operation": "Create", "status": "SUCCESS"}]})
            return Resp(200, {"data": [{"auditId": "new-fail", "transportProfileName": name, "operation": "Create", "status": "FAILED", "errorMessage": "backend rejected TP"}]})
        if url.endswith("/api/transport-profiles/orchestration/create"):
            return Resp(202, {"status": "PENDING", "message": "Transport Profile request accepted"})
        raise AssertionError(url)

    monkeypatch.setattr("app.executor.requests.request", fake_request)
    r = client.post(f"/api/stages/{stage['stageId']}/execute", json={"confirmation": "LIVE", "actor": "V20 Test"})
    assert r.status_code == 200, r.text
    run = r.json()["run"]
    assert run["createAccepted"] is True
    assert run["verifiedCreated"] is False
    assert run["success"] is False
    assert run["outcomeClassification"] == "FAILED"
    assert run["resultState"] == "CREATE_ACCEPTED_AUDIT_FAILED"


def test_v20_response_agent_cannot_override_deterministic_failed(monkeypatch):
    monkeypatch.setenv("HIP_TP_RESPONSE_AGENT_ENABLED", "true")
    monkeypatch.setattr("app.response_intelligence.DellAIAClient.available", lambda self: True)
    monkeypatch.setattr(
        "app.response_intelligence.DellAIAClient.complete_json",
        lambda self, **kwargs: {
            "classification": "SUCCESS",
            "confidence": 0.99,
            "explanation": "model guessed success",
            "evidence": ["HTTP 200"],
        },
    )
    create = classify_create_response(200, {"status": "FAILED", "message": "Transport Profile creation failed"})
    final = classify_final_outcome(create=create, verification={"verified": False, "state": "CREATE_REJECTED"})
    out = agent_assess_response(
        status_code=200,
        body={"status": "FAILED", "message": "Transport Profile creation failed"},
        create_classification=create,
        verification={"verified": False, "state": "CREATE_REJECTED"},
        final_classification=final,
    )
    assert out["llmUsed"] is True
    assert out["llmClassification"] == "SUCCESS"
    assert out["classification"] == "FAILED"
    assert out["agreement"] is False
    assert out["canOverrideDeterministic"] is False


def test_v20_bootstrap_exposes_response_classifier_policy(monkeypatch):
    monkeypatch.setenv("HIP_TP_RESPONSE_AGENT_ENABLED", "false")
    client = TestClient(app)
    b = client.get("/api/bootstrap")
    assert b.status_code == 200
    body = b.json()
    assert body["app"]["version"] == "23.0.0"
    assert body["governance"]["liveResponseClassification"] == ["SUCCESS", "EXISTING", "FAILED", "PENDING"]
    r = client.get("/api/runtime/live-readiness")
    assert r.status_code == 200
    assert r.json()["responseClassifier"]["outcomes"] == ["SUCCESS", "EXISTING", "FAILED", "PENDING"]


def test_v20_universal_template_dummy_sheet_is_not_auto_executable():
    from pathlib import Path
    from app.catalog import load_catalog
    from app.tp_service import analyze_tp_workbook

    root = Path(__file__).resolve().parents[1]
    p = root / "templates" / "HIP_TP_UNIVERSAL_TEAM_INPUT_TEMPLATE_V20_WITH_DUMMY_EXAMPLES.xlsx"
    out = analyze_tp_workbook(
        filename=p.name,
        data=p.read_bytes(),
        contracts=load_catalog(),
        scope="BOTH",
        use_llm=False,
        scan_all_sheets=True,
    )
    ignored = set(out.get("ignoredTemplateSheets") or [])
    assert "DUMMY_EXAMPLES" in ignored
    assert "README" in ignored
    assert all(a.get("sheetName") != "DUMMY_EXAMPLES" for a in out.get("tpActions") or [])

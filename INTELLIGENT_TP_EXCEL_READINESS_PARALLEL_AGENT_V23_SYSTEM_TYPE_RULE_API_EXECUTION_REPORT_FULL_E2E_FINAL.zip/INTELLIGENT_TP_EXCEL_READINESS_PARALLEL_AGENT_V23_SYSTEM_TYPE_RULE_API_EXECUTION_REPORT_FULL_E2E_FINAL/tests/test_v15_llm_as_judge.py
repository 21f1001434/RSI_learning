from __future__ import annotations

import csv
import io
import json

import pytest
from fastapi.testclient import TestClient

from app.executor import execute
from app.judge import (
    judge_action,
    judge_create_run,
    judge_gate,
    judge_migration_run,
    judge_diagnostics,
)
from app.main import app


def _csv() -> bytes:
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Source System", "Transport Profile Name", "Interface Type", "Existing Account Name", "Subscription Folder"])
    w.writerow(["AIC - DCE", "TP_V15_JUDGE_SRC_IB", "SFTP", "acct-v15", "/TP_V15_JUDGE_SRC_IB"])
    return out.getvalue().encode()


def test_v15_deterministic_block_cannot_be_promoted_by_llm(monkeypatch):
    monkeypatch.setenv("LLM_JUDGE_ENABLED", "true")
    monkeypatch.setattr("app.judge.DellAIAClient.available", lambda self: True)
    monkeypatch.setattr(
        "app.judge.DellAIAClient.complete_json",
        lambda self, **kwargs: {"verdict": "PASS", "score": 99, "confidence": 0.99, "reasons": ["Looks fine"], "concerns": []},
    )
    out = judge_action({"status": "DO_NOT_TRIGGER", "score": 0, "blockers": ["Missing interface"], "proposedRequest": {}})
    assert out["deterministicVerdict"] == "BLOCK"
    assert out["llmVerdict"] == "PASS"
    assert out["verdict"] == "BLOCK"


def test_v15_llm_can_make_pass_more_conservative(monkeypatch):
    monkeypatch.setenv("LLM_JUDGE_ENABLED", "true")
    monkeypatch.setattr("app.judge.DellAIAClient.available", lambda self: True)
    monkeypatch.setattr(
        "app.judge.DellAIAClient.complete_json",
        lambda self, **kwargs: {"verdict": "REVIEW", "score": 72, "confidence": 0.91, "reasons": ["Check account provenance"], "concerns": ["Ambiguous evidence"]},
    )
    out = judge_action({"status": "GOOD_TO_TRIGGER", "score": 100, "proposedRequest": {"systemName": "AIC"}})
    assert out["deterministicVerdict"] == "PASS"
    assert out["verdict"] == "REVIEW"
    assert out["llmUsed"] is True


def test_v15_judge_prompt_redacts_secrets(monkeypatch):
    monkeypatch.setenv("LLM_JUDGE_ENABLED", "true")
    captured = {}
    monkeypatch.setattr("app.judge.DellAIAClient.available", lambda self: True)
    def fake_complete(self, **kwargs):
        captured["user"] = kwargs["user"]
        return {"verdict": "PASS", "score": 100, "confidence": 1.0, "reasons": [], "concerns": []}
    monkeypatch.setattr("app.judge.DellAIAClient.complete_json", fake_complete)
    judge_action({
        "status": "GOOD_TO_TRIGGER",
        "proposedRequest": {"Password": "super-secret", "Username": "safe-user"},
        "mappings": [],
    })
    assert "super-secret" not in captured["user"]
    assert "<redacted>" in captured["user"]


def test_v15_required_judge_gate_blocks_live_before_network(monkeypatch):
    monkeypatch.setenv("LLM_JUDGE_REQUIRED_FOR_LIVE", "true")
    stage = {"preflight": {"passed": True, "judgeGate": {"passed": False}}}
    with pytest.raises(ValueError, match="LLM Judge gate"):
        execute(stage, {}, "LIVE", actor="test")


def test_v15_advisory_judge_gate_does_not_block(monkeypatch):
    monkeypatch.setenv("LLM_JUDGE_REQUIRED_FOR_LIVE", "false")
    gate = judge_gate({"verdict": "REVIEW"})
    assert gate["required"] is False
    assert gate["passed"] is True


def test_v15_tp_analysis_exposes_mapping_judge(monkeypatch):
    monkeypatch.setenv("LLM_JUDGE_ENABLED", "false")
    client = TestClient(app)
    r = client.post(
        "/api/tp/analyze",
        files={"workbook": ("tp.csv", _csv(), "text/csv")},
        data={"tp_scope": "SOURCE", "use_llm": "false"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    row = body["tpActions"][0]
    assert row["mappingJudge"]["verdict"] == "PASS"
    assert row["mappingJudge"]["canMutatePayload"] is False
    assert row["mappingJudge"]["canExecuteApi"] is False
    assert body["judgeSummary"]["PASS"] >= 1


def test_v15_post_create_and_migration_judges_follow_verified_evidence(monkeypatch):
    monkeypatch.setenv("LLM_JUDGE_ENABLED", "false")
    create = judge_create_run({"success": True, "verifiedCreated": True, "createAccepted": True, "resultState": "VERIFIED_CREATED"})
    migration = judge_migration_run({"success": True, "verifiedMigrated": True, "migrationAccepted": True, "resultState": "VERIFIED_MIGRATED"})
    assert create["verdict"] == "PASS"
    assert migration["verdict"] == "PASS"
    pending = judge_create_run({"success": False, "verifiedCreated": False, "createAccepted": True, "resultState": "CREATE_ACCEPTED_VERIFICATION_PENDING"})
    assert pending["verdict"] == "REVIEW"


def test_v15_bootstrap_and_judge_test_endpoints(monkeypatch):
    monkeypatch.setenv("LLM_JUDGE_ENABLED", "false")
    client = TestClient(app)
    boot = client.get("/api/bootstrap")
    assert boot.status_code == 200
    assert boot.json()["app"]["version"] == "23.0.0"
    assert "llmJudge" in boot.json()
    assert boot.json()["governance"]["llmAsJudge"] is True
    j = client.post("/api/judge/test")
    assert j.status_code == 200
    assert j.json()["judge"]["state"] == "DISABLED"

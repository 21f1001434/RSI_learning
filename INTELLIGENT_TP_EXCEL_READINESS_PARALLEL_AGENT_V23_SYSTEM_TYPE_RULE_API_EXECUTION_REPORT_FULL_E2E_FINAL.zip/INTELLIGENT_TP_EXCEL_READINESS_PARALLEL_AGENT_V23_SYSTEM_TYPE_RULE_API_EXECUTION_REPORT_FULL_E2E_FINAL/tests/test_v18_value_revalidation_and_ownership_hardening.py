from copy import deepcopy
from fastapi.testclient import TestClient

from app.main import app


def csv_bytes(headers, row):
    import csv, io
    out = io.StringIO(newline="")
    w = csv.writer(out)
    w.writerow(headers)
    w.writerow(row)
    return out.getvalue().encode("utf-8")


def analyze(client, headers, row, scope="SOURCE"):
    r = client.post(
        "/api/tp/analyze",
        files={"workbook": ("tp.csv", csv_bytes(headers, row), "text/csv")},
        data={"tp_scope": scope, "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert r.status_code == 200, r.text
    return r.json()


def test_v18_missing_required_value_can_be_edited_revalidated_and_batch_staged():
    client = TestClient(app)
    result = analyze(
        client,
        ["Source System", "Transport Profile Name", "Interface Type", "Source System Type", "Existing Account Name", "Subscription Folder"],
        ["client-system", "TP_EDIT_MISSING_SRC_IB", "SFTP", "Client", "acct-edit", ""],
        "SOURCE",
    )
    row = result["allApiResults"][0]
    assert row["status"] == "NEEDS_INPUT"
    assert "transportProfileDetails.0.interfaceDetails.0.parameters.Subscription Folder" in row["missingRequiredPaths"]

    payload = deepcopy(row["proposedRequest"])
    payload["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]["Subscription Folder"] = "/client/out"
    edited = client.post(
        f"/api/tp/analyses/{result['analysisId']}/actions/{row['actionId']}/values",
        json={"payload": payload, "actor": "TP Reviewer"},
    )
    assert edited.status_code == 200, edited.text
    updated = edited.json()["action"]
    assert updated["status"] == "GOOD_TO_TRIGGER"
    assert updated["goodToTrigger"] is True
    assert updated["humanValueEditCount"] >= 1
    assert "transportProfileDetails.0.interfaceDetails.0.parameters.Subscription Folder" in updated["humanValueEditPaths"]

    batch = client.post(
        "/api/tp/batch/stage",
        json={"analysisId": result["analysisId"], "actionIds": [updated["actionId"]], "reviewer": "TP Reviewer"},
    )
    assert batch.status_code == 200, batch.text
    body = batch.json()
    assert body["staged"] == 1
    staged = body["stages"][0]
    assert staged["payload"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]["Subscription Folder"] == "/client/out"


def test_v18_value_editor_blocks_schema_and_contract_selector_changes():
    client = TestClient(app)
    result = analyze(
        client,
        ["Source System", "Transport Profile Name", "Interface Type", "Source System Type", "Existing Account Name", "Subscription Folder"],
        ["client-system", "TP_EDIT_LOCK_SRC_IB", "SFTP", "Client", "acct-edit", "/out"],
        "SOURCE",
    )
    row = result["allApiResults"][0]

    bad_shape = deepcopy(row["proposedRequest"])
    bad_shape["inventedAttribute"] = "blocked"
    r1 = client.post(
        f"/api/tp/analyses/{result['analysisId']}/actions/{row['actionId']}/values",
        json={"payload": bad_shape, "actor": "Reviewer"},
    )
    assert r1.status_code == 400
    assert "attributes" in r1.text.lower() or "schema" in r1.text.lower()

    bad_selector = deepcopy(row["proposedRequest"])
    bad_selector["transportProfileDetails"][0]["interfaceDetails"][0]["interfaceType"] = "FTP"
    r2 = client.post(
        f"/api/tp/analyses/{result['analysisId']}/actions/{row['actionId']}/values",
        json={"payload": bad_selector, "actor": "Reviewer"},
    )
    assert r2.status_code == 400
    assert "contract-owned" in r2.text.lower() or "lock" in r2.text.lower()


def test_v18_uhal_uses_system_name_governed_type_not_customer_reference():
    # V23 removes customer/reference-based ownership inference. AIC - DCE is
    # Dell Application; any other explicit systemName is Partner, regardless
    # of whether the customer is U-HAUL.
    client = TestClient(app)
    common = ["Customer", "Transport Profile Name", "Interface Type", "Existing Account Name", "Subscription Folder"]

    src = analyze(
        client,
        ["Source System"] + common,
        ["AIC - DCE", "U-HAUL", "TP_UHAL_SRC_IB", "SFTP", "acct-src", "/src"],
        "SOURCE",
    )["allApiResults"][0]
    assert src["tpRoleKey"] == "source"
    assert src["systemName"] == "AIC - DCE"
    assert src["systemType"] == "Dell Application"
    assert src["ownershipResolved"] is True
    assert src["ownershipMethod"] == "SYSTEM_NAME_GOVERNED_TYPE_RULE"

    tgt = analyze(
        client,
        ["Target System"] + common,
        ["SYS-TGT", "U-HAUL", "TP_UHAL_TGT_OB", "SFTP", "acct-tgt", "/tgt"],
        "TARGET",
    )["allApiResults"][0]
    assert tgt["tpRoleKey"] == "target"
    assert tgt["systemName"] == "SYS-TGT"
    assert tgt["systemType"] == "Partner"
    assert tgt["ownershipResolved"] is True
    assert tgt["ownershipMethod"] == "SYSTEM_NAME_GOVERNED_TYPE_RULE"


def test_v18_ownership_contract_cannot_be_rebuilt_after_stage_snapshot_exists():
    client = TestClient(app)
    result = analyze(
        client,
        ["Source System", "Transport Profile Name", "Interface Type", "Existing Account Name", "Subscription Folder"],
        ["SYS-AMB", "TP_OWN_LOCK_SRC_IB", "SFTP", "acct", "/folder"],
        "SOURCE",
    )
    row = result["allApiResults"][0]
    own = client.post(
        f"/api/tp/analyses/{result['analysisId']}/actions/{row['actionId']}/ownership",
        json={"systemType": "Partner", "actor": "Reviewer"},
    )
    assert own.status_code == 200, own.text
    updated = own.json()["action"]
    assert updated["status"] == "GOOD_TO_TRIGGER"

    staged = client.post(
        "/api/stage",
        json={"analysisId": result["analysisId"], "rowId": updated["actionId"], "payload": updated["proposedRequest"], "reviewer": "Reviewer"},
    )
    assert staged.status_code == 200, staged.text

    blocked = client.post(
        f"/api/tp/analyses/{result['analysisId']}/actions/{updated['actionId']}/ownership",
        json={"systemType": "Dell Application", "actor": "Reviewer"},
    )
    assert blocked.status_code == 409
    assert "after this tp has been staged" in blocked.text.lower()

from copy import deepcopy
from fastapi.testclient import TestClient

from app.main import app


def csv_bytes(headers, row):
    import csv, io
    out = io.StringIO(newline="")
    w = csv.writer(out)
    w.writerow(headers)
    w.writerow(row)
    return out.getvalue().encode("utf-8")


def analyze(client, headers, row, scope="SOURCE"):
    r = client.post(
        "/api/tp/analyze",
        files={"workbook": ("tp.csv", csv_bytes(headers, row), "text/csv")},
        data={"tp_scope": scope, "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert r.status_code == 200, r.text
    return r.json()


def test_v17_sender_can_be_client_and_receiver_can_be_dell():
    client = TestClient(app)
    source = analyze(
        client,
        ["Source System", "Transport Profile Name", "Interface Type", "Source System Type", "Existing Account Name", "Subscription Folder"],
        ["client-sftp-system", "TP_CLIENT_SRC_IB", "SFTP", "Client", "client-acct", "/client/out"],
        "SOURCE",
    )["allApiResults"][0]
    assert source["tpRoleKey"] == "source"
    assert source["tpRole"] == "SOURCE / SENDER"
    assert source["systemType"] == "Partner"
    assert source["ownershipResolved"] is True
    assert source["status"] == "GOOD_TO_TRIGGER"

    target = analyze(
        client,
        ["Target System", "Transport Profile Name", "Interface Type", "Target System Type", "Existing Account Name", "Subscription Folder"],
        ["AIC - DCE", "TP_DELL_TGT_IB", "SFTP", "Dell Application", "dell-acct", "/dell/in"],
        "TARGET",
    )["allApiResults"][0]
    assert target["tpRoleKey"] == "target"
    assert target["tpRole"] == "TARGET / RECEIVER"
    assert target["systemType"] == "Dell Application"
    assert target["ownershipResolved"] is True
    assert target["status"] == "GOOD_TO_TRIGGER"


def test_v17_non_dell_sender_is_governed_partner_and_conflicting_override_is_blocked():
    # V23 supersedes the earlier ambiguous-ownership behavior: only governed Dell
    # system names (AIC - DCE by default) are Dell Application; every other
    # explicit systemName is Partner.
    client = TestClient(app)
    result = analyze(
        client,
        ["Source System", "Transport Profile Name", "Interface Type", "Existing Account Name", "Subscription Folder"],
        ["SYS-01", "TP_AMBIG_SRC_IB", "SFTP", "acct-1", "/folder"],
        "SOURCE",
    )
    row = result["allApiResults"][0]
    assert row["ownershipResolved"] is True
    assert row["systemType"] == "Partner"
    assert row["ownershipMethod"] == "SYSTEM_NAME_GOVERNED_TYPE_RULE"
    assert row["status"] == "GOOD_TO_TRIGGER"

    blocked = client.post(
        f"/api/tp/analyses/{result['analysisId']}/actions/{row['actionId']}/ownership",
        json={"systemType": "Dell Application", "actor": "Reviewer"},
    )
    assert blocked.status_code == 400
    assert "system_type_system_name_lock" in blocked.text.lower()


def test_v17_user_can_edit_values_but_not_attributes_before_stage():
    client = TestClient(app)
    result = analyze(
        client,
        ["Source System", "Transport Profile Name", "Interface Type", "Source System Type", "Existing Account Name", "Subscription Folder"],
        ["client-system", "TP_EDIT_SRC_IB", "SFTP", "Client", "acct-edit", "/out"],
        "SOURCE",
    )
    row = result["allApiResults"][0]
    assert row["status"] == "GOOD_TO_TRIGGER"
    payload = deepcopy(row["proposedRequest"])
    payload["systemName"] = "client-system-updated"
    edited = client.post(
        f"/api/tp/analyses/{result['analysisId']}/actions/{row['actionId']}/values",
        json={"payload": payload, "actor": "Human User"},
    )
    assert edited.status_code == 200, edited.text
    edited_row = edited.json()["action"]
    staged = client.post(
        "/api/stage",
        json={"analysisId": result["analysisId"], "rowId": row["actionId"], "payload": edited_row["proposedRequest"], "reviewer": "Human User"},
    )
    assert staged.status_code == 200, staged.text
    assert staged.json()["stage"]["payload"]["systemName"] == "client-system-updated"

    bad = deepcopy(edited_row["proposedRequest"])
    bad["inventedAttribute"] = "not allowed"
    rejected = client.post(
        "/api/stage",
        json={"analysisId": result["analysisId"], "rowId": row["actionId"], "payload": bad, "reviewer": "Human User"},
    )
    assert rejected.status_code == 400
    assert "attribute" in rejected.text.lower() or "schema" in rejected.text.lower()

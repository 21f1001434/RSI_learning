const $ = (id) => document.getElementById(id);
const state = { sections: [], runtime: null, process: null, preflight: null, liveRuntimeCertification: null, liveReadiness: null, descriptionPlan: null, runs: [], missionTrace: null, agentLiveView: null, agentLiveViewScreenshotUrl: "", worldModel: null, humanAssistance: null, humanSelectedControl: null, modelTests: { text:null, vision:null }, timer: null };

async function api(path, options = {}) {
  // V243R25: an optional timeout (status polls) so a slow answer cannot pile up requests.
  const { timeoutMs, ...fetchOptions } = options;
  const controller = timeoutMs ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  let response;
  try {
    response = await fetch(path, {
      ...fetchOptions,
      ...(controller ? { signal: controller.signal } : {}),
      headers: { "Content-Type": "application/json", ...(fetchOptions.headers || {}) },
    });
  } catch (error) {
    throw new Error(error?.name === "AbortError" ? `No answer from ${path.split("?")[0]} within ${Math.round(timeoutMs / 1000)} s` : `Cannot reach the backend (${error?.message || error})`);
  } finally {
    if (timer) clearTimeout(timer);
  }
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
  if (!response.ok) throw new Error(data.detail || data.error || `${response.status} ${response.statusText}`);
  return data;
}

function toast(message, kind = "good") {
  const el = $("toast");
  el.textContent = message;
  el.className = `toast ${kind}`;
  el.onclick = () => el.classList.add("hidden");
  // V243R37: a new message gets its full time (an older timer used to hide it early).
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => el.classList.add("hidden"), Math.min(9000, 3600 + String(message || "").length * 25));
}

function esc(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (m) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;" }[m]));
}

function table(rows, columns) {
  if (!rows?.length) return '<div class="empty">No rows available.</div>';
  // V243R37: a phase is shown by its name ("Source Document Type"), its key in the tooltip.
  const cell = (c, row) => c.render ? c.render(row)
    : (c.key === "phase" && CHAT_PHASES[row[c.key]] ? `<span title="${esc(row[c.key])}">${esc(CHAT_PHASES[row[c.key]])}</span>` : esc(row[c.key]));
  return `<table class="table"><thead><tr>${columns.map(c=>`<th>${esc(c.label)}</th>`).join("")}</tr></thead><tbody>${rows.map(row=>`<tr>${columns.map(c=>`<td>${cell(c, row)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
}


function renderModelTest(kind, result = null, pending = false) {
  const prefix = kind === "text" ? "textModel" : "visionModel";
  const badge = $(`${prefix}State`);
  const details = $(`${prefix}Details`);
  if (!badge || !details) return;
  if (pending) {
    badge.textContent = "Testing…"; badge.className = "badge info";
    details.innerHTML = '<b>Status</b><span>Calling the configured Dell AIA deployment…</span>';
    return;
  }
  if (!result) {
    badge.textContent = "Not tested"; badge.className = "badge neutral";
    return;
  }
  badge.textContent = result.pass ? "Available" : "Unavailable";
  badge.className = `badge ${result.pass ? "good" : "bad"}`;
  const verified = kind === "vision" ? result.image_understanding_verified : (result.capability_verified ?? result.response_received ?? result.expected_marker_seen);
  const contractWarning = kind === "text" ? (result.contract_warning || "") : "";
  details.innerHTML = `
    <b>Provider</b><span>${esc(result.provider || "Dell AIA GenAI Gateway")}</span>
    <b>Model</b><span>${esc(result.model || "—")}</span>
    <b>Latency</b><span>${esc(result.latency_ms ?? "—")} ms</span>
    <b>Endpoint configured</b><span>${result.endpoint_configured ? "Yes" : "No"}</span>
    ${Array.isArray(result.env_files_loaded) ? `<b>.env loaded</b><span>${result.env_files_loaded.length ? "Yes" : "No"}</span>` : ""}
    <b>Capability verified</b><span>${verified ? "Yes" : "No"}</span>
    <b>Result</b><span>${esc(result.status || "—")}</span>
    ${result.output_token_cap ? `<b>Output token cap</b><span>${esc(result.output_token_cap)}</span>` : ""}
    ${kind === "text" ? `<b>Synthetic marker</b><span>${result.expected_marker_seen ? "Matched" : "Not exact"}</span>` : ""}
    ${result.response_preview ? `<b>Model response</b><span class="mono">${esc(result.response_preview)}</span>` : ""}
    ${contractWarning ? `<b>Note</b><span>${esc(contractWarning)}</span>` : ""}
    ${result.error ? `<b>Error</b><span>${esc(result.error_kind || "model_error")}: ${esc(result.error)}</span>` : ""}`;
}

async function testModelAvailability(kind) {
  const button = $(kind === "text" ? "testTextModelBtn" : "testVisionModelBtn");
  if (button) button.disabled = true;
  renderModelTest(kind, null, true);
  try {
    const result = await api(`/api/models/${kind}/test`, {
      method:"POST",
      body:JSON.stringify({ config: $("configPath").value.trim() || "config.yaml" }),
    });
    state.modelTests[kind] = result;
    renderModelTest(kind, result, false);
    toast(`${kind === "text" ? "Text" : "Vision"} model ${result.pass ? "available" : "unavailable"}`, result.pass ? "good" : "bad");
    return result;
  } catch (error) {
    const result = { pass:false, status:"request_failed", error_kind:"backend_request", error:error.message };
    state.modelTests[kind] = result; renderModelTest(kind, result, false); toast(error.message, "bad");
    return result;
  } finally { if (button) button.disabled = false; }
}

function currentSection() { return $("sectionSelect").value || "all"; }
function selectedSpec() { return state.sections.find(s => s.id === currentSection()) || state.sections.at(-1) || { id:"all", label:"All HIP sections", phases:[] }; }

function missionPayload() {
  return {
    section: currentSection(),
    witness_mode: !!$("liveWitnessMode")?.checked,
    description: $("missionDescription").value.trim(),
    use_description_trigger: $("useDescriptionTrigger").checked,
    config: $("configPath").value.trim() || "config.yaml",
    input_json: $("inputPath").value.trim(),
    runs_dir: $("runsDir").value.trim() || "./runs",
    golden_screenshot_dir: $("goldenDir").value.trim(),
    upload_assets_dir: $("uploadsDir").value.trim(),
    api_mode: $("apiMode").value,
    write_heavy_evidence: $("heavyEvidence").checked,
    allow_api_mutation: $("allowApiMutation").checked,
    resume_run: $("resumeRun").value.trim(),
    until_complete: $("untilComplete").checked,
    readiness_token: state.liveReadiness?.token || "",
    save_after_fill: !!$("saveAfterFill")?.checked,
    save_confirmation: ($("saveConfirmation")?.value || "").trim(),
  };
}

function descriptionRequest() {
  const p = missionPayload();
  return {
    description:p.description, config:p.config, input_json:p.input_json,
    golden_screenshot_dir:p.golden_screenshot_dir, upload_assets_dir:p.upload_assets_dir,
  };
}

async function planDescription({silent=false}={}) {
  const description = $("missionDescription").value.trim();
  if (!description) { if(!silent) toast("Enter a mission description first", "bad"); return null; }
  const data = await api("/api/mission/description-plan", { method:"POST", body:JSON.stringify(descriptionRequest()) });
  state.descriptionPlan = data.description_plan || null;
  state.preflight = data;
  const spec = data.section || {};
  if (spec.id && state.sections.some(s=>s.id===spec.id)) $("sectionSelect").value = spec.id;
  $("useDescriptionTrigger").checked = true;
  renderScope(); renderPreflight();
  if(!silent) toast(`Description mapped to ${spec.label || (spec.phases||[]).join(", ")}`);
  return data;
}

async function loadSections() {
  const data = await api("/api/sections");
  state.sections = data.sections || [];
  const select = $("sectionSelect");
  select.innerHTML = state.sections.map(s => `<option value="${esc(s.id)}">${esc(s.label)}</option>`).join("");
  select.value = "all";
  renderScope();
}

function renderScope() {
  const triggered = $("useDescriptionTrigger")?.checked && state.descriptionPlan?.section;
  const spec = triggered ? state.descriptionPlan.section : selectedSpec();
  $("sectionNote").textContent = spec.dependency_note || (triggered ? "Description-selected deterministic HIP skills" : "");
  $("scopeMetric").textContent = spec.id === "all" ? "All sections" : String(spec.label || "Description-selected").replace(" only", "");
  $("phaseMetric").textContent = `${spec.phase_count || spec.phases?.length || 0} phase(s)`;
  const witness = !!$("liveWitnessMode")?.checked;
  if (witness) $("startBtn").textContent = spec.id === "all" ? "Start live witness" : "Run selected live witness";
  else $("startBtn").textContent = spec.id === "all" ? "Start full mission" : (triggered ? "Run description-triggered mission" : "Run selected section only");
}

function syncWitnessMode() {
  const witness = !!$("liveWitnessMode")?.checked;
  if (witness) {
    $("apiMode").value = "capture";
    $("allowApiMutation").checked = false;
  }
  $("allowApiMutation").disabled = witness;
  // Witness uses the completion-first bounded controller; avoid accidentally
  // turning the first live smoke into an unbounded recovery run.
  if (witness) $("untilComplete").checked = false;
  renderScope();
}

function invalidateLiveReadiness(reason = "Mission inputs changed") {
  state.liveReadiness = null;
  const badge=$("liveReadinessState"), details=$("liveReadinessSummary");
  if (badge) { badge.textContent="Not run"; badge.className="badge neutral"; }
  if (details) details.innerHTML=`<div class="empty">${esc(reason)}. Run Live GO/NO-GO before starting.</div>`;
  updateButtons();
}


function renderLiveRuntimeCertification(result = null, pending = false) {
  const badge=$("liveRuntimeCertState"), summary=$("liveRuntimeCertSummary"), tableWrap=$("liveRuntimeCertChecks");
  if (!badge || !summary || !tableWrap) return;
  if (pending) {
    badge.textContent="Checking…"; badge.className="badge info";
    summary.innerHTML='<div class="empty">Opening the real headed browser/runtime. Complete Dell SSO in the opened window if requested. No HIP mutation controls are authorized.</div>';
    tableWrap.innerHTML=""; return;
  }
  if (!result) {
    badge.textContent="Not run"; badge.className="badge neutral"; tableWrap.innerHTML=""; return;
  }
  badge.textContent=result.decision || (result.pass?"GO":"NO-GO"); badge.className=`badge ${result.pass?"good":"bad"}`;
  summary.innerHTML=`<div class="kv"><b>Decision</b><span>${esc(result.decision||"—")}</span><b>Certificate</b><span>${esc(result.certificate_id||"—")}</span><b>Blockers</b><span>${esc(result.blocker_count||0)}</span><b>Warnings</b><span>${esc(result.warning_count||0)}</span><b>Expires</b><span>${result.expires_at_epoch?new Date(result.expires_at_epoch*1000).toLocaleString():"—"}</span><b>Contract</b><span>${esc(result.non_mutating_contract||"")}</span></div>`;
  tableWrap.innerHTML=table(result.checks||[], [
    {key:"label",label:"Live runtime check"},
    {key:"pass",label:"Status",render:r=>r.pass?'<span class="badge good">PASS</span>':`<span class="badge ${r.severity==="warning"?"info":"bad"}">${r.severity==="warning"?"WARN":"BLOCK"}</span>`},
    {key:"detail",label:"Detail"},
  ]);
}

// V243R25: the certification runs in its own backend process.  Start it, then
// follow its progress; a failure shows the real reason, never an invented NO_GO.
async function runLiveRuntimeCertification() {
  const button=$("liveRuntimeCertBtn"); if(button) button.disabled=true;
  renderLiveRuntimeCertification(null,true);
  try {
    const job=await api("/api/mission/live-runtime-certification", {method:"POST", timeoutMs:60000, body:JSON.stringify({
      config:$("configPath").value.trim()||"config.yaml",
      runs_dir:$("runsDir").value.trim()||"./runs",
      target_url:"",
      ttl_seconds:0,
      require_pyautogui_mcp:false,
      requalify_models:!!$("requalifyModels")?.checked,
    })});
    toast(job.already_running?"A certification is already running — following it":"Windows runtime certification started — complete Dell SSO in the opened browser if asked","good");
    renderCertificationJob(job);
    return await followCertificationJob();
  } catch(error) {
    renderCertificationProblem(`Could not start the certification: ${error.message}`, "");
    toast(error.message,"bad");
    if(button) button.disabled=false;
    return null;
  }
}

async function followCertificationJob() {
  if (state.certFollowing) return null;
  state.certFollowing=true;
  const button=$("liveRuntimeCertBtn"); if(button) button.disabled=true;
  try {
    for (;;) {
      await new Promise(r=>setTimeout(r,3000));
      let job;
      try { job=await api("/api/mission/live-runtime-certification/status", {timeoutMs:15000}); }
      catch { continue; }  // a slow answer is not a result: keep following
      renderCertificationJob(job);
      if (job.status!=="running") return job;
    }
  } finally { state.certFollowing=false; if(button) button.disabled=false; }
}

function renderCertificationJob(job) {
  const badge=$("liveRuntimeCertState"), summary=$("liveRuntimeCertSummary"), tableWrap=$("liveRuntimeCertChecks");
  if (!badge || !summary || !tableWrap || !job) return;
  const rows=job.checks||[];
  const cols=[
    {key:"label",label:"Live runtime check"},
    {key:"pass",label:"Status",render:r=>r.pass?'<span class="badge good">PASS</span>':`<span class="badge ${r.severity==="warning"?"info":"bad"}">${r.severity==="warning"?"WARN":"BLOCK"}</span>`},
    {key:"detail",label:"Detail"},
  ];
  if (job.status==="running") {
    badge.textContent="Running…"; badge.className="badge info";
    summary.innerHTML=`<div class="kv"><b>Status</b><span>Running for ${esc(Math.round(job.elapsed_seconds||0))} s in its own process (the backend stays responsive)</span><b>Last check</b><span>${esc(job.last_check||"starting the browser…")}</span><b>Note</b><span>Complete Dell SSO in the opened browser window if it asks.</span></div>`;
    tableWrap.innerHTML=table(rows, cols);
  } else if (job.status==="done") {
    const result=job.result||{};
    state.liveRuntimeCertification=result;
    renderLiveRuntimeCertification(result,false);
    if (state.lastCertJob!==job.job_id) {
      state.lastCertJob=job.job_id;
      invalidateLiveReadiness("Windows runtime certification changed");
      toast(result.pass?"Windows runtime certified — now run Live GO/NO-GO":"Windows runtime NO-GO — see the BLOCK rows for the reason", result.pass?"good":"bad");
    }
  } else if (job.status==="failed") {
    renderCertificationProblem(job.error||"The certification did not finish.", job.log_tail||"", rows, cols);
  }
}

function renderCertificationProblem(message, logTail, rows=[], cols=null) {
  const badge=$("liveRuntimeCertState"), summary=$("liveRuntimeCertSummary"), tableWrap=$("liveRuntimeCertChecks");
  if (!badge || !summary || !tableWrap) return;
  badge.textContent="Not completed"; badge.className="badge bad";
  summary.innerHTML=`<div class="kv"><b>Problem</b><span>${esc(message)}</span></div>${logTail?`<pre class="log-tail">${esc(String(logTail).slice(-4000))}</pre>`:""}`;
  tableWrap.innerHTML=cols?table(rows, cols):"";
}

function renderLiveReadiness(result = null, pending = false) {
  const badge=$("liveReadinessState"), summary=$("liveReadinessSummary"), tableWrap=$("liveReadinessChecks");
  if (!badge || !summary || !tableWrap) return;
  if (pending) {
    badge.textContent="Checking…"; badge.className="badge info";
    summary.innerHTML='<div class="empty">Launching non-invasive browser/MCP probes and testing Dell AIA text + vision models…</div>';
    tableWrap.innerHTML=""; return;
  }
  if (!result) {
    badge.textContent="Not run"; badge.className="badge neutral";
    summary.innerHTML='<div class="empty">Run this gate immediately before a real mission.</div>'; tableWrap.innerHTML=""; return;
  }
  badge.textContent=result.decision || (result.pass?"GO":"NO-GO"); badge.className=`badge ${result.pass?"good":"bad"}`;
  summary.innerHTML=`<div class="kv"><b>Decision</b><span>${esc(result.decision||"—")}</span><b>Profile</b><span>${esc(result.execution_profile||"standard")}</span><b>Blockers</b><span>${esc(result.blocker_count||0)}</span><b>Warnings</b><span>${esc(result.warning_count||0)}</span><b>Receipt</b><span>${result.pass?`Valid for ${esc(result.expires_in_seconds||0)} seconds`:`Not issued`}</span><b>Execution contract</b><span>${esc(result.execution_contract||"")}</span>${result.witness_guarantee?`<b>Witness guarantee</b><span>${esc(result.witness_guarantee)}</span>`:""}</div>`;
  tableWrap.innerHTML=table(result.checks||[], [
    {key:"label",label:"Live check"},
    {key:"pass",label:"Status",render:r=>r.pass?'<span class="badge good">PASS</span>':`<span class="badge ${r.severity==="warning"?"info":"bad"}">${r.severity==="warning"?"WARN":"BLOCK"}</span>`},
    {key:"detail",label:"Detail"},
  ]);
}

async function runLiveReadiness({silent=false}={}) {
  if (!state.preflight) await runPreflight(true);
  renderLiveReadiness(null, true);
  const button=$("liveReadinessBtn"); if(button) button.disabled=true;
  try {
    const p=missionPayload();
    const result=await api("/api/mission/live-readiness", {method:"POST", body:JSON.stringify({
      section:p.section, witness_mode:p.witness_mode, description:p.description, use_description_trigger:p.use_description_trigger,
      config:p.config, input_json:p.input_json, runs_dir:p.runs_dir, golden_screenshot_dir:p.golden_screenshot_dir,
      upload_assets_dir:p.upload_assets_dir, api_mode:p.api_mode,
    })});
    state.liveReadiness=result;
    state.modelTests.text=(result.checks||[]).find(x=>x.id==="text_model")?.evidence || state.modelTests.text;
    state.modelTests.vision=(result.checks||[]).find(x=>x.id==="vision_model")?.evidence || state.modelTests.vision;
    if(state.modelTests.text) renderModelTest("text", state.modelTests.text, false);
    if(state.modelTests.vision) renderModelTest("vision", state.modelTests.vision, false);
    renderLiveReadiness(result, false); updateButtons();
    if(!silent) toast(result.pass?"Live readiness GO — mission may start":"Live readiness NO-GO — fix blockers first", result.pass?"good":"bad");
    return result;
  } catch(error) {
    // V243R25: a request that failed is "not completed" with its reason -- not an invented NO_GO blocker.
    state.liveReadiness={pass:false,decision:"NOT COMPLETED",checks:[],blocker_count:0,error:error.message,
      execution_contract:`The readiness check could not complete: ${error.message}`};
    renderLiveReadiness(state.liveReadiness,false); updateButtons(); if(!silent) toast(error.message,"bad"); return state.liveReadiness;
  } finally { if(button) button.disabled=false; }
}

async function runPreflight(silent = false) {
  try {
    const p = missionPayload();
    if (p.use_description_trigger && p.description) {
      state.preflight = await api("/api/mission/description-plan", { method:"POST", body:JSON.stringify(descriptionRequest()) });
      state.descriptionPlan = state.preflight.description_plan || null;
    } else {
      state.preflight = await api("/api/mission/preflight", { method:"POST", body:JSON.stringify({
        section:p.section, config:p.config, input_json:p.input_json, runs_dir:p.runs_dir, golden_screenshot_dir:p.golden_screenshot_dir, upload_assets_dir:p.upload_assets_dir,
      }) });
      state.descriptionPlan = null;
    }
    renderPreflight();
    if (state.liveReadiness) invalidateLiveReadiness("Static preflight reran");
    if (!silent) toast(state.preflight.pass ? "Preflight passed" : "Preflight has blocking issues", state.preflight.pass ? "good" : "bad");
  } catch (error) {
    state.preflight = null;
    renderPreflight(error.message);
    if (!silent) toast(error.message, "bad");
  }
}

function renderPreflight(error = "") {
  const p = state.preflight;
  if (!p) {
    $("preflightMetric").textContent = "Failed";
    $("preflightState").textContent = "Error";
    $("preflightState").className = "badge bad";
    $("preflightSummary").innerHTML = `<div class="empty">${esc(error || "Preflight not available")}</div>`;
    return;
  }
  const pass = !!p.pass && !!p.autogen?.pass;
  $("preflightMetric").textContent = pass ? "Ready" : "Blocked";
  $("preflightState").textContent = pass ? "Ready" : "Blocked";
  $("preflightState").className = `badge ${pass ? "good" : "bad"}`;
  $("inputMetric").textContent = p.input_contract?.section_scoped ? "Section-scoped input" : "Input validated";
  const issues = p.issues || [];
  const autogen = p.autogen || {};
  $("preflightSummary").innerHTML = `
    <div class="kv">
      <b>Input contract</b><span>${p.input_contract?.pass ? "PASS" : "FAIL"}</span>
      <b>Golden screenshots</b><span>${p.golden_screenshots_pass ? "Ready" : "Missing"}</span>
      <b>Upload assets</b><span>${p.upload_assets_pass ? "Ready" : "Missing"}</span>
      <b>AutoGen</b><span>${autogen.pass ? "0.7.5 Ready" : esc(autogen.reason || "Not ready")}</span>
      <b>Browser</b><span>${esc(state.runtime?.browser?.primary_name || state.runtime?.browser?.channel || "Chromium")} (same persistent CDP session)</span>
      <b>Vision model</b><span>${state.runtime?.vision_runtime?.enabled ? (state.runtime?.vision_runtime?.explicit_model_candidates?.length ? `Configured: ${esc(state.runtime.vision_runtime.explicit_model_candidates.join(", "))}` : "Enabled; model resolved/probed at runtime") : "Disabled"}</span>
      <b>5-minute loading watchdog</b><span>${state.runtime?.vision_runtime?.use_for_loading_watchdog ? `Vision-confirmed refresh after ${esc(state.runtime.vision_runtime.loading_refresh_after_seconds || 300)}s` : "Disabled"}</span>
      <b>PyAutoGUI fallback</b><span>${state.runtime?.pyautogui?.available ? "Ready (last resort)" : (state.runtime?.pyautogui?.enabled ? esc(state.runtime?.pyautogui?.reason || "Unavailable on this host") : "Disabled")}</span>
      <b>AutoWebGLM recovery</b><span>${state.runtime?.autowebglm?.enabled ? `${esc(state.runtime.autowebglm.official_action_count || 10)}-action protocol (${state.runtime?.autowebglm?.native_model_configured ? "native wrapper" : "Dell AIA planner"})` : "Disabled"}</span>
      <b>LangChain browser toolkit</b><span>${state.runtime?.langchain_browser_toolkit?.enabled ? "Read-only same-browser recovery" : "Disabled"}</span>
      <b>Version source</b><span>${esc(Object.entries(autogen.version_sources || {}).map(([k,v])=>`${k}: ${v}`).join(", ") || "—")}</span>
      <b>Blocking issues</b><span>${issues.length}</span>
    </div>${issues.length ? `<pre class="json-output">${esc(JSON.stringify(issues,null,2))}</pre>` : ""}`;
  const skill = p.skill_vetting || {};
  $("skillVetting").innerHTML = table(skill.skills || [], [
    {key:"phase",label:"Phase"},{key:"label",label:"Expert skill"},{key:"pass",label:"Vetted",render:r=>r.pass?'<span class="badge good">PASS</span>':'<span class="badge bad">FAIL</span>'},
    {key:"deterministic_contract",label:"Deterministic contract"},
  ]);
  const budget = p.context_budget || {};
  $("contextBudget").innerHTML = `<b>Policy</b><span>${esc(budget.policy || "—")}</span><b>Phases</b><span>${esc((budget.selected_phases||[]).join(", "))}</span><b>Input branches</b><span>${esc((budget.selected_input_keys||[]).join(", ") || "—")}</span><b>Capabilities loaded</b><span>${esc(budget.capability_count ?? 0)}</span><b>Context chars</b><span>${esc(budget.serialized_chars_before_limit ?? 0)} / ${esc(budget.max_serialized_chars ?? 0)}</span>`;
  $("phaseCoverage").innerHTML = table(p.phase_rows || [], [
    {key:"phase",label:"Phase"},{key:"pass",label:"Pass",render:r=>r.pass?'<span class="badge good">PASS</span>':'<span class="badge bad">FAIL</span>'},
    {key:"leaf_coverage",label:"Leaf coverage %"},{key:"mapped_paths",label:"Mapped"},{key:"accounted_nonmutable",label:"Nonmutable"},{key:"unmapped",label:"Unmapped"},
  ]);
  $("rowPlan").innerHTML = table(p.repeatable_row_plan || [], [
    {key:"phase",label:"Phase"},{key:"section",label:"Repeatable section"},{key:"json_rows",label:"JSON rows"},{key:"plus_clicks_from_one_initial_row",label:"+ clicks"},
  ]);
  updateButtons();
}

async function uploadInput(file) {
  const content = await file.text();
  const result = await api("/api/input/upload", { method:"POST", body:JSON.stringify({ filename:file.name, content }) });
  $("inputPath").value = result.path;
  toast(`Using ${result.filename}`);
  await runPreflight(true);
}

async function startMission() {
  try {
    if (!state.preflight) await runPreflight(true);
    if (!state.preflight?.pass || !state.preflight?.autogen?.pass || !state.preflight?.skill_vetting?.pass) throw new Error("Mission is blocked by input/AutoGen/expert-skill vetting. Fix the displayed issues first.");
    if (!state.liveReadiness?.pass) await runLiveReadiness({silent:true});
    if (!state.liveReadiness?.pass || !state.liveReadiness?.token) throw new Error("Live GO/NO-GO readiness is blocked. Fix the live blockers before starting.");
    const payload = missionPayload();
    if (payload.witness_mode && (payload.api_mode === "write" || payload.allow_api_mutation)) throw new Error("Live witness mode is strictly non-mutating. Disable API mutation/write mode.");
    if (payload.witness_mode && payload.save_after_fill) throw new Error("Live witness mode never clicks Save/Submit. Turn it off to save each form after verified fill.");
    if (payload.save_after_fill && payload.save_confirmation !== "ALLOW HIP MUTATION") throw new Error("Save after fill needs the confirmation phrase: ALLOW HIP MUTATION");
    if (payload.api_mode === "write" && !payload.allow_api_mutation) throw new Error("API write mode requires explicit Allow API mutation.");
    const result = await api("/api/mission/start", { method:"POST", body:JSON.stringify(payload) });
    toast(`Mission started (PID ${result.pid})`);
    await refreshStatus();
    showTab("mission");
  } catch (error) { toast(error.message, "bad"); }
}

async function processAction(action) {
  try {
    const result = await api(`/api/discovery/${action}`, { method:"POST", body:"{}" });
    toast(`${action}: ${result.status || "ok"}`);
    await refreshStatus();
  } catch (error) { toast(error.message, "bad"); }
}

function traceStatusClass(status) {
  const s=String(status||"").toLowerCase();
  if (["complete","completed","resumed","pass"].includes(s)) return "good";
  if (["blocked","failed","error"].includes(s)) return "bad";
  if (["running","in_progress"].includes(s)) return "info";
  return "neutral";
}

function compactTraceItems(rows, kind) {
  const items=(rows||[]).slice(-8);
  if (!items.length) return '<div class="empty">No '+esc(kind)+' evidence yet.</div>';
  return `<ul class="trace-list">${items.map(row=>{
    const execution=row.execution||{};
    const details=row.details||{};
    const exec=execution.actual_executor||row.backend||"";
    const planner=execution.planner||"";
    const fallback=execution.fallback_reason||"";
    const semanticId=execution.semantic_control_id||details.semantic_control_id||"";
    const semanticConfidence=execution.semantic_confidence ?? details.confidence ?? details.effect_confidence;
    const semanticStatus=execution.semantic_gate_status||details.status||"";
    const semanticEffect=execution.semantic_effect_type||details.effect_type||"";
    const semanticText=semanticId ? ` • semantic: ${esc(semanticId)}${semanticConfidence!==null&&semanticConfidence!==undefined?` @ ${Number(semanticConfidence).toFixed(2)}`:""}${semanticStatus?` (${esc(semanticStatus)})`:""}${semanticEffect?` → ${esc(semanticEffect)}`:""}` : "";
    const value=kind==="filled" ? ` = <strong>${esc(row.value||"")}</strong>` : "";
    const summary=row.summary||row.target||row.control||row.type||"observed";
    return `<li>${esc(summary)}${value}${planner?` • planner: ${esc(planner)}`:""}${exec?` • <span class="trace-executor">executor: ${esc(exec)}</span>`:""}${semanticText}${fallback?` • <span class="trace-fallback">fallback: ${esc(fallback)}</span>`:""}</li>`;
  }).join("")}</ul>`;
}


function scoreText(value) {
  if (value === null || value === undefined || value === "") return "—";
  const num=Number(value); return Number.isFinite(num) ? num.toFixed(2) : esc(value);
}

function renderAdaptiveMetric(summary) {
  const health=summary?.learning_health||{};
  const score=Math.max(0,Math.min(100,Number(health.learning_score||0)));
  if ($("adaptiveMetric")) $("adaptiveMetric").textContent=`${Math.round(score)}%`;
  if ($("adaptiveDetail")) $("adaptiveDetail").textContent=`${health.fresh_knowledge_count||0} fresh • ${health.stale_knowledge_count||0} stale • ${health.drift_suspect_count||0} drift`;
  if ($("agentLearningHealth")) $("agentLearningHealth").textContent=`${Math.round(score)}%`;
  if ($("agentLearningProgress")) $("agentLearningProgress").style.width=`${score}%`;
  if ($("agentStaleKnowledge")) $("agentStaleKnowledge").textContent=String(health.stale_knowledge_count||0);
  if ($("agentDriftKnowledge")) $("agentDriftKnowledge").textContent=String(health.drift_suspect_count||0);
  if ($("agentFreshKnowledge")) $("agentFreshKnowledge").textContent=String(health.fresh_knowledge_count||0);
}

function visualStage(cur) {
  const stage=String(cur?.visual_overlay?.stage||"").toLowerCase();
  const event=String(cur?.event||"").toLowerCase();
  if (stage==="failed" || event.includes("failed") || cur?.verification?.status==="failed") return "failed";
  if (stage==="verified" || event.includes("verified") || cur?.verification?.status==="verified") return "verified";
  if (stage==="acting" || event.includes("acting") || cur?.execution?.status==="acting") return "acting";
  if (stage==="selected" || event.includes("selected") || event.includes("planner")) return "selecting";
  return "waiting";
}

function renderLiveInputMap(payload) {
  // V243R34: input.json mapped onto the live HIP form, as the agent fills it.
  if (!$("liveInputMapRows")) return;
  const m = (payload && payload.map) || {};
  const rows = m.rows || [];
  if (!payload || !payload.found || !rows.length) { $("liveInputMapState").textContent = "Waiting"; $("liveInputMapState").className = "badge neutral"; return; }
  const state = m.complete ? ["Complete — filling stopped", "good"] : m.busy ? ["Agent is selecting…", "info"] : ["Filling", "info"];
  $("liveInputMapState").textContent = state[0]; $("liveInputMapState").className = `badge ${state[1]}`;
  $("liveInputMapSummary").innerHTML = `<b>Phase</b><span>${esc(m.phase_display || m.phase || "")}</span>`
    + `<b>Exact</b><span>${esc(m.exact || 0)} / ${esc(m.total || 0)}${m.different ? ` • ${esc(m.different)} different` : ""}${m.not_on_screen ? ` • ${esc(m.not_on_screen)} not on screen yet` : ""}${m.invalid ? ` • ${esc(m.invalid)} flagged invalid` : ""}</span>`
    + `<b>Updated</b><span>${esc(String(m.at || "").replace("T", " ").slice(0, 19))}${m.complete_at ? ` • complete at ${esc(String(m.complete_at).replace("T", " ").slice(11, 19))}` : ""}</span>`;
  const badge = { exact: ["✓ exact", "good"], different: ["≠ different", "bad"], not_on_screen: ["… not on screen yet", "neutral"], invalid: ["! invalid", "bad"], not_checked: ["– not checked", "neutral"] };
  $("liveInputMapRows").innerHTML = rows.map(r => {
    const b = badge[r.status] || [r.status, "neutral"];
    const row = r.row === null || r.row === undefined ? "" : ` [row ${Number(r.row) + 1}]`;
    return `<tr><td>${esc(r.input_path || r.field)}</td><td>${esc(r.label || "")}${esc(row)}</td><td>${esc(r.expected ?? "")}</td><td>${esc(r.live ?? "")}</td><td><span class="badge ${b[1]}">${esc(b[0])}</span></td></tr>`;
  }).join("");
}

function renderAgentLiveView(payload) {
  const panel=$("agentLiveViewPanel"), badge=$("agentLiveViewState"), image=$("agentLiveScreenshot"), imageEmpty=$("agentLiveScreenshotEmpty");
  const intent=$("agentLiveIntent"), surface=$("agentLiveSurface"), selected=$("agentLiveSelected"), candidates=$("agentLiveCandidates"), options=$("agentLiveOptions"), memory=$("agentLiveMemory"), memoryHints=$("agentLiveMemoryHints"), planner=$("agentLivePlanner"), execution=$("agentLiveExecution"), verification=$("agentLiveVerification");
  const banner=$("agentVisualStateBanner"), counters=$("agentOverlayCounters"), historyEl=$("agentDecisionHistory");
  if (!panel || !badge) return;
  const view=payload?.live_view||{}; const cur=view?.current||{};
  state.agentLiveView=view; state.agentLiveViewScreenshotUrl=payload?.screenshot_url||"";
  const globalSummary=state.worldModel?.summary||{};
  const currentSummary=cur?.website_memory?.summary||{};
  renderAdaptiveMetric(Object.keys(currentSummary).length?currentSummary:globalSummary);
  if (!payload?.found || !Object.keys(cur).length) {
    badge.textContent="Waiting"; badge.className="badge neutral";
    if (banner) { banner.className="visual-state-banner waiting"; banner.innerHTML='<strong>WAITING</strong><span>Memory proposes; the live page authorizes every action.</span>'; }
    if (counters) counters.innerHTML=['seen','candidate','selected','acting','verified','revealed','failed','foreground'].map(k=>`<div class="visual-counter"><b>0</b><span>${esc(k)}</span></div>`).join("");
    if (intent) intent.innerHTML='<div class="empty">No semantic target has been selected yet.</div>';
    if (surface) surface.innerHTML=""; if(selected) selected.innerHTML=""; if(candidates) candidates.innerHTML='<div class="empty">Candidate ranking will appear before each action.</div>';
    if(options) options.innerHTML='<div class="empty">Dropdown options will appear when a choice control is selected.</div>';
    if(memory) memory.innerHTML=""; if(memoryHints) memoryHints.innerHTML='<div class="empty">Verified website memory will appear after successful actions.</div>';
    if(planner) planner.innerHTML=""; if(execution) execution.innerHTML=""; if(verification) verification.innerHTML="";
    if(historyEl) historyEl.innerHTML='<div class="empty">Decision history will appear during a mission.</div>';
    if (image) image.classList.add("hidden"); if (imageEmpty) imageEmpty.classList.remove("hidden");
    return;
  }
  const event=String(cur.event||"observing"); const stage=visualStage(cur);
  badge.textContent=stage==="failed"?"Failed":stage==="verified"?"Verified":stage==="acting"?"Acting":"Selecting";
  badge.className=`badge ${stage==="failed"?"bad":stage==="verified"?"good":"info"}`;
  if (banner) {
    const copy={selecting:"Live candidates ranked; selected target is being re-proven.",acting:"Final semantic revalidation passed; governed physical action is dispatching.",verified:"Independent effect verification passed; verified semantics may strengthen memory.",failed:"Verification failed; negative evidence lowers confidence and may trigger drift demotion."}[stage]||"Memory proposes; the live page authorizes every action.";
    banner.className=`visual-state-banner ${stage}`; banner.innerHTML=`<strong>${esc(stage.toUpperCase())}</strong><span>${esc(copy)}</span>`;
  }
  const overlay=cur.visual_overlay||{}, counts=overlay.counts||{};
  if(counters) counters.innerHTML=['seen','candidate','selected','acting','verified','revealed','failed','foreground'].map(k=>`<div class="visual-counter"><b>${esc(counts[k]??0)}</b><span>${esc(k)}</span></div>`).join("");
  if (payload?.screenshot_url && image) {
    image.src=`${payload.screenshot_url}${payload.screenshot_url.includes("?")?"&":"?"}_ts=${Date.now()}`;
    image.classList.remove("hidden"); if(imageEmpty) imageEmpty.classList.add("hidden");
  } else { if(image) image.classList.add("hidden"); if(imageEmpty) imageEmpty.classList.remove("hidden"); }
  const sc=cur.selected_control||{}, as=cur.active_surface||{};
  if(intent) intent.innerHTML=`<b>Intent</b><span>${esc(cur.intent||cur.action||"—")}</span><b>Phase</b><span>${esc(cur.phase||"—")}</span><b>Expected</b><span>${esc(cur.expected_value||"—")}</span><b>Event</b><span>${esc(event)}</span><b>Overlay stage</b><span>${esc(overlay.stage||"—")}</span>`;
  if(surface) surface.innerHTML=`<b>Active surface</b><span>${esc(as.label||"—")}</span><b>Role</b><span>${esc(as.role||as.tag||"—")}</span><b>Selected tab</b><span>${esc((as.selected_tabs||[]).join(", ")||"—")}</span><b>Understanding confidence</b><span>${scoreText(as.understanding_confidence)}</span><b>Foreground-owned candidates</b><span>${overlay.foreground_owned_only===true?"Yes":"Current page"}</span>`;
  if(selected) selected.innerHTML=`<b>Selected control</b><span>${esc(sc.label||"—")}</span><b>Section</b><span>${esc(sc.section||"—")}</span><b>Role/type</b><span>${esc([sc.role,sc.control_type].filter(Boolean).join(" / ")||"—")}</span><b>Semantic ID</b><span class="mono-inline">${esc(sc.semantic_control_id||"—")}</span><b>Confidence</b><span>${scoreText(sc.confidence)}${sc.margin!==undefined&&sc.margin!==null?` • margin ${scoreText(sc.margin)}`:""}</span>`;
  const rows=(cur.candidate_ranking||[]);
  if(candidates) candidates.innerHTML=rows.length?table(rows,[
    {key:"rank",label:"#"},
    {key:"label",label:"Candidate / teach",render:r=>`${r.selected?'<span class="candidate-selected">SELECTED</span> ':''}<button class="teach-control-button" onclick="pickTeachControl('${encodeURIComponent(r.semantic_control_id||'')}','${encodeURIComponent(r.label||'')}','${encodeURIComponent(r.section||'')}','${encodeURIComponent(r.role||'')}')">${esc(r.label||r.semantic_control_id||"—")}</button>`},
    {key:"section",label:"Section"},{key:"role",label:"Role"},
    {key:"score",label:"Score",render:r=>scoreText(r.score)},
    {key:"rejection_reason",label:"Decision",render:r=>r.selected?'<span class="good-text">chosen</span>':`<span class="muted">${esc(r.rejection_reason||"lower rank")}</span>`},
  ]):'<div class="empty">No ranked candidates recorded for this action.</div>';
  const opts=cur.current_dropdown_options||[];
  if(options) options.innerHTML=opts.length?`<div class="option-chip-grid">${opts.map(o=>`<span class="option-chip">${esc(o)}</span>`).join("")}</div>`:'<div class="empty">No mounted dropdown/listbox options captured for the selected control.</div>';
  const wm=cur.website_memory||{}, ws=wm.summary||globalSummary||{}, wc=ws.controls||{}, wt=ws.transitions||{}, lh=ws.learning_health||{};
  renderAdaptiveMetric(ws);
  if(memory) memory.innerHTML=`<b>Status</b><span>${esc(wm.status||"new / no prior")}</span><b>Validated controls</b><span>${esc(wc.validated??0)}</span><b>Candidate controls</b><span>${esc(wc.candidate??0)}</span><b>Negative controls</b><span>${esc(wc.negative??0)}</span><b>Semantic states</b><span>${esc(ws.states??0)}</span><b>Validated transitions</b><span>${esc(wt.validated??0)}</span><b>Negative transitions</b><span>${esc(wt.negative??0)}</span><b>Effective confidence</b><span>${scoreText(lh.effective_confidence_average)}</span><b>Policy</b><span>Memory proposes; every action is re-proven live.</span>`;
  const mh=wm.hints||ws.recent_validated_hints||[];
  if(memoryHints) memoryHints.innerHTML=mh.length?table(mh,[
    {key:"trust",label:"Trust"},{key:"action_family",label:"Action"},
    {key:"control",label:"Remembered semantic control",render:r=>esc([r.control?.section,r.control?.label,r.control?.role].filter(Boolean).join(" → ")||"—")},
    {key:"effect_type",label:"Verified effect"},{key:"confidence",label:"Effective confidence",render:r=>scoreText(r.confidence)},
    {key:"age_days",label:"Age",render:r=>r.age_days===undefined?"—":`${esc(r.age_days)}d`},
    {key:"drift_suspect",label:"Drift",render:r=>r.drift_suspect?'<span class="bad-text">suspect</span>':'stable'},
    {key:"success_count",label:"Successes"},
  ]):'<div class="empty">No prior verified transition matched this action yet.</div>';
  const pl=cur.planner||{}; if(planner) planner.innerHTML=`<b>Framework</b><span>${esc(pl.framework||"AutoWebGLM")}</span><b>Aligned</b><span>${pl.aligned===true?"Yes":pl.aligned===false?"No":"Pending"}</span><b>Reason</b><span>${esc(pl.reason||"—")}</span>`;
  const ex=cur.execution||{}; if(execution) execution.innerHTML=`<b>Status</b><span>${esc(ex.status||"pending")}</span><b>Primary executor</b><span>${esc(ex.primary_executor||"—")}</span><b>Actual executor</b><span>${esc(ex.actual_executor||"—")}</span><b>Fallback</b><span>${esc(ex.fallback_reason||"—")}</span><b>Semantic revalidation</b><span>${esc(ex.semantic_revalidation||"—")}</span>`;
  const ve=cur.verification||{}; if(verification) verification.innerHTML=`<b>Status</b><span>${esc(ve.status||"pending")}</span><b>Effect</b><span>${esc(ve.semantic_effect_type||"—")}</span><b>Effect confidence</b><span>${scoreText(ve.semantic_effect_confidence)}</span><b>Exact commit</b><span>${ve.exact_value_commit_verified===true?"Yes":ve.exact_value_commit_verified===false?"No":"Pending"}</span><b>Observed</b><span>${esc(ve.observed_value||"—")}</span>${ve.error?`<b>Error</b><span class="bad-text">${esc(ve.error)}</span>`:""}`;
  const hist=(view.history||[]).slice(-8).reverse();
  if(historyEl) historyEl.innerHTML=hist.length?hist.map(h=>{
    const st=visualStage(h); const control=h.selected_control||{};
    const time=String(h.at||"").replace("T"," ").slice(0,19)||"—";
    return `<div class="decision-row ${esc(st)}"><time>${esc(time)}</time><span class="decision-event">${esc(h.event||"event")}</span><span class="decision-label">${esc(control.label||h.intent||h.action||"—")}</span><span class="decision-state">${esc(st)}</span></div>`;
  }).join(""):'<div class="empty">Decision history will appear during a mission.</div>';
}

function renderMissionTrace(payload) {
  const wrap=$("missionTraceSteps"), badge=$("missionTraceState"), summary=$("missionTraceSummary");
  if (!wrap || !badge || !summary) return;
  const trace=payload?.trace||payload||{};
  if (!trace || !Array.isArray(trace.steps)) {
    badge.textContent="Waiting"; badge.className="badge neutral";
    summary.textContent="No live mission trace yet."; wrap.innerHTML=""; return;
  }
  state.missionTrace=trace;
  badge.textContent=trace.status||"in_progress"; badge.className=`badge ${traceStatusClass(trace.status)}`;
  const runtime=trace.runtime_contract||{};
  summary.textContent=`Run ${trace.run_id||"—"} • ${trace.completed_step_ids?.length||0}/${trace.steps.length} complete • ${runtime.planner||"AutoWebGLM"} planner • ${runtime.primary_safe_action_executor||"PyAutoGUI MCP"} primary executor${runtime.semantic_understanding_enabled?" • semantic action gate ON":""}${runtime.autonomous_all_form_phases?" • autonomous/adaptive ALL PHASES":""}${runtime.playwright_mcp_available===false?" • MCP not yet attached":""}`;
  wrap.innerHTML=trace.steps.map(step=>{
    const status=String(step.status||"queued");
    const fills=step.filled||[], clicks=step.clicked||[], seen=[...(step.observed_controls||[]), ...(step.observed||[])];
    const verify=step.verification||{}, judge=step.judge||{}, handoff=step.handoff||{};
    const blocker=step.blocker||"";
    const missingFields=(judge.missing_fields||[]).slice(0,6);
    const judgeBlockDetail=judge.pass===false && missingFields.length
      ? `Judge missing: ${missingFields.map(x=>`${x.field||"field"}${x.reason?` (${x.reason})`:""}`).join("; ")}`
      : "";
    return `<div class="mission-step ${esc(status)}">
      <div class="mission-step-head"><div class="mission-step-title"><span class="mission-step-id">${esc(step.step_id||"")}</span><strong>${esc(step.label||step.phase||"")}</strong></div><span class="badge ${traceStatusClass(status)}">${esc(status)}</span></div>
      <div class="mission-step-grid">
        <div><b>Activity</b><span>${esc(step.current_activity||"Waiting")}</span></div>
        <div><b>Attempt</b><span>${esc(step.attempt||0)}</span></div>
        <div><b>Observed / Filled / Clicked</b><span>${seen.length} / ${fills.length} / ${clicks.length}</span></div>
        <div><b>Verification</b><span>${verify.pass===true?(verify.status==="pass_with_warnings"?"Pass (warnings)":"Exact pass"):verify.pass===false?"Failed":"Pending"}${judge.pass===true?" • judge pass":judge.pass===false?" • judge fail":""}${judge.multi_model_consensus_used?` • panel ${judge.multi_model_pass_votes||0}/${(judge.multi_model_pass_votes||0)+(judge.multi_model_fail_votes||0)} pass`:''}${judge.human_review_status?` • human ${esc(judge.human_verdict||judge.human_review_status)}`:''}</span></div>
        <div><b>Phase handoff</b><span>${handoff.status?`${esc(handoff.status)} → ${esc(handoff.to_step_id||"")}`:"Pending"}</span></div>
      </div>
      ${blocker?`<div class="help" style="color:#ff9dab"><strong>Blocker:</strong> ${esc(blocker)}</div>`:""}
      ${judgeBlockDetail?`<div class="help" style="color:#ffbf73"><strong>Judge evidence:</strong> ${esc(judgeBlockDetail)}${judge.text_model_status?` • text: ${esc(judge.text_model_status)}`:""}${judge.vision_model_status?` • vision: ${esc(judge.vision_model_status)}`:""}</div>`:""}
      <details><summary>What the agent observed / saw (${seen.length})</summary>${compactTraceItems(seen,"observed")}</details>
      <details><summary>What the agent filled (${fills.length})</summary>${compactTraceItems(fills,"filled")}</details>
      <details><summary>What the agent clicked / executed (${clicks.length})</summary>${compactTraceItems(clicks,"clicked")}</details>
    </div>`;
  }).join("");
}

async function refreshStatus() {
  // V243R25: one poll at a time; a slow poll is skipped, not stacked.
  if (state.refreshing) return;
  state.refreshing = true;
  try {
    const [runtime, process, runs, tracePayload, liveViewPayload, worldModelPayload, liveInputMapPayload] = await Promise.all([
      api(`/api/runtime/status?config=${encodeURIComponent($("configPath").value || "config.yaml")}`, {timeoutMs:20000}),
      api("/api/discovery/status", {timeoutMs:20000}),
      api(`/api/runs?config=${encodeURIComponent($("configPath").value || "config.yaml")}&runs_dir=${encodeURIComponent($("runsDir").value || "./runs")}&limit=25`).catch(()=>({runs:[],count:0})),
      api(`/api/mission/trace?config=${encodeURIComponent($("configPath").value || "config.yaml")}&runs_dir=${encodeURIComponent($("runsDir").value || "./runs")}`).catch(()=>({found:false,trace:{}})),
      api(`/api/mission/live-view?config=${encodeURIComponent($("configPath").value || "config.yaml")}&runs_dir=${encodeURIComponent($("runsDir").value || "./runs")}`).catch(()=>({found:false,live_view:{},screenshot_url:""})),
      api(`/api/mission/world-model?config=${encodeURIComponent($("configPath").value || "config.yaml")}`).catch(()=>({found:false,summary:{}})),
      api(`/api/mission/live-input-map?config=${encodeURIComponent($("configPath").value || "config.yaml")}&runs_dir=${encodeURIComponent($("runsDir").value || "./runs")}`).catch(()=>({found:false,map:{}})),
    ]);
    state.runtime = runtime; state.process = process; state.runs = runs.runs || []; state.missionTrace = tracePayload.trace || null; state.worldModel = worldModelPayload || null;
    state.statusFailures = 0;
    if (!state.certFollowing) {
      // A certification started by Live GO/NO-GO (auto refresh) shows its progress too.
      api("/api/mission/live-runtime-certification/status", {timeoutMs:10000}).then(job=>{
        if (job?.status==="running") { renderCertificationJob(job); followCertificationJob(); }
      }).catch(()=>{});
    }
    // V243R34: name the status parts that failed (each part is computed on its own).
    const failedParts = Object.keys(runtime.section_errors || {});
    $("backendBadge").textContent = runtime.degraded
      ? (failedParts.length ? `Backend ready (${failedParts.length} status part${failedParts.length>1?"s":""} failed)` : "Backend ready (partial status)")
      : "Backend ready";
    $("backendBadge").className = `badge ${runtime.degraded ? "info" : "good"}`;
    if ($("backendBadge")) $("backendBadge").title = runtime.status_error || "";
    const ag = runtime.autogen || {};
    $("autogenBadge").textContent = ag.pass ? "AutoGen 0.7.5" : (ag.status_error || !runtime.autogen ? "AutoGen status unavailable" : "AutoGen blocked");
    if ($("autogenBadge")) $("autogenBadge").title = ag.status_error || (ag.errors || []).join("; ") || "";
    $("autogenBadge").className = `badge ${ag.pass ? "good" : "bad"}`;
    const procText = process.paused ? "Paused" : process.running ? "Running" : "Stopped";
    $("processMetric").textContent = procText;
    $("pidMetric").textContent = process.pid ? `PID ${process.pid}` : "PID —";
    $("liveState").textContent = procText; $("liveState").className = `badge ${process.running ? (process.paused?"info":"good") : "neutral"}`;
    $("runsMetric").textContent = String(runs.count || state.runs.length);
    $("apiMetric").textContent = $("apiMode").value;
    const mf=runtime.mlflow||{};
    const si=runtime.skill_induction||{};
    const rp=runtime.replay_policy||{};
    const mp=runtime.model_portfolio||{};
    const ri=runtime.recursive_self_improvement||{};
    if ($("skillsMetric")) {
      // V243R22: certified form skills (proven by a deterministic replay) count too.
      const ps=runtime.portal_skills||{};
      $("skillsMetric").textContent = !si.enabled ? "Off" : String((si.validated_skill_count||0)+(ps.certified||0));
      $("skillsDetail").textContent = si.enabled ? `${ps.certified||0} certified forms • ${ps.candidate||0} learning • ${si.skill_count||0} task skills • ${(si.stale_skill_count||0)+(ps.stale||0)} stale` : "skill induction disabled";
    }
    if ($("mlflowMetric")) {
      $("mlflowMetric").textContent = !mf.enabled ? "Off" : (mf.package_available ? "Async ready" : "Unavailable");
      $("mlflowDetail").textContent = mf.enabled ? `${mf.version||"MLflow"} • ${mf.experiment_name||"HIP Portal Agent"}` : "observability disabled";
    }
    if ($("policyMetric")) {
      $("policyMetric").textContent = !rp.enabled ? "Off" : `${rp.exploitation_policy_count||0}/${rp.policy_count||0}`;
      $("policyDetail").textContent = rp.enabled ? `${rp.episode_count||0} episodes • ${rp.hybrid_policy_count||0} hybrid • v${rp.active_policy_version||0}` : "replay policy disabled";
    }
    if ($("modelPortfolioMetric")) {
      const champs=mp.role_champions||{};
      // V243R22: show the model actually answering default calls; the champion
      // is re-earned from fairly scored decisions (see the detail line).
      const champ=champs.planning||champs.action_selection||"";
      const scored=Object.values(mp.scored_decisions||{}).reduce((a,b)=>a+Number(b||0),0);
      $("modelPortfolioMetric").textContent = !mp.enabled ? "Off" : (mp.default_text_model||champ||"Learning");
      // V243R24: a model selected once by live task performance is used everywhere.
      const q=mp.qualification||{};
      // V243R29: all models are re-validated on navigation + completion judgments.
      const jr=q.live_judge_record||{};
      $("modelPortfolioDetail").textContent = !mp.enabled ? "model portfolio disabled" : (q.locked
        ? `champion by live task: ${q.correct||0}/${q.total||0} correct${q.judge_total?` • judged ${q.judge_correct||0}/${q.judge_total}`:""} • ${String(q.qualified_at||"").slice(0,10)}${q.in_use&&q.in_use!==q.selected_model?" • fallback "+q.in_use:""}${(jr.correct||jr.wrong)?` • live verdicts ${jr.correct||0}✓ ${jr.wrong||0}✗`:""}${q.needs_revalidation?" • re-validation due":""}`
        : `not qualified yet (runs on Live certification) • ${champ ? "champion "+champ : "champion: earning"} • ${scored} scored decisions`);
      // V243R36: why this model is the champion, and why each other model is not.
      $("modelPortfolioDetail").title = q.locked ? [`${q.selected_model}: ${q.selection_reason||""}`, ...(q.ranking||[]).filter(r=>r.model!==q.selected_model).map(r=>`${r.model}: ${r.why||""}`)].join("\n") : "";
    }
    if ($("runHistoryMetric")) {
      // V243R27: what the missions learned from past runs (folders and MLflow).
      const rh=runtime.run_history_learning||{};
      $("runHistoryMetric").textContent = rh.enabled===false ? "Off" : (rh.runs_learned ? `${rh.runs_learned} runs` : "Not yet");
      $("runHistoryDetail").textContent = rh.enabled===false ? "run-history learning disabled" : (rh.runs_learned
        ? `${rh.lesson_count||0} lessons in use • ${rh.runs_from_mlflow||0} from MLflow`
        : "learns at the next mission start");
    }
    if ($("editSectionsMetric")) {
      // V243R30: the Edit sections the agent knows (listing > expand > Edit, every field).
      const es=runtime.edit_sections||{};
      const known=(es.phases||[]).filter(p=>p.known);
      $("editSectionsMetric").textContent = es.total ? `${es.known||0}/${es.total} phases` : "Not yet";
      // V243R31: Clone / Deploy / Migrate sections too.
      const acts=es.actions||{};
      const actLine=["clone","deploy","migrate"].filter(a=>acts[a]).map(a=>`${a} ${acts[a].known||0}/${acts[a].total||0}`).join(" • ");
      $("editSectionsDetail").textContent = known.length
        ? known.slice(0,2).map(p=>`${p.title||p.phase}: ${p.fields||0} fields${(p.tabs||[]).length?`, ${p.tabs.length} tabs`:""}`).join(" • ") + (actLine?` • ${actLine}`:"")
        : (actLine || "learn-action-sections, or ask: capture the edit values of <object>");
    }
    if ($("recursiveMetric")) {
      $("recursiveMetric").textContent = !ri.enabled ? "Off" : `Cycle ${ri.cycle||0}`;
      $("recursiveDetail").textContent = ri.enabled ? `best ${Number(ri.best_reward||0).toFixed(3)} • plateau ${ri.plateau_count||0}` : "recursive improvement disabled";
    }
    // V243R34: "Off" only when a feature is really switched off. A status part that
    // failed shows its error; a part the backend did not send shows "—".
    for (const [metric, detail, part] of [
      ["skillsMetric", "skillsDetail", runtime.skill_induction], ["mlflowMetric", "mlflowDetail", runtime.mlflow],
      ["policyMetric", "policyDetail", runtime.replay_policy], ["modelPortfolioMetric", "modelPortfolioDetail", runtime.model_portfolio],
      ["recursiveMetric", "recursiveDetail", runtime.recursive_self_improvement], ["runHistoryMetric", "runHistoryDetail", runtime.run_history_learning],
      ["editSectionsMetric", "editSectionsDetail", runtime.edit_sections]]) {
      if (!$(metric)) continue;
      if (part && part.status_error) { $(metric).textContent = "Error"; $(detail).textContent = `status part failed: ${part.status_error}`.slice(0, 180); }
      else if (part === undefined) { $(metric).textContent = "—"; $(detail).textContent = "status not available (see the backend badge)"; }
    }
    $("console").textContent = process.console_tail || "Waiting for mission output…";
    $("console").scrollTop = $("console").scrollHeight;
    $("processDetails").innerHTML = `<b>Status</b><span>${esc(procText)}</span><b>PID</b><span>${esc(process.pid || "—")}</span><b>Runs dir</b><span>${esc(process.runs_dir || "—")}</span><b>Command</b><span>${esc((process.command || []).join(" "))}</span>`;
    renderRuns(); renderMissionTrace(tracePayload); renderAgentLiveView(liveViewPayload); renderLiveInputMap(liveInputMapPayload); renderAdaptiveMetric(worldModelPayload?.summary||{}); updateButtons();
  } catch (error) {
    // V243R25: "offline" only when the backend is really unreachable or three
    // polls in a row failed; one slow answer shows "Backend busy".
    state.statusFailures = (state.statusFailures || 0) + 1;
    const unreachable = /Cannot reach the backend|backend is unavailable|503/i.test(String(error?.message || ""));
    const offline = unreachable || state.statusFailures >= 3;
    $("backendBadge").textContent = offline ? "Backend offline" : "Backend busy"; $("backendBadge").className = `badge ${offline ? "bad" : "info"}`;
    $("backendBadge").title = String(error?.message || "");
    if (offline) $("processMetric").textContent = "Offline";
  } finally {
    state.refreshing = false;
  }
}

function updateButtons() {
  const running = !!state.process?.running;
  const paused = !!state.process?.paused;
  const ready = !!state.preflight?.pass && !!state.preflight?.autogen?.pass && !!state.liveReadiness?.pass && !!state.liveReadiness?.token;
  $("startBtn").disabled = running || !ready;
  $("pauseBtn").disabled = !running || paused;
  $("resumeBtn").disabled = !running || !paused;
  $("stopBtn").disabled = !running;
}

function renderRuns() {
  $("runsList").innerHTML = state.runs.length ? state.runs.map(r=>`<div class="run"><strong>${esc(r.run_id)}</strong><span>${esc(r.path)}</span></div>`).join("") : '<div class="empty">No runs discovered.</div>';
}

async function loadCapabilities() {
  try {
    const qs = new URLSearchParams({ config: $("configPath").value || "config.yaml", page_family: $("capFamily").value, text: $("capSearch").value });
    const data = await api(`/api/capabilities?${qs}`);
    const m=data.manifest||{}; $("capabilitySummary").textContent=`${data.count||0} shown • ${m.capability_count||0} total • ${m.bootstrap_source_count||0} canonical seed source(s) • live successes are marked validated_live`;
    $("capabilitiesTable").innerHTML = table(data.capabilities || [], [
      {key:"capability_id",label:"ID"},{key:"page_family",label:"Family"},{key:"label",label:"Capability"},{key:"action",label:"Action"},{key:"knowledge_source",label:"Source"},{key:"trust",label:"Trust"},{key:"verified",label:"Live verified"},
    ]);
  } catch(e){ toast(e.message,"bad"); }
}

async function loadApis() {
  try {
    const qs = new URLSearchParams({ config: $("configPath").value || "config.yaml", page_family: $("apiFamily").value, method: $("apiMethod").value });
    const data = await api(`/api/apis?${qs}`);
    const m=data.manifest||{}; $("apiSummary").textContent=`${data.count||0} shown • ${m.api_contract_count||0} total • canonical contracts are available immediately and live network observations update trust`;
    $("apisTable").innerHTML = table(data.api_contracts || [], [
      {key:"method",label:"Method"},{key:"endpoint",label:"Endpoint",render:r=>esc(r.endpoint || r.endpoint_template || r.url || "")},{key:"response_statuses",label:"Statuses",render:r=>esc((r.response_statuses||[]).join(", ") || "—")},{key:"page_families",label:"Families",render:r=>esc((r.page_families||[]).join(", "))},{key:"knowledge_source",label:"Source"},{key:"trust",label:"Trust"},
    ]);
  } catch(e){ toast(e.message,"bad"); }
}

function taskRequest(task) { return {
  task, config:$("configPath").value||"config.yaml", runs_dir:$("runsDir").value||"./runs",
  input_json:$("taskInputJson").value.trim()||"./input.json", input_root:$("taskInputRoot").value.trim(),
  start_url:$("taskStartUrl").value.trim(), deep_learn:$("taskDeepLearn").checked,
  allow_portal_mutation:$("taskAllowMutation").checked, confirmation:$("taskMutationConfirmation").value.trim(),
  operator_role:$("taskOperatorRole")?.value.trim()||"", approval_id:$("taskApprovalId")?.value.trim()||"",
  force_repeat_mutation:!!$("taskForceRepeatMutation")?.checked, allow_adaptive_exploration:true
}; }
async function taskAction(kind) {
  try {
    const task=$("taskText").value.trim(); if(!task) throw new Error("Enter a task first.");
    const data=await api(`/api/portal-task/${kind}`,{method:"POST",body:JSON.stringify(taskRequest(task))});
    $("taskOutput").textContent=JSON.stringify(data,null,2); if(kind==="run") showTab("mission");
  } catch(e){$("taskOutput").textContent=e.message;toast(e.message,"bad");}
}


function productionTaskRequest(task) {
  const base=taskRequest(task);
  return {
    task, config:base.config, input_json:base.input_json, input_root:base.input_root,
    start_url:base.start_url, runs_dir:base.runs_dir, golden_dir:$("goldenDir").value.trim(),
    uploads_dir:$("uploadsDir").value.trim(), deep_learn:base.deep_learn,
    allow_portal_mutation:base.allow_portal_mutation, confirmation:base.confirmation,
    operator_role:base.operator_role, approval_id:base.approval_id,
    force_repeat_mutation:base.force_repeat_mutation, mutation_expected:base.allow_portal_mutation
  };
}
async function productionAction(kind) {
  try {
    const task=$("taskText").value.trim(); if(!task) throw new Error("Enter a task first.");
    const payload=productionTaskRequest(task);
    const data=await api(`/api/production/${kind}`,{method:"POST",body:JSON.stringify(payload)});
    $("taskOutput").textContent=JSON.stringify(data,null,2);
    if(kind==="start"){toast(`Production E2E started (PID ${data.pid||"—"})`);showTab("mission");}
    else toast(data.pass?"Production doctor: GO":"Production doctor: NO-GO",data.pass?"good":"bad");
  } catch(e){$("taskOutput").textContent=e.message;toast(e.message,"bad");}
}

async function loadSkillLibrary() {
  try {
    const qs=new URLSearchParams({
      config:$('configPath').value||'config.yaml',
      query:$('skillLibrarySearch')?.value||'',
      status:$('skillLibraryStatus')?.value||'',
      limit:'100'
    });
    const data=await api(`/api/skills?${qs}`), m=data.manifest||{};
    if ($('skillLibrarySummary')) $('skillLibrarySummary').textContent=`${m.skill_count||0} skills • ${m.validated_skill_count||0} validated • ${m.drift_suspect_count||0} drift suspect • ${m.stale_skill_count||0} stale`;
    if ($('skillLibraryTable')) $('skillLibraryTable').innerHTML=table(data.skills||[],[
      {key:'name',label:'Skill'},
      {key:'status',label:'Status'},
      {key:'effective_confidence',label:'Effective confidence',render:r=>scoreText(r.effective_confidence)},
      {key:'success_count',label:'Successes'},
      {key:'failure_count',label:'Failures'},
      {key:'age_days',label:'Age (days)',render:r=>esc(Number(r.age_days||0).toFixed(1))},
      {key:'last_success_at',label:'Last verified'}
    ]);
  } catch(e){ if($('skillLibraryTable')) $('skillLibraryTable').innerHTML=`<div class="empty">${esc(e.message)}</div>`; }
}

async function loadReplayPolicy() {
  try {
    const qs=new URLSearchParams({config:$('configPath').value||'config.yaml',limit:'100'});
    const data=await api(`/api/replay-policy?${qs}`), m=data.manifest||{};
    if ($('replayPolicySummary')) $('replayPolicySummary').textContent=`${m.episode_count||0} replay episodes • ${m.policy_count||0} learned policies • ${m.exploitation_policy_count||0} exploitation • ${m.hybrid_policy_count||0} hybrid • ${m.exploration_policy_count||0} exploration`;
    if ($('replayPolicyTable')) $('replayPolicyTable').innerHTML=table(data.policies||[],[
      {key:'mode',label:'Mode'},
      {key:'winner',label:'Dream winner'},
      {key:'confidence',label:'Confidence',render:r=>scoreText(r.confidence)},
      {key:'support',label:'Runs'},
      {key:'success_rate',label:'Success rate',render:r=>scoreText(r.success_rate)},
      {key:'average_score',label:'Avg score',render:r=>scoreText(r.average_score)},
      {key:'workflow_step_count',label:'Fast steps'},
      {key:'policy_version',label:'Policy v'}
    ]);
    if ($('replayRunHistory')) $('replayRunHistory').textContent=JSON.stringify({old_run_import:data.old_run_import,recent_runs:m.recent_runs||[],cache:m.policy_cache_path,dreams:m.dream_cycles_path},null,2);
  } catch(e){ if($('replayPolicyTable')) $('replayPolicyTable').innerHTML=`<div class="empty">${esc(e.message)}</div>`; }
}



window.pickTeachControl = function(id,label,section,role){
  const control={semantic_control_id:decodeURIComponent(id||''),label:decodeURIComponent(label||''),section:decodeURIComponent(section||''),role:decodeURIComponent(role||'')};
  state.humanSelectedControl=control;
  if($('humanSemanticControl')) $('humanSemanticControl').value=control.semantic_control_id || control.label || '';
  if($('humanControlLabel')) $('humanControlLabel').value=control.label||'';
  if($('humanControlSection')) $('humanControlSection').value=control.section||'';
  if($('humanControlRole')) $('humanControlRole').value=control.role||'';
  toast(`Selected live control: ${control.label||control.semantic_control_id||'control'}`, 'info');
};

async function loadInteractiveTeaching(){
  try{
    const qs=new URLSearchParams({config:$('configPath').value||'config.yaml'});
    const data=await api(`/api/interactive-teaching?${qs}`); state.interactiveTeaching=data;
    const active=(data.active||[])[0]||null; state.interactiveTeachingSession=active;
    const badge=$('interactiveTeachState');
    if(!badge) return;
    if(!active){badge.textContent='Interactive teaching idle';badge.className='badge neutral';return;}
    badge.textContent=active.status==='recording'?`Recording ${active.phase||'HIP'} demonstration`:`Teaching captured; waiting for agent reproof`;
    badge.className='badge info';
  }catch(e){ if($('interactiveTeachState')){$('interactiveTeachState').textContent='Teaching unavailable';$('interactiveTeachState').className='badge bad';} }
}

async function startInteractiveTeaching(){
  try{
    const review=state.humanPhaseReviewRequest||{};
    const missionRun=(state.missionTrace&&state.missionTrace.run_id)||review.run_id||'';
    const phase=review.phase||'';
    if(!missionRun) throw new Error('Start a mission before interactive teaching.');
    const data=await api('/api/interactive-teaching/start',{method:'POST',body:JSON.stringify({
      run_id:missionRun,phase,task:`Teach ${review.phase_display||phase||'current HIP flow'}`,note:$('humanTeachNote')?.value||'',config:$('configPath').value||'config.yaml'
    })});
    state.interactiveTeachingSession=data.session||null;
    toast('Interactive teaching started. Use the real HIP browser and navigate/click the correct path; then return here and press Finish & learn.','info');
    await loadInteractiveTeaching();
  }catch(e){toast(e.message,'bad');}
}

async function finishInteractiveTeaching(){
  try{
    const session=state.interactiveTeachingSession||{};
    if(!session.session_id) throw new Error('No interactive teaching session is recording.');
    const data=await api('/api/interactive-teaching/finish',{method:'POST',body:JSON.stringify({
      session_id:session.session_id,note:$('humanTeachNote')?.value||'',config:$('configPath').value||'config.yaml'
    })});
    state.interactiveTeachingSession=data.session||session;
    toast('Demonstration finished. Now press Looks correct after the page is correct; the agent will capture, exact-reprove and promote this path.','good');
    await loadInteractiveTeaching();
  }catch(e){toast(e.message,'bad');}
}

async function loadHumanAssistance(){
  try{
    const qs=new URLSearchParams({config:$('configPath').value||'config.yaml'});
    const data=await api(`/api/human-assistance?${qs}`); state.humanAssistance=data;
    const req=(data.pending||[])[0]||null; const badge=$('humanAssistState'), reason=$('humanAssistReason'), select=$('humanInputPath');
    if(!req){
      if(badge){badge.textContent='No request';badge.className='badge neutral';}
      if(reason) reason.textContent='No field currently needs human teaching.';
      if(select) select.innerHTML='<option value="">No unresolved field</option>';
      return;
    }
    if(badge){badge.textContent='Needs assistance';badge.className='badge info';}
    revealHumanAssistance(false);
    if(reason) reason.textContent=req.reason||req.instruction||'Choose the correct live control.';
    if(select){select.innerHTML=(req.unresolved_input_paths||[]).map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join(''); select.dataset.requestId=req.request_id||'';}
  }catch(e){ if($('humanAssistState')){$('humanAssistState').textContent='Unavailable';$('humanAssistState').className='badge bad';} }
}

async function loadHumanPhaseReview(){
  try{
    const qs=new URLSearchParams({config:$('configPath').value||'config.yaml'});
    const data=await api(`/api/human-phase-review?${qs}`); state.humanPhaseReview=data;
    const req=(data.pending||[])[0]||null; const badge=$('humanPhaseReviewState'), reason=$('humanPhaseReviewReason'), meta=$('humanPhaseReviewMeta');
    if(!req){
      state.humanPhaseReviewRequest=null;
      if(badge){badge.textContent='No review';badge.className='badge neutral';}
      if(reason) reason.textContent='No newly learned phase is waiting for human confirmation.';
      if(meta) meta.textContent='';
      return;
    }
    state.humanPhaseReviewRequest=req;
    revealHumanAssistance(false);
    const verdict=(req.automated_verdict||'').toUpperCase();
    if(badge){badge.textContent=`Review ${req.phase_display||req.phase||''}`;badge.className='badge info';}
    if(reason) reason.textContent=req.reason||req.instruction||'Review the newly learned phase once.';
    if(meta) meta.textContent=`Automated: ${verdict||'UNKNOWN'} • deterministic: ${req.deterministic_pass?'PASS':'not proven'} • exact checkpoint: ${req.exact_checkpoint_pass?'PASS':'not proven'}${req.model_consensus?.used?` • model panel ${req.model_consensus.pass_votes||0}/${req.model_consensus.vote_count||0} pass`:''}`;
  }catch(e){ if($('humanPhaseReviewState')){$('humanPhaseReviewState').textContent='Unavailable';$('humanPhaseReviewState').className='badge bad';} }
}

async function submitHumanPhaseReview(verdict){
  try{
    const req=state.humanPhaseReviewRequest||{};
    if(!req.request_id) throw new Error('No phase review is currently pending.');
    const data=await api('/api/human-phase-review/resolve',{method:'POST',body:JSON.stringify({
      request_id:req.request_id,verdict,note:$('humanPhaseReviewNote')?.value||'',reviewer:'control-center-user',config:$('configPath').value||'config.yaml'
    })});
    toast(verdict==='pass'?'Phase confirmed. The agent can continue and learn from this approval.':'Correction recorded. The self-heal/policy loop will treat this as supervised failure evidence.',verdict==='pass'?'good':'info');
    if($('humanPhaseReviewNote')) $('humanPhaseReviewNote').value='';
    await loadHumanPhaseReview();
    await loadInteractiveTeaching();
    return data;
  }catch(e){toast(e.message,'bad');}
}

async function submitHumanTeaching(){
  try{
    const select=$('humanInputPath'); const requestId=select?.dataset?.requestId||''; const inputPath=select?.value||'';
    const control=state.humanSelectedControl||{};
    if(!requestId||!inputPath) throw new Error('No unresolved assistance request is selected.');
    if(!(control.semantic_control_id||control.label)) throw new Error('Click the correct candidate/control in Agent Live View first.');
    const data=await api('/api/human-assistance/teach',{method:'POST',body:JSON.stringify({
      request_id:requestId,input_path:inputPath,semantic_control_id:control.semantic_control_id||'',control_label:control.label||'',section:control.section||'',role:control.role||'',note:$('humanTeachNote')?.value||'',verified_by_human:true,config:$('configPath').value||'config.yaml'
    })});
    toast('Teaching recorded. Retry/resume the task; this mapping will be live re-proved before use.','good');
    state.humanSelectedControl=null; if($('humanSemanticControl')) $('humanSemanticControl').value=''; await loadHumanAssistance();
    return data;
  }catch(e){toast(e.message,'bad');}
}

async function loadModelPortfolio() {
  try {
    const qs=new URLSearchParams({config:$('configPath').value||'config.yaml'});
    const data=await api(`/api/model-portfolio?${qs}&probe=true`), m=data.manifest||{}, rows=[];
    const rankings=m.rankings||{};
    Object.keys(rankings).sort().forEach(role=>{
      (rankings[role]||[]).forEach((r,i)=>rows.push({role,rank:i+1,model:r.model,score:r.score,trials:r.trials,champion:(m.role_champions||{})[role]===r.model?'yes':''}));
    });
    if ($('modelPortfolioSummary')) $('modelPortfolioSummary').textContent=`${(m.text_models||[]).length} configured text • ${(m.available_text_models||[]).length} available • ${(m.recent_distinct_models||[]).length} recently used • ${(m.vision_models||[]).length} vision • cycle ${m.cycle||0} • learning=${m.learning_forces_portfolio?'multi-model':'adaptive'}`;
    if ($('modelPortfolioTable')) $('modelPortfolioTable').innerHTML=table(rows,[
      {key:'role',label:'Role'},{key:'rank',label:'#'},{key:'model',label:'Model'},{key:'score',label:'Score',render:r=>scoreText(r.score)},{key:'trials',label:'Trials'},{key:'champion',label:'Champion'}
    ]);
  } catch(e){ if($('modelPortfolioTable')) $('modelPortfolioTable').innerHTML=`<div class="empty">${esc(e.message)}</div>`; }
}

async function loadRecursiveImprovement() {
  try {
    const qs=new URLSearchParams({config:$('configPath').value||'config.yaml'});
    const data=await api(`/api/recursive-improvement?${qs}`);
    if ($('recursiveImprovementState')) $('recursiveImprovementState').textContent=JSON.stringify(data,null,2);
  } catch(e){ if($('recursiveImprovementState')) $('recursiveImprovementState').textContent=e.message; }
}

function renderRunHistory(data) {
  const summary=data?.summary||{}; const lessons=data?.lessons||{};
  if ($('runHistorySummary')) {
    const mf=lessons.mlflow||summary.mlflow||{};
    $('runHistorySummary').textContent = summary.runs_learned
      ? `${summary.summary}. MLflow: ${({ok:"read", no_store:"no MLflow runs recorded yet", no_experiment:"no HIP runs in MLflow yet", mlflow_not_installed:"not installed (run folders only)", timeout:"did not answer in time", disabled:"disabled", skipped:"not read"})[mf.status]||mf.status||"not read"}${mf.status==="ok"?` (${mf.new_runs||0} new run(s))`:""}. Learned ${String(lessons.derived_at||summary.derived_at||"").slice(0,19).replace("T"," ")}.`
      : "Nothing learned yet: the next mission reads the past runs first (or click Learn now).";
  }
  const reasons=lessons.reasons||summary.reasons||[];
  const phases=lessons.phases||{};
  const rows=reasons.map(r=>`<tr><td>${esc(r.phase||r.module||"")}</td><td>${esc(r.lesson)}</td><td>${esc(r.value)} s</td><td>${esc(r.why)}</td></tr>`).join("");
  const phaseRows=Object.entries(phases).map(([p,r])=>`<tr><td>${esc(p)}</td><td>${esc(r.completed)}/${esc(r.runs)}</td><td>${esc(r.p90_completed_attempt_seconds??"")}</td><td>${esc((r.top_failure_codes||[]).slice(0,3).map(x=>`${x[0]} ×${x[1]}`).join(", "))}</td><td>${esc((r.fields_that_failed||[]).slice(0,3).map(x=>`${x[0]} ×${x[1]}`).join(", "))}</td></tr>`).join("");
  if ($('runHistoryTable')) $('runHistoryTable').innerHTML = (rows||phaseRows)
    ? `<table><thead><tr><th>Phase / module</th><th>Lesson</th><th>Now</th><th>Why</th></tr></thead><tbody>${rows||'<tr><td colspan="4">No budget change needed.</td></tr>'}</tbody></table>`
      + (phaseRows ? `<table style="margin-top:14px"><thead><tr><th>Phase</th><th>Completed</th><th>p90 attempt (s)</th><th>What stopped it</th><th>Fields that failed</th></tr></thead><tbody>${phaseRows}</tbody></table>` : "")
    : '<div class="empty">Nothing learned yet.</div>';
}
async function loadRunHistory(learn) {
  try {
    const qs=new URLSearchParams({config:$('configPath').value||'config.yaml'});
    const data=learn ? await api(`/api/learning/run-history/refresh?${qs}`,{method:"POST",timeoutMs:120000}) : await api(`/api/learning/run-history?${qs}`);
    renderRunHistory(data);
  } catch(e){ if($('runHistorySummary')) $('runHistorySummary').textContent=e.message; }
}

function changeRequest() { return { task:$("changeText").value.trim(), config:$("configPath").value||"config.yaml", runs_dir:$("runsDir").value||"./runs", allow_adaptive_exploration:true, operator_role:$("operatorRole").value.trim(), approval_id:$("approvalId").value.trim(), allow_portal_mutation:$("allowPortalMutation").checked, confirmation:$("mutationConfirmation").value }; }
async function changeAction(kind) {
  try { const payload=changeRequest(); if(!payload.task) throw new Error("Describe the change first."); const data=await api(`/api/governed-change/${kind}`,{method:"POST",body:JSON.stringify(payload)}); $("governanceOutput").textContent=JSON.stringify(data,null,2); if(kind==="run") showTab("mission"); }
  catch(e){$("governanceOutput").textContent=e.message;toast(e.message,"bad");}
}
async function loadAudit(){try{$("governanceOutput").textContent=JSON.stringify(await api(`/api/governed-change/audit?config=${encodeURIComponent($("configPath").value||"config.yaml")}&limit=50`),null,2)}catch(e){toast(e.message,"bad")}}

function showTab(name, {remember = true, focus = false} = {}) {
  if (!document.getElementById(name)?.classList.contains("tab-panel")) return;
  document.querySelectorAll(".tabs button").forEach(b => {
    const on = b.dataset.tab === name;
    b.classList.toggle("active", on); b.setAttribute("aria-selected", on ? "true" : "false"); b.tabIndex = on ? 0 : -1;
    if (on && focus) b.focus({preventScroll: true});
    // Bring the tab into view inside the tab strip only (never scroll the page).
    const bar = b.parentElement;
    if (on && bar && bar.scrollWidth > bar.clientWidth) {
      const left = b.getBoundingClientRect().left - bar.getBoundingClientRect().left + bar.scrollLeft, right = left + b.offsetWidth;
      if (left < bar.scrollLeft) bar.scrollLeft = Math.max(0, left - 12);
      else if (right > bar.scrollLeft + bar.clientWidth) bar.scrollLeft = right - bar.clientWidth + 12;
    }
  });
  document.querySelectorAll(".tab-panel").forEach(p=>p.classList.toggle("active",p.id===name));
  // V243R37: the open tab is remembered (and linkable: #mission).
  if (remember) { try { localStorage.setItem("hipTab", name); history.replaceState(null, "", `#${name}`); } catch {} }
}

// V243R37: layout -- the sidebar collapses (a drawer below 1100 px), tabs work with the
// keyboard, tiles show their full text on hover and a colour for their state, and the
// docked chat can be resized.
const DRAWER_QUERY = "(max-width: 1099px)";
function initLayout() {
  const shell = document.querySelector(".shell"), btn = $("sideToggleBtn");
  const drawer = () => window.matchMedia(DRAWER_QUERY).matches;
  let collapsed = false; try { collapsed = localStorage.getItem("hipSideCollapsed") === "1"; } catch {}
  const apply = () => {
    shell?.classList.toggle("side-collapsed", !drawer() && collapsed);
    if (!drawer()) shell?.classList.remove("side-open");
    btn?.setAttribute("aria-expanded", String(drawer() ? !!shell?.classList.contains("side-open") : !collapsed));
  };
  const closeDrawer = () => { shell?.classList.remove("side-open"); apply(); };
  $("sideCloseBtn")?.addEventListener("click", closeDrawer);
  btn?.addEventListener("click", () => {
    if (drawer()) shell?.classList.toggle("side-open");
    else { collapsed = !collapsed; try { localStorage.setItem("hipSideCollapsed", collapsed ? "1" : "0"); } catch {} }
    apply();
  });
  $("sideBackdrop")?.addEventListener("click", closeDrawer);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && shell?.classList.contains("side-open")) closeDrawer(); });
  window.matchMedia(DRAWER_QUERY).addEventListener?.("change", closeDrawer);
  // Starting, pausing or stopping from the drawer closes it, so the dashboard is in view.
  ["startBtn", "pauseBtn", "resumeBtn", "stopBtn"].forEach(id => $(id)?.addEventListener("click", () => { if (drawer()) closeDrawer(); }));
  apply();

  const tabs = [...document.querySelectorAll(".tabs button[data-tab]")];
  $("tabs")?.addEventListener("keydown", (e) => {
    const i = tabs.indexOf(document.activeElement); if (i < 0) return;
    const next = {ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabs.length - 1}[e.key];
    if (next === undefined) return;
    e.preventDefault(); showTab(tabs[(next + tabs.length) % tabs.length].dataset.tab, {focus: true});
  });
  let initial = (location.hash || "").slice(1);
  if (!initial) { try { initial = localStorage.getItem("hipTab") || ""; } catch { initial = ""; } }
  if (initial) showTab(initial, {remember: false});
  window.addEventListener("hashchange", () => showTab((location.hash || "").slice(1), {remember: false}));

  initSideSections();
  initMetricTiles();
  initChatResize();
  document.addEventListener("keydown", (e) => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || "") || document.activeElement?.isContentEditable;
    if (e.key !== "/" || typing || e.ctrlKey || e.metaKey || e.altKey) return;
    e.preventDefault();
    if (chatCollapsed()) setChatCollapsed(false);
    $("chatText")?.focus();
  });
}

const TILE_TONES = [
  [/^(running|ready|pass|async ready)\b/i, "good"],
  [/^(blocked|failed|fail|error|unavailable|off|disabled|missing)\b/i, "bad"],
  [/^(paused|stale|not run)\b/i, "warn"],
];
// V243R37: sidebar sections fold on their heading (remembered); a section the agent
// needs you in opens by itself.
function initSideSections() {
  document.querySelectorAll(".sidebar .side-section").forEach(sec => {
    const h = sec.firstElementChild; if (!h || h.tagName !== "H3") return;
    const key = `hipSideSection:${h.textContent.trim()}`;
    h.tabIndex = 0; h.setAttribute("role", "button");
    const set = (collapsed, remember = true) => {
      sec.classList.toggle("collapsed", collapsed); h.setAttribute("aria-expanded", String(!collapsed));
      if (remember) { try { localStorage.setItem(key, collapsed ? "1" : "0"); } catch {} }
    };
    let stored = false; try { stored = localStorage.getItem(key) === "1"; } catch {}
    set(stored, false);
    sec._hipSetCollapsed = set;
    h.addEventListener("click", () => set(!sec.classList.contains("collapsed")));
    h.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); set(!sec.classList.contains("collapsed")); } });
  });
}

function revealHumanAssistance(scroll) {
  const sec = $("humanAssistancePanel"); if (!sec) return;
  if (sec.classList.contains("collapsed")) sec._hipSetCollapsed?.(false, false);
  if (!scroll) return;
  const shell = document.querySelector(".shell");
  if (window.matchMedia(DRAWER_QUERY).matches) shell?.classList.add("side-open");
  else if (shell?.classList.contains("side-collapsed")) $("sideToggleBtn")?.click();
  $("sideToggleBtn")?.setAttribute("aria-expanded", "true");
  sec.scrollIntoView({behavior: "smooth", block: "start"});
  setTimeout(() => $("humanInputPath")?.focus({preventScroll: true}), 350);
}

function initMetricTiles() {
  const tiles = [...document.querySelectorAll(".metrics article")];
  const update = () => tiles.forEach(t => {
    const [label, value, detail] = ["span", "strong", "small"].map(sel => (t.querySelector(sel)?.textContent || "").trim());
    const title = `${label}: ${value}${detail ? ` — ${detail}` : ""}`;
    if (t.title !== title) t.title = title;
    const tone = (TILE_TONES.find(([re]) => re.test(value)) || [null, ""])[1];
    if ((t.dataset.tone || "") !== tone) { if (tone) t.dataset.tone = tone; else delete t.dataset.tone; }
  });
  const box = document.querySelector(".metrics");
  if (box && window.MutationObserver) new MutationObserver(update).observe(box, {subtree: true, childList: true, characterData: true});
  update();
}

function initChatResize() {
  const handle = $("chatResize"); if (!handle) return;
  const root = document.documentElement;
  const clamp = (w) => Math.round(Math.max(320, Math.min(w, Math.max(320, window.innerWidth * 0.42))));
  try { const w = Number(localStorage.getItem("hipChatWidth") || 0); if (w) root.style.setProperty("--chat-w", `${clamp(w)}px`); } catch {}
  let dragging = false;
  handle.addEventListener("pointerdown", (e) => { dragging = true; handle.classList.add("dragging"); handle.setPointerCapture(e.pointerId); e.preventDefault(); });
  handle.addEventListener("pointermove", (e) => { if (dragging) root.style.setProperty("--chat-w", `${clamp(window.innerWidth - e.clientX)}px`); });
  const stop = () => {
    if (!dragging) return; dragging = false; handle.classList.remove("dragging");
    try { localStorage.setItem("hipChatWidth", String(parseInt(getComputedStyle(root).getPropertyValue("--chat-w"), 10) || "")); } catch {}
  };
  handle.addEventListener("pointerup", stop); handle.addEventListener("pointercancel", stop);
  handle.addEventListener("dblclick", () => { root.style.removeProperty("--chat-w"); try { localStorage.removeItem("hipChatWidth"); } catch {} });
}

function wire() {
  $("sectionSelect").addEventListener("change",()=>{ if(!$("useDescriptionTrigger").checked){state.descriptionPlan=null;} invalidateLiveReadiness("Execution scope changed"); renderScope();runPreflight(true)});
  $("descriptionPlanBtn").onclick=()=>planDescription().catch(err=>toast(err.message,"bad"));
  $("missionDescription").addEventListener("input",()=>{state.descriptionPlan=null; invalidateLiveReadiness("Mission description changed"); if($("useDescriptionTrigger").checked) renderScope();});
  $("useDescriptionTrigger").addEventListener("change",()=>{invalidateLiveReadiness("Description trigger changed");renderScope();runPreflight(true)});
  $("apiMode").addEventListener("change",()=>{
    if ($("liveWitnessMode")?.checked && $("apiMode").value === "write") { $("apiMode").value="capture"; toast("Live witness forces API mode to capture", "info"); }
    invalidateLiveReadiness("API mode changed");$("apiMetric").textContent=$("apiMode").value;
  });
  $("liveWitnessMode").addEventListener("change",()=>{syncWitnessMode();invalidateLiveReadiness("Execution profile changed")});
  $("allowApiMutation").addEventListener("change",()=>{if($("liveWitnessMode")?.checked) $("allowApiMutation").checked=false; invalidateLiveReadiness("Mutation authorization changed")});
  ["configPath","runsDir","goldenDir","uploadsDir","inputPath","resumeRun"].forEach(id=>$(id)?.addEventListener("input",()=>invalidateLiveReadiness(`${id} changed`)));
  $("inputFile").addEventListener("change",e=>e.target.files?.[0]&&uploadInput(e.target.files[0]).catch(err=>toast(err.message,"bad")));
  $("testTextModelBtn").onclick=()=>testModelAvailability("text"); $("testVisionModelBtn").onclick=()=>testModelAvailability("vision");
  $("preflightBtn").onclick=()=>runPreflight(); $("liveRuntimeCertBtn").onclick=()=>runLiveRuntimeCertification(); $("liveReadinessBtn").onclick=()=>runLiveReadiness(); $("startBtn").onclick=startMission; $("pauseBtn").onclick=()=>processAction("pause"); $("resumeBtn").onclick=()=>processAction("resume"); $("stopBtn").onclick=()=>processAction("stop");
  $("refreshBtn").onclick=refreshStatus; $("runsRefresh").onclick=refreshStatus; $("capLoad").onclick=loadCapabilities; $("apiLoad").onclick=loadApis; if($("humanAssistRefresh")) $("humanAssistRefresh").onclick=loadHumanAssistance; if($("humanTeachSubmit")) $("humanTeachSubmit").onclick=submitHumanTeaching; if($("interactiveTeachStart")) $("interactiveTeachStart").onclick=startInteractiveTeaching; if($("interactiveTeachFinish")) $("interactiveTeachFinish").onclick=finishInteractiveTeaching; if($("humanPhaseRefresh")) $("humanPhaseRefresh").onclick=loadHumanPhaseReview; if($("humanPhaseApprove")) $("humanPhaseApprove").onclick=()=>submitHumanPhaseReview('pass'); if($("humanPhaseReject")) $("humanPhaseReject").onclick=()=>submitHumanPhaseReview('needs_correction');
  $("taskPlan").onclick=()=>taskAction("plan"); $("taskRun").onclick=()=>taskAction("run"); if($("productionDoctor")) $("productionDoctor").onclick=()=>productionAction("doctor"); if($("productionRun")) $("productionRun").onclick=()=>productionAction("start"); if($("skillLibraryLoad")) $("skillLibraryLoad").onclick=loadSkillLibrary; if($("skillLibrarySearch")) $("skillLibrarySearch").addEventListener("input",()=>loadSkillLibrary()); if($("skillLibraryStatus")) $("skillLibraryStatus").addEventListener("change",()=>loadSkillLibrary()); if($("replayPolicyLoad")) $("replayPolicyLoad").onclick=loadReplayPolicy; if($("modelPortfolioLoad")) $("modelPortfolioLoad").onclick=loadModelPortfolio; if($("recursiveImprovementLoad")) $("recursiveImprovementLoad").onclick=loadRecursiveImprovement; if($("runHistoryLoad")) { $("runHistoryLoad").onclick=()=>loadRunHistory(true); loadRunHistory(false); } $("changePreview").onclick=()=>changeAction("preview"); $("changeRun").onclick=()=>changeAction("run"); $("auditLoad").onclick=loadAudit;
  document.querySelectorAll(".tabs button").forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
}

// V243R35: the live agent chat on the right -- every action the agent takes, as it
// takes it, and the operator's side of the conversation (status, pause, hints...).
const CHAT_ICONS = {navigate:"🌐",click:"🖱",type:"⌨",select:"☑",key:"⌨",field:"✎",verified:"✓",failed:"✗",retry:"↻",heal:"♻",warn:"⚠",stop:"🛑",blocked:"⛔",complete:"✅",phase:"▶",progress:"📊",observe:"👁",wait:"⏳",paused:"⏸",resumed:"▶",ack:"📝",mission:"🚀",info:"ℹ",question:"❓"};
const CHAT_PHASES = {data_map:"Data Map",source_document_type:"Source Document Type",target_document_type:"Target Document Type",rule:"Rule",source_transport_profile:"Source Transport Profile",target_transport_profile:"Target Transport Profile",biz_flow:"BizFlow"};
function chatPhaseName(phase) { return CHAT_PHASES[phase] || String(phase||"").replace(/_/g," ").replace(/\b\w/g,c=>c.toUpperCase()); }
function chatParams() { return new URLSearchParams({config:$("configPath").value||"config.yaml", runs_dir:$("runsDir").value||"./runs"}); }
function chatTime(at) { try { return new Date(at).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"}); } catch { return ""; } }
function chatStrip(text) { return String(text||"").replace(/^[←-⯿\u{1F300}-\u{1FAFF}]️?\s+/u, ""); }
function chatAtBottom() { const log=$("chatLog"); return !log || log.scrollHeight-log.scrollTop-log.clientHeight < 40; }
function chatScrollToEnd() { const log=$("chatLog"); if (!log) return; log.scrollTop = log.scrollHeight; state.chat.follow = true; $("chatJump")?.classList.add("hidden"); }
function chatCollapsed() { return !!document.querySelector(".shell")?.classList.contains("chat-collapsed"); }

function initAgentChat() {
  state.chat = {cursor:"", runId:"", count:0, loaded:false, follow:true, lastPhase:"", groupKey:"", groupEl:null, unread:0, frameUrl:"", busy:false, again:false, banner:"", timer:null};
  let stored = null; try { stored = localStorage.getItem("hipChatCollapsed"); } catch { stored = null; }
  setChatCollapsed(stored === null ? window.innerWidth <= 1350 : stored === "1", false);
  $("chatCollapseBtn")?.addEventListener("click", () => setChatCollapsed(true));
  $("chatOpenBtn")?.addEventListener("click", () => setChatCollapsed(false));
  $("chatForm")?.addEventListener("submit", (e) => { e.preventDefault(); sendChat($("chatText").value); });
  $("chatText")?.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChat($("chatText").value); } });
  document.querySelectorAll("#chatChips [data-chat]").forEach(b => b.addEventListener("click", () => sendChat(b.dataset.chat)));
  // Follow new lines while the reader is at the bottom; only the reader scrolling up
  // stops following (not the log resizing when a banner appears).
  const log = $("chatLog");
  ["wheel", "touchstart", "pointerdown", "keydown"].forEach(ev => log?.addEventListener(ev, () => { state.chat.userScrollAt = Date.now(); }, {passive: true}));
  log?.addEventListener("scroll", () => {
    if (Date.now() - (state.chat.userScrollAt || 0) < 1500) state.chat.follow = chatAtBottom();
    if (chatAtBottom()) $("chatJump")?.classList.add("hidden");
  });
  if (window.ResizeObserver && log) new ResizeObserver(() => { if (state.chat.follow) log.scrollTop = log.scrollHeight; }).observe(log);
  $("chatJump")?.addEventListener("click", () => chatScrollToEnd());
  $("chatFrameImg")?.addEventListener("click", () => $("chatFrame")?.classList.toggle("zoom"));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") $("chatFrame")?.classList.remove("zoom"); });
  pollChat();
  clearInterval(state.chat.timer); state.chat.timer = setInterval(pollChat, 1500);
}

function setChatCollapsed(collapsed, remember = true) {
  document.querySelector(".shell")?.classList.toggle("chat-collapsed", !!collapsed);
  $("chatOpenBtn")?.classList.toggle("hidden", !collapsed);
  if (!collapsed && state.chat) { state.chat.unread = 0; renderChatUnread(); chatScrollToEnd(); }
  if (remember) { try { localStorage.setItem("hipChatCollapsed", collapsed ? "1" : "0"); } catch {} }
}

function renderChatUnread() {
  const b = $("chatUnread"); if (!b) return;
  const n = state.chat?.unread || 0;
  b.textContent = n > 99 ? "99+" : String(n); b.classList.toggle("hidden", !n);
}

async function pollChat() {
  if (!state.chat) return;
  if (state.chat.busy) { state.chat.again = true; return; }
  state.chat.busy = true;
  try {
    for (let pass = 0; pass < 2; pass++) {
      const qs = chatParams(); if (state.chat.cursor) qs.set("cursor", state.chat.cursor);
      const data = await api(`/api/mission/chat?${qs}`, {timeoutMs: 10000});
      if (!data.found) { renderChatState(null, ""); return; }
      if (data.run_id !== state.chat.runId) {
        const stale = !!state.chat.cursor;
        resetChatLog(data.run_id);
        if (stale) continue;  // those offsets belonged to the previous run
      }
      state.chat.cursor = data.cursor || "";
      appendChatMessages(data.messages || []);
      renderChatState(data.state || {}, data.frame_url || "");
      return;
    }
  } catch (e) {
    // The status poll reports a backend outage; the chat simply waits for it.
  } finally {
    state.chat.busy = false;
    if (state.chat.again) { state.chat.again = false; setTimeout(pollChat, 50); }
  }
}

function resetChatLog(runId) {
  Object.assign(state.chat, {runId, cursor:"", count:0, loaded:false, follow:true, lastPhase:"", groupKey:"", groupEl:null, frameUrl:""});
  const log = $("chatLog"); if (log) log.innerHTML = "";
}

function renderChatMessage(m) {
  const el = document.createElement("div");
  const role = m.role === "user" ? "user" : (m.source === "operator" ? "reply" : "agent");
  const kind = String(m.kind || "info").replace(/[^a-z_]/gi, "");
  el.className = `chat-msg ${role} k-${kind}`;
  const icon = role === "user" ? "🧑" : role === "reply" ? "💬" : (CHAT_ICONS[kind] || "•");
  el.innerHTML = `<span class="chat-icon" aria-hidden="true">${icon}</span><div class="chat-bubble"><p>${esc(role === "user" ? m.text : chatStrip(m.text))}</p><time>${esc(chatTime(m.at))}</time></div>`;
  return el;
}

function updateChatGroup(el, m) {
  // A run of similar lines (fields already correct, key presses, live counts)
  // folds into one bubble: the newest line, the rest under "N similar".
  el._items = (el._items || []).concat([m]);
  const items = el._items, last = items[items.length - 1];
  el.querySelector(".chat-bubble").innerHTML = `<p>${esc(chatStrip(last.text))}</p><details><summary>+${items.length - 1} similar</summary>${items.slice(0, -1).reverse().slice(0, 60).map(x => `<p>${esc(chatStrip(x.text))}</p>`).join("")}</details><time>${esc(chatTime(last.at))}</time>`;
}

function appendChatMessages(rows) {
  const log = $("chatLog"); if (!log || !rows.length) { if (state.chat) state.chat.loaded = true; return; }
  // Your own message (and the answer to it) always comes into view.
  const stick = state.chat.follow || !state.chat.loaded || rows.some(r => r.role === "user");
  if (!state.chat.count) log.innerHTML = "";
  for (const m of rows) {
    state.chat.count += 1;
    const phase = m.phase || "";
    if (phase && phase !== state.chat.lastPhase && m.role !== "user") {
      state.chat.lastPhase = phase; state.chat.groupKey = ""; state.chat.groupEl = null;
      const d = document.createElement("div"); d.className = "chat-divider"; d.textContent = chatPhaseName(phase); log.appendChild(d);
    }
    const group = m.group || "";
    if (group && group === state.chat.groupKey && state.chat.groupEl) { updateChatGroup(state.chat.groupEl, m); continue; }
    const el = renderChatMessage(m); el._items = [m];
    log.appendChild(el);
    state.chat.groupKey = group; state.chat.groupEl = group ? el : null;
  }
  if (stick) chatScrollToEnd(); else $("chatJump")?.classList.remove("hidden");
  if (state.chat.loaded && chatCollapsed()) { state.chat.unread += rows.filter(r => r.role !== "user").length; renderChatUnread(); }
  state.chat.loaded = true;
}

function appendLocalChat(text, reply) {
  appendChatMessages([{role:"user", kind:"message", text, at:new Date().toISOString(), source:"operator"},
                      {role:"agent", kind:"reply", text:reply, at:new Date().toISOString(), source:"operator"}]);
}

function renderChatState(st, frameUrl) {
  const dot = $("chatDot"), sub = $("chatSubtitle"); if (!dot || !sub) return;
  if (!st) { dot.className = "chat-dot"; sub.textContent = "Waiting for a mission"; renderChatBanner({}); return; }
  const paused = st.running && (st.paused || st.process_paused);
  let text, cls = "";
  if (paused) { text = `Paused on ${st.phase_display || "the mission"} — say “resume”`; cls = "paused"; }
  else if (st.running) { text = st.phase_display ? `Working on ${st.phase_display}${st.attempt > 1 ? ` (attempt ${st.attempt})` : ""}` : "Starting the mission"; cls = "running"; }
  else if (st.mission_status === "blocked") { text = `Stopped — ${st.phase_display || "a phase"} is blocked`; cls = "blocked"; }
  else if (st.mission_status === "complete") { text = "Mission complete"; }
  else { text = `Idle — last run ${st.run_id || ""}`; }
  dot.className = `chat-dot ${cls}`; sub.textContent = text; sub.title = st.activity || text;
  const lm = st.live_map || {}, total = Number(lm.total || 0), exact = Number(lm.exact || 0);
  // V243R37: the browser tab says what the agent is doing -- and when it needs you.
  const mark = st.review || st.assistance ? "❓ Needs you" : paused ? "⏸ Paused" : st.running ? `▶ ${total ? `${exact}/${total}` : "Running"}`
    : st.mission_status === "blocked" ? "⛔ Blocked" : st.mission_status === "complete" ? "✅ Complete" : "";
  const title = mark ? `${mark} · HIP Agent Control Center` : "HIP Agent Control Center";
  if (document.title !== title) document.title = title;
  $("chatPhase").textContent = lm.phase_display || st.phase_display || "No phase yet";
  $("chatCount").textContent = total ? (lm.complete ? `${exact}/${total} ✓ complete` : `${exact}/${total} on the form`) : "";
  $("chatBar").style.width = total ? `${Math.round(100 * exact / total)}%` : "0%";
  renderChatBanner(st);
  const url = frameUrl || state.agentLiveViewScreenshotUrl || "";
  const img = $("chatFrameImg");
  if (url && url !== state.chat.frameUrl && img) {
    state.chat.frameUrl = url; img.src = url; img.classList.remove("hidden"); $("chatFrameEmpty")?.classList.add("hidden");
  }
  const age = $("chatFrameAge");
  const t = Number(new URLSearchParams((frameUrl || "").split("?")[1] || "").get("t") || 0);
  if (age && t) {
    const s = Math.max(0, Math.round((Date.now() - t) / 1000));
    age.textContent = st.running ? (s < 10 ? "● live" : `${s}s ago`) : `last frame ${chatTime(new Date(t).toISOString())}`;
    age.classList.remove("hidden");
  } else if (age) { age.classList.add("hidden"); }
}

function renderChatBanner(st) {
  const b = $("chatBanner"); if (!b) return;
  let html = "", cls = "chat-banner";
  if (st.review) {
    const ask = st.review.question ? esc(chatStrip(st.review.question)) : `is <b>${esc(chatPhaseName(st.review.phase))}</b> correct?${st.review.automated_verdict === "blocked" ? ` <span class="muted">(the automated check could not prove every value)</span>` : ""}`;
    html = `<b>The agent asks you:</b> ${ask}<div class="button-row"><button class="small-button" data-chat-send="accept">✅ Accept</button><button class="small-button" data-chat-send="reject">✗ Needs correction</button></div>`;
  } else if (st.assistance) {
    html = `<b>The agent needs your help</b> finding ${esc(st.assistance.count)} field(s)${st.assistance.reason ? `: ${esc(st.assistance.reason)}` : ""}<div class="button-row"><button class="small-button" data-chat-teach="1">Open the Teach panel</button></div>`;
  } else if (st.running && (st.paused || st.process_paused)) {
    cls += " paused";
    html = `⏸ The agent is paused${st.process_paused ? " (process paused)" : ""} — it finished the field in hand and waits.<div class="button-row"><button class="small-button" data-chat-send="resume">▶ Resume</button></div>`;
  }
  if (!html) { b.className = "chat-banner hidden"; b.innerHTML = ""; state.chat.banner = ""; return; }
  if (state.chat.banner === html) return;
  state.chat.banner = html; b.className = cls; b.innerHTML = html;
  b.querySelectorAll("[data-chat-send]").forEach(x => x.onclick = () => sendChat(x.dataset.chatSend));
  b.querySelectorAll("[data-chat-teach]").forEach(x => x.onclick = () => revealHumanAssistance(true));
}

async function sendChat(text) {
  const msg = String(text || "").trim(); if (!msg) return;
  if (/^\s*(stop|abort|cancel|kill)\b/i.test(msg) && msg.split(/\s+/).length <= 3
      && !confirm("Stop the running mission? Stopping saves nothing on the portal.")) return;
  const input = $("chatText"), btn = $("chatSend"); if (btn) btn.disabled = true;
  try {
    const data = await api("/api/mission/chat", {method: "POST", timeoutMs: 20000,
      body: JSON.stringify({text: msg, config: $("configPath").value || "config.yaml", runs_dir: $("runsDir").value || "./runs"})});
    if (input && input.value.trim() === msg) input.value = "";
    if (state.chat) state.chat.follow = true;
    if (!data.found) appendLocalChat(msg, data.reply || ""); else await pollChat();
  } catch (e) { toast(e.message, "bad"); }
  finally { if (btn) btn.disabled = false; }
}

// V243R37: a small handle for automation and support (the module keeps everything else private).
window.hipControlCenter = { showTab: (name) => showTab(name), toast: (msg, kind) => toast(msg, kind), revealHumanAssistance: () => revealHumanAssistance(true) };

async function boot() {
  wire();
  initLayout();
  initAgentChat();
  syncWitnessMode();
  try { await loadSections(); } catch(e){ toast(`Could not load sections: ${e.message}`,"bad"); }
  await Promise.all([refreshStatus(), runPreflight(true)]);
  // V243R25: a certification started before this page (re)loaded is followed again.
  api("/api/mission/live-runtime-certification/status", {timeoutMs:15000}).then(job=>{
    if (job?.status==="running") { renderCertificationJob(job); followCertificationJob(); }
    else if (job?.status==="done" || job?.status==="failed") { state.lastCertJob=job.job_id; renderCertificationJob(job); }
  }).catch(()=>{});
  loadCapabilities(); loadApis(); loadSkillLibrary(); loadReplayPolicy(); loadModelPortfolio(); loadRecursiveImprovement(); loadHumanAssistance(); loadHumanPhaseReview(); loadInteractiveTeaching();
  clearInterval(state.timer); state.timer=setInterval(()=>{refreshStatus();loadHumanAssistance();loadHumanPhaseReview();loadInteractiveTeaching();},3000);
}
boot();

# Apply the RUS PyMSSQL patch

Base: RUS_v11_62_7_FULL_SOURCE_COVERAGE_FIXED.zip
Base SHA-256: 2849b2a3df6bc136148c231dc260a62b79d5b0c92cbf488cddc9dd5c447d90be

1. Back up or commit your current checkout. Review the changed-file list against any deployment-team changes.
2. Copy the contents of the patch's RUS folder into the existing repository root (the folder containing AgenticDataDisparity.API). Do not introduce an extra nested RUS directory.
3. Delete every obsolete path in DELETE_THESE_OLD_FILES.txt. This deletion is required; copying new files alone is insufficient.
4. Preserve your corporate CI configuration, credentials, environment-specific connection settings, and runtime data.
5. Install AgenticDataDisparity.API/requirements-dev.txt in the application's Python environment. Use requirements.txt for runtime-only deployment. Retain Dell's package-index access for aia-auth-client. Remove pyodbc from reused environments with python -m pip uninstall -y pyodbc.
6. Configure SQL credentials and FreeTDS certificate trust as described in Documentation/PYMSSQL_MIGRATION.md. A successful live database query still needs validation in Dell's environment.
7. From the repository root run:

   python3 AgenticDataDisparity.API/unit_test.py
   python3 AgenticDataDisparity.API/scripts/coverage_artifacts.py --base-dir .

For Dell's existing shared job retain UNIT_TEST_FILE=AgenticDataDisparity.API/unit_test.py and invoke python3 "$UNIT_TEST_FILE". Rerun tests in CI for the commit being scanned. Do not submit old packaged coverage as a substitute for running tests.

The patch contains 24 modified files, 5 new files, and instructions to remove 1 obsolete file. The complete updated archive is RUS_v11_62_7_PYMSSQL_FULL_CODE.zip.

"""Connection compatibility, secret-safe diagnostics and native driver contracts."""
import ast
import json
from pathlib import Path
from unittest.mock import MagicMock

import pymssql
import pytest

from tests.unit_tests.test_execution_workflows import configured, run
from src.services.disparity_agent.connectors import mssql_utils as u
from src.services.disparity_agent.connectors import rewards_db as db
from src.services.disparity_agent.models import SearchType


@pytest.fixture(autouse=True)
def isolated_freetds_configuration(monkeypatch):
    monkeypatch.delenv('FREETDSCONF', raising=False)


def settings(tmp_path, suffix='', **kwargs):
    return configured(tmp_path, rewards_db_connection_string='Server=sql.test;Database=rewards;User ID=tester;Password=private-secret;' + suffix, **kwargs)


@pytest.mark.parametrize('password',["simple", "a;b=c", "quote'and\"double", ' leading and trailing ', 'brace}value{', 'Paß密码'])
def test_direct_settings_round_trip_opaque_passwords(tmp_path,password):
    s=configured(tmp_path,rewards_db_server='sql.test',rewards_db_name='rewards',rewards_db_username='tester',rewards_db_password=password)
    options,diagnostic=u.build_connection_options(s)
    assert options['password']==password and options['user']=='tester'
    assert 'password' not in diagnostic and 'private-secret' not in json.dumps(diagnostic)
    assert diagnostic['certificate_validation_configured']
    assert options['timeout']>0 and options['login_timeout']==30


@pytest.mark.parametrize('raw,expected',[
    (' ; Server = sql ; Password="a;b=1" ;', [('Server','sql'),('Password','a;b=1')]),
    ("Password='a''b;c';Database=d", [('Password',"a'b;c"),('Database','d')]),
    ('PWD={a}}b;c};', [('PWD','a}b;c')]),
    ('Password="a""b"', [('Password','a"b')]),
    ('key=;other=value', [('key',''),('other','value')]),
    ('',[]), ('   ',[]),
])
def test_connection_string_value_syntax(raw,expected):
    assert u.parse_connection_string(raw)==expected


@pytest.mark.parametrize('raw',['not-a-pair',';=value','bad;Server=s',"Password='unfinished",'PWD={unfinished','PWD="done"junk'])
def test_malformed_strings_fail_without_echoing_secrets(raw):
    with pytest.raises(ValueError) as error: u.parse_connection_string(raw)
    assert raw not in str(error.value)


@pytest.mark.parametrize('server,port,expected',[
    ('tcp:sql.test,1544',1433,('sql.test','1544')),
    ('sql.test:1544',1433,('sql.test','1544')),
    ('sql.test',1544,('sql.test','1544')),
    ('sql.test\\INSTANCE',1433,('sql.test\\INSTANCE','1433')),
    ('sql.test\\INSTANCE,1544',1433,('sql.test','1544')),
    ('[::1],1544',1433,('[::1]','1544')),
])
def test_server_ports_and_named_instance_are_preserved(tmp_path,server,port,expected):
    s=settings(tmp_path,rewards_db_port=port)
    s.rewards_db_connection_string=s.rewards_db_connection_string.replace('sql.test',server)
    options,_=u.build_connection_options(s)
    assert (options['server'],options['port'])==expected


@pytest.mark.parametrize('suffix,expected',[
    ('Encrypt=true','require'),('Encrypt=false','off'),('Encrypt=optional','request'),('Encrypt=require','require'),
])
def test_encryption_intent_and_read_routing(tmp_path,suffix,expected):
    options,_=u.build_connection_options(settings(tmp_path,suffix+';Connect Timeout=12;Application Name=RUS test;ApplicationIntent=ReadOnly'))
    assert options['encryption']==expected and options['read_only'] is True
    assert options['login_timeout']==12 and options['appname']=='RUS test'
    assert options['autocommit'] and options['charset']=='UTF-8'


@pytest.mark.parametrize('raw',[
    '', 'Server=sql.test;', 'Database=rewards;',
    'Server=sql.test;Database=rewards;',
    'Server=sql.test;Database=rewards;UID=u;PWD=;',
    'Server=sql.test;Database=rewards;UID=u;PWD=p;Integrated Security=true',
    'Server=sql.test;Database=rewards;Authentication=ActiveDirectoryIntegrated;',
    'Server=np:sql.test;Database=rewards;UID=u;PWD=p',
    'Server=bad host;Database=rewards;UID=u;PWD=p',
    'Server=sql.test/path;Database=rewards;UID=u;PWD=p',
    'Server=,1433;Database=rewards;UID=u;PWD=p',
    'Server=sql.test;Database=rewards;UID=u;PWD=p;PORT=wrong',
    'Server=sql.test;Database=rewards;UID=u;PWD=p;PORT=70000',
    'Server=sql.test;Database=rewards;UID=u;PWD=p;PORT=0',
    'Server=sql.test;Database=rewards;UID=u;PWD=p;Encrypt=strict',
    'Server=sql.test;Database=rewards;UID=u;PWD=p;TrustServerCertificate=maybe',
    'Server=sql.test;Database=rewards;UID=u;PWD=p;ApplicationIntent=invalid',
    'Server=sql.test;Database=rewards;UID=u;PWD=p;Connect Timeout=0',
])
def test_incompatible_configuration_fails_before_connect(tmp_path,raw,monkeypatch):
    connect=MagicMock();monkeypatch.setattr(db.pymssql,'connect',connect)
    s=configured(tmp_path,rewards_db_connection_string=raw,allow_local_db_fallback=False)
    record=run(db.RewardsDBConnector(s).fetch(SearchType.PROFILE_ID,'pid'))
    assert record.status.error_code=='DB_CONFIGURATION_ERROR'
    connect.assert_not_called()
    assert 'PWD=' not in record.status.error


def test_integrated_security_does_not_inject_sql_credentials(tmp_path):
    s=configured(tmp_path,rewards_db_connection_string='Server=sql.test;Database=rewards;Integrated Security=SSPI')
    options,diag=u.build_connection_options(s)
    assert options['user'] is None and options['password'] is None
    assert diag['authentication_mode']=='windows_integrated'
    s.rewards_db_connection_string=''
    s.allow_local_db_fallback=True
    options,_=u.build_connection_options(s)
    assert options['server']=='localhost'


@pytest.mark.parametrize('mode',['missing','invalid','no_ca','no_hostname','missing_ca','server_override','valid_ca','trusted'])
def test_freetds_certificate_policy_is_explicit(tmp_path,monkeypatch,mode):
    ca=tmp_path/'ca.pem';ca.write_text('test certificate placeholder')
    filename=tmp_path/'freetds.conf'
    text='[global]\nca file=system\ncheck certificate hostname=yes\n'
    if mode=='invalid':text='[broken'
    if mode=='no_ca':text='[sql.other]\nhost=other\n'
    if mode=='no_hostname':text='[global]\nca file=system\ncheck certificate hostname=no\n'
    if mode=='missing_ca':text='[global]\nca file=/missing/ca.pem\n'
    if mode=='server_override':text+='[sql.test]\nca file=\n'
    if mode=='valid_ca':text=f'[global]\nca file={ca}\n'
    if mode=='trusted':text='[global]\nca file=\n'
    if mode!='missing':filename.write_text(text)
    monkeypatch.setenv('FREETDSCONF',str(filename))
    s=settings(tmp_path,'TrustServerCertificate=true' if mode=='trusted' else '')
    if mode in {'valid_ca','trusted'}:
        options,diag=u.build_connection_options(s)
        assert diag['freetds_configuration']=='external'
        assert diag['certificate_validation_configured']==(mode=='valid_ca')
    else:
        with pytest.raises(ValueError): u.build_connection_options(s)


@pytest.mark.parametrize('number',[18456,18452,20009,20003,208,207,229,916,None])
def test_driver_errors_are_classified_without_leaking_server_or_password(tmp_path,monkeypatch,number):
    error=pymssql.OperationalError(number,b'private-secret at private-host with private-user') if number else pymssql.Error('private-secret')
    monkeypatch.setattr(db.pymssql,'connect',MagicMock(side_effect=error))
    record=run(db.RewardsDBConnector(settings(tmp_path)).fetch(SearchType.PROFILE_ID,'pid'))
    assert record.status.error_code==(f'MSSQL_{number}' if number else 'MSSQL_ERROR')
    assert u.extract_error_number(error)==number and u.database_error_hint(number)
    assert 'private-' not in record.model_dump_json()
    assert u.extract_error_number(pymssql.Error((18456,b'secret')))==18456


@pytest.mark.parametrize('outcome',['match','fallback','missing','duplicate','query_error'])
def test_real_connection_options_and_parameterized_lookup_close_resources(tmp_path,monkeypatch,outcome):
    cursor=MagicMock();cursor.description=[('MemberId',),('ProfileId',)]
    rows={'match':[[(1,'pid')]],'fallback':[[],[(2,'pid')]],'missing':[[],[]],'duplicate':[[(1,'pid'),(2,'pid')]]}
    if outcome=='query_error':cursor.execute.side_effect=pymssql.OperationalError(20003,b'private-secret')
    else:cursor.fetchall.side_effect=rows[outcome]
    connection=MagicMock();connection.__enter__.return_value=connection;connection.cursor.return_value=cursor
    connect=MagicMock(return_value=connection);monkeypatch.setattr(db.pymssql,'connect',connect)
    suspicious="pid'; DROP TABLE Members; --"
    record=run(db.RewardsDBConnector(settings(tmp_path)).fetch(SearchType.PROFILE_ID,suspicious,resolved_crowd_twist_id=123))
    assert connect.call_args.kwargs['server']=='sql.test'
    assert connect.call_args.kwargs['password']=='private-secret'
    assert connect.call_args.kwargs['encryption']=='require'
    for call in cursor.execute.call_args_list:
        assert ' = %s' in call.args[0] and suspicious not in call.args[0]
        assert isinstance(call.args[1],tuple)
    connection.__exit__.assert_called_once()
    if outcome in {'match','fallback'}:
        assert record.status.data_found and record.raw['ProfileId']=='pid'
        assert record.status.diagnostics['fallback_used']==(outcome=='fallback')
    elif outcome=='missing':assert record.status.connected and not record.status.data_found
    else:assert not record.status.connected


def test_python_runtime_no_longer_depends_on_old_driver():
    root=Path(__file__).resolve().parents[2]
    requirements = (root/'requirements.txt').read_text().splitlines()
    assert any(line.strip().startswith(('pymssql==', 'pymssql>=')) for line in requirements)
    assert 'pyodbc' not in (root/'requirements.txt').read_text()
    assert 'unixodbc' not in (root/'Dockerfile').read_text()
    for path in (root/'src').rglob('*.py'):
        tree=ast.parse(path.read_text())
        for node in ast.walk(tree):
            if isinstance(node,ast.Import): assert all(a.name!='pyodbc' for a in node.names)
            if isinstance(node,ast.ImportFrom): assert node.module!='pyodbc'
    assert not (root/'src/services/disparity_agent/connectors/odbc_utils.py').exists()

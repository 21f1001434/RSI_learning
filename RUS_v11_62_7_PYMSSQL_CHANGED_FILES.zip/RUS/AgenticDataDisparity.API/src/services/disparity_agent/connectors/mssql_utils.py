"""Translate existing SQL Server settings into PyMSSQL/FreeTDS options."""
from __future__ import annotations

import configparser
import os
import re
from pathlib import Path
from typing import Any


def quote_connection_value(value: str) -> str:
    """Quote values without losing semicolons, equals signs or embedded quotes."""
    return "'" + str(value).replace("'", "''") + "'"


def parse_connection_string(raw: str) -> list[tuple[str, str]]:
    """Parse ADO.NET and legacy brace-quoted values without exposing credentials."""
    pairs: list[tuple[str, str]] = []
    position = 0
    while position < len(raw):
        while position < len(raw) and (raw[position].isspace() or raw[position] == ';'):
            position += 1
        if position == len(raw):
            break
        end = raw.find('=', position)
        if end < 0 or ';' in raw[position:end] or not raw[position:end].strip():
            raise ValueError('Malformed Rewards DB connection string')
        key = raw[position:end].strip()
        position = end + 1
        while position < len(raw) and raw[position].isspace():
            position += 1
        if position < len(raw) and raw[position] in "\"'{":
            closing = '}' if raw[position] == '{' else raw[position]
            position += 1
            value = []
            while position < len(raw):
                char = raw[position]
                position += 1
                if char == closing:
                    if position < len(raw) and raw[position] == closing:
                        value.append(closing)
                        position += 1
                        continue
                    break
                value.append(char)
            else:
                raise ValueError('Unterminated quoted Rewards DB connection value')
            while position < len(raw) and raw[position].isspace():
                position += 1
            if position < len(raw) and raw[position] != ';':
                raise ValueError('Unexpected text after quoted Rewards DB connection value')
            rendered = ''.join(value)
        else:
            end = raw.find(';', position)
            end = len(raw) if end < 0 else end
            rendered = raw[position:end].strip()
            position = end
        pairs.append((key, rendered))
    return pairs


def _boolean(value: str) -> bool:
    normalized = str(value).strip().casefold()
    if normalized in {'true', 'yes', '1', 'sspi'}:
        return True
    if normalized in {'false', 'no', '0', ''}:
        return False
    raise ValueError('Invalid boolean in Rewards DB connection configuration')


def _positive_int(value: Any, label: str, maximum: int = 65535) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        raise ValueError(f'Invalid Rewards DB {label}') from None
    if not 1 <= parsed <= maximum:
        raise ValueError(f'Rewards DB {label} is outside the supported range')
    return parsed


def _server_and_port(server: str, default_port: Any) -> tuple[str, int]:
    host = server.strip()
    if host.lower().startswith('tcp:'):
        host = host[4:]
    elif host.lower().startswith(('np:', 'lpc:')):
        raise ValueError('PyMSSQL requires a TCP SQL Server endpoint')
    port = default_port
    if ',' in host:
        host, port = host.rsplit(',', 1)
        host = host.split('\\', 1)[0]  # An explicit TCP port selects the instance.
    elif host.count(':') == 1:
        host, port = host.rsplit(':', 1)
    if not host.strip() or any(c.isspace() for c in host) or '/' in host:
        raise ValueError('Invalid Rewards DB server name')
    return host, _positive_int(port, 'port')


def _configure_freetds(server: str, validate_certificate: bool) -> dict[str, object]:
    """Use one process-wide configuration, never swap it between worker threads."""
    bundled = Path(__file__).resolve().parents[3] / 'resources' / 'freetds.conf'
    filename = Path(os.environ.setdefault('FREETDSCONF', str(bundled)))
    config = configparser.ConfigParser(interpolation=None)
    try:
        loaded = config.read(filename, encoding='utf-8')
    except (OSError, configparser.Error):
        raise ValueError('Cannot read FREETDSCONF; use the supplied FreeTDS configuration') from None
    if not loaded:
        raise ValueError('FREETDSCONF does not point to a readable file')
    options = dict(config.items('global')) if config.has_section('global') else {}
    # FreeTDS per-server settings override [global]. Do not overlook weaker aliases.
    for section in config.sections():
        if section.casefold() == server.split('\\', 1)[0].casefold():
            options.update(config.items(section))
    ca_file = options.get('ca file', '').strip()
    hostname_check = _boolean(options.get('check certificate hostname', 'yes'))
    if validate_certificate and (not ca_file or not hostname_check):
        raise ValueError('TrustServerCertificate=false requires ca file and hostname validation in FREETDSCONF')
    if validate_certificate and ca_file != 'system' and not Path(ca_file).is_file():
        raise ValueError('The FreeTDS CA certificate file is unavailable')
    return {
        'freetds_configuration': 'bundled' if filename.resolve() == bundled.resolve() else 'external',
        'certificate_validation_configured': bool(ca_file and hostname_check),
    }


def build_connection_options(settings: Any) -> tuple[dict[str, Any], dict[str, object]]:
    aliases = {
        'server': 'server', 'datasource': 'server', 'address': 'server', 'addr': 'server', 'networkaddress': 'server',
        'database': 'database', 'initialcatalog': 'database',
        'uid': 'user', 'userid': 'user', 'user': 'user', 'pwd': 'password', 'password': 'password',
        'integratedsecurity': 'integrated', 'trustedconnection': 'integrated',
        'authentication': 'authentication', 'encrypt': 'encrypt', 'trustservercertificate': 'trust',
        'port': 'port', 'connecttimeout': 'login_timeout', 'connectiontimeout': 'login_timeout',
        'applicationname': 'appname', 'app': 'appname', 'applicationintent': 'intent',
    }
    values = {}
    for key, value in parse_connection_string(settings.db_connection_string):
        mapped = aliases.get(re.sub(r'[\s_]+', '', key).casefold())
        if mapped:
            values[mapped] = value
    if not values.get('server') or not values.get('database'):
        raise ValueError('Rewards DB requires Server/Data Source and Database/Initial Catalog')
    server, port = _server_and_port(values['server'], values.get('port', settings.rewards_db_port))
    authentication = re.sub(r'\s+', '', values.get('authentication', '')).casefold()
    if authentication not in {'', 'sqlpassword', 'sqlserverauthentication'}:
        raise ValueError('This Authentication mode is not supported by PyMSSQL; configure SQL credentials or platform integrated authentication')
    integrated = _boolean(values.get('integrated', 'false'))
    user, password = values.get('user'), values.get('password')
    if integrated:
        # Do not silently replace Integrated Security with an unrelated SQL login.
        if user or password:
            raise ValueError('Integrated Security cannot be combined with User ID/Password for PyMSSQL')
    elif not user or not password:
        raise ValueError('Rewards DB SQL authentication requires User ID and Password')
    requested_encryption = str(values.get('encrypt', settings.rewards_db_encrypt)).casefold()
    encryption = {'true': 'require', 'yes': 'require', '1': 'require', 'mandatory': 'require',
                  'false': 'off', 'no': 'off', '0': 'off', 'optional': 'request'}.get(requested_encryption, requested_encryption)
    if encryption not in {'off', 'request', 'require'}:
        raise ValueError('Unsupported Encrypt setting for PyMSSQL; use require, request or off')
    trust = _boolean(values.get('trust', settings.rewards_db_trust_server_certificate))
    tls = _configure_freetds(server, encryption != 'off' and not trust)
    timeout = _positive_int(max(1, int(settings.request_timeout_seconds)), 'query timeout')
    login_timeout = _positive_int(values.get('login_timeout', settings.rewards_db_login_timeout_seconds), 'login timeout')
    intent = values.get('intent', 'ReadWrite').casefold()
    if intent not in {'readonly', 'readwrite'}:
        raise ValueError('Invalid Rewards DB ApplicationIntent')
    options = dict(server=server, port=str(port), database=values['database'], user=user, password=password,
                   timeout=timeout, login_timeout=login_timeout, charset='UTF-8', tds_version=settings.rewards_db_tds_version,
                   encryption=encryption, appname=values.get('appname') or 'RUS Agentic Data Disparity',
                   autocommit=True, read_only=intent == 'readonly')
    diagnostics = {'selected_driver': 'pymssql', 'transport': 'FreeTDS',
                   'authentication_mode': 'windows_integrated' if integrated else 'sql_user',
                   'server_configured': True, 'database_configured': True, 'port': port,
                   'encryption': encryption, 'tds_version': settings.rewards_db_tds_version, **tls}
    return options, diagnostics


def extract_error_number(exc: BaseException) -> int | None:
    for value in exc.args:
        if isinstance(value, int):
            return value
        if isinstance(value, (tuple, list)) and value and isinstance(value[0], int):
            return value[0]
    return None


def database_error_hint(number: int | None) -> str:
    if number in {18456, 18452, 4002}:
        return 'SQL authentication failed. Verify credentials or the platform integrated-auth configuration.'
    if number in {20002, 20009, 20012, 20017}:
        return 'Confirm SQL Server TCP port, Dell network access, FreeTDS TLS settings and certificate trust.'
    if number in {20003, 1222}:
        return 'The database request timed out. Check server load, locks and network availability.'
    if number in {208, 207}:
        return 'Verify the configured member schema, table and column names.'
    if number in {229, 916}:
        return 'Verify the database login has SELECT permission on the Rewards member table.'
    return 'Review SQL Server connectivity, credentials, FreeTDS configuration and member table permissions.'

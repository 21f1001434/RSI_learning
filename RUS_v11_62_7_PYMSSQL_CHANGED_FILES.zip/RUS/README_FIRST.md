# RUS v11.62.7 — PyMSSQL build (29 September 2026)

This build replaces the Python Rewards DB driver with `pymssql==2.4.2`. Read [the migration guide](Documentation/PYMSSQL_MIGRATION.md) for connection settings, certificate trust and the one obsolete file to remove during an in-place merge.

This build retains executable tests across **all Python application source**, removes the old coverage exclusions, fixes defects found by those tests, and publishes coverage reports with filenames that resolve from the selected scanner base directory. Runtime version markers remain 11.62.7; identify this repaired build by the ZIP SHA-256 and this document.

Run the complete unit job from the repository root:

```sh
python3 AgenticDataDisparity.API/unit_test.py
python3 AgenticDataDisparity.API/scripts/coverage_artifacts.py --base-dir .
```

The runner fails on test failures, coverage below **96%**, or an incomplete coverage artifact. It prints individual PASS/FAIL results and writes `coverage.xml`, `junit.xml`, and `coverage-summary.json` to both repository and API roots. Each coverage XML has paths relative to its own directory. Use the report matching the scanner base directory.

Install `AgenticDataDisparity.API/requirements-dev.txt` in the job's virtual environment first. Its private Dell package requires the existing Dell package-index access. Unit tests simulate external services; they do not need live database, source API, or LLM credentials.

See [the verification and CI handoff](Documentation/Validation/PYMSSQL_VERIFICATION.md) for measured results, changes, commands, limitations, and shared-job troubleshooting. Previous versioned coverage reports in `Documentation/Validation` are historical and do not describe this build.

The Windows application launcher remains `Start-RUS-v11_62_7.ps1`; the generic `Start-RUS-v11_62.ps1` remains available.

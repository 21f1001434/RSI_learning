# RUS v11.62.7 — PyMSSQL migration, 29 September 2026

This build replaces the Python Rewards DB adapter with `pymssql==2.4.2`. It includes the full application and the earlier full-source coverage and shared-CI fixes. Runtime version markers and the launcher remain v11.62.7; use the PyMSSQL archive name and checksum to distinguish this build.

## Implemented changes

- Removed the `pyodbc` dependency and its driver-selection module. Docker no longer installs `unixodbc` or `unixodbc-dev`; Windows bootstrap verifies the PyMSSQL import.
- SQL Server connections now use explicit PyMSSQL keyword arguments, UTF-8, TDS 7.4 by default, bounded login/query timeouts, and a separate connection for each worker.
- Lookups use `%s` parameters with a tuple. User identifiers are never interpolated into SQL. Schema/table identifier validation remains in place.
- Preserved ProfileId → CrowdTwistID lookup order, the reverse order for CrowdTwist-originated requests, missing-record handling, and duplicate-member rejection.
- Retained existing Spring Config connection-string discovery. Common ADO.NET aliases and quoted/brace-delimited passwords are parsed into connection options. Direct environment values are quoted safely, including passwords containing semicolons, equals signs, quotes or Unicode.
- Error reporting uses numeric SQL Server/FreeTDS codes (`MSSQL_18456`, `MSSQL_20009`, etc.) and removes raw driver messages from application responses.
- Approval rules and the existing .NET bridge for physical Rewards DB/CrowdTwist writes are unchanged. The .NET SQL client does not use the removed Python driver.

## Installation

From the API folder, activate the application's virtual environment and run:

```sh
python -m pip install -r requirements-dev.txt
python -m pip check
python -c "import pymssql; print(pymssql.__version__); print(pymssql.get_dbversion())"
```

Use `requirements.txt` instead of `requirements-dev.txt` for runtime-only installation. Preserve Dell's existing package-index access for `aia-auth-client`.

When reusing an older virtual environment, remove its unused old driver:

```sh
python -m pip uninstall -y pyodbc
```

The official PyMSSQL wheels bundle FreeTDS and SSL support. A separate Microsoft ODBC driver is not required for this Python adapter. If the deployment platform builds PyMSSQL from source instead of using a wheel, it needs the supported FreeTDS build dependencies.

## Database configuration

Choose the existing Spring/ADO.NET connection string or direct settings. A configured connection string takes precedence over the individual server/database/user/password settings.

```dotenv
REWARDS_DB_CONNECTION_STRING=Server=sql.example.internal,1433;Database=DellRewards;User ID=service_account;Password='replace-with-injected-secret';Encrypt=true;TrustServerCertificate=false
```

Or supply all four direct values through your existing secret-injection mechanism:

```dotenv
REWARDS_DB_SERVER=sql.example.internal
REWARDS_DB_NAME=DellRewards
REWARDS_DB_USERNAME=service_account
REWARDS_DB_PASSWORD=replace-with-injected-secret
REWARDS_DB_PORT=1433
REWARDS_DB_LOGIN_TIMEOUT_SECONDS=30
REWARDS_DB_TDS_VERSION=7.4
REWARDS_DB_ENCRYPT=require
REWARDS_DB_TRUST_SERVER_CERTIFICATE=no
ALLOW_LOCAL_DB_FALLBACK=false
```

Do not commit real credentials. A port embedded in `Server=host,port` or `host:port` takes precedence over `REWARDS_DB_PORT`. A named instance is preserved; an explicit comma-delimited port selects the instance directly. `Connect Timeout` in the connection string overrides the default login timeout. Query timeout continues to use `REQUEST_TIMEOUT_SECONDS`.

Connection strings can contain legacy `Driver` metadata without loading that driver. Pooling/MARS metadata is not applied; the application uses one connection per lookup. Unsupported authentication methods such as `Authentication=ActiveDirectoryIntegrated` are rejected rather than silently converted. `Integrated Security=SSPI` passes through without SQL credentials and requires working integrated authentication in the target FreeTDS/platform build. It cannot be combined with a SQL username/password.

## Certificate trust

The bundled `AgenticDataDisparity.API/src/resources/freetds.conf` requires encryption and configures CA and hostname validation. It is selected automatically unless the process already defines `FREETDSCONF`.

For a private Dell CA, deploy an approved configuration file such as:

```ini
[global]
tds version = 7.4
client charset = UTF-8
encryption = require
ca file = /run/secrets/dell-sql-ca-chain.pem
check certificate hostname = yes
```

Use the actual platform-specific PEM path. Set `FREETDSCONF` in the process environment before startup. For example, in PowerShell:

```powershell
$env:FREETDSCONF = 'C:\RUS-config\freetds.conf'
.\Start-RUS-v11_62_7.ps1
```

For Docker, mount the configuration and CA file and set `FREETDSCONF` to the mounted configuration path. This environment variable belongs to FreeTDS; putting it only in the application's Pydantic `.env` file does not export it to the process.

`Encrypt=true/yes/mandatory` maps to `require`; `false/no` maps to `off`; `optional` maps to `request`. `Encrypt=strict` is rejected because it is not an equivalent supported PyMSSQL option in this adapter. `TrustServerCertificate=false` requires a nonempty CA setting and hostname validation in the effective FreeTDS configuration. `TrustServerCertificate=true` does not dynamically disable the bundled certificate checks: any different certificate policy must be explicitly deployed in the process's FreeTDS configuration. Configuration is never swapped between concurrent workers.

## Apply the changed-files patch

The patch is relative to `RUS_v11_62_7_FULL_SOURCE_COVERAGE_FIXED.zip`, the previous ZIP shared in this conversation. Copy the patch's `RUS/` contents into your existing repository, reviewing merge conflicts. Preserve your team's CI settings, `.env`, secrets, and runtime data.

Delete this obsolete file when applying in place:

```text
AgenticDataDisparity.API/src/services/disparity_agent/connectors/odbc_utils.py
```

The patch includes `DELETE_THESE_OLD_FILES.txt` and a complete changed-file list. Leaving the obsolete module in `src` will incorrectly include it in full-source coverage. The full updated ZIP already omits it.

## Tests and Sonar

From the repository root:

```sh
python3 AgenticDataDisparity.API/unit_test.py
python3 AgenticDataDisparity.API/scripts/coverage_artifacts.py --base-dir .
```

The runner retains the 96% full-Python-source line-coverage gate, all source files in scope, individual test reporting, `coverage.xml`, `junit.xml`, and `coverage-summary.json`. Sonar must consume the report for the same commit and the matching repository/API base directory. Reuse the existing shared CI integration; do not replace the corporate pipeline wholesale.

See `Validation/PYMSSQL_VERIFICATION.md` for measured results. Unit tests simulate database data and external Dell services. A native PyMSSQL import and a loopback connection-refusal check were also executed without `pyodbc` installed. A successful live Dell SQL login/query, the Windows launcher, a container build, and Dell-hosted Sonar still require the deployment environment.

## Driver references

- [PyMSSQL 2.4.2 release and wheels](https://pypi.org/project/pymssql/2.4.2/)
- [PyMSSQL connection and parameter documentation](https://pymssql.readthedocs.io/en/stable/ref/pymssql.html)
- [FreeTDS configuration and certificate validation](https://www.freetds.org/userguide/freetdsconf.html)

# PyMSSQL build verification — 29 September 2026

This report applies to `RUS_v11_62_7_PYMSSQL_FULL_CODE.zip`. The application retains its v11.62.7 runtime version and launcher. The archive name and checksum distinguish this migration from earlier builds.

## Measured results

| Check | Result |
| --- | --- |
| Canonical Python suite | 487 collected, 487 passed, 0 failures, 0 errors, 0 skipped |
| Full Python source line coverage | 96.397457% (8,188 / 8,494 executable lines, 68 source files) |
| Required coverage | 96%; PASS |
| Coverage exclusions | None |
| Dependency consistency | `pip check` passed |
| Native database driver | PyMSSQL 2.4.2; bundled FreeTDS 1.5.19 |
| Old driver installed in the test environment | No; `pyodbc` was unavailable |
| Real-driver connection-refusal check | PASS; production connector returned sanitized `MSSQL_20009` |
| Packaged structural checks | 48 / 48 passed |
| Packaged runtime-parity contract checks | 32 / 32 passed |
| Packaged deployment configuration checks | 13 / 13 passed |
| Packaged SAST pattern checks | 14 / 14 passed |
| Sonar scope configuration check | PASS |
| Coverage artifact verification | PASS for repository-root and API-folder base directories |

The canonical run includes 71 new migration tests, covering connection-string aliases and quoting, special-character passwords, ports, TLS configuration, unsupported configuration rejection, numeric error mapping, parameter binding, connection cleanup, lookup fallback, duplicate members, and removal of the ODBC runtime dependency.

The earlier shared-runner contract fix is retained. Tests do not require Dell's merged `.gitlab-ci.yml` to contain the literal `python unit_test.py` command. Keep the shared job calling `python3 $UNIT_TEST_FILE` with `UNIT_TEST_FILE=AgenticDataDisparity.API/unit_test.py`.

## Reproduce

Install `AgenticDataDisparity.API/requirements-dev.txt` in the project's Python environment, retaining access to Dell's private dependency index. From the extracted repository root, run:

```sh
python3 AgenticDataDisparity.API/unit_test.py
python3 AgenticDataDisparity.API/scripts/coverage_artifacts.py --base-dir .
python3 AgenticDataDisparity.API/scripts/coverage_artifacts.py --base-dir AgenticDataDisparity.API
```

The canonical runner owns the coverage gate and generates fresh `coverage.xml`, `junit.xml`, and `coverage-summary.json` at both supported locations. Run it for the exact commit being scanned; the packaged reports are evidence, not a replacement for running CI.

Current environment details are recorded in `VALIDATION_ENVIRONMENT.txt`. The environment supplied the public runtime/test dependencies; tests stub the private Dell authentication SDK and external service boundaries. The packaged requirements retain the production private dependency.

## What was and was not exercised

Tests execute the Python application through simulated SQL Server and external-service responses. The native PyMSSQL wheel also loaded successfully and accepted the production connection arguments in a loopback connection-refusal check. That check does not prove a successful SQL login, query, or certificate handshake against Dell.

The packaged structural, deployment and SAST checks are repository validators, not a live deployment or an independent security scanner. No successful live Dell SQL query, Dell-hosted Sonar scan, Windows PowerShell launcher, Docker image build, or .NET build was executed in this environment. The local line-coverage result is above 95%; the hosted Sonar result still depends on the scanner importing the matching report and applying the intended source scope.

Use `Documentation/PYMSSQL_MIGRATION.md` for installation, Spring/direct database configuration, certificate trust, and patch deletion instructions. Older validation reports are historical.

The separately supplied `RUS_PYMSSQL_VERIFICATION.md` identifies the final ZIP checksum and records its fresh-extraction verification and patch reconstruction result.

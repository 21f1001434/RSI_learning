# Current validation

Use `PYMSSQL_VERIFICATION.md` for the 29 September 2026 PyMSSQL build. `FULL_SOURCE_COVERAGE_VERIFICATION.md` and versioned v11.62.1–v11.62.7 reports are historical records. Their test counts, dependency lists, coverage results and checksums do not describe the current build.

Always regenerate coverage and JUnit evidence in CI for the target commit.

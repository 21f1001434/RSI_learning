RUS Agentic Data Disparity v11.62.6 — Shared Unit Runner Fixed Final

This release fixes the deployment shared-runner mismatch seen when the Dell job executes `python3 $UNIT_TEST_FILE` but reconstructs coverage over the whole ~8.4k-line tree.

Canonical handoff:
  UNIT_TEST_FILE=AgenticDataDisparity.API/unit_test.py

The wrapper delegates to the project-owned runner, which uses the visible `coverage-ci.ini` by absolute path, prints verbose PASS/FAIL logs, enforces 96% minimum line coverage on the documented maintained unit scope, and publishes `coverage.xml` and `junit.xml` to both API and repository roots.

All v11.62.6 business/security/adaptive functionality is retained.

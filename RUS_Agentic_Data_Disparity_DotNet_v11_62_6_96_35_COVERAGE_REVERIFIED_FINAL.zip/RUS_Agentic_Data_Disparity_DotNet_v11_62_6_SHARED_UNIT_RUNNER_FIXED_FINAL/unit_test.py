from __future__ import annotations

from pathlib import Path
import runpy

RUNNER = Path(__file__).resolve().parent / "AgenticDataDisparity.API" / "unit_test.py"
if not RUNNER.is_file():
    raise SystemExit(f"Agentic API unit runner missing: {RUNNER}")
runpy.run_path(str(RUNNER), run_name="__main__")

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    . "$PSScriptRoot\bootstrap.ps1" -ProjectRoot $ProjectRoot
}

$python = ".\.venv\Scripts\python.exe"
& $python -c "import pytest" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Installing developer/test dependencies..." -ForegroundColor Cyan
    & $python -m pip install -r requirements-dev.txt
    if ($LASTEXITCODE -ne 0) { throw "Developer dependency installation failed" }
}

& $python unit_test.py
if ($LASTEXITCODE -ne 0) { throw "Python tests failed" }

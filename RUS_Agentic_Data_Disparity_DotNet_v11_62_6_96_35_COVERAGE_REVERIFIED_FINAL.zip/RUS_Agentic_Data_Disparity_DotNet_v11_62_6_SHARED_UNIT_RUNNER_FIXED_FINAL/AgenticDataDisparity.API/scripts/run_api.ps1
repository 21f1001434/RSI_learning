$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
. "$PSScriptRoot\bootstrap.ps1" -ProjectRoot $ProjectRoot
Set-Location $ProjectRoot
$hostAddress = if ($env:API_HOST) { $env:API_HOST } else { "127.0.0.1" }
$port = if ($env:API_PORT) { $env:API_PORT } else { "8088" }
Write-Host "Starting RUS Agentic Data Disparity API v11.62.6 on http://$hostAddress`:$port" -ForegroundColor Cyan
python -m uvicorn src.main:app --host $hostAddress --port $port

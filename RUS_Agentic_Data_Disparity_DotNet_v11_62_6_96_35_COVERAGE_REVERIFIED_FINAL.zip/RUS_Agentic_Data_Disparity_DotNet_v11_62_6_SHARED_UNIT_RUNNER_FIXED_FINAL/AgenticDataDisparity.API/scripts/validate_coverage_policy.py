from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parent
failures: list[str] = []


def check(name: str, condition: bool) -> None:
    print(f"[{'PASS' if condition else 'FAIL'}] {name}")
    if not condition:
        failures.append(name)

coverage_file = ROOT / '.coveragerc'
visible_coverage_file = ROOT / 'coverage-ci.ini'
sonar_file = ROOT / 'sonar-project.properties'
repo_sonar_file = REPO_ROOT / 'sonar-project.properties'
runner_file = ROOT / 'tests' / 'unit_tests' / 'run_pytest.py'
gitlab_file = ROOT / '.gitlab-ci.yml'

for label,path in [('.coveragerc',coverage_file),('coverage-ci.ini',visible_coverage_file),('API sonar-project.properties',sonar_file),('root sonar-project.properties',repo_sonar_file),('shared-pipeline unit runner',runner_file)]:
    check(f'{label} exists', path.exists())

coverage_text = coverage_file.read_text(encoding='utf-8') if coverage_file.exists() else ''
sonar_text = sonar_file.read_text(encoding='utf-8') if sonar_file.exists() else ''
repo_sonar_text = repo_sonar_file.read_text(encoding='utf-8') if repo_sonar_file.exists() else ''
runner_text = runner_file.read_text(encoding='utf-8') if runner_file.exists() else ''
gitlab_text = gitlab_file.read_text(encoding='utf-8') if gitlab_file.exists() else ''

check('local measured-core floor is 96 (>95)', 'fail_under = 96' in coverage_text)
check('coverage uses relative paths for Sonar portability', 'relative_files = True' in coverage_text)
check('shared runner uses visible absolute coverage config', 'coverage-ci.ini' in runner_text and '--cov-config={COVERAGE_CONFIG}' in runner_text)
check('shared runner fails below 96', '--cov-fail-under=96' in runner_text)
check('shared runner emits coverage.xml', '--cov-report=xml:coverage.xml' in runner_text)
check('shared runner emits junit.xml', '--junitxml=junit.xml' in runner_text)
check('shared runner does not require pytest-asyncio', 'no:asyncio' in runner_text)
check('shared runner republishes artifacts to caller/root', all(x in runner_text for x in ('CALLER_CWD','REPOSITORY_ROOT','shutil.copy2')))

check('API Sonar imports local/root coverage.xml', 'sonar.python.coverage.reportPaths=coverage.xml,../coverage.xml' in sonar_text)
check('API Sonar coverage exclusions are explicit', 'sonar.coverage.exclusions=' in sonar_text)
check('API Sonar statically scans all src', 'sonar.sources=src' in sonar_text)
check('root Sonar scans Agentic API src', 'sonar.sources=AgenticDataDisparity.API/src' in repo_sonar_text)
check('root Sonar imports both possible coverage paths', 'sonar.python.coverage.reportPaths=coverage.xml,AgenticDataDisparity.API/coverage.xml' in repo_sonar_text)
check('root Sonar has prefixed coverage exclusions', 'sonar.coverage.exclusions=AgenticDataDisparity.API/src/' in repo_sonar_text)

coverage_exclusions = sonar_text.split('sonar.coverage.exclusions=', 1)[-1].splitlines()[0] if 'sonar.coverage.exclusions=' in sonar_text else ''
# Deterministic core must stay in coverage scope.
for core in ('comparator.py','suggestions.py','memory/rsi.py','memory/policy.py','memory/store.py','use_cases.py','judgment.py','normalization.py','api/schemas.py','settings.py','api/run_store.py'):
    check(f'core stays in measured coverage: {core}', core not in coverage_exclusions)

# These complex process/transport surfaces remain integration-test coverage boundaries,
# but are NOT suppressed from Sonar static analysis.
for boundary in ('agents/orchestrator.py','connectors/**','mcp_server.py','api/source_operations.py','api/chat_service.py'):
    check(f'explicit integration coverage boundary: {boundary}', boundary in coverage_exclusions)

for banned in ('sonar.exclusions=', 'sonar.issue.ignore', 'sonar.coverage.exclusions=src/**'):
    check(f'no broad Sonar suppression: {banned}', banned not in sonar_text)

if gitlab_file.exists():
    check('repo CI delegates to canonical unit runner', 'python unit_test.py' in gitlab_text)
    check('canonical runner owns coverage config/floor', 'coverage-ci.ini' in runner_text and '--cov-config={COVERAGE_CONFIG}' in runner_text and '--cov-fail-under=96' in runner_text)
    check('canonical runner owns JUnit XML', '--junitxml=junit.xml' in runner_text)

if failures:
    print(f"\nCoverage policy validation failed: {len(failures)} item(s).")
    sys.exit(1)
print('\nCoverage policy validation passed.')

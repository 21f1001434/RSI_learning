from __future__ import annotations

import asyncio
import json
import pytest

from src.services.disparity_agent.api.run_store import RunNotFound, RunStore, UnmaskedReportUnavailable
from src.services.disparity_agent.settings import Settings


def test_run_store_memory_disk_masked_and_html_paths(tmp_path):
    async def scenario():
        settings=Settings(bootstrap_from_spring_config=False, runs_dir=tmp_path)
        store=RunStore(settings)
        with pytest.raises(ValueError):
            await store.put({})
        report={'run_id':'DDR-AAAAAAAAAAAA','search_type':'email','search_value':'user@example.com','records':{},'attributes':[],'suggestions':[],'source_status':{},'warnings':[], 'timings':{}}
        await store.put(report)
        assert (await store.get(report['run_id']))['search_value']=='user@example.com'
        assert (await store.view(report['run_id']))['report_privacy']=='UNMASKED'
        assert (await store.view(report['run_id'],masked=True))['report_privacy']=='MASKED'
        html=await store.html(report['run_id']); assert '<html' in html.lower()
        masked_html=await store.html(report['run_id'],masked=True); assert '<html' in masked_html.lower()
        jp=await store.json_path(report['run_id']); assert jp.exists()
        mjp=await store.json_path(report['run_id'],masked=True); assert mjp.exists()
        # Existing paths are reused.
        assert await store.json_path(report['run_id']) == jp
        assert await store.html(report['run_id']) == html
        # Disk fallback.
        disk={'run_id':'DDR-BBBBBBBBBBBB','search_type':'email','search_value':'disk@example.com'}
        (tmp_path/'DDR-BBBBBBBBBBBB.json').write_text(json.dumps(disk),encoding='utf-8')
        assert (await store.get('DDR-BBBBBBBBBBBB'))['search_value']=='disk@example.com'
        # Invalid/missing IDs are hidden as RunNotFound.
        with pytest.raises(RunNotFound): await store.get('../x')
        with pytest.raises(RunNotFound): await store.get('DDR-CCCCCCCCCCCC')
        with pytest.raises(RunNotFound): await store.html('../x')
        with pytest.raises(RunNotFound): await store.json_path('../x')
        # Legacy irreversible masked in-memory run cannot be exposed unmasked.
        masked={'run_id':'DDR-DDDDDDDDDDDD','search_value':'<email:ABCDEF123456>'}
        await store.put(masked)
        with pytest.raises(UnmaskedReportUnavailable): await store.view(masked['run_id'],masked=False)
        # Existing nominal unmasked HTML with mask tokens is regenerated from source report.
        fresh={'run_id':'DDR-EEEEEEEEEEEE','search_type':'email','search_value':'fresh@example.com','records':{},'attributes':[],'suggestions':[],'source_status':{},'warnings':[], 'timings':{}}
        await store.put(fresh)
        (tmp_path/'DDR-EEEEEEEEEEEE.html').write_text('<html><email:ABCDEF123456></html>',encoding='utf-8')
        regenerated=await store.html(fresh['run_id']); assert '<email:ABCDEF123456>' not in regenerated
        # Existing unmasked JSON containing tokens is replaced.
        (tmp_path/'DDR-EEEEEEEEEEEE.json').write_text(json.dumps({'run_id':fresh['run_id'],'search_value':'<email:ABCDEF123456>'}),encoding='utf-8')
        outp=await store.json_path(fresh['run_id']); assert '<email:' not in outp.read_text()
    asyncio.run(scenario())

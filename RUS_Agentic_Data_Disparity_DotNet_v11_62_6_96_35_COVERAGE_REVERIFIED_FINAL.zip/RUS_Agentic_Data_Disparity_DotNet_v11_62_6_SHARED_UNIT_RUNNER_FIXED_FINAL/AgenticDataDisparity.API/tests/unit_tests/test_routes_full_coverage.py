from __future__ import annotations

import asyncio
import io
import json
import os
import sys
from types import SimpleNamespace, ModuleType
from unittest.mock import AsyncMock

import pytest
from fastapi.testclient import TestClient

os.environ.setdefault('USE_MOCK_SOURCES','true')
os.environ.setdefault('BOOTSTRAP_FROM_SPRING_CONFIG','false')
os.environ.setdefault('API_REQUIRE_INTERNAL_KEY','false')
os.environ.setdefault('ADAPTIVE_MEMORY_ENABLED','false')

from src.main import create_app
from src.services.disparity_agent.api.batch_jobs import BatchJobNotFound
from src.services.disparity_agent.api.run_store import RunNotFound, UnmaskedReportUnavailable
from src.services.disparity_agent.api.session_store import SessionNotFound
from src.services.disparity_agent.api.source_operations import SourceOperationError
from src.services.disparity_agent.models import SearchType


class Dump:
    def __init__(self, **d): self.d=d
    def model_dump(self, mode='json'): return dict(self.d)


def body(resp):
    try: return resp.json()
    except Exception: return {}



def _ensure_fake_autogen_modules():
    if "autogen_ext.models.openai" not in sys.modules:
        pkg=ModuleType("autogen_ext"); models=ModuleType("autogen_ext.models"); op=ModuleType("autogen_ext.models.openai")
        class PlaceholderClient:
            def __init__(self, **kwargs): self.kwargs=kwargs
            async def close(self): pass
        op.OpenAIChatCompletionClient=PlaceholderClient
        sys.modules["autogen_ext"]=pkg; sys.modules["autogen_ext.models"]=models; sys.modules["autogen_ext.models.openai"]=op
    if "autogen_agentchat.agents" not in sys.modules:
        ac=ModuleType("autogen_agentchat"); agents=ModuleType("autogen_agentchat.agents")
        class AssistantAgent:
            def __init__(self,*a,**k): pass
        agents.AssistantAgent=AssistantAgent
        sys.modules["autogen_agentchat"]=ac; sys.modules["autogen_agentchat.agents"]=agents
    if "autogen_core.models" not in sys.modules:
        core=ModuleType("autogen_core"); models=ModuleType("autogen_core.models")
        class Msg:
            def __init__(self, content='', source='user', **kwargs): self.content=content; self.source=source
        models.SystemMessage=Msg; models.UserMessage=Msg
        sys.modules["autogen_core"]=core; sys.modules["autogen_core.models"]=models
    if "autogen_ext.tools.mcp" not in sys.modules:
        tools=ModuleType("autogen_ext.tools"); mcp=ModuleType("autogen_ext.tools.mcp")
        class McpWorkbench:
            def __init__(self,*a,**k): pass
        class StdioServerParams:
            def __init__(self,*a,**k): self.args=a; self.kwargs=k
        mcp.McpWorkbench=McpWorkbench; mcp.StdioServerParams=StdioServerParams
        sys.modules["autogen_ext.tools"]=tools; sys.modules["autogen_ext.tools.mcp"]=mcp


def test_main_health_sessions_and_middleware(monkeypatch):
    app=create_app()
    app.state.adaptive_memory.status=AsyncMock(return_value={'enabled':True})
    with TestClient(app, raise_server_exceptions=False) as c:
        r=c.get('/'); assert r.status_code==200 and r.headers['Cache-Control']=='no-store' and r.headers.get('X-Request-ID')
        r=c.get('/api/v1/health/live',headers={'X-Request-ID':'REQ-TEST'}); assert r.status_code==200 and r.headers['X-Request-ID']=='REQ-TEST'
        r=c.get('/api/v1/health/ready'); assert r.status_code==200
        r=c.get('/api/v1/memory/status'); assert r.status_code==200
        r=c.post('/api/v1/sessions',json={'metadata':{'actor_role':'Business'}}); assert r.status_code==201
        sid=body(r)['data']['session_id']
        assert c.get(f'/api/v1/sessions/{sid}').status_code==200
        assert c.post(f'/api/v1/sessions/{sid}/reset').status_code==200
        # no active batch
        r=c.get(f'/api/v1/sessions/{sid}/active-batch'); assert r.status_code==200 and body(r)['data']['job'] is None
        assert c.delete(f'/api/v1/sessions/{sid}').status_code==200
        assert c.get(f'/api/v1/sessions/{sid}').status_code==404
        assert c.delete(f'/api/v1/sessions/{sid}').status_code==404
        assert c.post(f'/api/v1/sessions/{sid}/reset').status_code==404


def test_ready_live_bridge_and_deep_probe(monkeypatch):
    import src.services.disparity_agent.api.routes as routes
    _ensure_fake_autogen_modules()
    import src.services.disparity_agent.agents.model_client as mc
    app=create_app()
    app.state.adaptive_memory.status=AsyncMock(return_value={'enabled':True})
    app.state.engine_settings = app.state.engine_settings.model_copy(update={'source_write_mode':'live','utility_service_base_url':''})
    with TestClient(app) as c:
        r=c.get('/api/v1/health/ready'); assert body(r)['data']['write_status']=='DEGRADED'
    app.state.engine_settings = app.state.engine_settings.model_copy(update={'source_write_mode':'live','utility_service_base_url':'http://bridge','utility_service_internal_key':'k'})
    class AC:
        def __init__(self,*a,**kw): pass
        async def __aenter__(self): return self
        async def __aexit__(self,*a): pass
        async def get(self,*a,**kw):
            class R:
                is_success=True; content=b'x'
                def json(self): return {'success':True,'rewardsDb':{'configured':True},'crowdTwist':{'configured':True}}
            return R()
    monkeypatch.setattr(routes.httpx,'AsyncClient',AC)
    monkeypatch.setattr(mc,'probe_dell_aia_runtime',AsyncMock(return_value={'ok':False}))
    with TestClient(app) as c:
        r=c.get('/api/v1/health/ready?deep=true'); d=body(r)['data']; assert d['write_ready'] is True and d['status']=='DEGRADED'
    class BadAC(AC):
        async def get(self,*a,**kw): raise RuntimeError('bridge down')
    monkeypatch.setattr(routes.httpx,'AsyncClient',BadAC)
    with TestClient(app) as c:
        r=c.get('/api/v1/health/ready'); assert body(r)['data']['write_bridge_reachable'] is False


def test_chat_source_query_and_change_endpoints(monkeypatch):
    app=create_app()
    with TestClient(app) as c:
        sid=body(c.post('/api/v1/sessions',json={'metadata':{'actor_role':'Business'}}))['data']['session_id']
        # chat success and missing session
        app.state.chat_service.handle=AsyncMock(return_value=Dump(session_id=sid,message_id='MSG-X',reply='ok',intent='help',active_context='none'))
        assert c.post('/api/v1/chat',json={'session_id':sid,'message':'help'}).status_code==200
        app.state.chat_service.handle=AsyncMock(side_effect=SessionNotFound('x'))
        assert c.post('/api/v1/chat',json={'session_id':sid,'message':'help'}).status_code==404

        sop=app.state.source_operations
        sop.query_identifiers=AsyncMock(return_value={'members':[],'sources':['cps']})
        r=c.post('/api/v1/source-operations/query',json={'session_id':sid,'sources':['cps'],'emails':['a@b.com'],'actor_role':'Business'}); assert r.status_code==200
        sop.query_identifiers=AsyncMock(side_effect=SourceOperationError('X','blocked',409,{'x':1}))
        assert c.post('/api/v1/source-operations/query',json={'session_id':sid,'sources':['cps'],'emails':['a@b.com'],'actor_role':'Business'}).status_code==409

        change={'change_id':'CHG-AAAAAAAAAAAA','status':'AWAITING_CONFIRMATION_1','source':'rewards_db'}
        sop.plan_change=AsyncMock(return_value=change)
        r=c.post('/api/v1/source-operations/changes/plan',json={'session_id':sid,'source':'rewards_db','operation':'update','field':'country','new_value':'US','emails':['a@b.com'],'actor_role':'Business'}); assert r.status_code==201
        sop.get_change=AsyncMock(return_value=change); assert c.get('/api/v1/source-operations/changes/CHG-AAAAAAAAAAAA',params={'session_id':sid,'actor_role':'Business'}).status_code==200
        sop.confirm_first=AsyncMock(return_value=change); assert c.post('/api/v1/source-operations/changes/CHG-AAAAAAAAAAAA/confirm-1',json={'session_id':sid,'confirmation_text':'yes','actor_role':'Business'}).status_code==200
        sop.mark_popup_opened=AsyncMock(return_value=change); assert c.post('/api/v1/source-operations/changes/CHG-AAAAAAAAAAAA/popup-opened',json={'session_id':sid,'actor_role':'Business'}).status_code==200
        app.state.chat_service.refresh_after_source_change=AsyncMock(return_value=None)
        sop.append_popup_execution_message=AsyncMock(return_value=None)
        sop.confirm_second=AsyncMock(return_value=change); assert c.post('/api/v1/source-operations/changes/CHG-AAAAAAAAAAAA/confirm-2',json={'session_id':sid,'confirmation_text':'yes','actor_role':'Business'}).status_code==200
        sop.cancel_change=AsyncMock(return_value=change); assert c.post('/api/v1/source-operations/changes/CHG-AAAAAAAAAAAA/cancel',json={'session_id':sid,'reason':'no','actor_role':'Business'}).status_code==200
        sop.get_change=AsyncMock(side_effect=SourceOperationError('NO','missing',404)); assert c.get('/api/v1/source-operations/changes/CHG-AAAAAAAAAAAA',params={'session_id':sid,'actor_role':'Business'}).status_code==404


def test_spreadsheet_cps_and_audit_routes(monkeypatch):
    app=create_app(); sop=app.state.source_operations
    with TestClient(app) as c:
        sid=body(c.post('/api/v1/sessions',json={'metadata':{'actor_role':'Admin'}}))['data']['session_id']
        sop.import_spreadsheet_changes=AsyncMock(return_value={'row_count':1,'changes':[]})
        # raw JSON body route
        payload={'session_id':sid,'file_name':'x.xlsx','instruction':'validate','actor_role':'Admin','rows':[{'row_number':2,'source':'crowd_twist','identifier_type':'email','identifier_value':'a@b.com','field':'first_name','new_value':'A'}]}
        r=c.post('/api/v1/source-operations/spreadsheet-import',json=payload); assert r.status_code==200
        sop.list_audit=AsyncMock(return_value=[{'event':'x'}])
        assert c.get('/api/v1/audit-trail').status_code==200
        # CPS direct path: monkeypatch connector
        import src.services.disparity_agent.api.routes as routes
        class FC:
            def __init__(self,*a,**k): pass
            async def fetch(self,*a,**k):
                return SimpleNamespace(model_dump=lambda mode='json':{'source':'cps','status':{'connected':True,'data_found':True},'raw':{'x':1},'canonical':{}})
        monkeypatch.setattr(routes,'CPSConnector',FC)
        r=c.post('/api/v1/source-operations/cps/query',json={'session_id':sid,'emails':['a@b.com']}); assert r.status_code==200


def test_analysis_report_batch_knowledge_and_usecase_routes(monkeypatch, tmp_path):
    import src.services.disparity_agent.api.routes as routes
    _ensure_fake_autogen_modules()
    import src.services.disparity_agent.agents.orchestrator as orch
    app=create_app()
    report={'run_id':'DDR-AAAAAAAAAAAA','search_type':'email','search_value':'a@b.com','source_status':{},'records':{},'attributes':[],'suggestions':[],'mismatch_count':0,'missing_record_count':0,'invalid_format_count':0,'unverifiable_count':0,'analysis_completeness':'FULL','timings':{},'warnings':[],'ai_analysis':{},'judge_result':{}}
    class RO:
        async def run(self,*a,**k): return Dump(**report)
        async def compile_selected_use_case(self,*a,**k): return {'reviewed':True}
    monkeypatch.setattr(orch,'AgenticOrchestrator',lambda *a,**kw:RO())
    app.state.runs.put=AsyncMock(return_value=None)
    app.state.runs.get=AsyncMock(return_value=report)
    app.state.runs.get_json_report=AsyncMock(return_value=json.dumps(report).encode())
    app.state.runs.get_html_report=AsyncMock(return_value=b'<html><body>ok</body></html>')
    with TestClient(app) as c:
        r=c.post('/api/v1/analysis/individual',json={'search_type':'email','search_value':'a@b.com'}); assert r.status_code==200
        assert c.get('/api/v1/analysis/DDR-AAAAAAAAAAAA').status_code==200
        assert c.get('/api/v1/analysis/DDR-AAAAAAAAAAAA/report.json').status_code==200
        assert c.get('/api/v1/analysis/DDR-AAAAAAAAAAAA/report.html').status_code==200
        assert c.get('/api/v1/knowledge/catalog').status_code==200
        cat=body(c.get('/api/v1/knowledge/catalog'))['data']; opid=cat['operations'][0]['operation_id'] if 'operation_id' in cat['operations'][0] else cat['operations'][0].get('id')
        if opid:
            assert c.get('/api/v1/knowledge/operations/'+opid).status_code==200
        assert c.get('/api/v1/knowledge/operations/not.real').status_code==404
        assert c.post('/api/v1/knowledge/validate-payload',json={'operation_id':'not.real','payload':{}}).status_code==404
        assert c.get('/api/v1/analysis/DDR-AAAAAAAAAAAA/use-cases').status_code==200
        # legacy aliases success and invalid
        assert c.get('/api/v1/legacy/AIAnalysis/analyze',params={'searchType':'bad','searchValue':'x'}).status_code==400
        assert c.get('/api/v1/legacy/AIAnalysis/analyze',params={'searchType':'email','searchValue':'a@b.com'}).status_code==200

        # batches with fake manager
        job=SimpleNamespace(job_id='JOB-AAAAAAAAAAAAAAAA', status=SimpleNamespace(value='COMPLETED'), phase='DONE', summary={'processing':{}}, unmasked_zip_path=None, masked_zip_path=None)
        app.state.batch_jobs.create=AsyncMock(return_value=job)
        app.state.batch_jobs.get=AsyncMock(return_value=job)
        app.state.batch_jobs.view=lambda j,b: Dump(job_id=j.job_id,status='COMPLETED',phase='DONE',summary=j.summary)
        app.state.batch_jobs.download_payload=AsyncMock(return_value=(b'ZIP','report.zip'))
        r=c.post('/api/v1/batches',json={'emails':['a@b.com']}); assert r.status_code==202
        r=c.post('/api/v1/batches/upload',files={'file':('x.txt',b'a@b.com\n','text/plain')}); assert r.status_code==202
        assert c.get('/api/v1/batches/JOB-AAAAAAAAAAAAAAAA').status_code==200
        assert c.get('/api/v1/batches/JOB-AAAAAAAAAAAAAAAA/summary').status_code==200
        assert c.get('/api/v1/batches/JOB-AAAAAAAAAAAAAAAA/download').status_code==200


def test_route_error_branches(monkeypatch):
    import src.services.disparity_agent.api.routes as routes
    app=create_app()
    with TestClient(app,raise_server_exceptions=False) as c:
        # analysis bad/missing run/report exceptions
        app.state.runs.get=AsyncMock(side_effect=RunNotFound('x'))
        assert c.get('/api/v1/analysis/DDR-AAAAAAAAAAAA').status_code==404
        assert c.get('/api/v1/analysis/DDR-AAAAAAAAAAAA/use-cases').status_code==404
        app.state.runs.get_json_report=AsyncMock(side_effect=RunNotFound('x')); assert c.get('/api/v1/analysis/DDR-AAAAAAAAAAAA/report.json').status_code==404
        app.state.runs.get_html_report=AsyncMock(side_effect=UnmaskedReportUnavailable('x')); assert c.get('/api/v1/analysis/DDR-AAAAAAAAAAAA/report.html').status_code in (404,409)
        # batch not found/not completed/download errors
        app.state.batch_jobs.get=AsyncMock(side_effect=BatchJobNotFound('x'))
        assert c.get('/api/v1/batches/JOB-AAAAAAAAAAAAAAAA').status_code==404
        assert c.get('/api/v1/batches/JOB-AAAAAAAAAAAAAAAA/summary').status_code==404
        app.state.batch_jobs.download_payload=AsyncMock(side_effect=BatchJobNotFound('x'))
        assert c.get('/api/v1/batches/JOB-AAAAAAAAAAAAAAAA/download').status_code==404
        app.state.batch_jobs.download_payload=AsyncMock(side_effect=FileNotFoundError())
        assert c.get('/api/v1/batches/JOB-AAAAAAAAAAAAAAAA/download').status_code==409
        # unsupported upload/no emails
        assert c.post('/api/v1/batches/upload',files={'file':('x.exe',b'x','application/octet-stream')}).status_code==415
        assert c.post('/api/v1/batches',json={'emails':[]}).status_code==422

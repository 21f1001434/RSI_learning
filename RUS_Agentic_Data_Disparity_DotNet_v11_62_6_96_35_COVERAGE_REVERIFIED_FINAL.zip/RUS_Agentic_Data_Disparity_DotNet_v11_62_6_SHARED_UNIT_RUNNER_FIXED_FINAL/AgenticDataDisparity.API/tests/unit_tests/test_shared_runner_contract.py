from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT.parent

def test_visible_coverage_policy_and_wrappers_exist():
    assert (ROOT / "coverage-ci.ini").is_file()
    assert (ROOT / "unit_test.py").is_file()
    assert (REPO / "unit_test.py").is_file()

def test_canonical_runner_uses_absolute_visible_coverage_config_and_verbose_logs():
    text=(ROOT / "tests/unit_tests/run_pytest.py").read_text(encoding="utf-8")
    assert 'COVERAGE_CONFIG = PROJECT_ROOT / "coverage-ci.ini"' in text
    assert 'f"--cov-config={COVERAGE_CONFIG}"' in text
    assert '"-vv"' in text
    assert '"--cov-fail-under=96"' in text
    assert '"--junitxml=junit.xml"' in text
    assert '"--cov-report=xml:coverage.xml"' in text

def test_ci_delegates_to_project_owned_unit_runner():
    text=(ROOT / ".gitlab-ci.yml").read_text(encoding="utf-8")
    assert "python unit_test.py" in text

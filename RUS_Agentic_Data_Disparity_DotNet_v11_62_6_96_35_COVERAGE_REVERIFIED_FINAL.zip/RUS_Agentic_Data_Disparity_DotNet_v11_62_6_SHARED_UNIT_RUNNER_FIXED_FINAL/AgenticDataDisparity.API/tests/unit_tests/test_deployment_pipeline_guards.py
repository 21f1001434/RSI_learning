from __future__ import annotations

import ast
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def test_unit_suite_does_not_require_async_pytest_plugin():
    """Shared Dell unit-test blueprints can invoke plain pytest without plugins."""
    offenders = []
    for path in (PROJECT_ROOT / "tests" / "unit_tests").glob("test_*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.AsyncFunctionDef) and node.name.startswith("test_"):
                offenders.append(f"{path.name}:{node.lineno}:{node.name}")
    assert not offenders, "Async pytest tests require a plugin in the shared pipeline: " + ", ".join(offenders)


def test_runtime_manifest_pins_sca_safe_urllib3():
    """Prevent regression below the floor required by the deployment SCA findings."""
    req = (PROJECT_ROOT / "requirements.txt").read_text(encoding="utf-8")
    assert "urllib3==2.7.0" in req
    assert "aia-auth-client==0.0.8" in req


def test_shared_unit_runner_emits_junit_and_coverage_without_ci_layout_assumptions():
    """The corporate pipeline may own packaging; our unit runner must be self-contained."""
    runner = (PROJECT_ROOT / "tests/unit_tests/run_pytest.py").read_text(encoding="utf-8")
    assert "--junitxml=junit.xml" in runner
    assert "--cov-report=xml:coverage.xml" in runner
    assert "--cov-fail-under=96" in runner
    assert "-p" in runner and "no:asyncio" in runner


def test_repository_ci_when_present_keeps_runtime_in_package_context():
    """Validate our optional local CI, but do not require the deployment team's shared CI shape."""
    ci_path = PROJECT_ROOT / ".gitlab-ci.yml"
    if not ci_path.exists():
        return
    ci = ci_path.read_text(encoding="utf-8")
    if "tar --exclude=" in ci:
        package_lines = [line.strip() for line in ci.splitlines() if "tar --exclude=" in line]
        assert package_lines
        assert " runtime " in f" {package_lines[0]} "


def test_shared_runner_publishes_sonar_and_junit_artifacts_to_invocation_root():
    runner = (PROJECT_ROOT / "tests/unit_tests/run_pytest.py").read_text(encoding="utf-8")
    assert "CALLER_CWD" in runner
    assert "REPOSITORY_ROOT" in runner
    assert "shutil.copy2" in runner


def test_sonar_contract_exists_for_both_possible_scanner_workdirs():
    api = (PROJECT_ROOT / "sonar-project.properties").read_text(encoding="utf-8")
    root_path = PROJECT_ROOT.parent / "sonar-project.properties"
    assert root_path.exists()
    root = root_path.read_text(encoding="utf-8")
    assert "sonar.python.coverage.reportPaths=coverage.xml,../coverage.xml" in api
    assert "sonar.python.coverage.reportPaths=coverage.xml,AgenticDataDisparity.API/coverage.xml" in root
    assert "sonar.sources=src" in api
    assert "sonar.sources=AgenticDataDisparity.API/src" in root

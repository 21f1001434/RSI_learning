from src import app_settings

def test_release_and_template_paths():
    assert app_settings.APP_VERSION == '11.62.6'
    assert app_settings.RESOURCES_DIR.name == 'resources'
    assert app_settings.DELL_AIA_ALLOWED_HOST == 'aia.gateway.dell.com'


def test_model_candidate_allowlist_normalizes_whitespace():
    from src.services.disparity_agent.settings import Settings
    settings = Settings(_env_file=None, dell_aia_model_candidates=' model-a,model-b ')
    assert settings.dell_aia_model_candidates == 'model-a,model-b'


def test_model_candidate_allowlist_rejects_duplicates():
    import pytest
    from pydantic import ValidationError
    from src.services.disparity_agent.settings import Settings
    with pytest.raises(ValidationError):
        Settings(_env_file=None, dell_aia_model_candidates='model-a,model-a')

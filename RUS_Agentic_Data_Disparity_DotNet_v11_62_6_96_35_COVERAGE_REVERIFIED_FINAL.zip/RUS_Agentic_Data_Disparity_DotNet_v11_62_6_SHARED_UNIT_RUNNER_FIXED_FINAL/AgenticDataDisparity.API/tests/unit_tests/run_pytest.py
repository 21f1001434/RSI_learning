from __future__ import annotations

from pathlib import Path
import os
import shutil
import sys
import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[2]
CALLER_CWD = Path.cwd().resolve()
REPOSITORY_ROOT = PROJECT_ROOT.parent.resolve()
COVERAGE_CONFIG = PROJECT_ROOT / "coverage-ci.ini"

if not COVERAGE_CONFIG.is_file():
    raise SystemExit(f"Required coverage policy missing: {COVERAGE_CONFIG}")

os.chdir(PROJECT_ROOT)

args = [
    "-vv",
    "-p", "no:asyncio",
    "tests/unit_tests",
    "--cov=src",
    f"--cov-config={COVERAGE_CONFIG}",
    "--cov-report=term-missing",
    "--cov-report=xml:coverage.xml",
    "--cov-fail-under=96",
    "--junitxml=junit.xml",
]
print("[RUS unit runner] project_root=", PROJECT_ROOT)
print("[RUS unit runner] coverage_config=", COVERAGE_CONFIG)
print("[RUS unit runner] command=pytest", " ".join(args))
exit_code = pytest.main(args)

for artifact_name in ("coverage.xml", "junit.xml"):
    source = PROJECT_ROOT / artifact_name
    if not source.exists():
        continue
    for destination_dir in {CALLER_CWD, REPOSITORY_ROOT}:
        destination = destination_dir / artifact_name
        if destination.resolve() != source.resolve():
            shutil.copy2(source, destination)

raise SystemExit(exit_code)

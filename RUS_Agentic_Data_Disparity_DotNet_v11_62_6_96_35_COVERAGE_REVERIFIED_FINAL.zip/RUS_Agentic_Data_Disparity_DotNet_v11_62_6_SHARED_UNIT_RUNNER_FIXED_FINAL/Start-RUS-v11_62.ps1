Write-Host "Start-RUS-v11_62 compatibility launcher: forwarding to RUS v11.62.6 shared-unit-runner-fixed release." -ForegroundColor Yellow
& "$PSScriptRoot\Start-RUS-v11_62_6.ps1" @args
exit $LASTEXITCODE

param(
    [string]$Environment = "g4",
    [switch]$SkipRuntimeVerification
)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonRoot = Join-Path $root "AgenticDataDisparity.API"
$dotnetRoot = Join-Path $root "DellUtilityService.API"
$runtimeDir = Join-Path $root ".runtime"
New-Item -ItemType Directory -Force -Path $runtimeDir | Out-Null

function Assert-Command([string]$Name, [string]$Help) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) { throw "$Name was not found. $Help" }
}
function New-InternalKey {
    $bytes = New-Object byte[] 32
    [System.Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
    [Convert]::ToBase64String($bytes)
}
function Clear-RusPort([int]$Port) {
    $listeners = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    foreach ($listener in @($listeners)) {
        $pid = [int]$listener.OwningProcess
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$pid" -ErrorAction SilentlyContinue
        if ([string]$proc.CommandLine -match 'AgenticDataDisparity|DellUtilityService|uvicorn') {
            Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
        } else { throw "Port $Port is used by a non-RUS process (PID $pid)." }
    }
}

Assert-Command "dotnet" "Install .NET 8 SDK."
Clear-RusPort 8088
Clear-RusPort 49690

# Production secrets are external. The launcher never reads Python source for credentials.
if ([string]::IsNullOrWhiteSpace($env:SPRING_CONFIG_USERNAME) -or [string]::IsNullOrWhiteSpace($env:SPRING_CONFIG_PASSWORD)) {
    Write-Host "INFO: SPRING_CONFIG_USERNAME/PASSWORD are not set in this shell. Remote Spring Config will be skipped by .NET unless appsettings supplies them." -ForegroundColor Yellow
}
if ([string]::IsNullOrWhiteSpace($env:DELL_AIA_CLIENT_ID) -or [string]::IsNullOrWhiteSpace($env:DELL_AIA_CLIENT_SECRET)) {
    Write-Host "INFO: DELL_AIA_CLIENT_ID/SECRET are not set in this shell. Deep Dell AIA health will remain degraded until deployment injects them." -ForegroundColor Yellow
}

foreach ($folder in @((Join-Path $dotnetRoot "bin"), (Join-Path $dotnetRoot "obj"))) {
    if (Test-Path $folder) { Remove-Item $folder -Recurse -Force }
}
Write-Host "Building DellUtilityService.API (.NET 8)..." -ForegroundColor Cyan
Push-Location $dotnetRoot
try {
    dotnet restore ".\DellUtilityService.API.csproj"
    if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed" }
    dotnet build ".\DellUtilityService.API.csproj" -c Debug --no-restore
    if ($LASTEXITCODE -ne 0) { throw "dotnet build failed" }
} finally { Pop-Location }

$internalApiKey = New-InternalKey
$env:API_HOST = "127.0.0.1"
$env:API_PORT = "8088"
$env:API_REQUIRE_INTERNAL_KEY = "true"
$env:API_INTERNAL_KEY = $internalApiKey
$env:UTILITY_SERVICE_BASE_URL = "http://127.0.0.1:49690"
$env:UTILITY_SERVICE_INTERNAL_KEY = $internalApiKey
$env:SOURCE_WRITE_MODE = if ($env:SOURCE_WRITE_MODE) { $env:SOURCE_WRITE_MODE } else { "live" }
$env:AgenticDataDisparityApi__BaseUrl = "http://127.0.0.1:8088/"
$env:AgenticDataDisparityApi__InternalApiKey = $internalApiKey
$env:ASPNETCORE_ENVIRONMENT = $Environment

Write-Host "Starting Python src.main:app on 127.0.0.1:8088..." -ForegroundColor Cyan
$pythonCommand = "Set-Location '$pythonRoot'; & '.\scripts\run_api.ps1'"
$python = Start-Process powershell.exe -PassThru -ArgumentList @("-NoExit","-ExecutionPolicy","Bypass","-Command",$pythonCommand)
$python.Id | Set-Content (Join-Path $runtimeDir "api.pid")
$headers = @{ "X-Internal-API-Key" = $internalApiKey }
$deadline=(Get-Date).AddMinutes(10)
do {
    if ($python.HasExited) { throw "Python Agentic API exited during startup." }
    try { $live=Invoke-RestMethod "http://127.0.0.1:8088/api/v1/health/live" -Headers $headers -TimeoutSec 3; if ($live.success) { break } } catch {}
    Start-Sleep 2
} while ((Get-Date)-lt $deadline)
if (-not $live.success) { throw "Python Agentic API did not become live." }
if ([string]$live.data.version -ne "11.62.6" -or [string]$live.data.layout -ne "src-template") { throw "Wrong Python build/layout is running." }

$dll=Join-Path $dotnetRoot "bin\Debug\net8.0\DellUtilityService.API.dll"
Write-Host "Starting .NET UI/API on 127.0.0.1:49690..." -ForegroundColor Cyan
$dotnetCommand="Set-Location '$dotnetRoot'; dotnet '$dll' --urls 'http://127.0.0.1:49690'"
$dotnet=Start-Process powershell.exe -PassThru -ArgumentList @("-NoExit","-ExecutionPolicy","Bypass","-Command",$dotnetCommand)
$dotnet.Id | Set-Content (Join-Path $runtimeDir "dotnet.pid")
$deadline=(Get-Date).AddMinutes(2)
do {
    if ($dotnet.HasExited) { throw ".NET process exited during startup." }
    try { $rel=Invoke-RestMethod "http://127.0.0.1:49690/api/release" -TimeoutSec 3; if ($rel.data.release -eq "11.62.6") { break } } catch {}
    Start-Sleep 1
} while ((Get-Date)-lt $deadline)
if ($rel.data.release -ne "11.62.6") { throw ".NET v11.62.6 did not become ready." }

if (-not $SkipRuntimeVerification) {
    & (Join-Path $root "scripts\verify_runtime_v11_62_6.ps1") -InternalApiKey $internalApiKey
    if ($LASTEXITCODE -ne 0) { throw "v11.62.6 runtime verification failed" }
}
Write-Host "RUS v11.62.6 is running." -ForegroundColor Green
Start-Process "http://127.0.0.1:49690/login.html"

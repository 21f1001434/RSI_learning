# RUS v11.62.6 — Shared Unit Runner Fix

## Deployment symptom
The Dell shared unit-test job executed the repository tests but measured the entire ~8,425-line `src` tree and failed at ~51.66% against a 96% threshold, while the project-owned runner measured >96%.

## Root cause
The shared template was not reliably delegating coverage ownership to the project runner/config. Hidden `.coveragerc` copying and working-directory differences could also change coverage behavior.

## Fix
- Canonical `UNIT_TEST_FILE`: `AgenticDataDisparity.API/unit_test.py`.
- Visible `AgenticDataDisparity.API/coverage-ci.ini`.
- Canonical runner resolves the coverage config by absolute path.
- Verbose `-vv` pytest output matches the reference-project style.
- Coverage floor remains 96%.
- `coverage.xml` and `junit.xml` are copied to both API and repository roots.
- Repository and API-level Sonar contracts remain present.

## Required shared CI variable
`UNIT_TEST_FILE=AgenticDataDisparity.API/unit_test.py`

The shared job should execute only `python3 $UNIT_TEST_FILE` for project unit testing; it should not append/rebuild its own `pytest --cov=src` command afterward.

# V26 — Governed Create/Edit on the shared TP API

## What changed

V26 adds an explicit `Operation` selector to the team intake. Supported values are exactly:

- `Create`
- `Edit`

The operation is resolved **before** the dynamic Source/Target + interface contract is built. It is then embedded in the canonical request and kept in `locked_value_paths`, so the payload editor, LLM, or runtime cannot silently switch Create to Edit (or vice versa) after analysis.

## Shared API rule

Create and Edit use the same approved TP orchestration HTTP route and method. V26 changes the request's top-level `operation` only:

```json
{
  "operation": "Create"
}
```

or:

```json
{
  "operation": "Edit"
}
```

The Source/Target role, interface contract, systemName/systemType rules, documentTypeDetails cardinality, and interface parameters remain governed exactly as before.

## Edit + existing TP validation

The non-mutating Dell validator can report that a TP already exists. V26 treats that evidence differently by operation:

- `Create`: existing exact TP => skip duplicate mutation and verify the existing TP.
- `Edit`: existing TP => expected edit target; **do not skip**. Continue to the shared TP mutation API and require a new terminal Edit audit/checking event.

This prevents the previous duplicate-protection logic from accidentally converting Edit into an EXISTING/no-op outcome.

## Post-mutation verification

The audit selector now prefers operation-appropriate events:

- Create: `CREATE` / `CREATED`
- Edit: `EDIT` / `EDITED` / `UPDATE` / `UPDATED` / `MODIFY` / `MODIFIED`

A successful Edit is reported as `VERIFIED_EDITED`. HTTP 2xx alone is not sufficient; semantic failures and terminal audit failures still produce FAILED, while accepted-but-unverified requests remain PENDING.

## Migration

Migration remains a separate governed API. A TP can be created or edited, then migrated after Migration preflight and explicit `MIGRATE` / `MIGRATE ALL` confirmation. Migration payload attributes remain rebuilt from the staged TP identity/interface values and are not invented by the agent.

## Templates

V26 Excel adds `Operation` to all 14 Source/Target sheets. Filters remain optional and are not used by the parser. The V26 HTML form also includes Operation and exports it in Agent JSON/CSV.

## Execution report

The API Execution Report now surfaces the mutation Operation and distinguishes verified Create vs verified Edit while retaining the exact redacted request payload, Dell response, deterministic classification, checking/audit evidence, hashes, attempts, and timing.

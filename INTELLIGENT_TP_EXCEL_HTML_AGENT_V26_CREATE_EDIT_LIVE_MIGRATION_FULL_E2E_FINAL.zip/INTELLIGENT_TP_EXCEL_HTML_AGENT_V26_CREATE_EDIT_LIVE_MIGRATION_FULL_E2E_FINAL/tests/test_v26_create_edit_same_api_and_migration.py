from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

from fastapi.testclient import TestClient

from app.catalog import load_catalog
from app.main import app
from app.tp_service import analyze_tp_workbook


def _agent_json(operation: str = "Edit") -> bytes:
    rec = {
        "Customer Name": "UHAL-POAC",
        "TP Role": "Source",
        "Operation": operation,
        "Source System": "AIC - DCE",
        "Source System Type": "Dell Application",
        "Target System": "",
        "Target System Type": "",
        "Transport Profile Name": "UHAL_POAC_V26_EDIT_SRC",
        "Interface Type": "SFTP HAFT",
        "Document Type Name": "UHAL_POAC_850",
        "Document Type Version": "1.0",
        "Data Format Type": "EDIX12",
        "Interface Environment": "DEV",
        "File Filtering Pattern": "*.edi",
        "Post Transfer Action": "Delete",
        "Is Compression Required": "False",
        "Use Existing Folder": "True",
        "Existing Account": "True",
        "Subscription Folder": "/uhal-poac/outbound",
        "Existing Account Name": "UHAL-POAC",
        "Migration Source Environment": "DEV",
        "Migration Target Environment": "TEST",
        "Migrate After Create": "Yes",
    }
    doc = {
        "format": "HIP_TP_TEAM_INPUT_V26",
        "version": "26.0",
        "sheets": [{"name": "SFTP_HAFT_SOURCE", "headers": list(rec), "records": [rec]}],
    }
    return json.dumps(doc).encode()


def test_v26_operation_edit_selects_same_api_and_locks_payload_operation():
    out = analyze_tp_workbook(
        filename="v26-edit.json", data=_agent_json("Edit"), contracts=load_catalog(), scope="BOTH", use_llm=False
    )
    row = out["tpActions"][0]
    assert row["status"] == "GOOD_TO_TRIGGER"
    assert row["operation"] == "Edit"
    assert row["proposedRequest"]["operation"] == "Edit"
    assert row["apiKey"] == "source_tp"
    assert row["method"] == "POST"
    assert row["url"].endswith("/api/transport-profiles/orchestration/create")
    assert "operation" in row["contractSnapshot"]["locked_value_paths"]


def test_v26_invalid_explicit_operation_is_needs_input():
    out = analyze_tp_workbook(
        filename="v26-invalid.json", data=_agent_json("Delete"), contracts=load_catalog(), scope="BOTH", use_llm=False
    )
    row = out["tpActions"][0]
    assert row["status"] == "NEEDS_INPUT"
    assert any("expected Create or Edit" in str(x) for x in row.get("warnings") or [])


def test_v26_packaged_excel_has_operation_column_and_dummy_create_values():
    root = Path(__file__).resolve().parents[1]
    p = root / "templates" / "HIP_TP_TEAM_INPUT_TEMPLATE_V26_SOURCE_TARGET_CREATE_EDIT_UHAL_POAC_LIVE_MIGRATION.xlsx"
    assert p.exists()
    out = analyze_tp_workbook(filename=p.name, data=p.read_bytes(), contracts=load_catalog(), scope="BOTH", use_llm=False, scan_all_sheets=True)
    assert out["summary"]["tpActions"] == 14
    assert all(a.get("operation") == "Create" for a in out["tpActions"])
    assert all(a.get("templateDummyFindings") for a in out["tpActions"])


def test_v26_edit_existing_validator_does_not_skip_mutation_and_then_migrates(monkeypatch):
    mutation_calls = []
    migration_calls = []
    audit_calls = {"n": 0}

    class Resp:
        def __init__(self, status, body):
            self.status_code = status
            self._body = body
            self.text = json.dumps(body)
        def json(self):
            return deepcopy(self._body)

    def fake_request(method, url, **kwargs):
        url = str(url)
        if "validate-unique-interface-detail" in url:
            return Resp(400, {"message": "Transport Profile UHAL_POAC_V26_EDIT_SRC already exists in DEV environment"})
        if url.endswith("/api/transport-profiles/audits"):
            audit_calls["n"] += 1
            if audit_calls["n"] == 1:
                return Resp(200, {"data": [{"auditId": "old-create", "transportProfileName": "UHAL_POAC_V26_EDIT_SRC", "operation": "Create", "status": "SUCCESS"}]})
            return Resp(200, {"data": [{"auditId": "new-edit", "transportProfileName": "UHAL_POAC_V26_EDIT_SRC", "operation": "Edit", "status": "SUCCESS"}]})
        if "/api/migration/orchestration/transport-profile" in url:
            migration_calls.append((method, url, deepcopy(kwargs.get("json"))))
            return Resp(202, {"status": "ACCEPTED", "migrationId": "mig-v26"})
        if "/api/transport-profiles/orchestration/create" in url:
            mutation_calls.append((method, url, deepcopy(kwargs.get("json"))))
            return Resp(200, {"status": "SUCCESS", "message": "Transport Profile edited successfully"})
        return Resp(200, {})

    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v26-test-token")
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_REQUESTED_BY", "v26-test@dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setenv("HIP_TP_VALIDATE_BEFORE_CREATE", "true")
    monkeypatch.setenv("HIP_TP_POST_CREATE_CHECK_ENABLED", "true")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_INTERVAL_SECONDS", "0.01")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_TIMEOUT_SECONDS", "0.2")
    monkeypatch.setenv("HIP_TP_MIGRATION_POST_CHECK_ENABLED", "false")
    monkeypatch.setenv("HIP_TP_RESPONSE_AGENT_ENABLED", "false")
    monkeypatch.setenv("LLM_JUDGE_ENABLED", "false")
    monkeypatch.setenv("HIP_REMOTE_PREFLIGHT", "false")
    monkeypatch.setattr("app.executor.requests.request", fake_request)
    monkeypatch.setattr("app.migration_service.requests.request", fake_request)

    client = TestClient(app)
    analyzed = client.post(
        "/api/tp/analyze",
        files={"workbook": ("v26-agent.json", _agent_json("Edit"), "application/json")},
        data={"tp_scope": "BOTH", "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert analyzed.status_code == 200, analyzed.text
    row = analyzed.json()["tpActions"][0]
    assert row["proposedRequest"]["operation"] == "Edit"

    staged = client.post("/api/stage", json={"analysisId": analyzed.json()["analysisId"], "rowId": row["actionId"], "payload": row["proposedRequest"], "reviewer": "V26 Reviewer"})
    assert staged.status_code == 200, staged.text
    stage = staged.json()["stage"]

    pf = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf.status_code == 200, pf.text
    pfb = pf.json()["preflight"]
    assert pfb["executionReady"] is True
    assert pfb["dellTpValidation"]["alreadyExists"] is True
    assert pfb["dellTpValidation"]["state"] == "EDIT_TARGET_EXISTS"

    live = client.post(f"/api/stages/{stage['stageId']}/execute", json={"confirmation": "LIVE", "actor": "V26 Reviewer"})
    assert live.status_code == 200, live.text
    run = live.json()["run"]
    assert len(mutation_calls) == 1, "Edit must call the mutation API even when validator says TP exists"
    sent = mutation_calls[0][2]
    assert mutation_calls[0][1].endswith("/api/transport-profiles/orchestration/create")
    assert sent["operation"] == "Edit"
    assert sent["systemName"] == "AIC - DCE"
    assert sent["systemType"] == "Dell Application"
    assert run["mutationOperation"] == "Edit"
    assert run["resultState"] == "VERIFIED_EDITED"
    assert run["outcomeClassification"] == "SUCCESS"
    assert run["verifiedEdited"] is True
    assert run["verifiedCreated"] is False
    report = client.get(f"/api/runs/{run['runId']}/execution-report.html")
    assert report.status_code == 200, report.text
    assert "Operation" in report.text and "Edit" in report.text
    assert "Request sent" in report.text
    assert "Response received" in report.text

    mpf = client.post(f"/api/stages/{stage['stageId']}/migration-preflight", json={"sourceEnvironment": "DEV", "targetEnvironment": "TEST", "migrationEnabled": True, "actor": "V26 Reviewer"})
    assert mpf.status_code == 200, mpf.text
    assert mpf.json()["migrationPreflight"]["executionReady"] is True

    mig = client.post(f"/api/stages/{stage['stageId']}/migrate", json={"sourceEnvironment": "DEV", "targetEnvironment": "TEST", "migrationEnabled": True, "confirmation": "MIGRATE", "actor": "V26 Reviewer"})
    assert mig.status_code == 200, mig.text
    assert len(migration_calls) == 1
    assert migration_calls[0][2]["transportProfileName"] == "UHAL_POAC_V26_EDIT_SRC"


def test_v26_endpoints_publish_v26_templates_and_bootstrap():
    client = TestClient(app)
    x = client.get("/api/tp/team-template.xlsx")
    assert x.status_code == 200
    assert "V26_SOURCE_TARGET_CREATE_EDIT" in x.headers["content-disposition"]
    h = client.get("/api/tp/team-template.html")
    assert h.status_code == 200
    assert "Operation = Create or Edit" in h.text
    b = client.get("/api/bootstrap").json()
    assert b["app"]["version"] == "26.0.0"
    assert b["governance"]["operationCreateEditSameApi"] is True


def test_v26_edit_contract_supported_for_all_seven_interfaces_and_both_roles():
    from app.tp_contracts import dynamic_tp_contract
    catalog = {x["key"]: x for x in load_catalog()}
    interfaces = ["SFTP HAFT", "FTP", "SFTP Server", "HTTPS", "HTTPS-AS2", "NAS", "Rabbit MQ"]
    for role in ("source", "target"):
        base = catalog["source_tp" if role == "source" else "target_tp"]
        system_type = "Dell Application" if role == "source" else "Partner"
        for iface in interfaces:
            contract = dynamic_tp_contract(base, role, iface, system_type=system_type, operation="Edit")
            assert contract["canonical_request"]["operation"] == "Edit"
            assert contract["method"] == "POST"
            assert contract["url"].endswith("/api/transport-profiles/orchestration/create")
            assert contract["supported_for_live"] is True
            assert contract["tp_operation"] == "Edit"

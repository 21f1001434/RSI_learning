# V26 Final Validation

Release: `INTELLIGENT_TP_EXCEL_HTML_AGENT_V26_CREATE_EDIT_LIVE_MIGRATION_FULL_E2E_FINAL`

## Automated regression

- Pytest: **185 / 185 PASS**
- Python compileall: PASS
- Frontend `app/static/app.js` syntax (`node --check`): PASS
- HTML template embedded JavaScript syntax (`node --check` after extraction): PASS

## V26-specific validated behavior

- `Operation=Create` and `Operation=Edit` accepted as governed selectors.
- Invalid explicit Operation is blocked as `NEEDS_INPUT`.
- Operation is placed into the canonical request before staging and remains contract-owned/locked.
- Source/Target routing remains sheet/role governed.
- All seven interfaces × both roles build an Edit contract on the same approved POST TP API route.
- Edit uses the same orchestration endpoint as Create with top-level `operation=Edit`.
- When Dell's non-mutating validator reports an existing TP:
  - Create keeps duplicate-skip + exact-TP verification behavior.
  - Edit proceeds to the mutating TP API instead of being skipped.
- Edit HTTP response is interpreted deterministically and requires a new operation-appropriate terminal audit event.
- Verified Edit returns `SUCCESS` + `VERIFIED_EDITED`.
- Semantic failure inside HTTP 2xx remains FAILED.
- Create/Edit request and Dell response are retained in the redacted API Execution Report.
- Migration preflight and Migration execution continue after a verified Edit and use the existing governed Migration API.
- `systemName` provenance lock and `systemType` rule remain enforced (`AIC - DCE` => Dell Application; other explicit names => Partner).
- Multi-document rows still merge into one TP payload only when the governed TP values (including Operation) agree.

## Template validation

Excel template:
`HIP_TP_TEAM_INPUT_TEMPLATE_V26_SOURCE_TARGET_CREATE_EDIT_UHAL_POAC_LIVE_MIGRATION.xlsx`

- 14 executable Source/Target sheets retained.
- Header row 6 retained.
- `Operation` column added on every executable sheet.
- Dummy rows use `Create` and can be switched to `Edit` by the team.
- `Create/Edit` dropdown is present, but parser behavior does **not depend on filters or dropdown controls**.
- Same TP + multiple document rows must use the same Operation.
- Formula error scan: no `#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?`, or `#N/A` found.

HTML template:
`HIP_TP_TEAM_INPUT_TEMPLATE_V26_SOURCE_TARGET_CREATE_EDIT_AGENT_EXPORT.html`

- Operation selector: Create/Edit.
- Exports V26 Agent JSON and flat CSV with Operation included.
- Same Source/Target/interface mapper is used after upload.

## LIVE boundary statement

Automated tests exercise Analyze -> Stage -> Preflight -> LIVE executor -> `requests.request(...)` -> deterministic response classification -> Dell audit/checking verification -> Migration preflight -> Migration executor. The final external Dell network boundary is mocked in automated validation; no authenticated mutating Dell request was sent from the validation environment.

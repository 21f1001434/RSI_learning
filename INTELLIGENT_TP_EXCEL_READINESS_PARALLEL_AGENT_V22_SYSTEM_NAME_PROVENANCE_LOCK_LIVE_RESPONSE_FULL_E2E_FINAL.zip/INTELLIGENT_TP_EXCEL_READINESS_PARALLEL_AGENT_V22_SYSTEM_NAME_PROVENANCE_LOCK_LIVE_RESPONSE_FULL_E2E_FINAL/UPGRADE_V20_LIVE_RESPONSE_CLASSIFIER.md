# V20 Upgrade — Governed LIVE API + Response Intelligence

## Purpose

V20 completes the Transport Profile LIVE loop so the application does not stop at “HTTP request sent”. The exact staged payload is sent to the approved Dell HIP Create endpoint only after Stage, Preflight, runtime gates, immutable-contract checks, and explicit human confirmation. The resulting Dell response is then classified using deterministic evidence and independently verified with the Dell TP checking/audit API.

V20 retains all V19 behavior: same-TP multi-document consolidation, grouped System Name detection, flexible Dell/Client Sender/Receiver ownership, editable values before Stage, all seven interface contracts, Migration, and LLM-as-Judge.

## LIVE network boundary

When `HIP_LIVE_API_EXECUTION=true` and the operator types `LIVE` (or `LIVE ALL` for bulk), the backend reaches the real network boundary in `app/executor.py`:

```text
requests.request(
    method,
    resolved Dell HIP URL,
    headers=resolved OAuth/governed headers,
    json=canonical staged TP payload,
    timeout=...,
    verify=...
)
```

The outgoing payload is rebuilt from the immutable interface-specific canonical schema plus approved staged leaf values immediately before the call. Keys, nesting, array cardinality, URL, method, interface selector, role selector, and contract-owned values remain locked.

## Final classifications

V20 exposes `outcomeClassification` with four values:

| Classification | Meaning |
|---|---|
| `SUCCESS` | A new TP Create is terminally verified successful by the Dell TP checking/audit API. |
| `EXISTING` | Dell explicitly reports the exact Transport Profile already exists and the checking API verifies that exact TP. |
| `FAILED` | HTTP rejection, semantic failure in the body (including a 2xx body), or terminal audit failure. |
| `PENDING` | Dell accepted the request, but terminal verification is not yet available. |

`PENDING` is deliberate. The system will not label an unverified request SUCCESS merely because HTTP returned 200/201/202, and it will not call a still-processing request FAILED without failure evidence.

## 2xx semantic-failure hardening

V19 primarily used the configured success HTTP statuses to decide whether Create was accepted. V20 adds `app/response_intelligence.py` and evaluates structured response fields and response text before post-create verification.

Examples:

```json
{"status":"FAILED","message":"Transport Profile creation failed"}
```

Even with HTTP 200, this is `FAILED` and does not enter the success-verification path.

```json
{"success":false,"errorMessage":"request rejected"}
```

This is also `FAILED` even if the transport status is 2xx.

```json
{"message":"Transport Profile TP_X already exists in DEV"}
```

This is `EXISTING` evidence only because it explicitly identifies the Transport Profile. A generic message such as `System name already exists` is **not** reclassified as an existing TP.

## Existing-object handling

There are two existing-object paths:

1. **Pre-create validator reports exact TP exists** — duplicate Create is skipped and the checking API verifies the TP.
2. **Create endpoint reports exact TP exists** — the response is classified `EXISTING`, then the checking API verifies the exact TP identity.

Only verified exact-TP evidence is presented as final `EXISTING`. Otherwise the result remains `PENDING`/unverified.

## Post-create verification

For a newly accepted Create, V20 continues the V14/V19 baseline-aware audit flow:

```text
read audit baseline
  ↓
LIVE Create
  ↓
classify immediate response
  ↓
if accepted: poll GET /api/transport-profiles/audits
  ↓
new terminal SUCCESS → SUCCESS
new terminal FAILURE → FAILED
no terminal result before timeout → PENDING
```

An old historical SUCCESS record is not sufficient to verify a new Create because the verifier compares the post-Create audit record with the pre-Create baseline.

## Dell AIA response interpreter

`HIP_TP_RESPONSE_AGENT_ENABLED=true` enables a read-only Dell AIA interpretation after deterministic classification. The agent receives redacted evidence only and returns an advisory explanation/classification.

It cannot:

- alter `outcomeClassification`;
- mutate any TP value or attribute;
- approve or execute an API;
- override checking/audit evidence.

If the model disagrees with deterministic evidence, the deterministic result is retained and the disagreement is visible in `responseAgent.agreement`.

Configuration:

```text
HIP_TP_RESPONSE_AGENT_ENABLED=true
HIP_TP_RESPONSE_AGENT_MODEL=gpt-oss-120b
```

The response classifier itself does **not** depend on Dell AIA and continues to work when model credentials are unavailable.

## UI and history

Single LIVE execution, batch LIVE results, and execution history now surface the operator-facing classification instead of treating every successful run as “created”. This prevents an existing TP from being displayed as a newly created TP.

The run evidence includes:

```text
outcomeClassification
responseClassification
responseAgent
resultState
createAccepted
existing
verifiedCreated
verifiedExisting
postCreateVerification
responseSummary
```

## Universal workbook safety

The bundled workbook contains reference and dummy sheets. V20 excludes these from automatic execution scans:

```text
README
INTERFACE_MATRIX
FIELD_GUIDE
ALLOWED_VALUES
DUMMY_EXAMPLES
```

This is important for LIVE mode: dummy examples can never become automatic Create candidates merely because `scan_all_sheets=true`. The team should place real rows in `TP_INPUT`.

## Supported interfaces retained

The same governed Create path remains supported for Source/Sender and Target/Receiver across:

- SFTP HAFT
- SFTP Server
- FTP
- HTTPS
- HTTPS-AS2
- NAS
- Rabbit MQ

The selected Excel interface determines the approved immutable payload schema before mapping.

## LIVE setup

Use `.env.live.example` as the minimal LIVE configuration reference. The important execution controls are:

```text
HIP_LIVE_API_EXECUTION=true
HIP_TP_VALIDATE_BEFORE_CREATE=true
HIP_TP_POST_CREATE_CHECK_ENABLED=true
HIP_TP_RESPONSE_AGENT_ENABLED=true
ALLOWED_API_HOSTS=apigtwtst.us.dell.com
```

The UI still requires exact `LIVE` or `LIVE ALL` confirmation. PROD additionally requires `PRODUCTION_EXECUTION_CONFIRMATION=YES` and `CHANGE_TICKET`.

## Test boundary

Automated release tests use the real application code up to `requests.request(...)` and mock only the external Dell HTTP boundary. No real Dell Create/Migration mutation was performed while packaging V20.

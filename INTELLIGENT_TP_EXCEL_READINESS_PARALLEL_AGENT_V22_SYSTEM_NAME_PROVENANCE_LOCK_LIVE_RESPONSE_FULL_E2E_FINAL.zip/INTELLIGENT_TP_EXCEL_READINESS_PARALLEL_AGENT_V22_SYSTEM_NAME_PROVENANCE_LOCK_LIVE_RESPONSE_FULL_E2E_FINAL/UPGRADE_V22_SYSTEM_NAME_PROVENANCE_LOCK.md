# V22 Upgrade — systemName Provenance Lock / Anti-Hallucination Hardening

## Problem fixed

A Transport Profile could contain the correct Excel System Name (for example `AIC - DCE`) while unrelated partner/reference evidence such as a Partner Name was also present. A stale reference value could then surface as `systemName`, causing LIVE execution to look for the wrong HIP system (for example a partner/reference name) and return a "not found" response.

V22 makes `systemName` a protected identity value rather than an inferred free-text field.

## V22 source-of-truth rule

For a **Source/Sender** Transport Profile, `systemName` can be populated automatically only from the role-correct Excel Source System / Source System Name (or a safe generic System Name when the opposite side is absent).

For a **Target/Receiver** Transport Profile, the same rule applies to the role-correct Target System / Target System Name.

The following are never permitted to auto-substitute `systemName`:

- Partner Name
- Existing Account Name / HIP Account
- Dell-vs-Partner ownership labels
- deployment group values
- U-HAUL reference/smoke values
- LLM/Judge suggestions
- fuzzy semantic guesses from unrelated columns

Example enforced by regression test:

```text
Excel Source System = AIC - DCE
Partner Name        = dce-test-partner

Resulting payload:
systemName          = AIC - DCE
```

## Defense in depth

### Analyze

The analyzer records explicit provenance:

```text
systemSourceColumn
systemSourceValue
systemNameProvenance.approvedValue
systemNameProvenance.mode
systemNameProvenance.autoSubstitutionAllowed = false
```

An optional `TP Role`, `Transport Profile Role`, `TP Usage`, `Transport Profile Usage`, or Sender/Receiver field is honored before heuristic role detection.

### Stage

For TP actions carrying V22 provenance, Stage rejects a payload when `systemName` differs from the approved Excel-provenance value. The stage also stores a hash of the provenance metadata.

### Preflight

Preflight rechecks:

- protected provenance metadata exists
- metadata hash has not changed
- automatic substitution remains disabled
- payload `systemName` is populated
- payload `systemName` equals the approved value

A tampered staged payload is therefore blocked before LIVE.

### LIVE execution

Immediately before the outbound `requests.request(...)` call, the executor performs the same provenance check again. This prevents post-Preflight mutation from reaching Dell HIP.

## Legitimate human correction

A real correction is still supported. The operator must use **Apply value edits & revalidate**. The edit is recorded in `humanValueEditPaths`, provenance switches to `HUMAN_CONFIRMED_VALUE_EDIT`, readiness/Judge evaluation is rerun, and the newly approved value can then be staged.

Direct/unreviewed replacement is blocked.

## U-HAUL reference cleanup

The non-mutating U-HAUL reference helper no longer hardcodes a target partner System Name. `HIP_UHAL_TARGET_SYSTEM_NAME` is optional and defaults blank. Reference/smoke values do not participate in normal workbook TP mapping.

## Existing V21 behavior retained

V22 retains:

- all seven TP interfaces
- separate interface-sheet team workbook with filters/dropdowns
- same-TP multi-document consolidation into `documentTypeDetails[]`
- flexible Dell/Client Sender/Receiver ownership
- values-only governed editing
- immutable Stage contract
- pre-create validation
- real gated LIVE Create path
- post-create checking/audit verification
- deterministic `SUCCESS` / `EXISTING` / `FAILED` / `PENDING` classification
- optional Dell AIA `gpt-oss-120b` response explanation and LLM-as-Judge
- V130 TP Migration controls

The LLM remains advisory and cannot mutate `systemName`, the request schema, endpoint, method, or deterministic outcome.

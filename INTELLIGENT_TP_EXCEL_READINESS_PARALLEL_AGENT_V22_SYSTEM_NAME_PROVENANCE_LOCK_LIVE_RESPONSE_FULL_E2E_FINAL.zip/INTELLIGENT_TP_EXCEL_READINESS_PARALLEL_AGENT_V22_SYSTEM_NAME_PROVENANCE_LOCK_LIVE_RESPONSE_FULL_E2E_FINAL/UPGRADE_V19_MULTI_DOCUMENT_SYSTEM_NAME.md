# V19 Upgrade — Multi-Document TP Rows + System Name Detection

## Why this release exists

V18 correctly supported value edits and flexible Sender/Receiver ownership, but it still treated two Excel rows with the same TP identity and different Document Types as conflicting duplicate payloads. It also could report `systemName` as missing when a valid value was present under a grouped/context-qualified header such as `Transport Profile Details > System Name`.

V19 fixes both at the ingestion/contract layer so the behavior is preserved through Stage, Preflight, Create verification, and Migration workflows.

## 1. Same TP name + multiple Document Types

When multiple Excel rows have the same TP identity (`apiKey + systemName + transportProfileName`) and every payload value outside `documentTypeDetails` is identical, V19 emits one TP action and one payload.

Each distinct Document Type row becomes another dictionary in:

```json
transportProfileDetails[0].documentTypeDetails
```

Example:

```json
"documentTypeDetails": [
  {
    "documentTypeName": "perf_poa_855_edf",
    "documentTypeVersion": "1.0",
    "dataFormatType": "EDIX12"
  },
  {
    "documentTypeName": "2BDoctype10.0",
    "documentTypeVersion": "1.0",
    "dataFormatType": "XML"
  },
  {
    "documentTypeName": "AGING_FLATFILE",
    "documentTypeVersion": "3.0",
    "dataFormatType": "FLAT"
  }
]
```

### Merge safety rule

Only Document Type differences are auto-consolidated. If the same TP identity has a different interface, account, Subscription Folder, server/parameter value, or any other non-document payload value, the rows remain a conflicting duplicate and require human review.

Exact duplicate document dictionaries are de-duplicated.

## 2. Immutable contract still enforced

The HTTP boundary is not weakened. During analysis, V19 materializes a per-action canonical contract whose `documentTypeDetails` array has the exact number of approved dictionaries derived from Excel. That cardinality is then frozen.

After analysis:

- users may edit scalar values in the existing document dictionaries;
- users cannot add/remove document dictionaries through the generic payload editor;
- JSON keys and nesting remain locked;
- other array cardinalities remain locked;
- interface/role/ownership contract selectors remain locked according to the existing governance rules.

This allows the backend-supported repeatable document collection without opening generic schema mutation.

## 3. Data Format Type support

Explicit Excel aliases are now supported for the document `dataFormatType` value:

- `Data Format Type`
- `Document Data Format Type`
- `Document Type Data Format`
- `Data Format`

No LLM guess is used for this provenance-locked field.

## 4. System Name false-missing fix

V19 accepts exact and grouped/contextual System Name leaves including:

- `Source System`
- `Source System Name`
- `Target System`
- `Target System Name`
- `System`
- `System Name`
- `Transport Profile Details > System Name`

The final header leaf must be exactly `System` or `System Name` for the contextual generic fallback. This intentionally excludes `System Type`, ownership columns, interface columns, and other fuzzy system-related fields.

Source/Target cross-mapping remains blocked.

## 5. Ownership rebuild preservation

If a multi-document action still needs human Dell/Client ownership confirmation, **Apply ownership & rebuild contract** now preserves all `documentTypeDetails` entries while rebuilding the ownership-dependent interface contract before Stage.

## 6. UI visibility

The TP queue now shows the number of document types and the combined document names. The action facts panel also reports the multi-document count. The exact payload viewer and field matrix expose each array item separately.

## Regression coverage

Added `tests/test_v19_multi_document_and_system_name.py` covering:

1. 3 Excel rows for one TP merge into 3 document dictionaries.
2. `dataFormatType` is retained independently for each document.
3. Grouped `... > System Name` maps to `systemName` and is not reported missing.
4. Ownership rebuild preserves all document dictionaries.
5. Multi-document action can be staged with the expanded immutable contract.

Full suite result: **141 passed, 0 failed**.

@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo .venv not found. Run SETUP_APP.bat first.
  exit /b 1
)
call .venv\Scripts\activate.bat
echo Starting Intelligent Excel -^> API Decision Agent on http://127.0.0.1:8088
python -m uvicorn app.main:app --host 127.0.0.1 --port 8088
endlocal

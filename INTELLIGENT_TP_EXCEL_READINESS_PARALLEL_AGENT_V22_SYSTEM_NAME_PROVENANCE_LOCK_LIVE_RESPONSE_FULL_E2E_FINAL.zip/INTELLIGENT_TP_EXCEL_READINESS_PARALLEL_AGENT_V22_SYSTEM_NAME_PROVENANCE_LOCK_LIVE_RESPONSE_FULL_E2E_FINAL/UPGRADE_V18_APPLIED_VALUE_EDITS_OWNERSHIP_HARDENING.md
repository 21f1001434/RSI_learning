# V18 Upgrade — Applied Value Edits + Ownership Hardening

## What changed

- Added `POST /api/tp/analyses/{analysisId}/actions/{actionId}/values`.
- Added **Apply value edits & revalidate** to the review UI.
- Human edits are values-only; JSON keys, nesting, arrays, interface schema, role/interface selectors, system ownership selector, method/URL and other contract-owned values remain immutable.
- Missing required values can now be corrected while a row is `NEEDS_INPUT`; the action is fully revalidated and can transition to `GOOD_TO_TRIGGER`.
- Human-edited values are persisted back into all TP analysis mirrors, so later batch Stage uses the corrected payload rather than stale pre-edit evidence.
- Human edits become explicit mapping provenance (`HUMAN_CONFIRMED_VALUE_EDIT`), including identity-field confirmation.
- Ownership remains independent from direction: Source=Sender and Target=Receiver, but either side can be Dell Application or Client/Partner.
- Approved U-HAUL reference is explicitly regression-tested as Sender=Dell Application and Receiver=Client/Partner.
- Ownership contract rebuild is rejected after a Stage snapshot already exists for that analyzed TP, protecting staged immutability.

## Governed flow

`Excel → analyze → resolve Sender/Receiver role → resolve Dell/Client ownership → edit missing/customer values → Apply value edits & revalidate → deterministic readiness + LLM Judge → Stage → Preflight → Dell validator → LIVE Create → audit verification → optional Migration`

## Safety invariant

`Interface chooses attributes → ownership may choose approved conditional shape before Stage → attributes/selectors locked → customer leaf values editable → Stage freezes exact values and shape.`

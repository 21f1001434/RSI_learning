# V5 Upgrade — Excel-Authoritative Interface Type

## Requirement

The team workbook will provide the Transport Profile interface type. The agent must **read that value from Excel and map the row to the matching TP API contract**. It must not infer interface type.

## Implemented policy

1. Read only `Source Interface Type`, `Target Interface Type`, or exact `Interface Type`.
2. Missing explicit interface → `NEEDS INPUT`; no heuristic/LLM inference.
3. Unsupported explicit interface → `NOT READY`; no reinterpretation.
4. Lock the V122 interface-specific TP contract deterministically from the Excel value.
5. Force the interface payload mapping to use the exact Excel source column with confidence `1.0` and method `Explicit Excel interface lock`.
6. LLM can map other TP fields only after the interface contract is selected.
7. UI/HTML report displays both the raw Excel interface value/source column and the canonical API interface value.

## Example

Excel: `Source Interface Type = SFTP`

- Evidence retained as `SFTP` from `Source Interface Type`.
- Matching approved V122 FILE contract is selected.
- API canonical value becomes `SFTP HAFT`.
- Report shows `Excel: SFTP` → `API: SFTP HAFT`.

If `Source Interface Type` is blank while `SFTP Server` or TP name contains SFTP, the application does **not** guess SFTP.

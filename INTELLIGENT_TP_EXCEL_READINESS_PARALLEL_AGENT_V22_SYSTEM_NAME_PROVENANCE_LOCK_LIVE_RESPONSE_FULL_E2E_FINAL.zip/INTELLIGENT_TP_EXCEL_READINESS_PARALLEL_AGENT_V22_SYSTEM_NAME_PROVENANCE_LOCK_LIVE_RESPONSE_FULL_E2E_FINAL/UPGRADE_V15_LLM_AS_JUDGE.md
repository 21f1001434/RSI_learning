# V15 — Independent LLM-as-Judge + Verified Create/Migration

## Purpose

V15 adds an independent Dell AIA Judge role around the deterministic Transport Profile pipeline. It does **not** replace deterministic validation and it does **not** gain payload mutation or API execution authority.

## Judge checkpoints

The Judge evaluates redacted evidence at five points:

1. Mapping readiness (`MAPPING_READINESS`)
2. Create preflight (`PRE_LIVE`)
3. Post-Create verification (`POST_CREATE_VERIFICATION`)
4. Migration preflight (`PRE_MIGRATION`)
5. Post-Migration verification (`POST_MIGRATION_VERIFICATION`)

## Authority model

Deterministic validation remains authoritative.

- Deterministic `BLOCK` + Judge `PASS` => final `BLOCK`
- Deterministic `PASS` + Judge `REVIEW` => final `REVIEW`
- Deterministic `PASS` + Judge `BLOCK` => final `BLOCK`
- Judge cannot create/remove/rename/re-nest TP attributes
- Judge cannot change interface/role/runtime selectors
- Judge cannot change URL/method/headers
- Judge cannot execute Create or Migration

The Judge therefore acts as a second reviewer, never as an execution agent.

## Configuration

```text
LLM_JUDGE_ENABLED=true
LLM_JUDGE_MODEL=gpt-oss-120b
LLM_JUDGE_TEMPERATURE=0
LLM_JUDGE_REQUIRED_FOR_LIVE=false
LLM_JUDGE_FAIL_CLOSED=false
```

Default mode is advisory. To require the Judge before Create/Migration:

```text
LLM_JUDGE_REQUIRED_FOR_LIVE=true
LLM_JUDGE_FAIL_CLOSED=true
```

When mandatory, an unavailable or non-PASS Judge blocks the mutating network call.

## Security and privacy

Judge evidence is redacted before it is sent to Dell AIA. Common secret fields (authorization, access tokens, passwords, API keys, private keys/certificates and configured sensitive paths) are removed/redacted. The Judge prompt receives only the evidence needed to assess the TP decision.

## UI/report additions

V15 shows Judge state independently from deterministic readiness:

- top health/runtime Judge status
- Judge verdict in TP queue
- per-customer Judge reasoning
- Create preflight Judge
- post-Create verification Judge
- Migration preflight Judge
- post-Migration Judge
- Judge verdict in execution history/HTML reports

This preserves explainability: an operator can see whether a TP was blocked by deterministic contract logic, Dell API evidence, or the Judge.

## Create verification retained

Create is not considered successful from HTTP 2xx alone:

`Pre-create validator -> Create -> GET /api/transport-profiles/audits -> exact new successful audit -> VERIFIED_CREATED`

The post-Create Judge evaluates the verified evidence but cannot promote an unverified Create.

## Migration retained

Exact V130 TP Migration API:

```text
POST /api/migration/orchestration/transport-profile
```

Immutable request attributes:

```text
sourceEnvironment
targetEnvironment
transportProfileName
transportProfileInterfaceType
transportProfileInterfaceParameters
```

Migration reuses the selected immutable interface parameter structure for SFTP HAFT, SFTP Server, FTP, HTTPS, HTTPS-AS2, NAS, and Rabbit MQ.

Migration success can also be checked in the target environment before `VERIFIED_MIGRATED` is reported.

## U-HAUL reference guidance retained

U-HAUL remains an approved reference pattern for SFTP HAFT suggestions. Suggestions are advisory unless already covered by an approved deterministic alias. They never mutate a selected interface contract or bypass Stage/Preflight/Judge/Dell validation.

## Runtime endpoints

- `GET /api/health`
- `GET /api/bootstrap`
- `POST /api/judge/test`
- `POST /api/stages/{stage_id}/judge`
- `POST /api/runs/{run_id}/judge`
- `GET /api/runtime/live-readiness`
- `GET /api/runtime/migration-readiness`

## Release validation

The exact V15 source passed 130/130 automated tests, Python compilation, frontend JavaScript syntax validation, local API/UI smoke checks, seven-interface catalog validation, V130 environment-key parity, and ZIP integrity validation. Automated release tests mock the final external Dell mutation boundary; they do not create or migrate a real Dell TP from the packaging environment.

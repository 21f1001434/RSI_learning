@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if not exist .env (
  copy .env.example .env >nul
)
echo.
echo Setup complete.
echo Edit .env with the same V122 HIP / Account / Partner / System / Dell AIA settings used by your validated codebase.
echo Then run RUN_APP.bat
endlocal

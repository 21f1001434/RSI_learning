from __future__ import annotations
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Unit/regression runs never call a real Dell endpoint. V12-specific tests turn
# this on explicitly and mock only the HTTP boundary.
os.environ.setdefault("HIP_TP_VALIDATE_BEFORE_CREATE", "false")
# Keep legacy unit tests fast; dedicated V13/V14 verification tests opt in and
# mock the audit/checking boundary explicitly.
os.environ.setdefault("HIP_TP_POST_CREATE_CHECK_ENABLED", "false")
os.environ.setdefault("HIP_TP_MIGRATION_POST_CHECK_ENABLED", "false")

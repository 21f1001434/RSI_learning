from __future__ import annotations

import csv
import io
from copy import deepcopy

from fastapi.testclient import TestClient

from app.catalog import load_catalog, schema_locked
from app.main import app
from app.tp_service import analyze_tp_workbook, rebuild_action_ownership


def csv_rows(headers, rows) -> bytes:
    out = io.StringIO(newline="")
    writer = csv.writer(out)
    writer.writerow(headers)
    writer.writerows(rows)
    return out.getvalue().encode("utf-8")


def multi_doc_csv(*, include_ownership: bool = True) -> bytes:
    headers = [
        "Source System",
        "Transport Profile Name",
        "Interface Type",
        "Document Type Name",
        "Document Type Version",
        "Data Format Type",
        "Existing Account Name",
        "Subscription Folder",
    ]
    if include_ownership:
        headers.insert(1, "Source System Type")
    base = [
        ["AIC - DCE", "TP_MULTI_DOC_SRC_IB", "SFTP", "perf_poa_855_edf", "1.0", "EDIX12", "acct-multi", "/multi"],
        ["AIC - DCE", "TP_MULTI_DOC_SRC_IB", "SFTP", "2BDoctype10.0", "1.0", "XML", "acct-multi", "/multi"],
        ["AIC - DCE", "TP_MULTI_DOC_SRC_IB", "SFTP", "AGING_FLATFILE", "3.0", "FLAT", "acct-multi", "/multi"],
    ]
    if include_ownership:
        base = [[r[0], "Dell", *r[1:]] for r in base]
    else:
        base = [["SYS-AMB", *r[1:]] for r in base]
    return csv_rows(headers, base)


def test_v19_same_tp_rows_merge_into_repeatable_document_type_details():
    out = analyze_tp_workbook(
        filename="tp.csv",
        data=multi_doc_csv(),
        contracts=load_catalog(),
        scope="SOURCE",
        use_llm=False,
    )
    assert len(out["tpActions"]) == 1
    row = out["tpActions"][0]
    docs = row["proposedRequest"]["transportProfileDetails"][0]["documentTypeDetails"]

    assert docs == [
        {"documentTypeName": "perf_poa_855_edf", "documentTypeVersion": "1.0", "dataFormatType": "EDIX12"},
        {"documentTypeName": "2BDoctype10.0", "documentTypeVersion": "1.0", "dataFormatType": "XML"},
        {"documentTypeName": "AGING_FLATFILE", "documentTypeVersion": "3.0", "dataFormatType": "FLAT"},
    ]
    assert row["documentTypeCount"] == 3
    assert row["documentTypeNames"] == ["perf_poa_855_edf", "2BDoctype10.0", "AGING_FLATFILE"]
    assert row["mergedDocumentTypeRows"] == 3
    assert row["status"] == "GOOD_TO_TRIGGER"
    assert len(row["baseRequest"]["transportProfileDetails"][0]["documentTypeDetails"]) == 3
    assert len(row["contractSnapshot"]["canonical_request"]["transportProfileDetails"][0]["documentTypeDetails"]) == 3
    assert schema_locked(row["baseRequest"], row["proposedRequest"])
    assert any(m["targetPath"].endswith("documentTypeDetails.1.dataFormatType") for m in row["mappings"])
    assert any(m["targetPath"].endswith("documentTypeDetails.2.documentTypeName") for m in row["mappings"])


def test_v19_contextual_system_name_leaf_is_not_reported_missing():
    data = csv_rows(
        [
            "Add > Transport Profile Details > System Name",
            "Source System Type",
            "Transport Profile Name",
            "Interface Type",
            "Existing Account Name",
            "Subscription Folder",
        ],
        [["AIC - DCE", "Dell", "TP_SYSTEM_CONTEXT_SRC_IB", "SFTP", "acct-system", "/system"]],
    )
    out = analyze_tp_workbook(
        filename="tp.csv",
        data=data,
        contracts=load_catalog(),
        scope="SOURCE",
        use_llm=False,
    )
    row = out["tpActions"][0]
    assert row["systemName"] == "AIC - DCE"
    assert row["systemSourceColumn"] == "Add > Transport Profile Details > System Name"
    assert row["proposedRequest"]["systemName"] == "AIC - DCE"
    assert "systemName" not in row["missingRequiredPaths"]
    assert any(m["targetPath"] == "systemName" and m["sourceColumn"] == "Add > Transport Profile Details > System Name" for m in row["mappings"])


def test_v19_ownership_rebuild_preserves_all_document_types():
    out = analyze_tp_workbook(
        filename="tp.csv",
        data=multi_doc_csv(include_ownership=False),
        contracts=load_catalog(),
        scope="SOURCE",
        use_llm=False,
    )
    row = out["tpActions"][0]
    assert row["ownershipResolved"] is False
    assert len(row["proposedRequest"]["transportProfileDetails"][0]["documentTypeDetails"]) == 3

    base = next(c for c in load_catalog() if c["key"] == "source_tp")
    rebuilt = rebuild_action_ownership(deepcopy(row), base, "Client")
    docs = rebuilt["proposedRequest"]["transportProfileDetails"][0]["documentTypeDetails"]
    assert len(docs) == 3
    assert [d["documentTypeName"] for d in docs] == ["perf_poa_855_edf", "2BDoctype10.0", "AGING_FLATFILE"]
    assert rebuilt["systemType"] == "Partner"
    assert rebuilt["ownershipResolved"] is True
    assert schema_locked(rebuilt["baseRequest"], rebuilt["proposedRequest"])


def test_v19_multi_document_action_can_stage_with_expanded_immutable_contract():
    client = TestClient(app)
    analyzed = client.post(
        "/api/tp/analyze",
        files={"workbook": ("tp.csv", multi_doc_csv(), "text/csv")},
        data={"tp_scope": "SOURCE", "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert analyzed.status_code == 200, analyzed.text
    result = analyzed.json()
    assert len(result["allApiResults"]) == 1
    row = result["allApiResults"][0]
    assert row["status"] == "GOOD_TO_TRIGGER"

    staged = client.post(
        "/api/stage",
        json={
            "analysisId": result["analysisId"],
            "rowId": row["actionId"],
            "payload": row["proposedRequest"],
            "reviewer": "V19 Test Reviewer",
        },
    )
    assert staged.status_code == 200, staged.text
    stage = staged.json()["stage"]
    assert len(stage["payload"]["transportProfileDetails"][0]["documentTypeDetails"]) == 3
    assert len(stage["contractSnapshot"]["canonical_request"]["transportProfileDetails"][0]["documentTypeDetails"]) == 3

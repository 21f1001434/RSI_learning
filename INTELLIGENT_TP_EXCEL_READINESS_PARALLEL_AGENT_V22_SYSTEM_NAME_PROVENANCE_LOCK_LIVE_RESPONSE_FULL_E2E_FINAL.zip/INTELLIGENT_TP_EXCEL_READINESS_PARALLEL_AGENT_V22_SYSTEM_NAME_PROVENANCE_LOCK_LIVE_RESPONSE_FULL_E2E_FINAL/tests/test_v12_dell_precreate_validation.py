from __future__ import annotations

import csv
import io
from copy import deepcopy

from fastapi.testclient import TestClient

from app.main import app


def _live_env(monkeypatch):
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v12-test")
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_REQUESTED_BY", "v12-test@dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setenv("HIP_TP_VALIDATE_BEFORE_CREATE", "true")


def _analysis(client):
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["Source System", "Transport Profile Name", "Interface Type", "Existing Account Name", "Subscription Folder"])
    w.writerow(["AIC - DCE", "TP_V12_SRC_IB", "SFTP", "acct-v12", "/TP_V12_SRC_IB"])
    r = client.post("/api/tp/analyze", files={"workbook": ("tp.csv", out.getvalue().encode(), "text/csv")}, data={"tp_scope":"SOURCE", "use_llm":"false"})
    assert r.status_code == 200, r.text
    row = r.json()["tpActions"][0]
    assert row["status"] == "GOOD_TO_TRIGGER", row
    return r.json(), row


def _stage(client, analysis, row):
    r = client.post("/api/stage", json={"analysisId": analysis["analysisId"], "rowId": row["actionId"], "payload": deepcopy(row["proposedRequest"]), "reviewer":"V12 Test"})
    assert r.status_code == 200, r.text
    return r.json()["stage"]


def test_v12_preflight_blocks_create_when_exact_dell_validator_rejects(monkeypatch):
    _live_env(monkeypatch)
    calls = []
    class Resp:
        status_code = 400
        text = '{"message":"Existing Account Name is invalid"}'
        def json(self): return {"message":"Existing Account Name is invalid", "field":"Existing Account Name"}
    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs.get("json")))
        return Resp()
    monkeypatch.setattr("app.executor.requests.request", fake_request)
    client = TestClient(app)
    analysis, row = _analysis(client)
    stage = _stage(client, analysis, row)
    pf = client.post(f"/api/stages/{stage['stageId']}/preflight").json()["preflight"]
    assert pf["passed"] is False
    assert pf["executionReady"] is False
    assert pf["dellTpValidation"]["state"] == "REJECTED"
    assert "Existing Account Name is invalid" in pf["dellTpValidation"]["responseSummary"]
    assert calls and calls[0][1].endswith("/api/transport-profiles/validate-unique-interface-detail")
    # Mutating create endpoint is never called when validation rejects the values.
    assert not any(url.endswith("/api/transport-profiles/orchestration/create") for _, url, _ in calls)


def test_v12_create_400_is_saved_as_dell_rejected_with_response_summary(monkeypatch):
    _live_env(monkeypatch)
    class Resp:
        def __init__(self, status, body): self.status_code=status; self._body=body; self.text=str(body)
        def json(self): return self._body
    calls=[]
    def fake_request(method, url, **kwargs):
        calls.append(url)
        if url.endswith("/validate-unique-interface-detail"):
            return Resp(200, {"valid":True})
        return Resp(400, {"message":"Transport Profile payload rejected", "errors":["Subscription Folder invalid"]})
    monkeypatch.setattr("app.executor.requests.request", fake_request)
    client=TestClient(app)
    analysis,row=_analysis(client); stage=_stage(client,analysis,row)
    pf=client.post(f"/api/stages/{stage['stageId']}/preflight").json()["preflight"]
    assert pf["executionReady"] is True, pf
    live=client.post(f"/api/stages/{stage['stageId']}/execute", json={"confirmation":"LIVE","actor":"V12 Test"})
    assert live.status_code == 200, live.text
    run=live.json()["run"]
    assert run["success"] is False
    assert run["dellReached"] is True
    assert run["dellAccepted"] is False
    assert run["resultState"] == "REJECTED"
    assert "Subscription Folder invalid" in run["responseSummary"]
    assert any(url.endswith("/orchestration/create") for url in calls)


def test_v12_preflight_exposes_blank_required_and_optional_counts(monkeypatch):
    # LIVE disabled means no remote request; local completeness diagnostics still exist.
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "false")
    monkeypatch.setenv("HIP_TP_VALIDATE_BEFORE_CREATE", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v12-test")
    client=TestClient(app)
    analysis,row=_analysis(client); stage=_stage(client,analysis,row)
    pf=client.post(f"/api/stages/{stage['stageId']}/preflight").json()["preflight"]
    assert "blankCanonicalPaths" in pf
    assert "blankOptionalPaths" in pf
    assert pf["blankCanonicalCount"] >= pf["blankOptionalCount"]
    assert isinstance(pf["missingRequiredPaths"], list)

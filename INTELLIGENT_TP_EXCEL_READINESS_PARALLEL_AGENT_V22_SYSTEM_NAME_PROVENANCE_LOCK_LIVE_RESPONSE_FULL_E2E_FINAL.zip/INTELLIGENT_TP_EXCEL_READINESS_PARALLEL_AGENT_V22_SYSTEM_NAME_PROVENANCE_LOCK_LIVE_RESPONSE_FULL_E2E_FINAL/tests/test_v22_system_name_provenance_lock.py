from __future__ import annotations

import csv
import io
from copy import deepcopy

from fastapi.testclient import TestClient

from app.catalog import load_catalog
from app.main import app
from app.state import STATE
from app.tp_service import analyze_tp_workbook
from app.uhal_reference import create_payload as uhal_create_payload


def _csv(headers, rows) -> bytes:
    s = io.StringIO(newline="")
    w = csv.writer(s)
    w.writerow(headers)
    w.writerows(rows)
    return s.getvalue().encode("utf-8")


def _source_csv(*, tp_role: str = "") -> bytes:
    headers = [
        "Customer Name",
        "Source System",
        "Source System Type",
        "Target System",
        "Target System Type",
        "Partner Name",
        "Transport Profile Name",
        "Interface Type",
        "Document Type Name",
        "Document Type Version",
        "Data Format Type",
        "Existing Account Name",
        "Subscription Folder",
    ]
    values = [
        "U-HAUL",
        "AIC - DCE",
        "Dell Application",
        "CLIENT-RECEIVER-SYSTEM",
        "Partner",
        "dce-test-partner",
        "TP_V22_SYSTEM_LOCK_SRC_IB",
        "SFTP HAFT",
        "DOC_V22",
        "1.0",
        "XML",
        "acct-v22",
        "/v22",
    ]
    if tp_role:
        headers.insert(1, "TP Role")
        values.insert(1, tp_role)
    return _csv(headers, [values])


def _analyze_source(client: TestClient):
    r = client.post(
        "/api/tp/analyze",
        files={"workbook": ("v22.csv", _source_csv(), "text/csv")},
        data={"tp_scope": "SOURCE", "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert len(body["allApiResults"]) == 1
    return body, body["allApiResults"][0]


def test_v22_excel_system_name_wins_and_partner_name_can_never_substitute():
    out = analyze_tp_workbook(
        filename="v22.csv",
        data=_source_csv(),
        contracts=load_catalog(),
        scope="SOURCE",
        use_llm=False,
    )
    row = out["tpActions"][0]
    assert row["systemName"] == "AIC - DCE"
    assert row["proposedRequest"]["systemName"] == "AIC - DCE"
    assert row["systemSourceColumn"] == "Source System"
    assert row["systemSourceValue"] == "AIC - DCE"
    assert row["systemNameProvenance"]["approvedValue"] == "AIC - DCE"
    assert row["systemNameProvenance"]["autoSubstitutionAllowed"] is False
    assert row["systemNameProvenanceFindings"] == []
    system_mapping = next(m for m in row["mappings"] if m["targetPath"] == "systemName")
    assert system_mapping["sourceColumn"] == "Source System"
    assert system_mapping["mappedValue"] == "AIC - DCE"
    assert "dce-test-partner" != row["proposedRequest"]["systemName"]


def test_v22_stage_blocks_unreviewed_system_name_substitution():
    client = TestClient(app)
    analyzed, row = _analyze_source(client)
    payload = deepcopy(row["proposedRequest"])
    payload["systemName"] = "dce-test-partner"
    staged = client.post(
        "/api/stage",
        json={
            "analysisId": analyzed["analysisId"],
            "rowId": row["actionId"],
            "payload": payload,
            "reviewer": "V22 Reviewer",
        },
    )
    assert staged.status_code == 400
    assert "SYSTEM_NAME_PROVENANCE_LOCK" in staged.text
    assert "dce-test-partner" in staged.text
    assert "AIC - DCE" in staged.text


def test_v22_human_value_editor_can_explicitly_override_system_name_then_stage():
    client = TestClient(app)
    analyzed, row = _analyze_source(client)
    payload = deepcopy(row["proposedRequest"])
    payload["systemName"] = "AIC - DCE MANUAL OVERRIDE"
    edited = client.post(
        f"/api/tp/analyses/{analyzed['analysisId']}/actions/{row['actionId']}/values",
        json={"payload": payload, "actor": "V22 Human Reviewer"},
    )
    assert edited.status_code == 200, edited.text
    updated = edited.json()["action"]
    assert "systemName" in updated["humanValueEditPaths"]
    assert updated["systemNameProvenance"]["mode"] == "HUMAN_CONFIRMED_VALUE_EDIT"
    assert updated["systemNameProvenance"]["approvedValue"] == "AIC - DCE MANUAL OVERRIDE"
    assert updated["systemNameProvenanceFindings"] == []

    staged = client.post(
        "/api/stage",
        json={
            "analysisId": analyzed["analysisId"],
            "rowId": row["actionId"],
            "payload": updated["proposedRequest"],
            "reviewer": "V22 Human Reviewer",
        },
    )
    assert staged.status_code == 200, staged.text
    stage = staged.json()["stage"]
    assert stage["payload"]["systemName"] == "AIC - DCE MANUAL OVERRIDE"
    assert stage["systemNameProvenance"]["humanOverride"] is True


def test_v22_preflight_blocks_stage_file_tampering_of_system_name():
    client = TestClient(app)
    analyzed, row = _analyze_source(client)
    staged = client.post(
        "/api/stage",
        json={
            "analysisId": analyzed["analysisId"],
            "rowId": row["actionId"],
            "payload": row["proposedRequest"],
            "reviewer": "V22 Reviewer",
        },
    )
    assert staged.status_code == 200, staged.text
    stage = staged.json()["stage"]

    # Simulate out-of-band stage-file tampering before Preflight.
    tampered = STATE.get_stage(stage["stageId"])
    tampered["payload"]["systemName"] = "dce-test-partner"
    STATE.save_stage(tampered)

    pf = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf.status_code == 200, pf.text
    result = pf.json()["preflight"]
    assert result["passed"] is False
    assert any("SYSTEM_NAME_PROVENANCE_LOCK" in e for e in result["errors"])


def test_v22_explicit_tp_role_prevents_wrong_side_system_selection():
    data = _source_csv(tp_role="Sender")
    out = analyze_tp_workbook(
        filename="v22-role.csv",
        data=data,
        contracts=load_catalog(),
        scope="BOTH",
        use_llm=False,
    )
    assert len(out["tpActions"]) == 1
    row = out["tpActions"][0]
    assert row["tpRoleKey"] == "source"
    assert row["roleAmbiguous"] is False
    assert row["systemName"] == "AIC - DCE"
    assert row["systemSourceColumn"] == "Source System"


def test_v22_uhal_target_reference_has_no_stale_partner_system_default(monkeypatch):
    monkeypatch.delenv("HIP_UHAL_TARGET_SYSTEM_NAME", raising=False)
    ref = uhal_create_payload("target")
    assert ref["systemName"] == ""
    assert ref["systemName"] != "dce-test-partner"
    explicit = uhal_create_payload("target", system_name="CLIENT-SYSTEM-FROM-EXCEL")
    assert explicit["systemName"] == "CLIENT-SYSTEM-FROM-EXCEL"


def test_v22_live_http_boundary_sends_excel_system_name_not_partner_name(monkeypatch):
    captured = {}

    class Resp:
        status_code = 201
        text = '{"created":true}'
        def json(self):
            return {"created": True, "message": "accepted"}

    def fake_request(method, url, **kwargs):
        captured["method"] = method
        captured["url"] = url
        captured["json"] = deepcopy(kwargs.get("json"))
        return Resp()

    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v22-test-token")
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_REQUESTED_BY", "v22-test@dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setenv("HIP_TP_VALIDATE_BEFORE_CREATE", "false")
    monkeypatch.setenv("HIP_TP_POST_CREATE_CHECK_ENABLED", "false")
    monkeypatch.setenv("HIP_TP_RESPONSE_AGENT_ENABLED", "false")
    monkeypatch.setattr("app.executor.requests.request", fake_request)

    client = TestClient(app)
    analyzed, row = _analyze_source(client)
    assert row["proposedRequest"]["systemName"] == "AIC - DCE"

    staged = client.post(
        "/api/stage",
        json={
            "analysisId": analyzed["analysisId"],
            "rowId": row["actionId"],
            "payload": row["proposedRequest"],
            "reviewer": "V22 Reviewer",
        },
    )
    assert staged.status_code == 200, staged.text
    stage = staged.json()["stage"]
    pf = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf.status_code == 200, pf.text
    assert pf.json()["preflight"]["executionReady"] is True

    live = client.post(
        f"/api/stages/{stage['stageId']}/execute",
        json={"confirmation": "LIVE", "actor": "V22 Reviewer"},
    )
    assert live.status_code == 200, live.text
    run = live.json()["run"]
    assert captured["method"] == "POST"
    assert captured["json"]["systemName"] == "AIC - DCE"
    assert captured["json"]["systemName"] != "dce-test-partner"
    assert run["responseClassification"]["classification"] == "SUCCESS"
    # With independent post-create checking deliberately disabled in this unit
    # test, the final deterministic outcome remains PENDING/unverified.
    assert run["outcomeClassification"] == "PENDING"

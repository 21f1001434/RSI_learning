from __future__ import annotations

import csv
import io
import uuid
from copy import deepcopy

import pytest
from fastapi.testclient import TestClient

from app.catalog import normalize_contract, schema_locked
from app.main import app
from app.runtime_config import production_guard
from app.state import STATE


def _csv(interface: str = "SFTP", *, suffix: str | None = None) -> bytes:
    suffix = suffix or uuid.uuid4().hex[:10]
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Source System", "Transport Profile Name", "Interface Type", "Existing Account Name", "Subscription Folder"])
    w.writerow(["AIC - DCE", f"TP_{suffix}_SRC_IB", interface, f"acct-{suffix}", f"/TP_{suffix}_SRC_IB"])
    return out.getvalue().encode("utf-8")


def _analyze(client: TestClient, interface: str = "SFTP") -> dict:
    res = client.post(
        "/api/tp/analyze",
        files={"workbook": ("tp.csv", _csv(interface), "text/csv")},
        data={"tp_scope": "SOURCE", "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert res.status_code == 200, res.text
    body = res.json()
    row = body["tpActions"][0]
    assert row["status"] == "GOOD_TO_TRIGGER", row
    return body


def _stage(client: TestClient, analysis: dict, payload: dict) -> dict:
    row = analysis["tpActions"][0]
    res = client.post(
        "/api/stage",
        json={
            "analysisId": analysis["analysisId"],
            "rowId": row["actionId"],
            "payload": payload,
            "reviewer": "V11 Test Human",
        },
    )
    return {"response": res, "row": row}


def _live_env(monkeypatch) -> None:
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v11-test-token")
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_REQUESTED_BY", "v11-test@dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")


def test_v11_dynamic_contract_metadata_survives_normalize():
    client = TestClient(app)
    analysis = _analyze(client, "SFTP")
    row = analysis["tpActions"][0]
    c = normalize_contract(row["contractSnapshot"])
    assert c["interface_family"] == "FILE"
    assert c["tp_role"] == "source"
    assert "transportProfileDetails.0.interfaceDetails.0.interfaceType" in c["locked_value_paths"]
    assert c["supported_for_live"] is True


def test_v11_human_can_change_customer_value_but_not_attribute_set(monkeypatch):
    _live_env(monkeypatch)
    client = TestClient(app)
    analysis = _analyze(client, "SFTP")
    row = analysis["tpActions"][0]
    payload = deepcopy(row["proposedRequest"])
    payload["transportProfileDetails"][0]["transportProfileName"] = "TP_VALUE_EDIT_ALLOWED_SRC_IB"
    staged = _stage(client, analysis, payload)["response"]
    assert staged.status_code == 200, staged.text
    st = staged.json()["stage"]
    assert st["attributeMutationBlocked"] is True
    assert st["schemaSha256"]
    assert st["lockedValuesSha256"]

    bad = deepcopy(row["proposedRequest"])
    bad["agentInventedAttribute"] = "BLOCK-ME"
    rejected = _stage(client, analysis, bad)["response"]
    assert rejected.status_code == 400
    assert "attributes" in rejected.text.lower() or "schema" in rejected.text.lower()


def test_v11_interface_selector_is_locked_after_interface_contract_selection(monkeypatch):
    _live_env(monkeypatch)
    client = TestClient(app)
    analysis = _analyze(client, "SFTP")
    row = analysis["tpActions"][0]
    payload = deepcopy(row["proposedRequest"])
    payload["transportProfileDetails"][0]["interfaceDetails"][0]["interfaceType"] = "FTP"
    rejected = _stage(client, analysis, payload)["response"]
    assert rejected.status_code == 400
    assert "CONTRACT_OWNED_VALUE_LOCK" in rejected.text


def test_v11_preflight_separates_payload_pass_from_live_execution_readiness(monkeypatch):
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "false")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v11-test-token")
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    client = TestClient(app)
    analysis = _analyze(client, "SFTP")
    row = analysis["tpActions"][0]
    staged = _stage(client, analysis, deepcopy(row["proposedRequest"]))["response"]
    assert staged.status_code == 200, staged.text
    stage_id = staged.json()["stage"]["stageId"]
    pf = client.post(f"/api/stages/{stage_id}/preflight").json()["preflight"]
    assert pf["passed"] is True
    assert pf["executionReady"] is False
    assert pf["attributeMutationBlocked"] is True
    assert any("HIP_LIVE_API_EXECUTION" in x for x in pf["executionGateErrors"])


def test_v11_real_live_http_boundary_is_rebuilt_from_canonical_schema(monkeypatch):
    _live_env(monkeypatch)
    captured = {}

    class Resp:
        status_code = 201
        text = '{"created":true}'
        def json(self): return {"created": True, "id": "v11-live-id"}

    def fake_request(method, url, **kwargs):
        captured["method"] = method
        captured["url"] = url
        captured["json"] = deepcopy(kwargs.get("json"))
        captured["headers"] = deepcopy(kwargs.get("headers"))
        return Resp()

    monkeypatch.setattr("app.executor.requests.request", fake_request)
    client = TestClient(app)
    analysis = _analyze(client, "SFTP")
    row = analysis["tpActions"][0]
    payload = deepcopy(row["proposedRequest"])
    payload["systemName"] = "AIC - DCE VALUE EDIT"
    edited = client.post(
        f"/api/tp/analyses/{analysis['analysisId']}/actions/{row['actionId']}/values",
        json={"payload": payload, "actor": "V11 Test Human"},
    )
    assert edited.status_code == 200, edited.text
    edited_row = edited.json()["action"]
    staged = _stage(client, analysis, edited_row["proposedRequest"])["response"]
    assert staged.status_code == 200, staged.text
    stage = staged.json()["stage"]
    pf_res = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf_res.status_code == 200, pf_res.text
    pf = pf_res.json()["preflight"]
    assert pf["passed"] is True
    assert pf["executionReady"] is True, pf

    live = client.post(
        f"/api/stages/{stage['stageId']}/execute",
        json={"confirmation": "LIVE", "actor": "V11 Test Human"},
    )
    assert live.status_code == 200, live.text
    run = live.json()["run"]
    assert run["success"] is True
    assert run["attributeMutationBlocked"] is True
    assert run["schemaSha256"] == pf["schemaSha256"]
    assert captured["method"] == "POST"
    assert captured["url"].endswith("/api/transport-profiles/orchestration/create")
    assert schema_locked(row["contractSnapshot"]["canonical_request"], captured["json"])
    assert captured["json"]["systemName"] == "AIC - DCE VALUE EDIT"
    assert set(captured["json"]) == set(row["contractSnapshot"]["canonical_request"])


def test_v11_live_blocks_if_resolved_dell_execution_boundary_changes_after_preflight(monkeypatch):
    _live_env(monkeypatch)
    client = TestClient(app)
    analysis = _analyze(client, "SFTP")
    row = analysis["tpActions"][0]
    staged = _stage(client, analysis, deepcopy(row["proposedRequest"]))["response"].json()["stage"]
    pf = client.post(f"/api/stages/{staged['stageId']}/preflight").json()["preflight"]
    assert pf["executionReady"] is True
    monkeypatch.setenv("HIP_CONFIG_SERVICE_BASE_URL", "https://apigtwtst.us.dell.com/hip-config-service-changed")
    res = client.post(f"/api/stages/{staged['stageId']}/execute", json={"confirmation": "LIVE", "actor": "V11 Test Human"})
    assert res.status_code == 400
    assert "execution boundary changed" in res.text.lower()


def test_v11_v130_prod_guard_requires_confirmation_and_change_ticket(monkeypatch):
    monkeypatch.setenv("HIP_ENVIRONMENT", "PROD")
    monkeypatch.delenv("PRODUCTION_EXECUTION_CONFIRMATION", raising=False)
    monkeypatch.delenv("CHANGE_TICKET", raising=False)
    g = production_guard()
    assert g["passed"] is False
    assert len(g["errors"]) == 2
    monkeypatch.setenv("PRODUCTION_EXECUTION_CONFIRMATION", "YES")
    monkeypatch.setenv("CHANGE_TICKET", "CHG0123456")
    g2 = production_guard()
    assert g2["passed"] is True


def test_v11_sftp_server_contract_does_not_share_sftp_haft_attribute_set(monkeypatch):
    _live_env(monkeypatch)
    client = TestClient(app)
    sftp = _analyze(client, "SFTP")["tpActions"][0]
    # Build a minimally complete Source SFTP Server row using the V130 conditions.
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["Source System", "Transport Profile Name", "Interface Type", "Server Type", "SFTP Server", "Directory", "File Filtering Pattern", "Post File Transfer Action", "Polling Interval", "Are Input Files Compressed?", "Port", "Login Authentication Type", "Username", "Password"])
    w.writerow(["AIC - DCE", f"TP_{uuid.uuid4().hex[:8]}_SRC_IB", "SFTP Server", "Linux", "sftp.example", "/in", ".*", "Delete", "Every 5 Minutes", "False", "22", "Password", "svc", "secret"])
    res = client.post("/api/tp/analyze", files={"workbook": ("server.csv", out.getvalue().encode(), "text/csv")}, data={"tp_scope": "SOURCE", "use_llm": "false"})
    assert res.status_code == 200, res.text
    server = res.json()["tpActions"][0]
    assert server["status"] == "GOOD_TO_TRIGGER", server
    sftp_params = sftp["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
    server_params = server["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
    assert "Existing Account Name" in sftp_params
    assert "Server Name" not in sftp_params
    assert "Server Name" in server_params
    assert "Existing Account Name" not in server_params
    assert server["interfaceType"] == "SFTP Server"


def test_v11_runtime_live_readiness_exposes_real_dell_values_only_boundary(monkeypatch):
    _live_env(monkeypatch)
    client = TestClient(app)
    res = client.get('/api/runtime/live-readiness')
    assert res.status_code == 200, res.text
    body = res.json()
    assert body['actualNetworkExecution'] is True
    assert body['mutationPolicy'] == 'VALUES_ONLY'
    assert body['attributePolicy'] == 'IMMUTABLE_SELECTED_INTERFACE_CONTRACT'
    assert body['gates']['liveEnabled'] is True
    assert body['gates']['allTpHostsAllowed'] is True


def test_v11_stage_live_plan_is_non_mutating_and_matches_selected_contract(monkeypatch):
    _live_env(monkeypatch)
    client = TestClient(app)
    analysis = _analyze(client, 'SFTP')
    row = analysis['tpActions'][0]
    staged_res = _stage(client, analysis, deepcopy(row['proposedRequest']))['response']
    assert staged_res.status_code == 200, staged_res.text
    stage = staged_res.json()['stage']
    pf_res = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf_res.status_code == 200, pf_res.text
    plan_res = client.get(f"/api/stages/{stage['stageId']}/live-plan")
    assert plan_res.status_code == 200, plan_res.text
    plan = plan_res.json()
    assert plan['valuesOnly'] is True
    assert plan['attributeMutationBlocked'] is True
    assert plan['preflightPassed'] is True
    assert plan['executionReady'] is True
    assert plan['schemaSha256'] == plan['canonicalSchemaSha256']
    assert plan['method'] == 'POST'
    assert plan['url'].endswith('/api/transport-profiles/orchestration/create')
    assert 'transportProfileDetails.0.interfaceDetails.0.interfaceType' in plan['lockedValuePaths']


@pytest.mark.parametrize('mutation', ['remove_key', 'change_nesting', 'change_cardinality'])
def test_v11_stage_rejects_all_tp_attribute_shape_mutations(monkeypatch, mutation):
    _live_env(monkeypatch)
    client = TestClient(app)
    analysis = _analyze(client, 'SFTP')
    row = analysis['tpActions'][0]
    bad = deepcopy(row['proposedRequest'])
    if mutation == 'remove_key':
        bad.pop('systemType', None)
    elif mutation == 'change_nesting':
        bad['transportProfileDetails'][0]['interfaceDetails'][0]['parameters'] = 'not-an-object'
    else:
        bad['transportProfileDetails'].append(deepcopy(bad['transportProfileDetails'][0]))
    res = _stage(client, analysis, bad)['response']
    assert res.status_code == 400
    assert 'attribute' in res.text.lower() or 'schema' in res.text.lower() or 'cardinality' in res.text.lower()


def test_v11_live_rejects_server_side_attribute_tamper_after_preflight(monkeypatch):
    _live_env(monkeypatch)
    client = TestClient(app)
    analysis = _analyze(client, 'SFTP')
    row = analysis['tpActions'][0]
    staged = _stage(client, analysis, deepcopy(row['proposedRequest']))['response'].json()['stage']
    pf = client.post(f"/api/stages/{staged['stageId']}/preflight").json()['preflight']
    assert pf['executionReady'] is True
    tampered = STATE.get_stage(staged['stageId'])
    tampered['payload']['agentInventedAfterPreflight'] = 'must-never-leave-server'
    STATE.save_stage(tampered)
    res = client.post(f"/api/stages/{staged['stageId']}/execute", json={'confirmation':'LIVE','actor':'V11 Tamper Test'})
    assert res.status_code == 400
    assert 'changed after preflight' in res.text.lower() or 'canonical_tp_attribute_lock' in res.text.lower()

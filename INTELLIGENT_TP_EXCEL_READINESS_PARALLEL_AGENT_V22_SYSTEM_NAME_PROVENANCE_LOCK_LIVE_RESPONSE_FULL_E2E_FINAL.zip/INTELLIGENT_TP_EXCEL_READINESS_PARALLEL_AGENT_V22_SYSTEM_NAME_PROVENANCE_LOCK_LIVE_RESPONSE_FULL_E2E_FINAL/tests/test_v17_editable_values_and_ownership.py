from copy import deepcopy
from fastapi.testclient import TestClient

from app.main import app


def csv_bytes(headers, row):
    import csv, io
    out = io.StringIO(newline="")
    w = csv.writer(out)
    w.writerow(headers)
    w.writerow(row)
    return out.getvalue().encode("utf-8")


def analyze(client, headers, row, scope="SOURCE"):
    r = client.post(
        "/api/tp/analyze",
        files={"workbook": ("tp.csv", csv_bytes(headers, row), "text/csv")},
        data={"tp_scope": scope, "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert r.status_code == 200, r.text
    return r.json()


def test_v17_sender_can_be_client_and_receiver_can_be_dell():
    client = TestClient(app)
    source = analyze(
        client,
        ["Source System", "Transport Profile Name", "Interface Type", "Source System Type", "Existing Account Name", "Subscription Folder"],
        ["client-sftp-system", "TP_CLIENT_SRC_IB", "SFTP", "Client", "client-acct", "/client/out"],
        "SOURCE",
    )["allApiResults"][0]
    assert source["tpRoleKey"] == "source"
    assert source["tpRole"] == "SOURCE / SENDER"
    assert source["systemType"] == "Partner"
    assert source["ownershipResolved"] is True
    assert source["status"] == "GOOD_TO_TRIGGER"

    target = analyze(
        client,
        ["Target System", "Transport Profile Name", "Interface Type", "Target System Type", "Existing Account Name", "Subscription Folder"],
        ["AIC - DCE", "TP_DELL_TGT_IB", "SFTP", "Dell Application", "dell-acct", "/dell/in"],
        "TARGET",
    )["allApiResults"][0]
    assert target["tpRoleKey"] == "target"
    assert target["tpRole"] == "TARGET / RECEIVER"
    assert target["systemType"] == "Dell Application"
    assert target["ownershipResolved"] is True
    assert target["status"] == "GOOD_TO_TRIGGER"


def test_v17_human_can_confirm_ambiguous_sender_ownership_before_stage():
    client = TestClient(app)
    result = analyze(
        client,
        ["Source System", "Transport Profile Name", "Interface Type", "Existing Account Name", "Subscription Folder"],
        ["SYS-01", "TP_AMBIG_SRC_IB", "SFTP", "acct-1", "/folder"],
        "SOURCE",
    )
    row = result["allApiResults"][0]
    assert row["ownershipResolved"] is False
    assert row["status"] == "NEEDS_INPUT"
    rid = row["actionId"]
    r = client.post(
        f"/api/tp/analyses/{result['analysisId']}/actions/{rid}/ownership",
        json={"systemType": "Partner", "actor": "Reviewer"},
    )
    assert r.status_code == 200, r.text
    updated = r.json()["action"]
    assert updated["ownershipResolved"] is True
    assert updated["systemType"] == "Partner"
    assert updated["ownershipMethod"] == "HUMAN_CONFIRMED_OWNERSHIP_REBUILD"
    assert updated["status"] == "GOOD_TO_TRIGGER"


def test_v17_user_can_edit_values_but_not_attributes_before_stage():
    client = TestClient(app)
    result = analyze(
        client,
        ["Source System", "Transport Profile Name", "Interface Type", "Source System Type", "Existing Account Name", "Subscription Folder"],
        ["client-system", "TP_EDIT_SRC_IB", "SFTP", "Client", "acct-edit", "/out"],
        "SOURCE",
    )
    row = result["allApiResults"][0]
    assert row["status"] == "GOOD_TO_TRIGGER"
    payload = deepcopy(row["proposedRequest"])
    payload["systemName"] = "client-system-updated"
    edited = client.post(
        f"/api/tp/analyses/{result['analysisId']}/actions/{row['actionId']}/values",
        json={"payload": payload, "actor": "Human User"},
    )
    assert edited.status_code == 200, edited.text
    edited_row = edited.json()["action"]
    staged = client.post(
        "/api/stage",
        json={"analysisId": result["analysisId"], "rowId": row["actionId"], "payload": edited_row["proposedRequest"], "reviewer": "Human User"},
    )
    assert staged.status_code == 200, staged.text
    assert staged.json()["stage"]["payload"]["systemName"] == "client-system-updated"

    bad = deepcopy(edited_row["proposedRequest"])
    bad["inventedAttribute"] = "not allowed"
    rejected = client.post(
        "/api/stage",
        json={"analysisId": result["analysisId"], "rowId": row["actionId"], "payload": bad, "reviewer": "Human User"},
    )
    assert rejected.status_code == 400
    assert "attribute" in rejected.text.lower() or "schema" in rejected.text.lower()

from __future__ import annotations

import csv
import io
import json
from copy import deepcopy
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.catalog import load_catalog
from app.tp_service import analyze_tp_workbook
from app.migration_service import (
    MIGRATION_METHOD,
    MIGRATION_PATH,
    MIGRATION_TOP_LEVEL_KEYS,
    build_migration_payload,
    canonical_migration_request,
    validate_migration_payload,
)

ROOT = Path(__file__).resolve().parents[1]


def _env(monkeypatch, *, migration=True, post_create=False, post_migration=False):
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v14-test")
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_REQUESTED_BY", "v14-test@dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setenv("HIP_TP_VALIDATE_BEFORE_CREATE", "false")
    monkeypatch.setenv("HIP_TP_POST_CREATE_CHECK_ENABLED", "true" if post_create else "false")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_INTERVAL_SECONDS", "0.01")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_TIMEOUT_SECONDS", "0.2")
    monkeypatch.setenv("HIP_TP_MIGRATION_ENABLED", "true" if migration else "false")
    monkeypatch.setenv("HIP_MIGRATION_SOURCE_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_MIGRATION_TARGET_ENVIRONMENT", "TEST")
    monkeypatch.setenv("HIP_TP_MIGRATION_POST_CHECK_ENABLED", "true" if post_migration else "false")
    monkeypatch.setenv("HIP_TP_MIGRATION_POLL_INTERVAL_SECONDS", "0.01")
    monkeypatch.setenv("HIP_TP_MIGRATION_POLL_TIMEOUT_SECONDS", "0.2")


def _analysis(client: TestClient, name: str = "TP_V14_SRC_IB"):
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["Source System", "Transport Profile Name", "Interface Type", "Existing Account Name", "Subscription Folder"])
    w.writerow(["AIC - DCE", name, "SFTP", "acct-v14", f"/{name}"])
    res = client.post(
        "/api/tp/analyze",
        files={"workbook": ("tp.csv", out.getvalue().encode(), "text/csv")},
        data={"tp_scope": "SOURCE", "use_llm": "false"},
    )
    assert res.status_code == 200, res.text
    body = res.json(); row = body["tpActions"][0]
    assert row["status"] == "GOOD_TO_TRIGGER", row
    return body, row


def _stage_and_preflight(client: TestClient, analysis: dict, row: dict):
    st = client.post("/api/stage", json={
        "analysisId": analysis["analysisId"], "rowId": row["actionId"],
        "payload": deepcopy(row["proposedRequest"]), "reviewer": "V14 Test",
    })
    assert st.status_code == 200, st.text
    stage = st.json()["stage"]
    pf = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf.status_code == 200, pf.text
    assert pf.json()["preflight"]["passed"] is True, pf.json()
    return stage


def test_v14_migration_contract_matches_dev_published_v130_evidence():
    evidence = json.loads((ROOT / "config" / "tp_migration_contract_v130.json").read_text())
    assert MIGRATION_METHOD == evidence["method"] == "POST"
    assert MIGRATION_PATH == evidence["path"] == "/api/migration/orchestration/transport-profile"
    assert MIGRATION_TOP_LEVEL_KEYS == evidence["attributes"]


def test_v14_migration_payload_reuses_exact_selected_tp_interface_parameters(monkeypatch):
    _env(monkeypatch, post_migration=False)
    client = TestClient(app)
    analysis, row = _analysis(client)
    create_payload = row["proposedRequest"]
    migration = build_migration_payload(create_payload, source_environment="DEV", target_environment="TEST")
    assert list(migration.keys()) == MIGRATION_TOP_LEVEL_KEYS
    detail = create_payload["transportProfileDetails"][0]
    iface = detail["interfaceDetails"][0]
    assert migration["transportProfileName"] == detail["transportProfileName"]
    assert migration["transportProfileInterfaceType"] == iface["interfaceType"]
    assert migration["transportProfileInterfaceParameters"] == iface["parameters"]
    assert migration["transportProfileInterfaceParameters"] is not iface["parameters"]
    assert validate_migration_payload(migration, create_payload)["valid"] is True
    assert set(canonical_migration_request(create_payload)) == set(MIGRATION_TOP_LEVEL_KEYS)


def test_v14_migration_preflight_blocks_blank_target_environment(monkeypatch):
    _env(monkeypatch, post_migration=False)
    monkeypatch.setenv("HIP_MIGRATION_TARGET_ENVIRONMENT", "")
    client = TestClient(app)
    analysis, row = _analysis(client, "TP_V14_BLANK_TARGET_SRC_IB")
    stage = _stage_and_preflight(client, analysis, row)
    res = client.post(f"/api/stages/{stage['stageId']}/migration-preflight", json={"sourceEnvironment":"DEV", "targetEnvironment":""})
    assert res.status_code == 200, res.text
    pf = res.json()["migrationPreflight"]
    assert pf["executionReady"] is False
    assert any("targetEnvironment" in e for e in pf["errors"])


def test_v14_post_create_checking_api_is_required_for_verified_created(monkeypatch):
    _env(monkeypatch, post_create=True, post_migration=False)
    client = TestClient(app)
    analysis, row = _analysis(client, "TP_V14_VERIFY_SRC_IB")
    stage = _stage_and_preflight(client, analysis, row)
    calls = []

    class Resp:
        def __init__(self, status, body): self.status_code=status; self._body=body; self.text=json.dumps(body)
        def json(self): return self._body

    audit_calls = {"n": 0}
    def fake_request(method, url, **kwargs):
        calls.append((method, url, deepcopy(kwargs.get("json")), deepcopy(kwargs.get("params"))))
        if url.endswith("/api/transport-profiles/audits"):
            audit_calls["n"] += 1
            if audit_calls["n"] == 1:
                return Resp(200, {"data":[{"auditId":"old","transportProfileName":"TP_V14_VERIFY_SRC_IB","operation":"Create","status":"SUCCESS"}]})
            return Resp(200, {"data":[{"auditId":"new","transportProfileName":"TP_V14_VERIFY_SRC_IB","operation":"Create","status":"SUCCESS"}]})
        if url.endswith("/api/transport-profiles/orchestration/create"):
            return Resp(201, {"message":"accepted"})
        return Resp(200, {"valid":True})

    monkeypatch.setattr("app.executor.requests.request", fake_request)
    live = client.post(f"/api/stages/{stage['stageId']}/execute", json={"confirmation":"LIVE", "actor":"V14 Test"})
    assert live.status_code == 200, live.text
    run = live.json()["run"]
    assert run["createAccepted"] is True
    assert run["verifiedCreated"] is True
    assert run["success"] is True
    assert run["resultState"] == "VERIFIED_CREATED"
    assert any(url.endswith("/api/transport-profiles/audits") for _, url, _, _ in calls)


def test_v14_migration_executes_exact_v130_api_and_verifies_target_audit(monkeypatch):
    _env(monkeypatch, post_create=False, post_migration=True)
    client = TestClient(app)
    analysis, row = _analysis(client, "TP_V14_MIGRATE_SRC_IB")
    stage = _stage_and_preflight(client, analysis, row)
    calls = []

    class Resp:
        def __init__(self, status, body): self.status_code=status; self._body=body; self.text=json.dumps(body)
        def json(self): return self._body

    audit_calls = {"n": 0}
    def fake_migration_request(method, url, **kwargs):
        calls.append((method, url, deepcopy(kwargs.get("json")), deepcopy(kwargs.get("params"))))
        if url.endswith("/api/transport-profiles/audits"):
            audit_calls["n"] += 1
            if audit_calls["n"] == 1:
                return Resp(200, {"data":[{"auditId":"old-target","transportProfileName":"TP_V14_MIGRATE_SRC_IB","operation":"Migration","status":"SUCCESS"}]})
            return Resp(200, {"data":[{"auditId":"new-target","transportProfileName":"TP_V14_MIGRATE_SRC_IB","operation":"Migration","status":"SUCCESS"}]})
        if url.endswith(MIGRATION_PATH):
            return Resp(202, {"message":"migration accepted"})
        raise AssertionError(f"unexpected URL {url}")

    monkeypatch.setattr("app.migration_service.requests.request", fake_migration_request)
    pf = client.post(f"/api/stages/{stage['stageId']}/migration-preflight", json={"sourceEnvironment":"DEV", "targetEnvironment":"TEST"})
    assert pf.status_code == 200, pf.text
    assert pf.json()["migrationPreflight"]["executionReady"] is True, pf.json()
    res = client.post(f"/api/stages/{stage['stageId']}/migrate", json={"sourceEnvironment":"DEV", "targetEnvironment":"TEST", "confirmation":"MIGRATE", "actor":"V14 Test"})
    assert res.status_code == 200, res.text
    run = res.json()["run"]
    assert run["migrationAccepted"] is True
    assert run["verifiedMigrated"] is True
    assert run["success"] is True
    assert run["resultState"] == "VERIFIED_MIGRATED"
    migration_calls = [c for c in calls if c[1].endswith(MIGRATION_PATH)]
    assert len(migration_calls) == 1
    method, _, payload, _ = migration_calls[0]
    assert method == "POST"
    assert list(payload.keys()) == MIGRATION_TOP_LEVEL_KEYS
    assert payload["sourceEnvironment"] == "DEV"
    assert payload["targetEnvironment"] == "TEST"
    assert payload["transportProfileInterfaceType"] == row["interfaceType"]
    assert payload["transportProfileInterfaceParameters"] == row["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]


def test_v14_runtime_migration_readiness_endpoint_exposes_exact_api(monkeypatch):
    _env(monkeypatch, migration=True, post_migration=True)
    client = TestClient(app)
    res = client.get("/api/runtime/migration-readiness")
    assert res.status_code == 200, res.text
    m = res.json()["migration"]
    assert m["enabled"] is True
    assert m["method"] == "POST"
    assert m["path"] == MIGRATION_PATH
    assert m["attributes"] == MIGRATION_TOP_LEVEL_KEYS
    assert m["targetEnvironment"] == "TEST"

def test_v14_batch_migration_runs_multiple_staged_tps_in_parallel(monkeypatch):
    _env(monkeypatch, post_create=False, post_migration=False)
    client = TestClient(app)
    stages=[]
    for name in ("TP_V14_BATCH_A_SRC_IB", "TP_V14_BATCH_B_SRC_IB"):
        analysis,row=_analysis(client,name)
        stages.append(_stage_and_preflight(client,analysis,row))

    class Resp:
        status_code=202
        text='{"message":"accepted"}'
        def json(self): return {"message":"accepted"}
    calls=[]
    def fake_request(method,url,**kwargs):
        calls.append((method,url,deepcopy(kwargs.get("json"))))
        assert url.endswith(MIGRATION_PATH)
        return Resp()
    monkeypatch.setattr("app.migration_service.requests.request", fake_request)

    pf=client.post("/api/batch/migration-preflight",json={"stageIds":[x["stageId"] for x in stages],"sourceEnvironment":"DEV","targetEnvironment":"TEST","actor":"V14 Test"})
    assert pf.status_code==200,pf.text
    assert pf.json()["executionReady"]==2,pf.json()
    res=client.post("/api/batch/migrate",json={"stageIds":[x["stageId"] for x in stages],"sourceEnvironment":"DEV","targetEnvironment":"TEST","confirmation":"MIGRATE ALL","actor":"V14 Test","maxWorkers":2})
    assert res.status_code==200,res.text
    body=res.json()
    assert body["summary"]["executed"]==2
    assert body["summary"]["successful"]==2
    assert len(calls)==2
    assert all(c[0]=="POST" and c[1].endswith(MIGRATION_PATH) for c in calls)


# V14 migration must preserve the selected immutable parameter shape for every
# interface family supported by the TP application, on both Source and Target.
_V14_SOURCE_INTERFACES = {
    "SFTP": {"Existing Account Name": "acct-source", "Subscription Folder": "/sftp/source"},
    "SFTP Server": {
        "Server Type": "Linux", "SFTP Server": "sftp.source.example", "Directory": "/hip/in",
        "File Filtering Pattern": ".*", "Post File Transfer Action": "Delete",
        "Polling Interval": "Every 5 Minutes", "Are Input Files Compressed?": "False",
        "Port": "22", "Login Authentication Type": "Password", "Username": "svc", "Password": "secret",
    },
    "FTP": {"Existing Account Name": "acct-source", "Subscription Folder": "/ftp/source"},
    "HTTPS": {},
    "HTTPS-AS2": {
        "Partner Identifier": "PARTNER-AS2", "Dell Identifier": "DELL-AS2",
        "Partner Verification Certificate": "partner.crt",
        "Are SSL and Partner Verification Certificates identical?": "No",
        "AS2 URL": "https://partner.example/as2", "Are Input Files Compressed?": "False",
        "Is EBCDIC enabled?": "False",
    },
    "NAS": {
        "Protocol": "NFS", "Server Name": "nas-source", "Server Path": "/nas/in", "AD Group": "HIP-NAS",
        "File Filtering Pattern": ".*", "Polling Interval": "Every 5 Minutes",
        "Post File Transfer Action NAS": "Delete",
    },
    "Rabbit MQ": {"Interface Environment": "DEV", "Exchange Name": "hip.exchange.source"},
}

_V14_TARGET_INTERFACES = {
    "SFTP": {"Existing Account Name": "acct-target", "Subscription Folder": "/sftp/target"},
    "SFTP Server": {
        "Server Type": "Linux", "SFTP Server": "sftp.target.example", "Directory": "/hip/out",
        "Are Input Files Compressed?": "False", "Port": "22", "Login Authentication Type": "Password",
        "Username": "svc", "Password": "secret", "Is EBCDIC enabled?": "False",
    },
    "FTP": {"Existing Account Name": "acct-target", "Subscription Folder": "/ftp/target"},
    "HTTPS": {
        "Partner URL": "https://partner.example/api", "Receiver Grant Type": "client_credentials",
        "Receiver Token Endpoint": "https://partner.example/token", "Receiver Client Id": "client-id",
        "Receiver Client Secret": "client-secret",
    },
    "HTTPS-AS2": {
        "Partner URL": "https://partner.example/as2", "Partner Identifier": "PARTNER-AS2", "Dell Identifier": "DELL-AS2",
        "Signing Algorithm": "SHA256", "Encryption Algorithm": "AES256", "Encryption Certificate": "enc.crt",
        "SSL Certificate": "ssl.crt", "Enable AS2 Message Compression": "False",
        "Asynchronous MDN Required": "False", "Are Input Files Compressed?": "False", "Is EBCDIC enabled?": "False",
    },
    "NAS": {"Protocol": "SMB", "Server Name": "nas-target", "Server Path": "/nas/out", "AD Group": "HIP-NAS"},
    "Rabbit MQ": {"Interface Environment": "DEV", "Exchange Name": "hip.exchange.target"},
}


def _v14_csv(role: str, interface: str, params: dict[str, str]) -> bytes:
    system_header = "Source System" if role == "source" else "Target System"
    system_value = "AIC - DCE" if role == "source" else "partner-system"
    tp_name = f"V14_{interface.upper().replace(' ', '_').replace('-', '_')}_{'SRC_IB' if role == 'source' else 'TGT_OB'}"
    out = io.StringIO(); w = csv.writer(out)
    w.writerow([system_header, "Transport Profile Name", "Interface Type", *params.keys()])
    w.writerow([system_value, tp_name, interface, *params.values()])
    return out.getvalue().encode("utf-8")


@pytest.mark.parametrize("role,cases", [("source", _V14_SOURCE_INTERFACES), ("target", _V14_TARGET_INTERFACES)])
def test_v14_every_supported_interface_builds_exact_schema_locked_migration_payload(monkeypatch, role: str, cases: dict[str, dict[str, str]]):
    _env(monkeypatch, post_create=False, post_migration=False)
    for excel_interface, params in cases.items():
        analysis = analyze_tp_workbook(
            filename="migration-all.csv",
            data=_v14_csv(role, excel_interface, params),
            contracts=load_catalog(),
            scope=role.upper(),
            use_llm=False,
        )
        row = analysis["tpActions"][0]
        assert row["status"] == "GOOD_TO_TRIGGER", (role, excel_interface, row.get("missingRequiredPaths"), row.get("warnings"))
        create_payload = row["proposedRequest"]
        migration = build_migration_payload(create_payload, source_environment="DEV", target_environment="TEST")
        detail = create_payload["transportProfileDetails"][0]
        iface = detail["interfaceDetails"][0]
        assert list(migration.keys()) == MIGRATION_TOP_LEVEL_KEYS
        assert migration["transportProfileName"] == detail["transportProfileName"]
        assert migration["transportProfileInterfaceType"] == iface["interfaceType"]
        assert migration["transportProfileInterfaceParameters"] == iface["parameters"]
        check = validate_migration_payload(migration, create_payload)
        assert check["valid"] is True, (role, excel_interface, check)
        assert check["schemaLocked"] is True


def _v14_multi_source_csv() -> bytes:
    parameter_headers: list[str] = []
    for params in _V14_SOURCE_INTERFACES.values():
        for key in params:
            if key not in parameter_headers:
                parameter_headers.append(key)
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["Source System", "Transport Profile Name", "Interface Type", *parameter_headers])
    for idx, (interface, params) in enumerate(_V14_SOURCE_INTERFACES.items(), start=1):
        tp = f"V14_MIGRATE_{interface.upper().replace(' ', '_').replace('-', '_')}_{idx}_SRC_IB"
        w.writerow(["AIC - DCE", tp, interface, *[params.get(h, "") for h in parameter_headers]])
    return out.getvalue().encode("utf-8")


def test_v14_all_seven_interfaces_can_batch_migrate_in_parallel(monkeypatch):
    _env(monkeypatch, post_create=False, post_migration=False)
    monkeypatch.setenv("HIP_BULK_MAX_WORKERS", "4")
    monkeypatch.setenv("HIP_PARALLEL_CONFIG_WORKERS", "4")
    monkeypatch.setenv("HIP_AUTOGEN_MAX_STABLE_AGENTS", "4")
    client = TestClient(app)
    analyzed = client.post(
        "/api/tp/analyze",
        files={"workbook": ("migration-seven.csv", _v14_multi_source_csv(), "text/csv")},
        data={"tp_scope": "SOURCE", "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert analyzed.status_code == 200, analyzed.text
    body = analyzed.json(); rows = body["allApiResults"]
    assert len(rows) == 7
    assert all(r["status"] == "GOOD_TO_TRIGGER" for r in rows), [(r.get("interfaceType"), r.get("status"), r.get("missingRequiredPaths")) for r in rows]

    staged = client.post("/api/tp/batch/stage", json={
        "analysisId": body["analysisId"], "actionIds": [r["actionId"] for r in rows], "reviewer": "V14 All Interface Migration",
    })
    assert staged.status_code == 200, staged.text
    stage_ids = [s["stageId"] for s in staged.json()["stages"]]
    tp_pf = client.post("/api/batch/preflight", json={"stageIds": stage_ids})
    assert tp_pf.status_code == 200, tp_pf.text
    assert tp_pf.json()["passed"] == 7, tp_pf.json()

    class Resp:
        status_code = 202
        text = '{"message":"migration accepted"}'
        def json(self): return {"message": "migration accepted"}

    calls: list[dict] = []
    def fake_request(method, url, **kwargs):
        assert method == "POST"
        assert url.endswith(MIGRATION_PATH)
        calls.append(deepcopy(kwargs.get("json") or {}))
        return Resp()
    monkeypatch.setattr("app.migration_service.requests.request", fake_request)

    mpf = client.post("/api/batch/migration-preflight", json={
        "stageIds": stage_ids, "sourceEnvironment": "DEV", "targetEnvironment": "TEST", "actor": "V14 All Interface Migration",
    })
    assert mpf.status_code == 200, mpf.text
    assert mpf.json()["executionReady"] == 7, mpf.json()
    migrated = client.post("/api/batch/migrate", json={
        "stageIds": stage_ids, "sourceEnvironment": "DEV", "targetEnvironment": "TEST",
        "confirmation": "MIGRATE ALL", "actor": "V14 All Interface Migration", "maxWorkers": 4,
    })
    assert migrated.status_code == 200, migrated.text
    result = migrated.json()
    assert result["summary"]["executed"] == 7
    assert result["summary"]["successful"] == 7
    assert len(calls) == 7
    assert {c["transportProfileInterfaceType"] for c in calls} == {"SFTP HAFT", "SFTP Server", "FTP", "HTTPS", "HTTPS-AS2", "NAS", "Rabbit MQ"}
    assert all(list(c.keys()) == MIGRATION_TOP_LEVEL_KEYS for c in calls)

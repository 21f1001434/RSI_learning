from __future__ import annotations

import csv
import io
import uuid

import pytest
from fastapi.testclient import TestClient

from app.catalog import load_catalog
from app.main import app
from app.sftp_server_contract import SFTP_SERVER_SSH_KEY, materialize_sftp_server_parameters
from app.tp_service import analyze_tp_workbook


def csv_bytes(role: str, interface: str, params: dict[str, str], *, suffix: str = "") -> bytes:
    system_header = "Source System" if role == "source" else "Target System"
    system_value = "AIC - DCE" if role == "source" else "partner-system"
    suffix = suffix or uuid.uuid4().hex[:8]
    tp_name = f"{interface.upper().replace(' ', '_').replace('-', '_')}_{suffix}_{'SRC_IB' if role == 'source' else 'TGT_OB'}"
    headers = [system_header, "Transport Profile Name", "Interface Type", *params.keys()]
    values = [system_value, tp_name, interface, *params.values()]
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(headers)
    writer.writerow(values)
    return out.getvalue().encode("utf-8")


SOURCE_CASES = {
    "SFTP": {"Existing Account Name": "acct-source", "Subscription Folder": "/sftp/source"},
    "SFTP Server": {
        "Server Type": "Linux", "SFTP Server": "sftp.source.example", "Directory": "/hip/in",
        "File Filtering Pattern": ".*", "Post File Transfer Action": "Delete",
        "Polling Interval": "Every 5 Minutes", "Are Input Files Compressed?": "False",
        "Port": "22", "Login Authentication Type": "Password", "Username": "svc", "Password": "secret",
    },
    "FTP": {"Existing Account Name": "acct-source", "Subscription Folder": "/ftp/source"},
    "HTTPS": {},
    "HTTPS-AS2": {
        "Partner Identifier": "PARTNER-AS2", "Dell Identifier": "DELL-AS2",
        "Partner Verification Certificate": "partner.crt",
        "Are SSL and Partner Verification Certificates identical?": "No",
        "AS2 URL": "https://partner.example/as2", "Are Input Files Compressed?": "False",
        "Is EBCDIC enabled?": "False",
    },
    "NAS": {
        "Protocol": "NFS", "Server Name": "nas-source", "Server Path": "/nas/in", "AD Group": "HIP-NAS",
        "File Filtering Pattern": ".*", "Polling Interval": "Every 5 Minutes",
        "Post File Transfer Action NAS": "Delete",
    },
    "Rabbit MQ": {"Interface Environment": "DEV", "Exchange Name": "hip.exchange.source"},
}

TARGET_CASES = {
    "SFTP": {"Existing Account Name": "acct-target", "Subscription Folder": "/sftp/target"},
    "SFTP Server": {
        "Server Type": "Linux", "SFTP Server": "sftp.target.example", "Directory": "/hip/out",
        "Are Input Files Compressed?": "False", "Port": "22", "Login Authentication Type": "Password",
        "Username": "svc", "Password": "secret", "Is EBCDIC enabled?": "False",
    },
    "FTP": {"Existing Account Name": "acct-target", "Subscription Folder": "/ftp/target"},
    "HTTPS": {
        "Partner URL": "https://partner.example/api", "Receiver Grant Type": "client_credentials",
        "Receiver Token Endpoint": "https://partner.example/token", "Receiver Client Id": "client-id",
        "Receiver Client Secret": "client-secret",
    },
    "HTTPS-AS2": {
        "Partner URL": "https://partner.example/as2", "Partner Identifier": "PARTNER-AS2", "Dell Identifier": "DELL-AS2",
        "Signing Algorithm": "SHA256", "Encryption Algorithm": "AES256", "Encryption Certificate": "enc.crt",
        "SSL Certificate": "ssl.crt", "Enable AS2 Message Compression": "False",
        "Asynchronous MDN Required": "False", "Are Input Files Compressed?": "False", "Is EBCDIC enabled?": "False",
    },
    "NAS": {"Protocol": "SMB", "Server Name": "nas-target", "Server Path": "/nas/out", "AD Group": "HIP-NAS"},
    "Rabbit MQ": {"Interface Environment": "DEV", "Exchange Name": "hip.exchange.target"},
}


@pytest.mark.parametrize("interface,params", list(SOURCE_CASES.items()))
def test_v10_every_builtin_source_interface_maps_good_to_go(interface: str, params: dict[str, str]):
    out = analyze_tp_workbook(
        filename="all-interfaces.csv", data=csv_bytes("source", interface, params),
        contracts=load_catalog(), scope="SOURCE", use_llm=False,
    )
    row = out["tpActions"][0]
    assert row["status"] == "GOOD_TO_TRIGGER", (interface, row["missingRequiredPaths"], row["warnings"])
    assert row["interfaceType"] == ("SFTP HAFT" if interface == "SFTP" else interface)
    assert row["contractSnapshot"]["supported_for_live"] is True
    assert row["contractSnapshot"]["method"] == "POST"
    assert "/api/transport-profiles/orchestration/create" in row["contractSnapshot"]["url"]


@pytest.mark.parametrize("interface,params", list(TARGET_CASES.items()))
def test_v10_every_builtin_target_interface_maps_good_to_go(interface: str, params: dict[str, str]):
    out = analyze_tp_workbook(
        filename="all-interfaces.csv", data=csv_bytes("target", interface, params),
        contracts=load_catalog(), scope="TARGET", use_llm=False,
    )
    row = out["tpActions"][0]
    assert row["status"] == "GOOD_TO_TRIGGER", (interface, row["missingRequiredPaths"], row["warnings"])
    assert row["interfaceType"] == ("SFTP HAFT" if interface == "SFTP" else interface)
    assert row["contractSnapshot"]["supported_for_live"] is True


def test_v10_sftp_server_is_distinct_from_sftp_haft_and_directory_means_server_path_only():
    row = analyze_tp_workbook(
        filename="sftp-server.csv", data=csv_bytes("source", "SFTP Server", SOURCE_CASES["SFTP Server"]),
        contracts=load_catalog(), scope="SOURCE", use_llm=False,
    )["tpActions"][0]
    assert row["interfaceFamily"] == "SFTP_SERVER"
    assert row["interfaceType"] == "SFTP Server"
    params = row["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
    assert params["Server Path"] == "/hip/in"
    assert "Subscription Folder" not in params
    assert any(m["sourceColumn"] == "Directory" and m["targetPath"].endswith("parameters.Server Path") for m in row["mappings"])


def test_v10_sftp_server_linux_key_auth_injects_fixed_ssh_key_and_prunes_password():
    supplied = {
        "Server Type": "Linux", "Server Name": "sftp.example", "Server Path": "/in",
        "File Filtering Pattern": ".*", "Post File Transfer Action": "Delete", "Polling Interval": "Every Hour",
        "Are Input Files Compressed?": "False", "Server Port": "22", "Login Authentication Type": "Key",
        "SSH Username": "svc_hip",
    }
    out = materialize_sftp_server_parameters(supplied, system_type="Dell Application", profile_usage="Sender")
    assert out["SSH Key"] == SFTP_SERVER_SSH_KEY
    assert out["SSH Username"] == "svc_hip"
    assert "Username" not in out and "Password" not in out


def test_v10_sftp_server_windows_sender_prunes_linux_auth_fields():
    supplied = {
        "Server Type": "Windows", "Server Name": "win.example", "Server Path": "D:/hip/in",
        "File Filtering Pattern": "*.xml", "Post File Transfer Action": "Delete", "Polling Interval": "Every Hour",
        "Are Input Files Compressed?": "False", "Windows Login Authentication Type": "Password",
        "Windows Username": "svc", "Windows Password": "secret",
    }
    out = materialize_sftp_server_parameters(supplied, system_type="Dell Application", profile_usage="Sender")
    assert out["Windows Username"] == "svc"
    for field in ("Server Port", "Login Authentication Type", "Username", "Password", "SSH Username", "SSH Key"):
        assert field not in out


def test_v10_sftp_server_partner_receiver_prunes_sender_fields_and_requires_ebcdic_codepage_when_true():
    supplied = {
        "Server Type": "Linux", "Server Name": "partner.example", "Server Path": "/out",
        "File Filtering Pattern": "SHOULD_PRUNE", "Post File Transfer Action": "Delete", "Polling Interval": "Every Hour",
        "Are Input Files Compressed?": "False", "Server Port": "22", "Login Authentication Type": "Password",
        "Username": "svc", "Password": "secret", "Is EBCDIC enabled?": "True", "Code Page": "Cp037",
    }
    out = materialize_sftp_server_parameters(supplied, system_type="Partner", profile_usage="Receiver")
    assert out["Code Page"] == "Cp037"
    for field in ("File Filtering Pattern", "Post File Transfer Action", "Polling Interval"):
        assert field not in out
    with pytest.raises(ValueError, match="Partner SFTP Server supports Server Type=Linux only"):
        materialize_sftp_server_parameters({**supplied, "Server Type": "Windows"}, system_type="Partner", profile_usage="Receiver")


def test_v10_sftp_server_sender_conditional_rename_cron_compression():
    supplied = {
        "Server Type": "Linux", "Server Name": "s", "Server Path": "/p", "File Filtering Pattern": ".*",
        "Post File Transfer Action": "Rename", "Rename": "Random Text", "Polling Interval": "Cron Expression",
        "Cron Expression": "0 * * ? * *", "Are Input Files Compressed?": "True", "Compression Format": "ZIP",
        "Server Port": "22", "Login Authentication Type": "Password", "Username": "u", "Password": "p",
    }
    out = materialize_sftp_server_parameters(supplied, system_type="Dell Application", profile_usage="Sender")
    assert out["Rename"] == "Random Text"
    assert out["Cron Expression"] == "0 * * ? * *"
    assert out["Compression Format"] == "ZIP"


def test_v10_interface_catalog_lists_all_seven_as_live_create_supported():
    client = TestClient(app)
    res = client.get("/api/tp/interfaces")
    assert res.status_code == 200
    body = res.json()
    assert body["count"] == 7
    by_name = {x["interfaceType"]: x for x in body["interfaces"]}
    assert set(by_name) == {"SFTP HAFT", "SFTP Server", "FTP", "HTTPS", "HTTPS-AS2", "NAS", "Rabbit MQ"}
    assert all(x["liveCreateSupported"] for x in by_name.values())
    assert by_name["SFTP Server"]["family"] == "SFTP_SERVER"


class _FakeResponse:
    status_code = 201
    text = '{"created":true}'
    def json(self):
        return {"created": True, "id": "test-id"}


@pytest.mark.parametrize("interface,params", list(SOURCE_CASES.items()))
def test_v10_every_builtin_source_interface_can_stage_preflight_and_execute_live(monkeypatch, interface: str, params: dict[str, str]):
    # This test exercises the same HTTP endpoints as the UI while replacing the
    # external Dell network call with a deterministic 201 response.
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer unit-test")
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setattr("app.executor.requests.request", lambda *a, **k: _FakeResponse())

    client = TestClient(app)
    data = csv_bytes("source", interface, params, suffix="live" + uuid.uuid4().hex[:6])
    analyzed = client.post(
        "/api/tp/analyze",
        files={"workbook": ("all.csv", data, "text/csv")},
        data={"tp_scope": "SOURCE", "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert analyzed.status_code == 200, analyzed.text
    a = analyzed.json(); row = a["allApiResults"][0]
    assert row["status"] == "GOOD_TO_TRIGGER", (interface, row.get("warnings"), row.get("missingRequiredPaths"))

    staged = client.post("/api/stage", json={
        "analysisId": a["analysisId"], "rowId": row["actionId"], "payload": row["proposedRequest"], "reviewer": "V10 Test"
    })
    assert staged.status_code == 200, staged.text
    stage_id = staged.json()["stage"]["stageId"]
    pf = client.post(f"/api/stages/{stage_id}/preflight")
    assert pf.status_code == 200, pf.text
    assert pf.json()["preflight"]["passed"] is True, pf.json()["preflight"]
    live = client.post(f"/api/stages/{stage_id}/execute", json={"confirmation": "LIVE", "actor": "V10 Test"})
    assert live.status_code == 200, live.text
    assert live.json()["run"]["success"] is True
    assert live.json()["run"]["statusCode"] == 201



@pytest.mark.parametrize("interface,params", list(TARGET_CASES.items()))
def test_v10_every_builtin_target_interface_can_stage_preflight_and_execute_live(monkeypatch, interface: str, params: dict[str, str]):
    """Prove every Target/Receiver contract reaches the same governed LIVE boundary."""
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer unit-test")
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setattr("app.executor.requests.request", lambda *a, **k: _FakeResponse())

    client = TestClient(app)
    data = csv_bytes("target", interface, params, suffix="livetgt" + uuid.uuid4().hex[:6])
    analyzed = client.post(
        "/api/tp/analyze",
        files={"workbook": ("all-target.csv", data, "text/csv")},
        data={"tp_scope": "TARGET", "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert analyzed.status_code == 200, analyzed.text
    a = analyzed.json(); row = a["allApiResults"][0]
    assert row["status"] == "GOOD_TO_TRIGGER", (interface, row.get("warnings"), row.get("missingRequiredPaths"))

    staged = client.post("/api/stage", json={
        "analysisId": a["analysisId"], "rowId": row["actionId"], "payload": row["proposedRequest"], "reviewer": "V10 Target Test"
    })
    assert staged.status_code == 200, staged.text
    stage_id = staged.json()["stage"]["stageId"]
    pf = client.post(f"/api/stages/{stage_id}/preflight")
    assert pf.status_code == 200, pf.text
    assert pf.json()["preflight"]["passed"] is True, pf.json()["preflight"]
    live = client.post(f"/api/stages/{stage_id}/execute", json={"confirmation": "LIVE", "actor": "V10 Target Test"})
    assert live.status_code == 200, live.text
    assert live.json()["run"]["success"] is True
    assert live.json()["run"]["statusCode"] == 201

def _multi_interface_csv(cases: dict[str, dict[str, str]]) -> bytes:
    # One workbook/table containing multiple TP interface families, like the user's
    # multi-account Excel. The mapper must select a different exact contract per row.
    parameter_headers: list[str] = []
    for params in cases.values():
        for key in params:
            if key not in parameter_headers:
                parameter_headers.append(key)
    headers = ["Source System", "Transport Profile Name", "Interface Type", *parameter_headers]
    out = io.StringIO(); writer = csv.writer(out); writer.writerow(headers)
    for idx, (interface, params) in enumerate(cases.items(), start=1):
        row = ["AIC - DCE", f"V10_{interface.upper().replace(' ', '_').replace('-', '_')}_{idx}_SRC_IB", interface]
        row += [params.get(h, "") for h in parameter_headers]
        writer.writerow(row)
    return out.getvalue().encode("utf-8")


def test_v10_all_seven_interfaces_can_bulk_stage_preflight_and_parallel_live(monkeypatch):
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer unit-test")
    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_BULK_MAX_WORKERS", "4")
    monkeypatch.setenv("HIP_PARALLEL_CONFIG_WORKERS", "4")
    monkeypatch.setenv("HIP_AUTOGEN_MAX_STABLE_AGENTS", "4")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setattr("app.executor.requests.request", lambda *a, **k: _FakeResponse())

    client = TestClient(app)
    analyzed = client.post(
        "/api/tp/analyze",
        files={"workbook": ("all-interfaces.csv", _multi_interface_csv(SOURCE_CASES), "text/csv")},
        data={"tp_scope": "SOURCE", "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert analyzed.status_code == 200, analyzed.text
    body = analyzed.json()
    rows = body["allApiResults"]
    assert len(rows) == 7
    assert all(x["status"] == "GOOD_TO_TRIGGER" for x in rows), [(x["interfaceType"], x["status"], x.get("missingRequiredPaths")) for x in rows]
    assert {x["interfaceType"] for x in rows} == {"SFTP HAFT", "SFTP Server", "FTP", "HTTPS", "HTTPS-AS2", "NAS", "Rabbit MQ"}

    staged = client.post("/api/tp/batch/stage", json={
        "analysisId": body["analysisId"],
        "actionIds": [x["actionId"] for x in rows],
        "reviewer": "V10 Bulk Test",
    })
    assert staged.status_code == 200, staged.text
    stages = staged.json()["stages"]
    assert len(stages) == 7
    stage_ids = [x["stageId"] for x in stages]

    pf = client.post("/api/batch/preflight", json={"stageIds": stage_ids})
    assert pf.status_code == 200, pf.text
    assert pf.json()["passed"] == 7

    live = client.post("/api/batch/execute", json={
        "stageIds": stage_ids, "confirmation": "LIVE ALL", "actor": "V10 Bulk Test",
        "continueOnError": True, "maxWorkers": 4,
    })
    assert live.status_code == 200, live.text
    result = live.json()
    assert result["summary"]["successful"] == 7
    assert result["summary"]["failed"] == 0
    assert result["summary"]["workers"] <= 4

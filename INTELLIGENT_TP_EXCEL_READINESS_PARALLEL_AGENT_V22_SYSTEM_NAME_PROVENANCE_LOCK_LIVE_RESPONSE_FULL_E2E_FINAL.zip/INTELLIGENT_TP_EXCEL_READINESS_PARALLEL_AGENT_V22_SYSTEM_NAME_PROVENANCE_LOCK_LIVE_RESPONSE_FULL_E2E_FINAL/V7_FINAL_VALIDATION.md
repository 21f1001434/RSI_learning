# V7 Final Validation

Release: `INTELLIGENT_TP_EXCEL_READINESS_PARALLEL_AGENT_V7_UHAL_HEALTH_PAYLOAD_ACCURACY_FULL_E2E_FINAL`

## Automated validation
- Pytest: **49 passed / 49 total**
- Python application compilation: **PASS**
- Frontend `app.js` syntax (`node --check`): **PASS**
- FastAPI `/api/health`: **HTTP 200**
- FastAPI `/api/bootstrap`: **HTTP 200**
- UI `/`: **HTTP 200**

## U-HAUL reference parity
Offline payload parity was verified against V122 dev-approved U-HAUL configuration.

Source:
- System: `AIC - DCE`
- TP: `SFTP_U-HAUL_ASN_PC_SRC_IB`
- Interface: `SFTP HAFT`
- DocType: `XML_DellAutoASN_10_U-HAUL_ANS_IB`, version `1.0`
- Subscription Folder: `/SFTP_U-HAUL_ASN_PC_SRC_IB`
- Existing Account: `haftatap10251594`

Target:
- System: `dce-test-partner`
- TP: `SFTP_U-HAUL_ASN_PC_TGT_OB`
- Interface: `SFTP HAFT`
- DocType: `XML_SHIPMENT_NOTICE_10_U-HAUL_ANS_OB`, version `1.0`
- Subscription Folder: `/Inbound/ASN`
- Existing Account: `haftatap10251593`

The only offline value dependent on runtime `.env` is `requestedBy`; V7 reads it from `HIP_REQUESTED_BY`, matching V122 runtime behavior.

## Latest-result issue verdict
1. Source/Target API `DOWN / HTTP 500` from create-route OPTIONS: **invalid false-negative; fixed**.
2. Missing Document Type Name/Version where Excel has no usable value: **valid blocker**.
3. Combined `DocumentTypeName(1.0)` stored entirely as name: **invalid mapping; fixed with deterministic split**.
4. Every duplicate TP identity blocked: **over-strict; fixed**. Exact repeated evidence merges; conflicting duplicates block.
5. `LENS TP Name` used as executable Transport Profile name: **invalid; fixed**.
6. Generic/fuzzy account values such as `Yes`/`Catalogues`: **invalid account extraction; fixed**.
7. Ambiguous Source/Target role when both sides have evidence and explicit TP name does not encode role: **valid review blocker**.
8. Missing SFTP Subscription Folder / Existing Account Name: **valid V122 FILE TP blocker**.

## Safety
The U-HAUL smoke test calls only V122 TP validation, never TP Create. No real TP Create mutation was performed in this validation environment.

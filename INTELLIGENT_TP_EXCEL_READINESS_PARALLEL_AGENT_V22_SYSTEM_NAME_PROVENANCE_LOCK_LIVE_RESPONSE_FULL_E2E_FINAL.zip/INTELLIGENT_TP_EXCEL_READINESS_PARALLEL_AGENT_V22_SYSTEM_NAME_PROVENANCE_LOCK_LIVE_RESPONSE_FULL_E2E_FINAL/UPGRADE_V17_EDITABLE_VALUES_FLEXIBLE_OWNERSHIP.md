# V17 - Editable TP Values + Flexible Sender/Receiver Ownership

## Role and ownership are independent

- Source TP = Sender
- Target TP = Receiver
- Sender can be Dell Application or Client/Partner
- Receiver can be Dell Application or Client/Partner

U-HAUL is only an approved reference pattern: Sender=Dell, Receiver=Client/Partner. It is not applied globally.

## Ownership resolution order

1. Role-specific Excel ownership fields.
2. Explicit generic ownership field.
3. Safe tokens in the role-correct System value.
4. Approved U-HAUL reference fallback.
5. Human confirmation in the UI when still ambiguous.

## Human ownership endpoint

POST /api/tp/analyses/{analysis_id}/actions/{action_id}/ownership

Example body:

```json
{"systemType":"Partner","actor":"Human User"}
```

The backend rebuilds the approved interface contract before Stage and reruns readiness plus LLM-as-Judge.

## Editable values

The UI provides:

- field-by-field canonical leaf value editor
- advanced exact JSON payload value editor

Only values can change. Attributes, nesting, arrays, interface schema, method, URL, headers, role selectors and interface selectors stay immutable.

## Existing lifecycle retained

Excel -> Mapping -> Value/ownership review -> Stage -> Dell pre-create validator -> Judge -> LIVE Create -> audit verification -> VERIFIED_CREATED/EXISTING_VERIFIED -> Migration Preflight -> TP Migration -> target audit verification -> VERIFIED_MIGRATED.

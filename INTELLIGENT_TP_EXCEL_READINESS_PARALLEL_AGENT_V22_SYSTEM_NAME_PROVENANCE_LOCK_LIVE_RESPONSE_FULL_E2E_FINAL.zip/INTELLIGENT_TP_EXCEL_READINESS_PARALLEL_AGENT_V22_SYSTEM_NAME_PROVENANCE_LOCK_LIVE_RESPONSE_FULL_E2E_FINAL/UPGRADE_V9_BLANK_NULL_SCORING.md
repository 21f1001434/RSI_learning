# V9 — Blank / Null Aware Completeness Scoring

## Problem fixed

V8 forced `score = 100` whenever a TP was `GOOD_TO_TRIGGER`, even if optional canonical payload values were blank or null. That made the score look complete when the workbook/API payload still had missing values.

## V9 behavior

Execution decision and completeness score are independent:

- `GOOD_TO_TRIGGER`: mandatory execution gates passed.
- `NEEDS_INPUT`: a mandatory value/review gate is unresolved.
- `DO_NOT_TRIGGER`: the action is blocked.
- `score`: actual canonical payload value completeness.

Blank/null values always reduce score.

### Values treated as missing

`None`, `""`, whitespace-only strings, `null`, `none`, `NaN`, `<NA>`, `N/A`, empty lists and empty objects.

`0` and `false` remain valid values.

### Weighting

- required canonical payload leaf = 3× weight
- optional canonical payload leaf = 1× weight
- populated value = full credit for that leaf
- blank/null = zero credit

Required missing values therefore reduce the score more strongly and still block execution through the existing readiness gates.

## UI / HTML report

Each TP now exposes:

- canonical field count
- populated field count
- blank/null field count
- blank required field count
- blank optional field count
- completeness score
- score basis
- individual blank fields in the complete API field matrix

A Good-to-Go TP is no longer automatically shown as 100/100.

## Mapping and execution behavior retained

All V8 team mapping corrections remain unchanged, including explicit Interface Type precedence, Directory != Subscription Folder, HIP Account != Existing Account Name, grouped Account context, optional Document Type, schema locking, staging, preflight, U-HAUL health validation, and parallel LIVE execution.

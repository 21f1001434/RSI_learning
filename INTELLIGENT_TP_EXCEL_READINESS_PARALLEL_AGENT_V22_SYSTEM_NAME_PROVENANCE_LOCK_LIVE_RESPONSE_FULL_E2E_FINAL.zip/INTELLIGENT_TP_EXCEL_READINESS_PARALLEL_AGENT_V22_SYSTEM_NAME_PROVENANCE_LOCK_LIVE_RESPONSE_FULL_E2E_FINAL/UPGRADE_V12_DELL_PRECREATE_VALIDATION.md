# V12 — Dell pre-create validation and explicit missing-value diagnostics

- Added exact staged TP validation using `POST /api/transport-profiles/validate-unique-interface-detail` before mutating Create.
- Validation uses the same staged `interfaceType`, interface `parameters`, `transportProfileName`, and HIP environment that would be used by Create.
- Any Dell validation rejection blocks Create and is surfaced with HTTP status and response summary.
- Restored V130 FILE readiness: `Subscription Folder` + `Existing Account Name` are required for SFTP HAFT / FTP.
- Added blank required/optional counts to preflight.
- Added customer UI summary listing every missing required and optional/contract blank path.
- Batch LIVE result now distinguishes **ACCEPTED** from **REJECTED** and displays the Dell response/diagnosis.
- Execution history stores and displays `responseSummary`.
- Immutable interface contract/value-only LIVE protections from V11 remain unchanged.

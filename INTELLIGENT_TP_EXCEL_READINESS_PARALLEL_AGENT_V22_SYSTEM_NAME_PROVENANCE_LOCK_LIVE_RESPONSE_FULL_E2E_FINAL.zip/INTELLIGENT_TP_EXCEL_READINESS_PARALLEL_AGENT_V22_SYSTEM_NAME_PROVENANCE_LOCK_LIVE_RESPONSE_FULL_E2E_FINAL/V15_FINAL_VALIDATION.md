# V15 Final Validation — LLM-as-Judge + Verified TP Create/Migration

Date: 2026-09-18

## Result

**PASS — 130 / 130 automated tests**

Command:

```text
python -m pytest -q
```

Result:

```text
130 passed in 10.08s
```

## Static/runtime checks

- Python application compilation: PASS
- Frontend `app/static/app.js` syntax (`node --check`): PASS
- `GET /api/health`: HTTP 200
- `GET /api/bootstrap`: HTTP 200
- `GET /api/tp/interfaces`: HTTP 200
- `GET /api/runtime/live-readiness`: HTTP 200
- `GET /api/runtime/migration-readiness`: HTTP 200
- `GET /`: HTTP 200
- `POST /api/judge/test` with Judge disabled for offline smoke: HTTP 200
- Supported TP interfaces returned: 7
- V130 `.env.example` keys retained: 71 / 71 unique keys
- Missing V130 environment keys: 0

## Interface coverage

Both Source/Sender and Target/Receiver contracts remain supported for:

1. SFTP HAFT
2. SFTP Server
3. FTP
4. HTTPS
5. HTTPS-AS2
6. NAS
7. Rabbit MQ

All retain interface-specific immutable attribute structures and values-only execution.

## Create API path validation

Create route:

```text
POST /api/transport-profiles/orchestration/create
```

Pre-create non-mutating validation:

```text
POST /api/transport-profiles/validate-unique-interface-detail
```

Post-create checking/audit API:

```text
GET /api/transport-profiles/audits
```

Create HTTP 2xx is treated as accepted, not verified success. A new exact-TP terminal-success audit is required when post-create verification is enabled.

## TP Migration API validation

Exact V130 route:

```text
POST /api/migration/orchestration/transport-profile
```

Immutable migration attributes:

```text
sourceEnvironment
targetEnvironment
transportProfileName
transportProfileInterfaceType
transportProfileInterfaceParameters
```

The migration parameters preserve the exact locked interface parameter schema for every supported interface. Tests cover single and parallel/bulk migration and target-environment post-check semantics.

## LLM-as-Judge validation

The Judge is an independent role/prompt around deterministic validation.

Verified safety behavior:

- deterministic `BLOCK` cannot be promoted by LLM `PASS`
- LLM may make a deterministic decision more conservative
- Judge prompt/evidence redacts sensitive values
- Judge cannot mutate payloads or execute APIs
- mapping Judge evidence is exposed in analysis results
- Create preflight Judge is exposed and can be mandatory
- mandatory Judge gate blocks LIVE before any mutating network call
- post-Create Judge consumes Create + audit verification evidence
- Migration preflight Judge is exposed and can be mandatory
- post-Migration Judge consumes migration + target verification evidence
- offline/unavailable Judge cannot bypass deterministic gates

Environment controls:

```text
LLM_JUDGE_ENABLED
LLM_JUDGE_MODEL
LLM_JUDGE_TEMPERATURE
LLM_JUDGE_REQUIRED_FOR_LIVE
LLM_JUDGE_FAIL_CLOSED
```

## Immutable boundary validation

Tests continue to reject:

- added attributes
- removed attributes
- renamed attributes
- re-nested attributes
- changed list cardinality
- interface selector changes after contract selection
- Source/Target role changes
- method/URL drift
- contract/schema drift after preflight
- server-side state tampering before execution

Final network requests are reconstructed from the canonical selected-interface schema plus staged permitted values.

## Excel/readiness/report validation

Retained behavior includes:

- explicit Excel Interface Type contract selection
- U-HAUL SFTP HAFT reference suggestion (advisory only)
- exact field provenance
- blank/null-aware completeness scoring
- required-value blockers before LIVE
- customer-by-customer full TP field mapping
- master and individual HTML readiness reports
- Dell AIA/API/Judge health visibility
- loading/progress UX
- selected parallel Stage/Preflight/LIVE execution
- response diagnostics when Dell rejects a request

## External Dell boundary limitation

The application production code uses the real configured Dell HTTP route through `requests.request(...)` when LIVE/Migration gates and credentials are enabled. The release validation environment did **not** contain the user's Dell credentials and did not perform a real mutating Dell TP Create/Migration. Automated tests mock only the final external HTTP boundary while exercising the full application orchestration, gating, payload-building, verification, and Judge logic.

# V14 — Verified TP Create + V130 Transport Profile Migration

## Scope

V14 extends the standalone TP Excel application with two governed lifecycle guarantees:

1. **Create is verified after Dell accepts it.** A 2xx response is not final success. The application checks `GET /api/transport-profiles/audits` for the exact TP/environment and requires a new terminal-success record before reporting `VERIFIED_CREATED` when post-create verification is enabled.
2. **Transport Profile Migration uses the exact V130 Dev-published contract.**

## Exact Migration API

```text
POST /api/migration/orchestration/transport-profile
```

Exact top-level request attributes:

```text
sourceEnvironment
targetEnvironment
transportProfileName
transportProfileInterfaceType
transportProfileInterfaceParameters
```

The application does not add wrapper fields and does not infer a different Migration payload shape.

## Immutable parameter reuse

`transportProfileInterfaceParameters` is a deep copy of the already-selected Source/Target TP interface `parameters` object. Therefore the Migration API supports all built-in TP interfaces without maintaining a second, divergent parameter mapper:

- SFTP HAFT
- SFTP Server
- FTP
- HTTPS
- HTTPS-AS2
- NAS
- Rabbit MQ

The selected interface attributes remain immutable. Only values can change through the governed value-edit path before Stage/Preflight.

## Migration governance

A TP can migrate only after:

- its Excel mapping is `GOOD_TO_TRIGGER`;
- the TP Stage exists;
- the normal TP Preflight passed;
- `HIP_LIVE_API_EXECUTION=true`;
- `HIP_TP_MIGRATION_ENABLED=true`;
- the Migration host is allowlisted;
- HIP OAuth succeeds;
- PROD guard passes when applicable;
- source and target environments are present and different;
- the operator confirms `MIGRATE` for a single TP or `MIGRATE ALL` for a batch.

New runtime controls:

```env
HIP_TP_MIGRATION_ENABLED=false
HIP_MIGRATION_SOURCE_ENVIRONMENT=
HIP_MIGRATION_TARGET_ENVIRONMENT=
HIP_TP_MIGRATION_POST_CHECK_ENABLED=true
HIP_TP_MIGRATION_POLL_INTERVAL_SECONDS=60
HIP_TP_MIGRATION_POLL_TIMEOUT_SECONDS=3600
```

## Migration verification

When `HIP_TP_MIGRATION_POST_CHECK_ENABLED=true`, the app snapshots the target-environment TP audit state before Migration and polls the checking API afterward. It only reports `VERIFIED_MIGRATED` when a new matching terminal-success record is observed.

Possible states are explicit, including:

- `VERIFIED_MIGRATED`
- `MIGRATION_REJECTED`
- `MIGRATION_ACCEPTED_AUDIT_FAILED`
- `MIGRATION_ACCEPTED_VERIFICATION_PENDING`
- `MIGRATION_ACCEPTED_UNVERIFIED` (only when post-check is intentionally disabled)

## UI

The application now exposes single-TP and batch Migration controls:

- Source Environment
- Target Environment
- Validate Migration API / Migration Preflight
- `MIGRATE` confirmation
- `MIGRATE ALL` batch confirmation
- per-request result/evidence

The runtime/governance view shows the resolved method, route, environments, OAuth/live gates and Migration enablement without performing a mutation.

## U-HAUL guidance

U-HAUL remains an approved SFTP HAFT reference. The AI can surface SFTP HAFT as an advisory suggestion with U-HAUL as supporting reference. This does not auto-select a missing interface, mutate attributes, or bypass the human-governed lifecycle.

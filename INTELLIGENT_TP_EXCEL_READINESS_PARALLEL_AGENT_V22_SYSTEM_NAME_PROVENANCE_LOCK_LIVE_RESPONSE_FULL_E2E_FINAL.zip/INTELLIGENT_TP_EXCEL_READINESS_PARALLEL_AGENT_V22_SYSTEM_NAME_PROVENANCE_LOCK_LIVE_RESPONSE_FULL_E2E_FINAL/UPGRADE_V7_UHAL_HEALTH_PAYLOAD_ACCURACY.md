# V7 — U-HAUL TP Health + Payload Accuracy Hardening

## Why V7
The latest V6 screenshots showed Dell AIA and HIP OAuth as UP while Source/Target TP API health was DOWN with HTTP 500. That verdict was caused by an unsupported `OPTIONS` request to the TP orchestration create route. V7 removes that false-negative health logic from the service verdict.

## U-HAUL non-mutating service smoke
- Source/Target TP health is tested with the V122 endpoint:
  `/api/transport-profiles/validate-unique-interface-detail`
- The smoke request uses the exact developer-approved U-HAUL SFTP HAFT source/target property maps from V122.
- It tests V122 HIP OAuth, TLS/CA settings, host routing, validator route and TP interface payload family.
- It NEVER calls `/api/transport-profiles/orchestration/create`.
- Create-route `OPTIONS` is retained only as secondary diagnostics. HTTP 500 to OPTIONS is now `INCONCLUSIVE`, not `DOWN`.
- Runtime UI adds `Run U-HAUL TP Smoke Test` with Source/Target result cards.

## U-HAUL payload parity
V7 validates the workbook mapper against exact V122 U-HAUL Source and Target create payloads.
- Source TP: `SFTP_U-HAUL_ASN_PC_SRC_IB`
- Target TP: `SFTP_U-HAUL_ASN_PC_TGT_OB`
- `SFTP Server` Excel interface alias -> API `SFTP HAFT`
- V122 `Move To Archive` capitalization preserved
- Subscription Folder and Existing Account Name are required for FILE/SFTP TP readiness
- Document Type is sent as separate `documentTypeName` and `documentTypeVersion`
- `NAME(1.0)` Excel cells are deterministically split to name + version
- V122 customer and haftAccount tag values are populated from workbook evidence

## Readiness fixes from latest result
- `LENS TP Name` is reference/customer evidence only. It is no longer accepted as executable `transportProfileName`.
- TP identity requires DEV/Source/Target Transport Profile Name from Excel.
- HIP Account extraction is exact-header-only; broad fuzzy `Account` matches no longer produce values such as `Yes` or `Catalogues`.
- Exact duplicate evidence rows are merged into one TP candidate.
- Same TP identity with conflicting payload values remains `NEEDS_INPUT`.
- Missing Document Type Name/Version, TP name, System, Subscription Folder or Existing Account Name remain valid blockers.

## UI/report improvements
- Queue separates Customer, Application and HIP Account.
- Deep health explains validator-based TP health.
- U-HAUL smoke test button has loading state.
- Master HTML report separates Customer, Application and HIP Account.
- Per-customer complete canonical field coverage remains available.

## Validation
- 49/49 automated tests pass.
- U-HAUL Source workbook parity test: PASS.
- U-HAUL Target workbook parity test: PASS.
- Create OPTIONS HTTP 500 false-negative regression: PASS.
- Exact duplicate merge / conflicting duplicate block: PASS.
- LENS TP Name executable-identity regression: PASS.
- Python compile: PASS.
- Frontend JavaScript syntax: PASS.

No live TP Create mutation was executed during V7 validation. Actual authenticated service smoke is intended to run on the target machine using the user's V122-compatible `.env` credentials.

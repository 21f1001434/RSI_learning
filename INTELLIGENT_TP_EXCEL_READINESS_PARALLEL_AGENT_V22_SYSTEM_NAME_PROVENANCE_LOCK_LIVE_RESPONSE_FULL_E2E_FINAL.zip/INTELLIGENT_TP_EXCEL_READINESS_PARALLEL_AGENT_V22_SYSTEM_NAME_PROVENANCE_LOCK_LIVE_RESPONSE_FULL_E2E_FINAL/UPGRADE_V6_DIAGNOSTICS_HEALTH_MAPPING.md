# V6 Upgrade — TP Diagnostics, Per-Customer Mapping, Health & Loading UX

## Why V6 was needed

The supplied UI screenshots showed many TP rows with `Interface = SFTP Server` but `Mapped = 0`, `Score = 0/100`, `Not Ready`. The interface value was explicitly present in Excel, but V5 recognized only literal SFTP spellings.

V6 fixes this while preserving the core rule: **the interface is still read only from the authoritative Excel Interface Type cell; it is never inferred from other evidence.**

## Changes

### 1. Explicit interface alias registry

Approved labels such as `SFTP Server` are canonicalized to the exact V122 API interface value `SFTP HAFT`. Every canonicalization keeps the source Excel column/value in the audit trail and UI.

### 2. Strict TP mapping

Generic fuzzy overmapping was removed from the TP-specific path. Only approved TP aliases and high-confidence LLM suggestions to existing canonical paths can map values. Unknown columns remain evidence-only.

### 3. Hard readiness checklist

Every customer/TP exposes named PASS/FAIL checks rather than an unexplained mapping percentage. Missing System, TP Name, Document Type or interface parameters are visible immediately.

### 4. Complete API field matrix per customer

Every canonical payload leaf is displayed with required/optional status, final value, source classification, Excel source, mapping confidence and suggested Excel column if missing.

### 5. Individual customer reports

Each customer/TP gets its own downloadable HTML mapping/readiness report in addition to the workbook-level report.

### 6. Workbook diagnostics

The master result shows top blockers and Excel Interface → API Interface mapping counts so operators can identify systematic extraction/template problems quickly.

### 7. Active agent/API health

The app actively tests Dell AIA, HIP OAuth and Source/Target TP endpoint reachability using non-mutating checks. It distinguishes backend, model, OAuth and gateway/API state.

### 8. Loading feedback

Analyze, health, stage, preflight, approval and LIVE operations display an animated loading overlay, button loading state and elapsed time.

## Safety retained

- Interface inference remains disabled.
- Payload schema is immutable.
- Excel evidence cannot invent request attributes.
- AS2 receiver SSL certificate remains mandatory.
- Human stage + preflight + explicit LIVE confirmation remain mandatory.
- Parallel execution remains capped by V122 stability settings.
- Active health probes do not call TP Create.

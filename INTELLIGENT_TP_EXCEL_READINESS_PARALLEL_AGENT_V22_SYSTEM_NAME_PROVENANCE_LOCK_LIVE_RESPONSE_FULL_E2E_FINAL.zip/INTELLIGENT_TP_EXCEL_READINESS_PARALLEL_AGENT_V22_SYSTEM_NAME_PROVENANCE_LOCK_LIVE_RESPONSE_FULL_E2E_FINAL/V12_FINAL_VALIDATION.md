# V12 Final Validation — Dell TP pre-create validation and clear missing-value diagnostics

Date: 2026-09-17

## Final result

- Full automated regression: **112 / 112 PASS**
- Python compilation: **PASS**
- Frontend JavaScript syntax (`node --check`): **PASS**
- `GET /api/health`: **HTTP 200**
- `GET /api/bootstrap`: **HTTP 200**
- `GET /api/tp/interfaces`: **HTTP 200**
- `GET /api/runtime/live-readiness`: **HTTP 200**
- UI `/`: **HTTP 200**
- V130 environment parity: **71 / 71 unique V130 keys retained; 0 missing**

## V12 corrections

1. **Exact staged-value Dell validation before Create**
   - Preflight builds the non-mutating validator request from the exact staged Create values.
   - Endpoint: `POST /api/transport-profiles/validate-unique-interface-detail`.
   - If Dell rejects those values, preflight is blocked and the mutating Create endpoint is not called.

2. **SFTP HAFT / FTP mandatory readiness corrected to V130 behavior**
   - `Subscription Folder` is required.
   - `Existing Account Name` is required.
   - Missing either value produces `NEEDS_INPUT`, not `GOOD_TO_TRIGGER`.

3. **Blank/null visibility**
   - Preflight returns `missingRequiredPaths`, `blankOptionalPaths`, `blankCanonicalPaths` and counts.
   - Customer UI lists required-missing and optional-blank values separately.

4. **HTTP 400 semantics fixed**
   - HTTP 400 means Dell was reached and rejected the request.
   - Execution evidence now records `dellReached`, `dellAccepted`, `resultState`, and `responseSummary`.
   - Batch results and execution history show the Dell response/diagnosis instead of only `FAILED`.

5. **Immutable V11 contract boundary preserved**
   - No key/attribute add/remove/rename/re-nesting/cardinality mutation.
   - Interface-specific approved schema remains locked after selection.
   - Only approved values can vary.

## Safety

The automated suite does not perform an authenticated real Dell TP Create mutation. External HTTP is mocked in LIVE execution tests; Dell credentials remain local to the operator environment.

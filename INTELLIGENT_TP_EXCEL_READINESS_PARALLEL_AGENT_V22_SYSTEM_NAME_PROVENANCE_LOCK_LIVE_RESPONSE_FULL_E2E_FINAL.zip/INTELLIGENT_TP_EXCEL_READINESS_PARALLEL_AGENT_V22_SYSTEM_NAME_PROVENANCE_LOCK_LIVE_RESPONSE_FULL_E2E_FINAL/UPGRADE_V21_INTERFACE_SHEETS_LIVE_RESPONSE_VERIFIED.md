# V21 — Interface Sheets + Verified LIVE Response Intelligence

V21 is the consolidation release built on V20. It keeps the immutable Transport Profile contracts, all seven interface families, value-only edits, flexible Dell/Partner ownership, multi-document `documentTypeDetails[]`, Dell pre-create validation, verified Create, Migration, and LLM-as-Judge behavior.

## V21 additions

- Bundles `HIP_TP_TEAM_INPUT_TEMPLATE_V21_INTERFACE_SHEETS_FILTERS_DROPDOWNS.xlsx`.
- Exposes the template from `GET /api/tp/team-template.xlsx` and adds a UI download link.
- The workbook has one executable sheet per interface: `SFTP_HAFT`, `FTP`, `SFTP_SERVER`, `HTTPS`, `HTTPS_AS2`, `NAS`, `RABBIT_MQ`.
- The parser detects row 6 as the header in all seven sheets and ingests data from row 7 onward.
- `README` and `ALLOWED_VALUES` remain non-executable reference sheets.
- The explicit Excel `Interface Type` cell remains authoritative; the sheet name is not used to invent or override the interface.
- A filled seven-sheet regression workbook is included under `tests/fixtures/` and is verified as 7/7 `GOOD_TO_TRIGGER`.

## LIVE execution path

The actual application path remains:

`Excel → Analyze → Good-to-Go → Stage → Preflight → explicit LIVE/LIVE ALL → requests.request(...) → Dell HIP Create endpoint → Dell checking/audit endpoint → final classification`

The mutating Create call is only reached when all runtime and governance gates pass, including the exact staged schema/value fingerprints, approved contract, allowlisted host, auth material, production guard, and explicit user confirmation.

## Response classification

V21 keeps the deterministic classifier authoritative and adds further structured-response hardening:

- `SUCCESS` — a new Create is terminally verified successful by Dell checking/audit evidence.
- `EXISTING` — Dell explicitly reports the exact TP already exists and the checking API verifies it.
- `FAILED` — HTTP rejection, semantic failure in a 2xx body, terminal audit failure, or a verified-existing record whose latest exact-TP audit is terminally failed.
- `PENDING` — Dell accepted the request, or existing evidence was returned, but terminal exact-TP verification is not yet available.

Additional V21 response signals include top-level existing states such as `ALREADY_EXISTS`, explicit `transportProfileExists: true`, and string boolean success flags such as `"success":"false"`.

Dell AIA / `gpt-oss-120b` may explain the redacted response and return an advisory classification, but cannot override the deterministic state, mutate the request, or call another API.

## Batch outcome visibility

Batch execution now returns separate counts for `SUCCESS`, `EXISTING`, `FAILED`, and `PENDING`. The previous `successful` field is retained for backward compatibility, while the UI uses the explicit final classification counts.

## Safety boundary retained

V21 does not relax any API mutation safeguards. The agent still cannot add, remove, rename, or re-nest API attributes after contract selection. `documentTypeDetails[]` cardinality can only be materialized from repeated same-TP Excel rows during analysis and is locked afterward.

Automated release verification mocks only the external Dell HTTP boundary. No authenticated Dell Create or Migration mutation was performed while packaging the release.

# V19 Final Validation Report

Release: `V19_MULTI_DOCUMENT_SYSTEM_NAME_FULL_E2E_FINAL`  
Validation date: 2026-09-22

## Result

**141 / 141 automated tests PASS**

```text
pytest                              PASS (141 passed, 0 failed)
Python compilation                  PASS
Frontend JavaScript syntax          PASS
/api/health                         HTTP 200
/api/bootstrap                      HTTP 200
/api/tp/interfaces                  HTTP 200
/api/runtime/live-readiness         HTTP 200
/api/runtime/migration-readiness    HTTP 200
UI /                                HTTP 200
```

## New V19 regression validation

Validated a workbook-equivalent CSV with the same TP repeated three times and different Document Type evidence:

```text
TP_MULTI_DOC_SRC_IB
  ├─ perf_poa_855_edf  / 1.0 / EDIX12
  ├─ 2BDoctype10.0     / 1.0 / XML
  └─ AGING_FLATFILE    / 3.0 / FLAT
```

The analyzer emitted exactly **one** TP action whose payload contained exactly **three** dictionaries in `transportProfileDetails[0].documentTypeDetails`.

The resulting per-action canonical contract also contained three document dictionaries, so:

```text
Analyze                    PASS
Schema lock                PASS
Stage                      PASS
Preflight                  PASS
Preflight result           passed=true
```

The test also verifies that each document row keeps its own mapping provenance, including `dataFormatType`.

## System Name validation

A populated column named:

```text
Add > Transport Profile Details > System Name
```

was correctly mapped to:

```text
systemName = AIC - DCE
```

and `systemName` was not present in `missingRequiredPaths`.

Cross-role safety remains in place: Source TP cannot consume Target System evidence and Target TP cannot consume Source System evidence.

## Conflict behavior retained

Rows sharing a TP identity are auto-merged only when differences are limited to `documentTypeDetails`. Differences in non-document TP payload values still produce a review-required conflicting duplicate instead of silent consolidation.

## Existing functionality retained

The full suite continues to cover:

- SFTP HAFT
- SFTP Server
- FTP
- HTTPS
- HTTPS-AS2
- NAS
- Rabbit MQ
- Source/Sender and Target/Receiver
- Dell Application or Client/Partner ownership on either side
- U-HAUL approved Sender=Dell / Receiver=Client reference
- human value editing + revalidation
- ownership rebuild before Stage
- ownership immutability after Stage
- schema/selector mutation rejection
- LLM-as-Judge gates
- Dell pre-create validation
- post-create checking/audit verification
- TP Migration and migration verification
- parallel Stage/Create/Migration controls

## External mutation boundary

Automated validation did **not** execute a real mutating Dell TP Create or Migration request. Real execution remains controlled by the local `.env`, Dell OAuth/credentials, LIVE flags, host allowlist, preflight, validation API, Judge configuration, and explicit human confirmation.

from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Tuple

ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = ROOT / "config" / "api_catalog.json"


def flatten_leaves(value: Any, prefix: str = "") -> List[Tuple[str, Any]]:
    if isinstance(value, dict):
        out: List[Tuple[str, Any]] = []
        for key, child in value.items():
            out.extend(flatten_leaves(child, f"{prefix}.{key}" if prefix else str(key)))
        return out
    if isinstance(value, list):
        out: List[Tuple[str, Any]] = []
        for index, child in enumerate(value):
            out.extend(flatten_leaves(child, f"{prefix}.{index}" if prefix else str(index)))
        return out
    return [(prefix, value)] if prefix else []


def read_path(root: Any, path: str) -> Any:
    node = root
    for part in str(path).split("."):
        if isinstance(node, list):
            try: node = node[int(part)]
            except Exception: return None
        elif isinstance(node, dict): node = node.get(part)
        else: return None
    return node


def write_path(root: Any, path: str, value: Any) -> None:
    node = root
    parts = str(path).split(".")
    for index, part in enumerate(parts):
        last = index == len(parts) - 1
        if isinstance(node, list):
            pos = int(part)
            if pos >= len(node): raise KeyError(path)
            if last: node[pos] = value
            else: node = node[pos]
        elif isinstance(node, dict):
            if part not in node: raise KeyError(path)
            if last: node[part] = value
            else: node = node[part]
        else: raise KeyError(path)


def schema_locked(base: Any, candidate: Any) -> bool:
    def sig(v: Any, prefix: str = "$") -> List[Tuple[str, str, Any]]:
        rows: List[Tuple[str, str, Any]] = []
        if isinstance(v, dict):
            rows.append((prefix, "object", tuple(sorted(v.keys()))))
            for key in sorted(v): rows.extend(sig(v[key], f"{prefix}.{key}"))
        elif isinstance(v, list):
            rows.append((prefix, "array", len(v)))
            for i, item in enumerate(v): rows.extend(sig(item, f"{prefix}.{i}"))
        else: rows.append((prefix, "scalar", None))
        return rows
    return sig(base) == sig(candidate)


def _digest(raw: Mapping[str, Any]) -> str:
    relevant = {k: raw.get(k) for k in (
        "key", "version", "method", "url", "request_kind", "canonical_request", "required_paths",
        "identity_paths", "field_rules", "headers", "success_statuses", "preflight_checks", "depends_on",
        "locked_value_paths", "interface_family", "tp_role"
    )}
    data = json.dumps(relevant, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def normalize_contract(raw: Mapping[str, Any]) -> Dict[str, Any]:
    key = str(raw.get("key") or "").strip()
    if not key: raise ValueError("Every API contract needs a non-empty key")
    method = str(raw.get("method") or "POST").strip().upper()
    if method not in {"GET", "POST", "PUT", "PATCH", "DELETE"}: raise ValueError(f"{key}: unsupported HTTP method {method}")
    request_kind = str(raw.get("request_kind") or raw.get("requestKind") or ("params" if method == "GET" else "payload")).strip().lower()
    if request_kind not in {"payload", "params"}: raise ValueError(f"{key}: request_kind must be payload or params")
    canonical = deepcopy(raw.get("canonical_request") if "canonical_request" in raw else raw.get("canonicalRequest"))
    if not isinstance(canonical, dict): raise ValueError(f"{key}: canonical_request must be a JSON object")
    paths = [path for path, _ in flatten_leaves(canonical)]
    required = [str(x) for x in (raw.get("required_paths") or raw.get("requiredPaths") or [])]
    identity = [str(x) for x in (raw.get("identity_paths") or raw.get("identityPaths") or [])]
    sensitive = [str(x) for x in (raw.get("sensitive_paths") or raw.get("sensitivePaths") or [])]
    locked_values = [str(x) for x in (raw.get("locked_value_paths") or raw.get("lockedValuePaths") or [])]
    unknown = [p for p in required + identity + sensitive + locked_values if p not in paths]
    if unknown: raise ValueError(f"{key}: required/identity/sensitive/locked paths are not canonical leaves: {unknown[:10]}")
    field_rules = deepcopy(raw.get("field_rules") or raw.get("fieldRules") or {})
    if not isinstance(field_rules, dict): raise ValueError(f"{key}: field_rules must be an object")
    unknown_rules = [str(p) for p in field_rules if str(p) not in paths]
    if unknown_rules: raise ValueError(f"{key}: field_rules reference non-canonical leaves: {unknown_rules[:10]}")
    lifecycle = str(raw.get("lifecycle_status") or raw.get("lifecycleStatus") or "APPROVED").strip().upper()
    if lifecycle not in {"DRAFT", "APPROVED", "DEPRECATED"}: raise ValueError(f"{key}: lifecycle_status must be DRAFT, APPROVED or DEPRECATED")
    duplicate_policy = str(raw.get("duplicate_policy") or raw.get("duplicatePolicy") or "warn").strip().lower()
    if duplicate_policy not in {"allow", "warn", "block"}: raise ValueError(f"{key}: duplicate_policy must be allow, warn or block")
    retry = deepcopy(raw.get("retry_policy") or raw.get("retryPolicy") or {})
    if not isinstance(retry, dict): retry = {}
    retry = {
        "enabled": bool(retry.get("enabled", False)),
        "max_attempts": max(1, min(int(retry.get("max_attempts", retry.get("maxAttempts", 3))), 6)),
        "backoff_seconds": max(0.0, min(float(retry.get("backoff_seconds", retry.get("backoffSeconds", 1.0))), 30.0)),
        "statuses": [int(x) for x in (retry.get("statuses") or [429, 502, 503, 504])],
    }
    preflight_checks = deepcopy(raw.get("preflight_checks") or raw.get("preflightChecks") or [])
    if not isinstance(preflight_checks, list): raise ValueError(f"{key}: preflight_checks must be a list")
    for check in preflight_checks:
        if not isinstance(check, dict): raise ValueError(f"{key}: every preflight check must be an object")
        cm = str(check.get("method") or "GET").upper()
        if cm not in {"GET", "HEAD"}: raise ValueError(f"{key}: preflight checks are read-only and must use GET/HEAD")
    result = {
        "key": key,
        "name": str(raw.get("name") or raw.get("label") or key),
        "group": str(raw.get("group") or "API"),
        "description": str(raw.get("description") or ""),
        "version": str(raw.get("version") or "1.0.0"),
        "owner": str(raw.get("owner") or "Unassigned"),
        "lifecycle_status": lifecycle,
        "tags": [str(x) for x in (raw.get("tags") or [])],
        "method": method,
        "url": str(raw.get("url") or "").strip(),
        "request_kind": request_kind,
        "canonical_request": canonical,
        "required_paths": required,
        "identity_paths": identity,
        "sensitive_paths": sensitive,
        "locked_value_paths": locked_values,
        "field_rules": field_rules,
        "headers": dict(raw.get("headers") or {}),
        "header_aliases": dict(raw.get("header_aliases") or raw.get("headerAliases") or {}),
        "success_statuses": [int(x) for x in (raw.get("success_statuses") or raw.get("successStatuses") or [200, 201, 202, 204])],
        "allow_live": bool(raw.get("allow_live", raw.get("allowLive", True))),
        "duplicate_policy": duplicate_policy,
        "idempotency_header": str(raw.get("idempotency_header") or raw.get("idempotencyHeader") or "").strip(),
        "retry_policy": retry,
        "preflight_checks": preflight_checks,
        "depends_on": [str(x) for x in (raw.get("depends_on") or raw.get("dependsOn") or [])],
        "notes": list(raw.get("notes") or []),
        # Preserve TP contract extensions across stage/preflight normalization.
        # These are part of the immutable execution contract, not user-editable data.
        "interface_family": str(raw.get("interface_family") or raw.get("interfaceFamily") or ""),
        "tp_role": str(raw.get("tp_role") or raw.get("tpRole") or ""),
        "interface_reference": str(raw.get("interface_reference") or raw.get("interfaceReference") or ""),
        "interface_display": str(raw.get("interface_display") or raw.get("interfaceDisplay") or ""),
        "supported_for_live": bool(raw.get("supported_for_live", raw.get("supportedForLive", False))),
        "canonical_leaf_count": len(paths),
        "paths": paths,
    }
    result["contract_sha256"] = _digest(result)
    return result


def validate_catalog(contracts: List[Mapping[str, Any]]) -> Dict[str, Any]:
    errors: List[str] = []
    warnings: List[str] = []
    keys = [str(c.get("key")) for c in contracts]
    if len(keys) != len(set(keys)): errors.append("Catalog contains duplicate API keys")
    keyset = set(keys)
    for c in contracts:
        key = str(c.get("key"))
        for dep in c.get("depends_on") or []:
            if dep not in keyset: errors.append(f"{key}: unknown dependency {dep}")
        if c.get("lifecycle_status") != "APPROVED": warnings.append(f"{key}: lifecycle is {c.get('lifecycle_status')}")
        if c.get("allow_live") and not c.get("url"): errors.append(f"{key}: allow_live=true but URL is empty")
        if c.get("allow_live") and not c.get("identity_paths"): warnings.append(f"{key}: LIVE-enabled contract has no identity_paths")
        if str(c.get("method")) == "POST" and c.get("retry_policy", {}).get("enabled") and not c.get("idempotency_header"):
            warnings.append(f"{key}: POST retries will be suppressed because no idempotency_header is configured")
    # dependency cycle detection
    graph = {str(c.get("key")): list(c.get("depends_on") or []) for c in contracts}
    visiting: set[str] = set(); visited: set[str] = set()
    def dfs(node: str) -> None:
        if node in visiting:
            errors.append(f"Dependency cycle detected at {node}"); return
        if node in visited: return
        visiting.add(node)
        for dep in graph.get(node, []): dfs(dep)
        visiting.discard(node); visited.add(node)
    for key in graph: dfs(key)
    return {"valid": not errors, "errors": errors, "warnings": warnings, "count": len(contracts)}


def load_catalog(path: Path = CATALOG_PATH) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    raw = json.loads(path.read_text(encoding="utf-8"))
    rows = raw.get("apis") if isinstance(raw, dict) else raw
    if not isinstance(rows, list): raise ValueError("API catalog must be a JSON list or {\"apis\": [...]} object")
    contracts = [normalize_contract(row) for row in rows if isinstance(row, dict)]
    validation = validate_catalog(contracts)
    if validation["errors"]: raise ValueError("; ".join(validation["errors"][:10]))
    return contracts


def catalog_public(contracts: Iterable[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for c in contracts:
        out.append({
            "key": c["key"], "name": c["name"], "group": c["group"], "description": c.get("description", ""),
            "version": c.get("version"), "owner": c.get("owner"), "lifecycleStatus": c.get("lifecycle_status"),
            "tags": c.get("tags", []), "contractSha256": c.get("contract_sha256"),
            "method": c["method"], "url": c["url"], "requestKind": c["request_kind"],
            "requiredPaths": c["required_paths"], "identityPaths": c["identity_paths"], "sensitivePaths": c.get("sensitive_paths", []),
            "fieldRules": c.get("field_rules", {}), "canonicalLeafCount": c["canonical_leaf_count"], "allowLive": c["allow_live"],
            "duplicatePolicy": c.get("duplicate_policy", "warn"), "idempotencyHeader": c.get("idempotency_header", ""),
            "retryPolicy": c.get("retry_policy", {}), "preflightChecks": c.get("preflight_checks", []), "dependsOn": c.get("depends_on", []),
            "canonicalRequest": c["canonical_request"], "notes": c.get("notes", []),
        })
    return out


def parse_imported_catalog(data: bytes) -> List[Dict[str, Any]]:
    raw = json.loads(data.decode("utf-8-sig"))
    rows = raw.get("apis") if isinstance(raw, dict) else raw
    if not isinstance(rows, list) or not rows: raise ValueError("Imported catalog must contain at least one API contract")
    contracts = [normalize_contract(row) for row in rows if isinstance(row, dict)]
    if not contracts: raise ValueError("No valid API contracts found")
    validation = validate_catalog(contracts)
    if validation["errors"]: raise ValueError("; ".join(validation["errors"][:10]))
    return contracts

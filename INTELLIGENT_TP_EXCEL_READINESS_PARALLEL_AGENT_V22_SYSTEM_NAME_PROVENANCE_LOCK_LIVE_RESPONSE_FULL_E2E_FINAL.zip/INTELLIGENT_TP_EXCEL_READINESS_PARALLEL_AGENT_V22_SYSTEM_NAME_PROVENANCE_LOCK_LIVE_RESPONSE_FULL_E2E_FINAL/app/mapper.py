from __future__ import annotations

import json
import math
import os
import re
from copy import deepcopy
from difflib import SequenceMatcher
from typing import Any, Dict, List, Mapping, Sequence, Tuple

from .catalog import flatten_leaves, read_path, schema_locked, write_path
from .llm import DellAIAClient
from .governance import identity_fingerprint, profile_records, validate_field_rules
from .workbook import blank, detect_header, display, headers_and_records, norm_text, read_workbook


TOKEN_EXPANSIONS = {
    "tp": ("transport", "profile"), "rcvr": ("receiver",), "recv": ("receiver",),
    "sndr": ("sender",), "biz": ("business",), "doc": ("document",),
    "acct": ("account",), "env": ("environment",), "intf": ("interface",),
    "src": ("source",), "tgt": ("target",), "aprf": ("profile",),
}

GLOBAL_ALIASES: Dict[str, Tuple[str, ...]] = {
    "lens tp name": ("transportprofilename", "flowname"),
    "dev transport profile name": ("transportprofilename",),
    "transport profile name": ("transportprofilename",),
    "transport name": ("transportprofilename",),
    "interface type": ("interfacetype", "transportprofileinterfacetype"),
    "source interface type": ("interfacetype", "transportprofileinterfacetype"),
    "target interface type": ("interfacetype", "transportprofileinterfacetype"),
    "document type name": ("documenttypename", "name"),
    "dell biz doc": ("documenttypename", "name", "transactiontype"),
    "biz doc type": ("documenttypename", "name", "transactiontype"),
    "biz flow name": ("flowname",),
    "hip name only": ("flowname",),
    "target system": ("systemname", "name"),
    "source system": ("systemname", "name"),
    # HIP Account is an application/account identity and must not be reused as
    # FILE Existing Account Name. TP-only mapping has a stricter grouped-header
    # resolver for the actual Transport Profile account field.
    "hip account names": ("accountname",),
    "hip account name": ("accountname",),
    "account": ("accountname",),
    "need to account": ("accountname",),
    "interface environment": ("interfaceenvironment", "sourceenvironment", "targetenvironment"),
    "environment": ("hipenvironment", "environment", "sourceenvironment", "targetenvironment", "interfaceenvironment"),
    "partner identifier": ("partneridentifiervalue", "partneridentifier"),
    "duns": ("partneridentifiervalue",),
    "sftp server": ("servername", "partnerurl", "hipurl", "as2url"),
    "server": ("servername",), "server name": ("servername",),
    "server path": ("serverpath",), "directory": ("serverpath",),
    "folder": ("serverpath",), "subscription folder": ("subscriptionfolder",), "exchange name": ("exchangename",),
    "protocol": ("protocol",), "request method": ("requestmethod",),
    "ssl certificate": ("sslcertificate",), "encryption certificate": ("encryptioncertificate",),
    "signing algorithm": ("signingalgorithm",), "encryption algorithm": ("encryptionalgorithm",),
}

RECORD_HEADER_HINTS = (
    "hip account", "account name", "application tracking", "lens tp name",
    "transport profile name", "transport name", "customer", "partner",
)


def compact(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", norm_text(value))


def tokens(value: Any) -> List[str]:
    out: List[str] = []
    for token in norm_text(value).split():
        out.extend(TOKEN_EXPANSIONS.get(token, (token,)))
    return out


def path_leaf(path: str) -> str:
    parts = [p for p in str(path).split(".") if not p.isdigit()]
    return parts[-1] if parts else str(path)


def interface_family(value: Any) -> str:
    c = compact(value)
    if "sftp" in c:
        return "sftp"
    if c in {"as2", "httpsas2"} or "httpsas2" in c:
        return "https_as2"
    if "https" in c:
        return "https"
    if "rabbitmq" in c:
        return "rabbitmq"
    if c.startswith("nas"):
        return "nas"
    if c.startswith("ftp"):
        return "ftp"
    return ""


def coerce_like(value: Any, current: Any, target_path: str) -> Tuple[Any, str | None, bool]:
    if blank(value):
        return current, None, False
    # Preserve approved canonical interface labels when workbook uses a shorthand
    # from the same family (e.g. SFTP -> SFTP HAFT). Never cross interface families.
    if compact(path_leaf(target_path)) in {"interfacetype", "transportprofileinterfacetype"}:
        source_family = interface_family(value)
        current_family = interface_family(current)
        if source_family and current_family and source_family == current_family and display(value) != display(current):
            return current, None, True
    if isinstance(current, bool):
        text = compact(value)
        if text in {"true", "yes", "y", "1"}:
            return True, None, display(value) != "True"
        if text in {"false", "no", "n", "0"}:
            return False, None, display(value) != "False"
        return current, f"expected boolean-like value, got {display(value)!r}", False
    if isinstance(current, int) and not isinstance(current, bool):
        try:
            return int(float(str(value).strip())), None, not isinstance(value, int)
        except Exception:
            return current, f"expected integer-like value, got {display(value)!r}", False
    if isinstance(current, float):
        try:
            return float(str(value).strip()), None, not isinstance(value, float)
        except Exception:
            return current, f"expected numeric value, got {display(value)!r}", False
    if current is None:
        return value, None, False
    return display(value), None, display(value) != display(current)


def role_alignment(header: str, api_key: str, path: str) -> float:
    h, k, p = norm_text(header), norm_text(api_key), norm_text(path)
    bonus = 0.0
    if "source" in h:
        bonus += 0.18 if "source" in k or "sender" in p else -0.08 if "target" in k or "receiver" in p else 0
    if "target" in h or "receiver" in h:
        bonus += 0.18 if "target" in k or "receiver" in p else -0.08 if "source" in k or "sender" in p else 0
    if "sender" in h:
        bonus += 0.15 if "sender" in p or "source" in k else 0
    return bonus


def mapping_score(header: str, path: str, api_key: str, aliases: Mapping[str, Any] | None = None) -> float:
    h_tokens = set(tokens(header))
    p_tokens = set(tokens(path.replace(".", " ")))
    if not h_tokens or not p_tokens:
        return 0.0
    overlap = len(h_tokens & p_tokens) / max(1, len(h_tokens | p_tokens))
    leaf = compact(path_leaf(path))
    hc = compact(header)
    pc = compact(path)
    seq = SequenceMatcher(None, hc, leaf or pc).ratio()
    score = 0.48 * overlap + 0.30 * seq
    if hc == leaf:
        score += 0.34
    elif leaf and (leaf in hc or hc in leaf):
        score += 0.18
    if leaf and leaf in hc and len(leaf) >= 5:
        score += 0.16
    all_aliases: Dict[str, Tuple[str, ...]] = dict(GLOBAL_ALIASES)
    for source, targets in (aliases or {}).items():
        if isinstance(targets, str):
            all_aliases[norm_text(source)] = (compact(targets),)
        elif isinstance(targets, list):
            all_aliases[norm_text(source)] = tuple(compact(x) for x in targets)
    nh = norm_text(header)
    for alias, targets in all_aliases.items():
        if alias in nh or nh in alias:
            if any(t and (t in pc or t == leaf) for t in targets):
                score += 0.34
    score += role_alignment(header, api_key, path)
    return max(0.0, min(1.0, score))


def sheet_affinity(headers: Sequence[str], contracts: Sequence[Mapping[str, Any]]) -> float:
    score = 0.0
    for header in headers:
        best = 0.0
        for c in contracts:
            for path in c.get("paths") or []:
                best = max(best, mapping_score(header, str(path), str(c.get("key") or ""), c.get("header_aliases")))
        if best >= 0.55:
            score += best
    return score


def choose_sheet(workbook: Dict[str, Any], contracts: Sequence[Mapping[str, Any]], requested_sheet: str = "", header_row: int = 0):
    candidates = []
    for sheet in workbook.get("sheets") or []:
        if requested_sheet and str(sheet.get("name")) != requested_sheet:
            continue
        rows = sheet.get("rows") or []
        if not rows:
            continue
        idx = max(0, header_row - 1) if header_row else detect_header(rows)
        headers, records = headers_and_records(rows, idx)
        score = sheet_affinity(headers, contracts) * 2.5 + min(len(records), 20) * 0.05 + len(headers) * 0.02
        candidates.append({"sheet": sheet, "headerIndex": idx, "headers": headers, "records": records, "score": score})
    if not candidates:
        raise ValueError(f"Worksheet {requested_sheet!r} was not found" if requested_sheet else "No readable worksheet has data")
    candidates.sort(key=lambda x: x["score"], reverse=True)
    picked = candidates[0]
    meta = [
        {"name": str(x["sheet"].get("name") or "Sheet"), "headerRow": x["headerIndex"] + 1, "columnCount": len(x["headers"]), "dataRowCount": len(x["records"]), "score": round(x["score"], 3)}
        for x in candidates
    ]
    return picked, meta


def _masked_samples(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    samples = []
    for row in rows[:5]:
        safe = {}
        for k, v in row.items():
            text = display(v)
            kl = norm_text(k)
            if any(x in kl for x in ("password", "secret", "token", "certificate", "private key")):
                safe[k] = "<masked>"
            else:
                safe[k] = text[:100]
        samples.append(safe)
    return samples


def run_agents(headers: List[str], sample_rows: List[Dict[str, Any]], contracts: List[Dict[str, Any]], enabled: bool) -> Dict[str, Any]:
    client = DellAIAClient()
    meta: Dict[str, Any] = {"enabled": bool(enabled), "used": False, "diagnostics": client.diagnostics(), "agents": []}
    if not enabled:
        meta["note"] = "LLM disabled; deterministic mapper used"
        return meta
    if not client.available():
        meta["note"] = "Dell AIA is not configured; deterministic mapper used"
        return meta
    try:
        schema = client.complete_json(
            system=(
                "You are Excel Schema Analyst. Deterministic workbook parsing is authoritative. Identify semantic roles of headers. "
                "Interface Type is an explicit Excel-controlled input: never infer it from TP names, server/URL/port/authentication fields, delivery fields, or context. "
                "Never invent cell values, credentials, IDs, paths, API fields, account names, or certificates. Return JSON only."
            ),
            user=(
                "Headers:\n" + json.dumps(headers[:100], ensure_ascii=False) +
                "\nSample rows (secrets masked):\n" + json.dumps(_masked_samples(sample_rows), ensure_ascii=False)[:10000] +
                "\nReturn {columnRoles:[{header,role,confidence,reason}],accountColumns:[header],notes:[string]}."
            ),
            temperature=0.0,
        )
        meta["agents"].append({"name": "Excel Schema Analyst", "model": client.model, "output": schema})
        candidates = [
            {"apiKey": c["key"], "apiName": c["name"], "targetPaths": c["paths"][:120], "requiredPaths": c["required_paths"], "identityPaths": c["identity_paths"]}
            for c in contracts[:12]
        ]
        mapping = client.complete_json(
            system=(
                "You are API Contract Mapping Agent. You may map an Excel header only to an exact targetPath supplied for that exact apiKey. "
                "Never infer Interface Type. Interface contract selection is performed outside the LLM from an explicit Excel Interface Type cell. "
                "Never add, remove, rename or infer an API attribute. Never invent a cell value. Prefer no mapping to a weak mapping. Return JSON only."
            ),
            user=(
                "Headers:\n" + json.dumps(headers[:100], ensure_ascii=False) +
                "\nCanonical API leaves:\n" + json.dumps(candidates, ensure_ascii=False)[:22000] +
                "\nReturn {mappings:[{header,apiKey,targetPath,confidence,reason}],apiRanking:[{apiKey,confidence,reason}],notes:[string]}. "
                "Use only exact input header/apiKey/targetPath values; confidence is 0..1."
            ),
            temperature=0.0,
        )
        meta["agents"].append({"name": "API Contract Mapping Agent", "model": client.model, "output": mapping})
        meta["schema"] = schema
        meta["mapping"] = mapping
        meta["used"] = True
        return meta
    except Exception as exc:
        meta["note"] = f"Dell AIA unavailable: {type(exc).__name__}: {exc}; deterministic mapper used"
        return meta


def validated_llm_hints(meta: Mapping[str, Any], headers: Sequence[str], contracts: Mapping[str, Mapping[str, Any]]) -> Dict[Tuple[str, str], Dict[str, Any]]:
    out: Dict[Tuple[str, str], Dict[str, Any]] = {}
    mapping = meta.get("mapping") if isinstance(meta, Mapping) else {}
    rows = mapping.get("mappings") if isinstance(mapping, Mapping) else []
    header_lookup = {norm_text(h): h for h in headers}
    for item in rows if isinstance(rows, list) else []:
        if not isinstance(item, dict):
            continue
        header = header_lookup.get(norm_text(item.get("header")))
        key = str(item.get("apiKey") or "")
        path = str(item.get("targetPath") or "")
        try:
            conf = float(item.get("confidence") or 0)
        except Exception:
            conf = 0.0
        if header and key in contracts and path in contracts[key]["paths"] and conf >= 0.78:
            out[(key, header)] = {"path": path, "confidence": min(1.0, conf), "method": "Dell AIA", "reason": str(item.get("reason") or "LLM semantic match")[:400]}
    return out


def deterministic_column_map(headers: Sequence[str], contract: Mapping[str, Any], llm_hints: Mapping[Tuple[str, str], Mapping[str, Any]]) -> Dict[str, Dict[str, Any]]:
    key = str(contract["key"])
    proposals: List[Tuple[float, str, str, str, str]] = []
    for header in headers:
        hint = llm_hints.get((key, header))
        if hint:
            proposals.append((float(hint["confidence"]), header, str(hint["path"]), str(hint["method"]), str(hint["reason"])))
        for path in contract["paths"]:
            score = mapping_score(header, path, key, contract.get("header_aliases"))
            if score >= 0.56:
                proposals.append((score, header, path, "Deterministic semantic mapper", f"header/path semantic score {score:.2f}"))
    proposals.sort(key=lambda x: x[0], reverse=True)
    out: Dict[str, Dict[str, Any]] = {}
    used_paths: set[str] = set()
    for score, header, path, method, reason in proposals:
        if header in out or path in used_paths:
            continue
        # Avoid weak name-only mappings to generic `name` unless confidence is strong.
        if path_leaf(path) == "name" and score < 0.72:
            continue
        out[header] = {"path": path, "confidence": round(score, 3), "method": method, "reason": reason}
        used_paths.add(path)
    return out


def record_label(values: Mapping[str, Any], excel_row: int) -> Tuple[str, str]:
    for hint in RECORD_HEADER_HINTS:
        for header, value in values.items():
            if hint in norm_text(header) and not blank(value):
                return display(value), f"{header}: {display(value)}"
    first = next((display(v) for v in values.values() if not blank(v)), "")
    return first or f"Row {excel_row}", f"Workbook row {excel_row}"


def evaluate_row(record: Mapping[str, Any], contract: Mapping[str, Any], column_map: Mapping[str, Mapping[str, Any]]) -> Dict[str, Any]:
    proposed = deepcopy(contract["canonical_request"])
    # V122 migration runtime contract: source defaults to the active HIP environment;
    # target may be operator-supplied in .env. Excel can still override via a safe mapped value.
    if str(contract.get("group") or "").lower() == "migration":
        source_env = str(os.getenv("HIP_MIGRATION_SOURCE_ENVIRONMENT") or os.getenv("HIP_ENVIRONMENT") or "").strip()
        target_env = str(os.getenv("HIP_MIGRATION_TARGET_ENVIRONMENT") or "").strip()
        if source_env and read_path(proposed, "sourceEnvironment") is not None:
            write_path(proposed, "sourceEnvironment", source_env)
        if target_env and read_path(proposed, "targetEnvironment") is not None:
            write_path(proposed, "targetEnvironment", target_env)
    mappings: List[Dict[str, Any]] = []
    warnings: List[str] = []
    mapped_paths: List[str] = []
    for header, meta in column_map.items():
        source = (record.get("values") or {}).get(header)
        if blank(source):
            continue
        path = str(meta["path"])
        current = read_path(proposed, path)
        coerced, error, normalized = coerce_like(source, current, path)
        if error:
            warnings.append(f"{header} → {path}: {error}")
            continue
        write_path(proposed, path, coerced)
        mapped_paths.append(path)
        mappings.append({
            "sourceColumn": header, "sourceValue": display(source), "targetPath": path,
            "previousValue": current, "mappedValue": coerced, "confidence": meta["confidence"],
            "method": meta["method"], "reason": meta["reason"], "valueNormalized": normalized,
        })
    required = list(contract.get("required_paths") or [])
    identity = list(contract.get("identity_paths") or [])
    missing = [p for p in required if blank(read_path(proposed, p))]
    identity_from_excel = not identity or any(p in mapped_paths for p in identity)
    structure_ok = schema_locked(contract["canonical_request"], proposed)
    low_conf = [m for m in mappings if float(m["confidence"]) < 0.64]
    field_findings = validate_field_rules(proposed, contract)
    lifecycle = str(contract.get("lifecycle_status") or "APPROVED")
    if not structure_ok:
        status = "DO_NOT_TRIGGER"
        warnings.append("Schema-lock violation detected")
    elif lifecycle == "DEPRECATED":
        status = "DO_NOT_TRIGGER"
        warnings.append("API contract is DEPRECATED and cannot be recommended for new execution")
    elif not mappings:
        status = "DO_NOT_TRIGGER"
        warnings.append("No workbook values could be mapped safely into this API")
    elif missing:
        status = "NEEDS_INPUT"
    elif lifecycle != "APPROVED":
        status = "NEEDS_INPUT"
        warnings.append(f"API contract lifecycle is {lifecycle}; APPROVED is required for a final trigger recommendation")
    elif field_findings:
        status = "NEEDS_INPUT"
        warnings.extend([f["message"] for f in field_findings[:8]])
    elif not identity_from_excel:
        status = "NEEDS_INPUT"
        warnings.append("Object identity is inherited from the catalog template; map or confirm an identity value from this Excel row")
    elif low_conf:
        status = "NEEDS_INPUT"
        warnings.append("At least one mapping has low confidence and requires review")
    else:
        status = "GOOD_TO_TRIGGER"
    score = 45 + min(32, len(mappings) * 8) + (12 if identity_from_excel else 0) - len(missing) * 16 - len(low_conf) * 6 - len(field_findings) * 8
    if lifecycle != "APPROVED": score -= 12
    if not contract.get("url"):
        score -= 8
        warnings.append("API URL is not configured; mapping can be staged but LIVE execution cannot run")
    score = max(0, min(100, int(round(score))))
    values = record.get("values") or {}
    account, label = record_label(values, int(record.get("excelRow") or 0))
    mapped_headers = {m["sourceColumn"] for m in mappings}
    unmapped = [h for h, v in values.items() if not blank(v) and h not in mapped_headers]
    return {
        "excelRow": int(record.get("excelRow") or 0), "account": account, "recordLabel": label,
        "apiKey": contract["key"], "apiName": contract["name"], "group": contract["group"],
        "method": contract["method"], "url": contract["url"], "requestKind": contract["request_kind"],
        "status": status, "goodToTrigger": status == "GOOD_TO_TRIGGER", "score": score,
        "mappings": mappings, "mappedCount": len(mappings), "mappedPaths": mapped_paths,
        "requiredPaths": required, "missingRequiredPaths": missing, "identityPaths": identity,
        "identityMappedFromExcel": identity_from_excel, "identityFingerprint": identity_fingerprint(contract, proposed),
        "fieldRuleFindings": field_findings, "contractVersion": contract.get("version"),
        "contractLifecycle": lifecycle, "contractSha256": contract.get("contract_sha256"),
        "warnings": warnings, "unmappedColumns": unmapped,
        "baseRequest": deepcopy(contract["canonical_request"]), "proposedRequest": proposed,
        "structureLocked": structure_ok,
    }


def api_rank(result: Mapping[str, Any]) -> float:
    status_bonus = {"GOOD_TO_TRIGGER": 42, "NEEDS_INPUT": 12, "DO_NOT_TRIGGER": -18}.get(str(result.get("status")), 0)
    return float(result.get("score") or 0) + status_bonus + int(result.get("mappedCount") or 0) * 4 - len(result.get("missingRequiredPaths") or []) * 10


def _apply_workbook_duplicate_guard(rows: List[Dict[str, Any]]) -> None:
    identity_groups: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for r in rows:
        identity = str(r.get("identityFingerprint") or "")
        if not identity:
            r["duplicateWorkbookIdentity"] = False
            r["duplicateWorkbookRows"] = []
            continue
        identity_groups.setdefault((str(r.get("apiKey")), identity), []).append(r)
    for group in identity_groups.values():
        if len(group) > 1:
            excel_rows = [int(x.get("excelRow") or 0) for x in group]
            for r in group:
                r["duplicateWorkbookIdentity"] = True
                r["duplicateWorkbookRows"] = excel_rows
                r.setdefault("warnings", []).append(
                    f"Duplicate object identity appears in workbook rows {excel_rows}; review before staging/execution"
                )
                if r.get("status") == "GOOD_TO_TRIGGER":
                    r["status"] = "NEEDS_INPUT"
                    r["goodToTrigger"] = False
                    r["score"] = max(0, int(r.get("score") or 0) - 15)
        else:
            group[0]["duplicateWorkbookIdentity"] = False
            group[0]["duplicateWorkbookRows"] = []


def analyze_workbook(
    *, filename: str, data: bytes, contracts: Sequence[Mapping[str, Any]], selected_api: str = "AUTO",
    requested_sheet: str = "", header_row: int = 0, use_llm: bool = True,
) -> Dict[str, Any]:
    workbook = read_workbook(filename, data)
    if selected_api != "AUTO":
        active = [deepcopy(c) for c in contracts if c["key"] == selected_api]
        if not active:
            raise ValueError(f"API {selected_api!r} was not found in the catalog")
    else:
        active = [deepcopy(c) for c in contracts]
    if not active:
        raise ValueError("API catalog is empty")

    picked, sheet_meta = choose_sheet(workbook, active, requested_sheet, header_row)
    headers = picked["headers"]
    records = picked["records"]
    if not records:
        raise ValueError("The selected worksheet has a header but no populated data rows")

    llm_candidates = sorted(active, key=lambda c: sheet_affinity(headers, [c]), reverse=True)[:12]
    llm = run_agents(headers, [r["values"] for r in records[:5]], llm_candidates, use_llm)
    by_key = {c["key"]: c for c in active}
    hints = validated_llm_hints(llm, headers, by_key)
    maps = {c["key"]: deterministic_column_map(headers, c, hints) for c in active}

    results: List[Dict[str, Any]] = []
    all_api_results: List[Dict[str, Any]] = []
    for record in records:
        evaluated = [evaluate_row(record, c, maps[c["key"]]) for c in active]
        for r in evaluated:
            r["applicable"] = bool(r.get("mappedCount"))
        if selected_api == "AUTO":
            evaluated.sort(key=api_rank, reverse=True)
            # Multi-API applicability matrix: every API with at least one safe mapping is retained.
            applicable = [deepcopy(r) for r in evaluated if r.get("applicable")]
            all_api_results.extend(applicable)
            chosen = deepcopy(evaluated[0])
            chosen["apiAlternatives"] = [
                {
                    "apiKey": r["apiKey"], "apiName": r["apiName"], "status": r["status"], "score": r["score"],
                    "mappedCount": r["mappedCount"], "missingRequiredPaths": r["missingRequiredPaths"],
                }
                for r in evaluated[1:6]
            ]
            results.append(chosen)
        else:
            one = deepcopy(evaluated[0])
            all_api_results.append(deepcopy(one))
            results.append(one)

    _apply_workbook_duplicate_guard(all_api_results)

    # Reflect duplicate downgrades into the per-row primary recommendation.
    matrix_index = {
        (int(r.get("excelRow") or 0), str(r.get("apiKey"))): r for r in all_api_results
    }
    for r in results:
        updated = matrix_index.get((int(r.get("excelRow") or 0), str(r.get("apiKey"))))
        if updated:
            for key in ("status", "goodToTrigger", "score", "warnings", "duplicateWorkbookIdentity", "duplicateWorkbookRows"):
                r[key] = deepcopy(updated.get(key))

    counts = {s: sum(1 for r in results if r["status"] == s) for s in ("GOOD_TO_TRIGGER", "NEEDS_INPUT", "DO_NOT_TRIGGER")}
    action_counts = {s: sum(1 for r in all_api_results if r["status"] == s) for s in ("GOOD_TO_TRIGGER", "NEEDS_INPUT", "DO_NOT_TRIGGER")}
    mapping_summary = [
        {
            "apiKey": c["key"], "apiName": c["name"],
            "columnMappings": [
                {"sourceColumn": h, "targetPath": m["path"], "confidence": m["confidence"], "method": m["method"], "reason": m["reason"]}
                for h, m in maps[c["key"]].items()
            ],
            "canonicalLeafCount": c["canonical_leaf_count"],
        }
        for c in active
    ]
    return {
        "ok": True,
        "policy": "SCHEMA_IMMUTABLE_MULTI_API_MATRIX_HUMAN_STAGE_PREFLIGHT_BULK_LIVE",
        "file": {"name": filename, "format": workbook["format"], "size": len(data)},
        "sheet": {"name": picked["sheet"].get("name"), "headerRow": picked["headerIndex"] + 1, "headers": headers, "dataRowCount": len(records)},
        "dataProfile": profile_records(headers, records),
        "sheets": sheet_meta,
        "selectionMode": selected_api,
        "summary": {
            "rows": len(results), **counts,
            "apiActions": len(all_api_results),
            "GOOD_API_ACTIONS": action_counts["GOOD_TO_TRIGGER"],
            "NEEDS_API_ACTIONS": action_counts["NEEDS_INPUT"],
            "BLOCKED_API_ACTIONS": action_counts["DO_NOT_TRIGGER"],
        },
        "results": results,
        "allApiResults": all_api_results,
        "mappingSummary": mapping_summary,
        "llm": llm,
        "governance": {
            "agentCanEditSchema": False,
            "agentCanPersist": False,
            "humanStageRequired": True,
            "preflightRequired": True,
            "liveConfirmationRequired": True,
            "bulkLiveSupported": True,
        },
        "notes": [
            "AUTO evaluates every applicable API for each workbook row; all GOOD_TO_TRIGGER API actions can be staged/preflighted/executed in bulk.",
            "The top recommendation remains visible per Excel row, while allApiResults is the governed multi-API execution matrix.",
            "Agents can map/change values only at canonical leaf paths already present in the selected API contract.",
            "Unmapped Excel columns are deliberately retained for review instead of becoming invented API attributes.",
        ],
    }

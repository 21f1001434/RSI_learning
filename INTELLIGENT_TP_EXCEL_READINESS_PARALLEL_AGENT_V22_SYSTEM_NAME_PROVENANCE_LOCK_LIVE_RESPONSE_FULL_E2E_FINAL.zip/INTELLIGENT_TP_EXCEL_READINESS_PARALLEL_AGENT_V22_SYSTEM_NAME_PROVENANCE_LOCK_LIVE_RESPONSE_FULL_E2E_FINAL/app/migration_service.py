from __future__ import annotations

"""Governed Transport Profile migration using the exact V130 published API contract.

The V130 source of truth publishes one TP migration endpoint:
    POST /api/migration/orchestration/transport-profile

Exact top-level attributes:
    sourceEnvironment
    targetEnvironment
    transportProfileName
    transportProfileInterfaceType
    transportProfileInterfaceParameters

The parameter object reuses the already-selected immutable Source/Target TP interface
contract. No migration-only parameter names are invented and the agent cannot add,
remove, rename, or re-nest migration attributes.
"""

import os
import re
import time
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, Mapping, Sequence

import requests

from .catalog import schema_locked
from .executor import _target_bearer_value, _response_summary
from .governance import fingerprint, redact, schema_fingerprint
from .runtime_config import (
    env_bool,
    host_allowed,
    live_enabled,
    production_guard,
    request_timeout,
    request_verify,
)
from .workbook import blank
from .judge import judge_migration_preflight, judge_gate, judge_migration_run

MIGRATION_METHOD = "POST"
MIGRATION_PATH = "/api/migration/orchestration/transport-profile"
MIGRATION_TOP_LEVEL_KEYS = [
    "sourceEnvironment",
    "targetEnvironment",
    "transportProfileName",
    "transportProfileInterfaceType",
    "transportProfileInterfaceParameters",
]

_SUCCESS_STATUSES = {"SUCCESS", "SUCCEEDED", "COMPLETED", "COMPLETE", "DEPLOYED", "ACTIVE", "DONE", "FINISHED"}
_FAILURE_STATUSES = {"FAIL", "FAILED", "FAILURE", "ERROR", "ERRORED", "REJECTED", "CANCELLED", "CANCELED", "ABORTED", "TERMINATED"}
_STATUS_KEYS = {"status", "taskStatus", "operationStatus", "auditStatus", "deploymentStatus", "transportProfileStatus", "result", "state"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def migration_enabled() -> bool:
    return env_bool("HIP_TP_MIGRATION_ENABLED", False)


def migration_effectively_enabled(explicit_user_enable: bool = False) -> bool:
    """Migration may be enabled globally OR explicitly by the human for this run.

    This mirrors V130's user-controlled Migration toggle while avoiding the V15
    problem where a visible DEV→TEST choice was still blocked solely because the
    process .env flag was false.
    """
    return bool(migration_enabled() or explicit_user_enable)


def migration_post_check_enabled() -> bool:
    return env_bool("HIP_TP_MIGRATION_POST_CHECK_ENABLED", True)


def migration_poll_interval_seconds() -> float:
    try:
        return max(0.05, float(os.getenv("HIP_TP_MIGRATION_POLL_INTERVAL_SECONDS", "60") or 60))
    except Exception:
        return 60.0


def migration_poll_timeout_seconds() -> float:
    try:
        return max(1.0, float(os.getenv("HIP_TP_MIGRATION_POLL_TIMEOUT_SECONDS", "3600") or 3600))
    except Exception:
        return 3600.0


def migration_environments(source: str | None = None, target: str | None = None) -> tuple[str, str]:
    source_env = str(source or os.getenv("HIP_MIGRATION_SOURCE_ENVIRONMENT") or os.getenv("HIP_ENVIRONMENT") or "DEV").strip().upper()
    target_env = str(target or os.getenv("HIP_MIGRATION_TARGET_ENVIRONMENT") or "").strip().upper()
    return source_env, target_env


def migration_url() -> str:
    base = str(os.getenv("HIP_CONFIG_SERVICE_BASE_URL") or "https://apigtwtst.us.dell.com/hip-config-service").rstrip("/")
    return base + MIGRATION_PATH


def _tp_parts(create_payload: Mapping[str, Any]) -> tuple[str, str, Dict[str, Any]]:
    details = list(create_payload.get("transportProfileDetails") or [])
    detail = details[0] if details and isinstance(details[0], Mapping) else {}
    interfaces = list(detail.get("interfaceDetails") or []) if isinstance(detail, Mapping) else []
    iface = interfaces[0] if interfaces and isinstance(interfaces[0], Mapping) else {}
    name = str(detail.get("transportProfileName") or "").strip()
    interface_type = str(iface.get("interfaceType") or "").strip()
    params = deepcopy(iface.get("parameters") or {}) if isinstance(iface.get("parameters"), Mapping) else {}
    return name, interface_type, params


def build_migration_payload(create_payload: Mapping[str, Any], *, source_environment: str = "", target_environment: str = "") -> Dict[str, Any]:
    source_env, target_env = migration_environments(source_environment, target_environment)
    name, interface_type, params = _tp_parts(create_payload)
    return {
        "sourceEnvironment": source_env,
        "targetEnvironment": target_env,
        "transportProfileName": name,
        "transportProfileInterfaceType": interface_type,
        "transportProfileInterfaceParameters": params,
    }


def canonical_migration_request(create_payload: Mapping[str, Any]) -> Dict[str, Any]:
    """Exact immutable V130 migration shape, with dynamic interface parameter keys."""
    _, _, params = _tp_parts(create_payload)
    # Values are irrelevant for the schema signature; keys/nesting/cardinality are the lock.
    return {
        "sourceEnvironment": "",
        "targetEnvironment": "",
        "transportProfileName": "",
        "transportProfileInterfaceType": "",
        "transportProfileInterfaceParameters": deepcopy(params),
    }


def validate_migration_payload(payload: Mapping[str, Any], create_payload: Mapping[str, Any], *, explicit_user_enable: bool = False) -> Dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    canonical = canonical_migration_request(create_payload)
    if list(payload.keys()) != MIGRATION_TOP_LEVEL_KEYS:
        # dict ordering isn't a contract requirement, but exact key set is.
        if set(payload.keys()) != set(MIGRATION_TOP_LEVEL_KEYS):
            errors.append("Migration attribute lock failed: top-level attributes differ from the V130 published TP migration contract")
    if not schema_locked(canonical, dict(payload)):
        errors.append("Migration attribute lock failed: keys/nesting/cardinality or interface parameter attributes changed")
    required = ["sourceEnvironment", "targetEnvironment", "transportProfileName", "transportProfileInterfaceType"]
    missing = [k for k in required if blank(payload.get(k))]
    params = payload.get("transportProfileInterfaceParameters")
    if not isinstance(params, Mapping) or not params:
        missing.append("transportProfileInterfaceParameters")
    if missing:
        errors.append("Missing Migration values: " + ", ".join(missing))
    src = str(payload.get("sourceEnvironment") or "").strip().upper()
    tgt = str(payload.get("targetEnvironment") or "").strip().upper()
    if src and tgt and src == tgt:
        errors.append("targetEnvironment must be different from sourceEnvironment")
    if not migration_effectively_enabled(explicit_user_enable):
        warnings.append("TP Migration is not enabled. Enable it explicitly in the UI for this run or set HIP_TP_MIGRATION_ENABLED=true.")
    url = migration_url()
    if not host_allowed(url):
        errors.append("Migration endpoint host is not allowlisted")
    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "missing": missing,
        "url": url,
        "method": MIGRATION_METHOD,
        "schemaLocked": schema_locked(canonical, dict(payload)),
        "schemaSha256": schema_fingerprint(dict(payload)),
        "canonicalSchemaSha256": schema_fingerprint(canonical),
        "payloadSha256": fingerprint(dict(payload)),
        "contract": {
            "method": MIGRATION_METHOD,
            "path": MIGRATION_PATH,
            "attributes": list(MIGRATION_TOP_LEVEL_KEYS),
            "source": "V130/V122 Dev-published HIP Migration contract",
        },
    }


def migration_preflight(stage: Mapping[str, Any], contract: Mapping[str, Any], *, source_environment: str = "", target_environment: str = "", migration_enabled_by_user: bool = False) -> Dict[str, Any]:
    create_payload = stage.get("payload") or {}
    payload = build_migration_payload(create_payload, source_environment=source_environment, target_environment=target_environment)
    local = validate_migration_payload(payload, create_payload, explicit_user_enable=migration_enabled_by_user)
    errors = list(local.get("errors") or [])
    warnings = list(local.get("warnings") or [])
    if str(stage.get("analysisStatus") or "") != "GOOD_TO_TRIGGER":
        errors.append("Only a Good-to-Go Transport Profile may be migrated from this application")
    # A normal TP preflight proves the exact interface contract and values are still valid.
    tp_pf = stage.get("preflight") or {}
    if not tp_pf.get("passed"):
        errors.append("Run and pass the Transport Profile preflight before Migration preflight")
    if not live_enabled():
        errors.append("HIP_LIVE_API_EXECUTION=false; Migration LIVE is blocked")
    if not migration_effectively_enabled(migration_enabled_by_user):
        errors.append("TP Migration is disabled. Explicitly enable Migration in the UI for this run or set HIP_TP_MIGRATION_ENABLED=true.")
    prod = production_guard()
    if not prod.get("passed"):
        errors.extend([str(x) for x in (prod.get("errors") or [])])
    # Validate HIP OAuth now. This is non-mutating and catches credential errors before Migration.
    oauth: Dict[str, Any]
    try:
        bearer = _target_bearer_value(contract)
        oauth = {"ok": bool(bearer), "state": "UP" if bearer else "DOWN", "message": "HIP Config OAuth token acquired" if bearer else "HIP OAuth token unavailable"}
        if not bearer:
            errors.append("HIP Config OAuth token is unavailable")
    except Exception as exc:
        oauth = {"ok": False, "state": "AUTH_FAILED", "message": f"{type(exc).__name__}: {exc}"}
        errors.append("HIP Config OAuth failed: " + str(exc))
    execution_ready = not errors
    return {
        **local,
        "passed": not errors,
        "executionReady": execution_ready,
        "errors": errors,
        "warnings": warnings,
        "checkedAt": _now(),
        "payload": redact(payload),
        "sourceEnvironment": payload.get("sourceEnvironment"),
        "targetEnvironment": payload.get("targetEnvironment"),
        "oauth": oauth,
        "migrationEnabled": migration_effectively_enabled(migration_enabled_by_user),
        "migrationEnabledByEnvironment": migration_enabled(),
        "migrationEnabledByUser": bool(migration_enabled_by_user),
        "liveEnabled": live_enabled(),
        "postMigrationCheckEnabled": migration_post_check_enabled(),
    }


def _audit_url() -> str:
    base = str(os.getenv("HIP_CONFIG_SERVICE_BASE_URL") or "https://apigtwtst.us.dell.com/hip-config-service").rstrip("/")
    return base + "/api/transport-profiles/audits"


def _normalize(value: Any) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", str(value or "").strip().upper()).strip("_")


def _audit_records(body: Any) -> list[Dict[str, Any]]:
    records: Any = body
    if isinstance(body, Mapping):
        records = body.get("data") or body.get("audits") or body.get("results") or []
    if not isinstance(records, list):
        return []
    return [dict(x) for x in records if isinstance(x, Mapping)]


def _record_name(record: Mapping[str, Any]) -> str:
    for key in ("transportProfileName", "profileName", "tpName", "name"):
        if record.get(key) not in (None, ""):
            return str(record.get(key)).strip()
    for key in ("request", "payload", "transportProfile", "details"):
        nested = record.get(key)
        if isinstance(nested, Mapping):
            found = _record_name(nested)
            if found:
                return found
    return ""


def _record_operation(record: Mapping[str, Any]) -> str:
    for key in ("operation", "operationType", "action", "transportProfileOperation"):
        if record.get(key) not in (None, ""):
            return _normalize(record.get(key))
    return ""


def _record_statuses(record: Mapping[str, Any]) -> set[str]:
    out: set[str] = set()
    def walk(node: Any) -> None:
        if isinstance(node, Mapping):
            for key, value in node.items():
                if key in _STATUS_KEYS and value not in (None, ""):
                    norm = _normalize(value)
                    if norm:
                        out.add(norm)
                if isinstance(value, (Mapping, list)):
                    walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)
    walk(record)
    return out


def fetch_migration_audit_snapshot(tp_name: str, target_environment: str, contract: Mapping[str, Any]) -> Dict[str, Any]:
    url = _audit_url()
    params = {"transportProfileName": str(tp_name or "").strip(), "hipEnvironment": str(target_environment or "").strip().upper()}
    if not params["transportProfileName"] or not params["hipEnvironment"]:
        return {"ok": False, "state": "MISSING_IDENTITY", "url": url, "params": params, "message": "TP name/target environment is missing"}
    if not host_allowed(url):
        return {"ok": False, "state": "BLOCKED", "url": url, "params": params, "message": "TP checking API host is not allowlisted"}
    try:
        bearer = _target_bearer_value(contract)
    except Exception as exc:
        return {"ok": False, "state": "AUTH_FAILED", "url": url, "params": params, "message": f"OAuth failed: {type(exc).__name__}: {exc}"}
    headers = {"Accept": "application/json", "Authorization": bearer}
    requester = str(os.getenv("HIP_REQUESTED_BY") or "").strip()
    if requester:
        headers["x-requester-id"] = requester
    started = time.perf_counter()
    try:
        response = requests.request("GET", url, headers=headers, params=params, timeout=request_timeout(), verify=request_verify())
        status = int(response.status_code)
        try:
            body: Any = response.json()
        except Exception:
            body = response.text[:20000]
        records = _audit_records(body)
        named = [r for r in records if not _record_name(r) or _record_name(r) == params["transportProfileName"]]
        latest = (named or records)[0] if (named or records) else None
        statuses = sorted(_record_statuses(latest or {}))
        operation = _record_operation(latest or {})
        ok = 200 <= status < 300
        return {
            "ok": ok,
            "state": "REACHABLE" if ok else ("AUTH_FAILED" if status in {401, 403} else "ERROR"),
            "url": url,
            "params": params,
            "statusCode": status,
            "elapsedMs": int((time.perf_counter() - started) * 1000),
            "recordsCount": len(records),
            "latestRecord": redact(latest) if latest else None,
            "latestRecordSha256": fingerprint(latest) if latest else "",
            "latestStatuses": statuses,
            "latestOperation": operation,
            "responseSummary": _response_summary(body, status),
            "response": redact(body),
            "mutating": False,
        }
    except requests.RequestException as exc:
        return {"ok": False, "state": "DOWN", "url": url, "params": params, "message": f"{type(exc).__name__}: {exc}", "mutating": False}


def verify_migrated_tp(tp_name: str, target_environment: str, contract: Mapping[str, Any], *, baseline: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    if not migration_post_check_enabled():
        return {"enabled": False, "required": False, "verified": False, "passed": True, "state": "DISABLED", "message": "HIP_TP_MIGRATION_POST_CHECK_ENABLED=false"}
    baseline_sha = str((baseline or {}).get("latestRecordSha256") or "")
    start = time.perf_counter()
    attempts: list[Dict[str, Any]] = []
    interval = migration_poll_interval_seconds()
    timeout = migration_poll_timeout_seconds()
    last: Dict[str, Any] = {}
    while True:
        snap = fetch_migration_audit_snapshot(tp_name, target_environment, contract)
        last = snap
        latest_sha = str(snap.get("latestRecordSha256") or "")
        changed = bool(latest_sha and (not baseline_sha or latest_sha != baseline_sha))
        statuses = set(str(x) for x in (snap.get("latestStatuses") or []))
        operation = str(snap.get("latestOperation") or "")
        attempts.append({
            "attempt": len(attempts) + 1, "statusCode": snap.get("statusCode"), "state": snap.get("state"),
            "changedFromBaseline": changed, "statuses": sorted(statuses), "operation": operation,
            "latestRecordSha256": latest_sha,
        })
        if snap.get("ok") and changed and statuses.intersection(_FAILURE_STATUSES):
            return {"enabled": True, "required": True, "verified": False, "passed": False, "state": "MIGRATION_AUDIT_FAILED", "message": "Dell TP checking API reported Migration failure", "attempts": attempts, "latestRecord": snap.get("latestRecord"), "latestStatuses": sorted(statuses), "latestOperation": operation, "responseSummary": snap.get("responseSummary"), "elapsedMs": int((time.perf_counter()-start)*1000)}
        if snap.get("ok") and changed and statuses.intersection(_SUCCESS_STATUSES):
            return {"enabled": True, "required": True, "verified": True, "passed": True, "state": "VERIFIED_MIGRATED", "message": "Dell TP checking API confirmed a new successful TP event in the target environment", "attempts": attempts, "latestRecord": snap.get("latestRecord"), "latestStatuses": sorted(statuses), "latestOperation": operation, "responseSummary": snap.get("responseSummary"), "elapsedMs": int((time.perf_counter()-start)*1000)}
        if snap.get("state") == "AUTH_FAILED":
            return {"enabled": True, "required": True, "verified": False, "passed": False, "state": "AUTH_FAILED", "message": snap.get("message") or "TP checking API authentication failed", "attempts": attempts, "elapsedMs": int((time.perf_counter()-start)*1000)}
        if (time.perf_counter() - start) >= timeout:
            break
        time.sleep(min(interval, max(0.0, timeout - (time.perf_counter() - start))))
    return {"enabled": True, "required": True, "verified": False, "passed": False, "state": "MIGRATION_VERIFICATION_TIMEOUT", "message": "Migration was accepted but the TP checking API did not expose a new terminal target-environment event before timeout", "attempts": attempts, "latestRecord": last.get("latestRecord"), "latestStatuses": last.get("latestStatuses") or [], "latestOperation": last.get("latestOperation"), "responseSummary": last.get("responseSummary"), "elapsedMs": int((time.perf_counter()-start)*1000)}


def execute_migration(stage: Mapping[str, Any], contract: Mapping[str, Any], *, source_environment: str, target_environment: str, confirmation: str, actor: str = "Human User", migration_enabled_by_user: bool = False) -> Dict[str, Any]:
    if str(confirmation or "").strip().upper() != "MIGRATE":
        raise ValueError("Type MIGRATE to execute the Transport Profile Migration API")
    pf = migration_preflight(stage, contract, source_environment=source_environment, target_environment=target_environment, migration_enabled_by_user=migration_enabled_by_user)
    judgement = judge_migration_preflight(stage, pf)
    gate = judge_gate(judgement)
    pf["llmJudge"] = judgement
    pf["judgeGate"] = gate
    if not gate.get("passed"):
        pf["executionReady"] = False
        pf.setdefault("errors", []).append(gate.get("message") or "LLM Judge gate blocked Migration")
    if not pf.get("executionReady"):
        raise ValueError("Migration preflight is not execution-ready: " + " | ".join(str(x) for x in (pf.get("errors") or [])))
    payload = build_migration_payload(stage.get("payload") or {}, source_environment=source_environment, target_environment=target_environment)
    # Rebuild from the exact V130 published attribute list at the HTTP boundary.
    request_payload = {key: deepcopy(payload[key]) for key in MIGRATION_TOP_LEVEL_KEYS}
    local = validate_migration_payload(request_payload, stage.get("payload") or {}, explicit_user_enable=migration_enabled_by_user)
    if not local.get("valid"):
        raise ValueError("Migration immutable contract failed immediately before HTTP: " + " | ".join(local.get("errors") or []))
    url = migration_url()
    bearer = _target_bearer_value(contract)
    headers = {"Accept": "application/json", "Content-Type": "application/json", "Authorization": bearer}
    requester = str(os.getenv("HIP_REQUESTED_BY") or "").strip()
    if requester:
        headers["x-requester-id"] = requester
    tp_name = str(request_payload.get("transportProfileName") or "")
    target_env = str(request_payload.get("targetEnvironment") or "")
    baseline = fetch_migration_audit_snapshot(tp_name, target_env, contract) if migration_post_check_enabled() else {"ok": False, "state": "DISABLED", "latestRecordSha256": ""}
    started = time.perf_counter()
    response = requests.request(MIGRATION_METHOD, url, headers=headers, json=request_payload, timeout=request_timeout(), verify=request_verify())
    elapsed = int((time.perf_counter() - started) * 1000)
    try:
        body: Any = response.json()
    except Exception:
        body = response.text[:20000]
    accepted = int(response.status_code) in {200, 201, 202, 204}
    verification = verify_migrated_tp(tp_name, target_env, contract, baseline=baseline) if accepted else {"enabled": migration_post_check_enabled(), "required": True, "verified": False, "passed": False, "state": "MIGRATION_REJECTED", "message": "Migration API rejected the request; post-check not used to claim success"}
    success = bool(accepted and (verification.get("verified") if verification.get("required") else verification.get("passed", True)))
    if success and verification.get("verified"):
        result_state = "VERIFIED_MIGRATED"
    elif success and not verification.get("required"):
        result_state = "MIGRATION_ACCEPTED_UNVERIFIED"
    elif not accepted:
        result_state = "MIGRATION_REJECTED"
    elif verification.get("state") == "MIGRATION_AUDIT_FAILED":
        result_state = "MIGRATION_ACCEPTED_AUDIT_FAILED"
    else:
        result_state = "MIGRATION_ACCEPTED_VERIFICATION_PENDING"
    response_summary = _response_summary(body, int(response.status_code))
    if accepted:
        response_summary += " | Migration check: " + str(verification.get("message") or verification.get("state") or "pending")
    run = {
        "runId": "",
        "stageId": stage.get("stageId"),
        "analysisId": stage.get("analysisId"),
        "rowId": stage.get("rowId"),
        "excelRow": stage.get("excelRow"),
        "sheetName": stage.get("sheetName"),
        "account": stage.get("account"),
        "apiKey": "migration_transport_profile",
        "apiName": "Transport Profile Migration",
        "actor": actor,
        "executedAt": _now(),
        "method": MIGRATION_METHOD,
        "url": url,
        "statusCode": int(response.status_code),
        "success": success,
        "migrationAccepted": accepted,
        "verifiedMigrated": bool(verification.get("verified")),
        "resultState": result_state,
        "sourceEnvironment": request_payload.get("sourceEnvironment"),
        "targetEnvironment": request_payload.get("targetEnvironment"),
        "responseSummary": response_summary,
        "elapsedMs": elapsed + int(verification.get("elapsedMs") or 0),
        "migrationElapsedMs": elapsed,
        "payloadSha256": fingerprint(request_payload),
        "schemaSha256": schema_fingerprint(request_payload),
        "attributeMutationBlocked": True,
        "request": {"kind": "payload", "payload": redact(request_payload)},
        "response": redact(body),
        "migrationAuditBaseline": redact(baseline),
        "postMigrationVerification": redact(verification),
        "llmJudge": {},
    }
    run["llmJudge"] = judge_migration_run(run)
    return run


def migration_runtime_summary() -> Dict[str, Any]:
    source_env, target_env = migration_environments()
    return {
        "enabled": migration_enabled(),
        "userCanEnablePerRun": True,
        "method": MIGRATION_METHOD,
        "url": migration_url(),
        "path": MIGRATION_PATH,
        "attributes": list(MIGRATION_TOP_LEVEL_KEYS),
        "sourceEnvironment": source_env,
        "targetEnvironment": target_env,
        "postCheckEnabled": migration_post_check_enabled(),
        "pollIntervalSeconds": migration_poll_interval_seconds(),
        "pollTimeoutSeconds": migration_poll_timeout_seconds(),
        "hostAllowed": host_allowed(migration_url()),
        "reference": "V130 R1 Dev-published TP Migration API",
    }

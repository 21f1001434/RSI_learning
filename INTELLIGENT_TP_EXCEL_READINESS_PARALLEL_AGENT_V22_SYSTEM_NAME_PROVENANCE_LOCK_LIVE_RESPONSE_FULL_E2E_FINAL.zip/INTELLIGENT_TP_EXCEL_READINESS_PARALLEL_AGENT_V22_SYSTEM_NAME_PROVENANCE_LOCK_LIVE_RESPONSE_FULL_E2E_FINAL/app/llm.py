from __future__ import annotations

import json
import os
import time
from typing import Any, Dict

import requests

from .runtime_config import request_timeout, request_verify


class DellAIAClient:
    """Dell AIA client using the same environment contract as the supplied V122 app.

    Primary V122 variables:
      DELL_AIA_BASE_URL, DELL_AIA_MODEL, DELL_AIA_TEMPERATURE,
      DELL_AIA_CLIENT_ID, DELL_AIA_CLIENT_SECRET, DELL_AIA_TOKEN_URL,
      DELL_AIA_SCOPE, DELL_AUTH_MODE, USE_DELL_SSO.

    AIA_* aliases remain accepted only for backward compatibility with V1/V2 of
    this standalone app; the shipped .env.example is V122-compatible.
    """

    def __init__(self) -> None:
        self.base_url = (
            os.getenv("DELL_AIA_BASE_URL")
            or os.getenv("AIA_BASE_URL")
            or "https://aia.gateway.dell.com/genai/dev/v1"
        ).rstrip("/")
        self.model = os.getenv("DELL_AIA_MODEL") or os.getenv("AIA_MODEL") or "gpt-oss-120b"
        self.temperature = float(os.getenv("DELL_AIA_TEMPERATURE", "0.2") or 0.2)
        self.chat_path = os.getenv("AIA_CHAT_PATH", "/chat/completions")
        if not self.chat_path.startswith("/"):
            self.chat_path = "/" + self.chat_path
        self.client_id = os.getenv("DELL_AIA_CLIENT_ID") or os.getenv("AIA_CLIENT_ID") or ""
        self.client_secret = os.getenv("DELL_AIA_CLIENT_SECRET") or os.getenv("AIA_CLIENT_SECRET") or ""
        self.token_url = os.getenv("DELL_AIA_TOKEN_URL") or os.getenv("AIA_TOKEN_URL") or ""
        self.scope = os.getenv("DELL_AIA_SCOPE") or os.getenv("AIA_SCOPE") or ""
        self.static_token = (
            os.getenv("DELL_AIA_TOKEN")
            or os.getenv("AIA_STATIC_BEARER_TOKEN")
            or os.getenv("AIA_BEARER_TOKEN")
            or ""
        ).strip()
        if self.static_token.lower().startswith("bearer "):
            self.static_token = self.static_token[7:].strip()
        self.timeout = request_timeout()
        self.verify_tls = request_verify()
        self.use_dell_sso = str(os.getenv("USE_DELL_SSO", "true")).lower() in {"1", "true", "yes", "y"}
        self.auth_mode = os.getenv("DELL_AUTH_MODE", "auto")
        try:
            self.extra_headers = json.loads(os.getenv("AIA_EXTRA_HEADERS_JSON", "{}"))
        except Exception:
            self.extra_headers = {}
        self._token_cache: tuple[str, float] | None = None

    def available(self) -> bool:
        return bool(self.base_url and (self.static_token or (self.client_id and self.client_secret)))

    def diagnostics(self) -> Dict[str, Any]:
        if self.static_token:
            auth = "static bearer"
        elif self.client_id and self.client_secret and self.token_url:
            auth = "OAuth client_credentials"
        elif self.client_id and self.client_secret:
            auth = "Dell aia_auth client_credentials"
        else:
            auth = "not configured"
        return {
            "provider": "Dell AIA",
            "baseUrl": self.base_url,
            "model": self.model,
            "available": self.available(),
            "auth": auth,
            "authMode": self.auth_mode,
            "useDellSso": self.use_dell_sso,
            "envCompatibility": "V122",
        }

    def _oauth_token(self) -> str:
        data: Dict[str, str] = {"grant_type": "client_credentials"}
        if self.scope:
            data["scope"] = self.scope
        headers = {"Accept": "application/json"}
        response = requests.post(
            self.token_url,
            data=data,
            auth=(self.client_id, self.client_secret),
            headers=headers,
            timeout=self.timeout,
            verify=self.verify_tls,
        )
        if response.status_code in {400, 401, 403}:
            response = requests.post(
                self.token_url,
                data={**data, "client_id": self.client_id, "client_secret": self.client_secret},
                headers=headers,
                timeout=self.timeout,
                verify=self.verify_tls,
            )
        response.raise_for_status()
        payload = response.json()
        token = payload.get("access_token") or payload.get("accessToken") or payload.get("token") or payload.get("bearerToken")
        if not token:
            raise RuntimeError("Dell AIA token response did not contain an access token")
        self._token_cache = (str(token), time.time() + float(payload.get("expires_in", 1800)))
        return str(token)

    def _internal_token(self) -> str:
        try:
            from aia_auth import auth  # type: ignore
        except Exception as exc:
            raise RuntimeError(
                "DELL_AIA_CLIENT_ID/DELL_AIA_CLIENT_SECRET are configured but Dell aia_auth is unavailable. "
                "Install/configure aia_auth or configure DELL_AIA_TOKEN_URL."
            ) from exc
        result = auth.client_credentials(self.client_id, self.client_secret)
        token = (
            getattr(result, "token", "")
            or getattr(result, "access_token", "")
            or (result.get("token") if isinstance(result, dict) else "")
            or (result.get("access_token") if isinstance(result, dict) else "")
        )
        if not token:
            raise RuntimeError("Dell aia_auth returned no token/access_token")
        self._token_cache = (str(token), time.time() + 1800)
        return str(token)

    def _get_token(self) -> str:
        if self.static_token:
            return self.static_token
        if self._token_cache and self._token_cache[1] > time.time() + 60:
            return self._token_cache[0]
        if self.token_url:
            return self._oauth_token()
        if self.client_id and self.client_secret:
            return self._internal_token()
        raise RuntimeError("Dell AIA credentials are not configured")

    def complete_json(self, *, system: str, user: str, temperature: float | None = None) -> Dict[str, Any]:
        if not self.available():
            raise RuntimeError("Dell AIA is not configured")
        payload = {
            "model": self.model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "temperature": self.temperature if temperature is None else float(temperature),
            "response_format": {"type": "json_object"},
        }
        response = requests.post(
            self.base_url + self.chat_path,
            headers={"Authorization": f"Bearer {self._get_token()}", "Content-Type": "application/json", "Accept": "application/json", **self.extra_headers},
            json=payload,
            timeout=self.timeout,
            verify=self.verify_tls,
        )
        response.raise_for_status()
        body = response.json()
        content = body.get("choices", [{}])[0].get("message", {}).get("content", "{}")
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            raise RuntimeError("Dell AIA response JSON must be an object")
        return parsed

    def test(self) -> Dict[str, Any]:
        try:
            response = self.complete_json(system="Return JSON only.", user='Return exactly {"status":"ok","provider":"Dell AIA"}.', temperature=0.0)
            return {"ok": str(response.get("status", "")).lower() == "ok", "diagnostics": self.diagnostics(), "response": response}
        except Exception as exc:
            return {"ok": False, "diagnostics": self.diagnostics(), "error": f"{type(exc).__name__}: {exc}"}

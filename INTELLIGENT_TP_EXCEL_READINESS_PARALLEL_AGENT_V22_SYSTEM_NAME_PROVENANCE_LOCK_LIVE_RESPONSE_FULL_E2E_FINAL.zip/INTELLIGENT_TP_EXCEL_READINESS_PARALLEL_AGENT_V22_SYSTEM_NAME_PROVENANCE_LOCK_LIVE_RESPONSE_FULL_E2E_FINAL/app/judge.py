from __future__ import annotations

import json
import os
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, Mapping

from .governance import redact
from .llm import DellAIAClient

_LEVEL = {"PASS": 0, "REVIEW": 1, "BLOCK": 2, "UNAVAILABLE": 1}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _bool_env(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in {"1", "true", "yes", "y", "on"}


def judge_enabled() -> bool:
    return _bool_env("LLM_JUDGE_ENABLED", True)


def judge_required_for_live() -> bool:
    return _bool_env("LLM_JUDGE_REQUIRED_FOR_LIVE", False)


def judge_fail_closed() -> bool:
    return _bool_env("LLM_JUDGE_FAIL_CLOSED", judge_required_for_live())


def judge_temperature() -> float:
    try:
        return float(os.getenv("LLM_JUDGE_TEMPERATURE", "0") or 0)
    except Exception:
        return 0.0


def _client() -> DellAIAClient:
    client = DellAIAClient()
    judge_model = str(os.getenv("LLM_JUDGE_MODEL") or "").strip()
    if judge_model:
        client.model = judge_model
    return client


def judge_diagnostics() -> Dict[str, Any]:
    client = _client()
    d = client.diagnostics()
    return {
        "enabled": judge_enabled(),
        "requiredForLive": judge_required_for_live(),
        "failClosed": judge_fail_closed(),
        "provider": d.get("provider", "Dell AIA"),
        "model": d.get("model", "gpt-oss-120b"),
        "available": bool(d.get("available")),
        "temperature": judge_temperature(),
        "policy": "LLM evaluates redacted evidence only; deterministic validation always wins; Judge cannot mutate payloads or execute APIs",
    }


def _norm_verdict(value: Any) -> str:
    v = str(value or "").strip().upper().replace("-", "_").replace(" ", "_")
    if v in {"PASS", "APPROVE", "APPROVED", "OK", "SAFE", "READY"}:
        return "PASS"
    if v in {"BLOCK", "FAIL", "FAILED", "REJECT", "REJECTED", "UNSAFE", "NOT_READY"}:
        return "BLOCK"
    return "REVIEW"


def _deterministic_action_verdict(action: Mapping[str, Any]) -> str:
    status = str(action.get("status") or "").upper()
    if status == "DO_NOT_TRIGGER":
        return "BLOCK"
    if status == "NEEDS_INPUT":
        return "REVIEW"
    if status == "GOOD_TO_TRIGGER":
        return "PASS"
    return "REVIEW"


def _deterministic_preflight_verdict(preflight: Mapping[str, Any]) -> str:
    if not bool(preflight.get("passed")):
        return "BLOCK"
    # executionReady can be false because LIVE flags/host gates are disabled; this
    # is still a review condition rather than evidence that the TP mapping is bad.
    if not bool(preflight.get("executionReady")):
        return "REVIEW"
    return "PASS"


def _deterministic_create_verdict(run: Mapping[str, Any]) -> str:
    outcome = str(run.get("outcomeClassification") or "").upper()
    if outcome in {"SUCCESS", "EXISTING"} and bool(run.get("success")):
        return "PASS"
    if outcome == "FAILED":
        return "BLOCK"
    if outcome == "PENDING":
        return "REVIEW"
    if bool(run.get("success")) and (bool(run.get("verifiedCreated")) or bool(run.get("verifiedExisting"))):
        return "PASS"
    if bool(run.get("createAccepted")) or bool(run.get("existing")):
        return "REVIEW"
    return "BLOCK"


def _deterministic_migration_verdict(obj: Mapping[str, Any]) -> str:
    if "executionReady" in obj or "passed" in obj:
        if not bool(obj.get("passed")):
            return "BLOCK"
        return "PASS" if bool(obj.get("executionReady")) else "REVIEW"
    if bool(obj.get("success")) and bool(obj.get("verifiedMigrated", obj.get("postMigrationVerification", {}).get("verified"))):
        return "PASS"
    if bool(obj.get("migrationAccepted")):
        return "REVIEW"
    return "BLOCK"


def _max_severity(a: str, b: str) -> str:
    a = _norm_verdict(a)
    b = _norm_verdict(b)
    return a if _LEVEL.get(a, 1) >= _LEVEL.get(b, 1) else b


def _prompt(kind: str) -> str:
    return (
        "You are the independent LLM-as-Judge for an enterprise Dell HIP Transport Profile automation. "
        "You are NOT the mapping agent. You may not propose new API attributes, mutate payload structure, choose a different interface contract, "
        "or authorize an API call. Evaluate only the supplied redacted evidence. Deterministic validation is authoritative. "
        "Return JSON with keys verdict (PASS|REVIEW|BLOCK), score (0-100), confidence (0-1), reasons (array), concerns (array). "
        f"Judge stage: {kind}. PASS only when the evidence is internally consistent for that stage. "
        "BLOCK only for a concrete contradiction or unsafe/missing evidence; otherwise REVIEW. Never invent missing facts."
    )


def _compact(value: Any, *, max_chars: int = 26000) -> Any:
    safe = redact(deepcopy(value))
    raw = json.dumps(safe, ensure_ascii=False, default=str)
    if len(raw) <= max_chars:
        return safe
    # Preserve validity and tell the judge the evidence was truncated.
    return {"truncated": True, "preview": raw[:max_chars]}


def _judge(kind: str, evidence: Mapping[str, Any], deterministic: str) -> Dict[str, Any]:
    deterministic = _norm_verdict(deterministic)
    base = {
        "kind": kind,
        "enabled": judge_enabled(),
        "requiredForLive": judge_required_for_live(),
        "deterministicVerdict": deterministic,
        "verdict": deterministic,
        "score": 100 if deterministic == "PASS" else (55 if deterministic == "REVIEW" else 0),
        "confidence": 1.0,
        "reasons": ["Deterministic application validation is authoritative."],
        "concerns": [],
        "llmUsed": False,
        "model": _client().model,
        "generatedAt": _now(),
        "canMutatePayload": False,
        "canExecuteApi": False,
    }
    if not judge_enabled():
        base["state"] = "DISABLED"
        base["reasons"].append("LLM Judge is disabled; deterministic verdict used.")
        return base

    client = _client()
    if not client.available():
        base["state"] = "UNAVAILABLE"
        base["confidence"] = 0.7
        base["concerns"].append("Dell AIA Judge credentials are not configured; deterministic fallback used.")
        if (judge_required_for_live() or judge_fail_closed()) and deterministic == "PASS":
            base["verdict"] = "REVIEW"
        return base

    try:
        llm = client.complete_json(
            system=_prompt(kind),
            user=json.dumps({"stage": kind, "deterministicVerdict": deterministic, "evidence": _compact(evidence)}, ensure_ascii=False, default=str),
            temperature=judge_temperature(),
        )
        lv = _norm_verdict(llm.get("verdict"))
        # The LLM may only be equally or more conservative than deterministic rules.
        final = _max_severity(deterministic, lv)
        try:
            score = max(0, min(100, int(float(llm.get("score", base["score"])))))
        except Exception:
            score = int(base["score"])
        try:
            confidence = max(0.0, min(1.0, float(llm.get("confidence", 0.7))))
        except Exception:
            confidence = 0.7
        reasons = llm.get("reasons") if isinstance(llm.get("reasons"), list) else []
        concerns = llm.get("concerns") if isinstance(llm.get("concerns"), list) else []
        base.update({
            "state": "COMPLETED",
            "verdict": final,
            "llmVerdict": lv,
            "score": score,
            "confidence": confidence,
            "reasons": [str(x)[:600] for x in reasons[:8]] or base["reasons"],
            "concerns": [str(x)[:600] for x in concerns[:8]],
            "llmUsed": True,
            "raw": {k: llm.get(k) for k in ("verdict", "score", "confidence")},
        })
    except Exception as exc:
        base["state"] = "ERROR"
        base["confidence"] = 0.6
        base["concerns"].append(f"LLM Judge unavailable: {type(exc).__name__}: {exc}")
        if (judge_required_for_live() or judge_fail_closed()) and deterministic == "PASS":
            base["verdict"] = "REVIEW"
    return base


def judge_action(action: Mapping[str, Any]) -> Dict[str, Any]:
    evidence = {
        "status": action.get("status"),
        "score": action.get("score"),
        "tpRole": action.get("tpRole"),
        "tpName": action.get("tpName"),
        "systemName": action.get("systemName"),
        "excelInterface": action.get("interfaceRawValue"),
        "apiInterface": action.get("interfaceType"),
        "interfaceSourceColumn": action.get("interfaceSourceColumn"),
        "missingRequiredPaths": action.get("missingRequiredPaths"),
        "blankOptionalPaths": action.get("blankOptionalPaths"),
        "blockers": action.get("blockers"),
        "warnings": action.get("warnings"),
        "readinessChecks": action.get("readinessChecks"),
        "mappings": action.get("mappings"),
        "fieldMatrix": action.get("fieldMatrix"),
        "interfaceSuggestion": action.get("interfaceSuggestion"),
        "payload": action.get("proposedRequest"),
    }
    return _judge("MAPPING_READINESS", evidence, _deterministic_action_verdict(action))


def judge_preflight(stage: Mapping[str, Any], preflight: Mapping[str, Any]) -> Dict[str, Any]:
    evidence = {
        "analysisStatus": stage.get("analysisStatus"),
        "analysisScore": stage.get("analysisScore"),
        "attributeMutationBlocked": stage.get("attributeMutationBlocked"),
        "schemaSha256": stage.get("schemaSha256"),
        "contractSha256": stage.get("contractSha256"),
        "preflight": preflight,
        "payload": stage.get("payload"),
    }
    return _judge("PRE_LIVE", evidence, _deterministic_preflight_verdict(preflight))


def judge_create_run(run: Mapping[str, Any]) -> Dict[str, Any]:
    evidence = {
        "resultState": run.get("resultState"),
        "outcomeClassification": run.get("outcomeClassification"),
        "responseClassification": run.get("responseClassification"),
        "responseAgent": run.get("responseAgent"),
        "statusCode": run.get("statusCode"),
        "createAccepted": run.get("createAccepted"),
        "verifiedCreated": run.get("verifiedCreated"),
        "verifiedExisting": run.get("verifiedExisting"),
        "existing": run.get("existing"),
        "createSkipped": run.get("createSkipped"),
        "responseSummary": run.get("responseSummary"),
        "postCreateVerification": run.get("postCreateVerification"),
        "request": run.get("request"),
    }
    return _judge("POST_CREATE_VERIFICATION", evidence, _deterministic_create_verdict(run))


def judge_migration_preflight(stage: Mapping[str, Any], preflight: Mapping[str, Any]) -> Dict[str, Any]:
    evidence = {
        "tpName": ((stage.get("payload") or {}).get("transportProfileDetails") or [{}])[0].get("transportProfileName") if isinstance(stage.get("payload"), Mapping) else "",
        "preflight": preflight,
        "migrationPayload": preflight.get("payload"),
    }
    return _judge("PRE_MIGRATION", evidence, _deterministic_migration_verdict(preflight))


def judge_migration_run(run: Mapping[str, Any]) -> Dict[str, Any]:
    evidence = {
        "resultState": run.get("resultState"),
        "statusCode": run.get("statusCode"),
        "migrationAccepted": run.get("migrationAccepted"),
        "verifiedMigrated": run.get("verifiedMigrated"),
        "responseSummary": run.get("responseSummary"),
        "postMigrationVerification": run.get("postMigrationVerification"),
        "request": run.get("request"),
    }
    return _judge("POST_MIGRATION_VERIFICATION", evidence, _deterministic_migration_verdict(run))


def judge_gate(judgement: Mapping[str, Any]) -> Dict[str, Any]:
    required = judge_required_for_live()
    verdict = _norm_verdict(judgement.get("verdict"))
    passed = (not required) or verdict == "PASS"
    return {
        "required": required,
        "passed": passed,
        "verdict": verdict,
        "message": "LLM Judge PASS" if passed else f"LLM Judge gate requires PASS; current verdict is {verdict}",
    }


def test_judge() -> Dict[str, Any]:
    sample = {
        "status": "GOOD_TO_TRIGGER",
        "score": 100,
        "tpName": "SFTP_U-HAUL_ASN_PC_SRC_IB",
        "tpRole": "SOURCE / SENDER",
        "interfaceRawValue": "SFTP HAFT",
        "interfaceType": "SFTP HAFT",
        "missingRequiredPaths": [],
        "blockers": [],
        "warnings": [],
        "readinessChecks": [{"name": "Interface recognized", "status": "PASS", "blocking": False}],
        "proposedRequest": {"systemName": "AIC - DCE", "transportProfileDetails": [{"transportProfileName": "SFTP_U-HAUL_ASN_PC_SRC_IB", "interfaceDetails": [{"interfaceType": "SFTP HAFT", "parameters": {"Subscription Folder": "/SFTP_U-HAUL_ASN_PC_SRC_IB", "Existing Account Name": "haftatap10251594"}}]}]},
    }
    out = judge_action(sample)
    diag = judge_diagnostics()
    ok = out.get("state") == "COMPLETED" or (out.get("state") == "DISABLED" and not diag.get("requiredForLive"))
    return {"ok": bool(ok), "diagnostics": diag, "judge": out}

from __future__ import annotations

import hashlib
import json
import threading
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
STAGES_DIR = DATA / "stages"
RUNS_DIR = DATA / "runs"
AUDIT_PATH = DATA / "audit.jsonl"
STAGES_DIR.mkdir(parents=True, exist_ok=True)
RUNS_DIR.mkdir(parents=True, exist_ok=True)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class AppState:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.analyses: Dict[str, Dict[str, Any]] = {}
        self.session_catalog = None

    def audit(self, action: str, actor: str = "system", *, stage_id: str = "", run_id: str = "", details: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
        with self.lock:
            previous = ""
            if AUDIT_PATH.exists():
                try:
                    last = AUDIT_PATH.read_text(encoding="utf-8").splitlines()[-1]
                    previous = str(json.loads(last).get("eventSha256") or "")
                except Exception:
                    previous = ""
            event = {
                "timestamp": now_iso(), "action": action, "actor": actor,
                "stageId": stage_id, "runId": run_id, "details": dict(details or {}), "previousSha256": previous,
            }
            event["eventSha256"] = _sha(event)
            with AUDIT_PATH.open("a", encoding="utf-8") as f:
                f.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")
            return event

    def add_analysis(self, result: Dict[str, Any]) -> str:
        analysis_id = "ana_" + uuid.uuid4().hex[:16]
        value = deepcopy(result); value["analysisId"] = analysis_id
        for index, row in enumerate(value.get("results") or []):
            row["rowId"] = f"row_{index}_{row.get('excelRow', index)}"
        for index, row in enumerate(value.get("allApiResults") or []):
            row["actionId"] = f"act_{index}_{row.get('excelRow', index)}_{row.get('apiKey', 'api')}"
        for index, row in enumerate(value.get("tpActions") or []):
            row["actionId"] = f"tpact_{index}_{row.get('excelRow', index)}_{row.get('apiKey', 'tp')}"
        with self.lock: self.analyses[analysis_id] = value
        self.audit("ANALYSIS_CREATED", details={"analysisId": analysis_id, "rows": len(value.get("results") or [])})
        return analysis_id

    def get_analysis(self, analysis_id: str) -> Dict[str, Any]:
        with self.lock:
            if analysis_id not in self.analyses: raise KeyError(analysis_id)
            return deepcopy(self.analyses[analysis_id])

    def update_analysis_action(self, analysis_id: str, action_id: str, replacement: Mapping[str, Any]) -> Dict[str, Any]:
        """Replace one analyzed action across all mirrored analysis buckets.

        TP analyses expose the same logical action under ``tpActions``,
        ``allApiResults`` and ``results`` with bucket-specific ids.  Human value /
        ownership edits must update every mirror so later batch staging cannot use
        stale pre-edit evidence.
        """
        with self.lock:
            if analysis_id not in self.analyses:
                raise KeyError(analysis_id)
            analysis = self.analyses[analysis_id]
            source = None
            for bucket in ("allApiResults", "tpActions", "results"):
                for row in (analysis.get(bucket) or []):
                    if str(row.get("actionId") or row.get("rowId") or "") == str(action_id):
                        source = row
                        break
                if source is not None:
                    break
            if source is None:
                raise KeyError(action_id)

            match = (
                str(source.get("sheetName") or ""),
                int(source.get("excelRow") or 0),
                str(source.get("apiKey") or ""),
                str(source.get("tpRoleKey") or ""),
            )
            returned = None
            for bucket in ("allApiResults", "tpActions", "results"):
                rows = analysis.get(bucket) or []
                for i, row in enumerate(rows):
                    marker = (
                        str(row.get("sheetName") or ""),
                        int(row.get("excelRow") or 0),
                        str(row.get("apiKey") or ""),
                        str(row.get("tpRoleKey") or ""),
                    )
                    if marker != match:
                        continue
                    value = deepcopy(dict(replacement))
                    # Keep bucket-local ids so existing UI references remain valid.
                    if row.get("actionId"):
                        value["actionId"] = row.get("actionId")
                    if row.get("rowId"):
                        value["rowId"] = row.get("rowId")
                    rows[i] = value
                    if bucket == "allApiResults":
                        returned = deepcopy(value)

            primary = analysis.get("allApiResults") or analysis.get("tpActions") or analysis.get("results") or []
            if isinstance(analysis.get("summary"), dict):
                analysis["summary"]["GOOD_TO_TRIGGER"] = sum(1 for r in primary if r.get("status") == "GOOD_TO_TRIGGER")
                analysis["summary"]["NEEDS_INPUT"] = sum(1 for r in primary if r.get("status") == "NEEDS_INPUT")
                analysis["summary"]["DO_NOT_TRIGGER"] = sum(1 for r in primary if r.get("status") == "DO_NOT_TRIGGER")
                analysis["summary"]["GOOD_API_ACTIONS"] = analysis["summary"]["GOOD_TO_TRIGGER"]
            self.analyses[analysis_id] = analysis
            result = returned or deepcopy(dict(replacement))
        self.audit("ANALYSIS_ACTION_UPDATED", actor="Human User", details={"analysisId": analysis_id, "actionId": action_id})
        return result

    def stages_for_action(self, analysis_id: str, row: Mapping[str, Any]) -> List[Dict[str, Any]]:
        """Return immutable stage snapshots created for the same analyzed TP action."""
        matches: List[Dict[str, Any]] = []
        sheet = str(row.get("sheetName") or "")
        excel_row = int(row.get("excelRow") or 0)
        api_key = str(row.get("apiKey") or "")
        row_ids = {str(row.get("rowId") or ""), str(row.get("actionId") or "")} - {""}
        for path in STAGES_DIR.glob("stg_*.json"):
            try:
                stage = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if str(stage.get("analysisId") or "") != str(analysis_id):
                continue
            same_marker = (
                str(stage.get("sheetName") or "") == sheet
                and int(stage.get("excelRow") or 0) == excel_row
                and str(stage.get("apiKey") or "") == api_key
            )
            same_id = str(stage.get("rowId") or "") in row_ids if row_ids else False
            if same_marker or same_id:
                matches.append(stage)
        return matches

    def stage(self, record: Dict[str, Any]) -> Dict[str, Any]:
        stage_id = "stg_" + uuid.uuid4().hex[:16]
        value = deepcopy(record)
        value.update({
            "stageId": stage_id, "createdAt": now_iso(), "preflight": None, "executed": False,
            "approvalStatus": "PENDING", "approvals": [], "rejections": [],
        })
        path = STAGES_DIR / f"{stage_id}.json"
        path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        self.audit("STAGE_CREATED", actor=str(value.get("reviewer") or "Human User"), stage_id=stage_id,
                   details={"analysisId": value.get("analysisId"), "rowId": value.get("rowId"), "apiKey": value.get("apiKey")})
        return value

    def get_stage(self, stage_id: str) -> Dict[str, Any]:
        path = STAGES_DIR / f"{stage_id}.json"
        if not path.exists(): raise KeyError(stage_id)
        return json.loads(path.read_text(encoding="utf-8"))

    def save_stage(self, stage: Mapping[str, Any]) -> None:
        stage_id = str(stage.get("stageId") or "")
        if not stage_id: raise ValueError("stageId missing")
        (STAGES_DIR / f"{stage_id}.json").write_text(json.dumps(dict(stage), ensure_ascii=False, indent=2, default=str), encoding="utf-8")

    def approve_stage(self, stage_id: str, approver: str, comment: str = "", four_eyes: bool = False) -> Dict[str, Any]:
        stage = self.get_stage(stage_id)
        reviewer = str(stage.get("reviewer") or "").strip().lower()
        if four_eyes and reviewer and reviewer == approver.strip().lower():
            raise ValueError("Four-eyes approval requires a different approver from the staging reviewer")
        approval = {"approver": approver, "comment": comment, "approvedAt": now_iso()}
        stage.setdefault("approvals", []).append(approval)
        stage["approvalStatus"] = "APPROVED"
        stage["preflight"] = None  # approval state changed; re-run preflight for an exact gate snapshot
        self.save_stage(stage)
        self.audit("STAGE_APPROVED", actor=approver, stage_id=stage_id, details={"comment": comment[:500]})
        return stage

    def reject_stage(self, stage_id: str, approver: str, comment: str = "") -> Dict[str, Any]:
        stage = self.get_stage(stage_id)
        stage.setdefault("rejections", []).append({"approver": approver, "comment": comment, "rejectedAt": now_iso()})
        stage["approvalStatus"] = "REJECTED"; stage["preflight"] = None
        self.save_stage(stage)
        self.audit("STAGE_REJECTED", actor=approver, stage_id=stage_id, details={"comment": comment[:500]})
        return stage

    def save_run(self, run: Dict[str, Any]) -> Dict[str, Any]:
        run_id = str(run.get("runId") or ("run_" + uuid.uuid4().hex[:16]))
        run["runId"] = run_id
        (RUNS_DIR / f"{run_id}.json").write_text(json.dumps(run, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        self.audit("LIVE_EXECUTED", actor=str(run.get("actor") or "Human User"), stage_id=str(run.get("stageId") or ""), run_id=run_id,
                   details={
                       "apiKey": run.get("apiKey"), "statusCode": run.get("statusCode"), "success": run.get("success"),
                       "createAccepted": run.get("createAccepted"), "verifiedCreated": run.get("verifiedCreated"),
                       "resultState": run.get("resultState"),
                   })
        return run

    def get_run(self, run_id: str) -> Dict[str, Any]:
        path = RUNS_DIR / f"{run_id}.json"
        if not path.exists():
            raise KeyError(run_id)
        return json.loads(path.read_text(encoding="utf-8"))

    def update_run(self, run: Mapping[str, Any], *, audit_action: str = "RUN_UPDATED") -> Dict[str, Any]:
        run_id = str(run.get("runId") or "")
        if not run_id:
            raise ValueError("runId missing")
        value = dict(run)
        (RUNS_DIR / f"{run_id}.json").write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        self.audit(audit_action, actor=str(value.get("actor") or "Human User"), stage_id=str(value.get("stageId") or ""), run_id=run_id,
                   details={"success": value.get("success"), "verifiedCreated": value.get("verifiedCreated"), "resultState": value.get("resultState")})
        return value

    def history(self, limit: int = 100) -> List[Dict[str, Any]]:
        rows = []
        for path in sorted(RUNS_DIR.glob("run_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]:
            try: rows.append(json.loads(path.read_text(encoding="utf-8")))
            except Exception: continue
        return rows

    def successful_duplicate(self, api_key: str, identity_fingerprint: str) -> Optional[Dict[str, Any]]:
        if not identity_fingerprint: return None
        for run in self.history(1000):
            if run.get("success") and run.get("apiKey") == api_key and run.get("identityFingerprint") == identity_fingerprint:
                return run
        return None

    def audit_history(self, limit: int = 200) -> List[Dict[str, Any]]:
        if not AUDIT_PATH.exists(): return []
        rows = []
        for line in AUDIT_PATH.read_text(encoding="utf-8").splitlines()[-limit:][::-1]:
            try: rows.append(json.loads(line))
            except Exception: continue
        return rows


STATE = AppState()

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict
import os

# Exact developer-approved U-HAUL Transport Profile reference values from the
# supplied V122 code base (dev_approved/UHAL_input_dev_approved.json +
# Runner.tp_orch_payload). These are used for non-mutating TP validation smoke
# tests and payload-parity regression tests. They are never sent to the create
# endpoint by the health check.

SOURCE_PARAMETERS: Dict[str, Any] = {
    "Interface Environment": "UAT",
    "File Filtering Pattern": ".*\\*.",
    "Post Transfer Action": "Move To Archive",
    "Is Compression Required": "FALSE",
    "Use Existing Folder": "No",
    "Existing Account": "Yes",
    "Subscription Folder": "/SFTP_U-HAUL_ASN_PC_SRC_IB",
    "Existing Account Name": "haftatap10251594",
}

TARGET_PARAMETERS: Dict[str, Any] = {
    "Interface Environment": "UAT",
    "File Filtering Pattern": ".*\\*.",
    "Post Transfer Action": "Move To Archive",
    "Is Compression Required": "FALSE",
    "Use Existing Folder": "No",
    "Existing Account": "Yes",
    "Subscription Folder": "/Inbound/ASN",
    "Existing Account Name": "haftatap10251593",
}


def _requested_by() -> str:
    return str(os.getenv("HIP_REQUESTED_BY") or "adheesh.srivastava@dellteam.com").strip()


def _environment() -> str:
    return str(os.getenv("HIP_ENVIRONMENT") or "DEV").strip()


def validation_payload(role: str) -> Dict[str, Any]:
    source = str(role).lower().startswith("source")
    return {
        "interfaceType": "SFTP HAFT",
        "propertyMap": deepcopy(SOURCE_PARAMETERS if source else TARGET_PARAMETERS),
        "transportProfileName": "SFTP_U-HAUL_ASN_PC_SRC_IB" if source else "SFTP_U-HAUL_ASN_PC_TGT_OB",
        "hipEnvironment": _environment(),
    }


def create_payload(role: str, system_name: str | None = None) -> Dict[str, Any]:
    source = str(role).lower().startswith("source")
    account = "haftatap10251594" if source else "haftatap10251593"
    doc_name = "XML_DellAutoASN_10_U-HAUL_ANS_IB" if source else "XML_SHIPMENT_NOTICE_10_U-HAUL_ANS_OB"
    tp_name = "SFTP_U-HAUL_ASN_PC_SRC_IB" if source else "SFTP_U-HAUL_ASN_PC_TGT_OB"
    params = deepcopy(SOURCE_PARAMETERS if source else TARGET_PARAMETERS)
    # V22: never hard-code a partner System Name into an executable-looking
    # reference payload. The previous hard-coded partner-system sample could be stale
    # and must never leak into analysis/LIVE. Source AIC - DCE remains the known
    # U-HAUL Dell-side reference; Target/Receiver systemName must be explicitly
    # supplied (or configured only for a non-mutating smoke preview).
    resolved_system_name = str(system_name or "").strip()
    if not resolved_system_name:
        resolved_system_name = (
            str(os.getenv("HIP_UHAL_SOURCE_SYSTEM_NAME") or "AIC - DCE").strip()
            if source else str(os.getenv("HIP_UHAL_TARGET_SYSTEM_NAME") or "").strip()
        )
    return {
        "operation": "Create",
        "systemName": resolved_system_name,
        "systemType": "Dell Application" if source else "Partner",
        "requestedBy": _requested_by(),
        "hipEnvironment": _environment(),
        "transportProfileDetails": [{
            "transportProfileName": tp_name,
            "transportProfileUsage": "Sender" if source else "Receiver",
            "isFirstMigration": True,
            "transportProfileOperation": "create",
            "deploymentGroupName": "hip-automation",
            "interfaceDetails": [{
                "interfaceType": "SFTP HAFT",
                "interfaceRole": "Primary",
                "parameters": params,
            }],
            "isInterfaceDetailChangeRequired": False,
            "documentTypeDetails": [{
                "documentTypeName": doc_name,
                "documentTypeVersion": "1.0",
                "dataFormatType": "XML",
            }],
            "isDocumentTypeChangeRequired": False,
            "flowSteps": [],
            "isFlowStepChangeRequired": False,
            "callbackConfig": None,
            "isCallbackConfigChangeRequired": False,
            "tags": [
                {"key": "customer", "value": "U-HAUL"},
                {"key": "haftAccount", "value": account},
            ],
            "isTagChangeRequired": False,
            "splitterConfig": {"isSplitRequired": False, "regexExpression": ""},
            "isTPSplitterConfigChangeRequired": False,
            "ediConfig": None,
            "isEdiConfigurationChangeRequired": False,
        }],
        "transportProfileEditDetails": [],
        "crqDetails": None,
    }

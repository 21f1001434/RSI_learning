from __future__ import annotations

import json
import os
import re
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Mapping

from .governance import redact
from .llm import DellAIAClient

# Final operator-facing outcomes. PENDING is deliberately retained as a fourth
# state so an accepted-but-not-yet-verified request is never mislabeled SUCCESS
# or FAILED merely to force a tri-state answer.
FINAL_OUTCOMES = {"SUCCESS", "EXISTING", "FAILED", "PENDING"}

_STATUS_KEYS = {
    "status", "state", "result", "resultstatus", "operationstatus", "taskstatus",
    "deploymentstatus", "transportprofilestatus", "outcome", "verdict",
}
_SUCCESS_WORDS = {
    "SUCCESS", "SUCCEEDED", "COMPLETED", "COMPLETE", "CREATED", "ACTIVE",
    "DONE", "FINISHED", "ACCEPTED", "OK",
}
_FAILURE_WORDS = {
    "FAIL", "FAILED", "FAILURE", "ERROR", "ERRORED", "REJECTED", "INVALID",
    "CANCELLED", "CANCELED", "ABORTED", "TERMINATED", "DENIED",
}
_PENDING_WORDS = {
    "PENDING", "QUEUED", "PROCESSING", "IN_PROGRESS", "INPROGRESS", "STARTED",
    "ACCEPTED_FOR_PROCESSING", "SUBMITTED",
}

_EXISTING_PATTERNS = (
    r"\btransport\s*profile\b.{0,180}\balready\s+exists?\b",
    r"\btransportprofile(?:name)?\b.{0,180}\balready\s+exists?\b",
    r"\balready\s+exists?\b.{0,180}\btransport\s*profile\b",
    r"\btransport\s*profile\b.{0,180}\bpre[- ]?existing\b",
    r"\btransport\s*profile\b.{0,180}\bobject\s+exists\b",
)
_FAILURE_PATTERNS = (
    r"\btransport\s*profile\b.{0,180}\b(?:create|creation|request|operation)?\s*(?:failed|failure|rejected|invalid)\b",
    r"\b(?:failed|failure|rejected|unable\s+to\s+create|could\s+not\s+create|not\s+created)\b",
    r"\bvalidation\s+(?:failed|error)\b",
)
_SUCCESS_PATTERNS = (
    r"\btransport\s*profile\b.{0,180}\b(?:created|completed|succeeded|successfully)\b",
    r"\bcreated\s+successfully\b",
    r"\bsuccessfully\s+created\b",
    r"\brequest\s+(?:accepted|submitted)\b",
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _norm(value: Any) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", str(value or "").strip().upper()).strip("_")


def _json_text(value: Any) -> str:
    try:
        if isinstance(value, (Mapping, list)):
            return json.dumps(value, ensure_ascii=False, default=str).lower()
        return str(value or "").lower()
    except Exception:
        return str(value or "").lower()


def _message_text(value: Any) -> str:
    """Flatten scalar string *values* only, avoiding JSON key-name false positives."""
    parts: list[str] = []
    def visit(node: Any) -> None:
        if isinstance(node, Mapping):
            for v in node.values():
                visit(v)
        elif isinstance(node, list):
            for v in node:
                visit(v)
        elif isinstance(node, str):
            parts.append(node)
    visit(value)
    return " | ".join(parts).lower() if parts else (str(value or "").lower() if not isinstance(value, (Mapping, list)) else "")


def _walk(node: Any, path: str = "$") -> Iterable[tuple[str, str, Any]]:
    if isinstance(node, Mapping):
        for key, value in node.items():
            child = f"{path}.{key}"
            yield child, str(key), value
            if isinstance(value, (Mapping, list)):
                yield from _walk(value, child)
    elif isinstance(node, list):
        for i, value in enumerate(node):
            child = f"{path}[{i}]"
            yield child, str(i), value
            if isinstance(value, (Mapping, list)):
                yield from _walk(value, child)


def _existing_evidence(body: Any) -> list[str]:
    text = _message_text(body)
    found = []
    for pattern in _EXISTING_PATTERNS:
        if re.search(pattern, text, flags=re.I | re.S):
            found.append("response explicitly states that the Transport Profile already exists")
            break
    if isinstance(body, Mapping):
        for path, key, value in _walk(body):
            nk = re.sub(r"[^a-z0-9]", "", key.lower())
            if nk in {"transportprofileexists", "tpexists", "isexistingtransportprofile"} and value is True:
                found.append(f"{path}=true explicitly indicates an existing Transport Profile")
            if path.count(".") == 1 and nk in _STATUS_KEYS:
                v = _norm(value)
                if v in {"EXISTING", "EXISTS", "ALREADY_EXISTS", "DUPLICATE"}:
                    found.append(f"{path}={value!r} is a top-level existing/duplicate TP state")
            if nk in {"code", "errorcode", "statuscode", "reasoncode"}:
                v = _norm(value)
                if "TRANSPORT" in v and "PROFILE" in v and any(x in v for x in ("EXIST", "DUPLICATE")):
                    found.append(f"{path}={value!r} indicates an existing/duplicate Transport Profile")
    return list(dict.fromkeys(found))


def _structured_signals(body: Any) -> Dict[str, list[str]]:
    out = {"success": [], "failure": [], "pending": []}
    if not isinstance(body, (Mapping, list)):
        return out
    for path, key, value in _walk(body):
        nk = re.sub(r"[^a-z0-9]", "", key.lower())
        if nk == "success":
            if isinstance(value, bool):
                out["success" if value else "failure"].append(f"{path}={value}")
            elif isinstance(value, str) and _norm(value) in {"TRUE", "YES", "SUCCESS", "SUCCEEDED"}:
                out["success"].append(f"{path}={value!r}")
            elif isinstance(value, str) and _norm(value) in {"FALSE", "NO", "FAIL", "FAILED", "FAILURE"}:
                out["failure"].append(f"{path}={value!r}")
        if nk in _STATUS_KEYS and not isinstance(value, (Mapping, list)):
            v = _norm(value)
            if v in _FAILURE_WORDS or any(v.startswith(x + "_") for x in _FAILURE_WORDS):
                out["failure"].append(f"{path}={value!r}")
            elif v in _SUCCESS_WORDS or any(v.startswith(x + "_") for x in _SUCCESS_WORDS):
                out["success"].append(f"{path}={value!r}")
            elif v in _PENDING_WORDS or any(v.startswith(x + "_") for x in _PENDING_WORDS):
                out["pending"].append(f"{path}={value!r}")
        if nk in {"errors", "error", "errormessage", "violations"} and value not in (None, "", [], {}):
            # A populated error collection is strong failure evidence. A field named
            # 'error' with boolean false is not.
            if not (isinstance(value, bool) and value is False):
                out["failure"].append(f"{path} contains error evidence")
    return out


def classify_create_response(status_code: int, body: Any, success_statuses: Iterable[int] | None = None) -> Dict[str, Any]:
    """Classify the immediate Dell Create response without claiming final TP success.

    HTTP success alone is not sufficient: a 2xx body containing explicit FAILED/
    ERROR evidence is classified FAILED. Explicit same-TP duplicate evidence is
    classified EXISTING even when Dell uses a 4xx status.
    """
    success_set = {int(x) for x in (success_statuses or (200, 201, 202, 204))}
    status_code = int(status_code)
    existing = _existing_evidence(body)
    signals = _structured_signals(body)
    text = _message_text(body)

    text_failure = [p for p in _FAILURE_PATTERNS if re.search(p, text, flags=re.I | re.S)]
    text_success = [p for p in _SUCCESS_PATTERNS if re.search(p, text, flags=re.I | re.S)]
    http_ok = status_code in success_set

    if existing:
        classification = "EXISTING"
        reason = "Dell response contains explicit same-Transport-Profile existing/duplicate evidence."
        accepted = False
    elif signals["failure"] or text_failure:
        classification = "FAILED"
        reason = "Dell response contains explicit failure/rejection evidence."
        accepted = False
    elif not http_ok:
        classification = "FAILED"
        reason = f"HTTP {status_code} is not an approved Create success status."
        accepted = False
    else:
        # A 2xx with no semantic contradiction means the Create was accepted at the
        # HTTP boundary. Final SUCCESS still requires the Dell checking/audit API.
        classification = "SUCCESS"
        reason = "Dell Create request was accepted at the HTTP boundary; final SUCCESS requires checking-API verification."
        accepted = True

    evidence = []
    evidence.extend(existing[:4])
    evidence.extend(signals["failure"][:4])
    evidence.extend(signals["success"][:4])
    evidence.extend(signals["pending"][:4])
    if text_failure:
        evidence.append("response text matched an explicit failure phrase")
    if text_success:
        evidence.append("response text matched a success/accepted phrase")
    evidence.append(f"HTTP {status_code}; approved success statuses={sorted(success_set)}")

    return {
        "classification": classification,
        "acceptedForVerification": accepted,
        "existing": classification == "EXISTING",
        "failed": classification == "FAILED",
        "httpAccepted": http_ok,
        "semanticFailure": bool(signals["failure"] or text_failure),
        "semanticSuccess": bool(signals["success"] or text_success),
        "semanticPending": bool(signals["pending"]),
        "reason": reason,
        "evidence": evidence[:12],
        "classifiedAt": _now(),
        "deterministic": True,
    }


def classify_final_outcome(*, create: Mapping[str, Any], verification: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    """Convert Create + checking-API evidence into an operator-facing outcome."""
    verification = verification or {}
    c = str(create.get("classification") or "").upper()
    verified = bool(verification.get("verified"))
    vstate = str(verification.get("state") or "").upper()

    if c == "EXISTING":
        if verified:
            outcome, reason = "EXISTING", "Dell reported an existing Transport Profile and the checking API verified the exact TP."
        elif vstate == "EXISTING_AUDIT_FAILED":
            outcome, reason = "FAILED", "Dell reported an existing Transport Profile, but the latest exact-TP audit evidence is a terminal failure."
        else:
            outcome, reason = "PENDING", "Dell reported an existing Transport Profile, but the checking API has not verified the exact TP yet."
    elif c == "FAILED":
        outcome, reason = "FAILED", "Dell Create response was rejected or contained explicit failure evidence."
    elif verified:
        outcome, reason = "SUCCESS", "Dell checking API verified a new successful Transport Profile Create."
    elif vstate in {"AUDIT_FAILED", "CREATE_REJECTED", "EXISTING_AUDIT_FAILED"}:
        outcome, reason = "FAILED", "Dell checking/audit evidence reports a terminal failure."
    else:
        outcome, reason = "PENDING", "Dell accepted the Create request, but terminal success has not yet been verified."

    return {
        "classification": outcome,
        "reason": reason,
        "verificationState": vstate or None,
        "verified": verified,
        "deterministic": True,
        "classifiedAt": _now(),
    }



def summarize_outcomes(rows: Iterable[Mapping[str, Any]]) -> Dict[str, int]:
    """Return explicit final outcome counts for LIVE/batch reporting.

    Never collapse EXISTING or PENDING into generic success/failure. Rows that
    fail before a Dell response and therefore lack a classification are FAILED.
    """
    counts = {name: 0 for name in ("SUCCESS", "EXISTING", "FAILED", "PENDING")}
    for row in rows:
        value = str(row.get("outcomeClassification") or ("SUCCESS" if row.get("success") else "FAILED")).upper()
        if value not in counts:
            value = "FAILED"
        counts[value] += 1
    return counts

def response_agent_enabled() -> bool:
    raw = os.getenv("HIP_TP_RESPONSE_AGENT_ENABLED", "true")
    return str(raw).strip().lower() in {"1", "true", "yes", "y", "on"}


def _client() -> DellAIAClient:
    client = DellAIAClient()
    model = str(os.getenv("HIP_TP_RESPONSE_AGENT_MODEL") or os.getenv("LLM_JUDGE_MODEL") or "").strip()
    if model:
        client.model = model
    return client


def agent_assess_response(
    *,
    status_code: int,
    body: Any,
    create_classification: Mapping[str, Any],
    verification: Mapping[str, Any] | None,
    final_classification: Mapping[str, Any],
) -> Dict[str, Any]:
    """Ask Dell AIA to explain/classify redacted response evidence.

    The LLM is advisory only. It cannot override the deterministic outcome, mutate
    payloads, or execute APIs. This gives operators a natural-language interpretation
    while keeping the final state reproducible and testable.
    """
    deterministic = str(final_classification.get("classification") or "PENDING").upper()
    base = {
        "enabled": response_agent_enabled(),
        "state": "DETERMINISTIC_ONLY",
        "deterministicClassification": deterministic,
        "classification": deterministic,
        "llmUsed": False,
        "canOverrideDeterministic": False,
        "canExecuteApi": False,
        "canMutatePayload": False,
        "model": _client().model,
        "explanation": str(final_classification.get("reason") or ""),
        "generatedAt": _now(),
    }
    if not response_agent_enabled():
        base["state"] = "DISABLED"
        return base
    client = _client()
    if not client.available():
        base["state"] = "UNAVAILABLE"
        base["explanation"] += " Dell AIA response interpreter is not configured; deterministic classification was used."
        return base

    evidence = {
        "httpStatus": int(status_code),
        "createClassification": deepcopy(create_classification),
        "finalClassification": deepcopy(final_classification),
        "verification": redact(deepcopy(verification or {})),
        "response": redact(deepcopy(body)),
    }
    prompt = (
        "You are a read-only Dell HIP Transport Profile API response interpreter. "
        "Classify the supplied redacted evidence as SUCCESS, EXISTING, FAILED, or PENDING and explain why. "
        "SUCCESS means a new TP is terminally verified successful. EXISTING means Dell explicitly reports the exact TP already existed and checking evidence verifies it. "
        "FAILED means explicit rejection/failure evidence. PENDING means accepted or existing evidence is not yet terminally verified. "
        "The deterministic classification is authoritative; do not invent facts and do not suggest changing API attributes. "
        "Return JSON: classification, confidence (0-1), explanation, evidence (array of short strings)."
    )
    try:
        llm = client.complete_json(system=prompt, user=json.dumps(evidence, ensure_ascii=False, default=str), temperature=0.0)
        proposed = str(llm.get("classification") or "").strip().upper()
        if proposed not in FINAL_OUTCOMES:
            proposed = "PENDING"
        try:
            confidence = max(0.0, min(1.0, float(llm.get("confidence", 0.7))))
        except Exception:
            confidence = 0.7
        llm_evidence = llm.get("evidence") if isinstance(llm.get("evidence"), list) else []
        base.update({
            "state": "COMPLETED",
            "llmUsed": True,
            "llmClassification": proposed,
            # Never let the model overwrite deterministic business state.
            "classification": deterministic,
            "confidence": confidence,
            "explanation": str(llm.get("explanation") or base["explanation"])[:1500],
            "evidence": [str(x)[:500] for x in llm_evidence[:8]],
            "agreement": proposed == deterministic,
        })
    except Exception as exc:
        base["state"] = "ERROR"
        base["error"] = f"{type(exc).__name__}: {exc}"
        base["explanation"] += " Dell AIA response interpreter failed; deterministic classification was retained."
    return base


__all__ = [
    "FINAL_OUTCOMES",
    "agent_assess_response",
    "classify_create_response",
    "classify_final_outcome",
    "response_agent_enabled",
    "summarize_outcomes",
]

from __future__ import annotations

import json
import re
from copy import deepcopy
from typing import Any, Dict, List, Mapping, Tuple
from urllib.parse import urlparse

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

HTTP_METHODS = {"get", "post", "put", "patch", "delete"}


def _slug(value: Any) -> str:
    text = re.sub(r"[^a-zA-Z0-9]+", "_", str(value or "api")).strip("_").lower()
    return text[:80] or "api"


def _example_from_schema(schema: Mapping[str, Any], components: Mapping[str, Any] | None = None, depth: int = 0) -> Any:
    if depth > 8: return None
    if "$ref" in schema and components:
        ref = str(schema["$ref"]); key = ref.split("/")[-1]
        target = (components.get("schemas") or {}).get(key)
        if isinstance(target, Mapping): return _example_from_schema(target, components, depth + 1)
    if "example" in schema: return deepcopy(schema["example"])
    if "default" in schema: return deepcopy(schema["default"])
    enum = schema.get("enum")
    if isinstance(enum, list) and enum: return deepcopy(enum[0])
    typ = schema.get("type")
    if typ == "object" or isinstance(schema.get("properties"), Mapping):
        return {str(k): _example_from_schema(v if isinstance(v, Mapping) else {}, components, depth + 1) for k, v in (schema.get("properties") or {}).items()}
    if typ == "array": return [_example_from_schema(schema.get("items") or {}, components, depth + 1)]
    if typ == "integer": return 0
    if typ == "number": return 0.0
    if typ == "boolean": return False
    return ""


def _rules_from_schema(schema: Mapping[str, Any], prefix: str = "", components: Mapping[str, Any] | None = None, depth: int = 0) -> Tuple[List[str], Dict[str, Dict[str, Any]]]:
    if depth > 8: return [], {}
    if "$ref" in schema and components:
        key = str(schema["$ref"]).split("/")[-1]; target = (components.get("schemas") or {}).get(key)
        if isinstance(target, Mapping): return _rules_from_schema(target, prefix, components, depth + 1)
    required_paths: List[str] = []; rules: Dict[str, Dict[str, Any]] = {}
    props = schema.get("properties") or {}
    required_names = set(schema.get("required") or [])
    if isinstance(props, Mapping):
        for name, child in props.items():
            path = f"{prefix}.{name}" if prefix else str(name)
            if name in required_names: required_paths.append(path)
            if not isinstance(child, Mapping): continue
            typ = child.get("type")
            if typ == "object" or child.get("properties") or "$ref" in child:
                sub_req, sub_rules = _rules_from_schema(child, path, components, depth + 1); required_paths.extend(sub_req); rules.update(sub_rules)
            elif typ == "array":
                item = child.get("items") or {}; item_path = path + ".0"
                if isinstance(item, Mapping) and (item.get("type") == "object" or item.get("properties") or "$ref" in item):
                    sub_req, sub_rules = _rules_from_schema(item, item_path, components, depth + 1); required_paths.extend(sub_req); rules.update(sub_rules)
                else:
                    r = {}; 
                    if isinstance(item, Mapping) and item.get("type"): r["type"] = item.get("type")
                    if r: rules[item_path] = r
            else:
                r: Dict[str, Any] = {}
                if typ in {"string", "integer", "number", "boolean"}: r["type"] = typ
                if child.get("enum"): r["enum"] = deepcopy(child["enum"])
                if child.get("pattern"): r["pattern"] = child["pattern"]
                if child.get("minLength") is not None: r["min_length"] = child["minLength"]
                if child.get("maxLength") is not None: r["max_length"] = child["maxLength"]
                if child.get("minimum") is not None: r["min"] = child["minimum"]
                if child.get("maximum") is not None: r["max"] = child["maximum"]
                if r: rules[path] = r
    return required_paths, rules


def openapi_to_contracts(doc: Mapping[str, Any]) -> List[Dict[str, Any]]:
    servers = doc.get("servers") or []
    base = str((servers[0] or {}).get("url") or "") if servers and isinstance(servers[0], Mapping) else ""
    if not base and doc.get("swagger"):
        scheme = str((doc.get("schemes") or ["https"])[0]); host = str(doc.get("host") or ""); base_path = str(doc.get("basePath") or "")
        base = f"{scheme}://{host}{base_path}" if host else base_path
    components = doc.get("components") or {}
    if doc.get("definitions") and not components.get("schemas"):
        components = {**dict(components), "schemas": doc.get("definitions") or {}}
    rows: List[Dict[str, Any]] = []
    for path, methods in (doc.get("paths") or {}).items():
        if not isinstance(methods, Mapping): continue
        for method, op in methods.items():
            if method.lower() not in HTTP_METHODS or not isinstance(op, Mapping): continue
            schema: Mapping[str, Any] = {}
            request_kind = "params" if method.lower() == "get" else "payload"
            params = list(methods.get("parameters") or []) + list(op.get("parameters") or [])
            if method.lower() == "get":
                props = {}; req = []
                for param in params:
                    if isinstance(param, Mapping) and param.get("in") == "query":
                        name = str(param.get("name") or ""); props[name] = param.get("schema") or {k:v for k,v in param.items() if k in {"type","enum","pattern","minimum","maximum"}} or {"type": "string"}
                        if param.get("required"): req.append(name)
                schema = {"type": "object", "properties": props, "required": req}
            else:
                content = ((op.get("requestBody") or {}).get("content") or {}) if isinstance(op.get("requestBody") or {}, Mapping) else {}
                media = content.get("application/json") or content.get("application/*+json") or next((v for k, v in content.items() if "json" in str(k)), {})
                if isinstance(media, Mapping): schema = media.get("schema") or {}
                if not schema:  # Swagger 2 body parameter
                    body_param = next((p for p in params if isinstance(p, Mapping) and p.get("in") == "body"), None)
                    if isinstance(body_param, Mapping): schema = body_param.get("schema") or {}
            canonical = _example_from_schema(schema, components) if schema else {}
            if not isinstance(canonical, dict): canonical = {"value": canonical}
            required, rules = _rules_from_schema(schema, "", components)
            operation_id = op.get("operationId") or f"{method}_{path}"
            rows.append({
                "key": _slug(operation_id), "name": str(op.get("summary") or operation_id), "group": "Imported OpenAPI",
                "description": str(op.get("description") or "Imported from OpenAPI; review identity paths, auth headers and LIVE policy before approval."),
                "version": str((doc.get("info") or {}).get("version") or "imported"), "owner": "Imported / needs owner",
                "lifecycle_status": "DRAFT", "tags": [str(x) for x in (op.get("tags") or [])], "method": method.upper(),
                "url": base.rstrip("/") + "/" + str(path).lstrip("/") if base else str(path), "request_kind": request_kind,
                "canonical_request": canonical, "required_paths": required, "identity_paths": [], "field_rules": rules,
                "headers": {"Authorization": "${TARGET_API_TOKEN}"} if doc.get("security") or op.get("security") else {},
                "success_statuses": [int(code) for code in (op.get("responses") or {}) if str(code).isdigit() and 200 <= int(code) < 300] or [200, 201, 202, 204],
                "allow_live": False, "duplicate_policy": "warn", "notes": ["Imported as DRAFT. Human contract governance is required before LIVE."],
            })
    return rows


def _postman_items(items: List[Any], prefix: str = "") -> List[Tuple[str, Mapping[str, Any]]]:
    out: List[Tuple[str, Mapping[str, Any]]] = []
    for item in items:
        if not isinstance(item, Mapping): continue
        name = str(item.get("name") or "request"); full = f"{prefix} / {name}" if prefix else name
        if isinstance(item.get("item"), list): out.extend(_postman_items(item["item"], full))
        elif isinstance(item.get("request"), Mapping): out.append((full, item["request"]))
    return out


def postman_to_contracts(doc: Mapping[str, Any]) -> List[Dict[str, Any]]:
    rows = []
    for name, req in _postman_items(doc.get("item") or []):
        method = str(req.get("method") or "POST").upper()
        url_obj = req.get("url")
        if isinstance(url_obj, Mapping): url = str(url_obj.get("raw") or "")
        else: url = str(url_obj or "")
        canonical: Dict[str, Any] = {}
        body = req.get("body") or {}
        if isinstance(body, Mapping) and body.get("mode") == "raw":
            try:
                parsed = json.loads(str(body.get("raw") or "{}")); canonical = parsed if isinstance(parsed, dict) else {"value": parsed}
            except Exception: canonical = {}
        headers = {}
        for h in req.get("header") or []:
            if isinstance(h, Mapping) and h.get("key") and not h.get("disabled"): headers[str(h["key"])] = str(h.get("value") or "")
        # Never persist a concrete auth secret from a Postman collection.
        for k in list(headers):
            if re.search(r"authorization|token|api[-_ ]?key", k, re.I): headers[k] = "${TARGET_API_TOKEN}"
        rows.append({
            "key": _slug(name), "name": name, "group": "Imported Postman", "description": "Imported from Postman collection; review before approval.",
            "version": "imported", "owner": "Imported / needs owner", "lifecycle_status": "DRAFT", "method": method, "url": url,
            "request_kind": "params" if method == "GET" else "payload", "canonical_request": canonical, "required_paths": [], "identity_paths": [],
            "headers": headers, "success_statuses": [200, 201, 202, 204], "allow_live": False, "duplicate_policy": "warn",
            "notes": ["Imported as DRAFT. Required paths and identity paths must be reviewed by a human API owner."],
        })
    return rows


def parse_api_definition(data: bytes, filename: str = "") -> Tuple[List[Dict[str, Any]], str]:
    text = data.decode("utf-8-sig")
    try: doc = json.loads(text)
    except Exception:
        if yaml is None: raise ValueError("YAML import requires PyYAML")
        doc = yaml.safe_load(text)
    if not isinstance(doc, Mapping): raise ValueError("API definition must be a JSON/YAML object")
    if doc.get("openapi") or (doc.get("swagger") and doc.get("paths")):
        rows = openapi_to_contracts(doc); kind = "OpenAPI/Swagger"
    elif str(((doc.get("info") or {}).get("schema") or "")).find("postman") >= 0 or isinstance(doc.get("item"), list):
        rows = postman_to_contracts(doc); kind = "Postman"
    elif isinstance(doc.get("apis"), list) or isinstance(doc, list):
        raise ValueError("This looks like a native app catalog; use the normal catalog import")
    else: raise ValueError("Unrecognized API definition. Supported: OpenAPI/Swagger JSON/YAML or Postman Collection JSON")
    if not rows: raise ValueError("No API operations were found in the definition")
    return rows, kind

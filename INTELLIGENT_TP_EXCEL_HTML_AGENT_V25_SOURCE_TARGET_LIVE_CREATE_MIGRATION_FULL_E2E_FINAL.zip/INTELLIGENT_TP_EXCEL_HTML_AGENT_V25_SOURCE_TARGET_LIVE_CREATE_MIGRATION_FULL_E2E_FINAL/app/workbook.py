from __future__ import annotations

import csv
import io
import json
import math
import re
import zipfile
from typing import Any, Dict, List, Sequence, Tuple
from xml.etree import ElementTree as ET

MAX_FILE_BYTES = 20 * 1024 * 1024
MAX_ROWS = 1000
MAX_COLUMNS = 200
_BLANK_TEXT = {"", "-", "--", "n/a", "na", "#n/a", "#na", "none", "null", "nan", "nat", "<na>", "tbd", "not available", "data not available"}


def blank(value: Any) -> bool:
    """Return True when a workbook/API value is genuinely absent.

    V9 scoring rule: blank, null, NaN-like values and empty containers carry no
    evidence and must never receive completeness credit. Numeric zero and
    boolean False are valid values and therefore are *not* blank.
    """
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    if isinstance(value, str):
        return value.strip().casefold() in _BLANK_TEXT
    if isinstance(value, (list, tuple, set, dict)):
        return len(value) == 0
    return False


def display(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def norm_text(value: Any) -> str:
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(value or ""))
    text = text.replace("&", " and ")
    return " ".join(re.findall(r"[a-z0-9]+", text.casefold()))


_NS_MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_NS_REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_NS_PKG_REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"


def _col_index(cell_ref: str) -> int:
    match = re.match(r"([A-Z]+)", str(cell_ref or "").upper())
    if not match:
        return 0
    value = 0
    for ch in match.group(1):
        value = value * 26 + (ord(ch) - 64)
    return max(0, value - 1)


def _shared_strings(zf: zipfile.ZipFile) -> List[str]:
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    return ["".join((node.text or "") for node in si.iter(f"{_NS_MAIN}t")) for si in root.findall(f"{_NS_MAIN}si")]


def _xlsx_sheet_targets(zf: zipfile.ZipFile) -> List[Tuple[str, str]]:
    workbook = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    targets = {rel.attrib.get("Id", ""): rel.attrib.get("Target", "") for rel in rels.findall(f"{_NS_PKG_REL}Relationship")}
    out: List[Tuple[str, str]] = []
    sheets = workbook.find(f"{_NS_MAIN}sheets")
    for sheet in list(sheets) if sheets is not None else []:
        rel_id = sheet.attrib.get(f"{_NS_REL}id", "")
        target = targets.get(rel_id, "")
        if not target:
            continue
        path = target.lstrip("/") if target.startswith("/") else "xl/" + target.lstrip("/")
        path = re.sub(r"(^|/)\.(/|$)", r"\1", path)
        while "/../" in path:
            left, right = path.split("/../", 1)
            path = left.rsplit("/", 1)[0] + "/" + right
        out.append((sheet.attrib.get("name", "Sheet"), path))
    return out


def _read_xlsx_sheet(zf: zipfile.ZipFile, path: str, shared: Sequence[str]) -> List[List[Any]]:
    root = ET.fromstring(zf.read(path))
    data = root.find(f"{_NS_MAIN}sheetData")
    rows: List[List[Any]] = []
    for row in (list(data) if data is not None else [])[: MAX_ROWS + 50]:
        values: Dict[int, Any] = {}
        max_col = -1
        for cell in list(row):
            if not cell.tag.endswith("}c"):
                continue
            idx = _col_index(cell.attrib.get("r", "A1"))
            if idx >= MAX_COLUMNS:
                continue
            typ = cell.attrib.get("t", "")
            raw = cell.find(f"{_NS_MAIN}v")
            inline = cell.find(f"{_NS_MAIN}is")
            value: Any = ""
            if typ == "inlineStr" and inline is not None:
                value = "".join((node.text or "") for node in inline.iter(f"{_NS_MAIN}t"))
            elif raw is not None and raw.text is not None:
                text = raw.text
                if typ == "s":
                    try:
                        value = shared[int(text)]
                    except Exception:
                        value = text
                elif typ == "b":
                    value = text == "1"
                elif typ in {"str", "e"}:
                    value = text
                else:
                    try:
                        number = float(text)
                        value = int(number) if number.is_integer() else number
                    except Exception:
                        value = text
            values[idx] = value
            max_col = max(max_col, idx)
        rows.append([values.get(i, "") for i in range(max_col + 1)] if max_col >= 0 else [])
    return rows


def read_workbook(filename: str, data: bytes) -> Dict[str, Any]:
    if len(data) > MAX_FILE_BYTES:
        raise ValueError(f"Workbook is larger than {MAX_FILE_BYTES // (1024*1024)} MB")
    low = str(filename or "").casefold()
    if low.endswith(".csv"):
        rows = [row[:MAX_COLUMNS] for row in csv.reader(io.StringIO(data.decode("utf-8-sig", errors="replace")))][: MAX_ROWS + 50]
        return {"format": "CSV", "sheets": [{"name": "CSV", "rows": rows}]}
    if low.endswith(".json"):
        try:
            doc = json.loads(data.decode("utf-8-sig", errors="strict"))
        except Exception as exc:
            raise ValueError("The uploaded .json file is not valid JSON") from exc
        if not isinstance(doc, dict) or not isinstance(doc.get("sheets"), list):
            raise ValueError("Agent JSON must contain a top-level sheets[] array")
        exported_format = str(doc.get("format") or doc.get("kind") or "").strip()
        if exported_format and exported_format not in {"HIP_TP_TEAM_INPUT_V25", "HIP_TP_TEAM_INPUT", "TP_TEAM_INPUT"}:
            raise ValueError(f"Unsupported Agent JSON format {exported_format!r}")
        sheets = []
        for item in doc.get("sheets") or []:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "Sheet")[:80]
            rows_obj = item.get("rows")
            headers = item.get("headers")
            records = item.get("records")
            # V25 HTML export uses records[] dictionaries. Convert them to the
            # same row matrix used by XLSX so the exact same mapper executes.
            if isinstance(records, list):
                if not isinstance(headers, list) or not headers:
                    ordered = []
                    for rec in records:
                        if isinstance(rec, dict):
                            for key in rec:
                                if str(key) not in ordered:
                                    ordered.append(str(key))
                    headers = ordered
                headers = [str(x)[:200] for x in (headers or [])][:MAX_COLUMNS]
                matrix = [[f"V25 HTML export - {name}"], [], [], [], [], headers]
                for rec in records[:MAX_ROWS]:
                    if isinstance(rec, dict):
                        matrix.append([rec.get(h, "") for h in headers])
                sheets.append({"name": name, "rows": matrix})
                continue
            if isinstance(rows_obj, list):
                if rows_obj and isinstance(rows_obj[0], dict):
                    ordered = [str(x) for x in (headers or [])]
                    if not ordered:
                        for rec in rows_obj:
                            if isinstance(rec, dict):
                                for key in rec:
                                    if str(key) not in ordered:
                                        ordered.append(str(key))
                    ordered = ordered[:MAX_COLUMNS]
                    matrix = [[f"V25 HTML export - {name}"], [], [], [], [], ordered]
                    for rec in rows_obj[:MAX_ROWS]:
                        if isinstance(rec, dict):
                            matrix.append([rec.get(h, "") for h in ordered])
                    sheets.append({"name": name, "rows": matrix})
                else:
                    matrix = [list(r)[:MAX_COLUMNS] for r in rows_obj[:MAX_ROWS + 50] if isinstance(r, list)]
                    sheets.append({"name": name, "rows": matrix})
        if not sheets:
            raise ValueError("Agent JSON contains no readable sheets/records")
        return {"format": "JSON", "sheets": sheets, "sourceFormat": exported_format or "HIP_TP_TEAM_INPUT_V25"}
    if low.endswith((".xlsx", ".xlsm")):
        try:
            with zipfile.ZipFile(io.BytesIO(data), "r") as zf:
                shared = _shared_strings(zf)
                sheets = [
                    {"name": name, "rows": _read_xlsx_sheet(zf, path, shared)}
                    for name, path in _xlsx_sheet_targets(zf)
                    if path in zf.namelist()
                ]
                if not sheets:
                    raise ValueError("No readable worksheets were found")
                return {"format": "XLSX", "sheets": sheets}
        except zipfile.BadZipFile as exc:
            raise ValueError("The uploaded workbook is not a valid .xlsx/.xlsm file") from exc
    if low.endswith(".xls"):
        raise ValueError("Legacy .xls is not supported. Save it as .xlsx or CSV")
    raise ValueError("Upload an .xlsx, .xlsm, .csv, or V25 Agent .json file")


def _header_score(row: Sequence[Any]) -> float:
    texts = [display(v) for v in row if not blank(v)]
    if len(texts) < 2:
        return -1.0
    textual = sum(1 for v in texts if re.search(r"[A-Za-z]", v))
    unique = len({norm_text(v) for v in texts if norm_text(v)})
    hints = sum(1 for v in texts if any(word in norm_text(v) for word in ("account", "transport", "interface", "document", "system", "flow", "name", "server", "type", "partner", "environment")))
    return textual + unique * 0.35 + hints * 1.5


def detect_header(rows: Sequence[Sequence[Any]]) -> int:
    candidates = [(index, _header_score(row)) for index, row in enumerate(rows[:30])]
    candidates.sort(key=lambda item: (item[1], -item[0]), reverse=True)
    return candidates[0][0] if candidates and candidates[0][1] >= 0 else 0


def headers_and_records(rows: Sequence[Sequence[Any]], header_index: int) -> Tuple[List[str], List[Dict[str, Any]]]:
    """Build stable headers while preserving Excel parent/group context.

    The team workbook contains repeated leaf labels such as ``Account`` under
    different grouped headings (Partner Details vs Transport Profile Details).
    Older builds collapsed those to ``Account``, ``Account (2)``, ... and the
    mapper could not tell which account belonged to the TP API.  For duplicate
    leaf labels we now retain the nearest parent headers from the rows above the
    detected header row, e.g. ``Add >Transport Profile Details > Account``.

    Unique headers stay unchanged, so simple CSV/XLSX files remain fully
    backwards compatible.
    """
    raw_headers = list(rows[header_index]) if 0 <= header_index < len(rows) else []
    raw_headers = raw_headers[:MAX_COLUMNS]
    width = len(raw_headers)

    bases = [display(v) or f"Column {i + 1}" for i, v in enumerate(raw_headers)]
    base_counts: Dict[str, int] = {}
    for base in bases:
        base_counts[base] = base_counts.get(base, 0) + 1

    # Group labels in Excel are commonly merged.  The XML stores the text only
    # in the left-most cell, so forward-fill parent rows before reading context.
    parent_rows: List[List[str]] = []
    for parent_idx in range(max(0, header_index - 3), header_index):
        source = list(rows[parent_idx]) if parent_idx < len(rows) else []
        filled: List[str] = []
        last = ""
        for col in range(width):
            value = display(source[col]) if col < len(source) else ""
            if value:
                last = value
            filled.append(last)
        parent_rows.append(filled)

    headers: List[str] = []
    used: Dict[str, int] = {}
    for index, base in enumerate(bases):
        candidate = base
        if base_counts.get(base, 0) > 1:
            context: List[str] = []
            for prow in parent_rows:
                value = display(prow[index]) if index < len(prow) else ""
                if value and norm_text(value) != norm_text(base) and value not in context:
                    context.append(value)
            if context:
                # The closest two group labels are normally enough to identify
                # the business section while keeping UI/report labels readable.
                candidate = " > ".join(context[-2:] + [base])
        count = used.get(candidate, 0) + 1
        used[candidate] = count
        headers.append(candidate if count == 1 else f"{candidate} ({count})")

    records: List[Dict[str, Any]] = []
    for excel_row, row in enumerate(rows[header_index + 1 : header_index + 1 + MAX_ROWS], start=header_index + 2):
        values = list(row) + [""] * max(0, len(headers) - len(row))
        record = {headers[i]: values[i] for i in range(len(headers))}
        if any(not blank(v) for v in record.values()):
            records.append({"excelRow": excel_row, "values": record})
    return headers, records

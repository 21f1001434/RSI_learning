# V25 — Source/Target Excel + HTML Agent JSON, LIVE Create, Response Intelligence & Migration

V25 keeps the V23 systemName/systemType provenance locks and LIVE response classifier, and adds a team-input layer that does not depend on Excel filters.

## Intake

- 14 executable workbook sheets: one SOURCE and one TARGET sheet for each approved interface family.
- Sheet names lock both role and interface (`SFTP_HAFT_SOURCE`, `HTTPS_TARGET`, etc.).
- Header row 6 is read directly; Excel filters/dropdowns are not required.
- Same TP repeated for multiple document types is consolidated into one payload with repeated `documentTypeDetails[]` items.
- UHAL-POAC dummy rows are packaged for every sheet but are blocked from Stage/LIVE until all `DUMMY_`, `REPLACE_ME`, and `example.invalid` values are replaced.

## HTML alternative

`templates/HIP_TP_TEAM_INPUT_TEMPLATE_V25_SOURCE_TARGET_AGENT_EXPORT.html` is an Excel-free form. It exports:

- Agent JSON (`HIP_TP_TEAM_INPUT_V25`) preserving Source/Target/interface sheet groups.
- Flat CSV with explicit `TP Role` and `Interface Type` on every row.

Both are accepted by `/api/tp/analyze` and use the same mapper as XLSX.

## API routing

- `*_SOURCE` -> `source_tp` governed Create contract.
- `*_TARGET` -> `target_tp` governed Create contract.
- Interface family selects the exact immutable interface schema.
- `AIC - DCE` -> `systemType = Dell Application`; every other explicit `systemName` -> `Partner`.
- Stage, Preflight and final LIVE boundary re-check system identity and immutable contract fingerprints.

## LIVE Create + response interpretation

After Stage + Preflight + explicit `LIVE` / `LIVE ALL`, the configured Dell Create HTTP call is made. The deterministic response classifier returns `SUCCESS`, `EXISTING`, `FAILED`, or `PENDING`; the Dell checking/audit API is used for terminal verification where configured. Dell AIA response interpretation is advisory/read-only and cannot override deterministic evidence.

## Migration

Migration uses the exact V130 endpoint:

`POST /api/migration/orchestration/transport-profile`

The payload is rebuilt from the staged Create identity/interface values and contains only:

- `sourceEnvironment`
- `targetEnvironment`
- `transportProfileName`
- `transportProfileInterfaceType`
- `transportProfileInterfaceParameters`

Template migration columns are intent/prefill only. Migration still requires Migration Preflight and explicit `MIGRATE` / `MIGRATE ALL` confirmation.

## Execution evidence

Create and Migration runs are saved with request/response evidence and can be rendered through the existing execution-report endpoints. Sensitive auth/password/token/certificate fields stay redacted in stored/report evidence.

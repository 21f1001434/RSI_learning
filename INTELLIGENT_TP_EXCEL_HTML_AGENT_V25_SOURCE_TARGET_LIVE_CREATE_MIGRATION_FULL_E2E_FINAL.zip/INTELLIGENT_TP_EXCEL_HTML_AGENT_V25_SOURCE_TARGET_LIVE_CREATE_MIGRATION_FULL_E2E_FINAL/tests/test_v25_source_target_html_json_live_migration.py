from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

from fastapi.testclient import TestClient

from app.catalog import load_catalog
from app.main import app
from app.migration_service import build_migration_payload
from app.tp_service import analyze_tp_workbook


V25_SHEETS = {
    "SFTP_HAFT_SOURCE", "SFTP_HAFT_TARGET", "FTP_SOURCE", "FTP_TARGET",
    "SFTP_SERVER_SOURCE", "SFTP_SERVER_TARGET", "HTTPS_SOURCE", "HTTPS_TARGET",
    "HTTPS_AS2_SOURCE", "HTTPS_AS2_TARGET", "NAS_SOURCE", "NAS_TARGET",
    "RABBIT_MQ_SOURCE", "RABBIT_MQ_TARGET",
}


def _agent_json_source(*, interface_type: str = "SFTP HAFT", sheet: str = "SFTP_HAFT_SOURCE") -> bytes:
    rec = {
        "Customer Name": "UHAL-POAC",
        "TP Role": "Source",
        "Source System": "AIC - DCE",
        "Source System Type": "Dell Application",
        "Target System": "",
        "Target System Type": "",
        "Transport Profile Name": "UHAL_POAC_V25_SRC",
        "Interface Type": interface_type,
        "Document Type Name": "UHAL_POAC_850",
        "Document Type Version": "1.0",
        "Data Format Type": "EDIX12",
        "Interface Environment": "DEV",
        "File Filtering Pattern": "*.edi",
        "Post Transfer Action": "Delete",
        "Is Compression Required": "False",
        "Use Existing Folder": "True",
        "Existing Account": "True",
        "Subscription Folder": "/uhal-poac/outbound",
        "Existing Account Name": "UHAL-POAC",
        "Migration Source Environment": "DEV",
        "Migration Target Environment": "TEST",
        "Migrate After Create": "Yes",
    }
    doc = {
        "format": "HIP_TP_TEAM_INPUT_V25",
        "version": "25.0",
        "sheets": [{"name": sheet, "headers": list(rec), "records": [rec]}],
    }
    return json.dumps(doc).encode("utf-8")


def _agent_json_source_target() -> bytes:
    src = json.loads(_agent_json_source().decode("utf-8"))["sheets"][0]
    tgt_rec = {
        "Customer Name": "UHAL-POAC",
        "TP Role": "Target",
        "Source System": "",
        "Source System Type": "",
        "Target System": "UHAL-POAC",
        "Target System Type": "Partner",
        "Transport Profile Name": "UHAL_POAC_V25_TGT",
        "Interface Type": "SFTP HAFT",
        "Document Type Name": "UHAL_POAC_855",
        "Document Type Version": "1.0",
        "Data Format Type": "EDIX12",
        "Interface Environment": "DEV",
        "File Filtering Pattern": "*.edi",
        "Post Transfer Action": "Delete",
        "Is Compression Required": "False",
        "Use Existing Folder": "True",
        "Existing Account": "True",
        "Subscription Folder": "/uhal-poac/inbound",
        "Existing Account Name": "UHAL-POAC",
        "Migration Source Environment": "DEV",
        "Migration Target Environment": "TEST",
        "Migrate After Create": "No",
    }
    doc = {
        "format": "HIP_TP_TEAM_INPUT_V25",
        "version": "25.0",
        "sheets": [src, {"name": "SFTP_HAFT_TARGET", "headers": list(tgt_rec), "records": [tgt_rec]}],
    }
    return json.dumps(doc).encode("utf-8")


def test_v25_packaged_excel_has_14_source_target_sheets_and_dummies_are_not_live_ready():
    root = Path(__file__).resolve().parents[1]
    p = root / "templates" / "HIP_TP_TEAM_INPUT_TEMPLATE_V25_SOURCE_TARGET_NO_FILTER_UHAL_POAC_LIVE_MIGRATION.xlsx"
    assert p.exists()
    out = analyze_tp_workbook(
        filename=p.name, data=p.read_bytes(), contracts=load_catalog(), scope="BOTH", use_llm=False, scan_all_sheets=True
    )
    meta = {x["name"]: x for x in out["sheets"]}
    assert V25_SHEETS.issubset(meta)
    assert all(meta[x]["headerRow"] == 6 for x in V25_SHEETS)
    assert out["summary"]["tpActions"] == 14
    assert out["summary"]["GOOD_TO_TRIGGER"] == 0
    assert out["summary"]["NEEDS_INPUT"] == 14
    assert all(a.get("templateDummyFindings") for a in out["tpActions"])


def test_v25_html_agent_json_uses_same_mapper_and_sheet_locks_source_target_api():
    out = analyze_tp_workbook(
        filename="v25-agent-export.json", data=_agent_json_source_target(), contracts=load_catalog(), scope="BOTH", use_llm=False
    )
    assert out["file"]["format"] == "JSON"
    assert out["summary"]["GOOD_TO_TRIGGER"] == 2
    by_role = {a["tpRoleKey"]: a for a in out["tpActions"]}
    assert by_role["source"]["apiKey"] == "source_tp"
    assert by_role["source"]["systemName"] == "AIC - DCE"
    assert by_role["source"]["systemType"] == "Dell Application"
    assert by_role["target"]["apiKey"] == "target_tp"
    assert by_role["target"]["systemName"] == "UHAL-POAC"
    assert by_role["target"]["systemType"] == "Partner"
    assert by_role["source"]["templateSheetLock"]["filterRequired"] is False
    assert by_role["source"]["migrationIntent"] == {
        "enabled": True,
        "sourceEnvironment": "DEV",
        "targetEnvironment": "TEST",
        "advisoryOnly": True,
        "requiresExplicitConfirmation": "MIGRATE / MIGRATE ALL",
    }


def test_v25_sheet_name_can_supply_missing_role_and_interface_but_conflict_is_blocked():
    doc = json.loads(_agent_json_source().decode("utf-8"))
    rec = doc["sheets"][0]["records"][0]
    rec["TP Role"] = ""
    rec["Interface Type"] = ""
    out = analyze_tp_workbook(
        filename="v25.json", data=json.dumps(doc).encode(), contracts=load_catalog(), scope="BOTH", use_llm=False
    )
    row = out["tpActions"][0]
    assert row["status"] == "GOOD_TO_TRIGGER"
    assert row["tpRoleKey"] == "source"
    assert row["interfaceType"] == "SFTP HAFT"
    assert row["apiKey"] == "source_tp"

    bad = json.loads(_agent_json_source(interface_type="HTTPS").decode("utf-8"))
    out_bad = analyze_tp_workbook(
        filename="v25-bad.json", data=json.dumps(bad).encode(), contracts=load_catalog(), scope="BOTH", use_llm=False
    )
    assert out_bad["tpActions"][0]["status"] == "DO_NOT_TRIGGER"
    assert "sheet/interface mismatch" in out_bad["tpActions"][0]["warnings"][0]


def test_v25_migration_payload_reuses_exact_create_identity_and_values():
    out = analyze_tp_workbook(
        filename="v25.json", data=_agent_json_source(), contracts=load_catalog(), scope="BOTH", use_llm=False
    )
    row = out["tpActions"][0]
    mig = build_migration_payload(row["proposedRequest"], source_environment="DEV", target_environment="TEST")
    assert mig["transportProfileName"] == "UHAL_POAC_V25_SRC"
    assert mig["sourceEnvironment"] == "DEV"
    assert mig["targetEnvironment"] == "TEST"
    iface = row["proposedRequest"]["transportProfileDetails"][0]["interfaceDetails"][0]
    assert mig["transportProfileInterfaceType"] == iface["interfaceType"]
    assert mig["transportProfileInterfaceParameters"] == iface["parameters"]


def test_v25_template_endpoints_and_bootstrap_advertise_no_filter_excel_and_html():
    client = TestClient(app)
    x = client.get("/api/tp/team-template.xlsx")
    assert x.status_code == 200
    assert "V25_SOURCE_TARGET_NO_FILTER" in x.headers["content-disposition"]
    h = client.get("/api/tp/team-template.html")
    assert h.status_code == 200
    assert "text/html" in h.headers["content-type"]
    assert "Export Agent JSON" in h.text
    b = client.get("/api/bootstrap").json()
    assert b["app"]["version"] == "25.0.0"
    assert b["teamTemplate"]["filtersRequired"] is False
    assert b["teamTemplate"]["agentJsonSupported"] is True
    assert set(b["teamTemplate"]["interfaceSheets"]) == V25_SHEETS


def test_v25_agent_json_reaches_real_create_and_migration_http_boundaries(monkeypatch):
    create_calls = []
    migration_calls = []

    class CreateResp:
        status_code = 201
        text = '{"created":true}'
        def json(self):
            return {"created": True, "transportProfileId": "tp-v25"}

    class MigrationResp:
        status_code = 202
        text = '{"accepted":true}'
        def json(self):
            return {"accepted": True, "migrationId": "mig-v25"}

    def fake_request(method, url, **kwargs):
        if "/api/migration/orchestration/transport-profile" in str(url):
            migration_calls.append((method, url, deepcopy(kwargs.get("json"))))
            return MigrationResp()
        create_calls.append((method, url, deepcopy(kwargs.get("json"))))
        return CreateResp()

    monkeypatch.setenv("HIP_LIVE_API_EXECUTION", "true")
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "true")
    monkeypatch.setenv("HIP_BULK_LIVE_EXECUTION", "true")
    monkeypatch.setenv("ALLOWED_API_HOSTS", "apigtwtst.us.dell.com")
    monkeypatch.setenv("HIP_AUTHORIZATION", "Bearer v25-test-token")
    monkeypatch.setenv("HIP_ENVIRONMENT", "DEV")
    monkeypatch.setenv("HIP_REQUESTED_BY", "v25-test@dell.com")
    monkeypatch.setenv("FOUR_EYES_REQUIRED", "false")
    monkeypatch.setenv("HIP_TP_VALIDATE_BEFORE_CREATE", "false")
    monkeypatch.setenv("HIP_TP_POST_CREATE_CHECK_ENABLED", "false")
    monkeypatch.setenv("HIP_TP_MIGRATION_POST_CHECK_ENABLED", "false")
    monkeypatch.setenv("HIP_TP_RESPONSE_AGENT_ENABLED", "false")
    monkeypatch.setenv("LLM_JUDGE_ENABLED", "false")
    monkeypatch.setattr("app.executor.requests.request", fake_request)
    monkeypatch.setattr("app.migration_service.requests.request", fake_request)

    client = TestClient(app)
    analyzed = client.post(
        "/api/tp/analyze",
        files={"workbook": ("v25-agent.json", _agent_json_source(), "application/json")},
        data={"tp_scope": "BOTH", "use_llm": "false", "scan_all_sheets": "true"},
    )
    assert analyzed.status_code == 200, analyzed.text
    body = analyzed.json()
    row = body["tpActions"][0]
    assert row["status"] == "GOOD_TO_TRIGGER"

    staged = client.post(
        "/api/stage",
        json={"analysisId": body["analysisId"], "rowId": row["actionId"], "payload": row["proposedRequest"], "reviewer": "V25 Reviewer"},
    )
    assert staged.status_code == 200, staged.text
    stage = staged.json()["stage"]

    pf = client.post(f"/api/stages/{stage['stageId']}/preflight")
    assert pf.status_code == 200, pf.text
    assert pf.json()["preflight"]["executionReady"] is True

    live = client.post(f"/api/stages/{stage['stageId']}/execute", json={"confirmation": "LIVE", "actor": "V25 Reviewer"})
    assert live.status_code == 200, live.text
    assert create_calls
    sent = create_calls[0][2]
    assert sent["systemName"] == "AIC - DCE"
    assert sent["systemType"] == "Dell Application"
    assert sent["transportProfileDetails"][0]["transportProfileName"] == "UHAL_POAC_V25_SRC"

    mpf = client.post(
        f"/api/stages/{stage['stageId']}/migration-preflight",
        json={"sourceEnvironment": "DEV", "targetEnvironment": "TEST", "migrationEnabled": True, "actor": "V25 Reviewer"},
    )
    assert mpf.status_code == 200, mpf.text
    assert mpf.json()["migrationPreflight"]["executionReady"] is True

    mig = client.post(
        f"/api/stages/{stage['stageId']}/migrate",
        json={"sourceEnvironment": "DEV", "targetEnvironment": "TEST", "migrationEnabled": True, "confirmation": "MIGRATE", "actor": "V25 Reviewer"},
    )
    assert mig.status_code == 200, mig.text
    assert migration_calls
    mig_payload = migration_calls[0][2]
    assert mig_payload["transportProfileName"] == "UHAL_POAC_V25_SRC"
    assert mig_payload["sourceEnvironment"] == "DEV"
    assert mig_payload["targetEnvironment"] == "TEST"

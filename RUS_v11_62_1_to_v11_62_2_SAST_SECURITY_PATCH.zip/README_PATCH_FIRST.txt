RUS v11.62.1 -> v11.62.2 SAST SECURITY PATCH
================================================
Copy this patch over the v11.62.1 deployment-reverified tree, preserving paths.
Changed existing files: 32
Added files: 8
Removed files: 1

Primary security changes are in:
- AgenticDataDisparity.API/src/services/disparity_agent/agents/model_client.py
- AgenticDataDisparity.API/src/services/disparity_agent/api/routes.py
- AgenticDataDisparity.API/src/services/disparity_agent/api/run_store.py
- AgenticDataDisparity.API/src/services/disparity_agent/api/batch_jobs.py
- AgenticDataDisparity.API/src/services/disparity_agent/api/file_security.py
- AgenticDataDisparity.API/tests/unit_tests/test_sast_security_regressions.py

CI validate stage now also runs the SAST regression validator.
Current version: 11.62.2

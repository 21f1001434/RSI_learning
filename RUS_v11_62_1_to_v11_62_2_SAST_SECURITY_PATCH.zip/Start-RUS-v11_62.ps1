$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "RUS v11.62.2 SAST/security hotfix: forwarding to Start-RUS-v11_62_2.ps1" -ForegroundColor Yellow
& (Join-Path $root "Start-RUS-v11_62_2.ps1") @args
exit $LASTEXITCODE

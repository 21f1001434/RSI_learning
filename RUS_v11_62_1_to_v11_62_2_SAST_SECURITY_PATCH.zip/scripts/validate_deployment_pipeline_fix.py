from __future__ import annotations

import ast
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
API = ROOT / "AgenticDataDisparity.API"
checks: list[tuple[str, bool, str]] = []

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, bool(ok), detail))
    print(("PASS" if ok else "FAIL"), name, detail)

req = (API / "requirements.txt").read_text(encoding="utf-8")
dev = (API / "requirements-dev.txt").read_text(encoding="utf-8")
ci = (API / ".gitlab-ci.yml").read_text(encoding="utf-8")
base = (API / "ci-cd/templates/base-pipeline.yml").read_text(encoding="utf-8")
docker = (API / "Dockerfile").read_text(encoding="utf-8")

check("release is 11.62.2", (ROOT / "VERSION").read_text().strip() == "11.62.2")
check("SCA-safe urllib3 direct pin", bool(re.search(r"(?m)^urllib3==2\.7\.0\s*$", req)))
check("Dell AIA auth package retained", "aia-auth-client==0.0.8" in req)
check("pytest-asyncio not required", "pytest-asyncio" not in dev.lower())
check("CI runs plugin-independent unit tests", "-p no:asyncio" in ci)
check("CI emits declared JUnit artifact", "--junitxml=junit.xml" in ci and "junit: junit.xml" in ci)
check("CI package archive includes runtime directory", bool(re.search(r"tar .*\bsrc\s+runtime\s+requirements\.txt", ci)))
check("CI validates installed dependency graph", "python -m pip check" in base)
check("Docker validates installed dependency graph", "python -m pip check" in docker)

offenders: list[str] = []
for path in (API / "tests/unit_tests").glob("test_*.py"):
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in ast.walk(tree):
        if isinstance(node, ast.AsyncFunctionDef) and node.name.startswith("test_"):
            offenders.append(f"{path.name}:{node.lineno}:{node.name}")
check("unit-test suite has no async pytest entry points", not offenders, ", ".join(offenders))

launcher = ROOT / "Start-RUS-v11_62_2.ps1"
check("deployment-fixed launcher exists", launcher.exists())
check("compatibility launcher exists", (ROOT / "Start-RUS-v11_62.ps1").exists())
check("runtime verifier exists", (ROOT / "scripts/verify_runtime_v11_62_2.ps1").exists())

failed = [x for x in checks if not x[1]]
print(f"\n{len(checks)-len(failed)}/{len(checks)} deployment-fix checks passed")
raise SystemExit(1 if failed else 0)

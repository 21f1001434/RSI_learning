param(
    [string]$BaseUrl = "http://127.0.0.1:49690",
    [Parameter(Mandatory=$true)][string]$InternalApiKey
)
$ErrorActionPreference="Stop"
function Assert([bool]$Condition,[string]$Message){ if(-not $Condition){ throw $Message } }
$headers=@{ "X-Internal-API-Key"=$InternalApiKey }
$py=Invoke-RestMethod "http://127.0.0.1:8088/api/v1/health/live" -Headers $headers -TimeoutSec 10
Assert ($py.success -and $py.data.version -eq "11.62.2") "Wrong Python API version."
Assert ($py.data.layout -eq "src-template") "Python API is not using the production src template."
$ready=Invoke-RestMethod "http://127.0.0.1:8088/api/v1/health/ready" -Headers $headers -TimeoutSec 10
Assert ($ready.success) "Python readiness failed."
Assert ($ready.data.source_write_authorization -eq "profile-governed approval workflow") "Wrong approval policy."
Assert ($ready.data.profile_write_policy.business -match "single chat") "Business approval policy missing."
Assert ($ready.data.profile_write_policy.customer_support -match "popup") "Customer Support popup policy missing."
Assert ($ready.data.profile_write_policy.technical -match "popup") "Technical popup policy missing."
Assert ($ready.data.profile_write_policy.admin -match "popup") "Admin popup policy missing."
Assert ($ready.data.profile_write_policy.cps -match "read-only") "CPS must remain read-only."
Assert ($ready.data.adaptive_memory.enabled -eq $true) "Adaptive execution memory is not enabled."
Assert ($ready.data.adaptive_memory.bounded_rsi -eq $true) "Bounded RSI policy is not enabled."
Assert ($ready.data.adaptive_memory.pii_persisted -eq $false) "Adaptive memory must not persist raw PII."
Assert ($ready.data.adaptive_memory.code_self_modification -eq $false) "Code self-modification must remain disabled."
Assert ($ready.data.adaptive_memory.business_rule_mutation -eq $false) "Business-rule mutation must remain disabled."
Assert ($ready.data.adaptive_memory.approval_bypass -eq $false) "Approval bypass must remain disabled."
$memory=Invoke-RestMethod "http://127.0.0.1:8088/api/v1/memory/status" -Headers $headers -TimeoutSec 10
Assert ($memory.success -and $memory.data.enabled -eq $true) "Adaptive-memory status endpoint failed."
Assert ($memory.data.backend -eq "sqlite") "Unexpected adaptive-memory backend."
Assert ($memory.data.pii_persisted -eq $false) "Adaptive-memory status reports PII persistence."
Assert ($memory.data.skill_induction -eq $true) "Adaptive skill induction is not enabled."
Assert ($memory.data.model_allowlist.Count -ge 1) "Dell AIA model allow-list is empty."
Assert ($memory.data.model_allowlist_mutation -eq $false) "RSI must not modify the model allow-list."

$rel=Invoke-RestMethod "$BaseUrl/api/release" -TimeoutSec 10
Assert ($rel.data.release -eq "11.62.2") "Wrong .NET/UI release."
$bridge=Invoke-RestMethod "$BaseUrl/api/internal/source-write/capabilities" -Headers $headers -TimeoutSec 10
Assert ($bridge.success -and $bridge.sharedManualUpdateContract) "Shared manual write bridge unavailable."
Assert ($bridge.rewardsDb.implementation -match "RewardsDbOperationsV2") "Rewards DB does not use shared writer."
Assert ($bridge.crowdTwist.implementation -match "LoyaltyServiceProviderV3") "CrowdTwist does not use shared writer."

foreach($path in @('/login.html','/rus-app.html','/ai-analysis.html','/cps.html','/members.html','/crowdtwist.html','/search.html')){
    $r=Invoke-WebRequest "$BaseUrl$path" -UseBasicParsing -TimeoutSec 10
    Assert ($r.StatusCode -eq 200 -and $r.Content -match '<html') "$path failed."
    Assert ($r.Content -match '11.62.2') "$path has a stale release cache marker."
}
$agent=Invoke-WebRequest "$BaseUrl/ai-analysis.html" -UseBasicParsing -TimeoutSec 10
Assert ($agent.Content -match 'Data Disparity Agent') "Data Disparity Agent UI title missing."
Assert ($agent.Content -match 'Profile-governed approvals') "Governed approval UI copy missing."
Write-Host "RUS v11.62.2 runtime verification passed." -ForegroundColor Green

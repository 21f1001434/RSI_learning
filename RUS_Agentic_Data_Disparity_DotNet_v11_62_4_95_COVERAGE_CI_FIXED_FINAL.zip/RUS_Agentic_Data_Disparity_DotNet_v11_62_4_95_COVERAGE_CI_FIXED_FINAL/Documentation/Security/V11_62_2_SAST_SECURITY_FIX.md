# RUS v11.62.2 — Deployment SAST Security Fix

Date: 24 Sep 2026

This hotfix addresses the four high-severity source-scan findings reported by the deployment team while preserving the existing v11.62.1 business, approval, memory/RSI, and source-write behavior.

## Findings fixed

| Finding | Reported location | Remediation |
|---|---|---|
| Hardcoded Non-Cryptographic Secret | `src/services/disparity_agent/agents/model_client.py` | Removed the static adapter-only key-like literal. AutoGen now receives a non-persistent process-local value generated with Python `secrets`. Dell AIA bearer authentication still comes from `DellAIARefreshingAuth`. |
| Path Traversal | `src/services/disparity_agent/api/routes.py` JSON report download | Run IDs are constrained to the generated `DDR-XXXXXXXXXXXX` contract, report paths are containment checked under `runtime/runs`, `FileResponse` is removed, and the response is produced from structured report bytes with a safe filename. |
| Path Traversal | `src/services/disparity_agent/api/routes.py` batch ZIP download | Job IDs are constrained to `JOB-XXXXXXXXXXXXXXXX`, stored artifact paths are proven to remain under the configured batch-output directory, `FileResponse` is removed, and `Content-Disposition` uses a validated basename. |
| Cross-site Scripting (XSS) | `src/services/disparity_agent/api/routes.py` HTML report | The route no longer uses `HTMLResponse`. It renders from structured report data through the existing escaping renderer, requires a strict run ID, adds `X-Content-Type-Options: nosniff`, and returns a restrictive CSP with `script-src 'none'`, `object-src 'none'`, `base-uri 'none'`, and `form-action 'none'`. |

## New defense-in-depth module

`AgenticDataDisparity.API/src/services/disparity_agent/api/file_security.py`

Responsibilities:

- validates generated run IDs;
- validates generated batch job IDs;
- resolves generated artifacts only as direct children of configured roots;
- verifies internally stored batch paths cannot leave their configured directory;
- validates download filenames before adding them to HTTP headers.

## Regression coverage

`AgenticDataDisparity.API/tests/unit_tests/test_sast_security_regressions.py`

The suite covers:

- traversal payloads such as `../etc/passwd`;
- encoded/markup-shaped run and job IDs;
- download/header-injection attempts;
- artifact containment;
- HTML escaping of script and event-handler shaped input;
- absence of the two response sinks identified by the scanner;
- runtime-generated AutoGen compatibility key behavior.

`python scripts/validate_sast_security_fixes.py` performs an additional static release gate for the reported finding classes.

## Behavior intentionally unchanged

- CPS remains Agentic read-only.
- Rewards DB writes still use `RewardsDbOperationsV2.UpdateMemberColumnAsync`.
- CrowdTwist writes still use `LoyaltyServiceProviderV3.UpdateUserProfilePropertiesAsync`.
- Business requires one chat approval.
- Customer Support, Technical, and Admin require chat approval plus final popup.
- Per-user Dry Run, global write kill switch, pre-write reread/drift checks, read-after-write verification, audit, adaptive memory, bounded RSI, MCP, and LLM-as-Judge remain in place.

## Required deployment checks

Run all of the following from the package root / Agent API directory as applicable:

```powershell
python .\scripts\validate_package_v11_62.py
python .\scripts\validate_v11_62_full_parity.py
python .\scripts\validate_deployment_pipeline_fix.py
python .\scripts\validate_sast_security_fixes.py
cd .\AgenticDataDisparity.API
python -m pytest -q -p no:asyncio
```

Then rerun the deployment team's SAST/SCA pipeline and the target Windows `.NET 8` build.

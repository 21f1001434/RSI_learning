# RUS v11.62.1 Deployment Pipeline Hotfix

## Deployment-team findings addressed

### 1. Unit-test job: async tests not natively supported
The shared pipeline invoked plain `pytest` without an async plugin, causing the
profile-governed update matrix to fail before the production service logic ran.

**Fix:** `test_profile_governed_updates.py` now uses a normal synchronous pytest
entry point and executes the real async service flow with `asyncio.run(...)`. The
regression no longer requires `pytest-asyncio`. `requirements-dev.txt` and
`scripts/test.ps1` were simplified accordingly.

### 2. SCA scan: four high-severity urllib3 findings
The screenshots show vulnerabilities resolved at urllib3 2.6.0, 2.6.3 and 2.7.0,
introduced transitively through `aia-auth-client==0.0.8`.

**Fix:** `requirements.txt` now directly pins `urllib3==2.7.0`. This forces the
transitive dependency onto the security floor required by the strictest reported
finding while preserving the existing Dell AIA authentication package.

### 3. Regression guards
`test_deployment_pipeline_guards.py` prevents both issues from silently returning:
- unit tests may not expose `async def test_*` functions that need a pytest plugin;
- the production manifest must retain the safe urllib3 pin.

## Unchanged business behavior
No role, approval, source-of-truth, write, memory, RSI, Dell AIA, CPS, Rewards DB,
CrowdTwist, frontend, or audit business logic was weakened by this hotfix.

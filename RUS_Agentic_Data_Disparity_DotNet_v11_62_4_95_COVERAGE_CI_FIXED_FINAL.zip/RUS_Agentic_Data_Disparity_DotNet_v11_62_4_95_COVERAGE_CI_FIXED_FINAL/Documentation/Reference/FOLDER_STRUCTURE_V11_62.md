# RUS v11.62 Production Folder Structure

```text
RUS_Agentic_Data_Disparity_DotNet_v11_62_FULL_ADAPTIVE_FINAL/
├── AgenticDataDisparity.API/
│   ├── .vscode/
│   ├── ci-cd/
│   │   └── templates/
│   ├── runtime/
│   │   ├── runs/                  # generated at runtime; ignored
│   │   └── memory/                # generated SQLite adaptive memory; ignored
│   ├── scripts/
│   ├── src/
│   │   ├── health/
│   │   │   └── routes.py
│   │   ├── services/
│   │   │   ├── llm_services.py
│   │   │   └── disparity_agent/
│   │   │       ├── agents/
│   │   │       │   ├── json_utils.py
│   │   │       │   ├── model_client.py
│   │   │       │   ├── orchestrator.py
│   │   │       │   └── playwright_fallback.py
│   │   │       ├── api/
│   │   │       │   ├── app.py
│   │   │       │   ├── batch_jobs.py
│   │   │       │   ├── chat_service.py
│   │   │       │   ├── config.py
│   │   │       │   ├── dependencies.py
│   │   │       │   ├── routes.py
│   │   │       │   ├── run_store.py
│   │   │       │   ├── schemas.py
│   │   │       │   ├── session_store.py
│   │   │       │   └── source_operations.py
│   │   │       ├── connectors/
│   │   │       │   ├── cps.py
│   │   │       │   ├── crowd_twist.py
│   │   │       │   ├── oauth.py
│   │   │       │   ├── odbc_utils.py
│   │   │       │   ├── rewards_db.py
│   │   │       │   └── tcps.py
│   │   │       ├── memory/
│   │   │       │   ├── __init__.py
│   │   │       │   ├── policy.py
│   │   │       │   ├── rsi.py
│   │   │       │   └── store.py
│   │   │       ├── api_knowledge.py
│   │   │       ├── batch.py
│   │   │       ├── comparator.py
│   │   │       ├── concurrency_policy.py
│   │   │       ├── config_server.py
│   │   │       ├── country_reference.py
│   │   │       ├── field_mapping.py
│   │   │       ├── identifier_input.py
│   │   │       ├── identity_resolution.py
│   │   │       ├── judgment.py
│   │   │       ├── mcp_server.py
│   │   │       ├── models.py
│   │   │       ├── normalization.py
│   │   │       ├── pipeline.py
│   │   │       ├── reporting.py
│   │   │       ├── security.py
│   │   │       ├── settings.py
│   │   │       ├── suggestions.py
│   │   │       └── use_cases.py
│   │   ├── shared/
│   │   ├── resources/
│   │   ├── app_settings.py
│   │   ├── main.py
│   │   ├── models.py
│   │   ├── prompt_manager.py
│   │   ├── prompts.py
│   │   └── routes.py
│   ├── tests/
│   │   ├── conftest.py
│   │   └── unit_tests/
│   ├── .dockerignore
│   ├── .env.example
│   ├── .gitignore
│   ├── .gitlab-ci.yml
│   ├── Dockerfile
│   ├── pytest.ini
│   ├── requirements.txt
│   ├── requirements-dev.txt
│   └── VERSION
├── DellUtilityService.API/
│   ├── AgenticIntegration/
│   ├── Configurations/
│   ├── Controllers/
│   ├── Data/
│   ├── Models/
│   ├── Services/
│   ├── wwwroot/
│   ├── Program.cs
│   └── DellUtilityService.API.csproj
├── Documentation/
│   ├── Architecture/
│   ├── Reference/
│   └── Validation/
├── scripts/
├── README_FIRST.md
├── Start-AgentAPI-Manual.ps1
├── Start-DellUtility-Manual.ps1
├── Start-RUS-v11_62.ps1
└── VERSION
```

## Runtime ownership

- Browser/UI calls only same-origin .NET endpoints.
- .NET proxies Agentic requests to FastAPI and supplies internal authentication + actor/profile context.
- Python performs analysis/orchestration and bounded learning.
- Physical Rewards DB/CrowdTwist writes are delegated back to the existing .NET writer bridge.
- CPS is never an Agentic write target.

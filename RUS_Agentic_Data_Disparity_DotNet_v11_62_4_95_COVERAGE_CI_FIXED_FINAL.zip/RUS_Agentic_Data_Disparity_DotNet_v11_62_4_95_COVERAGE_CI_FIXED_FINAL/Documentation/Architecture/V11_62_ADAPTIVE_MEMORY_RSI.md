# RUS v11.62 Adaptive Memory, Skill Induction and Bounded RSI

## Purpose

The adaptive layer improves repeated Agentic analysis without allowing an LLM to self-modify application behavior. It is a **measured execution-policy learner**, not an autonomous code-writing system.

The goal is to learn which **pre-approved reasoning strategy** and, optionally, which **deployment-approved Dell AIA model** performs best for a recurring PII-free evidence shape.

## Four memory layers

1. **Session working memory** — existing chat/run/approval state for the current user session. This remains in the existing session store and does not survive service restart.
2. **Persistent trajectory memory** — SQLite stores only PII-free task signatures, selected strategy/model, objective reward, judge result, contract quality, latency, source-availability shape and generic lessons.
3. **Learned skill memory** — aggregates successful strategy/model pairings for the same PII-free task signature. A skill becomes eligible only after a configurable minimum sample count.
4. **Governed write-quality memory** — stores source name, field name, outcome/verification, Dry Run flag, role and duration. It does not store member identifiers or before/after values.

## End-to-end adaptive flow

```text
Fresh user request
   -> deterministic CPS / Rewards DB / CrowdTwist evidence collection
   -> deterministic disparity rules
   -> build PII-free evidence-shape signature
   -> retrieve exact/similar replay lessons
   -> look for a sufficiently sampled learned skill
   -> bounded strategy selector
        -> bootstrap safe strategies
        -> bounded exploration
        -> measured exploitation
   -> optional bounded Dell AIA champion/challenger selector
        -> only deployment-configured model names
        -> default DELL_AIA_MODEL is the fail-safe champion
   -> Dell AIA Analysis Agent
   -> independent Dell AIA Judge
   -> deterministic judge enforcement
   -> objective outcome/reward calculation
   -> persist PII-free trajectory/reflection/skill statistics
   -> future equivalent runs can reuse the better measured route
```

## Static strategy registry

`memory/policy.py` defines the only executable reasoning strategies:

- `grounded_baseline`
- `grounded_concise`
- `grounded_claim_check`

RSI cannot create a fourth strategy at runtime. Adding a strategy requires a normal source-code change, review, tests and deployment.

## PII-free semantic replay

The task signature is built from evidence shape, for example search type + whether each source was found/unavailable + bounded mismatch/missing/format/unverifiable counters. It contains **no email address, Profile ID, CrowdTwist ID or source value**.

Replay uses exact matching first and then Jaccard similarity over those generic signature tokens. Lessons are short generic execution lessons such as "tighten claim-to-evidence alignment"; they never contain member data.

## Skill induction

`skill_stats` learns only this tuple:

```text
task_type + PII-free task_signature + safe strategy_id + approved model name
```

with attempt count, success count and objective reward. When the minimum evidence threshold is reached, a learned skill can nominate the previously successful strategy/model for an equivalent or sufficiently similar evidence shape.

A learned skill **cannot** nominate an unknown strategy or unknown model because both selections are checked against static/configured allow-lists before use.

## Champion/challenger Dell AIA selection

The default is still a single model (`DELL_AIA_MODEL`). Multi-model selection is optional and disabled by default.

When enabled, the only eligible challenger names come from:

```text
DELL_AIA_MODEL_CANDIDATES=model-b,model-c
ADAPTIVE_MODEL_SELECTION_ENABLED=true
```

The selector performs bounded bootstrap/exploration/exploitation over those names using measured reward. It never discovers, invents or edits model names.

If a selected challenger is not routed in the current Dell AIA environment, orchestration falls back to the configured default champion rather than inventing another route.

## Objective reward signals

`AdaptiveMemoryController.score_analysis()` uses execution-quality signals only:

- required MCP evidence collection succeeded,
- Dell AIA analysis succeeded,
- independent judge ACCEPTED/PARTIAL/REJECTED outcome,
- direct JSON contract versus locally normalized output,
- latency relative to the configured target.

The reward is never used to determine source-of-truth values, approvals or mutation permissions.

## Hard safety boundary

Adaptive memory / bounded RSI cannot:

- modify Python, .NET or frontend source code,
- mutate field mappings or truth-source rules,
- turn CPS into a write target,
- change role permissions,
- skip chat or popup approvals,
- disable Dry Run or the global write kill switch,
- create new API/tool endpoints,
- select arbitrary member correction values,
- add models to the deployment model allow-list,
- persist raw identifiers, source payloads, source values, secrets or chat text.

## Failure behavior

Memory is fail-open only relative to analysis optimization. If SQLite is unavailable, the request falls back to the safe baseline strategy and configured default model. The core deterministic analysis can continue and memory reports `DEGRADED_FAIL_OPEN`.

Governance remains fail-closed: source writes still require the existing role approval state machine, write controls, pre-write validation and post-write verification.

## Persistence

Default database:

`AgenticDataDisparity.API/runtime/memory/adaptive_memory.sqlite3`

The database is runtime-generated, ignored by Git/Docker packaging, retention-limited and record-count bounded. `skill_stats` entries also expire when they have not been used within the configured retention period.

## Operations and observability

- `GET /api/v1/health/ready` — overall API/readiness + safe adaptive-memory summary.
- `GET /api/v1/memory/status` — PII-safe memory, policy, model-performance and learned-skill telemetry.
- `.NET GET /api/agentic-ai/memory/status` — authenticated same-origin proxy for the browser/application layer.
- Data Disparity Agent UI shows session-message count, learned-run count, learned-skill count, bounded-RSI state and whether champion/challenger selection is active.

## Governed writes are unchanged

The adaptive layer is **not** a mutation engine. Rewards DB and CrowdTwist changes still flow through the profile approval state machine and then the existing .NET manual writers. CPS remains read-only. Pre-write re-read/drift checks, read-after-write verification and audit remain authoritative.

using Microsoft.EntityFrameworkCore;

namespace DellUtilityService.API.Data;

public class DellUtilityDbContext : DbContext
{
    public DellUtilityDbContext(DbContextOptions<DellUtilityDbContext> options)
        : base(options)
    {
    }

    public DbSet<Member> Members { get; set; }
    public DbSet<BulkOperation> BulkOperations { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Member>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.ProfileId).IsRequired();
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.HasIndex(e => e.ProfileId).IsUnique();
            entity.HasIndex(e => e.CrowdTwistID);
            entity.HasIndex(e => e.CountryCode);
        });
    }
}

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DellUtilityService.API.Data;

public class Member
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid Id { get; set; }

    [Required]
    public Guid ProfileId { get; set; }

    public string? CountryCode { get; set; }

    public long CrowdTwistID { get; set; }

    public long MemberKey { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime Created { get; set; } = DateTime.UtcNow;

    public DateTime LastUpdated { get; set; } = DateTime.UtcNow;

    [MaxLength(100), Required]
    public string UpdateChannel { get; set; }
    [MaxLength(150), Required]
    public string SourceUpdateBy { get; set; }
}

public class BulkOperation
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    public string OperationType { get; set; } = string.Empty;

    public string? Status { get; set; }

    public int TotalProcessed { get; set; }

    public int SuccessCount { get; set; }

    public int FailureCount { get; set; }

    public DateTime Created { get; set; } = DateTime.UtcNow;

    public string? ErrorMessage { get; set; }
}

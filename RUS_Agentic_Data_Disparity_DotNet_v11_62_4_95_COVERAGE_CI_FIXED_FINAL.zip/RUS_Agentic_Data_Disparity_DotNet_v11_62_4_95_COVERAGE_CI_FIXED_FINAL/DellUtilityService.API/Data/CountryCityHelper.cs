using System.Globalization;
using System.Text;

namespace Dell.Rewards.Domain.Entities.CT;

/// <summary>
/// Region-specific CrowdTwist city-ID lookup used by country updates.
/// The mapping is loaded from Data/CountryCityReference.csv, which is copied to
/// the build/publish output by the project file. Unknown countries fail closed.
/// </summary>
public enum CityIdSet
{
    SB,
    US1
}

public static class CountryCityHelper
{
    private sealed record CityIds(int Sb, int Us1);
    private static readonly Lazy<IReadOnlyDictionary<string, CityIds>> Data = new(Load, true);

    public static int GetCityIdByIso(string countryCode, CityIdSet set)
    {
        var iso = (countryCode ?? string.Empty).Trim().ToUpperInvariant();
        if (iso.Length != 2)
            throw new ArgumentException("A two-letter ISO-3166 country code is required.", nameof(countryCode));

        if (!Data.Value.TryGetValue(iso, out var ids))
            throw new KeyNotFoundException($"No CrowdTwist city mapping exists for ISO country '{iso}'.");

        return set == CityIdSet.US1 ? ids.Us1 : ids.Sb;
    }

    private static IReadOnlyDictionary<string, CityIds> Load()
    {
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "Data", "CountryCityReference.csv"),
            Path.Combine(Directory.GetCurrentDirectory(), "Data", "CountryCityReference.csv")
        };
        var path = candidates.FirstOrDefault(File.Exists)
            ?? throw new FileNotFoundException("CrowdTwist country/city reference file was not found.", candidates[0]);

        var result = new Dictionary<string, CityIds>(StringComparer.OrdinalIgnoreCase);
        var lines = File.ReadLines(path).Skip(1);
        foreach (var line in lines)
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            var cells = ParseCsvLine(line);
            if (cells.Count < 4) continue;
            var iso = cells[1].Trim().ToUpperInvariant();
            if (iso.Length != 2) continue;
            if (!int.TryParse(cells[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out var sb)) continue;
            if (!int.TryParse(cells[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out var us1)) us1 = sb;
            result[iso] = new CityIds(sb, us1);
        }
        if (result.Count == 0) throw new InvalidDataException("CrowdTwist country/city reference contains no usable mappings.");
        return result;
    }

    private static List<string> ParseCsvLine(string line)
    {
        var values = new List<string>();
        var current = new StringBuilder();
        var quoted = false;
        for (var i = 0; i < line.Length; i++)
        {
            var ch = line[i];
            if (ch == '"')
            {
                if (quoted && i + 1 < line.Length && line[i + 1] == '"') { current.Append('"'); i++; }
                else quoted = !quoted;
            }
            else if (ch == ',' && !quoted) { values.Add(current.ToString()); current.Clear(); }
            else current.Append(ch);
        }
        values.Add(current.ToString());
        return values;
    }
}

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace DellUtilityService.API.Services;

public interface IAuditPrivacyService
{
    object? Mask(object? value, string? key = null);
}

public sealed partial class AuditPrivacyService : IAuditPrivacyService
{
    private static readonly HashSet<string> SensitiveKeys = new(StringComparer.OrdinalIgnoreCase)
    {
        "before", "after", "target", "searchValue", "search_value", "requestedIdentifier",
        "requested_identifier", "email", "profileId", "profile_id", "crowdTwistId", "crowd_twist_id",
        "memberKey", "member_key", "phone", "postalCode", "postal_code", "cityId", "city_id",
        "firstName", "first_name", "lastName", "last_name", "value", "newValue", "new_value"
    };

    public object? Mask(object? value, string? key = null)
    {
        if (value is null) return null;
        JsonElement element;
        try
        {
            element = value is JsonElement jsonElement
                ? jsonElement
                : JsonSerializer.SerializeToElement(value, new JsonSerializerOptions(JsonSerializerDefaults.Web));
        }
        catch
        {
            return MaskString(Convert.ToString(value) ?? string.Empty, key);
        }
        return MaskElement(element, key);
    }

    private object? MaskElement(JsonElement element, string? key)
    {
        return element.ValueKind switch
        {
            JsonValueKind.Object => element.EnumerateObject().ToDictionary(
                property => property.Name,
                property => MaskElement(property.Value, property.Name),
                StringComparer.OrdinalIgnoreCase),
            JsonValueKind.Array => element.EnumerateArray().Select(item => MaskElement(item, key)).ToList(),
            JsonValueKind.String => MaskString(element.GetString() ?? string.Empty, key),
            JsonValueKind.Number => SensitiveKeys.Contains(key ?? string.Empty)
                ? MaskString(element.GetRawText(), key)
                : JsonSerializer.Deserialize<object>(element.GetRawText()),
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            JsonValueKind.Null => null,
            _ => MaskString(element.GetRawText(), key)
        };
    }

    private static string MaskString(string value, string? key)
    {
        if (string.IsNullOrWhiteSpace(value)) return value;
        var trimmed = value.Trim();
        if (trimmed.StartsWith("<masked:", StringComparison.OrdinalIgnoreCase)) return trimmed;
        if (EmailRegex().IsMatch(trimmed))
        {
            var at = trimmed.IndexOf('@');
            var local = at > 0 ? trimmed[..at] : trimmed;
            var domain = at > 0 ? trimmed[at..] : string.Empty;
            return $"{local[..1]}***{domain}";
        }
        if (GuidRegex().IsMatch(trimmed)) return $"{trimmed[..4]}…{trimmed[^4..]}";
        if (LongNumericRegex().IsMatch(trimmed)) return $"***{trimmed[^4..]}";
        if (!SensitiveKeys.Contains(key ?? string.Empty)) return trimmed;
        if (trimmed.Length <= 2) return "**";
        if (trimmed.Length <= 6) return $"{trimmed[..1]}***";
        return $"{trimmed[..2]}***{trimmed[^2..]}";
    }

    [GeneratedRegex(@"^[^\s@]+@[^\s@]+\.[^\s@]+$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex EmailRegex();

    [GeneratedRegex(@"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex GuidRegex();

    [GeneratedRegex(@"^\d{7,}$", RegexOptions.CultureInvariant)]
    private static partial Regex LongNumericRegex();
}

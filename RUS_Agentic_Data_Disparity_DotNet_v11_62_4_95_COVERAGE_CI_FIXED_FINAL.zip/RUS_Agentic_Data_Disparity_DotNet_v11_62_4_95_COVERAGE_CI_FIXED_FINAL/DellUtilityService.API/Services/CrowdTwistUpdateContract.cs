using DellUtilityService.API.Models;
using Newtonsoft.Json.Linq;

namespace DellUtilityService.API.Services;

/// <summary>
/// Single CrowdTwist update contract shared by the manual CrowdTwist tab and
/// the internal Agentic source-write bridge. Keeping country expansion and
/// value inspection here prevents the two update paths from drifting.
/// </summary>
public static class CrowdTwistUpdateContract
{
    public static bool IsCountryProperty(string? propertyName)
    {
        if (string.IsNullOrWhiteSpace(propertyName)) return false;
        var normalized = propertyName.Trim().ToLowerInvariant();
        return normalized is "country" or "countrycode" or "country_code";
    }

    public static Dictionary<string, string> ExpandProperties(string propertyName, string propertyValue)
    {
        if (IsCountryProperty(propertyName))
        {
            return ExpandCountryProperties(propertyValue);
        }

        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            [propertyName] = propertyValue
        };
    }

    public static Dictionary<string, string> ExpandCountryProperties(string countryCode)
    {
        var normalizedCountryCode = (countryCode ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(normalizedCountryCode))
        {
            throw new ArgumentException("Country code is required for a CrowdTwist country update.", nameof(countryCode));
        }

        var locationData = LocationGenerator(normalizedCountryCode);
        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["country_code"] = normalizedCountryCode,
            ["postal_code"] = locationData["postal_code"]?.ToString() ?? string.Empty,
            ["city_id"] = locationData["city_id"]?.ToString() ?? "0"
        };
    }

    public static object? ReadProperty(UserDetailsResponse? user, string propertyName)
    {
        if (user is null || string.IsNullOrWhiteSpace(propertyName)) return null;
        var normalized = propertyName.Replace("_", string.Empty).Replace("-", string.Empty);
        var property = typeof(UserDetailsResponse).GetProperties()
            .FirstOrDefault(item => item.Name.Replace("_", string.Empty).Equals(normalized, StringComparison.OrdinalIgnoreCase));
        return property?.GetValue(user);
    }

    private static JObject LocationGenerator(string countryCode)
    {
        if (countryCode == "US")
        {
            return new JObject
            {
                ["country_code"] = countryCode,
                ["postal_code"] = "10001",
                ["city_id"] = 0
            };
        }

        if (countryCode == "CA")
        {
            return new JObject
            {
                ["country_code"] = countryCode,
                ["postal_code"] = "M5V 1J9",
                ["city_id"] = 0
            };
        }

        return new JObject
        {
            ["country_code"] = countryCode,
            ["city_id"] = ResolveCountryCityId(countryCode),
            ["postal_code"] = null
        };
    }

    private static int ResolveCountryCityId(string countryCode)
    {
        return Dell.Rewards.Domain.Entities.CT.CountryCityHelper.GetCityIdByIso(
            countryCode,
            Dell.Rewards.Domain.Entities.CT.CityIdSet.SB);
    }
}

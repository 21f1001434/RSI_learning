namespace DellUtilityService.API.Services.Authentication;

public static class RusRoles
{
    public const string Customer = "Customer";
    public const string Business = "Business";
    public const string Technical = "Technical";
    public const string Admin = "Admin";

    public const string All = Customer + "," + Business + "," + Technical + "," + Admin;
    public const string BusinessOrHigher = Business + "," + Technical + "," + Admin;
    public const string TechnicalOrAdmin = Technical + "," + Admin;
    public const string CustomerTechnicalOrAdmin = Customer + "," + Technical + "," + Admin;

    public static readonly IReadOnlyList<string> Assignable =
        new[] { Customer, Business, Technical, Admin };

    public static string Normalize(string? role)
    {
        var value = (role ?? string.Empty).Trim();
        if (value.Equals(Admin, StringComparison.OrdinalIgnoreCase)) return Admin;
        if (value.Equals(Technical, StringComparison.OrdinalIgnoreCase) ||
            value.Equals("Technician", StringComparison.OrdinalIgnoreCase) ||
            value.Equals("Engineer", StringComparison.OrdinalIgnoreCase) ||
            value.Equals("Operator", StringComparison.OrdinalIgnoreCase)) return Technical;
        if (value.Equals(Business, StringComparison.OrdinalIgnoreCase) ||
            value.Equals("Business User", StringComparison.OrdinalIgnoreCase) ||
            value.Equals("Buisness", StringComparison.OrdinalIgnoreCase)) return Business;
        if (value.Equals(Customer, StringComparison.OrdinalIgnoreCase) ||
            value.Equals("Customer Support", StringComparison.OrdinalIgnoreCase) ||
            value.Equals("Support", StringComparison.OrdinalIgnoreCase) ||
            value.Equals("User", StringComparison.OrdinalIgnoreCase)) return Customer;
        return Customer;
    }

    public static bool IsAdmin(string? role) => Normalize(role) == Admin;
    public static bool IsTechnicalOrAdmin(string? role)
    {
        var normalized = Normalize(role);
        return normalized == Technical || normalized == Admin;
    }
    public static bool CanGovernAgenticWrites(string? role)
    {
        // v11.62: every authenticated RUS role may use governed Agentic writes.
        // Authentication and the per-profile Dry Run policy remain mandatory; CPS
        // is still read-only and only Rewards DB / CrowdTwist are writable.
        if (string.IsNullOrWhiteSpace(role)) return false;
        var normalized = Normalize(role);
        return normalized == Customer || normalized == Business || normalized == Technical || normalized == Admin;
    }

    public static RoleViewProfile Profile(string? role)
    {
        return Normalize(role) switch
        {
            Admin => new RoleViewProfile(
                Admin,
                "Administrator",
                "Full governance, all-user audit visibility, technical operations, and user administration.",
                "admin-control-center",
                DefaultAuditMasked: false,
                new RolePermissions(
                    ViewDashboard: true,
                    UseAgenticAnalysis: true,
                    UseBatchAnalysis: true,
                    UseApiKnowledge: true,
                    PlanAgenticUpdates: true,
                    ApproveAgenticUpdates: true,
                    ViewCpsPage: true,
                    ViewRewardsPage: true,
                    ViewCrowdTwistPage: true,
                    ViewUnifiedSearchPage: true,
                    ReadSourceData: true,
                    WriteSourceData: true,
                    ViewAudit: true,
                    ViewAllAudit: true,
                    SelectAuditPrivacy: false,
                    ViewTechnicalDetails: true,
                    SelectReportPrivacy: true,
                    ViewUnmaskedReports: true,
                    ManageUsers: true,
                    ExportAudit: true)),
            Technical => new RoleViewProfile(
                Technical,
                "Technical Operations",
                "Full source diagnostics and manual operations, Agentic analysis, governed writes, and technical evidence.",
                "technical-operations",
                DefaultAuditMasked: false,
                new RolePermissions(
                    ViewDashboard: true,
                    UseAgenticAnalysis: true,
                    UseBatchAnalysis: true,
                    UseApiKnowledge: true,
                    PlanAgenticUpdates: true,
                    ApproveAgenticUpdates: true,
                    ViewCpsPage: true,
                    ViewRewardsPage: true,
                    ViewCrowdTwistPage: true,
                    ViewUnifiedSearchPage: true,
                    ReadSourceData: true,
                    WriteSourceData: true,
                    ViewAudit: true,
                    ViewAllAudit: false,
                    SelectAuditPrivacy: true,
                    ViewTechnicalDetails: true,
                    SelectReportPrivacy: true,
                    ViewUnmaskedReports: true,
                    ManageUsers: false,
                    ExportAudit: true)),
            Business => new RoleViewProfile(
                Business,
                "Business Operations",
                "Business-focused Dashboard and Agentic AI, with the same manual source tools available to every signed-in role.",
                "business-insights",
                DefaultAuditMasked: true,
                new RolePermissions(
                    ViewDashboard: true,
                    UseAgenticAnalysis: true,
                    UseBatchAnalysis: true,
                    UseApiKnowledge: false,
                    PlanAgenticUpdates: true,
                    ApproveAgenticUpdates: true,
                    ViewCpsPage: true,
                    ViewRewardsPage: true,
                    ViewCrowdTwistPage: true,
                    ViewUnifiedSearchPage: true,
                    ReadSourceData: true,
                    WriteSourceData: true,
                    ViewAudit: true,
                    ViewAllAudit: false,
                    SelectAuditPrivacy: true,
                    ViewTechnicalDetails: false,
                    SelectReportPrivacy: true,
                    ViewUnmaskedReports: true,
                    ManageUsers: false,
                    ExportAudit: true)),
            _ => new RoleViewProfile(
                Customer,
                "Customer Support",
                "Customer-support Dashboard and Agentic AI with governed Rewards DB/CrowdTwist corrections and role-safe reporting.",
                "customer-support",
                DefaultAuditMasked: true,
                new RolePermissions(
                    ViewDashboard: true,
                    UseAgenticAnalysis: true,
                    UseBatchAnalysis: true,
                    UseApiKnowledge: false,
                    PlanAgenticUpdates: true,
                    ApproveAgenticUpdates: true,
                    ViewCpsPage: true,
                    ViewRewardsPage: true,
                    ViewCrowdTwistPage: true,
                    ViewUnifiedSearchPage: true,
                    ReadSourceData: true,
                    WriteSourceData: true,
                    ViewAudit: true,
                    ViewAllAudit: false,
                    SelectAuditPrivacy: true,
                    ViewTechnicalDetails: false,
                    SelectReportPrivacy: false,
                    ViewUnmaskedReports: false,
                    ManageUsers: false,
                    ExportAudit: true))
        };
    }
}

public sealed record RolePermissions(
    bool ViewDashboard,
    bool UseAgenticAnalysis,
    bool UseBatchAnalysis,
    bool UseApiKnowledge,
    bool PlanAgenticUpdates,
    bool ApproveAgenticUpdates,
    bool ViewCpsPage,
    bool ViewRewardsPage,
    bool ViewCrowdTwistPage,
    bool ViewUnifiedSearchPage,
    bool ReadSourceData,
    bool WriteSourceData,
    bool ViewAudit,
    bool ViewAllAudit,
    bool SelectAuditPrivacy,
    bool ViewTechnicalDetails,
    bool SelectReportPrivacy,
    bool ViewUnmaskedReports,
    bool ManageUsers,
    bool ExportAudit);

public sealed record RoleViewProfile(
    string Code,
    string Label,
    string Description,
    string DashboardMode,
    bool DefaultAuditMasked,
    RolePermissions Permissions);

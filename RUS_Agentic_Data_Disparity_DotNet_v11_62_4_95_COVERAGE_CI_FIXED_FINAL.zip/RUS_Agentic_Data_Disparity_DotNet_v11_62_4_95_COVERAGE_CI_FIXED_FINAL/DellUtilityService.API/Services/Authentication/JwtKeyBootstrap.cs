using System.Security.Cryptography;
using DellUtilityService.API.Configurations;

namespace DellUtilityService.API.Services.Authentication;

public static class JwtKeyBootstrap
{
    public static string Resolve(WebApplicationBuilder builder)
    {
        var configured = Environment.GetEnvironmentVariable("RUS_JWT_SIGNING_KEY")
            ?? builder.Configuration[$"{JwtAuthenticationOptions.SectionName}:SigningKey"];
        if (!string.IsNullOrWhiteSpace(configured))
        {
            if (configured.Length < 32)
            {
                throw new InvalidOperationException("RUS_JWT_SIGNING_KEY must contain at least 32 characters.");
            }
            return configured;
        }

        var path = Path.Combine(builder.Environment.ContentRootPath, "App_Data", "jwt-signing-key.txt");
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        if (File.Exists(path))
        {
            var existing = File.ReadAllText(path).Trim();
            if (existing.Length >= 32) return existing;
        }

        var generated = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
        File.WriteAllText(path, generated);
        return generated;
    }
}

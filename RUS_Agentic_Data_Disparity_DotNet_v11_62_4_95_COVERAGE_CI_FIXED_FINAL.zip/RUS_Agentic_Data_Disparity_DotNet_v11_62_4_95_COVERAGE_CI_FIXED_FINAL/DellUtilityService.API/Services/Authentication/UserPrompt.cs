namespace DellUtilityService.API.Services.Authentication;

public sealed class UserPrompt
{
    public string Id { get; set; } = $"prm-{Guid.NewGuid():N}";
    public string TargetUserId { get; set; } = string.Empty;
    public string TargetUsername { get; set; } = string.Empty;
    public string CreatedByUserId { get; set; } = string.Empty;
    public string CreatedByUsername { get; set; } = string.Empty;
    public string CreatedByDisplayName { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string Severity { get; set; } = "info";
    public string? ActionUrl { get; set; }
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime? ExpiresAtUtc { get; set; }
    public DateTime? ReadUtc { get; set; }
    public bool IsDismissed { get; set; }

    public bool IsExpired(DateTime utcNow) => ExpiresAtUtc is not null && ExpiresAtUtc <= utcNow;
}

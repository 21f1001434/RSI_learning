using System.Security.Cryptography;

namespace DellUtilityService.API.Services.Authentication;

public interface IPasswordHashService
{
    bool Verify(string password, UserAccount account);
    void SetPassword(UserAccount account, string password);
}

public sealed class PasswordHashService : IPasswordHashService
{
    private const int SaltSize = 16;
    private const int HashSize = 32;
    private const int DefaultIterations = 210_000;

    public bool Verify(string password, UserAccount account)
    {
        if (string.IsNullOrEmpty(password) ||
            string.IsNullOrWhiteSpace(account.PasswordSalt) ||
            string.IsNullOrWhiteSpace(account.PasswordHash))
        {
            return false;
        }

        try
        {
            var salt = Convert.FromBase64String(account.PasswordSalt);
            var expected = Convert.FromBase64String(account.PasswordHash);
            var iterations = Math.Clamp(account.PasswordIterations, 100_000, 1_000_000);
            var actual = Rfc2898DeriveBytes.Pbkdf2(
                password,
                salt,
                iterations,
                HashAlgorithmName.SHA256,
                expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch (FormatException)
        {
            return false;
        }
    }

    public void SetPassword(UserAccount account, string password)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(password);
        var salt = RandomNumberGenerator.GetBytes(SaltSize);
        var hash = Rfc2898DeriveBytes.Pbkdf2(
            password,
            salt,
            DefaultIterations,
            HashAlgorithmName.SHA256,
            HashSize);
        account.PasswordSalt = Convert.ToBase64String(salt);
        account.PasswordHash = Convert.ToBase64String(hash);
        account.PasswordIterations = DefaultIterations;
        account.PasswordChangedUtc = DateTime.UtcNow;
    }
}

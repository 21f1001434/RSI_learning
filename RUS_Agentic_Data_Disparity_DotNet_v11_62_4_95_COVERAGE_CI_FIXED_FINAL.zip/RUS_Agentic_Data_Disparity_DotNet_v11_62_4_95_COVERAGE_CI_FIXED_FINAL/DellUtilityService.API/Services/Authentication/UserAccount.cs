namespace DellUtilityService.API.Services.Authentication;

public sealed class UserAccount
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Username { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string Role { get; set; } = RusRoles.Customer;
    public bool IsActive { get; set; } = true;
    // Per-user Agentic execution safety profile. Admin is always forced to false (live governed writes).
    public bool DryRunEnabled { get; set; } = false;
    public string PasswordSalt { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public int PasswordIterations { get; set; } = 210_000;
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime? PasswordChangedUtc { get; set; }
}

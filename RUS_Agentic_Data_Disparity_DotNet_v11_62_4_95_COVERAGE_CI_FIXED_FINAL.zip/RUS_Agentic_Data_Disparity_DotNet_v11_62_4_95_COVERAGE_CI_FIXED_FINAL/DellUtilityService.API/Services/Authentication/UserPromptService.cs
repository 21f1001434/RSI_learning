using System.Text.Json;

namespace DellUtilityService.API.Services.Authentication;

public interface IUserPromptService
{
    Task<UserPrompt> CreateAsync(UserPrompt prompt, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<UserPrompt>> ListForUserAsync(string userId, bool includeRead, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<UserPrompt>> ListAllAsync(CancellationToken cancellationToken = default);
    Task<UserPrompt?> MarkReadAsync(string promptId, string userId, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(string promptId, CancellationToken cancellationToken = default);
    Task<int> DeleteForUserAsync(string userId, CancellationToken cancellationToken = default);
}

public sealed class JsonUserPromptService : IUserPromptService
{
    private readonly string _path;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web) { WriteIndented = true };

    public JsonUserPromptService(IWebHostEnvironment environment)
    {
        _path = Path.Combine(environment.ContentRootPath, "App_Data", "user-prompts.json");
    }

    public async Task<UserPrompt> CreateAsync(UserPrompt prompt, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var prompts = await ReadUnlockedAsync(cancellationToken);
            prompt.Id = string.IsNullOrWhiteSpace(prompt.Id) ? $"prm-{Guid.NewGuid():N}" : prompt.Id.Trim();
            prompt.CreatedUtc = prompt.CreatedUtc == default ? DateTime.UtcNow : prompt.CreatedUtc.ToUniversalTime();
            prompt.Severity = NormalizeSeverity(prompt.Severity);
            prompt.ActionUrl = NormalizeActionUrl(prompt.ActionUrl);
            prompts.Add(Clone(prompt));
            await WriteUnlockedAsync(prompts, cancellationToken);
            return Clone(prompt);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<IReadOnlyList<UserPrompt>> ListForUserAsync(
        string userId,
        bool includeRead,
        CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var now = DateTime.UtcNow;
            var prompts = await ReadUnlockedAsync(cancellationToken);
            return prompts
                .Where(item => item.TargetUserId.Equals(userId, StringComparison.OrdinalIgnoreCase))
                .Where(item => !item.IsDismissed && !item.IsExpired(now))
                .Where(item => includeRead || item.ReadUtc is null)
                .OrderByDescending(item => item.CreatedUtc)
                .Select(Clone)
                .ToList();
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<IReadOnlyList<UserPrompt>> ListAllAsync(CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var prompts = await ReadUnlockedAsync(cancellationToken);
            return prompts.OrderByDescending(item => item.CreatedUtc).Select(Clone).ToList();
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<UserPrompt?> MarkReadAsync(
        string promptId,
        string userId,
        CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var prompts = await ReadUnlockedAsync(cancellationToken);
            var prompt = prompts.FirstOrDefault(item =>
                item.Id.Equals(promptId, StringComparison.OrdinalIgnoreCase) &&
                item.TargetUserId.Equals(userId, StringComparison.OrdinalIgnoreCase));
            if (prompt is null) return null;
            prompt.ReadUtc ??= DateTime.UtcNow;
            await WriteUnlockedAsync(prompts, cancellationToken);
            return Clone(prompt);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<bool> DeleteAsync(string promptId, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var prompts = await ReadUnlockedAsync(cancellationToken);
            var removed = prompts.RemoveAll(item => item.Id.Equals(promptId, StringComparison.OrdinalIgnoreCase));
            if (removed == 0) return false;
            await WriteUnlockedAsync(prompts, cancellationToken);
            return true;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<int> DeleteForUserAsync(string userId, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var prompts = await ReadUnlockedAsync(cancellationToken);
            var removed = prompts.RemoveAll(item => item.TargetUserId.Equals(userId, StringComparison.OrdinalIgnoreCase));
            if (removed > 0) await WriteUnlockedAsync(prompts, cancellationToken);
            return removed;
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task<List<UserPrompt>> ReadUnlockedAsync(CancellationToken cancellationToken)
    {
        if (!File.Exists(_path)) return new List<UserPrompt>();
        await using var stream = new FileStream(
            _path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete,
            16 * 1024, useAsync: true);
        return await JsonSerializer.DeserializeAsync<List<UserPrompt>>(stream, _json, cancellationToken)
            ?? new List<UserPrompt>();
    }

    private async Task WriteUnlockedAsync(List<UserPrompt> prompts, CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
        var temporary = _path + ".tmp";
        await using (var stream = File.Create(temporary))
        {
            await JsonSerializer.SerializeAsync(stream, prompts, _json, cancellationToken);
        }
        File.Move(temporary, _path, overwrite: true);
    }

    private static string NormalizeSeverity(string? value) => (value ?? string.Empty).Trim().ToLowerInvariant() switch
    {
        "success" => "success",
        "warning" => "warning",
        "error" or "critical" => "error",
        _ => "info"
    };

    private static string? NormalizeActionUrl(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var normalized = value.Trim();
        if (!normalized.StartsWith("/", StringComparison.Ordinal) || normalized.StartsWith("//", StringComparison.Ordinal))
        {
            throw new ArgumentException("Action URL must be a same-origin relative path beginning with '/'.");
        }
        return normalized;
    }

    private static UserPrompt Clone(UserPrompt prompt) => new()
    {
        Id = prompt.Id,
        TargetUserId = prompt.TargetUserId,
        TargetUsername = prompt.TargetUsername,
        CreatedByUserId = prompt.CreatedByUserId,
        CreatedByUsername = prompt.CreatedByUsername,
        CreatedByDisplayName = prompt.CreatedByDisplayName,
        Title = prompt.Title,
        Message = prompt.Message,
        Severity = prompt.Severity,
        ActionUrl = prompt.ActionUrl,
        CreatedUtc = prompt.CreatedUtc,
        ExpiresAtUtc = prompt.ExpiresAtUtc,
        ReadUtc = prompt.ReadUtc,
        IsDismissed = prompt.IsDismissed
    };
}

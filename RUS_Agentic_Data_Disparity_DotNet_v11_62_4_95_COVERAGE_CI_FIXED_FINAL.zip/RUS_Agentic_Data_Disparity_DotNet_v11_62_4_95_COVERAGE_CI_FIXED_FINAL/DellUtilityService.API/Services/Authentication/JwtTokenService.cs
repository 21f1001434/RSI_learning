using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using DellUtilityService.API.Configurations;
using DellUtilityService.API.Models.Auth;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace DellUtilityService.API.Services.Authentication;

public interface IJwtTokenService
{
    LoginResponse Issue(UserAccount user);
}

public sealed class JwtTokenService : IJwtTokenService
{
    private readonly JwtAuthenticationOptions _options;
    private readonly SigningCredentials _credentials;

    public JwtTokenService(IOptions<JwtAuthenticationOptions> options)
    {
        _options = options.Value;
        if (string.IsNullOrWhiteSpace(_options.SigningKey))
        {
            throw new InvalidOperationException("JWT signing key was not initialized.");
        }
        _credentials = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.SigningKey)),
            SecurityAlgorithms.HmacSha256);
    }

    public LoginResponse Issue(UserAccount user)
    {
        var now = DateTime.UtcNow;
        var expires = now.Add(_options.AccessTokenLifetime);
        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, user.Id),
            new(ClaimTypes.NameIdentifier, user.Id),
            new(ClaimTypes.Name, user.Username),
            new("preferred_username", user.Username),
            new("display_name", user.DisplayName),
            new(ClaimTypes.Role, RusRoles.Normalize(user.Role)),
            new("view_profile", RusRoles.Profile(user.Role).DashboardMode),
            new("dry_run_enabled", (!RusRoles.IsAdmin(user.Role) && user.DryRunEnabled).ToString().ToLowerInvariant()),
            new("pwd_changed", (user.PasswordChangedUtc?.ToUniversalTime().Ticks ?? 0L).ToString(System.Globalization.CultureInfo.InvariantCulture)),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N")),
            new("token_type", "access")
        };
        if (!string.IsNullOrWhiteSpace(user.Email))
        {
            claims.Add(new Claim(ClaimTypes.Email, user.Email));
            claims.Add(new Claim(JwtRegisteredClaimNames.Email, user.Email));
        }

        var token = new JwtSecurityToken(
            issuer: _options.Issuer,
            audience: _options.Audience,
            claims: claims,
            notBefore: now,
            expires: expires,
            signingCredentials: _credentials);

        return new LoginResponse(
            new JwtSecurityTokenHandler().WriteToken(token),
            "Bearer",
            expires,
            new AuthenticatedUserResponse(
                user.Id, user.Username, user.DisplayName, RusRoles.Normalize(user.Role), user.Email,
                !RusRoles.IsAdmin(user.Role) && user.DryRunEnabled,
                EffectiveWriteMode(user),
                RusRoles.Profile(user.Role)));
    }

    private static string EffectiveWriteMode(UserAccount user) =>
        RusRoles.IsAdmin(user.Role) ? "live" : user.DryRunEnabled ? "dry_run" : "live";
}

using System.Text.Json;
using DellUtilityService.API.Configurations;
using Microsoft.Extensions.Options;

namespace DellUtilityService.API.Services.Authentication;

public interface IUserStore
{
    Task<UserAccount?> FindByUsernameAsync(string username, CancellationToken cancellationToken = default);
    Task<UserAccount?> FindByIdAsync(string id, CancellationToken cancellationToken = default);
    Task<UserAccount?> FindAnyByIdAsync(string id, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<UserAccount>> ListAsync(bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<UserAccount> CreateAsync(
        string username,
        string displayName,
        string? email,
        string role,
        string password,
        CancellationToken cancellationToken = default);
    Task<UserAccount> UpdateProfileAsync(
        string id,
        string displayName,
        string? email,
        string role,
        CancellationToken cancellationToken = default);
    Task<UserAccount> SetActiveAsync(string id, bool active, CancellationToken cancellationToken = default);
    Task<UserAccount> SetDryRunAsync(string id, bool enabled, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(string id, CancellationToken cancellationToken = default);
    Task UpdatePasswordAsync(string id, string password, CancellationToken cancellationToken = default);
}

public sealed class DuplicateUserException : InvalidOperationException
{
    public DuplicateUserException(string message) : base(message) { }
}

public sealed class FileUserStore : IUserStore
{
    private readonly string _storePath;
    private readonly string _seedPath;
    private readonly string _deletedUsersPath;
    private readonly IPasswordHashService _passwords;
    private readonly ILogger<FileUserStore> _logger;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly object _cacheSync = new();
    private List<UserAccount>? _cachedUsers;
    private DateTime _cachedFileStampUtc;
    private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };

    public FileUserStore(
        IWebHostEnvironment environment,
        IOptions<JwtAuthenticationOptions> options,
        IPasswordHashService passwords,
        ILogger<FileUserStore> logger)
    {
        _passwords = passwords;
        _logger = logger;
        _storePath = Resolve(environment.ContentRootPath, options.Value.UserStoreFile);
        _seedPath = Resolve(environment.ContentRootPath, options.Value.SeedUsersFile);
        _deletedUsersPath = Path.Combine(environment.ContentRootPath, "App_Data", "auth-users.deleted.json");
        EnsureStoreExists();
    }

    public async Task<UserAccount?> FindByUsernameAsync(string username, CancellationToken cancellationToken = default)
    {
        var users = await ReadAsync(cancellationToken);
        return users.FirstOrDefault(user =>
            user.IsActive && string.Equals(user.Username, username.Trim(), StringComparison.OrdinalIgnoreCase));
    }

    public async Task<UserAccount?> FindByIdAsync(string id, CancellationToken cancellationToken = default)
    {
        var user = await FindAnyByIdAsync(id, cancellationToken);
        return user?.IsActive == true ? user : null;
    }

    public async Task<UserAccount?> FindAnyByIdAsync(string id, CancellationToken cancellationToken = default)
    {
        var users = await ReadAsync(cancellationToken);
        return users.FirstOrDefault(user => string.Equals(user.Id, id, StringComparison.OrdinalIgnoreCase));
    }

    public async Task<IReadOnlyList<UserAccount>> ListAsync(bool includeInactive = false, CancellationToken cancellationToken = default) =>
        (await ReadAsync(cancellationToken))
            .Where(user => includeInactive || user.IsActive)
            .OrderBy(user => RoleSortOrder(user.Role))
            .ThenBy(user => user.Username, StringComparer.OrdinalIgnoreCase)
            .ToList();

    public async Task<UserAccount> CreateAsync(
        string username,
        string displayName,
        string? email,
        string role,
        string password,
        CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var users = await ReadUnlockedAsync(cancellationToken);
            username = username.Trim();
            email = NormalizeEmail(email);
            if (users.Any(user => string.Equals(user.Username, username, StringComparison.OrdinalIgnoreCase)))
            {
                throw new DuplicateUserException("That username is already registered.");
            }
            if (!string.IsNullOrWhiteSpace(email) && users.Any(user =>
                    !string.IsNullOrWhiteSpace(user.Email) &&
                    string.Equals(user.Email, email, StringComparison.OrdinalIgnoreCase)))
            {
                throw new DuplicateUserException("That email address is already registered.");
            }

            var user = new UserAccount
            {
                Id = $"usr-{Guid.NewGuid():N}",
                Username = username,
                DisplayName = displayName.Trim(),
                Email = email,
                Role = NormalizeRole(role),
                IsActive = true,
                CreatedUtc = DateTime.UtcNow
            };
            _passwords.SetPassword(user, password);
            users.Add(user);
            await WriteUnlockedAsync(users, cancellationToken);
            return Clone(user);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<UserAccount> UpdateProfileAsync(
        string id,
        string displayName,
        string? email,
        string role,
        CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var users = await ReadUnlockedAsync(cancellationToken);
            var user = users.FirstOrDefault(item => string.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase))
                ?? throw new InvalidOperationException("The user no longer exists.");
            email = NormalizeEmail(email);
            if (!string.IsNullOrWhiteSpace(email) && users.Any(item =>
                    !string.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase) &&
                    !string.IsNullOrWhiteSpace(item.Email) &&
                    string.Equals(item.Email, email, StringComparison.OrdinalIgnoreCase)))
            {
                throw new DuplicateUserException("That email address is already registered.");
            }
            user.DisplayName = displayName.Trim();
            user.Email = email;
            user.Role = NormalizeRole(role);
            if (RusRoles.IsAdmin(user.Role)) user.DryRunEnabled = false;
            await WriteUnlockedAsync(users, cancellationToken);
            return Clone(user);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<UserAccount> SetActiveAsync(string id, bool active, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var users = await ReadUnlockedAsync(cancellationToken);
            var user = users.FirstOrDefault(item => string.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase))
                ?? throw new InvalidOperationException("The user no longer exists.");
            user.IsActive = active;
            await WriteUnlockedAsync(users, cancellationToken);
            return Clone(user);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<UserAccount> SetDryRunAsync(string id, bool enabled, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var users = await ReadUnlockedAsync(cancellationToken);
            var user = users.FirstOrDefault(item => string.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase))
                ?? throw new InvalidOperationException("The user no longer exists.");

            // Administrators always use governed live execution. This invariant is
            // enforced in the persistent store as well as the API/UI boundary.
            user.DryRunEnabled = RusRoles.IsAdmin(user.Role) ? false : enabled;
            await WriteUnlockedAsync(users, cancellationToken);
            return Clone(user);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<bool> DeleteAsync(string id, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var users = await ReadUnlockedAsync(cancellationToken);
            var target = users.FirstOrDefault(item => string.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase));
            if (target is null) return false;
            users.Remove(target);
            var deleted = await ReadDeletedUsersUnlockedAsync(cancellationToken);
            deleted.Add($"id:{target.Id.ToLowerInvariant()}");
            deleted.Add($"username:{target.Username.ToLowerInvariant()}");
            await WriteDeletedUsersUnlockedAsync(deleted, cancellationToken);
            await WriteUnlockedAsync(users, cancellationToken);
            return true;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task UpdatePasswordAsync(string id, string password, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var users = await ReadUnlockedAsync(cancellationToken);
            var user = users.FirstOrDefault(item => string.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase))
                ?? throw new InvalidOperationException("The user no longer exists.");
            _passwords.SetPassword(user, password);
            await WriteUnlockedAsync(users, cancellationToken);
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task<List<UserAccount>> ReadAsync(CancellationToken cancellationToken)
    {
        // JWT validation runs for every authenticated API call. Serve the common read
        // path from an immutable in-memory snapshot so concurrent browser requests do
        // not queue behind the JSON file semaphore and get cancelled during navigation.
        if (TryReadCache(out var cached)) return cached;

        await _gate.WaitAsync(cancellationToken);
        try
        {
            if (TryReadCache(out cached)) return cached;
            return await ReadUnlockedAsync(cancellationToken);
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task<List<UserAccount>> ReadUnlockedAsync(CancellationToken cancellationToken)
    {
        if (TryReadCache(out var cached)) return cached;
        if (!File.Exists(_storePath)) EnsureStoreExists();
        await using var stream = new FileStream(
            _storePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete,
            bufferSize: 16 * 1024, useAsync: true);
        var users = await JsonSerializer.DeserializeAsync<List<UserAccount>>(stream, _json, cancellationToken)
            ?? new List<UserAccount>();
        var changed = false;
        foreach (var user in users)
        {
            // v11.16 used the generic User role. Preserve the original full-access
            // Adheesh account as Technical while migrating all other legacy users
            // to the least-privileged Customer Support profile.
            var normalized = user.Username.Equals("Adheesh", StringComparison.OrdinalIgnoreCase) &&
                             user.Role.Equals("User", StringComparison.OrdinalIgnoreCase)
                ? RusRoles.Technical
                : RusRoles.Normalize(user.Role);
            if (!string.Equals(user.Role, normalized, StringComparison.Ordinal))
            {
                user.Role = normalized;
                changed = true;
            }
            if (RusRoles.IsAdmin(user.Role) && user.DryRunEnabled)
            {
                user.DryRunEnabled = false;
                changed = true;
            }
        }

        // Merge newly shipped seed accounts without overwriting existing users,
        // password changes, role assignments, or active/inactive state. This lets
        // an upgraded v11.16 installation receive the v11.17 Business and Customer
        // Support sample accounts while preserving all local administration work.
        if (File.Exists(_seedPath))
        {
            var deletedUsers = await ReadDeletedUsersUnlockedAsync(cancellationToken);
            await using var seedStream = File.OpenRead(_seedPath);
            var seedUsers = await JsonSerializer.DeserializeAsync<List<UserAccount>>(
                seedStream, _json, cancellationToken) ?? new List<UserAccount>();
            foreach (var seed in seedUsers)
            {
                var seedWasDeleted = deletedUsers.Contains($"id:{seed.Id.ToLowerInvariant()}") ||
                                     deletedUsers.Contains($"username:{seed.Username.ToLowerInvariant()}");
                var alreadyExists = users.Any(user =>
                    user.Id.Equals(seed.Id, StringComparison.OrdinalIgnoreCase) ||
                    user.Username.Equals(seed.Username, StringComparison.OrdinalIgnoreCase));
                if (alreadyExists) continue;
                if (seedWasDeleted) continue;

                seed.Role = RusRoles.Normalize(seed.Role);
                if (RusRoles.IsAdmin(seed.Role)) seed.DryRunEnabled = false;
                users.Add(Clone(seed));
                changed = true;
                _logger.LogInformation(
                    "Added missing seeded JWT user {Username} with role {Role} during store migration.",
                    seed.Username,
                    seed.Role);
            }
        }

        if (changed)
        {
            await WriteUnlockedAsync(users, CancellationToken.None);
        }
        else
        {
            UpdateCache(users);
        }
        return CloneUsers(users);
    }

    private async Task WriteUnlockedAsync(List<UserAccount> users, CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(_storePath)!);
        var temporary = _storePath + ".tmp";
        await using (var stream = File.Create(temporary))
        {
            await JsonSerializer.SerializeAsync(stream, users, _json, cancellationToken);
        }
        File.Move(temporary, _storePath, overwrite: true);
        UpdateCache(users);
    }

    private async Task<HashSet<string>> ReadDeletedUsersUnlockedAsync(CancellationToken cancellationToken)
    {
        if (!File.Exists(_deletedUsersPath)) return new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        await using var stream = new FileStream(
            _deletedUsersPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete,
            8 * 1024, useAsync: true);
        var values = await JsonSerializer.DeserializeAsync<List<string>>(stream, _json, cancellationToken)
            ?? new List<string>();
        return new HashSet<string>(values, StringComparer.OrdinalIgnoreCase);
    }

    private async Task WriteDeletedUsersUnlockedAsync(HashSet<string> values, CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(_deletedUsersPath)!);
        var temporary = _deletedUsersPath + ".tmp";
        await using (var stream = File.Create(temporary))
        {
            await JsonSerializer.SerializeAsync(stream, values.OrderBy(value => value).ToList(), _json, cancellationToken);
        }
        File.Move(temporary, _deletedUsersPath, overwrite: true);
    }

    private void EnsureStoreExists()
    {
        if (File.Exists(_storePath)) return;
        Directory.CreateDirectory(Path.GetDirectoryName(_storePath)!);
        if (!File.Exists(_seedPath))
        {
            throw new FileNotFoundException("The JWT user seed file is missing.", _seedPath);
        }
        File.Copy(_seedPath, _storePath, overwrite: false);
        _logger.LogInformation("Initialized the JWT user store at {UserStorePath}.", _storePath);
    }


    private bool TryReadCache(out List<UserAccount> users)
    {
        lock (_cacheSync)
        {
            if (_cachedUsers is null)
            {
                users = new List<UserAccount>();
                return false;
            }

            DateTime currentStamp;
            try
            {
                currentStamp = File.Exists(_storePath)
                    ? File.GetLastWriteTimeUtc(_storePath)
                    : DateTime.MinValue;
            }
            catch (IOException)
            {
                currentStamp = _cachedFileStampUtc;
            }

            if (currentStamp != _cachedFileStampUtc)
            {
                _cachedUsers = null;
                users = new List<UserAccount>();
                return false;
            }

            users = CloneUsers(_cachedUsers);
            return true;
        }
    }

    private void UpdateCache(IEnumerable<UserAccount> users)
    {
        lock (_cacheSync)
        {
            _cachedUsers = CloneUsers(users);
            try
            {
                _cachedFileStampUtc = File.Exists(_storePath)
                    ? File.GetLastWriteTimeUtc(_storePath)
                    : DateTime.MinValue;
            }
            catch (IOException)
            {
                _cachedFileStampUtc = DateTime.UtcNow;
            }
        }
    }

    private static List<UserAccount> CloneUsers(IEnumerable<UserAccount> users) =>
        users.Select(Clone).ToList();

    public static string NormalizeRole(string? role) => RusRoles.Normalize(role);


    private static int RoleSortOrder(string? role) => RusRoles.Normalize(role) switch
    {
        RusRoles.Admin => 0,
        RusRoles.Technical => 1,
        RusRoles.Business => 2,
        _ => 3
    };

    private static string? NormalizeEmail(string? email) =>
        string.IsNullOrWhiteSpace(email) ? null : email.Trim().ToLowerInvariant();

    private static UserAccount Clone(UserAccount user) => new()
    {
        Id = user.Id,
        Username = user.Username,
        DisplayName = user.DisplayName,
        Email = user.Email,
        Role = user.Role,
        IsActive = user.IsActive,
        DryRunEnabled = RusRoles.IsAdmin(user.Role) ? false : user.DryRunEnabled,
        PasswordSalt = user.PasswordSalt,
        PasswordHash = user.PasswordHash,
        PasswordIterations = user.PasswordIterations,
        CreatedUtc = user.CreatedUtc,
        PasswordChangedUtc = user.PasswordChangedUtc
    };

    private static string Resolve(string root, string configured) =>
        Path.IsPathRooted(configured) ? configured : Path.Combine(root, configured);
}

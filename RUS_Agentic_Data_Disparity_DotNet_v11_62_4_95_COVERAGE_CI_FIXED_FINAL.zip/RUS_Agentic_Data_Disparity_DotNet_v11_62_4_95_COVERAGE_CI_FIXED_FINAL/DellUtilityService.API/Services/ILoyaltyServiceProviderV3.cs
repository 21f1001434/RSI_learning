using DellUtilityService.API.Models;

namespace DellUtilityService.API.Services;

public interface ILoyaltyServiceProviderV3
{
    Task<UserDetailsResponse?> SearchLoyaltyMemberAsync(Search.SearchType searchType, string searchValue);
    Task<bool> UpdateUserProfilePropertyAsync(int crowdTwistId, string propertyName, string propertyValue);
    Task<bool> UpdateUserProfilePropertiesAsync(int crowdTwistId, Dictionary<string, string> properties);
}

public class CrowdTwistUser
{
    public int CrowdTwistId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string? ProfileId { get; set; }
    public bool Status { get; set; }
}

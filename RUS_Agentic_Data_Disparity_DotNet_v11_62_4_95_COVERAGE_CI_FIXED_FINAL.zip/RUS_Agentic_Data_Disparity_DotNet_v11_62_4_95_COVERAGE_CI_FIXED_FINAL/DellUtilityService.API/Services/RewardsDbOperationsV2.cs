using Microsoft.EntityFrameworkCore;
using DellUtilityService.API.Data;

namespace DellUtilityService.API.Services;

public class RewardsDbOperationsV2 : IRewardsDbOperationsV2
{
    private readonly DellUtilityDbContext _context;
    private readonly ILogger<RewardsDbOperationsV2> _logger;

    public RewardsDbOperationsV2(DellUtilityDbContext context, ILogger<RewardsDbOperationsV2> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Member?> GetMemberByIdAsync(Guid id)
    {
        return await _context.Members.FindAsync(id);
    }

    public async Task<Member?> GetMemberByProfileIdAsync(Guid profileId)
    {
        try
        {
            var res = await _context.Members.FirstOrDefaultAsync(m => m.ProfileId == profileId);
           
        }
        catch(Exception ex)
        {
            _logger.LogError("", ex.Message);
        }
        return await _context.Members.FirstOrDefaultAsync(m => m.ProfileId == profileId);
    }
    public async Task<Member?> GetMemberByCrowdTwistIdAsync(long crowdTiwstId)
    {
        return await _context.Members.FirstOrDefaultAsync(m => m.CrowdTwistID == crowdTiwstId);
    }

    public Task<Member?> GetMemberByEmailAsync(string email)
    {
        // Member currently has no email column in this data model. Keep the contract
        // asynchronous without creating a fake async state machine.
        return Task.FromResult<Member?>(null);
    }

    public async Task<List<Member>> SearchMembersAsync(string searchTerm)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return new List<Member>();
            }

            // Try to parse as Guid (for id or profileId)
            if (Guid.TryParse(searchTerm, out Guid guidValue))
            {
                var results = new List<Member>();
                
                // Search by Id (database primary key)
                var byId = await _context.Members.FindAsync(guidValue);
                if (byId != null) results.Add(byId);
                
                // Search by ProfileId - can have multiple records
                var byProfileIds = await _context.Members.Where(m => m.ProfileId == guidValue).ToListAsync();
                foreach (var member in byProfileIds)
                {
                    if (!results.Any(r => r.Id == member.Id))
                    {
                        results.Add(member);
                    }
                }
                
                return results;
            }
            
            // Try to parse as long (for CrowdTwistId)
            if (long.TryParse(searchTerm, out long longValue))
            {
                var results = await _context.Members.Where(m => m.CrowdTwistID == longValue).ToListAsync();
                return results;
            }
            
            return new List<Member>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error searching members: {ex.Message}");
            return new List<Member>();
        }
    }

    public async Task<bool> UpdateMemberColumnAsync(Guid id, string columnName, string newValue)
    {
        try
        {
            var member = await _context.Members.FirstOrDefaultAsync(m => m.Id == id);
            if (member == null) return false;

            var columnNameLower = columnName.ToLower();
            switch (columnNameLower)
            {
                case "country":
                case "countrycode":
                    member.CountryCode = newValue;
                    break;
                case "isactive":
                case "is_active":
                    if (bool.TryParse(newValue, out bool isActive))
                        member.IsActive = isActive;
                    break;
                case "crowdtwistid":
                    if (long.TryParse(newValue, out long crowdTwistId))
                        member.CrowdTwistID = crowdTwistId;
                    break;
                case "memberkey":
                    if (long.TryParse(newValue, out long memberKey))
                        member.MemberKey = memberKey;
                    break;
                case "profileid":
                    member.ProfileId = Guid.Parse(newValue);
                    break;
                default:
                    _logger.LogWarning($"Unsupported column name: {columnName}");
                    return false;
            }

            member.LastUpdated = DateTime.UtcNow;
            member.UpdateChannel = "Utility Service";
            member.SourceUpdateBy = "Utility Service";
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error updating member column: {ex.Message}");
            return false;
        }
    }

    public async Task<bool> UpdateMemberColumnByIdAsync(Guid id, string columnName, string newValue)
    {
        try
        {
            var member = await _context.Members.FindAsync(id);
            if (member == null) return false;

            var columnNameLower = columnName.ToLower();
            switch (columnNameLower)
            {
                case "country":
                case "countrycode":
                    member.CountryCode = newValue;
                    break;
                case "isactive":
                case "is_active":
                    if (bool.TryParse(newValue, out bool isActive))
                        member.IsActive = isActive;
                    break;
                case "crowdtwistid":
                    if (long.TryParse(newValue, out long crowdTwistId))
                        member.CrowdTwistID = crowdTwistId;
                    break;
                case "memberkey":
                    if (long.TryParse(newValue, out long memberKey))
                        member.MemberKey = memberKey;
                    break;
                case "profileid":
                    if (Guid.TryParse(newValue, out Guid profileId))
                        member.ProfileId = profileId;
                    break;
                default:
                    _logger.LogWarning($"Unsupported column name: {columnName}");
                    return false;
            }

            member.LastUpdated = DateTime.UtcNow;
            await _context.SaveChangesAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error updating member column by Id: {ex.Message}");
            return false;
        }
    }

    public async Task<BulkOperation> BulkUpdateMemberColumnAsync(List<MemberColumnUpdateRequest> requests)
    {
        var bulkOperation = new BulkOperation
        {
            OperationType = "BulkUpdateMemberColumn",
            Status = "InProgress",
            TotalProcessed = requests.Count,
            SuccessCount = 0,
            FailureCount = 0
        };

        try
        {
            foreach (var request in requests)
            {
                var result = await UpdateMemberColumnAsync(request.Id, request.ColumnName, request.NewValue);
                if (result)
                    bulkOperation.SuccessCount++;
                else
                    bulkOperation.FailureCount++;
            }

            bulkOperation.Status = "Completed";
            _context.BulkOperations.Add(bulkOperation);
            await _context.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            bulkOperation.Status = "Failed";
            bulkOperation.ErrorMessage = ex.Message;
            _logger.LogError(ex, $"Error in bulk update: {ex.Message}");
            _context.BulkOperations.Add(bulkOperation);
            await _context.SaveChangesAsync();
        }

        return bulkOperation;
    }
}

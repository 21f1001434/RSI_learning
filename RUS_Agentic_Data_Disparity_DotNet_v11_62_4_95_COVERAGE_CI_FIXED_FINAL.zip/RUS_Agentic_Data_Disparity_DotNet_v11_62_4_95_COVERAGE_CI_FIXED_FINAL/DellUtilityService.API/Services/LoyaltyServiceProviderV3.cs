using DellUtilityService.API.Configurations;
using DellUtilityService.API.Models;
using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;

namespace DellUtilityService.API.Services;

public class LoyaltyServiceProviderV3 : ILoyaltyServiceProviderV3
{
    private static readonly CTAuthCache _authCache = new();
    private static CTAuthCacheExt2 _authCacheExt2 = new CTAuthCacheExt2();
    private static CTAuthCacheExt _authCacheExt = new CTAuthCacheExt();
    private readonly HttpClient _httpClient;
    private readonly VaultConfigurations _vaultConfigurations;
    private readonly ILogger<LoyaltyServiceProviderV3> _logger;

    public LoyaltyServiceProviderV3(HttpClient httpClient, IOptions<VaultConfigurations> vaultConfigurations, ILogger<LoyaltyServiceProviderV3> logger)
    {
        _httpClient = httpClient;
        _vaultConfigurations = vaultConfigurations.Value;
        _logger = logger;
    }

    private string? GetAuthToken()
    {
        if (_authCache.IsValid)
        {
            return _authCache.Token;
        }

        var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(_vaultConfigurations.CTLayer7ClientId + ":" + _vaultConfigurations.CTLayer7Secret);
        string base64EncAuthId = Convert.ToBase64String(plainTextBytes);

        var stringContent = new FormUrlEncodedContent(new[] {
            new KeyValuePair<string,string>("grant_type","client_credentials"),
        });

        var request = new HttpRequestMessage(HttpMethod.Post, _vaultConfigurations.CTLayer7AuthTokenURL)
        {
            Content = stringContent,
            Headers = {
                { "Accept", "application/json" },
                { "Authorization", "Basic " + base64EncAuthId }
            }
        };

        try
        {
            using var response = _httpClient.SendAsync(request).Result;
            if (response.StatusCode == System.Net.HttpStatusCode.OK && response.Content != null)
            {
                using var responseStream = response.Content.ReadAsStreamAsync().Result;
                //var output = await response.Content.ReadAsStringAsync(CancellationToken.None).ConfigureAwait(false);
                var responseData = JsonSerializer.DeserializeAsync<CrowdTwistAuthResponse>(responseStream).Result;
                if (responseData != null)
                {
                    _authCache.Expires = DateTime.UtcNow.AddSeconds(Math.Max(60, responseData.ExpiresIn - 60));
                    _authCache.Token = responseData.AccessToken;
                    return responseData.AccessToken;
                }
            }
            else
            {
                var errorResponse = response.Content.ReadAsStringAsync().Result;
                _logger.LogWarning($"CT Layer7 Authentication Call to {request.RequestUri} failed for {_vaultConfigurations.CTLayer7ClientId}, Response Code: {response.StatusCode}, Response Message: {errorResponse ?? "null"}");
                return null;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error Making CT Layer7 Authentication api call to {_vaultConfigurations.CTLayer7AuthTokenURL}, Exception: {ex.Message}");
            return null;
        }
        
        return null;
    }
    public string? GetAuthTokenExt2()
    {
        if (_authCacheExt2.IsValid && !string.IsNullOrWhiteSpace(_authCacheExt2.Token))
        {
            return _authCacheExt2.Token;
        }

        // Some Spring Config environments expose only the base CrowdTwist read
        // credentials while others expose the dedicated Ext2 pair. Prefer Ext2,
        // but fall back to the base read client so the manual CrowdTwist tab does
        // not crash with a null reference when Ext2-specific values are absent.
        var clientId = !string.IsNullOrWhiteSpace(_vaultConfigurations.CTLayer7Ext2ClientId)
            ? _vaultConfigurations.CTLayer7Ext2ClientId
            : _vaultConfigurations.CTLayer7ClientId;
        var clientSecret = !string.IsNullOrWhiteSpace(_vaultConfigurations.CTLayer7Ext2Secret)
            ? _vaultConfigurations.CTLayer7Ext2Secret
            : _vaultConfigurations.CTLayer7Secret;

        if (string.IsNullOrWhiteSpace(_vaultConfigurations.CTLayer7AuthTokenURL) ||
            string.IsNullOrWhiteSpace(clientId) ||
            string.IsNullOrWhiteSpace(clientSecret))
        {
            _logger.LogWarning("CrowdTwist read authentication is not configured. Required: CTLayer7AuthTokenURL and Ext2/base read client credentials.");
            return null;
        }

        var plainTextBytes = Encoding.UTF8.GetBytes(clientId + ":" + clientSecret);
        var base64EncAuthId = Convert.ToBase64String(plainTextBytes);
        var stringContent = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("grant_type", "client_credentials")
        });
        var request = new HttpRequestMessage(HttpMethod.Post, _vaultConfigurations.CTLayer7AuthTokenURL)
        {
            Content = stringContent,
            Headers =
            {
                { "Accept", "application/json" },
                { "Authorization", "Basic " + base64EncAuthId }
            }
        };

        try
        {
            using var response = _httpClient.SendAsync(request).Result;
            if (response.StatusCode != HttpStatusCode.OK || response.Content is null)
            {
                var errorResponse = response.Content is null ? string.Empty : response.Content.ReadAsStringAsync().Result;
                _logger.LogWarning("CrowdTwist read authentication failed. HTTP {StatusCode}. Response: {Response}", response.StatusCode, errorResponse);
                return null;
            }

            using var responseStream = response.Content.ReadAsStreamAsync().Result;
            var responseData = JsonSerializer.DeserializeAsync<CrowdTwistAuthResponse>(responseStream).Result;
            if (responseData is null || string.IsNullOrWhiteSpace(responseData.AccessToken))
            {
                _logger.LogWarning("CrowdTwist read authentication returned HTTP 200 but no access token.");
                return null;
            }

            _authCacheExt2.Expires = DateTime.UtcNow.AddSeconds(Math.Max(60, responseData.ExpiresIn - 60));
            _authCacheExt2.Token = responseData.AccessToken;
            return responseData.AccessToken;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "CrowdTwist read authentication call failed.");
            return null;
        }
    }

    public string? GetAuthTokenExt()
    {
        if (_authCacheExt.IsValid && !string.IsNullOrWhiteSpace(_authCacheExt.Token))
        {
            return _authCacheExt.Token;
        }

        if (string.IsNullOrWhiteSpace(_vaultConfigurations.CTLayer7AuthTokenURL) ||
            string.IsNullOrWhiteSpace(_vaultConfigurations.CTLayer7ExtClientId) ||
            string.IsNullOrWhiteSpace(_vaultConfigurations.CTLayer7ExtSecret))
        {
            _logger.LogWarning("CrowdTwist write authentication is not configured. Required: CTLayer7AuthTokenURL, CTLayer7ExtClientId and CTLayer7ExtSecret.");
            return null;
        }

        var plainTextBytes = Encoding.UTF8.GetBytes(_vaultConfigurations.CTLayer7ExtClientId + ":" + _vaultConfigurations.CTLayer7ExtSecret);
        var base64EncAuthId = Convert.ToBase64String(plainTextBytes);
        var stringContent = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("grant_type", "client_credentials")
        });
        var request = new HttpRequestMessage(HttpMethod.Post, _vaultConfigurations.CTLayer7AuthTokenURL)
        {
            Content = stringContent,
            Headers =
            {
                { "Accept", "application/json" },
                { "Authorization", "Basic " + base64EncAuthId }
            }
        };

        try
        {
            using var response = _httpClient.SendAsync(request).Result;
            if (response.StatusCode != HttpStatusCode.OK || response.Content is null)
            {
                var errorResponse = response.Content is null ? string.Empty : response.Content.ReadAsStringAsync().Result;
                _logger.LogWarning("CrowdTwist write authentication failed. HTTP {StatusCode}. Response: {Response}", response.StatusCode, errorResponse);
                return null;
            }

            using var responseStream = response.Content.ReadAsStreamAsync().Result;
            var responseData = JsonSerializer.DeserializeAsync<CrowdTwistAuthResponse>(responseStream).Result;
            if (responseData is null || string.IsNullOrWhiteSpace(responseData.AccessToken))
            {
                _logger.LogWarning("CrowdTwist write authentication returned HTTP 200 but no access token.");
                return null;
            }

            _authCacheExt.Expires = DateTime.UtcNow.AddSeconds(Math.Max(60, responseData.ExpiresIn - 60));
            _authCacheExt.Token = responseData.AccessToken;
            return responseData.AccessToken;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "CrowdTwist write authentication call failed.");
            return null;
        }
    }

    public async Task<UserDetailsResponse?> SearchLoyaltyMemberAsync(Search.SearchType searchType, string searchValue)
    {
        if (string.IsNullOrWhiteSpace(searchValue))
        {
            throw new ArgumentException("A CrowdTwist search value is required.", nameof(searchValue));
        }

        // Ext2 is the preferred read endpoint. Older Spring Config profiles may
        // expose only CTLayer7ApiURL; use it as a read-only compatibility fallback.
        var baseAddress = !string.IsNullOrWhiteSpace(_vaultConfigurations.CTLayer7ApiExt2URL)
            ? _vaultConfigurations.CTLayer7ApiExt2URL
            : _vaultConfigurations.CTLayer7ApiURL;
        if (string.IsNullOrWhiteSpace(baseAddress))
        {
            throw new InvalidOperationException(
                "CrowdTwist read endpoint is not configured. Expected CTLayer7ApiExt2URL (preferred) or CTLayer7ApiURL from Spring Config.");
        }
        if (string.IsNullOrWhiteSpace(_vaultConfigurations.CrowdTwistApiKey))
        {
            throw new InvalidOperationException("CrowdTwistApiKey is not configured by Spring Config.");
        }

        var token = GetAuthTokenExt2();
        if (string.IsNullOrWhiteSpace(token))
        {
            throw new InvalidOperationException(
                "CrowdTwist read authentication failed. Verify the Layer7 auth URL and Ext2/base read credentials loaded from Spring Config.");
        }

        var idType = searchType switch
        {
            Search.SearchType.Id => Search.Id,
            Search.SearchType.Email => Search.Email,
            Search.SearchType.ProfileId or Search.SearchType.ThirdPartyId => Search.ThirdPartyId,
            _ => Search.Email
        };
        var escapedValue = Uri.EscapeDataString(searchValue.Trim());
        var escapedApiKey = Uri.EscapeDataString(_vaultConfigurations.CrowdTwistApiKey);
        var fullUrl = $"{baseAddress.TrimEnd('/')}/v2/users/{escapedValue}?id_type={idType}&api_key={escapedApiKey}";

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, fullUrl);
            request.Headers.TryAddWithoutValidation("Accept", "application/json");
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            using var response = await _httpClient.SendAsync(request, CancellationToken.None).ConfigureAwait(false);
            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }
            if (!response.IsSuccessStatusCode)
            {
                var output = await response.Content.ReadAsStringAsync(CancellationToken.None).ConfigureAwait(false);
                _logger.LogWarning("CrowdTwist search failed. HTTP {StatusCode}. Response: {Response}", response.StatusCode, output);
                throw new HttpRequestException(
                    $"CrowdTwist search returned HTTP {(int)response.StatusCode} ({response.StatusCode}).",
                    null,
                    response.StatusCode);
            }

            var user = await response.Content.ReadFromJsonAsync<UserDetailsResponse>(cancellationToken: CancellationToken.None).ConfigureAwait(false);
            if (user is null)
            {
                _logger.LogWarning("CrowdTwist search returned a successful response with an empty member payload.");
            }
            return user;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "CrowdTwist search returned an invalid JSON payload.");
            throw new HttpRequestException("CrowdTwist search returned an invalid response payload.", ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "CrowdTwist search call failed.");
            throw new HttpRequestException("CrowdTwist search could not be completed.", ex);
        }
    }

    public async Task<bool> UpdateUserProfilePropertyAsync(int crowdTwistId, string propertyName, string propertyValue)
    {
        return await UpdateUserProfilePropertiesAsync(crowdTwistId, new Dictionary<string, string> { { propertyName, propertyValue } });
    }

    public async Task<bool> UpdateUserProfilePropertiesAsync(int crowdTwistId, Dictionary<string, string> properties)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(_vaultConfigurations.CTLayer7ApiExtURL) ||
                string.IsNullOrWhiteSpace(_vaultConfigurations.CrowdTwistApiKey))
            {
                throw new InvalidOperationException(
                    "CrowdTwist write endpoint is not configured. Expected CTLayer7ApiExtURL and CrowdTwistApiKey from Spring Config.");
            }

            var token = GetAuthTokenExt();
            if (string.IsNullOrWhiteSpace(token))
            {
                throw new InvalidOperationException(
                    "CrowdTwist write authentication failed. Verify CTLayer7ExtClientId/CTLayer7ExtSecret and CTLayer7AuthTokenURL.");
            }

            var apiUrl = $"{_vaultConfigurations.CTLayer7ApiExtURL.TrimEnd('/')}/v2/users/{crowdTwistId}?api_key={Uri.EscapeDataString(_vaultConfigurations.CrowdTwistApiKey)}";

            var payload = new Dictionary<string, object>();

            foreach (var property in properties)
            {
                var propertyName = property.Key.ToLower();
                var propertyValue = property.Value;

                string apiFieldName = propertyName switch
                {
                    "firstname" or "first_name" => "first_name",
                    "lastname" or "last_name" => "last_name",
                    "email" or "emailaddress" or "email_address" => "email_address",
                    "country" => "country_code",
                    "profileid" or "profile_id" or "third_party_id" => "third_party_id",
                    "is_active" or "isactive" or "status" => "is_active",
                    "phone" or "phonenumber" or "phone_number" or "mobilephone" or "mobilephonenumber" or "mobile_phone_number" => "mobile_phone_number",
                    "postalcode" or "postal_code" => "postal_code",
                    "cityid" or "city_id" => "city_id",
                    _ => propertyName
                };

                // Convert third_party_id to uppercase
                if (apiFieldName == "third_party_id" || apiFieldName == "profileid" && !string.IsNullOrEmpty(propertyValue))
                {
                    propertyValue = propertyValue.ToUpper();
                }

                if (apiFieldName == "is_active" && bool.TryParse(propertyValue, out bool boolValue))
                {
                    payload[apiFieldName] = boolValue;
                }
                else if (apiFieldName == "city_id" && long.TryParse(propertyValue, out long longValue))
                {
                    payload[apiFieldName] = longValue;
                }
                else
                {
                    payload[apiFieldName] = propertyValue;
                }
            }

            var jsonContent = JsonSerializer.Serialize(payload);
            var request = new HttpRequestMessage(HttpMethod.Put, apiUrl)
            {
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json"),
                Headers = {
                    { "Accept", "*/*" },
                    { "Authorization", "Bearer " + token }
                }
            };

            var response = await _httpClient.SendAsync(request, CancellationToken.None).ConfigureAwait(false);

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation($"Successfully updated properties for CrowdTwistId {crowdTwistId}");
                return true;
            }

            var errorContent = await response.Content.ReadAsStringAsync(CancellationToken.None).ConfigureAwait(false);
            _logger.LogWarning($"Error updating properties for CrowdTwistId {crowdTwistId}. Status: {response.StatusCode}, Error: {errorContent}");
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error updating properties for CrowdTwistId {crowdTwistId}");
            throw new Exception($"Error updating properties: {ex.Message}", ex);
        }
    }
}

public class CTAuthCache
{
    public string Token { get; set; } = string.Empty;
    public DateTime Expires { get; set; }
    public bool IsValid => DateTime.UtcNow < Expires;
}
internal class CTAuthCacheExt2
{
    public string Token { get; set; } = string.Empty;
    public DateTime Expires { get; set; }

    public bool IsValid
    {
        get { return DateTime.UtcNow < Expires.ToUniversalTime(); }
    }
}
internal class CTAuthCacheExt
{
    public string Token { get; set; } = string.Empty;
    public DateTime Expires { get; set; }

    public bool IsValid
    {
        get { return DateTime.UtcNow < Expires.ToUniversalTime(); }
    }
}

public class CrowdTwistAuthResponse
{
    [System.Text.Json.Serialization.JsonPropertyName("access_token")]
    public string AccessToken { get; set; } = string.Empty;
    [System.Text.Json.Serialization.JsonPropertyName("expires_in")]
    public int ExpiresIn { get; set; }
    [System.Text.Json.Serialization.JsonPropertyName("token_type")]
    public string TokenType { get; set; } = string.Empty;
}

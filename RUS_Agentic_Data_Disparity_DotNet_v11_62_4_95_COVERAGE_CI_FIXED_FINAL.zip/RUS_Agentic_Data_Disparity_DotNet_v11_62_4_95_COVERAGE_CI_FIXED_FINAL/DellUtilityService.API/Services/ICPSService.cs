using DellUtilityService.API.Models;

namespace DellUtilityService.API.Services;

public interface ICPSService
{
    Task<CPSProfileData?> CreateUserAsync(CPSUserRequest request);
    Task<CPSProfileData?> GetUserAsync(string email);
    Task<CPSProfileData?> GetUserByProfileIdAsync(Guid profileId);
}

public class CPSUserRequest
{
    public string Email { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
}

public class CPSUser
{
    public string Email { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string? ProfileId { get; set; }
    public bool IsActive { get; set; }
}

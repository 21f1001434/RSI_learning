using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace DellUtilityService.API.Services;

public sealed class AuditActor
{
    public string Name { get; init; } = "Unknown user";
    public string? DisplayName { get; init; }
    public string? UserId { get; init; }
    public string? Username { get; init; }
    public string? Email { get; init; }
    public string? Role { get; init; }
    public bool DryRunEnabled { get; init; }
    public string Channel { get; init; } = "manual-ui";
    public bool IsAuthenticated { get; init; }
}

public sealed class AuditTrailEntry
{
    public string AuditId { get; set; } = $"AUD-{Guid.NewGuid():N}".ToUpperInvariant();
    public DateTime TimestampUtc { get; set; } = DateTime.UtcNow;
    public string Actor { get; set; } = "Unknown user";
    public string? ActorDisplayName { get; set; }
    public string? ActorId { get; set; }
    public string? ActorUsername { get; set; }
    public string? ActorEmail { get; set; }
    public string? ActorRole { get; set; }
    public string Channel { get; set; } = "manual-ui";
    public string Source { get; set; } = "Unknown";
    public string Action { get; set; } = "Unknown";
    public string Status { get; set; } = "Unknown";
    public string? Target { get; set; }
    public string? Field { get; set; }
    public object? Before { get; set; }
    public object? After { get; set; }
    public string? Reason { get; set; }
    public string? CorrelationId { get; set; }
    public string? Verification { get; set; }
    public Dictionary<string, object?> Details { get; set; } = new();
}

public sealed class AuditTrailQueryResult
{
    public List<AuditTrailEntry> Entries { get; init; } = new();
    public int Total { get; init; }
    public Dictionary<string, int> StatusCounts { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, int> SourceCounts { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, int> ActorCounts { get; init; } = new(StringComparer.OrdinalIgnoreCase);
}

public interface IAuditActorResolver
{
    AuditActor Resolve();
}

public sealed class AuditActorResolver : IAuditActorResolver
{
    private readonly IHttpContextAccessor _accessor;

    public AuditActorResolver(IHttpContextAccessor accessor) => _accessor = accessor;

    public AuditActor Resolve()
    {
        var context = _accessor.HttpContext;
        var principal = context?.User;
        var authenticated = principal?.Identity?.IsAuthenticated == true;
        var channel = First(context?.Request.Headers["X-RUS-Channel"].FirstOrDefault(), "manual-ui")!;

        if (authenticated)
        {
            var username = First(
                principal!.FindFirstValue("preferred_username"),
                principal!.Identity?.Name,
                principal.FindFirstValue(ClaimTypes.Name));
            var displayName = First(principal.FindFirstValue("display_name"), username);
            return new AuditActor
            {
                Name = username ?? "Unknown user",
                DisplayName = displayName,
                UserId = First(principal.FindFirstValue(ClaimTypes.NameIdentifier), principal.FindFirstValue("sub")),
                Username = username,
                Email = First(principal.FindFirstValue(ClaimTypes.Email), principal.FindFirstValue("email")),
                Role = First(principal.FindFirstValue(ClaimTypes.Role), principal.FindFirstValue("role")),
                DryRunEnabled = string.Equals(principal.FindFirstValue("dry_run_enabled"), "true", StringComparison.OrdinalIgnoreCase),
                Channel = channel,
                IsAuthenticated = true
            };
        }

        var fallbackActor = First(
            context?.Request.Headers["X-RUS-Actor"].FirstOrDefault(),
            context?.Request.Headers["X-MS-CLIENT-PRINCIPAL-NAME"].FirstOrDefault(),
            context?.Request.Headers["X-Forwarded-User"].FirstOrDefault(),
            "Unknown user");
        return new AuditActor
        {
            Name = fallbackActor!,
            DisplayName = fallbackActor,
            Username = fallbackActor,
            Email = First(
                context?.Request.Headers["X-RUS-Actor-Email"].FirstOrDefault(),
                context?.Request.Headers["X-Forwarded-Email"].FirstOrDefault()),
            Channel = channel,
            IsAuthenticated = false
        };
    }

    private static string? First(params string?[] values) =>
        values.FirstOrDefault(value => !string.IsNullOrWhiteSpace(value))?.Trim();
}

public interface IAuditTrailService
{
    Task AppendAsync(AuditTrailEntry entry, CancellationToken cancellationToken = default);
    Task<AuditTrailQueryResult> QueryAsync(
        int limit = 100,
        string? source = null,
        string? status = null,
        string? actor = null,
        string? action = null,
        DateTime? fromUtc = null,
        DateTime? toUtc = null,
        CancellationToken cancellationToken = default);
}

public sealed class JsonlAuditTrailService : IAuditTrailService
{
    private readonly string _path;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web)
    {
        DefaultIgnoreCondition = JsonIgnoreCondition.Never,
        WriteIndented = false
    };
    private readonly ILogger<JsonlAuditTrailService> _logger;
    private readonly IAuditActorResolver _actorResolver;

    public JsonlAuditTrailService(
        IWebHostEnvironment environment,
        IConfiguration configuration,
        ILogger<JsonlAuditTrailService> logger,
        IAuditActorResolver actorResolver)
    {
        _logger = logger;
        _actorResolver = actorResolver;
        var configured = configuration["AuditTrail:File"];
        _path = string.IsNullOrWhiteSpace(configured)
            ? Path.Combine(environment.ContentRootPath, "App_Data", "audit-trail.jsonl")
            : Path.IsPathRooted(configured)
                ? configured
                : Path.Combine(environment.ContentRootPath, configured);
    }

    public async Task AppendAsync(AuditTrailEntry entry, CancellationToken cancellationToken = default)
    {
        try
        {
            // The authenticated JWT identity is authoritative. Client-supplied actor headers
            // may identify legacy calls but can never override an authenticated principal.
            var actor = _actorResolver.Resolve();
            if (actor.IsAuthenticated)
            {
                entry.Actor = actor.Name;
                entry.ActorDisplayName = actor.DisplayName;
                entry.ActorId = actor.UserId;
                entry.ActorUsername = actor.Username;
                entry.ActorEmail = actor.Email;
                entry.ActorRole = actor.Role;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(entry.Actor) || entry.Actor == "Unknown user") entry.Actor = actor.Name;
                entry.ActorDisplayName ??= actor.DisplayName;
                entry.ActorId ??= actor.UserId;
                entry.ActorUsername ??= actor.Username;
                entry.ActorEmail ??= actor.Email;
                entry.ActorRole ??= actor.Role;
            }
            if (string.IsNullOrWhiteSpace(entry.Channel)) entry.Channel = actor.Channel;
            entry.Details["authenticatedUser"] = actor.IsAuthenticated;
            entry.Details["actorUsername"] = entry.ActorUsername;
            entry.Details["actorRole"] = entry.ActorRole;

            Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
            var line = JsonSerializer.Serialize(entry, _jsonOptions) + Environment.NewLine;
            await _gate.WaitAsync(cancellationToken);
            try
            {
                await File.AppendAllTextAsync(_path, line, cancellationToken);
            }
            finally
            {
                _gate.Release();
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            _logger.LogWarning("Audit append was cancelled for {AuditId}.", entry.AuditId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unable to append audit entry {AuditId} to {AuditPath}.", entry.AuditId, _path);
        }
    }

    public async Task<AuditTrailQueryResult> QueryAsync(
        int limit = 100,
        string? source = null,
        string? status = null,
        string? actor = null,
        string? action = null,
        DateTime? fromUtc = null,
        DateTime? toUtc = null,
        CancellationToken cancellationToken = default)
    {
        limit = Math.Clamp(limit, 1, 1000);
        var entries = new List<AuditTrailEntry>();
        if (File.Exists(_path))
        {
            try
            {
                await _gate.WaitAsync(cancellationToken);
                try
                {
                    foreach (var line in await File.ReadAllLinesAsync(_path, cancellationToken))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        try
                        {
                            var item = JsonSerializer.Deserialize<AuditTrailEntry>(line, _jsonOptions);
                            if (item is not null) entries.Add(item);
                        }
                        catch (JsonException)
                        {
                            // A malformed historical row must not block the audit screen.
                        }
                    }
                }
                finally
                {
                    _gate.Release();
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogError(ex, "Unable to read audit trail from {AuditPath}.", _path);
            }
        }

        IEnumerable<AuditTrailEntry> filtered = entries;
        if (!string.IsNullOrWhiteSpace(source)) filtered = filtered.Where(x => Contains(x.Source, source));
        if (!string.IsNullOrWhiteSpace(status)) filtered = filtered.Where(x => Contains(x.Status, status));
        if (!string.IsNullOrWhiteSpace(actor)) filtered = filtered.Where(x =>
            Contains(x.Actor, actor) || Contains(x.ActorDisplayName, actor) || Contains(x.ActorUsername, actor) || Contains(x.ActorEmail, actor));
        if (!string.IsNullOrWhiteSpace(action)) filtered = filtered.Where(x => Contains(x.Action, action));
        if (fromUtc.HasValue) filtered = filtered.Where(x => x.TimestampUtc >= fromUtc.Value.ToUniversalTime());
        if (toUtc.HasValue) filtered = filtered.Where(x => x.TimestampUtc <= toUtc.Value.ToUniversalTime());

        var all = filtered.OrderByDescending(x => x.TimestampUtc).ToList();
        return new AuditTrailQueryResult
        {
            Entries = all.Take(limit).ToList(),
            Total = all.Count,
            StatusCounts = all.GroupBy(x => x.Status ?? "Unknown", StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.Count(), StringComparer.OrdinalIgnoreCase),
            SourceCounts = all.GroupBy(x => x.Source ?? "Unknown", StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.Count(), StringComparer.OrdinalIgnoreCase),
            ActorCounts = all.GroupBy(x => x.ActorUsername ?? x.Actor ?? "Unknown user", StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.Count(), StringComparer.OrdinalIgnoreCase)
        };
    }

    private static bool Contains(string? value, string expected) =>
        value?.Contains(expected, StringComparison.OrdinalIgnoreCase) == true;
}

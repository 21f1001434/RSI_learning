using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using DellUtilityService.API.Configurations;
using DellUtilityService.API.Models;

namespace DellUtilityService.API.Services;

public class CPSService : ICPSService
{
    private static readonly Dictionary<string, DCIAuthCache> TokenCache = new();
    private readonly HttpClient _httpClient;
    private readonly VaultConfigurations _vaultConfigurations;
    private readonly ILogger<CPSService> _logger;

    public CPSService(HttpClient httpClient, IOptions<VaultConfigurations> vaultConfigurations, ILogger<CPSService> logger)
    {
        _httpClient = httpClient;
        _vaultConfigurations = vaultConfigurations.Value;
        _logger = logger;
    }

    private string? GetToken()
    {
        if (TokenCache.TryGetValue("DCI_TOKEN", out DCIAuthCache? cache))
        {
            if (cache != null && cache.IsValid) return cache.AccessToken;
        }

        var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(_vaultConfigurations.DCIAppClientId + ":" + _vaultConfigurations.DCIAppClientSecret);
        string base64EncAuthId = Convert.ToBase64String(plainTextBytes);

        var stringContent = new FormUrlEncodedContent(new[] {
            new KeyValuePair<string,string>("grant_type","client_credentials"),
        });

        var request = new HttpRequestMessage(HttpMethod.Post, _vaultConfigurations.DCIAuthUrl)
        {
            Content = stringContent,
            Headers = {
                { "Accept", "application/json" },
                { "Authorization", "Basic " + base64EncAuthId }
            }
        };

        using (var response = _httpClient.SendAsync(request, CancellationToken.None).Result)
        {
            if (response.StatusCode == System.Net.HttpStatusCode.OK && response.Content != null)
            {
                using (var responseStream = response.Content.ReadAsStreamAsync(CancellationToken.None).Result)
                {
                    var responseData = JsonSerializer.DeserializeAsync<DCIAuthCache>(responseStream, cancellationToken: CancellationToken.None).Result;
                    if (responseData != null)
                    {
                        responseData.Expires = DateTime.UtcNow.AddSeconds(responseData.ExpiresInSeconds - 60);
                        TokenCache["DCI_TOKEN"] = responseData;
                        return responseData.AccessToken;
                    }
                }
            }
            else
            {
                _logger.LogWarning($"Error making get api call to {_vaultConfigurations.DCIAuthUrl}, Response Code: {response.StatusCode}");
            }
            return null;
        }
    }

    private static HttpRequestMessage HttpGetRequest(string url, string authToken) => new(HttpMethod.Get, url)
    {
        Headers = { { "Accept", "application/json" }, { "Authorization", "Bearer " + authToken } }
    };

    private static HttpRequestMessage HttpPostRequest(string url, string payload, string authToken) => new(HttpMethod.Post, url)
    {
        Content = new StringContent(payload, Encoding.UTF8, "application/json"),
        Headers = { { "Accept", "application/json" }, { "Authorization", "Bearer " + authToken } }
    };

    public async Task<CPSProfileData?> CreateUserAsync(CPSUserRequest request)
    {
        try
        {
            var token = GetToken();
            if (string.IsNullOrEmpty(token))
            {
                _logger.LogWarning("Failed to get DCI authentication token");
                return null;
            }
            var baseAddress = _vaultConfigurations.CPSBaseAddress ?? "https://localhost";
            var fullUrl = baseAddress.TrimEnd('/') + "/" + CPSUrls.CreateAccount.TrimStart('/');
            var httpRequest = HttpPostRequest(fullUrl, JsonSerializer.Serialize(request), token);
            using var response = await _httpClient.SendAsync(httpRequest, CancellationToken.None).ConfigureAwait(false);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<CPSProfileData>();
            }
            return null;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error creating CPS user: {ex.Message}", ex);
        }
    }

    public async Task<CPSProfileData?> GetUserAsync(string email)
    {
        try
        {
            var token = GetToken();
            if (string.IsNullOrEmpty(token))
            {
                _logger.LogWarning("Failed to get DCI authentication token");
                return null;
            }
            var baseAddress = _vaultConfigurations.CPSBaseAddress ?? "https://www-sit-g4.dell.com/di/api/account";
            var fullUrl = baseAddress.TrimEnd('/') + "/" + CPSUrls.GetAccountUrl.TrimStart('/') + email;
            var httpRequest = HttpGetRequest(fullUrl, token);
            using var response = await _httpClient.SendAsync(httpRequest, CancellationToken.None).ConfigureAwait(false);
            //var output = await response.Content.ReadAsStringAsync(CancellationToken.None).ConfigureAwait(false);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<CPSProfileData>();
            }
            return null;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error getting CPS user: {ex.Message}", ex);
        }
    }

    public async Task<CPSProfileData?> GetUserByProfileIdAsync(Guid profileId)
    {
        try
        {
            var token = GetToken();
            if (string.IsNullOrEmpty(token))
            {
                _logger.LogWarning("Failed to get DCI authentication token");
                return null;
            }
            var baseAddress = _vaultConfigurations.CPSBaseAddress ?? "https://www-sit-g4.dell.com/di/api/account";
            var fullUrl = baseAddress.TrimEnd('/') + "/" + CPSUrls.GetAccountUrl.TrimStart('/') + profileId;
            var httpRequest = HttpGetRequest(fullUrl, token);
            using var response = await _httpClient.SendAsync(httpRequest, CancellationToken.None).ConfigureAwait(false);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<CPSProfileData>();
            }
            return null;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error getting CPS user by profile ID: {ex.Message}", ex);
        }
    }
}

public class DCIAuthCache
{
    [System.Text.Json.Serialization.JsonPropertyName("access_token")]
    public string AccessToken { get; set; } = string.Empty;
    [System.Text.Json.Serialization.JsonPropertyName("expires_in")]
    public int ExpiresInSeconds { get; set; }
    public DateTime Expires { get; set; }
    public bool IsValid => DateTime.UtcNow < Expires;
}

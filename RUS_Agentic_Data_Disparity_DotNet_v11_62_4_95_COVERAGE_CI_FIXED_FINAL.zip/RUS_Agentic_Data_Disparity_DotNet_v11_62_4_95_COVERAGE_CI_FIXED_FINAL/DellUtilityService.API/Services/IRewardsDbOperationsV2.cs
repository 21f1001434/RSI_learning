using DellUtilityService.API.Data;

namespace DellUtilityService.API.Services;

public interface IRewardsDbOperationsV2
{
    Task<Member?> GetMemberByIdAsync(Guid id);
    Task<Member?> GetMemberByProfileIdAsync(Guid profileId);
    Task<Member?> GetMemberByEmailAsync(string email);
    Task<Member?> GetMemberByCrowdTwistIdAsync(long crowdTiwstId);
    Task<List<Member>> SearchMembersAsync(string searchTerm);
    Task<bool> UpdateMemberColumnAsync(Guid id, string columnName, string newValue);
    Task<bool> UpdateMemberColumnByIdAsync(Guid id, string columnName, string newValue);
    Task<BulkOperation> BulkUpdateMemberColumnAsync(List<MemberColumnUpdateRequest> requests);
}

public class MemberColumnUpdateRequest
{
    public Guid Id { get; set; }
    public string ColumnName { get; set; } = string.Empty;
    public string NewValue { get; set; } = string.Empty;
}

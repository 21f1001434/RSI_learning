'use strict';

(function () {
    const STORAGE_PREFIX = 'rus.notifications.v3';
    const MAX_ITEMS = 100;
    let serverSyncTimer = null;

    function currentUsername() {
        const direct = window.RUSAuth?.getUser?.()?.username;
        if (direct) return String(direct).toLowerCase();
        try {
            const stored = JSON.parse(sessionStorage.getItem('rus.auth.user') || 'null');
            return String(stored?.username || 'anonymous').toLowerCase();
        } catch {
            return 'anonymous';
        }
    }

    function storageKey() {
        return `${STORAGE_PREFIX}.${currentUsername()}`;
    }

    function read() {
        try {
            const value = JSON.parse(localStorage.getItem(storageKey()) || '[]');
            return Array.isArray(value) ? value : [];
        } catch {
            return [];
        }
    }

    function write(items) {
        const normalized = items.slice(0, MAX_ITEMS);
        localStorage.setItem(storageKey(), JSON.stringify(normalized));
        window.dispatchEvent(new CustomEvent('rus:notifications-changed', { detail: { items: normalized } }));
    }

    function add({ title, message, type = 'info', category = 'general', link = null, metadata = {}, system = true, dedupeKey = null, createdAt = null, read: isRead = false }) {
        const items = read();
        const normalizedKey = dedupeKey || metadata?.dedupeKey || null;
        if (normalizedKey) {
            const index = items.findIndex(item => item.dedupeKey === normalizedKey);
            if (index >= 0) {
                const existing = items[index];
                items[index] = {
                    ...existing,
                    title: String(title || existing.title),
                    message: String(message ?? existing.message),
                    type: type || existing.type,
                    category: category || existing.category,
                    link: link ?? existing.link,
                    metadata: { ...(existing.metadata || {}), ...(metadata || {}) },
                    read: Boolean(isRead || existing.read)
                };
                write(items);
                return items[index];
            }
        }
        const item = {
            id: `NTF-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
            title: String(title || 'RUS notification'),
            message: String(message || ''),
            type,
            category,
            link,
            metadata,
            dedupeKey: normalizedKey,
            createdAt: createdAt || new Date().toISOString(),
            read: Boolean(isRead)
        };
        items.unshift(item);
        write(items);

        if (system && 'Notification' in window && Notification.permission === 'granted') {
            try {
                const notification = new Notification(item.title, { body: item.message, tag: normalizedKey || item.id });
                if (link) notification.onclick = () => { window.focus(); window.location.href = link; };
            } catch (error) {
                console.debug('Browser notification unavailable', error);
            }
        }
        return item;
    }

    function markServerPromptRead(item) {
        const promptId = item?.metadata?.serverPromptId;
        if (!promptId) return;
        fetch(`/api/auth/prompts/${encodeURIComponent(promptId)}/read`, {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'Content-Type': 'application/json', 'X-RUS-Channel': 'in-app-prompt' },
            body: '{}'
        }).catch(error => console.debug('Unable to acknowledge server prompt', error));
    }

    function markRead(id) {
        const items = read();
        const selected = items.find(item => item.id === id);
        write(items.map(item => item.id === id ? { ...item, read: true } : item));
        markServerPromptRead(selected);
    }

    function markAllRead() {
        const items = read();
        items.filter(item => !item.read).forEach(markServerPromptRead);
        write(items.map(item => ({ ...item, read: true })));
    }

    function remove(id) {
        write(read().filter(item => item.id !== id));
    }

    function clear() {
        write([]);
    }

    async function requestPermission() {
        if (!('Notification' in window)) return 'unsupported';
        if (Notification.permission === 'granted') return 'granted';
        try {
            return await Notification.requestPermission();
        } catch {
            return Notification.permission;
        }
    }

    function unreadCount() {
        return read().filter(item => !item.read).length;
    }

    async function syncServerPrompts() {
        const user = window.RUSAuth?.getUser?.();
        if (!user?.id) return [];
        try {
            const response = await fetch('/api/auth/prompts?includeRead=true', {
                cache: 'no-store', credentials: 'same-origin',
                headers: { Accept: 'application/json', 'X-RUS-Channel': 'in-app-prompt' }
            });
            if (!response.ok) return [];
            const envelope = await response.json().catch(() => ({}));
            const prompts = envelope?.data ?? envelope ?? [];
            if (!Array.isArray(prompts)) return [];
            prompts.forEach(prompt => add({
                title: prompt.title,
                message: `${prompt.message}${prompt.createdByDisplayName ? ` — ${prompt.createdByDisplayName}` : ''}`,
                type: prompt.severity || 'info',
                category: 'admin-prompt',
                link: prompt.actionUrl || null,
                metadata: { serverPromptId: prompt.id, createdBy: prompt.createdByUsername, expiresAtUtc: prompt.expiresAtUtc },
                dedupeKey: `server-prompt:${prompt.id}`,
                createdAt: prompt.createdUtc,
                read: Boolean(prompt.readUtc),
                system: !prompt.readUtc
            }));
            return prompts;
        } catch (error) {
            console.debug('Server prompts unavailable', error);
            return [];
        }
    }

    function startServerSync() {
        if (serverSyncTimer) window.clearInterval(serverSyncTimer);
        syncServerPrompts();
        serverSyncTimer = window.setInterval(syncServerPrompts, 30000);
        window.addEventListener('focus', syncServerPrompts);
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') syncServerPrompts();
        });
    }

    window.RUSNotifications = {
        list: read,
        add,
        markRead,
        markAllRead,
        remove,
        clear,
        requestPermission,
        unreadCount,
        syncServerPrompts
    };

    document.addEventListener('DOMContentLoaded', async () => {
        await window.RUSAuth?.ready;
        startServerSync();
    });
})();

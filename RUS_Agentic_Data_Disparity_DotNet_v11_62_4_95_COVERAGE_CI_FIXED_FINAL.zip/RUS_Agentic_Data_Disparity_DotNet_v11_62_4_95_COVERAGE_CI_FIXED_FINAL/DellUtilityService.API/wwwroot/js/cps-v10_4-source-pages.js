// CPS Operations JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Create user form handler
    const createUserForm = document.getElementById('createUserForm');
    if (createUserForm) {
        createUserForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(createUserForm);
            const data = {
                email: formData.get('email'),
                firstName: formData.get('firstName'),
                lastName: formData.get('lastName'),
                country: formData.get('country')
            };
            
            showLoader('Creating user in CPS...');
            try {
                const response = await cpsApi.createUser(data);
                if (response.success) {
                    showMessage('User created successfully in CPS');
                    createUserForm.reset();
                } else {
                    showMessage(response.message || 'Failed to create user', true);
                }
            } catch (error) {
                showMessage('Error creating user', true);
            } finally {
                hideLoader();
            }
        });
    }
});

async function searchCPSByEmail() {
    const email = document.getElementById('searchEmail').value;
    if (!email) {
        showMessage('Please enter an email', true);
        return;
    }
    
    showLoader('Searching user in CPS...');
    try {
        const response = await cpsApi.getUser(email);
        if (response.success) {
            showResult('cpsEmailResult', response.data, true);
            showMessage('User found in CPS');
        } else {
            showMessage(response.message || 'User not found', true);
            document.getElementById('cpsEmailResult').innerHTML = '<p class="not-found">User not found</p>';
        }
    } catch (error) {
        showMessage('Error searching user', true);
        document.getElementById('cpsEmailResult').innerHTML = '<p class="not-found">Error searching user</p>';
    } finally {
        hideLoader();
    }
}

async function searchCPSByProfileId() {
    const profileId = document.getElementById('searchProfileId').value;
    if (!profileId) {
        showMessage('Please enter a profile ID', true);
        return;
    }
    
    showLoader('Searching user in CPS...');
    try {
        const response = await cpsApi.getUserByProfileId(profileId);
        if (response.success) {
            showResult('cpsProfileResult', response.data, true);
            showMessage('User found in CPS');
        } else {
            showMessage(response.message || 'User not found', true);
            document.getElementById('cpsProfileResult').innerHTML = '<p class="not-found">User not found</p>';
        }
    } catch (error) {
        showMessage('Error searching user', true);
        document.getElementById('cpsProfileResult').innerHTML = '<p class="not-found">Error searching user</p>';
    } finally {
        hideLoader();
    }
}

// Members DB Operations JavaScript

async function searchMemberByProfileId() {
    const profileId = document.getElementById('memberProfileId').value;
    if (!profileId) {
        showMessage('Please enter a profile ID', true);
        return;
    }
    
    showLoader('Searching member in database...');
    try {
        const response = await membersApi.getMemberByProfileId(profileId);
        if (response.success) {
            showResult('memberResult', response.data, true);
            showMessage('Member found');
        } else {
            showMessage(response.message || 'Member not found', true);
            document.getElementById('memberResult').innerHTML = '<p class="not-found">Member not found</p>';
        }
    } catch (error) {
        showMessage('Error searching member', true);
        document.getElementById('memberResult').innerHTML = '<p class="not-found">Error searching member</p>';
    } finally {
        hideLoader();
    }
}

async function searchMember() {
    const searchType = document.getElementById('memberSearchType').value;
    const searchValue = document.getElementById('memberSearchValue').value;
    
    if (!searchValue) {
        showMessage('Please enter a search value', true);
        return;
    }
    
    showLoader('Searching member in database...');
    try {
        const response = await fetch(`/api/members/search?searchTerm=${encodeURIComponent(searchValue)}`);
        const result = await response.json();
        
        if (result.success) {
            if (Array.isArray(result.data)) {
                if (result.data.length === 0) {
                    showMessage('No members found', true);
                    document.getElementById('memberResult').innerHTML = '<p class="not-found">No members found</p>';
                } else if (result.data.length === 1) {
                    showResult('memberResult', result.data[0], true);
                    showMessage('Member found');
                } else {
                    showMultipleResults('memberResult', result.data);
                    showMessage(`Found ${result.data.length} members`);
                }
            } else {
                showResult('memberResult', result.data, true);
                showMessage('Member found');
            }
        } else {
            showMessage(result.message || 'Member not found', true);
            document.getElementById('memberResult').innerHTML = '<p class="not-found">Member not found</p>';
        }
    } catch (error) {
        showMessage('Error searching member', true);
        document.getElementById('memberResult').innerHTML = '<p class="not-found">Error searching member</p>';
    } finally {
        hideLoader();
    }
}

function showMultipleResults(containerId, members) {
    const container = document.getElementById(containerId);
    if (!members || members.length === 0) {
        container.innerHTML = '<p class="not-found">No members found</p>';
        return;
    }

    let html = '<div class="multiple-results"><h3>Multiple Results Found</h3>';
    members.forEach((member, index) => {
        html += `
            <div class="result-card" style="margin-bottom: 10px; padding: 15px; border: 1px solid #ddd; border-radius: 5px;">
                <h4>Result ${index + 1}</h4>
                <p><strong>ID:</strong> ${member.id}</p>
                <p><strong>Profile ID:</strong> ${member.profileId}</p>
                <p><strong>CrowdTwist ID:</strong> ${member.crowdTwistID}</p>
                <p><strong>Country Code:</strong> ${member.countryCode}</p>
                <p><strong>Is Active:</strong> ${member.isActive}</p>
                <p><strong>Member Key:</strong> ${member.memberKey}</p>
                <p><strong>Last Updated:</strong> ${member.lastUpdated}</p>
            </div>
        `;
    });
    html += '</div>';
    container.innerHTML = html;
}

async function uploadMemberBulkFile() {
    const fileInput = document.getElementById('memberBulkFile');
    const resultSection = document.getElementById('memberBulkResult');
    
    if (!fileInput.files || fileInput.files.length === 0) {
        alert('Please select a file to upload');
        return;
    }

    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append('file', file);

    showLoader('Processing Member DB bulk update...');
    
    try {
        const response = await fetch('/api/members/bulkupdate', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Upload failed');
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `MemberDB_BulkUpdate_Result_${new Date().toISOString().slice(0, 10)}.xlsx`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        resultSection.innerHTML = `
            <div class="success-message">
                <h3>Upload Successful!</h3>
                <p>Result file has been downloaded automatically.</p>
            </div>
        `;
    } catch (error) {
        resultSection.innerHTML = `
            <div class="error-message">
                <h3>Upload Failed</h3>
                <p>${error.message}</p>
            </div>
        `;
    } finally {
        hideLoader();
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Update column form handler
    const updateColumnForm = document.getElementById('updateColumnForm');
    if (updateColumnForm) {
        updateColumnForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(updateColumnForm);
            const data = {
                id: formData.get('id'),
                columnName: formData.get('columnName'),
                newValue: formData.get('newValue')
            };
            
            showLoader('Updating member column...');
            try {
                const response = await membersApi.updateColumn(data);
                if (response.success) {
                    showMessage('Column updated successfully');
                    updateColumnForm.reset();
                } else {
                    showMessage(response.message || 'Failed to update column', true);
                }
            } catch (error) {
                showMessage('Error updating column', true);
            } finally {
                hideLoader();
            }
        });
    }

    // Bulk upload handler
    const uploadMemberBulkBtn = document.getElementById('uploadMemberBulkBtn');
    if (uploadMemberBulkBtn) {
        uploadMemberBulkBtn.addEventListener('click', uploadMemberBulkFile);
    }
});

'use strict';

const API_BASE_URL = '/api';

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('\"', '&quot;')
        .replaceAll("'", '&#039;');
}

function safeJsonText(value) {
    try { return JSON.stringify(value, null, 2); } catch { return String(value ?? ''); }
}

function openAgenticRequest(command, { context = 'individual' } = {}) {
    const text = String(command || '').trim();
    if (!text) return;
    sessionStorage.setItem('rus.agentic.prefill', text);
    window.RUSWorkspace?.setShared('rus.agentic.chatContext', context === 'batch' ? 'batch' : 'individual');
    window.location.href = 'ai-analysis.html';
}

window.RUSAgentHandoff = { open: openAgenticRequest };

function renderSafeMarkdown(value) {
    const inline = (text) => {
        let safe = escapeHtml(text ?? '');
        safe = safe.replace(/`([^`]+)`/g, '<code class="chat-inline-code">$1</code>');
        safe = safe.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
        return safe.replace(/(^|\s)(https?:\/\/[^\s<]+)/g, (match, prefix, url) => {
            const clean = url.replace(/[.,;:!?)]$/, '');
            const suffix = url.slice(clean.length);
            return `${prefix}<a class="chat-link" href="${clean}" target="_blank" rel="noopener">${clean}</a>${suffix}`;
        });
    };
    const lines = String(value ?? '').replace(/\r\n?/g, '\n').split('\n');
    const blocks = [];
    let paragraph = [];
    let list = [];
    let listType = 'ul';
    const flushParagraph = () => {
        if (!paragraph.length) return;
        blocks.push(`<p class="chat-paragraph">${inline(paragraph.join(' '))}</p>`);
        paragraph = [];
    };
    const flushList = () => {
        if (!list.length) return;
        blocks.push(`<${listType} class="chat-list">${list.map((item) => `<li>${inline(item)}</li>`).join('')}</${listType}>`);
        list = [];
    };
    for (const raw of lines) {
        const line = raw.trim();
        if (!line) { flushParagraph(); flushList(); continue; }
        const heading = line.match(/^(#{1,4})\s+(.+)$/);
        if (heading) {
            flushParagraph(); flushList();
            const level = Math.min(4, heading[1].length + 2);
            blocks.push(`<h${level} class="chat-heading">${inline(heading[2])}</h${level}>`);
            continue;
        }
        const bullet = line.match(/^[-•*]\s+(.+)$/);
        const numbered = line.match(/^\d+[.)]\s+(.+)$/);
        if (bullet || numbered) {
            flushParagraph();
            const nextType = numbered ? 'ol' : 'ul';
            if (list.length && nextType !== listType) flushList();
            listType = nextType;
            list.push((bullet || numbered)[1]);
            continue;
        }
        flushList();
        paragraph.push(line);
    }
    flushParagraph(); flushList();
    return blocks.join('');
}

window.RUSFormat = { escapeHtml, renderSafeMarkdown, safeJsonText };


async function apiCall(endpoint, method = 'GET', data = null) {
    const options = {
        method,
        headers: { 'Content-Type': 'application/json' }
    };
    if (data !== null && data !== undefined) options.body = JSON.stringify(data);

    const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
    const contentType = response.headers.get('content-type') || '';
    const result = contentType.includes('application/json')
        ? await response.json().catch(() => null)
        : await response.text().catch(() => '');

    if (!response.ok) {
        const message = result?.message || result?.detail || result?.error?.message
            || (typeof result === 'string' ? result : '') || `HTTP ${response.status}`;
        const error = new Error(message);
        error.status = response.status;
        error.payload = result;
        throw error;
    }
    return result;
}

// CPS API
const cpsApi = {
    createUser: async (data) => {
        return await apiCall('/cps/create-user', 'POST', data);
    },
    getUser: async (email) => {
        return await apiCall(`/cps/get-user/${encodeURIComponent(email)}`);
    },
    getUserByProfileId: async (profileId) => {
        return await apiCall(`/cps/get-user-by-profile/${encodeURIComponent(profileId)}`);
    }
};

// Members API
const membersApi = {
    getMemberById: async (id) => {
        return await apiCall(`/members/get-by-id/${encodeURIComponent(id)}`);
    },
    getMemberByProfileId: async (profileId) => {
        return await apiCall(`/members/get-by-profile/${encodeURIComponent(profileId)}`);
    },
    updateColumn: async (data) => {
        return await apiCall('/members/update-column', 'POST', data);
    },
    bulkUpdateColumns: async (data) => {
        return await apiCall('/members/bulk-update-columns', 'POST', data);
    }
};

// CrowdTwist API
const crowdTwistApi = {
    searchMember: async (searchType, searchValue) => {
        return await apiCall(`/crowdtwist/search?searchType=${encodeURIComponent(searchType)}&searchValue=${encodeURIComponent(searchValue)}`);
    },
    updateProperty: async (data) => {
        return await apiCall('/crowdtwist/update-property', 'POST', data);
    },
    bulkUpdateProperties: async (data) => {
        return await apiCall('/crowdtwist/bulk-update-properties', 'POST', data);
    }
};

// Search API
const searchApi = {
    searchByEmail: async (email) => {
        return await apiCall(`/search/by-email?email=${encodeURIComponent(email)}`);
    },
    searchByProfileId: async (profileId) => {
        return await apiCall(`/search/by-profile-id?profileId=${encodeURIComponent(profileId)}`);
    }
};

// AI Analysis API
const aiAnalysisApi = {
    analyze: async (searchType, searchValue) => {
        return await apiCall(`/AIAnalysis/analyze?searchType=${encodeURIComponent(searchType)}&searchValue=${encodeURIComponent(searchValue)}`);
    },
    quickAction: async (action) => {
        return await apiCall(`/AIAnalysis/quick-action?action=${encodeURIComponent(action)}`);
    }
};

// Utility functions
function showResult(containerId, data, isTable = false, expectedProperties = null) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (isTable && data && typeof data === 'object') {
        const propertiesToDisplay = expectedProperties || Object.keys(data);
        const displayedProperties = new Set();
        const rows = [];
        for (const key of propertiesToDisplay) {
            const normalizedKey = String(key).toLowerCase().replace(/_/g, '').replace(/([A-Z])/g, '');
            if (displayedProperties.has(normalizedKey)) continue;
            const value = Object.prototype.hasOwnProperty.call(data, key) ? data[key] : null;
            rows.push(`<tr><td>${escapeHtml(key)}</td><td>${formatValue(value)}</td></tr>`);
            displayedProperties.add(normalizedKey);
        }
        container.innerHTML = `<div class="table-scroll"><table class="result-table"><thead><tr><th>Field</th><th>Value</th></tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
    } else if (data !== null && data !== undefined) {
        const pre = document.createElement('pre');
        pre.textContent = safeJsonText(data);
        container.replaceChildren(pre);
    } else {
        container.innerHTML = '<p class="not-found">No data found</p>';
    }
    window.RUSWorkspace?.persistFields?.();
}

function formatValue(value) {
    if (value === null || value === undefined || (typeof value === 'string' && value.trim() === '')) return 'N/A';
    if (Array.isArray(value)) {
        if (!value.length) return 'N/A';
        return `<div class="array-container">${value.map((item, index) => `<div class="array-item"><strong>[${index}]</strong>: ${formatValue(item)}</div>`).join('')}</div>`;
    }
    if (typeof value === 'object') {
        return `<div class="object-container">${Object.entries(value).map(([key, item]) => `<div class="object-item"><strong>${escapeHtml(key)}:</strong> ${formatValue(item)}</div>`).join('')}</div>`;
    }
    return escapeHtml(value);
}

function showMessage(message, isError = false) {
    const div = document.createElement('div');
    div.className = `app-toast ${isError ? 'error' : 'success'}`;
    const icon = document.createElement('span');
    icon.textContent = isError ? '!' : '✓';
    const copy = document.createElement('div');
    copy.textContent = String(message || '');
    div.append(icon, copy);
    document.body.appendChild(div);
    window.RUSNotifications?.add({
        title: isError ? 'Operation failed' : 'Operation completed',
        message: String(message || ''),
        type: isError ? 'error' : 'success',
        category: document.body?.dataset?.page || 'operation',
        link: window.location.pathname.split('/').pop() || 'index.html',
        system: !isError
    });
    setTimeout(() => div.remove(), 4200);
}

function setLoading(buttonId, loading) {
    const button = document.getElementById(buttonId);
    if (button) {
        button.disabled = loading;
        button.textContent = loading ? 'Loading...' : button.getAttribute('data-original-text') || button.textContent;
    }
}

// Agentic Dell AIA / AutoGen API proxy. All requests stay same-origin and the
// internal Python API key remains on the .NET server.
const AGENTIC_PROXY_BASE = '/api/agentic-ai';
async function agenticRequest(path, options = {}) {
    const response = await fetch(`${AGENTIC_PROXY_BASE}${path}`, {
        cache: 'no-store',
        ...options,
        headers: {
            ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
            ...(options.headers || {})
        }
    });

    const contentType = response.headers.get('content-type') || '';
    let payload = null;
    if (contentType.includes('application/json')) {
        payload = await response.json().catch(() => null);
    } else {
        payload = await response.text().catch(() => '');
    }

    if (!response.ok) {
        const message = payload?.error?.message
            || payload?.detail
            || payload?.message
            || (typeof payload === 'string' ? payload : '')
            || `Request failed with HTTP ${response.status}`;
        const error = new Error(message);
        error.status = response.status;
        error.payload = payload;
        error.requestId = payload?.requestId || payload?.request_id || response.headers.get('x-request-id') || null;
        throw error;
    }

    return payload;
}

const agenticAiApi = {
    configuration: () => agenticRequest('/configuration'),
    bootstrap: (sessionId = null, deepHealth = false) => agenticRequest('/bootstrap', {
        method: 'POST',
        body: JSON.stringify({ session_id: sessionId, deep_health: deepHealth })
    }),
    live: () => agenticRequest('/health/live'),
    ready: (deep = false) => agenticRequest(`/health/ready?deep=${deep}`),
    memoryStatus: () => agenticRequest('/memory/status'),

    createSession: (metadata = { channel: 'dotnet-rus-ui' }) => agenticRequest('/sessions', {
        method: 'POST',
        body: JSON.stringify({ metadata })
    }),
    getSession: (sessionId, includeMessages = true) =>
        agenticRequest(`/sessions/${encodeURIComponent(sessionId)}?includeMessages=${includeMessages}`),
    resetSession: (sessionId) => agenticRequest(`/sessions/${encodeURIComponent(sessionId)}/reset`, {
        method: 'POST',
        body: '{}'
    }),
    deleteSession: (sessionId) => agenticRequest(`/sessions/${encodeURIComponent(sessionId)}`, {
        method: 'DELETE'
    }),
    getSessionActiveBatch: (sessionId) =>
        agenticRequest(`/sessions/${encodeURIComponent(sessionId)}/active-batch`),

    chat: (request) => agenticRequest('/chat', {
        method: 'POST',
        body: JSON.stringify(request)
    }),
    querySource: (request) => agenticRequest('/source-operations/query', {
        method: 'POST',
        body: JSON.stringify(request)
    }),
    planSourceChange: (request) => agenticRequest('/source-operations/changes/plan', {
        method: 'POST',
        body: JSON.stringify(request)
    }),
    getSourceChange: (changeId, sessionId) => agenticRequest(`/source-operations/changes/${encodeURIComponent(changeId)}?sessionId=${encodeURIComponent(sessionId)}`),
    confirmSourceChangeFirst: (changeId, sessionId, confirmationText) => agenticRequest(`/source-operations/changes/${encodeURIComponent(changeId)}/confirm-1`, {
        method: 'POST',
        body: JSON.stringify({ session_id: sessionId, confirmation_text: confirmationText, approval_channel: 'chat' })
    }),
    markSourceChangePopupOpened: (changeId, sessionId) => agenticRequest(`/source-operations/changes/${encodeURIComponent(changeId)}/popup-opened`, {
        method: 'POST',
        body: JSON.stringify({ session_id: sessionId })
    }),
    confirmSourceChangeSecond: (changeId, request) => agenticRequest(`/source-operations/changes/${encodeURIComponent(changeId)}/confirm-2`, {
        method: 'POST',
        body: JSON.stringify(request)
    }),
    cancelSourceChange: (changeId, sessionId, reason = 'Cancelled from UI') => agenticRequest(`/source-operations/changes/${encodeURIComponent(changeId)}/cancel`, {
        method: 'POST',
        body: JSON.stringify({ session_id: sessionId, reason })
    }),
    analyze: (request) => agenticRequest('/analysis/individual', {
        method: 'POST',
        body: JSON.stringify(request)
    }),
    getAnalysis: (runId, masked = false) => agenticRequest(`/analysis/${encodeURIComponent(runId)}?masked=${masked ? 'true' : 'false'}`),
    htmlReportUrl: (runId, masked = false) => `${AGENTIC_PROXY_BASE}/analysis/${encodeURIComponent(runId)}/report.html?masked=${masked ? 'true' : 'false'}`,
    jsonReportUrl: (runId, masked = false) => `${AGENTIC_PROXY_BASE}/analysis/${encodeURIComponent(runId)}/report.json?masked=${masked ? 'true' : 'false'}`,

    submitBatch: (request) => agenticRequest('/batches', {
        method: 'POST',
        body: JSON.stringify(request)
    }),
    uploadBatch: (file, settings) => {
        const data = new FormData();
        data.append('file', file, file.name);
        const query = new URLSearchParams({
            maxParallel: String(settings.maxParallel ?? 8),
            maxParallelAi: String(settings.maxParallelAi ?? 2),
            includeGroupAi: String(settings.includeGroupAi ?? true)
        });
        if (settings.sessionId) query.set('sessionId', settings.sessionId);
        return agenticRequest(`/batches/upload?${query}`, { method: 'POST', body: data });
    },
    uploadSourceUpdateWorkbook: (file, settings) => {
        const data = new FormData();
        data.append('file', file, file.name);
        data.append('sessionId', settings.sessionId || '');
        data.append('instruction', settings.instruction || 'validate these spreadsheet changes');
        return agenticRequest('/source-operations/spreadsheet', { method: 'POST', body: data });
    },
    getBatch: (jobId) => agenticRequest(`/batches/${encodeURIComponent(jobId)}`),
    getBatchSummary: (jobId) => agenticRequest(`/batches/${encodeURIComponent(jobId)}/summary`),
    batchDownloadUrl: (jobId, masked = false) => `${AGENTIC_PROXY_BASE}/batches/${encodeURIComponent(jobId)}/download?masked=${masked ? 'true' : 'false'}`,

    getCatalog: () => agenticRequest('/knowledge/catalog'),
    getOperation: (operationId) => agenticRequest(`/knowledge/operations/${encodeURIComponent(operationId)}`),
    validatePayload: (operationId, payload) => agenticRequest('/knowledge/validate-payload', {
        method: 'POST',
        body: JSON.stringify({ operation_id: operationId, payload })
    }),
    getUseCases: (runId) => agenticRequest(`/analysis/${encodeURIComponent(runId)}/use-cases`),
    compileUseCasePlan: (runId, useCaseId, includeDellAiaReview = true) => agenticRequest('/use-cases/plan', {
        method: 'POST',
        body: JSON.stringify({
            run_id: runId,
            use_case_id: useCaseId,
            include_dell_aia_review: includeDellAiaReview
        })
    })
};

// Search Operations JavaScript
async function performSearch() {
    const searchType = document.getElementById('searchType').value;
    const searchValue = document.getElementById('searchValue').value;
    
    if (!searchValue) {
        showMessage('Please enter a search value', true);
        return;
    }
    
    showLoader('Searching across all systems...');
    try {
        let response;
        if (searchType === 'email') {
            response = await searchApi.searchByEmail(searchValue);
        } else if (searchType === 'profileId') {
            response = await searchApi.searchByProfileId(searchValue);
        }
        
        if (response.success) {
            displaySearchResults(response.data, 'searchResult');
            showMessage('Search completed');
        } else {
            showMessage(response.message || 'Search failed', true);
            document.getElementById('searchResult').innerHTML = '<p class="not-found">No results found</p>';
        }
    } catch (error) {
        showMessage('Error searching', true);
        document.getElementById('searchResult').innerHTML = '<p class="not-found">Error searching</p>';
    } finally {
        hideLoader();
    }
}

function displaySearchResults(data, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    let html = '<div class="search-results-grid">';
    
    // Members DB result
    html += '<div class="search-result-card">';
    html += '<h3>Members DB</h3>';
    if (data.memberData) {
        html += '<table class="result-table">';
        html = displayObjectProperties(data.memberData, html);
        html += '</table>';
    } else {
        html += '<p class="not-found">Not found</p>';
    }
    html += '</div>';
    
    // CPS result
    html += '<div class="search-result-card">';
    html += '<h3>CPS</h3>';
    if (data.cpsData) {
        html += '<table class="result-table">';
        html = displayObjectProperties(data.cpsData, html);
        html += '</table>';
    } else {
        html += '<p class="not-found">Not found</p>';
    }
    html += '</div>';
    
    // CrowdTwist result
    html += '<div class="search-result-card">';
    html += '<h3>CrowdTwist</h3>';
    if (data.crowdTwistData) {
        html += '<table class="result-table">';
        html = displayObjectProperties(data.crowdTwistData, html);
        html += '</table>';
    } else {
        html += '<p class="not-found">Not found</p>';
    }
    html += '</div>';
    
    html += '</div>';
    
    container.innerHTML = html;
}

function displayObjectProperties(obj, html, indent = 0, expectedProperties = null) {
    const propertiesToDisplay = expectedProperties || Object.keys(obj);
    const displayedProperties = new Set();
    
    for (const key of propertiesToDisplay) {
        // Skip if this property or its variant has already been displayed
        const normalizedKey = key.toLowerCase().replace(/_/g, '').replace(/([A-Z])/g, '');
        if (displayedProperties.has(normalizedKey)) {
            continue;
        }
        
        const value = obj.hasOwnProperty(key) ? obj[key] : null;
        const displayValue = formatValue(value);
        const padding = indent > 0 ? 'style="padding-left: ' + (indent * 20) + 'px;"' : '';
        html += `<tr ${padding}><td>${key}</td><td>${displayValue}</td></tr>`;
        displayedProperties.add(normalizedKey);
    }
    return html;
}

function formatValue(value) {
    if (value === null || value === undefined) {
        return 'N/A';
    }
    
    if (typeof value === 'string' && value.trim() === '') {
        return 'N/A';
    }
    
    if (Array.isArray(value)) {
        if (value.length === 0) {
            return 'N/A';
        }
        let result = '<div class="array-container">';
        value.forEach((item, index) => {
            result += `<div class="array-item"><strong>[${index}]</strong>: ${formatValue(item)}</div>`;
        });
        result += '</div>';
        return result;
    }
    
    if (typeof value === 'object') {
        let result = '<div class="object-container">';
        for (const [k, v] of Object.entries(value)) {
            result += `<div class="object-item"><strong>${k}:</strong> ${formatValue(v)}</div>`;
        }
        result += '</div>';
        return result;
    }
    
    return value;
}

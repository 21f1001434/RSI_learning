/* v11.19 role-focused UX for Dashboard and Agentic AI only. */
'use strict';
(function(){
  const normalizeRole=(value)=>String(value||'Customer').trim().toLowerCase();
  const role=()=>normalizeRole(window.RUSAuth?.getUser?.()?.role);
  const isFocused=()=>['business','customer','customer support'].includes(role());
  const isBusiness=()=>role()==='business';
  const byId=(id)=>document.getElementById(id);

  function setRoleClass(){
    const r=role()==='customer support'?'customer':role();
    document.body.classList.add(`role-${r}`);
    document.body.dataset.roleView=r;
  }
  function focusDashboard(){
    const title=document.querySelector('.dashboard-command-copy h2');
    const copy=document.querySelector('.dashboard-command-copy p');
    const eyebrow=document.querySelector('.dashboard-command-copy .eyebrow');
    const governance=document.querySelector('.dashboard-governance-card');
    if(role()==='business'){
      if(eyebrow) eyebrow.textContent='Business operations';
      if(title) title.textContent='Data quality overview';
      if(copy) copy.textContent='Run analysis, review suggested corrections, and track your governed changes.';
      if(governance){ governance.querySelector('.governance-flow').innerHTML='<b>Analyze</b><i>→</i><b>Chat yes</b><i>→</i><b>Verify</b>'; governance.querySelector('p').textContent='Business changes execute after one explicit chat approval and a final source recheck.'; }
    } else if(role()==='customer'){
      if(eyebrow) eyebrow.textContent='Customer support';
      if(title) title.textContent='Customer support overview';
      if(copy) copy.textContent='Find the right record, review recommended actions, and keep a clear activity history.';
      if(governance){ governance.querySelector('.governance-flow').innerHTML='<b>Find</b><i>→</i><b>Approve</b><i>→</i><b>Verify</b>'; governance.querySelector('p').textContent='Customer Support can execute governed Rewards DB/CrowdTwist corrections. Dry Run and role-safe reporting remain enforced.'; }
    }
  }
  function forceBusinessBatchDefaults(){
    // v11.37: managed roles stay on 8 source / 2 Dell AIA workers. Admin configuration is handled in ai-analysis.js.
  }
  function focusAgentic(){
    if(!isFocused()) return;
    // Keep the full Agentic navigation visible. Role permissions still hide unauthorized tabs.
    const h=document.querySelector('.agentic-hero-copy h1');
    const p=document.querySelector('.agentic-hero-copy p');
    if(h) h.textContent=isBusiness()?'Business Data Assistant':'Customer Support Assistant';
    if(p) p.textContent=isBusiness()?'Analyze individual or bulk customer data and review the suggested corrections.':'Find customer records, analyze discrepancies, and execute approved governed corrections.';
    forceBusinessBatchDefaults();
  }
  function init(){ setRoleClass(); if(document.body.dataset.page==='dashboard') focusDashboard(); if(document.body.dataset.page==='ai-analysis') focusAgentic(); }
  window.RUSRoleFocusedViews={isFocused,isBusiness,role,forceBusinessBatchDefaults};
  window.RUSAuth?.ready?.then(init).catch(init); if(!window.RUSAuth?.ready) document.addEventListener('DOMContentLoaded',init);
})();

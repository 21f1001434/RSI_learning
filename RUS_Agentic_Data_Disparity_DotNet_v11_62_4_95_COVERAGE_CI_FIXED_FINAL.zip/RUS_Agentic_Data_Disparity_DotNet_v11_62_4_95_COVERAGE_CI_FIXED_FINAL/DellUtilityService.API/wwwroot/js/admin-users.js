'use strict';

(function () {
    const table = document.getElementById('usersTable');
    const message = document.getElementById('userAdminMessage');
    const userDialog = document.getElementById('userDialog');
    const userForm = document.getElementById('userForm');
    const userDialogMessage = document.getElementById('userDialogMessage');
    const resetDialog = document.getElementById('resetPasswordDialog');
    const resetForm = document.getElementById('resetPasswordForm');
    const delegateDialog = document.getElementById('delegateDialog');
    const delegateForm = document.getElementById('delegateForm');
    const promptDialog = document.getElementById('promptDialog');
    const promptForm = document.getElementById('promptForm');
    let users = [];

    const escape = (value) => String(value ?? '')
        .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;').replaceAll("'", '&#039;');

    function showMessage(text, isError = false) {
        if (!message) return;
        message.textContent = text || '';
        message.classList.toggle('hidden', !text);
        message.classList.toggle('success', Boolean(text) && !isError);
        message.classList.toggle('error', Boolean(text) && isError);
    }

    function dialogMessage(id, text, isError = true) {
        const node = document.getElementById(id);
        if (!node) return;
        node.textContent = text || '';
        node.classList.toggle('hidden', !text);
        node.classList.toggle('error', Boolean(text) && isError);
        node.classList.toggle('success', Boolean(text) && !isError);
    }

    async function request(path, options = {}) {
        const response = await fetch(path, {
            cache: 'no-store',
            credentials: 'same-origin',
            ...options,
            headers: {
                ...(options.body ? { 'Content-Type': 'application/json' } : {}),
                'X-RUS-Channel': 'admin-ui',
                ...(options.headers || {})
            }
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(payload?.error?.message || payload?.message || `HTTP ${response.status}`);
        return payload?.data ?? payload;
    }

    function render() {
        const active = users.filter(item => item.isActive).length;
        const countRole = role => users.filter(item => item.isActive && String(item.role).toLowerCase() === role).length;
        document.querySelector('[data-user-summary="total"]').textContent = String(users.length);
        document.querySelector('[data-user-summary="customer"]').textContent = String(countRole('customer'));
        document.querySelector('[data-user-summary="business"]').textContent = String(countRole('business'));
        document.querySelector('[data-user-summary="technical"]').textContent = String(countRole('technical'));
        document.querySelector('[data-user-summary="admins"]').textContent = String(countRole('admin'));
        document.querySelector('[data-user-summary="inactive"]').textContent = String(users.length - active);

        if (!users.length) {
            table.innerHTML = '<div class="audit-empty"><strong>No users found.</strong></div>';
            return;
        }
        table.innerHTML = `<div class="audit-table-wrap"><table class="audit-table user-admin-table"><thead><tr><th>User</th><th>Role</th><th>Agentic write mode</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead><tbody>${users.map(row).join('')}</tbody></table></div>`;
        table.querySelectorAll('[data-user-edit]').forEach(button => button.addEventListener('click', () => openEdit(button.dataset.userEdit)));
        table.querySelectorAll('[data-user-delegate]').forEach(button => button.addEventListener('click', () => openDelegate(button.dataset.userDelegate)));
        table.querySelectorAll('[data-user-prompt]').forEach(button => button.addEventListener('click', () => openPrompt(button.dataset.userPrompt)));
        table.querySelectorAll('[data-user-toggle]').forEach(button => button.addEventListener('click', () => toggleUser(button.dataset.userToggle, button.dataset.active === 'true')));
        table.querySelectorAll('[data-user-reset]').forEach(button => button.addEventListener('click', () => openReset(button.dataset.userReset)));
        table.querySelectorAll('[data-user-dry-run]').forEach(button => button.addEventListener('click', () => toggleDryRun(button.dataset.userDryRun)));
        table.querySelectorAll('[data-user-purge]').forEach(button => button.addEventListener('click', () => purgeUser(button.dataset.userPurge)));
    }

    function row(user) {
        const initials = (user.displayName || user.username || 'U').split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase();
        return `<tr class="${user.isActive ? '' : 'is-inactive'}">
            <td><div class="admin-user-cell"><span>${escape(initials)}</span><div><strong>${escape(user.displayName || user.username)}</strong><small>${escape(user.username)}${user.email ? ` · ${escape(user.email)}` : ''}</small></div></div></td>
            <td><span class="role-pill ${String(user.role).toLowerCase()}">${escape(user.role)}</span></td>
            <td><div class="agentic-write-mode-cell"><span class="write-mode-pill ${String(user.effectiveWriteMode || 'live').toLowerCase() === 'dry_run' ? 'dry-run' : 'live'}">${String(user.effectiveWriteMode || 'live').toLowerCase() === 'dry_run' ? 'DRY RUN' : 'LIVE'}</span><small>${String(user.role || '').toLowerCase() === 'admin' ? 'Admin locked' : (user.dryRunEnabled ? 'No source modification' : 'Governed source updates')}</small></div></td>
            <td><span class="audit-status ${user.isActive ? 'success' : 'warning'}">${user.isActive ? 'Active' : 'Inactive'}</span></td>
            <td>${escape(new Date(user.createdUtc).toLocaleString())}</td>
            <td><div class="user-action-row">
                <button data-user-edit="${escape(user.id)}">Edit profile</button>
                <button data-user-delegate="${escape(user.id)}">Delegate role</button>
                <button data-user-prompt="${escape(user.id)}" ${user.isActive ? '' : 'disabled'}>Prompt</button>
                <button data-user-dry-run="${escape(user.id)}" ${String(user.role || '').toLowerCase() === 'admin' ? 'disabled title="Admin profiles are always live"' : ''}>${user.dryRunEnabled ? 'Disable dry run' : 'Enable dry run'}</button>
                <button data-user-reset="${escape(user.id)}">Reset password</button>
                <button class="${user.isActive ? 'danger' : 'success'}" data-user-toggle="${escape(user.id)}" data-active="${user.isActive}">${user.isActive ? 'Deactivate' : 'Activate'}</button>
                ${user.isActive ? '' : `<button class="danger permanent" data-user-purge="${escape(user.id)}">Delete permanently</button>`}
            </div></td>
        </tr>`;
    }

    async function load() {
        showMessage('');
        try {
            users = await request('/api/auth/users');
            render();
        } catch (error) {
            showMessage(error.message || 'Unable to load users.', true);
        } finally {
            document.getElementById('loader')?.classList.add('hidden');
        }
    }

    function syncDryRunEditor() {
        const role = String(userForm?.elements?.role?.value || 'Customer').toLowerCase();
        const select = userForm?.elements?.dryRunEnabled;
        const help = document.getElementById('dryRunProfileHelp');
        if (!select) return;
        const isAdmin = role === 'admin';
        if (isAdmin) select.value = 'false';
        select.disabled = isAdmin;
        if (help) {
            help.textContent = isAdmin
                ? 'Admin profiles are always LIVE. Dry Run is disabled and cannot be enabled.'
                : 'Dry Run ON validates and audits Agentic changes without modifying Rewards DB or CrowdTwist. Dry Run OFF permits governed live writes for authorized roles.';
        }
    }

    async function setDryRun(id, enabled) {
        return request(`/api/auth/users/${encodeURIComponent(id)}/dry-run`, {
            method: 'POST',
            body: JSON.stringify({ enabled: Boolean(enabled) })
        });
    }

    async function toggleDryRun(id) {
        const user = users.find(item => item.id === id);
        if (!user) return;
        if (String(user.role || '').toLowerCase() === 'admin') {
            showMessage('Dry Run is always disabled for Admin profiles.', true);
            return;
        }
        const enable = !Boolean(user.dryRunEnabled);
        const label = enable ? 'enable Dry Run' : 'disable Dry Run and permit governed live writes';
        if (!window.confirm(`${label} for ${user.username}? The user will need to sign in again.`)) return;
        try {
            await setDryRun(id, enable);
            showMessage(enable
                ? `Dry Run enabled for ${user.username}. Agentic updates will not modify source data.`
                : `Dry Run disabled for ${user.username}. Authorized Agentic updates can execute live.`);
            await load();
        } catch (error) {
            showMessage(error.message || 'Unable to update Dry Run access.', true);
        }
    }

    function openCreate() {
        userForm.reset();
        userForm.elements.id.value = '';
        userForm.elements.username.disabled = false;
        document.querySelector('[data-create-password]').classList.remove('hidden');
        userForm.elements.password.required = true;
        userForm.elements.dryRunEnabled.value = 'false';
        syncDryRunEditor();
        document.getElementById('userDialogTitle').textContent = 'Add user';
        dialogMessage('userDialogMessage', '');
        userDialog.showModal();
        userForm.elements.username.focus();
    }

    function openEdit(id) {
        const user = users.find(item => item.id === id);
        if (!user) return;
        userForm.reset();
        userForm.elements.id.value = user.id;
        userForm.elements.username.value = user.username;
        userForm.elements.username.disabled = true;
        userForm.elements.displayName.value = user.displayName || '';
        userForm.elements.email.value = user.email || '';
        userForm.elements.role.value = ['Customer','Business','Technical','Admin'].find(role => role.toLowerCase() === String(user.role || '').toLowerCase()) || 'Customer';
        userForm.elements.dryRunEnabled.value = user.dryRunEnabled ? 'true' : 'false';
        syncDryRunEditor();
        document.querySelector('[data-create-password]').classList.add('hidden');
        userForm.elements.password.required = false;
        document.getElementById('userDialogTitle').textContent = `Edit ${user.username}`;
        dialogMessage('userDialogMessage', '');
        userDialog.showModal();
    }

    async function saveUser(event) {
        event.preventDefault();
        const data = new FormData(userForm);
        const id = String(data.get('id') || '');
        const body = {
            username: String(data.get('username') || '').trim(),
            displayName: String(data.get('displayName') || '').trim(),
            email: String(data.get('email') || '').trim() || null,
            role: String(data.get('role') || 'Customer'),
            dryRunEnabled: String(data.get('dryRunEnabled') || 'false') === 'true',
            password: String(data.get('password') || '')
        };
        try {
            let savedUser;
            if (id) {
                savedUser = await request(`/api/auth/users/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify({ displayName: body.displayName, email: body.email, role: body.role }) });
            } else {
                savedUser = await request('/api/auth/users', { method: 'POST', body: JSON.stringify(body) });
            }
            const targetId = id || savedUser?.id;
            const adminRole = String(body.role || '').toLowerCase() === 'admin';
            if (targetId) await setDryRun(targetId, adminRole ? false : body.dryRunEnabled);
            userDialog.close();
            showMessage(id ? 'User profile updated.' : 'User created.');
            await load();
        } catch (error) {
            dialogMessage('userDialogMessage', error.message || 'Unable to save user.');
        }
    }

    function openDelegate(id) {
        const user = users.find(item => item.id === id);
        if (!user) return;
        delegateForm.reset();
        delegateForm.elements.id.value = id;
        delegateForm.elements.role.value = ['Customer','Business','Technical','Admin'].find(role => role.toLowerCase() === String(user.role).toLowerCase()) || 'Customer';
        document.getElementById('delegateTarget').textContent = `Assign a governed access profile to ${user.username}.`;
        dialogMessage('delegateMessage', '');
        delegateDialog.showModal();
    }

    async function delegateUser(event) {
        event.preventDefault();
        const data = new FormData(delegateForm);
        try {
            await request(`/api/auth/users/${encodeURIComponent(String(data.get('id') || ''))}/delegate`, {
                method: 'POST',
                body: JSON.stringify({ role: String(data.get('role') || 'Customer'), reason: String(data.get('reason') || '').trim() || null })
            });
            delegateDialog.close();
            showMessage('Role delegation completed. The user has been prompted to sign in again.');
            await load();
        } catch (error) {
            dialogMessage('delegateMessage', error.message || 'Unable to delegate the role.');
        }
    }

    function openPrompt(id) {
        const user = users.find(item => item.id === id);
        if (!user || !user.isActive) return;
        promptForm.reset();
        promptForm.elements.id.value = id;
        promptForm.elements.severity.value = 'info';
        document.getElementById('promptTarget').textContent = `Send a visible Dashboard/Agentic AI prompt to ${user.username}.`;
        dialogMessage('promptMessage', '');
        promptDialog.showModal();
        promptForm.elements.title.focus();
    }

    async function promptUser(event) {
        event.preventDefault();
        const data = new FormData(promptForm);
        const rawExpiry = String(data.get('expiresAtUtc') || '');
        const expiresAtUtc = rawExpiry ? new Date(rawExpiry).toISOString() : null;
        try {
            await request(`/api/auth/users/${encodeURIComponent(String(data.get('id') || ''))}/prompts`, {
                method: 'POST',
                body: JSON.stringify({
                    title: String(data.get('title') || '').trim(),
                    message: String(data.get('message') || '').trim(),
                    severity: String(data.get('severity') || 'info'),
                    actionUrl: String(data.get('actionUrl') || '').trim() || null,
                    expiresAtUtc
                })
            });
            promptDialog.close();
            showMessage('Prompt sent. It will appear in the user’s notification drawer.');
        } catch (error) {
            dialogMessage('promptMessage', error.message || 'Unable to send the prompt.');
        }
    }

    async function toggleUser(id, active) {
        const user = users.find(item => item.id === id);
        if (!user) return;
        const verb = active ? 'deactivate' : 'activate';
        if (!window.confirm(`${verb === 'deactivate' ? 'Deactivate' : 'Activate'} ${user.username}?`)) return;
        try {
            await request(`/api/auth/users/${encodeURIComponent(id)}${active ? '' : '/activate'}`, { method: active ? 'DELETE' : 'POST', body: active ? undefined : '{}' });
            showMessage(`User ${active ? 'deactivated' : 'activated'}.`);
            await load();
        } catch (error) {
            showMessage(error.message || `Unable to ${verb} user.`, true);
        }
    }

    async function purgeUser(id) {
        const user = users.find(item => item.id === id);
        if (!user || user.isActive) return;
        const confirmation = window.prompt(`Permanent deletion cannot be undone. Type DELETE ${user.username} to continue.`);
        if (confirmation !== `DELETE ${user.username}`) return;
        try {
            await request(`/api/auth/users/${encodeURIComponent(id)}/purge`, { method: 'DELETE' });
            showMessage(`User ${user.username} permanently deleted.`);
            await load();
        } catch (error) {
            showMessage(error.message || 'Unable to permanently delete the user.', true);
        }
    }

    function openReset(id) {
        const user = users.find(item => item.id === id);
        if (!user) return;
        resetForm.reset();
        resetForm.elements.id.value = id;
        document.getElementById('resetPasswordTarget').textContent = `Set a new password for ${user.username}.`;
        dialogMessage('resetPasswordMessage', '');
        resetDialog.showModal();
        resetForm.elements.newPassword.focus();
    }

    async function resetPassword(event) {
        event.preventDefault();
        const data = new FormData(resetForm);
        const password = String(data.get('newPassword') || '');
        const confirmation = String(data.get('confirmPassword') || '');
        if (password !== confirmation) {
            dialogMessage('resetPasswordMessage', 'Passwords do not match.');
            return;
        }
        try {
            await request(`/api/auth/users/${encodeURIComponent(String(data.get('id') || ''))}/reset-password`, { method: 'POST', body: JSON.stringify({ newPassword: password }) });
            resetDialog.close();
            showMessage('Password reset completed. Existing sessions will be rejected on the next request.');
        } catch (error) {
            dialogMessage('resetPasswordMessage', error.message || 'Unable to reset password.');
        }
    }

    document.addEventListener('DOMContentLoaded', async () => {
        await window.RUSAuth?.ready;
        if (String(window.RUSAuth?.getUser?.()?.role || '').toLowerCase() !== 'admin') {
            window.location.replace('/rus-app.html?accessDenied=admin');
            return;
        }
        document.getElementById('openCreateUser')?.addEventListener('click', openCreate);
        document.getElementById('refreshUsers')?.addEventListener('click', load);
        document.getElementById('closeUserDialog')?.addEventListener('click', () => userDialog.close());
        document.getElementById('cancelUserDialog')?.addEventListener('click', () => userDialog.close());
        document.querySelectorAll('[data-reset-close]').forEach(button => button.addEventListener('click', () => resetDialog.close()));
        document.querySelectorAll('[data-delegate-close]').forEach(button => button.addEventListener('click', () => delegateDialog.close()));
        document.querySelectorAll('[data-prompt-close]').forEach(button => button.addEventListener('click', () => promptDialog.close()));
        userForm?.elements?.role?.addEventListener('change', syncDryRunEditor);
        userForm?.addEventListener('submit', saveUser);
        resetForm?.addEventListener('submit', resetPassword);
        delegateForm?.addEventListener('submit', delegateUser);
        promptForm?.addEventListener('submit', promptUser);
        await load();
    });
})();

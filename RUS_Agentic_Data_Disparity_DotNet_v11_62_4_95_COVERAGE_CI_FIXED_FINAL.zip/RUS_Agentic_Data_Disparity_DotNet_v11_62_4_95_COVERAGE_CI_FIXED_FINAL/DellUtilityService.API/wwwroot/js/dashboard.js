'use strict';

(function () {
    const byId = (id) => document.getElementById(id);
    const envelope = (payload) => payload?.data ?? payload ?? {};

    function setUpdatedAt() {
        const node = byId('dashboardUpdatedAt');
        if (node) node.textContent = `Updated ${new Intl.DateTimeFormat(undefined, { timeStyle: 'short' }).format(new Date())}`;
    }

    function renderHealthRow(name, status, label) {
        const row = document.querySelector(`[data-service="${name}"]`);
        if (!row) return;
        const dot = row.querySelector('.service-dot');
        dot.className = `service-dot ${status}`;
        row.querySelector('b').textContent = label;
    }

    async function refreshHealth() {
        renderHealthRow('agentic', 'checking', 'Checking');
        renderHealthRow('write-mode', 'checking', 'Checking');

        // v11.53: process liveness and capability readiness are intentionally
        // separate. A running Agentic API must not be labelled DEGRADED merely
        // because an optional/governed-write capability needs attention.
        const [liveResult, readyResult, configResult] = await Promise.allSettled([
            fetch('/api/agentic-ai/health/live', { cache: 'no-store' }),
            fetch('/api/agentic-ai/health/ready?deep=false', { cache: 'no-store' }),
            fetch('/api/agentic-ai/configuration', { cache: 'no-store' })
        ]);

        const liveResponse = liveResult.status === 'fulfilled' ? liveResult.value : null;
        const readyResponse = readyResult.status === 'fulfilled' ? readyResult.value : null;
        const configResponse = configResult.status === 'fulfilled' ? configResult.value : null;

        const livePayload = liveResponse ? await liveResponse.json().catch(() => ({})) : {};
        const readyPayload = readyResponse ? await readyResponse.json().catch(() => ({})) : {};
        const configPayload = configResponse ? await configResponse.json().catch(() => ({})) : {};
        const liveData = envelope(livePayload);
        const readyData = envelope(readyPayload);
        const config = envelope(configPayload);

        const liveStatus = String(liveData.status || '').toUpperCase();
        const readyStatus = String(readyData.status || '').toUpperCase();
        const processOnline = Boolean(
            (liveResponse?.ok && ['LIVE', 'ONLINE', 'READY'].includes(liveStatus)) ||
            (readyResponse?.ok && ['LIVE', 'ONLINE', 'READY', 'DEGRADED'].includes(readyStatus))
        );

        renderHealthRow(
            'agentic',
            processOnline ? 'online' : 'offline',
            processOnline ? 'Online' : 'Unavailable');

        const canPlanWrites = Boolean(config.features?.planAgenticUpdates ?? config.features?.PlanAgenticUpdates);
        const mode = canPlanWrites
            ? String(config.effectiveWriteMode || readyData.source_write_mode || 'unknown').toLowerCase()
            : 'read_only';
        const writeStatus = String(readyData.write_status || readyData.writeStatus || '').toUpperCase();
        const writeNeedsAttention = mode === 'live' && (
            writeStatus === 'DEGRADED' ||
            Boolean(readyData.manual_write_bridge_error)
        );

        let modeLabel = mode === 'read_only' ? 'Read only' : mode.replaceAll('_', ' ') || 'Unknown';
        let modeClass = mode === 'dry_run' || mode === 'read_only' ? 'neutral' : mode === 'live' ? 'online' : 'warning';
        if (writeNeedsAttention) {
            modeLabel = 'Live · bridge attention';
            modeClass = 'warning';
        } else if (mode === 'live' && writeStatus === 'READY') {
            modeLabel = 'Live · ready';
        }
        renderHealthRow('write-mode', modeClass, modeLabel);

        setUpdatedAt();
    }

    function syncKpis(event) {
        const summary = event.detail?.summary || {};
        const values = {
            total: summary.total || 0,
            completed: summary.completed || 0,
            pending: summary.pending || 0,
            failed: summary.failed || 0,
            actors: summary.uniqueActors || summary.unique_actors || Object.keys(summary.actorCounts || summary.actor_counts || {}).length
        };
        Object.entries(values).forEach(([key, value]) => {
            document.querySelectorAll(`[data-dashboard-kpi="${key}"]`).forEach((node) => { node.textContent = String(value); });
        });
        setUpdatedAt();
    }

    document.addEventListener('DOMContentLoaded', () => {
        refreshHealth();
        byId('serviceRefreshButton')?.addEventListener('click', refreshHealth);
        byId('dashboardRefreshButton')?.addEventListener('click', () => {
            refreshHealth();
            const audit = document.querySelector('[data-audit-root]');
            if (audit && window.RUSAuditTrail) window.RUSAuditTrail.load(audit, { limit: 150 });
        });
        document.querySelector('[data-audit-root]')?.addEventListener('rus:audit-loaded', syncKpis);
        const refreshAudit = () => {
            const audit = document.querySelector('[data-audit-root]');
            if (audit && window.RUSAuditTrail) window.RUSAuditTrail.load(audit, { limit: 150 });
        };
        window.setInterval(() => {
            if (!document.hidden) refreshAudit();
        }, 30000);
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) refreshAudit();
        });
        // Browser back/forward cache can restore an old Dashboard DOM after an
        // Agentic update. Always refresh health + audit/KPIs when the page is
        // shown again so completed analyses/updates are reflected immediately.
        window.addEventListener('pageshow', () => {
            refreshHealth();
            refreshAudit();
            try { localStorage.removeItem('rus.dashboard.auditDirty'); } catch { /* storage unavailable */ }
        });
        if (new URLSearchParams(window.location.search).get('accessDenied') === 'admin') {
            window.setTimeout(() => window.showMessage?.('Administrator access is required for user management.', true), 250);
        }
        document.body.classList.add('dashboard-ready');
    });
})();

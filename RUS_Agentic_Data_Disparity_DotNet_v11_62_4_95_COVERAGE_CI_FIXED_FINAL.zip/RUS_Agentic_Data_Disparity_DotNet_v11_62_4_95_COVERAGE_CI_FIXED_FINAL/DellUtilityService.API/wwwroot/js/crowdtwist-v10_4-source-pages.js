// CrowdTwist Operations JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Update property form handler
    const updatePropertyForm = document.getElementById('updatePropertyForm');
    if (updatePropertyForm) {
        updatePropertyForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(updatePropertyForm);
            const data = {
                crowdTwistId: parseInt(formData.get('crowdTwistId')),
                propertyName: formData.get('propertyName'),
                newValue: formData.get('newValue')
            };
            
            showLoader('Updating property in CrowdTwist...');
            try {
                const response = await crowdTwistApi.updateProperty(data);
                if (response.success) {
                    showMessage('Property updated successfully in CrowdTwist');
                    updatePropertyForm.reset();
                } else {
                    showMessage(response.message || 'Failed to update property', true);
                }
            } catch (error) {
                showMessage('Error updating property', true);
            } finally {
                hideLoader();
            }
        });
    }

    // Bulk upload handler
    const uploadCrowdTwistBulkBtn = document.getElementById('uploadCrowdTwistBulkBtn');
    if (uploadCrowdTwistBulkBtn) {
        uploadCrowdTwistBulkBtn.addEventListener('click', uploadCrowdTwistBulkFile);
    }
});

async function searchCrowdTwist() {
    const searchType = document.getElementById('ctSearchType').value;
    const searchValue = document.getElementById('ctSearchValue').value;
    
    if (!searchValue) {
        showMessage('Please enter a search value', true);
        return;
    }
    
    showLoader('Searching member in CrowdTwist...');
    try {
        const response = await crowdTwistApi.searchMember(searchType, searchValue);
        if (response.success) {
            showResult('ctSearchResult', response.data, true);
            showMessage('Member found in CrowdTwist');
        } else {
            showMessage(response.message || 'Member not found', true);
            document.getElementById('ctSearchResult').innerHTML = '<p class="not-found">Member not found</p>';
        }
    } catch (error) {
        showMessage('Error searching member', true);
        document.getElementById('ctSearchResult').innerHTML = '<p class="not-found">Error searching member</p>';
    } finally {
        hideLoader();
    }
}

async function uploadCrowdTwistBulkFile() {
    const fileInput = document.getElementById('crowdtwistBulkFile');
    const resultSection = document.getElementById('crowdtwistBulkResult');
    
    if (!fileInput.files || fileInput.files.length === 0) {
        alert('Please select a file to upload');
        return;
    }

    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append('file', file);

    showLoader('Processing CrowdTwist bulk update...');
    
    try {
        const response = await fetch('/api/crowdtwist/bulkupdate', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Upload failed');
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `CrowdTwist_BulkUpdate_Result_${new Date().toISOString().slice(0, 10)}.xlsx`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        resultSection.innerHTML = `
            <div class="success-message">
                <h3>Upload Successful!</h3>
                <p>Result file has been downloaded automatically.</p>
            </div>
        `;
    } catch (error) {
        resultSection.innerHTML = `
            <div class="error-message">
                <h3>Upload Failed</h3>
                <p>${error.message}</p>
            </div>
        `;
    } finally {
        hideLoader();
    }
}

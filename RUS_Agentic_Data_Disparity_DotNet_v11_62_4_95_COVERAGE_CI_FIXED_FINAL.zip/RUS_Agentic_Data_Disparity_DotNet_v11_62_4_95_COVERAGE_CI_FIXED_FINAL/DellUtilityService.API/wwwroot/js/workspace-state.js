'use strict';

(function () {
    const PREFIX = 'rus.workspace.v4';
    const LEGACY_PREFIX = 'rus.workspace.v3';
    const page = document.body?.dataset?.page || window.location.pathname.split('/').pop()?.replace('.html', '') || 'dashboard';
    const key = `${PREFIX}.${page}`;
    const legacyKey = `${LEGACY_PREFIX}.${page}`;
    const SHARED_KEYS = new Set([
        'rus.agentic.sessionId',
        'rus.agentic.jobId',
        'rus.agentic.chatContext'
    ]);
    let writeTimer = null;
    let htmlTimer = null;

    function parse(raw, fallback) {
        try {
            const value = JSON.parse(raw || '');
            return value && typeof value === 'object' ? value : fallback;
        } catch {
            return fallback;
        }
    }

    function read() {
        const current = parse(sessionStorage.getItem(key), null);
        if (current) return current;
        const legacy = parse(sessionStorage.getItem(legacyKey), {});
        if (Object.keys(legacy).length) {
            sessionStorage.setItem(key, JSON.stringify(legacy));
            sessionStorage.removeItem(legacyKey);
        }
        return legacy;
    }

    function write(value) {
        sessionStorage.setItem(key, JSON.stringify({ ...value, updatedAt: new Date().toISOString() }));
    }

    function patch(next) {
        const value = { ...read(), ...next };
        write(value);
        return value;
    }

    function schedulePatch(next) {
        clearTimeout(writeTimer);
        writeTimer = window.setTimeout(() => patch(next), 80);
    }

    function getShared(name, fallback = null) {
        if (!SHARED_KEYS.has(name)) return sessionStorage.getItem(name) ?? fallback;
        const sessionValue = sessionStorage.getItem(name);
        if (sessionValue !== null) return sessionValue;
        const sharedValue = localStorage.getItem(name);
        if (sharedValue !== null) sessionStorage.setItem(name, sharedValue);
        return sharedValue ?? fallback;
    }

    function setShared(name, value) {
        const normalized = value === null || value === undefined ? null : String(value);
        if (normalized === null) return removeShared(name);
        sessionStorage.setItem(name, normalized);
        if (SHARED_KEYS.has(name)) localStorage.setItem(name, normalized);
        window.dispatchEvent(new CustomEvent('rus:shared-state-changed', { detail: { name, value: normalized } }));
        return normalized;
    }

    function removeShared(name) {
        sessionStorage.removeItem(name);
        if (SHARED_KEYS.has(name)) localStorage.removeItem(name);
        window.dispatchEvent(new CustomEvent('rus:shared-state-changed', { detail: { name, value: null } }));
    }

    function hydrateShared() {
        SHARED_KEYS.forEach((name) => {
            if (sessionStorage.getItem(name) === null) {
                const value = localStorage.getItem(name);
                if (value !== null) sessionStorage.setItem(name, value);
            }
        });
    }

    function persistFields() {
        const fields = document.querySelectorAll('input[id]:not([type="file"]):not([type="password"]), textarea[id], select[id]');
        const values = {};
        fields.forEach((field) => {
            if (field.dataset.noPersist === 'true') return;
            values[field.id] = field.type === 'checkbox' || field.type === 'radio'
                ? Boolean(field.checked)
                : field.value;
        });
        schedulePatch({ fields: values });
    }

    function restoreFields() {
        const values = read().fields || {};
        Object.entries(values).forEach(([id, value]) => {
            const field = document.getElementById(id);
            if (!field || field.dataset.noPersist === 'true') return;
            if (field.type === 'checkbox' || field.type === 'radio') field.checked = Boolean(value);
            else field.value = value ?? '';
        });
    }

    function persistHtmlNow() {
        const html = {};
        document.querySelectorAll('[data-persist-html][id]').forEach((node) => {
            html[node.id] = node.innerHTML;
        });
        patch({ html });
    }

    function persistHtml() {
        clearTimeout(htmlTimer);
        htmlTimer = window.setTimeout(persistHtmlNow, 150);
    }

    function restoreHtml() {
        const html = read().html || {};
        Object.entries(html).forEach(([id, value]) => {
            const node = document.getElementById(id);
            if (node && node.dataset.persistHtml !== 'false') node.innerHTML = value || '';
        });
    }

    function setSection(name, value) {
        const state = read();
        patch({ sections: { ...(state.sections || {}), [name]: value } });
    }

    function getSection(name, fallback = null) {
        return (read().sections || {})[name] ?? fallback;
    }

    function clearPage() {
        sessionStorage.removeItem(key);
        sessionStorage.removeItem(legacyKey);
    }

    function restoreAll() {
        hydrateShared();
        restoreFields();
        restoreHtml();
        const state = read();
        if (Number.isFinite(state.scrollY)) requestAnimationFrame(() => window.scrollTo(0, state.scrollY));
        document.dispatchEvent(new CustomEvent('rus:workspace-restored', { detail: { page, state } }));
    }

    function persistAll() {
        persistFields();
        persistHtmlNow();
        patch({ scrollY: window.scrollY });
    }

    function bind() {
        restoreAll();
        document.addEventListener('input', (event) => {
            if (event.target.matches('input[id]:not([type="file"]):not([type="password"]),textarea[id],select[id]')) persistFields();
        });
        document.addEventListener('change', (event) => {
            if (event.target.matches('input[id]:not([type="file"]):not([type="password"]),textarea[id],select[id]')) persistFields();
        });

        const observer = new MutationObserver(persistHtml);
        document.querySelectorAll('[data-persist-html][id]').forEach((node) => observer.observe(node, { childList: true, subtree: true, characterData: true }));

        let scrollTimer = null;
        window.addEventListener('scroll', () => {
            clearTimeout(scrollTimer);
            scrollTimer = window.setTimeout(() => patch({ scrollY: window.scrollY }), 120);
        }, { passive: true });
        window.addEventListener('pagehide', persistAll);
        window.addEventListener('beforeunload', persistAll);
        window.addEventListener('pageshow', (event) => { if (event.persisted) restoreAll(); });
        window.addEventListener('storage', (event) => {
            if (SHARED_KEYS.has(event.key)) {
                if (event.newValue === null) sessionStorage.removeItem(event.key);
                else sessionStorage.setItem(event.key, event.newValue);
                window.dispatchEvent(new CustomEvent('rus:shared-state-changed', { detail: { name: event.key, value: event.newValue } }));
            }
        });
    }

    window.RUSWorkspace = {
        page, read, write, patch, setSection, getSection, clearPage,
        persistFields, restoreFields, persistHtml, restoreHtml,
        getShared, setShared, removeShared
    };
    hydrateShared();
    document.addEventListener('DOMContentLoaded', bind);
})();

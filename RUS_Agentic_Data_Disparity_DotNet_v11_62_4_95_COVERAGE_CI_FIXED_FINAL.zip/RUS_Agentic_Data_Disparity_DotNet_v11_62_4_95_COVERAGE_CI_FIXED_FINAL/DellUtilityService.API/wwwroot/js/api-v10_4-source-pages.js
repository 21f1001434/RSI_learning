const API_BASE_URL = '/api';

async function apiCall(endpoint, method = 'GET', data = null) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json',
        },
    };

    if (data) {
        options.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
        const result = await response.json();
        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// CPS API
const cpsApi = {
    createUser: async (data) => {
        return await apiCall('/cps/create-user', 'POST', data);
    },
    getUser: async (email) => {
        return await apiCall(`/cps/get-user/${encodeURIComponent(email)}`);
    },
    getUserByProfileId: async (profileId) => {
        return await apiCall(`/cps/get-user-by-profile/${encodeURIComponent(profileId)}`);
    }
};

// Members API
const membersApi = {
    getMemberById: async (id) => {
        return await apiCall(`/members/get-by-id/${encodeURIComponent(id)}`);
    },
    getMemberByProfileId: async (profileId) => {
        return await apiCall(`/members/get-by-profile/${encodeURIComponent(profileId)}`);
    },
    updateColumn: async (data) => {
        return await apiCall('/members/update-column', 'POST', data);
    },
    bulkUpdateColumns: async (data) => {
        return await apiCall('/members/bulk-update-columns', 'POST', data);
    }
};

// CrowdTwist API
const crowdTwistApi = {
    searchMember: async (searchType, searchValue) => {
        return await apiCall(`/crowdtwist/search?searchType=${encodeURIComponent(searchType)}&searchValue=${encodeURIComponent(searchValue)}`);
    },
    updateProperty: async (data) => {
        return await apiCall('/crowdtwist/update-property', 'POST', data);
    },
    bulkUpdateProperties: async (data) => {
        return await apiCall('/crowdtwist/bulk-update-properties', 'POST', data);
    }
};

// Search API
const searchApi = {
    searchByEmail: async (email) => {
        return await apiCall(`/search/by-email?email=${encodeURIComponent(email)}`);
    },
    searchByProfileId: async (profileId) => {
        return await apiCall(`/search/by-profile-id?profileId=${encodeURIComponent(profileId)}`);
    }
};

// AI Analysis API
const aiAnalysisApi = {
    analyze: async (searchType, searchValue) => {
        return await apiCall(`/AIAnalysis/analyze?searchType=${encodeURIComponent(searchType)}&searchValue=${encodeURIComponent(searchValue)}`);
    },
    quickAction: async (action) => {
        return await apiCall(`/AIAnalysis/quick-action?action=${encodeURIComponent(action)}`);
    }
};

// Utility functions
function showResult(containerId, data, isTable = false, expectedProperties = null) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (isTable && data) {
        let tableHtml = '<table class="result-table"><thead><tr><th>Field</th><th>Value</th></tr></thead><tbody>';
        const propertiesToDisplay = expectedProperties || Object.keys(data);
        const displayedProperties = new Set();
        
        for (const key of propertiesToDisplay) {
            // Skip if this property or its variant has already been displayed
            const normalizedKey = key.toLowerCase().replace(/_/g, '').replace(/([A-Z])/g, '');
            if (displayedProperties.has(normalizedKey)) {
                continue;
            }
            
            const value = data.hasOwnProperty(key) ? data[key] : null;
            const displayValue = formatValue(value);
            tableHtml += `<tr><td>${key}</td><td>${displayValue}</td></tr>`;
            displayedProperties.add(normalizedKey);
        }
        tableHtml += '</tbody></table>';
        container.innerHTML = tableHtml;
    } else if (data) {
        container.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
    } else {
        container.innerHTML = '<p class="not-found">No data found</p>';
    }
}

function formatValue(value) {
    if (value === null || value === undefined) {
        return 'N/A';
    }
    
    if (typeof value === 'string' && value.trim() === '') {
        return 'N/A';
    }
    
    if (Array.isArray(value)) {
        if (value.length === 0) {
            return 'N/A';
        }
        let result = '<div class="array-container">';
        value.forEach((item, index) => {
            result += `<div class="array-item"><strong>[${index}]</strong>: ${formatValue(item)}</div>`;
        });
        result += '</div>';
        return result;
    }
    
    if (typeof value === 'object') {
        let result = '<div class="object-container">';
        for (const [k, v] of Object.entries(value)) {
            result += `<div class="object-item"><strong>${k}:</strong> ${formatValue(v)}</div>`;
        }
        result += '</div>';
        return result;
    }
    
    return value;
}

function showMessage(message, isError = false) {
    const div = document.createElement('div');
    div.style.position = 'fixed';
    div.style.top = '20px';
    div.style.right = '20px';
    div.style.padding = '16px 24px';
    div.style.background = isError ? '#ff4d4f' : '#52c41a';
    div.style.color = 'white';
    div.style.borderRadius = '4px';
    div.style.zIndex = '9999';
    div.textContent = message;
    document.body.appendChild(div);
    
    setTimeout(() => {
        div.remove();
    }, 3000);
}

function setLoading(buttonId, loading) {
    const button = document.getElementById(buttonId);
    if (button) {
        button.disabled = loading;
        button.textContent = loading ? 'Loading...' : button.getAttribute('data-original-text') || button.textContent;
    }
}

// Agentic Dell AIA / AutoGen API proxy. All requests stay same-origin and the
// internal Python API key remains on the .NET server.
async function agenticRequest(path, options = {}) {
    const response = await fetch(`/api/agentic-ai${path}`, {
        cache: 'no-store',
        ...options,
        headers: {
            ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
            ...(options.headers || {})
        }
    });

    const contentType = response.headers.get('content-type') || '';
    let payload = null;
    if (contentType.includes('application/json')) {
        payload = await response.json().catch(() => null);
    } else {
        payload = await response.text().catch(() => '');
    }

    if (!response.ok) {
        const message = payload?.error?.message
            || payload?.detail
            || payload?.message
            || (typeof payload === 'string' ? payload : '')
            || `Request failed with HTTP ${response.status}`;
        const error = new Error(message);
        error.status = response.status;
        error.payload = payload;
        throw error;
    }

    return payload;
}

const agenticAiApi = {
    configuration: () => agenticRequest('/configuration'),
    bootstrap: (sessionId = null, deepHealth = false) => agenticRequest('/bootstrap', {
        method: 'POST',
        body: JSON.stringify({ session_id: sessionId, deep_health: deepHealth })
    }),
    live: () => agenticRequest('/health/live'),
    ready: (deep = false) => agenticRequest(`/health/ready?deep=${deep}`),

    createSession: (metadata = { channel: 'dotnet-rus-ui' }) => agenticRequest('/sessions', {
        method: 'POST',
        body: JSON.stringify({ metadata })
    }),
    getSession: (sessionId, includeMessages = true) =>
        agenticRequest(`/sessions/${encodeURIComponent(sessionId)}?includeMessages=${includeMessages}`),
    resetSession: (sessionId) => agenticRequest(`/sessions/${encodeURIComponent(sessionId)}/reset`, {
        method: 'POST',
        body: '{}'
    }),
    deleteSession: (sessionId) => agenticRequest(`/sessions/${encodeURIComponent(sessionId)}`, {
        method: 'DELETE'
    }),
    getSessionActiveBatch: (sessionId) =>
        agenticRequest(`/sessions/${encodeURIComponent(sessionId)}/active-batch`),

    chat: (request) => agenticRequest('/chat', {
        method: 'POST',
        body: JSON.stringify(request)
    }),
    analyze: (request) => agenticRequest('/analysis/individual', {
        method: 'POST',
        body: JSON.stringify(request)
    }),
    getAnalysis: (runId) => agenticRequest(`/analysis/${encodeURIComponent(runId)}`),
    htmlReportUrl: (runId) => `/api/agentic-ai/analysis/${encodeURIComponent(runId)}/report.html`,
    jsonReportUrl: (runId) => `/api/agentic-ai/analysis/${encodeURIComponent(runId)}/report.json`,

    submitBatch: (request) => agenticRequest('/batches', {
        method: 'POST',
        body: JSON.stringify(request)
    }),
    uploadBatch: (file, settings) => {
        const data = new FormData();
        data.append('file', file, file.name);
        const query = new URLSearchParams({
            maxParallel: String(settings.maxParallel ?? 4),
            maxParallelAi: String(settings.maxParallelAi ?? 1),
            includeGroupAi: String(settings.includeGroupAi ?? true)
        });
        if (settings.sessionId) query.set('sessionId', settings.sessionId);
        return agenticRequest(`/batches/upload?${query}`, { method: 'POST', body: data });
    },
    getBatch: (jobId) => agenticRequest(`/batches/${encodeURIComponent(jobId)}`),
    getBatchSummary: (jobId) => agenticRequest(`/batches/${encodeURIComponent(jobId)}/summary`),
    batchDownloadUrl: (jobId) => `/api/agentic-ai/batches/${encodeURIComponent(jobId)}/download`,

    getCatalog: () => agenticRequest('/knowledge/catalog'),
    getOperation: (operationId) => agenticRequest(`/knowledge/operations/${encodeURIComponent(operationId)}`),
    validatePayload: (operationId, payload) => agenticRequest('/knowledge/validate-payload', {
        method: 'POST',
        body: JSON.stringify({ operation_id: operationId, payload })
    }),
    getUseCases: (runId) => agenticRequest(`/analysis/${encodeURIComponent(runId)}/use-cases`),
    compileUseCasePlan: (runId, useCaseId, includeDellAiaReview = true) => agenticRequest('/use-cases/plan', {
        method: 'POST',
        body: JSON.stringify({
            run_id: runId,
            use_case_id: useCaseId,
            include_dell_aia_review: includeDellAiaReview
        })
    })
};

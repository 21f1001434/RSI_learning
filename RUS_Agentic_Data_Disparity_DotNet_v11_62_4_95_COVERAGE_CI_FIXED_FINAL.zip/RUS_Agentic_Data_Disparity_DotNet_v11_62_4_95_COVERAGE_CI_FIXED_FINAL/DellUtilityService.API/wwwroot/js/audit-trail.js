'use strict';

(function () {
    const escape = (value) => String(value ?? '')
        .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;').replaceAll("'", '&#039;');

    const displayValue = (value) => {
        if (value === null || value === undefined || value === '') return '—';
        if (typeof value === 'object') {
            try { return JSON.stringify(value); } catch { return String(value); }
        }
        return String(value);
    };

    const envelope = (payload) => payload?.data ?? payload ?? {};

    function statusClass(status) {
        const text = String(status || '').toLowerCase();
        if (text.includes('complete') || text.includes('success') || text.includes('dry_run') || text.includes('verified')) return 'success';
        if (text.includes('fail') || text.includes('block') || text.includes('abort') || text.includes('partial') || text.includes('error')) return 'error';
        if (text.includes('await') || text.includes('execut') || text.includes('plan') || text.includes('start') || text.includes('pending')) return 'pending';
        if (text.includes('cancel')) return 'warning';
        return 'neutral';
    }

    function formatTime(value) {
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return value || '—';
        return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
    }

    function currentPrivacy(root) {
        const select = root.querySelector('[data-audit-privacy]');
        if (!select) return 'true';
        return select.value === 'false' ? 'false' : 'true';
    }

    function queryString(root, limit) {
        const params = new URLSearchParams({ limit: String(limit), masked: currentPrivacy(root) });
        root.querySelectorAll('[data-audit-filter]').forEach((input) => {
            if (input.disabled) return;
            const value = String(input.value || '').trim();
            if (value) params.set(input.dataset.auditFilter, value);
        });
        return params.toString();
    }

    async function load(root, options = {}) {
        const table = root.querySelector('[data-audit-table]');
        const empty = root.querySelector('[data-audit-empty]');
        const error = root.querySelector('[data-audit-error]');
        const refresh = root.querySelector('[data-audit-refresh]');
        if (refresh) refresh.disabled = true;
        root.classList.add('is-loading');
        if (error) error.classList.add('hidden');
        try {
            const response = await fetch(`/api/audit-trail?${queryString(root, options.limit || 100)}`, { cache: 'no-store' });
            const payload = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(payload?.error?.message || payload?.message || `HTTP ${response.status}`);
            const data = envelope(payload);
            const entries = data.entries || [];
            applyScope(root, data.scope || {});
            renderSummary(root, data.summary || {});
            renderTable(table, entries);
            if (empty) empty.classList.toggle('hidden', entries.length > 0);
            root.dataset.auditLoaded = 'true';
            root.dispatchEvent(new CustomEvent('rus:audit-loaded', { detail: data }));
            return data;
        } catch (exception) {
            if (table) table.innerHTML = '';
            if (empty) empty.classList.add('hidden');
            if (error) {
                error.textContent = `Audit trail unavailable: ${exception.message}`;
                error.classList.remove('hidden');
            }
            return null;
        } finally {
            root.classList.remove('is-loading');
            if (refresh) refresh.disabled = false;
        }
    }

    function applyScope(root, scope) {
        const role = String(scope.role || 'Customer').toLowerCase();
        const admin = role === 'admin';
        const label = root.querySelector('[data-audit-scope-label]');
        const description = root.querySelector('[data-audit-scope-description]');
        const privacy = root.querySelector('[data-audit-privacy]');
        const actorFilter = root.querySelector('[data-audit-filter="actor"]');
        const exportButton = root.querySelector('[data-audit-export]');
        const roleLabel = scope.roleLabel || ({ customer: 'Customer Support', business: 'Business Operations', technical: 'Technical Operations', admin: 'Administrator' }[role] || scope.role);
        if (label) label.textContent = admin ? 'Admin audit view · all users' : `${roleLabel} audit · ${scope.username || 'signed-in user'}`;
        if (description) {
            description.textContent = admin
                ? 'All users and all manual/Agentic events are visible with canonical unmasked values.'
                : role === 'technical'
                    ? 'Only your activity is shown, including technical identifiers and diagnostics. Masked and unmasked modes are available.'
                    : role === 'business'
                        ? 'Only your activity is shown with business-safe before/after values; internal payloads and diagnostics are hidden.'
                        : 'Only your support activity is shown. Internal payloads, correlation identifiers, and technical evidence are hidden.';
        }
        if (privacy) {
            privacy.value = scope.privacyMode === 'unmasked' ? 'false' : 'true';
            privacy.disabled = admin || scope.canSelectPrivacy === false;
            privacy.closest('label')?.classList.toggle('admin-fixed', admin);
        }
        if (actorFilter) {
            actorFilter.disabled = !scope.allUsers;
            actorFilter.value = scope.allUsers ? actorFilter.value : (scope.username || '');
            actorFilter.placeholder = scope.allUsers ? 'Name or email' : 'Scoped to your account';
            actorFilter.closest('label')?.classList.toggle('hidden', !scope.allUsers);
        }
        if (exportButton) exportButton.classList.toggle('hidden', scope.canExportAudit === false);
        document.querySelectorAll('[data-admin-only]').forEach(node => node.classList.toggle('hidden', !admin));
        root.dataset.auditRole = role;
        root.dataset.auditPrivacy = scope.privacyMode || 'masked';
    }

    function renderSummary(root, summary) {
        const values = {
            total: summary.total ?? 0,
            completed: summary.completed ?? 0,
            failed: summary.failed ?? 0,
            pending: summary.pending ?? 0,
            actors: summary.uniqueActors ?? summary.unique_actors ?? Object.keys(summary.actorCounts || summary.actor_counts || {}).length
        };
        Object.entries(values).forEach(([key, value]) => {
            const node = root.querySelector(`[data-audit-summary="${key}"]`);
            if (node) node.textContent = String(value);
        });
    }

    function renderTable(container, entries) {
        if (!container) return;
        if (!entries.length) {
            container.innerHTML = '';
            return;
        }
        container.innerHTML = `
            <div class="audit-table-wrap">
                <table class="audit-table">
                    <thead><tr>
                        <th>Time</th><th>Updated by</th><th>Source / action</th><th>Target</th>
                        <th>Change</th><th>Status</th><th>Verification</th><th></th>
                    </tr></thead>
                    <tbody>${entries.map((item, index) => row(item, index)).join('')}</tbody>
                </table>
            </div>`;
        container.querySelectorAll('[data-audit-expand]').forEach((button) => {
            button.addEventListener('click', () => {
                const detail = container.querySelector(`[data-audit-detail="${button.dataset.auditExpand}"]`);
                detail?.classList.toggle('hidden');
                button.setAttribute('aria-expanded', String(!detail?.classList.contains('hidden')));
            });
        });
    }

    function row(item, index) {
        const actorUsername = item.actorUsername || item.actor_username || item.actor || 'Unknown user';
        const actorDisplayName = item.actorDisplayName || item.actor_display_name || '';
        const actorEmail = item.actorEmail || item.actor_email || '';
        const actorRole = item.actorRole || item.actor_role || item.details?.actorRole || '';
        const before = displayValue(item.before);
        const after = displayValue(item.after);
        const status = item.status || 'Unknown';
        const channel = item.channel || 'manual-ui';
        const detail = {
            auditId: item.auditId || item.audit_id,
            correlationId: item.correlationId || item.correlation_id,
            reason: item.reason,
            channel,
            details: item.details || {}
        };
        return `
            <tr>
                <td><time>${escape(formatTime(item.timestampUtc || item.timestamp_utc || item.timestamp))}</time></td>
                <td><strong>${escape(actorUsername)}</strong>${actorDisplayName && actorDisplayName !== actorUsername ? `<small>${escape(actorDisplayName)}</small>` : ''}${actorEmail ? `<small>${escape(actorEmail)}</small>` : ''}<small>${escape([actorRole, channel.replaceAll('-', ' ')].filter(Boolean).join(' · '))}</small></td>
                <td><strong>${escape(item.source || 'Unknown')}</strong><small>${escape(item.action || 'Unknown')}</small></td>
                <td><span class="audit-target">${escape(item.target || '—')}</span>${item.field ? `<small>Field: ${escape(item.field)}</small>` : ''}</td>
                <td><div class="audit-change"><span>${escape(before)}</span><b>→</b><span>${escape(after)}</span></div></td>
                <td><span class="audit-status ${statusClass(status)}">${escape(status.replaceAll('_', ' '))}</span></td>
                <td>${escape(item.verification || '—')}</td>
                <td><button class="audit-expand-button" type="button" data-audit-expand="${index}" aria-expanded="false">Details</button></td>
            </tr>
            <tr class="audit-detail-row hidden" data-audit-detail="${index}"><td colspan="8"><pre>${escape(JSON.stringify(detail, null, 2))}</pre></td></tr>`;
    }

    function exportCsv(root) {
        const rows = [...root.querySelectorAll('.audit-table tbody tr:not(.audit-detail-row)')];
        if (!rows.length) return;
        const header = ['Time', 'Updated by', 'Source / action', 'Target', 'Change', 'Status', 'Verification'];
        const data = rows.map((row) => [...row.cells].slice(0, 7).map((cell) => cell.innerText.replace(/\n+/g, ' · ').trim()));
        const csv = [header, ...data].map((line) => line.map((value) => `"${String(value).replaceAll('"', '""')}"`).join(',')).join('\n');
        const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
        const link = document.createElement('a');
        link.href = url;
        link.download = `RUS_Audit_Trail_${root.dataset.auditPrivacy || 'masked'}_${new Date().toISOString().replaceAll(':', '-')}.csv`;
        link.click();
        URL.revokeObjectURL(url);
    }

    function init(root, options = {}) {
        if (!root || root.dataset.auditInitialized === 'true') return;
        root.dataset.auditInitialized = 'true';
        const privacy = root.querySelector('[data-audit-privacy]');
        if (privacy) {
            try { privacy.value = localStorage.getItem('rus.audit.masked') ?? 'true'; } catch { privacy.value = 'true'; }
            privacy.addEventListener('change', () => {
                try { localStorage.setItem('rus.audit.masked', privacy.value); } catch { }
                load(root, options);
            });
        }
        root.querySelector('[data-audit-refresh]')?.addEventListener('click', () => load(root, options));
        root.querySelector('[data-audit-export]')?.addEventListener('click', () => exportCsv(root));
        root.querySelectorAll('[data-audit-filter]').forEach((input) => {
            input.addEventListener(input.tagName === 'SELECT' ? 'change' : 'input', () => {
                clearTimeout(root.__auditDebounce);
                root.__auditDebounce = setTimeout(() => load(root, options), 250);
            });
        });
        if (options.autoLoad !== false) load(root, options);
    }

    window.RUSAuditTrail = { init, load };

    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('[data-audit-root]').forEach((root) => init(root, {
            limit: Number(root.dataset.auditLimit || 100),
            autoLoad: root.dataset.auditAutoload !== 'false'
        }));
    });
})();

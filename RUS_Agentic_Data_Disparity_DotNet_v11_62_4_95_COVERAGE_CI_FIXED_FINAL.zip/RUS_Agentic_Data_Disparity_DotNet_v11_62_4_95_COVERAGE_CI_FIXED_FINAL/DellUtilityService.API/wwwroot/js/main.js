'use strict';

// Navigation, legacy tabs and common loader behavior.
document.addEventListener('DOMContentLoaded', function () {
    const currentPage = document.body?.dataset?.page || window.location.pathname.split('/').pop()?.replace('.html', '') || 'dashboard';
    document.querySelectorAll('.nav-link').forEach((link) => link.classList.toggle('active', link.dataset.page === currentPage));

    const savedTab = window.RUSWorkspace?.getSection('legacyActiveTab');
    if (savedTab && document.getElementById(`${savedTab}-tab`)) switchTab(savedTab, document.querySelector(`[data-tab-name="${savedTab}"]`), false);
});

function switchTab(tabName, button = null, persist = true) {
    document.querySelectorAll('.tab-content').forEach((content) => {
        content.style.display = 'none';
        content.classList.remove('active');
    });
    document.querySelectorAll('.tab-btn').forEach((btn) => btn.classList.remove('active'));
    const panel = document.getElementById(`${tabName}-tab`);
    if (panel) {
        panel.style.display = 'block';
        panel.classList.add('active');
    }
    const activeButton = button || document.querySelector(`[data-tab-name="${tabName}"]`);
    activeButton?.classList.add('active');
    if (persist) window.RUSWorkspace?.setSection('legacyActiveTab', tabName);
}

function switchSearchTab(tabName, button = null) {
    switchTab(tabName, button, true);
}

function showLoader(text = 'Processing…') {
    const loader = document.getElementById('loader');
    const loaderText = document.querySelector('.loader-text');
    if (loader) {
        loader.classList.add('active');
        if (loaderText) loaderText.textContent = text;
    }
}

function hideLoader() {
    document.getElementById('loader')?.classList.remove('active');
}

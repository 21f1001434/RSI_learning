'use strict';
const FIXED_SOURCE_PARALLEL_WORKERS = 8;
const FIXED_DELL_AIA_PARALLEL_WORKERS = 2;
const FIXED_GROUPED_DELL_AIA = true;


const REPORT_PRIVACY_PREFERENCE_VERSION = '11.4.0';
const REPORT_PRIVACY_VERSION_KEY = 'rus.agentic.reportPrivacyVersion';
const REPORT_MASKED_KEY = 'rus.agentic.reportMasked';

function readInitialReportMaskedPreference() {
    const storedVersion = sessionStorage.getItem(REPORT_PRIVACY_VERSION_KEY);
    if (storedVersion !== REPORT_PRIVACY_PREFERENCE_VERSION) {
        // v11.3 stored `true` as the implicit default. Migrate once so stale
        // session state cannot keep the upgraded UI masked after deployment.
        sessionStorage.setItem(REPORT_PRIVACY_VERSION_KEY, REPORT_PRIVACY_PREFERENCE_VERSION);
        sessionStorage.setItem(REPORT_MASKED_KEY, 'false');
        window.RUSWorkspace?.setShared(REPORT_MASKED_KEY, 'false');
        return false;
    }
    const stored = window.RUSWorkspace?.getShared(REPORT_MASKED_KEY) ?? sessionStorage.getItem(REPORT_MASKED_KEY);
    return String(stored ?? 'false') === 'true';
}

const agenticState = {
    sessionId: window.RUSWorkspace?.getShared('rus.agentic.sessionId') ?? sessionStorage.getItem('rus.agentic.sessionId'),
    activeRunId: null,
    activeJobId: window.RUSWorkspace?.getShared('rus.agentic.jobId') ?? sessionStorage.getItem('rus.agentic.jobId'),
    activeBatchResultId: null,
    activeContext: 'none',
    chatContextMode: (window.RUSWorkspace?.getShared('rus.agentic.chatContext') ?? sessionStorage.getItem('rus.agentic.chatContext')) || 'individual',
    currentBatchSummary: null,
    batchCompletionAnnounced: false,
    pollTimer: null,
    pollIntervalMs: 5000,
    catalogOperations: [],
    currentReport: null,
    pendingChatFile: null,
    pendingChatFileEmails: [],
    pendingChatFileKind: null,
    intakeMode: 'auto',
    intakeBusy: false,
    approvalPopupChange: null,
    approvalPopupBusy: false,
    reportMasked: readInitialReportMaskedPreference(),
    currentRole: 'customer',
    reportHistory: []
};

const byId = (id) => document.getElementById(id);
const envelopeData = (payload) => payload?.data ?? payload ?? {};

function currentAgenticRole() { return String(agenticState.currentRole || 'customer').toLowerCase(); }
function isFocusedAgenticRole() { return ['business', 'customer', 'customer support'].includes(currentAgenticRole()); }
function isBusinessAgenticRole() { return currentAgenticRole() === 'business'; }


const EMAIL_PATTERN = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const PROFILE_ID_PATTERN = /\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b/i;
const CROWD_TWIST_ID_PATTERN = /\b(?:crowd\s*twist|crowdtwist|ct)\s*(?:id|identifier|member\s*id)?\s*[:=#-]?\s*(\d{1,20})\b/i;
const BARE_CROWD_TWIST_ID_PATTERN = /^\s*(\d{6,20})\s*$/;
const PREFIX_CROWD_TWIST_ID_PATTERN = /^\s*(\d{6,20})\b/;
const WRITE_INTENT_PATTERN = /\b(update|change|set|correct|replace|modify|write|fix|apply|execute|implement|make\s+(?:the\s+)?change|do\s+(?:the\s+)?changes?)\b/i;
const ANALYSIS_VERBS = /\b(analy[sz]e|analysis|check|compare|inspect|run|process|validate|review|find\s+disparit(?:y|ies))\b/i;
const FULL_ANALYSIS_TERMS = /\b(analy[sz]e|analysis|disparit(?:y|ies)|compare\s+(?:all\s+)?(?:three|3)\s+sources)\b/i;
const SOURCE_SYSTEM_TERMS = /\b(cps|rewards\s*db|rewardsdb|members?\s*db|crowd\s*twist|crowdtwist|ct)\b/i;
const SOURCE_READ_VERBS = /\b(run|fetch|get|show|retrieve|extract|pull|lookup|search|read|check|data)\b/i;
const QUESTION_PREFIX = /^\s*(what|why|how|which|who|when|where|show|give|tell|explain|summari[sz]e|list|is|are|did|does|can|could|would)\b/i;

function extractEmails(value) {
    const matches = String(value || '').match(EMAIL_PATTERN) || [];
    const unique = [];
    const seen = new Set();
    for (const raw of matches) {
        const email = raw.trim();
        const key = email.toLowerCase();
        if (!seen.has(key)) {
            seen.add(key);
            unique.push(email);
        }
    }
    return unique;
}

function countEmailOccurrences(value) {
    return (String(value || '').match(EMAIL_PATTERN) || []).length;
}

function extractPrimaryIdentifier(value) {
    const text = String(value || '');
    const profile = text.match(PROFILE_ID_PATTERN);
    if (profile) return { searchType: 'profileid', value: profile[0].toUpperCase(), label: 'Profile ID' };
    const crowdTwist = text.match(CROWD_TWIST_ID_PATTERN);
    if (crowdTwist) return { searchType: 'crowdtwistid', value: crowdTwist[1], label: 'CrowdTwist ID' };
    const bareCrowdTwist = text.match(BARE_CROWD_TWIST_ID_PATTERN);
    if (bareCrowdTwist) return { searchType: 'crowdtwistid', value: bareCrowdTwist[1], label: 'CrowdTwist ID' };
    const prefixCrowdTwist = text.match(PREFIX_CROWD_TWIST_ID_PATTERN);
    if (prefixCrowdTwist && (ANALYSIS_VERBS.test(text.slice(prefixCrowdTwist[0].length)) || WRITE_INTENT_PATTERN.test(text.slice(prefixCrowdTwist[0].length)))) {
        return { searchType: 'crowdtwistid', value: prefixCrowdTwist[1], label: 'CrowdTwist ID' };
    }
    const emails = extractEmails(text);
    if (emails.length === 1) return { searchType: 'email', value: emails[0], label: 'Email' };
    return null;
}

function residualTextWithoutIdentifiers(value) {
    const text = String(value || '');
    const identifier = extractPrimaryIdentifier(text);
    let residual = text
        .replace(EMAIL_PATTERN, ' ')
        .replace(PROFILE_ID_PATTERN, ' ')
        .replace(CROWD_TWIST_ID_PATTERN, ' ');
    if (identifier?.searchType === 'crowdtwistid') {
        const escaped = String(identifier.value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        residual = residual.replace(new RegExp(`^\\s*${escaped}\\b`), ' ');
    }
    return residual.replace(/[\s,;|:\-–—()[\]{}]+/g, ' ').trim();
}

function classifySmartInput(text, file = agenticState.pendingChatFile, forcedMode = agenticState.intakeMode) {
    const fileKind = file ? agenticState.pendingChatFileKind : null;
    const emails = file && fileKind !== 'updates' ? agenticState.pendingChatFileEmails : (file ? [] : extractEmails(text));
    const occurrenceCount = file ? emails.length : countEmailOccurrences(text);
    const duplicates = Math.max(0, occurrenceCount - emails.length);
    const identifier = file ? null : extractPrimaryIdentifier(text);
    const residual = residualTextWithoutIdentifiers(text);
    const explicitQuestion = QUESTION_PREFIX.test(residual) || /\?\s*$/.test(String(text || '').trim());
    const explicitAnalysis = FULL_ANALYSIS_TERMS.test(residual);
    const sourceRead = SOURCE_SYSTEM_TERMS.test(String(text || ''))
        && SOURCE_READ_VERBS.test(String(text || ''))
        && !explicitAnalysis;
    const writeIntent = Boolean(identifier) && WRITE_INTENT_PATTERN.test(String(text || ''));

    let mode = 'question';
    if (file && fileKind === 'updates') {
        mode = 'spreadsheet_update';
    } else if (writeIntent) {
        // Keep the complete natural-language command intact. The backend first
        // analyzes the supplied Email/Profile ID/CrowdTwist ID, then executes
        // the requested governed change from the fresh report.
        mode = 'command';
    } else if (forcedMode === 'batch') {
        mode = 'batch';
    } else if (forcedMode === 'individual') {
        mode = 'individual';
    } else if (forcedMode === 'question') {
        mode = 'question';
    } else if (file || occurrenceCount > 1 || emails.length > 1) {
        mode = 'batch';
    } else if (sourceRead) {
        // Keep source-specific reads in chat so the deterministic router can
        // resolve Email, Profile ID, CrowdTwist ID, or a remembered "ID above".
        mode = 'question';
    } else if (identifier) {
        mode = 'individual';
    }

    return {
        mode,
        emails,
        identifier,
        occurrenceCount,
        duplicates,
        residual,
        explicitQuestion,
        explicitAnalysis,
        sourceRead,
        writeIntent,
        hasFile: Boolean(file),
        fileName: file?.name || null,
        fileKind
    };
}

function intakeModeLabel(mode) {
    if (mode === 'individual') return 'Single analysis';
    if (mode === 'batch') return 'Bulk analysis';
    if (mode === 'spreadsheet_update') return 'Excel updates';
    if (mode === 'command') return 'Analyze + update';
    return 'Question';
}

function setIntakeBusy(active) {
    agenticState.intakeBusy = active;
    const button = byId('sendChatButton');
    const attach = byId('attachChatFileButton');
    const mode = byId('intakeModeSelect');
    if (button) button.disabled = active;
    if (attach) attach.disabled = active;
    if (mode) mode.disabled = active;
}

function updateSmartIntakePreview() {
    const text = byId('chatInput')?.value || '';
    const detection = classifySmartInput(text);
    const badge = byId('intakeDetectionBadge');
    const status = byId('intakeDetectionText');
    const preview = byId('intakeEmailPreview');
    const button = byId('sendChatButton');

    if (badge) {
        badge.className = `intake-detection-badge mode-${detection.mode}`;
        badge.textContent = intakeModeLabel(detection.mode);
    }

    if (status) {
        if (detection.mode === 'spreadsheet_update') {
            status.textContent = `Attached Excel update workbook: ${detection.fileName}. Ask "apply these changes" to enter your profile's governed approval flow, or "validate first" to create previews without writing.`;
        } else if (detection.mode === 'batch') {
            const source = detection.hasFile ? `Attached file: ${detection.fileName}` : 'Pasted email list';
            status.textContent = detection.emails.length
                ? `${source}. ${detection.emails.length} unique email(s) detected${detection.duplicates ? `; ${detection.duplicates} duplicate occurrence(s) will be ignored` : ''}.`
                : `${source}. No valid email address was detected yet.`;
        } else if (detection.mode === 'command') {
            status.textContent = detection.identifier
                ? `${detection.identifier.label} detected with an update request. The agent will run a fresh linked analysis for ${detection.identifier.value}, resolve the requested attribute/value, and then apply the governed change if authorized.`
                : 'Update commands require one resolvable email, Profile ID, or CrowdTwist ID.';
        } else if (detection.mode === 'individual') {
            status.textContent = detection.identifier
                ? `${detection.identifier.label} detected. A linked CPS, Rewards DB and CrowdTwist analysis will run for ${detection.identifier.value}.`
                : 'Single mode requires one email, Profile ID, or CrowdTwist ID.';
        } else {
            status.textContent = hasIndividualChatContext() || hasBatchChatContext()
                ? `Question mode will use the selected ${agenticState.chatContextMode === 'batch' ? 'bulk' : 'single'} result context.`
                : 'Question mode is available, but analysis-specific answers require a completed single or bulk run.';
        }
    }

    if (preview) {
        if ((detection.mode === 'individual' || detection.mode === 'command') && detection.identifier) {
            preview.innerHTML = `<span class="email-preview-chip">${escapeHtml(detection.identifier.label)} · ${escapeHtml(detection.identifier.value)}</span>`;
        } else {
            const visible = detection.emails.slice(0, 4);
            preview.innerHTML = visible.map((email) => `<span class="email-preview-chip">${escapeHtml(email)}</span>`).join('')
                + (detection.emails.length > visible.length ? `<span class="email-preview-more">+${detection.emails.length - visible.length} more</span>` : '');
        }
    }

    if (button) {
        button.textContent = detection.mode === 'spreadsheet_update'
            ? 'Process Excel updates'
            : detection.mode === 'batch'
                ? `Start bulk analysis${detection.emails.length ? ` (${detection.emails.length})` : ''}`
                : detection.mode === 'command'
                    ? 'Analyze & apply change'
                    : detection.mode === 'individual'
                        ? 'Analyze single user'
                        : 'Send question';
    }

    return detection;
}

async function readEmailFile(file) {
    if (!file) return [];
    const extension = String(file.name || '').toLowerCase().split('.').pop();
    if (!['txt', 'csv'].includes(extension)) throw new Error('Only TXT and CSV email lists are supported.');
    if (file.size > 5_000_000) throw new Error('The selected file exceeds the 5 MB limit.');
    const text = await file.text();
    return extractEmails(text);
}

async function attachSmartInputFile(file) {
    if (!file) return;
    try {
        const extension = String(file.name || '').toLowerCase().split('.').pop();
        if (file.size > 5_000_000) throw new Error('The selected file exceeds the 5 MB limit.');
        let emails = [];
        let kind = 'emails';
        if (['xlsx', 'xlsm'].includes(extension)) {
            kind = 'updates';
        } else {
            emails = await readEmailFile(file);
        }
        agenticState.pendingChatFile = file;
        agenticState.pendingChatFileEmails = emails;
        agenticState.pendingChatFileKind = kind;
        const panel = byId('selectedChatFile');
        panel?.classList.remove('hidden');
        if (byId('selectedChatFileName')) byId('selectedChatFileName').textContent = file.name;
        if (byId('selectedChatFileMeta')) {
            byId('selectedChatFileMeta').textContent = kind === 'updates'
                ? 'Excel source-update workbook · CrowdTwistID/ProfileId/Email + PropertyName + PropertyValue'
                : (emails.length ? `${emails.length} unique email(s) detected · bulk analysis ready` : 'No valid emails detected');
        }
        updateSmartIntakePreview();
    } catch (error) {
        clearSmartInputFile();
        showToast(error.message, true);
    }
}

function clearSmartInputFile() {
    agenticState.pendingChatFile = null;
    agenticState.pendingChatFileEmails = [];
    agenticState.pendingChatFileKind = null;
    const input = byId('chatFileInput');
    if (input) input.value = '';
    byId('selectedChatFile')?.classList.add('hidden');
    updateSmartIntakePreview();
}

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function formatInlineMarkdown(value) {
    let text = escapeHtml(value ?? '');
    text = text.replace(/`([^`]+)`/g, '<code class="chat-inline-code">$1</code>');
    text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/(^|\s)(https?:\/\/[^\s<]+)/g, (match, prefix, url) => {
        const clean = url.replace(/[.,;:!?)]$/, '');
        const suffix = url.slice(clean.length);
        return `${prefix}<a class="chat-link" href="${clean}" target="_blank" rel="noopener">${clean}</a>${suffix}`;
    });
    return text;
}

function splitMarkdownTableRow(line) {
    let text = String(line ?? '').trim();
    if (text.startsWith('|')) text = text.slice(1);
    if (text.endsWith('|')) text = text.slice(0, -1);
    return text.split('|').map((cell) => cell.trim());
}

function isMarkdownTableSeparator(line) {
    const cells = splitMarkdownTableRow(line);
    return cells.length >= 2 && cells.every((cell) => /^:?-{3,}:?$/.test(cell));
}

function renderMarkdownTable(lines, startIndex) {
    if (startIndex + 1 >= lines.length) return null;
    const headerLine = String(lines[startIndex] ?? '').trim();
    const separatorLine = String(lines[startIndex + 1] ?? '').trim();
    if (!headerLine.includes('|') || !isMarkdownTableSeparator(separatorLine)) return null;

    const headers = splitMarkdownTableRow(headerLine);
    if (headers.length < 2) return null;
    const rows = [];
    let index = startIndex + 2;
    while (index < lines.length) {
        const line = String(lines[index] ?? '').trim();
        if (!line || !line.includes('|')) break;
        const cells = splitMarkdownTableRow(line);
        if (cells.length < 2) break;
        while (cells.length < headers.length) cells.push('');
        rows.push(cells.slice(0, headers.length));
        index += 1;
    }

    const head = headers.map((cell) => `<th scope="col">${formatInlineMarkdown(cell)}</th>`).join('');
    const body = rows.length
        ? rows.map((cells) => `<tr>${cells.map((cell, cellIndex) => `<td data-label="${escapeHtml(headers[cellIndex])}">${formatInlineMarkdown(cell)}</td>`).join('')}</tr>`).join('')
        : `<tr><td colspan="${headers.length}">No rows.</td></tr>`;
    return {
        html: `<div class="chat-table-scroll" role="region" aria-label="Chat result table" tabindex="0"><table class="chat-markdown-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`,
        nextIndex: index,
    };
}

function formatAssistantText(value) {
    const lines = String(value ?? '').replace(/\r\n?/g, '\n').split('\n');
    const blocks = [];
    let listType = null;
    let listItems = [];
    let paragraph = [];

    const flushList = () => {
        if (!listItems.length) return;
        const tag = listType === 'ol' ? 'ol' : 'ul';
        blocks.push(`<${tag} class="chat-list">${listItems.map((item) => `<li>${formatInlineMarkdown(item)}</li>`).join('')}</${tag}>`);
        listItems = [];
        listType = null;
    };
    const flushParagraph = () => {
        if (!paragraph.length) return;
        blocks.push(`<p class="chat-paragraph">${formatInlineMarkdown(paragraph.join(' '))}</p>`);
        paragraph = [];
    };

    for (let index = 0; index < lines.length;) {
        const rawLine = lines[index];
        const line = rawLine.trim();
        const table = renderMarkdownTable(lines, index);
        if (table) {
            flushParagraph();
            flushList();
            blocks.push(table.html);
            index = table.nextIndex;
            continue;
        }
        if (!line) {
            flushParagraph();
            flushList();
            index += 1;
            continue;
        }
        const heading = line.match(/^(#{1,4})\s+(.+)$/);
        if (heading) {
            flushParagraph();
            flushList();
            const level = Math.min(4, heading[1].length + 2);
            blocks.push(`<h${level} class="chat-heading chat-heading-${heading[1].length}">${formatInlineMarkdown(heading[2])}</h${level}>`);
            index += 1;
            continue;
        }
        const bullet = line.match(/^[-•*]\s+(.+)$/);
        if (bullet) {
            flushParagraph();
            if (listType && listType !== 'ul') flushList();
            listType = 'ul';
            listItems.push(bullet[1]);
            index += 1;
            continue;
        }
        const numbered = line.match(/^\d+[.)]\s+(.+)$/);
        if (numbered) {
            flushParagraph();
            if (listType && listType !== 'ol') flushList();
            listType = 'ol';
            listItems.push(numbered[1]);
            index += 1;
            continue;
        }
        flushList();
        paragraph.push(line);
        index += 1;
    }
    flushParagraph();
    flushList();
    return blocks.join('');
}

function formatDuration(milliseconds) {
    if (milliseconds === null || milliseconds === undefined || Number.isNaN(Number(milliseconds))) return '—';
    const ms = Number(milliseconds);
    if (ms < 1000) return `${Math.round(ms)} ms`;
    const seconds = ms / 1000;
    if (seconds < 60) return `${seconds.toFixed(seconds < 10 ? 2 : 1)} s`;
    const minutes = Math.floor(seconds / 60);
    const remaining = Math.round(seconds % 60);
    return `${minutes}m ${remaining}s`;
}

function displayValue(value) {
    if (value === null || value === undefined || value === '') return '—';
    if (typeof value === 'boolean') return value ? 'Yes' : 'No';
    if (Array.isArray(value)) return value.length ? value.join(', ') : '—';
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
}

function setLoader(active, text = 'Processing…') {
    const loader = byId('loader');
    if (!loader) return;
    byId('loaderText').textContent = text;
    loader.classList.toggle('active', active);
}

function showToast(message, error = false) {
    const toast = document.createElement('div');
    toast.className = `agentic-toast ${error ? 'error' : 'success'}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4500);
}

function setServiceStatus(status, label) {
    const node = byId('serviceStatus');
    node.className = `status-pill status-${status}`;
    node.textContent = label;
}

function reportPrivacyLabel(masked = agenticState.reportMasked) {
    return masked ? 'Masked · safe to share' : 'Unmasked · contains source values';
}

function syncUniversalReportDownloadButtons() {
    const single = byId('currentReportDownloadButton');
    if (single) {
        const runId = agenticState.currentReport?.run_id || agenticState.activeRunId;
        if (runId && agenticState.activeContext === 'individual') {
            single.href = agenticAiApi.htmlReportUrl(runId, agenticState.reportMasked);
            single.classList.remove('hidden');
            single.title = `Download ${agenticState.reportMasked ? 'masked' : 'unmasked'} role-safe report`;
        } else {
            single.classList.add('hidden');
            single.removeAttribute('href');
        }
    }

    const bulk = byId('inlineBatchDownloadButton');
    if (bulk) {
        if (agenticState.activeJobId && agenticState.activeContext === 'batch' && agenticState.currentBatchSummary) {
            bulk.href = agenticAiApi.batchDownloadUrl(agenticState.activeJobId, agenticState.reportMasked);
            bulk.classList.remove('hidden');
            bulk.title = `Download ${agenticState.reportMasked ? 'masked' : 'unmasked'} role-safe bulk report ZIP`;
        } else {
            bulk.classList.add('hidden');
            bulk.removeAttribute('href');
        }
    }
}

function refreshReportDownloadLinks() {
    const select = byId('reportPrivacySelect');
    if (select) select.value = agenticState.reportMasked ? 'masked' : 'unmasked';
    const hint = byId('reportPrivacyHint');
    if (hint) {
        hint.textContent = agenticState.reportMasked
            ? 'On-screen values and downloaded reports are tokenized.'
            : 'On-screen results and downloads contain original source values. Use only in an approved secure location.';
        hint.classList.toggle('privacy-warning', !agenticState.reportMasked);
    }
    if (agenticState.currentReport?.run_id) renderReportActions(agenticState.currentReport);
    const batchLink = byId('batchDownloadButton');
    if (batchLink && agenticState.activeJobId && !batchLink.classList.contains('hidden')) {
        batchLink.href = agenticAiApi.batchDownloadUrl(agenticState.activeJobId, agenticState.reportMasked);
        batchLink.textContent = `Download ${agenticState.reportMasked ? 'masked' : 'unmasked'} report ZIP`;
    }
    const note = byId('batchReportPrivacyNote');
    if (note) {
        note.textContent = agenticState.reportMasked
            ? 'Masked package selected. Email, Profile ID, CrowdTwist ID, names, phone and postal values are tokenized.'
            : 'Unmasked package selected. The ZIP contains original source values and must remain in an approved secure location.';
        note.classList.toggle('privacy-warning', !agenticState.reportMasked);
    }
    syncUniversalReportDownloadButtons();
}

async function setReportPrivacy(masked, { persist = true, announce = false, reloadView = true } = {}) {
    const previousMasked = agenticState.reportMasked;
    agenticState.reportMasked = Boolean(masked);

    const persistSelection = () => {
        if (!persist) return;
        sessionStorage.setItem(REPORT_PRIVACY_VERSION_KEY, REPORT_PRIVACY_PREFERENCE_VERSION);
        sessionStorage.setItem(REPORT_MASKED_KEY, String(agenticState.reportMasked));
        window.RUSWorkspace?.setShared(REPORT_MASKED_KEY, String(agenticState.reportMasked));
    };

    persistSelection();
    refreshReportDownloadLinks();

    if (reloadView && agenticState.activeRunId) {
        try {
            await loadActiveAnalysis(agenticState.activeRunId, false, true);
        } catch (error) {
            agenticState.reportMasked = previousMasked;
            persistSelection();
            refreshReportDownloadLinks();
            const legacyRun = /UNMASKED_REPORT_UNAVAILABLE|legacy run|rerun the analysis/i.test(error.message || '');
            showToast(
                legacyRun
                    ? 'This run was created with irreversible masked values. Run the analysis again after the v11.4 upgrade.'
                    : (error.message || 'Unable to refresh report privacy view.'),
                true
            );
            return false;
        }
    }

    if (announce) showToast(`${reportPrivacyLabel()} selected.`);
    return true;
}

function renderReportActions(report) {
    const container = byId('reportActions');
    if (!container) return;
    if (!report?.run_id) {
        container.innerHTML = '';
        return;
    }
    const masked = agenticState.reportMasked;
    const privacy = masked ? 'Masked' : 'Unmasked';
    container.innerHTML = `
        <span class="report-privacy-badge ${masked ? 'masked' : 'unmasked'}">${escapeHtml(privacy)}</span>
        <a class="btn btn-secondary btn-sm" target="_blank" rel="noopener" href="${agenticAiApi.htmlReportUrl(report.run_id, masked)}">Open ${escapeHtml(privacy)} HTML</a>
        <a class="btn btn-secondary btn-sm" download href="${agenticAiApi.jsonReportUrl(report.run_id, masked)}">Download ${escapeHtml(privacy)} JSON</a>`;
}

function sourceChangeValue(value) {
    if (value === null || value === undefined || value === '') return '—';
    if (typeof value === 'object') {
        try { return JSON.stringify(value); } catch { return String(value); }
    }
    return String(value);
}

function renderSourceChangeControls(change) {
    if (!change || !change.change_id) return '';
    const id = escapeHtml(change.change_id);
    const status = String(change.status || '');
    const mode = escapeHtml(change.write_mode || 'dry_run');
    const targets = Array.isArray(change.targets) ? change.targets : [];
    const preview = targets.slice(0, 3).map((target) => `<div><strong>${escapeHtml(target.email || 'target')}</strong><span>${escapeHtml(sourceChangeValue(target.before))} → ${escapeHtml(sourceChangeValue(target.after))}</span></div>`).join('');
    const summary = `<div class="source-change-card"><div class="source-change-card-head"><strong>${id}</strong><span class="source-change-status">${escapeHtml(status)}</span></div><div class="source-change-card-meta">${escapeHtml(change.source_label || change.source || '')} · ${escapeHtml(change.field || '')} · ${change.target_count || 0} target(s) · mode ${mode}</div>${preview ? `<div class="source-change-plan-preview">${preview}</div>` : ''}`;
    if (status === 'AWAITING_CONFIRMATION_1') {
        const businessSingleApproval = Number(change.required_confirmation_count || 2) === 1 || change.approval_policy === 'business_chat';
        const approvalCopy = businessSingleApproval
            ? 'Review the exact values, then approve in chat. Business executes after this single chat approval with pre-write recheck and read-after-write verification.'
            : 'Review the exact values, then record chat approval 1. Customer Support, Technical and Admin must complete the final-review popup before execution.';
        return `${summary}<div class="source-change-warning">${approvalCopy}</div><div class="source-change-actions"><button type="button" class="btn btn-primary btn-sm source-change-chat-action" data-message="approve ${id}">Approve in chat</button><button type="button" class="btn btn-secondary btn-sm source-change-chat-action" data-message="cancel">Cancel</button></div></div>`;
    }
    if (status === 'AWAITING_CONFIRMATION_2') {
        return `${summary}<div class="source-change-warning">Chat approval is recorded. A live write cannot be triggered by another chat command. Review the exact plan in the final popup and approve it there.</div><div class="source-change-actions"><button type="button" class="btn btn-primary btn-sm source-change-popup-action" data-change-id="${id}">Review final approval (2 of 2)</button><button type="button" class="btn btn-secondary btn-sm source-change-chat-action" data-message="cancel">Cancel</button></div></div>`;
    }
    return `${summary}</div>`;
}

function resetSourceApprovalDialog() {
    agenticState.approvalPopupChange = null;
    agenticState.approvalPopupBusy = false;
    const review = byId('sourceApprovalReviewAck');
    const audit = byId('sourceApprovalAuditAck');
    const phrase = byId('sourceApprovalPhrase');
    const error = byId('sourceApprovalError');
    if (review) review.checked = false;
    if (audit) audit.checked = false;
    if (phrase) phrase.value = '';
    if (error) { error.textContent = ''; error.classList.add('hidden'); }
    updateSourceApprovalButton();
}

function updateSourceApprovalButton() {
    const button = byId('confirmSourceApprovalButton');
    if (!button) return;
    const ready = Boolean(
        agenticState.approvalPopupChange
        && byId('sourceApprovalReviewAck')?.checked
        && byId('sourceApprovalAuditAck')?.checked
        && String(byId('sourceApprovalPhrase')?.value || '').trim().toUpperCase() === 'APPROVE'
        && !agenticState.approvalPopupBusy
    );
    button.disabled = !ready;
    button.textContent = agenticState.approvalPopupBusy ? 'Executing…' : 'Approve and execute';
}

function renderSourceApprovalDialog(change) {
    const summary = byId('sourceApprovalSummary');
    const targets = byId('sourceApprovalTargets');
    if (summary) {
        summary.innerHTML = [
            ['Change ID', change.change_id],
            ['Source', change.source_label || change.source],
            ['Field', change.field],
            ['Write mode', change.write_mode],
            ['New value', sourceChangeValue(change.new_value)],
            ['Targets', change.target_count || (change.targets || []).length],
            ['Requested by', change.actor || 'Unknown user'],
            ['Chat approved by', change.first_confirmed_by || 'Pending'],
            ['Chat approved at', change.first_confirmed_at || '—'],
            ['Plan fingerprint', String(change.plan_digest || '').slice(0, 12) || '—'],
            ['Reason', change.reason || 'Agentic AI request']
        ].map(([label, value]) => `<div><small>${escapeHtml(label)}</small><strong>${escapeHtml(sourceChangeValue(value))}</strong></div>`).join('');
    }
    if (targets) {
        const rows = (change.targets || []).map((target) => `<tr><td>${escapeHtml(target.email || 'target')}</td><td>${escapeHtml(sourceChangeValue(target.identity?.profile_id || target.identity?.crowd_twist_id || '—'))}</td><td class="source-approval-before">${escapeHtml(sourceChangeValue(target.before))}</td><td class="source-approval-after">${escapeHtml(sourceChangeValue(target.after))}</td></tr>`).join('');
        targets.innerHTML = `<table><thead><tr><th>Target</th><th>Resolved ID</th><th>Current value</th><th>Proposed value</th></tr></thead><tbody>${rows || '<tr><td colspan="4">No eligible targets were returned.</td></tr>'}</tbody></table>`;
    }
}

async function openSourceApprovalPopup(changeId) {
    if (!changeId || !agenticState.sessionId) return;
    const dialog = byId('sourceApprovalDialog');
    if (!dialog) return;
    setLoader(true, 'Loading final source-change preview…');
    try {
        const response = await agenticAiApi.getSourceChange(changeId, agenticState.sessionId);
        const change = envelopeData(response).change || envelopeData(response);
        if (String(change.status || '') !== 'AWAITING_CONFIRMATION_2') {
            throw new Error(`Final approval is not available while the change is ${change.status || 'unknown'}.`);
        }
        const openedResponse = await agenticAiApi.markSourceChangePopupOpened(change.change_id, agenticState.sessionId);
        const openedChange = envelopeData(openedResponse).change || envelopeData(openedResponse) || change;
        resetSourceApprovalDialog();
        agenticState.approvalPopupChange = openedChange;
        renderSourceApprovalDialog(openedChange);
        updateSourceApprovalButton();
        dialog.showModal();
        byId('sourceApprovalPhrase')?.focus();
        refreshAuditViews();
    } catch (error) {
        showToast(error.message || 'Unable to open final approval.', true);
    } finally {
        setLoader(false);
    }
}

function closeSourceApprovalPopup() {
    const dialog = byId('sourceApprovalDialog');
    if (dialog?.open) dialog.close();
    resetSourceApprovalDialog();
}

async function confirmSourceApprovalPopup() {
    const change = agenticState.approvalPopupChange;
    if (!change || agenticState.approvalPopupBusy) return;
    const errorBox = byId('sourceApprovalError');
    agenticState.approvalPopupBusy = true;
    updateSourceApprovalButton();
    if (errorBox) { errorBox.textContent = ''; errorBox.classList.add('hidden'); }
    try {
        const response = await agenticAiApi.confirmSourceChangeSecond(change.change_id, {
            session_id: agenticState.sessionId,
            confirmation_text: 'APPROVE',
            approval_channel: 'popup',
            popup_acknowledged: Boolean(byId('sourceApprovalReviewAck')?.checked),
            audit_acknowledged: Boolean(byId('sourceApprovalAuditAck')?.checked),
            plan_digest: change.plan_digest,
            popup_token: change.popup_approval_token
        });
        const completed = envelopeData(response).change || envelopeData(response);
        closeSourceApprovalPopup();
        addChatMessage('assistant', sourceChangeExecutionMessage(completed), {
            intent: 'source_confirm_2',
            structuredData: { change: completed, next_change: completed.next_change || null }
        });
        const postWrite = completed.post_write_analysis || {};
        if (postWrite.run_id) {
            const loaded = await loadActiveAnalysis(postWrite.run_id, false, false);
            if (loaded) {
                agenticState.activeContext = 'individual';
                setChatContextMode('individual', { persist: true, announce: false });
            }
        }
        RUSNotifications?.add({
            title: 'Agentic source change completed',
            message: `${completed.change_id || ''} · ${completed.source_label || completed.source || ''} · ${completed.status || ''}`,
            type: ['COMPLETED', 'DRY_RUN_COMPLETED'].includes(String(completed.status || '')) ? 'success' : 'warning',
            category: 'source-change',
            link: 'ai-analysis.html'
        });
        refreshAuditViews();
        showToast(`Source change ${completed.status || 'completed'}.`);
    } catch (error) {
        if (errorBox) {
            errorBox.textContent = error.message || 'Final approval failed.';
            errorBox.classList.remove('hidden');
        }
    } finally {
        agenticState.approvalPopupBusy = false;
        updateSourceApprovalButton();
    }
}

function sourceChangeExecutionMessage(change) {
    const results = Array.isArray(change.results) ? change.results : [];
    const successful = results.filter((item) => item.success).length;
    const requiredApprovals = Number(change.required_confirmation_count || 2);
    const approvalLabel = requiredApprovals === 1 || change.approval_policy === 'business_chat'
        ? 'Business chat approval'
        : 'chat approval + final-review popup';
    const lines = [
        `## Agentic source update — ${change.status || 'completed'}`,
        `- **Change ID:** \`${change.change_id || ''}\``,
        `- **Source:** ${change.source_label || change.source || ''}`,
        `- **Execution authorization:** ${approvalLabel}`,
        `- **Write mode:** ${change.write_mode || ''}`,
        `- **Verified targets:** ${successful}/${change.target_count || results.length}`
    ];
    if (change.status === 'DRY_RUN_COMPLETED') lines.push('', 'The execution request and precondition checks passed. No source data was modified because dry-run mode is enabled.');
    else if (change.status === 'ABORTED_PRECONDITION_CHANGED') lines.push('', 'Execution was aborted because a source value changed after the original preview.');
    else lines.push('', 'Read-after-write verification was recorded in the audit trail for every attempted target.');
    const postWrite = change.post_write_analysis || {};
    if (String(postWrite.status || '').toUpperCase() === 'COMPLETED') {
        lines.push('', '### Post-write cross-source verification',
            `Fresh run \`${postWrite.run_id || 'unknown'}\` is now active. Remaining mismatches: ${postWrite.mismatch_count || 0}; missing records: ${postWrite.missing_record_count || 0}.`);
    } else if (String(postWrite.status || '').toUpperCase() === 'FAILED') {
        lines.push('', 'The verified source write succeeded, but automatic cross-source reanalysis could not complete. Run Analyze again to refresh the comparison.');
    }
    if (change.next_change) {
        lines.push('', `The next analyzed correction (${change.next_change.change_set_index || '?'} of ${change.next_change.change_set_total || '?'}) is ready for its own approval.`);
    }
    return lines.join('\n');
}

function renderSourceQueryCard(data) {
    if (!data || !data.source_results) return '';
    const summaries = Object.values(data.source_results || {});
    const summaryHtml = summaries.map((item) => `
        <div class="chat-source-stat">
            <span>${escapeHtml(item.source_label || item.source)}</span>
            <strong>${escapeHtml(item.found_count || 0)}</strong>
            <small>found · ${escapeHtml(item.no_value_found_count || 0)} no value · ${escapeHtml(item.failed_count || 0)} failed</small>
        </div>`).join('');
    const memberHtml = (data.members || []).slice(0, 20).map((member) => {
        const identity = member.resolved_identity || {};
        const input = member.identifier || {};
        const memberLabel = identity.email || member.email || `${input.label || 'Identifier'}: ${input.value || 'unknown'}`;
        const resolved = [
            identity.email ? `Email ${identity.email}` : null,
            identity.profile_id ? `Profile ID ${identity.profile_id}` : null,
            identity.crowd_twist_id !== null && identity.crowd_twist_id !== undefined && String(identity.crowd_twist_id) !== ''
                ? `CrowdTwist ID ${identity.crowd_twist_id}` : null
        ].filter(Boolean);
        const rows = Object.entries(member.results || {}).map(([source, item]) => {
            const label = ({ cps: 'CPS', rewards_db: 'Rewards DB', crowd_twist: 'CrowdTwist' }[source] || source);
            const state = item.data_found ? 'Data found' : item.connected ? 'No value found' : 'Unavailable';
            const fields = Object.entries(item.canonical || {})
                .filter(([, value]) => value !== null && value !== undefined && String(value) !== '')
                .slice(0, 12)
                .map(([key, value]) => `<div><span>${escapeHtml(key.replaceAll('_', ' '))}</span><strong>${escapeHtml(value)}</strong></div>`)
                .join('');
            const resolution = item.identifier_resolution || {};
            const attempts = resolution.attempts || item.record?.status?.diagnostics?.identifier_lookup_sequence || [];
            const order = resolution.lookup_order || item.record?.status?.diagnostics?.lookup_order || [];
            let lookup = '';
            if (source === 'rewards_db') {
                const displayedOrder = Array.isArray(order) && order.length
                    ? order.join(' → ')
                    : input.search_type === 'crowdtwistid' ? 'CrowdTwistID → ProfileId' : 'ProfileId → CrowdTwistID';
                lookup = `<p class="result-lookup-note"><strong>Rewards DB:</strong> ${escapeHtml(displayedOrder)}</p>`;
            } else if (source === 'crowd_twist') {
                const attemptText = attempts.length
                    ? attempts.map((attempt) => `${attempt.key || attempt.search_type || 'identifier'} ${attempt.data_found ? '✓' : attempt.connected ? 'no record' : 'unavailable'}`).join(' → ')
                    : input.search_type === 'crowdtwistid' ? 'CrowdTwistID direct' : input.search_type === 'profileid' ? 'ProfileId direct → linked fallback' : 'Email → ProfileId → CrowdTwistID';
                lookup = `<p class="result-lookup-note"><strong>CrowdTwist:</strong> ${escapeHtml(attemptText)}</p>`;
            } else if (source === 'cps') {
                lookup = `<p class="result-lookup-note"><strong>CPS:</strong> ${escapeHtml(item.retrieval_method || input.label || 'resolved identifier')}</p>`;
            }
            return `<li class="chat-source-row"><div class="chat-source-line"><span>${escapeHtml(label)}</span><strong class="${item.data_found ? 'source-result-ok' : item.connected ? 'source-result-empty' : 'source-result-error'}">${escapeHtml(state)}</strong></div>${lookup}${fields ? `<div class="source-field-grid">${fields}</div>` : ''}</li>`;
        }).join('');
        return `<details class="chat-source-member" open><summary>${escapeHtml(memberLabel)}</summary>${resolved.length ? `<p class="dependency-note"><strong>Resolved identity:</strong> ${resolved.map(escapeHtml).join(' · ')}</p>` : ''}<ul>${rows}</ul></details>`;
    }).join('');
    const inputTypes = new Set((data.members || []).map((member) => member.identifier?.search_type).filter(Boolean));
    const rewardsNote = inputTypes.has('crowdtwistid')
        ? 'Supplied CrowdTwist ID first → Profile ID extracted from CrowdTwist as fallback.'
        : 'Profile ID first → linked CrowdTwist ID fallback. Rewards DB is not queried by email alone.';
    const crowdTwistNote = inputTypes.has('crowdtwistid')
        ? 'Supplied CrowdTwist ID is fetched directly; its Profile ID/email continue the linked lookup into Rewards DB and CPS.'
        : inputTypes.has('profileid')
            ? 'Supplied Profile ID is used directly, followed by linked email/CrowdTwist ID only when needed.'
            : 'Email first → CPS Profile ID → Rewards DB CrowdTwist ID.';
    return `<section class="chat-source-result-card">
        <div class="chat-source-result-head"><span class="eyebrow">Read-only source result</span><strong>${escapeHtml(data.requested_member_count || 0)} member(s)</strong></div>
        <div class="chat-source-stats">${summaryHtml}</div>
        ${data.rewards_db_dependency_resolution?.required ? `<p class="dependency-note"><strong>Rewards DB:</strong> ${escapeHtml(rewardsNote)}</p>` : ''}
        ${data.crowd_twist_dependency_resolution?.required ? `<p class="dependency-note"><strong>CrowdTwist:</strong> ${escapeHtml(crowdTwistNote)}</p>` : ''}
        <div class="chat-source-members">${memberHtml}</div>
    </section>`;
}

function addChatMessage(role, content, metadata = {}) {
    const container = byId('chatMessages');
    const row = document.createElement('div');
    row.className = `message ${role === 'user' ? 'user-message' : 'bot-message'}`;
    const avatar = role === 'user' ? '👤' : '🤖';
    const body = role === 'user' ? escapeHtml(content) : formatAssistantText(content);
    const meta = metadata.intent
        ? `<div class="message-meta">${escapeHtml(metadata.intent)}</div>`
        : '';
    const structuredData = metadata.structuredData || metadata.structured_data || {};
    const currentChange = structuredData.change;
    const nextChange = structuredData.next_change || currentChange?.next_change;
    const spreadsheetChanges = Array.isArray(structuredData.spreadsheet_update?.rows)
        ? structuredData.spreadsheet_update.rows.map((row) => row?.change).filter(Boolean)
        : [];
    const changeControls = role === 'user'
        ? ''
        : `${renderSourceChangeControls(currentChange)}${renderSourceChangeControls(nextChange)}${spreadsheetChanges.map(renderSourceChangeControls).join('')}`;
    const sourceQueryCard = role === 'user' ? '' : renderSourceQueryCard(structuredData);
    row.innerHTML = role === 'user'
        ? `<div class="message-content"><p>${body}</p>${meta}</div><div class="message-avatar">${avatar}</div>`
        : `<div class="message-avatar">${avatar}</div><div class="message-content"><div class="chat-rich-text">${body}</div>${meta}</div>`;
    if (changeControls) row.querySelector('.message-content')?.insertAdjacentHTML('beforeend', changeControls);
    if (sourceQueryCard) row.querySelector('.message-content')?.insertAdjacentHTML('beforeend', sourceQueryCard);
    container.appendChild(row);
    container.scrollTop = container.scrollHeight;
}

function showTyping() {
    hideTyping();
    const container = byId('chatMessages');
    const node = document.createElement('div');
    node.id = 'typingIndicator';
    node.className = 'typing-indicator';
    node.innerHTML = '<span></span><span></span><span></span>';
    container.appendChild(node);
    container.scrollTop = container.scrollHeight;
}

function hideTyping() {
    byId('typingIndicator')?.remove();
}

function clearChatView() {
    byId('chatMessages').innerHTML = `
        <div class="message bot-message">
            <div class="message-avatar">🤖</div>
            <div class="message-content"><p>Session memory is ready. Paste an Email, Profile ID, or CrowdTwist ID for a single analysis, paste or attach an email list for bulk analysis, or ask a follow-up question.</p></div>
        </div>`;
}

function updateContextIndicators() {
    byId('activeRunText').textContent = agenticState.activeRunId || 'None';
    byId('activeBatchText').textContent = agenticState.activeBatchResultId || agenticState.activeJobId || 'None';
    byId('activeContextText').textContent = agenticState.activeContext === 'batch'
        ? 'Bulk analysis'
        : agenticState.activeContext === 'individual'
            ? 'Individual analysis'
            : 'None';
}

function hasIndividualChatContext() {
    return Boolean(agenticState.activeRunId || agenticState.currentReport);
}

function hasBatchChatContext() {
    return Boolean(agenticState.activeJobId || agenticState.activeBatchResultId || agenticState.currentBatchSummary);
}

function setChatContextMode(mode, { persist = true, announce = false } = {}) {
    const normalized = mode === 'batch' ? 'batch' : 'individual';
    agenticState.chatContextMode = normalized;
    if (persist) window.RUSWorkspace?.setShared('rus.agentic.chatContext', normalized);

    const select = byId('chatContextSelect');
    if (select) select.value = normalized;
    byId('individualChatActions')?.classList.toggle('hidden', normalized !== 'individual');
    byId('batchChatActions')?.classList.toggle('hidden', normalized !== 'batch');

    // The unified composer accepts identifiers, lists and questions. The selected
    // context only controls which completed result is used for follow-up questions.
    updateSmartIntakePreview();

    const hint = byId('chatContextHint');
    if (hint) {
        if (normalized === 'batch') {
            hint.textContent = hasBatchChatContext()
                ? `Bulk context selected: ${agenticState.activeBatchResultId || agenticState.activeJobId || 'batch in progress'}.`
                : 'No bulk analysis is available in this session yet.';
        } else {
            hint.textContent = hasIndividualChatContext()
                ? `Single context selected: ${agenticState.activeRunId || 'active report'}.`
                : 'No single-user analysis is available in this session yet.';
        }
    }

    if (announce) {
        showToast(normalized === 'batch' ? 'Chat switched to bulk analysis.' : 'Chat switched to single analysis.');
    }
}

function syncChatContextSelector({ preferActive = false } = {}) {
    const select = byId('chatContextSelect');
    if (!select) return;

    const hasIndividual = hasIndividualChatContext();
    const hasBatch = hasBatchChatContext();
    const individualOption = select.querySelector('option[value="individual"]');
    const batchOption = select.querySelector('option[value="batch"]');
    if (individualOption) individualOption.disabled = !hasIndividual;
    if (batchOption) batchOption.disabled = !hasBatch;
    select.disabled = !hasIndividual && !hasBatch;

    let desired = agenticState.chatContextMode;
    if (preferActive && ['individual', 'batch'].includes(agenticState.activeContext)) {
        desired = agenticState.activeContext;
    }
    if (desired === 'individual' && !hasIndividual && hasBatch) desired = 'batch';
    if (desired === 'batch' && !hasBatch && hasIndividual) desired = 'individual';
    if (!hasIndividual && !hasBatch) desired = 'individual';
    setChatContextMode(desired, { persist: true, announce: false });
}


function historyKey(item) {
    return item?.kind === 'batch' ? `batch:${item.batch_id || item.job_id || ''}` : `individual:${item.run_id || ''}`;
}

function rememberReportHistory(item) {
    if (!item) return;
    const key = historyKey(item);
    if (!key || key.endsWith(':')) return;
    agenticState.reportHistory = (agenticState.reportHistory || []).filter(existing => historyKey(existing) !== key);
    agenticState.reportHistory.push(item);
    agenticState.reportHistory = agenticState.reportHistory.slice(-20);
    renderSessionReportHistory();
}

function renderSessionReportHistory() {
    const container = byId('sessionReportHistory');
    const count = byId('sessionReportHistoryCount');
    if (!container) return;
    const items = [...(agenticState.reportHistory || [])].reverse();
    if (count) count.textContent = `${items.length} report${items.length === 1 ? '' : 's'}`;
    if (!items.length) {
        container.innerHTML = '<span class="empty-copy">Run a single or bulk analysis to build session history.</span>';
        return;
    }
    container.innerHTML = items.map((item, index) => {
        const kind = item.kind === 'batch' ? 'Bulk' : 'Single';
        const id = item.kind === 'batch' ? (item.batch_id || item.job_id || 'Batch') : (item.run_id || 'Run');
        const label = item.label || item.search_value || id;
        const meta = item.kind === 'batch'
            ? `${item.unique_members ?? '—'} member(s) · ${item.completed_count ?? '—'} completed`
            : `${item.search_type || 'identifier'} · ${id}`;
        return `<button type="button" class="session-report-history-item" data-history-index="${index}"><span class="history-kind ${item.kind === 'batch' ? 'bulk' : 'single'}">${kind}</span><span><strong>${escapeHtml(label)}</strong><small>${escapeHtml(meta)}</small></span><b>View</b></button>`;
    }).join('');
    container.querySelectorAll('[data-history-index]').forEach((button) => button.addEventListener('click', async () => {
        const item = items[Number(button.dataset.historyIndex)];
        if (!item) return;
        activateTab('chatTab');
        if (item.kind === 'batch' && item.job_id) {
            agenticState.activeJobId = item.job_id;
            await loadBatchSummary(item.job_id, { announce: false, makeActive: true });
        } else if (item.run_id) {
            await loadActiveAnalysis(item.run_id, true);
        }
    }));
}

function showInlineResult(kind) {
    const empty = byId('analysisEmptyState');
    const single = byId('analysisResult');
    const bulk = byId('inlineBatchResult');
    empty?.classList.toggle('hidden', kind !== 'none');
    single?.classList.toggle('hidden', kind !== 'individual');
    bulk?.classList.toggle('hidden', kind !== 'batch');
}

function clearBatchPresentation({ message = 'Upload a file to begin.', clearSharedJob = true } = {}) {
    clearTimeout(agenticState.pollTimer);
    agenticState.pollTimer = null;
    agenticState.activeJobId = null;
    agenticState.activeBatchResultId = null;
    agenticState.currentBatchSummary = null;
    agenticState.batchCompletionAnnounced = false;
    if (clearSharedJob) window.RUSWorkspace?.removeShared('rus.agentic.jobId');

    const title = byId('batchStatusTitle');
    const progress = byId('batchProgressBar');
    const metrics = byId('batchMetrics');
    const phase = byId('batchPhaseText');
    const summary = byId('batchSummaryContainer');
    const download = byId('batchDownloadButton');
    if (title) title.textContent = 'Not started';
    if (progress) progress.style.width = '0%';
    if (metrics) metrics.innerHTML = '';
    if (phase) phase.textContent = message;
    if (summary) summary.innerHTML = '';
    if (download) {
        download.classList.add('hidden');
        download.removeAttribute('href');
    }
}

async function refreshActiveBatchContext({ announce = false } = {}) {
    if (!agenticState.sessionId) return null;
    try {
        const response = await agenticAiApi.getSessionActiveBatch(agenticState.sessionId);
        const data = envelopeData(response);
        const job = data.job || null;
        const summary = data.summary || null;
        if (job?.job_id) {
            agenticState.activeJobId = job.job_id;
            window.RUSWorkspace?.setShared('rus.agentic.jobId', job.job_id);
        } else if (!summary) {
            clearBatchPresentation({ clearSharedJob: true });
        }
        if (summary) {
            agenticState.currentBatchSummary = summary;
            agenticState.activeBatchResultId = summary.batch_id || job?.batch_id || null;
        } else if (job?.batch_id) {
            agenticState.activeBatchResultId = job.batch_id;
        }
        if (data.active_context) agenticState.activeContext = data.active_context;
        updateContextIndicators();
        if (summary) renderBatchSummary(summary, { announce, makeActive: data.active_context === 'batch' });
        return data;
    } catch (error) {
        console.warn('Unable to refresh active batch context', error);
        return null;
    }
}

function renderAgenticWriteMode(mode, health = {}) {
    const node = byId('agenticWriteModeStatus');
    if (!node) return;
    const accessMode = String(health?.accessMode || '').toLowerCase();
    const normalized = String(mode || 'live').toLowerCase();
    const role = String(window.RUSAuth?.getUser?.()?.role || '').toLowerCase();
    const readOnly = accessMode === 'read-only';
    node.classList.remove('live', 'dry-run', 'read-only');
    if (readOnly) {
        node.classList.add('read-only');
        node.textContent = '● Read-only profile';
        node.title = 'This profile can analyze data but cannot modify Rewards DB or CrowdTwist.';
    } else if (normalized === 'dry_run') {
        node.classList.add('dry-run');
        node.textContent = '● Dry Run profile';
        node.title = 'Agentic changes are validated and audited, but Rewards DB and CrowdTwist are not modified.';
    } else {
        node.classList.add('live');
        node.textContent = role === 'admin' ? '● Live governed writes · Admin' : '● Live governed writes';
        node.title = 'Authorized Agentic changes follow the signed-in profile approval policy before governed source updates execute.';
    }
}

async function bootstrapSession(deepHealth = false) {
    setServiceStatus('pending', 'Connecting…');
    try {
        const response = await agenticAiApi.bootstrap(agenticState.sessionId, deepHealth);
        const data = envelopeData(response);
        const session = data.session || {};
        const health = data.health || {};
        renderAgenticWriteMode(data.effectiveWriteMode || (data.dryRunEnabled ? 'dry_run' : 'live'), health);

        const sessionReused = Boolean(data.sessionReused);
        const serverJobId = session.active_batch_job_id || session.active_batch_id || null;
        agenticState.sessionId = session.session_id;
        agenticState.activeRunId = session.active_run_id || null;
        agenticState.activeJobId = serverJobId;
        agenticState.activeBatchResultId = session.active_batch_result_id || null;
        agenticState.activeContext = session.active_context || 'none';
        agenticState.pollIntervalMs = Math.max(2000, Number(data.batchPollIntervalSeconds || 5) * 1000);
        window.RUSWorkspace?.setShared('rus.agentic.sessionId', agenticState.sessionId);
        if (serverJobId) window.RUSWorkspace?.setShared('rus.agentic.jobId', serverJobId);
        else window.RUSWorkspace?.removeShared('rus.agentic.jobId');

        // A non-reused session means the Python API restarted, the session expired,
        // or the user explicitly moved to a new server-side session. Never attach
        // persisted DOM from the previous session to this new identity context.
        if (!sessionReused) {
            clearChatView();
            clearAnalysis();
            clearBatchPresentation({
                clearSharedJob: true,
                message: 'No bulk analysis is attached to this new session.'
            });
        } else if (!serverJobId) {
            clearBatchPresentation({ clearSharedJob: true });
        }

        byId('sessionIdText').textContent = agenticState.sessionId || 'Unavailable';
        updateContextIndicators();
        const adaptiveMemory = health.adaptive_memory || health.adaptiveMemory || null;
        const memoryNode = byId('memoryStatusText');
        if (memoryNode) {
            const sessionCount = session.message_count ?? 0;
            if (adaptiveMemory?.enabled) {
                const trajectoryCount = Number(adaptiveMemory.trajectories || 0);
                const skillCount = Number(adaptiveMemory.learned_skills || 0);
                const rsiLabel = adaptiveMemory.rsi_enabled ? 'bounded RSI on' : 'RSI off';
                const modelLabel = adaptiveMemory.model_selection_enabled ? 'champion/challenger on' : 'single model';
                memoryNode.textContent = `${sessionCount} session messages · ${trajectoryCount} learned runs · ${skillCount} skills · ${rsiLabel} · ${modelLabel}`;
                memoryNode.title = 'Persistent memory stores only PII-minimized execution outcomes, learned evidence-shape skills and replay lessons. Model selection is bounded to the configured Dell AIA allow-list. Memory cannot change business rules, source-write contracts or approvals.';
            } else {
                memoryNode.textContent = `${sessionCount} messages retained`;
            }
        }

        const apiVersionNode = byId('agentApiVersion');
        if (apiVersionNode) {
            const backendVersion = health.version || health.api_version || 'unknown';
            apiVersionNode.textContent = `Agent API v${backendVersion}`;
            apiVersionNode.title = `Python layout: ${health.layout || 'src-template'}`;
        }

        const healthStatus = String(health.status || 'READY').toUpperCase();
        const healthOnline = healthStatus === 'READY' || healthStatus === 'LIVE' || healthStatus === 'ONLINE' || health.available === true || health.live === true;
        setServiceStatus(
            healthOnline ? 'online' : healthStatus === 'DEGRADED' ? 'warning' : 'offline',
            healthStatus === 'READY' ? 'Dell AIA API ready' : healthOnline ? 'Agentic API online' : `Service ${healthStatus.toLowerCase()}`);

        agenticState.reportHistory = Array.isArray(session.report_history) ? session.report_history : [];
        renderSessionReportHistory();

        const messages = session.messages || [];
        clearChatView();
        if (messages.length) {
            byId('chatMessages').innerHTML = '';
            messages.forEach((message) => addChatMessage(message.role, message.content, message.metadata || {}));
        }

        if (agenticState.activeRunId) {
            await loadActiveAnalysis(agenticState.activeRunId, false);
        } else {
            clearAnalysis();
        }
        if (agenticState.activeJobId) {
            const batchContext = await refreshActiveBatchContext({ announce: false });
            const batchStatus = String(batchContext?.job?.status || '').toUpperCase();
            if (!['COMPLETED', 'FAILED'].includes(batchStatus)) {
                startBatchPolling(agenticState.activeJobId);
            } else if (batchContext?.job) {
                renderBatchStatus(batchContext.job);
            }
        }
        syncChatContextSelector({ preferActive: !(window.RUSWorkspace?.getShared('rus.agentic.chatContext') ?? sessionStorage.getItem('rus.agentic.chatContext')) });
    } catch (error) {
        setServiceStatus('offline', 'Agentic API unavailable');
        byId('sessionIdText').textContent = 'Not connected';
        addChatMessage('assistant', `The Agentic Data Disparity API is unavailable: ${error.message}`);
    }
}

async function runDeepHealth() {
    setLoader(true, 'Checking Dell AIA model route…');
    try {
        const response = await agenticAiApi.ready(true);
        const data = envelopeData(response);
        const probe = data.dell_aia_probe || {};
        if (probe.ok) {
            setServiceStatus('online', `${data.dell_aia_model || 'Dell AIA'} ready`);
            showToast(`Dell AIA route succeeded in ${probe.attempts || 1} attempt(s).`);
        } else {
            setServiceStatus('warning', 'Dell AIA route degraded');
            showToast('The API is reachable, but the Dell AIA route is degraded.', true);
        }
    } catch (error) {
        setServiceStatus('offline', 'Deep health failed');
        showToast(error.message, true);
    } finally {
        setLoader(false);
    }
}

async function createNewSession() {
    setLoader(true, 'Creating a new session…');
    try {
        if (agenticState.sessionId) {
            await agenticAiApi.deleteSession(agenticState.sessionId).catch(() => null);
        }
        window.RUSWorkspace?.removeShared('rus.agentic.sessionId');
        window.RUSWorkspace?.removeShared('rus.agentic.jobId');
        agenticState.sessionId = null;
        agenticState.activeRunId = null;
        agenticState.activeJobId = null;
        agenticState.activeBatchResultId = null;
        agenticState.activeContext = 'none';
        agenticState.currentReport = null;
        agenticState.currentBatchSummary = null;
        agenticState.batchCompletionAnnounced = false;
        agenticState.chatContextMode = 'individual';
        window.RUSWorkspace?.setShared('rus.agentic.chatContext', 'individual');
        clearAnalysis();
        clearChatView();
        if (byId('chatInput')) byId('chatInput').value = '';
        clearSmartInputFile();
        await bootstrapSession(false);
        showToast('New AI session created.');
    } finally {
        setLoader(false);
    }
}

async function resetSession() {
    if (!agenticState.sessionId) return;
    setLoader(true, 'Clearing session memory…');
    try {
        await agenticAiApi.resetSession(agenticState.sessionId);
        agenticState.activeRunId = null;
        agenticState.activeJobId = null;
        agenticState.activeBatchResultId = null;
        agenticState.activeContext = 'none';
        agenticState.currentReport = null;
        agenticState.currentBatchSummary = null;
        agenticState.batchCompletionAnnounced = false;
        agenticState.chatContextMode = 'individual';
        window.RUSWorkspace?.setShared('rus.agentic.chatContext', 'individual');
        window.RUSWorkspace?.removeShared('rus.agentic.jobId');
        updateContextIndicators();
        byId('memoryStatusText').textContent = '0 messages retained';
        clearChatView();
        clearAnalysis();
        if (byId('chatInput')) byId('chatInput').value = '';
        clearSmartInputFile();
        showToast('Session memory cleared.');
    } catch (error) {
        showToast(error.message, true);
    } finally {
        setLoader(false);
    }
}

function clearAnalysis() {
    byId('analysisResult').classList.add('hidden');
    byId('analysisEmptyState').classList.remove('hidden');
    byId('reportActions').innerHTML = '';
    byId('inlineBatchResult')?.classList.add('hidden');
    byId('currentReportDownloadButton')?.classList.add('hidden');
    byId('inlineBatchDownloadButton')?.classList.add('hidden');
}

async function runIndividualAnalysis(searchType, searchValue, { userMessage = null, clearComposer = false } = {}) {
    const value = String(searchValue || '').trim();
    if (!value) {
        showToast('Enter a valid identifier.', true);
        return null;
    }
    if (!agenticState.sessionId) await bootstrapSession(false);

    addChatMessage('user', userMessage || `Analyze ${searchType}: ${value}`);
    showTyping();
    setIntakeBusy(true);
    setLoader(true, 'Data Agent → Dell AIA Analyst → Judge…');
    try {
        const response = await agenticAiApi.analyze({
            search_type: searchType,
            search_value: value,
            session_id: agenticState.sessionId,
            include_raw_source_data: true,
            include_html: false,
            mask_report_values: agenticState.reportMasked
        });
        const report = envelopeData(response).report;
        if (!report) throw new Error('The analysis response did not contain a report.');
        renderAnalysis(report);
        addChatMessage('assistant', [
            `## Single-user analysis completed`,
            `- **Identifier:** ${report.search_value || value}`,
            `- **Run ID:** ${report.run_id || '—'}`,
            '',
            report.deterministic_summary || 'Analysis completed.'
        ].join('\n'), { intent: 'analysis' });
        if (clearComposer && byId('chatInput')) byId('chatInput').value = '';
        clearSmartInputFile();
        updateSmartIntakePreview();
        RUSNotifications?.add({
            title: 'Single analysis completed',
            message: `${report.search_value || value} · ${report.run_id || 'verified report ready'}`,
            type: 'success', category: 'analysis', link: 'ai-analysis.html'
        });
        refreshAuditViews();
        return report;
    } catch (error) {
        addChatMessage('assistant', `Analysis failed: ${error.message}`, { intent: 'error' });
        showToast(error.message, true);
        return null;
    } finally {
        hideTyping();
        setLoader(false);
        setIntakeBusy(false);
    }
}

async function analyzeData() {
    const searchType = byId('searchType').value;
    const searchValue = byId('searchValue').value.trim();
    if (!searchValue) {
        showToast('Enter an email, Profile ID or CrowdTwist ID.', true);
        return;
    }
    await runIndividualAnalysis(searchType, searchValue);
}

async function loadActiveAnalysis(runId, showBusy = true, rethrow = false) {
    if (showBusy) setLoader(true, 'Loading active report…');
    try {
        const response = await agenticAiApi.getAnalysis(runId, agenticState.reportMasked);
        const report = envelopeData(response);
        renderAnalysis(report, { makeActive: showBusy });
        return report;
    } catch (error) {
        if (showBusy) showToast(error.message, true);
        if (rethrow) throw error;
        return null;
    } finally {
        if (showBusy) setLoader(false);
    }
}

function renderAnalysis(report, { makeActive = true } = {}) {
    agenticState.currentReport = report;
    agenticState.activeRunId = report.run_id;
    if (makeActive) agenticState.activeContext = 'individual';
    updateContextIndicators();
    if (makeActive) setChatContextMode('individual', { persist: true, announce: false });
    syncChatContextSelector();
    showInlineResult('individual');
    rememberReportHistory({ kind: 'individual', run_id: report.run_id, label: report.search_value || report.run_id, search_type: report.search_type, search_value: report.search_value, created_at: new Date().toISOString() });
    byId('analysisTitle').textContent = `${report.search_value || 'Member'} · ${report.run_id || ''}`;
    const privacyNode = byId('analysisPrivacyBadge');
    if (privacyNode) {
        const maskedView = String(report.report_privacy || '').toUpperCase() === 'MASKED';
        privacyNode.textContent = maskedView ? 'Masked view' : 'Unmasked view';
        privacyNode.className = `report-privacy-badge ${maskedView ? 'masked' : 'unmasked'}`;
    }

    const aiExecution = report.ai_execution || {};
    const judge = report.judge_result || {};
    const kpis = [
        ['Coverage', report.analysis_completeness || '—'],
        ['Mismatches', report.mismatch_count ?? 0],
        ['Missing records', report.missing_record_count ?? 0],
        ['Exact changes', report.actionable_suggestion_count ?? 0],
        ['Manual review', report.manual_review_count ?? 0],
        ['Judge', judge.verdict || aiExecution.judge_verdict || '—'],
        ['Total time', formatDuration(report.timings?.end_to_end_ms || report.timings?.total_processing_ms)]
    ];
    byId('analysisKpis').innerHTML = kpis.map(([label, value]) => `
        <div class="mini-kpi"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('');

    byId('deterministicSummary').innerHTML = `
        <p>${escapeHtml(report.deterministic_summary || 'No deterministic summary was returned.')}</p>
        <div class="truth-policy"><strong>Truth policy:</strong> ${escapeHtml(report.truth_policy || '—')}</div>`;

    renderSourceHealth(report.source_status || {});
    renderSuggestions(report.suggestions || []);
    renderAttributes(report.attributes || []);
    renderJudge(judge, aiExecution);
    renderTimings(report.timings || {});
    byId('rawAnalysisJson').textContent = JSON.stringify(report, null, 2);

    renderReportActions(report);
    syncUniversalReportDownloadButtons();
}

function renderSourceHealth(sourceStatus) {
    const labels = { cps: 'CPS', rewards_db: 'Rewards DB', crowd_twist: 'CrowdTwist' };
    byId('sourceHealthGrid').innerHTML = Object.entries(sourceStatus).map(([key, source]) => {
        const state = !source.connected ? 'Unavailable' : source.data_found ? 'Data found' : 'No value found';
        const css = !source.connected ? 'source-error' : source.data_found ? 'source-success' : 'source-warning';
        const diagnostics = source.diagnostics || {};
        const attempts = diagnostics.lookup_attempts || diagnostics.identifier_lookup_sequence || [];
        const lookupHtml = attempts.length
            ? `<div class="lookup-path">${attempts.map((attempt) =>
                `<span>${escapeHtml(attempt.key)}: ${attempt.rows_found > 0 ? 'matched' : attempt.attempted ? 'no row' : 'not attempted'}</span>`).join('<span class="lookup-arrow">→</span>')}</div>`
            : '';
        const tcps = diagnostics.tcps_country_lookup;
        return `<article class="source-health-card ${css}">
            <div class="source-title"><strong>${escapeHtml(labels[key] || key)}</strong><span>${escapeHtml(state)}</span></div>
            <dl>
                <dt>Method</dt><dd>${escapeHtml(source.retrieval_method || '—')}</dd>
                <dt>Latency</dt><dd>${escapeHtml(formatDuration(source.latency_ms))}</dd>
                <dt>HTTP</dt><dd>${escapeHtml(source.http_status ?? '—')}</dd>
                <dt>Stage</dt><dd>${escapeHtml(source.stage || '—')}</dd>
            </dl>
            ${lookupHtml}
            ${tcps ? `<div class="sub-diagnostic">tCPS: ${escapeHtml(tcps.data_found ? 'country found' : tcps.error_code || 'no country')} · ${escapeHtml(formatDuration(tcps.latency_ms))}</div>` : ''}
            ${source.diagnostic_hint ? `<p class="diagnostic-hint">${escapeHtml(source.diagnostic_hint)}</p>` : ''}
        </article>`;
    }).join('');
}

function renderSuggestions(suggestions) {
    const container = byId('suggestionsContainer');
    if (!suggestions.length) {
        container.innerHTML = '<p class="empty-copy">No suggested changes were generated.</p>';
        return;
    }
    if (isFocusedAgenticRole()) {
        const actionable = suggestions.filter((item) => item.recommended_value !== null && item.recommended_value !== undefined);
        const visible = actionable.length ? actionable : suggestions;
        container.innerHTML = `<div class="focused-suggestion-list">${visible.map((item) => `<article class="focused-suggestion">
            <div class="focused-suggestion-head"><h4>${escapeHtml(item.label || item.attribute || 'Suggested action')}</h4><span class="result-chip priority-${escapeHtml(String(item.priority || 'medium').toLowerCase())}">${escapeHtml(item.priority || 'Review')}</span></div>
            <p>${escapeHtml(item.recommendation || item.reason || item.action || 'Review this item.')}</p>
            ${item.recommended_value !== null && item.recommended_value !== undefined ? `<div class="focused-change-line"><span class="before">${escapeHtml(displayValue(item.current_value))}</span><b>→</b><span class="after">${escapeHtml(displayValue(item.recommended_value))}</span></div>` : ''}
        </article>`).join('')}</div>
        ${isBusinessAgenticRole() && actionable.length ? `<div class="focused-report-actions"><button type="button" class="btn btn-primary" data-business-change>Do the suggested changes</button><span class="cell-note">You will review the exact plan, then approve it once in chat.</span></div>` : ''}`;
        container.querySelector('[data-business-change]')?.addEventListener('click', () => sendChat('auto', 'Do the suggested changes'));
        return;
    }
    container.innerHTML = `<div class="table-scroll"><table class="agentic-table">
        <thead><tr><th>Priority</th><th>Attribute</th><th>Action</th><th>Target</th><th>Current</th><th>Recommended</th><th>Review</th></tr></thead>
        <tbody>${suggestions.map((item) => `<tr>
            <td><span class="result-chip priority-${escapeHtml(String(item.priority || '').toLowerCase())}">${escapeHtml(item.priority || '—')}</span></td>
            <td><strong>${escapeHtml(item.label || item.attribute)}</strong><div class="cell-note">${escapeHtml(item.reason || '')}</div></td>
            <td>${escapeHtml(item.action || '—')}</td>
            <td>${escapeHtml(item.target_source || '—')}</td>
            <td>${escapeHtml(displayValue(item.current_value))}</td>
            <td>${escapeHtml(displayValue(item.recommended_value))}</td>
            <td>${item.requires_manual_review ? 'Manual' : item.automation_eligible ? 'Dry-run ready' : 'No write'}</td>
        </tr>`).join('')}</tbody></table></div>`;
}

function renderAttributes(attributes) {
    if (!attributes.length) {
        byId('attributeTableContainer').innerHTML = '<p class="empty-copy">No attribute verdicts.</p>';
        return;
    }
    byId('attributeTableContainer').innerHTML = `<table class="agentic-table">
        <thead><tr><th>Attribute</th><th>Status</th><th>Truth source</th><th>Truth value</th><th>Wrong sources</th><th>Explanation</th></tr></thead>
        <tbody>${attributes.map((item) => `<tr>
            <td><strong>${escapeHtml(item.label || item.attribute)}</strong></td>
            <td><span class="result-chip status-${escapeHtml(String(item.status || '').toLowerCase())}">${escapeHtml(item.status || '—')}</span></td>
            <td>${escapeHtml(item.truth_source || '—')}</td>
            <td>${escapeHtml(displayValue(item.truth_value))}</td>
            <td>${escapeHtml(displayValue(item.wrong_sources))}</td>
            <td>${escapeHtml(item.explanation || '')}</td>
        </tr>`).join('')}</tbody></table>`;
}

function renderJudge(judge, aiExecution) {
    const verdict = judge.verdict || aiExecution.judge_verdict || '—';
    const disposition = judge.content_disposition || aiExecution.final_content_status || '—';
    const analystPublished = aiExecution.analyst_content_published;
    byId('judgeContainer').innerHTML = `
        <div class="judge-banner judge-${escapeHtml(String(verdict).toLowerCase())}">
            <div><span>Judge verdict</span><strong>${escapeHtml(verdict)}</strong></div>
            <div><span>Published content</span><strong>${escapeHtml(disposition)}</strong></div>
            <div><span>Analyst output published</span><strong>${analystPublished === undefined ? '—' : analystPublished ? 'Yes' : 'No'}</strong></div>
        </div>
        <p>${escapeHtml(judge.corrected_summary || agenticState.currentReport?.ai_analysis?.summary || 'No Judge summary was returned.')}</p>
        ${(judge.unsupported_claims || []).length ? `<div class="warning-box"><strong>Unsupported claims removed:</strong><ul>${judge.unsupported_claims.map((claim) => `<li>${escapeHtml(claim)}</li>`).join('')}</ul></div>` : ''}`;
}

function flattenTimings(value, prefix = '', output = []) {
    Object.entries(value || {}).forEach(([key, item]) => {
        const label = prefix ? `${prefix} · ${key}` : key;
        if (item && typeof item === 'object' && !Array.isArray(item)) {
            flattenTimings(item, label, output);
        } else if (key.endsWith('_ms') || typeof item === 'number') {
            output.push([label.replaceAll('_', ' '), formatDuration(item)]);
        }
    });
    return output;
}

function renderTimings(timings) {
    const rows = flattenTimings(timings);
    byId('timingContainer').innerHTML = rows.length
        ? `<table class="agentic-table"><thead><tr><th>Step</th><th>Duration</th></tr></thead><tbody>${rows.map(([step, duration]) => `<tr><td>${escapeHtml(step)}</td><td>${escapeHtml(duration)}</td></tr>`).join('')}</tbody></table>`
        : '<p class="empty-copy">No timing data returned.</p>';
}


async function acceptQueuedBatch(job, description) {
    agenticState.activeJobId = job.job_id;
    agenticState.activeBatchResultId = null;
    agenticState.currentBatchSummary = null;
    agenticState.activeContext = 'batch';
    setChatContextMode('batch', { persist: true, announce: false });
    agenticState.batchCompletionAnnounced = false;
    window.RUSWorkspace?.setShared('rus.agentic.jobId', job.job_id);
    updateContextIndicators();
    renderBatchStatus(job);
    startBatchPolling(job.job_id);
    addChatMessage('assistant', [
        '## Bulk analysis queued',
        `- **Job ID:** ${job.job_id}`,
        `- **Submitted:** ${job.submitted_count ?? 0}`,
        `- **Unique valid emails:** ${job.unique_valid_count ?? 0}`,
        `- **Duplicates ignored:** ${job.duplicate_count ?? 0}`,
        '',
        description || 'The Agent will attach the completed portfolio summary to this chat session.'
    ].join('\n'), { intent: 'batch_queued' });
    showToast(`Batch ${job.job_id} queued.`);
    refreshAuditViews();
}

async function submitPastedEmailBatch(emails, originalText) {
    if (!emails.length) throw new Error('No valid email address was detected for bulk analysis.');
    const response = await agenticAiApi.submitBatch({
        emails,
        session_id: agenticState.sessionId,
        max_parallel: FIXED_SOURCE_PARALLEL_WORKERS,
        max_parallel_ai: FIXED_DELL_AIA_PARALLEL_WORKERS,
        include_group_ai: FIXED_GROUPED_DELL_AIA
    });
    const job = envelopeData(response);
    await acceptQueuedBatch(job, 'The pasted list was accepted. Progress and the final summary will be available in this chat and in Batch Processing.');
    if (byId('chatInput')) byId('chatInput').value = '';
    updateSmartIntakePreview();
    return job;
}

async function submitAttachedEmailBatch(file) {
    if (!file) throw new Error('Select a TXT or CSV file.');
    const response = await agenticAiApi.uploadBatch(file, {
        sessionId: agenticState.sessionId,
        maxParallel: FIXED_SOURCE_PARALLEL_WORKERS,
        maxParallelAi: FIXED_DELL_AIA_PARALLEL_WORKERS,
        includeGroupAi: FIXED_GROUPED_DELL_AIA
    });
    const job = envelopeData(response);
    await acceptQueuedBatch(job, `The attached file **${file.name}** was accepted. The completed result will be retained in this session.`);
    if (byId('chatInput')) byId('chatInput').value = '';
    clearSmartInputFile();
    return job;
}

async function submitAttachedUpdateWorkbook(file, instruction) {
    if (!file) throw new Error('Select an XLSX or XLSM update workbook.');
    const response = await agenticAiApi.uploadSourceUpdateWorkbook(file, {
        sessionId: agenticState.sessionId,
        instruction: instruction || 'validate these spreadsheet changes'
    });
    return envelopeData(response);
}

async function submitSmartInput() {
    if (agenticState.intakeBusy) return;
    const text = (byId('chatInput')?.value || '').trim();
    const detection = updateSmartIntakePreview();

    if (!text && !agenticState.pendingChatFile) {
        showToast('Enter an Email, Profile ID, CrowdTwist ID, paste an email list, attach TXT/CSV/XLSX, or ask a question.', true);
        return;
    }
    if (!agenticState.sessionId) await bootstrapSession(false);

    if (detection.mode === 'spreadsheet_update') {
        const instruction = text || 'validate these spreadsheet changes';
        addChatMessage('user', `${instruction}\nWorkbook: ${detection.fileName}`);
        setIntakeBusy(true);
        setLoader(true, 'Processing Excel source updates…');
        try {
            const data = await submitAttachedUpdateWorkbook(agenticState.pendingChatFile, instruction);
            addChatMessage('assistant', data.reply || 'The Excel update workbook was processed.', {
                intent: data.intent || 'spreadsheet_updates_validated',
                structuredData: data.structured_data || {}
            });
            if (data.active_run_id) {
                const loaded = await loadActiveAnalysis(data.active_run_id, false, false);
                if (loaded) {
                    agenticState.activeContext = 'individual';
                    setChatContextMode('individual', { persist: true, announce: false });
                }
            }
            refreshAuditViews();
            if (byId('chatInput')) byId('chatInput').value = '';
            clearSmartInputFile();
            showToast(data.intent === 'spreadsheet_updates_executed' ? 'Excel updates executed.' : (data.intent === 'spreadsheet_updates_awaiting_final_approval' ? 'Chat approval recorded. Complete the final-review popup(s).' : 'Excel updates validated.'));
        } catch (error) {
            addChatMessage('assistant', `Excel update processing failed: ${error.message}`, { intent: 'error' });
            showToast(error.message, true);
        } finally {
            setLoader(false);
            setIntakeBusy(false);
        }
        return;
    }

    if (detection.mode === 'command') {
        // Do not strip the change instruction by jumping directly to /analyze.
        // The chat router needs the full command so it can run a fresh analysis
        // for the supplied identifier and create the exact governed correction
        // plan before the authenticated profile's approval step(s).
        await sendChat('auto');
        return;
    }

    if (detection.mode === 'individual') {
        if (!detection.identifier) {
            showToast('Single analysis requires one email, Profile ID, or CrowdTwist ID.', true);
            return;
        }
        await runIndividualAnalysis(detection.identifier.searchType, detection.identifier.value, {
            userMessage: text || `Analyze ${detection.identifier.label}: ${detection.identifier.value}`,
            clearComposer: true
        });
        return;
    }

    if (detection.mode === 'batch') {
        if (!detection.emails.length) {
            showToast('Bulk analysis requires at least one valid email address.', true);
            return;
        }
        addChatMessage('user', detection.hasFile
            ? `Run bulk analysis from ${detection.fileName} (${detection.emails.length} unique emails)`
            : `Run bulk analysis for ${detection.emails.length} unique emails`);
        setIntakeBusy(true);
        setLoader(true, 'Submitting bulk analysis…');
        try {
            if (detection.hasFile) await submitAttachedEmailBatch(agenticState.pendingChatFile);
            else await submitPastedEmailBatch(detection.emails, text);
        } catch (error) {
            addChatMessage('assistant', `Bulk submission failed: ${error.message}`, { intent: 'error' });
            showToast(error.message, true);
        } finally {
            setLoader(false);
            setIntakeBusy(false);
        }
        return;
    }

    await sendChat('auto');
}

function refreshAuditViews() {
    try { localStorage.setItem('rus.dashboard.auditDirty', String(Date.now())); } catch { /* storage unavailable */ }
    if (!window.RUSAuditTrail?.load) return;
    document.querySelectorAll('[data-audit-root]').forEach((root) => {
        window.RUSAuditTrail.load(root, { limit: Number(root.dataset.auditLimit || 100) });
    });
}

async function sendChat(action = 'auto', explicitMessage = null) {
    const message = (explicitMessage ?? byId('chatInput').value).trim();
    if (!message || !agenticState.sessionId) return;
    if (!explicitMessage) {
        byId('chatInput').value = '';
        updateSmartIntakePreview();
    }
    addChatMessage('user', message);
    showTyping();
    try {
        const response = await agenticAiApi.chat({
            session_id: agenticState.sessionId,
            message,
            action,
            context: agenticState.chatContextMode,
            judge_response: true
        });
        const data = envelopeData(response);
        addChatMessage('assistant', data.reply || 'No reply returned.', { intent: data.intent, structuredData: data.structured_data || {} });
        if (data.intent === 'source_query') {
            const structured = data.structured_data || {};
            RUSNotifications?.add({ title: 'Source extraction completed', message: `${structured.requested_member_count || structured.requested_count || 0} member(s) · ${(structured.source_labels || [structured.source_label]).filter(Boolean).join(' + ')}`, type: 'success', category: 'source-query', link: 'ai-analysis.html' });
        }
        if (['source_confirm_2', 'source_change_executed', 'source_changes_executed', 'source_change_cancelled'].includes(data.intent)) {
            const change = data.structured_data?.change || {};
            const completed = data.intent !== 'source_change_cancelled';
            const title = data.intent === 'source_changes_executed' ? 'Requested source changes processed' : (completed ? 'Source change completed' : 'Source change cancelled');
            RUSNotifications?.add({ title, message: `${change.change_id || ''} · ${change.status || ''}`, type: completed ? 'success' : 'warning', category: 'source-change', link: 'ai-analysis.html' });
        }
        if (data.active_run_id) {
            agenticState.activeRunId = data.active_run_id;
            const preparedFromIdentifier = data.intent === 'source_change_planned' && data.structured_data?.analysis_performed;
            if (data.intent === 'analyze') {
                const loaded = await loadActiveAnalysis(data.active_run_id, false, false);
                if (loaded) {
                    agenticState.activeContext = 'individual';
                    setChatContextMode('individual', { persist: true, announce: false });
                    showToast('Analysis complete. The result panel has been updated.');
                }
            } else if (preparedFromIdentifier) {
                const loaded = await loadActiveAnalysis(data.active_run_id, false, false);
                if (loaded) {
                    agenticState.activeContext = 'individual';
                    setChatContextMode('individual', { persist: true, announce: false });
                    showToast('Change plan prepared. Review the exact values in chat.');
                }
            }
        }
        const postWrite = data.structured_data?.change?.post_write_analysis || {};
        if (postWrite.run_id) {
            const loaded = await loadActiveAnalysis(postWrite.run_id, false, false);
            if (loaded) {
                agenticState.activeContext = 'individual';
                setChatContextMode('individual', { persist: true, announce: false });
                showToast('Source updated. Fresh cross-source verification is now active.');
            }
        } else if (String(postWrite.status || '').toUpperCase() === 'FAILED') {
            showToast('Source update succeeded, but automatic reanalysis failed. Run Analyze to refresh.', true);
        }
        if (['analyze', 'source_query', 'source_change_planned', 'source_change_needs_details', 'source_confirm_1', 'source_popup_required', 'source_confirm_2', 'source_change_executed', 'source_changes_executed', 'source_change_cancelled', 'source_operation_error'].includes(data.intent)) {
            refreshAuditViews();
        }
        if (data.active_batch_id) {
            agenticState.activeJobId = data.active_batch_id;
            window.RUSWorkspace?.setShared('rus.agentic.jobId', data.active_batch_id);
        }
        if (data.memory?.active_context) agenticState.activeContext = data.memory.active_context;
        if (String(data.intent || '').startsWith('batch_') && data.active_batch_id) agenticState.activeContext = 'batch';
        updateContextIndicators();
        syncChatContextSelector();
        byId('memoryStatusText').textContent = 'Individual and bulk context retained in session';
    } catch (error) {
        addChatMessage('assistant', `Chat request failed: ${error.message}`, { intent: 'error' });
    } finally {
        hideTyping();
    }
}

async function loadUseCases() {
    if (!agenticState.activeRunId) {
        showToast('Run an analysis first.', true);
        return;
    }
    setLoader(true, 'Loading use-case recommendations…');
    try {
        const response = await agenticAiApi.getUseCases(agenticState.activeRunId);
        const recommendations = envelopeData(response).recommendations || [];
        byId('useCasesContainer').innerHTML = recommendations.map((item) => `
            <article class="use-case-card">
                <div><span class="result-chip priority-${escapeHtml(String(item.priority || '').toLowerCase())}">${escapeHtml(item.priority || '—')}</span></div>
                <div class="use-case-copy"><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.why_suggested || item.description || '')}</p></div>
                <button class="btn btn-secondary btn-sm compile-plan" data-use-case="${escapeHtml(item.use_case_id)}">Compile plan</button>
            </article>`).join('') || '<p class="empty-copy">No use cases returned.</p>';
        document.querySelectorAll('.compile-plan').forEach((button) => {
            button.addEventListener('click', () => compileUseCasePlan(button.dataset.useCase));
        });
    } catch (error) {
        showToast(error.message, true);
    } finally {
        setLoader(false);
    }
}

async function compileUseCasePlan(useCaseId) {
    setLoader(true, `Compiling ${useCaseId} with Dell AIA review…`);
    try {
        const response = await agenticAiApi.compileUseCasePlan(agenticState.activeRunId, useCaseId, true);
        const pre = document.createElement('pre');
        pre.className = 'json-viewer';
        pre.textContent = JSON.stringify(envelopeData(response), null, 2);
        byId('useCasesContainer').prepend(pre);
    } catch (error) {
        showToast(error.message, true);
    } finally {
        setLoader(false);
    }
}

async function startBatch() {
    const file = byId('batchFile').files[0];
    if (!file) {
        showToast('Select a TXT or CSV file.', true);
        return;
    }
    const isAdmin = currentAgenticRole() === 'admin';
    const maxParallel = isAdmin ? Math.max(1, Math.min(8, Number(byId('batchMaxParallel')?.value || FIXED_SOURCE_PARALLEL_WORKERS))) : FIXED_SOURCE_PARALLEL_WORKERS;
    const maxParallelAi = isAdmin ? Math.max(1, Math.min(2, Number(byId('batchMaxParallelAi')?.value || FIXED_DELL_AIA_PARALLEL_WORKERS))) : FIXED_DELL_AIA_PARALLEL_WORKERS;
    const includeGroupAi = isAdmin ? Boolean(byId('batchIncludeGroupAi')?.checked) : FIXED_GROUPED_DELL_AIA;
    setLoader(true, 'Submitting batch…');
    try {
        const response = await agenticAiApi.uploadBatch(file, {
            sessionId: agenticState.sessionId,
            maxParallel,
            maxParallelAi,
            includeGroupAi
        });
        const job = envelopeData(response);
        addChatMessage('user', `Run bulk analysis from ${file.name}`);
        await acceptQueuedBatch(job, `The Batch Processing upload **${file.name}** was accepted and attached to this chat session.`);
    } catch (error) {
        showToast(error.message, true);
    } finally {
        setLoader(false);
    }
}

function startBatchPolling(jobId) {
    if (!jobId) return;
    clearTimeout(agenticState.pollTimer);
    const poll = async () => {
        try {
            const response = await agenticAiApi.getBatch(jobId);
            const job = envelopeData(response);
            renderBatchStatus(job);
            if (job.status === 'COMPLETED') {
                agenticState.activeContext = 'batch';
                agenticState.activeBatchResultId = job.batch_id || agenticState.activeBatchResultId;
                updateContextIndicators();
                await loadBatchSummary(jobId, { announce: true });
                refreshAuditViews();
                return;
            }
            if (job.status === 'FAILED') {
                agenticState.activeContext = 'batch';
                updateContextIndicators();
                showToast(job.error?.message || 'Batch failed.', true);
                refreshAuditViews();
                return;
            }
            agenticState.pollTimer = setTimeout(poll, agenticState.pollIntervalMs);
        } catch (error) {
            if (Number(error.status) === 404) {
                clearTimeout(agenticState.pollTimer);
                if (agenticState.activeJobId === jobId) {
                    agenticState.activeJobId = null;
                    window.RUSWorkspace?.removeShared('rus.agentic.jobId');
                }
                updateContextIndicators();
                syncChatContextSelector();
                byId('batchStatusTitle').textContent = 'Previous job unavailable';
                byId('batchPhaseText').textContent = 'The Python API was restarted or this browser retained an expired job ID. Submit a new batch.';
                addChatMessage('assistant', 'The previous bulk job is no longer available. The API may have restarted, so the stale polling request has been stopped. Submit the list again to create a new job.', { intent: 'batch_not_found' });
                return;
            }
            byId('batchPhaseText').textContent = `Polling error: ${error.message}. Retrying…`;
            agenticState.pollTimer = setTimeout(poll, Math.max(agenticState.pollIntervalMs, 10000));
        }
    };
    poll();
}

function renderBatchStatus(job) {
    if (job?.job_id) {
        agenticState.activeJobId = job.job_id;
        window.RUSWorkspace?.setShared('rus.agentic.jobId', job.job_id);
    }
    if (job?.batch_id) agenticState.activeBatchResultId = job.batch_id;
    if (job?.status) agenticState.activeContext = 'batch';
    updateContextIndicators();
    syncChatContextSelector();
    const total = Number(job.unique_valid_count || 0);
    const completed = Number(job.completed_count || 0);
    const percent = total ? Math.min(100, Math.round((completed / total) * 100)) : job.status === 'COMPLETED' ? 100 : 0;
    byId('batchStatusTitle').textContent = `${job.status || 'QUEUED'} · ${job.job_id || ''}`;
    byId('batchProgressBar').style.width = `${percent}%`;
    byId('batchPhaseText').textContent = `${job.phase || 'QUEUED'} · elapsed ${formatDuration(job.elapsed_ms)}`;
    byId('batchMetrics').innerHTML = [
        ['Submitted', job.submitted_count ?? 0],
        ['Unique', job.unique_valid_count ?? 0],
        ['Duplicates', job.duplicate_count ?? 0],
        ['Completed', job.completed_count ?? 0],
        ['Failed', job.failed_count ?? 0]
    ].map(([label, value]) => `<div class="mini-kpi"><span>${label}</span><strong>${escapeHtml(value)}</strong></div>`).join('');

    if (job.status === 'COMPLETED') {
        const link = byId('batchDownloadButton');
        link.href = agenticAiApi.batchDownloadUrl(job.job_id, agenticState.reportMasked);
        link.textContent = `Download ${agenticState.reportMasked ? 'masked' : 'unmasked'} report ZIP`;
        link.classList.remove('hidden');
        refreshReportDownloadLinks();
    }
}

function percentValue(numerator, denominator) {
    const num = Number(numerator || 0);
    const den = Number(denominator || 0);
    return den > 0 ? Math.round((num / den) * 1000) / 10 : 0;
}

function deriveBatchInsights(summary) {
    if (summary.batch_insights) return summary.batch_insights;
    const processing = summary.processing || {};
    const population = summary.population_metrics || {};
    const unique = Number(population.unique_members_processed || processing.completed_count || 0);
    const counts = summary.attribute_issue_user_counts || {};
    const ranked = Object.entries(counts)
        .map(([attribute, count]) => ({ attribute, users_affected: Number(count || 0), percentage_of_members: percentValue(count, unique) }))
        .sort((a, b) => b.users_affected - a.users_affected || a.attribute.localeCompare(b.attribute));
    const majorityCount = ranked[0]?.users_affected || 0;
    const majority = ranked.filter((item) => item.users_affected === majorityCount && majorityCount > 0);
    const bySource = summary.source_member_record_metrics?.by_source || summary.source_record_status || {};
    const sourceCoverage = Object.entries(bySource).map(([source, item]) => ({
        source,
        found_members: Number(item.FOUND || 0),
        missing_member_records: Number(item.NO_RECORD || 0),
        unavailable_members: Number(item.UNAVAILABLE || 0),
        coverage_percentage: percentValue(item.FOUND, unique)
    })).sort((a, b) => b.missing_member_records - a.missing_member_records);
    return {
        unique_members: unique,
        population_percentages: {
            members_with_any_issue: percentValue(population.users_with_any_issue, unique),
            members_with_exact_changes: percentValue(population.users_with_exact_changes, unique),
            members_requiring_manual_review: percentValue(population.users_requiring_manual_review, unique),
            members_with_missing_source_record: percentValue(population.users_with_any_missing_source_record, unique)
        },
        majority_issue: { attributes: majority, is_tie: majority.length > 1 },
        ranked_issue_attributes: ranked,
        source_coverage: sourceCoverage,
        judge_distribution: Object.entries(summary.judge_outcomes || {}).map(([verdict, count]) => ({
            verdict, members: Number(count || 0), percentage_of_members: percentValue(count, unique)
        }))
    };
}

function sourceLabel(source) {
    return { cps: 'CPS', rewards_db: 'Rewards DB', crowd_twist: 'CrowdTwist' }[String(source || '').toLowerCase()] || source || 'Unknown';
}

function issueBar(item, unique) {
    const pct = item.percentage_of_members ?? percentValue(item.users_affected, unique);
    return `<div class="insight-bar-row">
        <div class="insight-bar-label"><strong>${escapeHtml(item.attribute)}</strong><span>${escapeHtml(item.users_affected)} / ${escapeHtml(unique)} · ${escapeHtml(pct)}%</span></div>
        <div class="insight-bar-track"><span style="width:${Math.min(100, Number(pct || 0))}%"></span></div>
    </div>`;
}

function renderBatchSummary(summary, { announce = false, makeActive = true } = {}) {
    agenticState.currentBatchSummary = summary;
    agenticState.activeBatchResultId = summary.batch_id || agenticState.activeBatchResultId;
    if (makeActive) agenticState.activeContext = 'batch';
    updateContextIndicators();
    if (makeActive) setChatContextMode('batch', { persist: true, announce: false });
    syncChatContextSelector();
    showInlineResult('batch');
    rememberReportHistory({ kind: 'batch', job_id: agenticState.activeJobId, batch_id: summary.batch_id || agenticState.activeBatchResultId, label: summary.batch_id || agenticState.activeJobId || 'Bulk report', unique_members: summary.population_metrics?.unique_members_processed, completed_count: summary.processing?.completed_count, failed_count: summary.processing?.failed_count, created_at: new Date().toISOString() });
    syncUniversalReportDownloadButtons();

    const processing = summary.processing || {};
    const population = summary.population_metrics || {};
    const totals = summary.totals || {};
    const judge = summary.judge_outcomes || {};
    const timings = summary.timings || {};
    const sourceMetrics = summary.source_member_record_metrics || {};
    const authoritative = summary.authoritative_group_summary || '';
    const insights = deriveBatchInsights(summary);
    const percentages = insights.population_percentages || {};
    const unique = Number(insights.unique_members || population.unique_members_processed || 0);
    const majority = insights.majority_issue?.attributes || [];
    const majorityText = majority.length
        ? `${majority.map((item) => item.attribute).join(', ')} ${majority.length > 1 ? 'are tied' : 'is'} highest at ${majority[0].users_affected} member(s) (${majority[0].percentage_of_members}%).`
        : 'No recurring non-match issue was found.';
    const rankedIssues = insights.ranked_issue_attributes || [];
    const sourceCoverage = insights.source_coverage || [];
    const judgeDistribution = insights.judge_distribution || [];

    const statCards = [
        ['Unique members', unique],
        ['Completed', processing.completed_count ?? 0],
        ['Failed', processing.failed_count ?? 0],
        ['Any issue', `${population.users_with_any_issue ?? 0} (${percentages.members_with_any_issue ?? 0}%)`],
        ['Exact-change users', `${population.users_with_exact_changes ?? 0} (${percentages.members_with_exact_changes ?? 0}%)`],
        ['Manual-review users', `${population.users_requiring_manual_review ?? 0} (${percentages.members_requiring_manual_review ?? 0}%)`],
        ['Missing-source users', `${population.users_with_any_missing_source_record ?? 0} (${percentages.members_with_missing_source_record ?? 0}%)`],
        ['Total time', formatDuration(timings.batch_total_ms)]
    ];

    const findingCards = [
        ['Mismatch items', totals.mismatches ?? 0],
        ['Missing source records', sourceMetrics.missing_source_member_records_total ?? totals.missing_records ?? 0],
        ['Deferred attributes', totals.deferred ?? 0],
        ['Format issues', totals.format_issues ?? 0],
        ['Unverifiable', totals.unverifiable ?? 0],
        ['Exact changes', totals.exact_changes ?? 0],
        ['Manual review items', totals.manual_review ?? 0]
    ];

    byId('batchSummaryContainer').innerHTML = `
        <section class="batch-insight-section">
            <div class="batch-insight-heading">
                <div><div class="eyebrow">Completed bulk analysis</div><h3>Summary statistics</h3></div>
                <span class="result-chip status-accepted">${escapeHtml(summary.batch_id || 'BATCH')}</span>
            </div>
            <div class="mini-kpi-grid batch-stat-grid">
                ${statCards.map(([label, value]) => `<div class="mini-kpi"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}
            </div>
        </section>

        <section class="batch-insight-section majority-insight">
            <div class="batch-insight-heading"><div><div class="eyebrow">Portfolio pattern</div><h3>Majority issue</h3></div></div>
            <div class="majority-callout"><span class="majority-icon">◎</span><div><strong>${escapeHtml(majorityText)}</strong><p>Calculated by unique members with a non-MATCH verdict for each attribute. Ties are preserved.</p></div></div>
        </section>

        <section class="batch-insight-section">
            <div class="batch-insight-heading"><div><div class="eyebrow">Distribution</div><h3>Top issue attributes</h3></div></div>
            <div class="insight-bars">${rankedIssues.length ? rankedIssues.slice(0, 8).map((item) => issueBar(item, unique)).join('') : '<p class="empty-copy">No recurring issues.</p>'}</div>
        </section>

        <div class="batch-summary-grid">
            <div class="summary-panel"><h3>Finding item totals</h3>${findingCards.map(([label, value]) => `<p><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></p>`).join('')}</div>
            <div class="summary-panel"><h3>Source coverage</h3>${sourceCoverage.map((item) => `<p><span>${escapeHtml(sourceLabel(item.source))}</span><strong>${escapeHtml(item.coverage_percentage)}%</strong><small>${escapeHtml(item.found_members)} found · ${escapeHtml(item.missing_member_records)} no record</small></p>`).join('') || '<p>No source coverage returned.</p>'}</div>
            <div class="summary-panel"><h3>Judge outcomes</h3>${judgeDistribution.map((item) => `<p><span>${escapeHtml(item.verdict)}</span><strong>${escapeHtml(item.members)} (${escapeHtml(item.percentage_of_members)}%)</strong></p>`).join('') || Object.entries(judge).map(([key, value]) => `<p><span>${escapeHtml(key)}</span><strong>${escapeHtml(value)}</strong></p>`).join('') || '<p>No Judge totals returned.</p>'}</div>
            <div class="summary-panel"><h3>Agent execution</h3><p><span>Dell AIA success</span><strong>${escapeHtml(processing.dell_aia_execution_success_count ?? 0)}</strong></p><p><span>MCP success</span><strong>${escapeHtml(processing.mcp_success_count ?? 0)}</strong></p><p><span>Email-context failures</span><strong>${escapeHtml(processing.email_context_integrity_failures ?? 0)}</strong></p></div>
            <div class="summary-panel"><h3>Timing</h3><p><span>Total</span><strong>${escapeHtml(formatDuration(timings.batch_total_ms))}</strong></p><p><span>Data collection</span><strong>${escapeHtml(formatDuration(timings.data_collection_phase_ms))}</strong></p><p><span>Analysis + Judge</span><strong>${escapeHtml(formatDuration(timings.analysis_judge_phase_ms))}</strong></p></div>
        </div>
        ${authoritative ? `<div class="summary-banner"><strong>Authoritative grouped result</strong><p>${escapeHtml(authoritative)}</p></div>` : ''}
        <div class="batch-question-prompts">
            <strong>Ask the Agent:</strong>
            <button class="batch-question-chip" data-message="Show summary statistics">Summary statistics</button>
            <button class="batch-question-chip" data-message="What is the majority issue?">Majority issue</button>
            <button class="batch-question-chip" data-message="Which source has the most missing records?">Source coverage</button>
            <button class="batch-question-chip" data-message="Show Judge outcomes">Judge outcomes</button>
            <button class="batch-question-chip" data-message="Which users have exact changes?">Affected users</button>
        </div>`;

    const inlineBatchSummary = byId('inlineBatchSummaryContainer');
    if (inlineBatchSummary) inlineBatchSummary.innerHTML = byId('batchSummaryContainer')?.innerHTML || '';

    document.querySelectorAll('.batch-question-chip').forEach((button) => {
        button.addEventListener('click', () => {
            activateTab('chatTab');
            sendChat('auto', button.dataset.message);
        });
    });

    // v11.37: bulk result is rendered in the same Chat & Analysis result pane for every role.

    byId('memoryStatusText').textContent = 'Bulk result, statistics and conversation retained in session';
    if (announce && !agenticState.batchCompletionAnnounced) {
        const message = [
            `## Bulk analysis completed — ${summary.batch_id || agenticState.activeJobId}`,
            '',
            '### Summary statistics',
            `- **Unique members:** ${unique}`,
            `- **Completed:** ${processing.completed_count ?? 0}`,
            `- **Failed:** ${processing.failed_count ?? 0}`,
            `- **Users with exact changes:** ${population.users_with_exact_changes ?? 0} (${percentages.members_with_exact_changes ?? 0}%)`,
            `- **Users requiring manual review:** ${population.users_requiring_manual_review ?? 0} (${percentages.members_requiring_manual_review ?? 0}%)`,
            '',
            '### Majority issue',
            `- ${majorityText}`,
            '',
            'Ask me: **Show summary statistics**, **What is the majority issue?**, **Which source has the most missing records?**, **Show Judge outcomes**, or **Which users have exact changes?**'
        ].join('\n');
        addChatMessage('assistant', message, { intent: 'batch_completed' });
        RUSNotifications?.add({
            title: 'Bulk analysis completed',
            message: `${summary.batch_id || agenticState.activeJobId} · ${processing.completed_count ?? 0} completed · ${processing.failed_count ?? 0} failed`,
            type: 'success', category: 'batch', link: 'ai-analysis.html'
        });
        agenticState.batchCompletionAnnounced = true;
    }
}

async function loadBatchSummary(jobId, { announce = false, makeActive = true } = {}) {
    try {
        const response = await agenticAiApi.getBatchSummary(jobId);
        const summary = envelopeData(response);
        renderBatchSummary(summary, { announce, makeActive });
        return summary;
    } catch (error) {
        showToast(error.message, true);
        return null;
    }
}

async function loadCatalog() {
    setLoader(true, 'Loading API knowledge catalog…');
    try {
        const response = await agenticAiApi.getCatalog();
        const data = envelopeData(response);
        const summary = data.summary || {};
        agenticState.catalogOperations = data.operations || [];
        byId('catalogSummary').innerHTML = `<div class="mini-kpi-grid">
            <div class="mini-kpi"><span>Operations</span><strong>${escapeHtml(summary.operation_count ?? agenticState.catalogOperations.length)}</strong></div>
            <div class="mini-kpi"><span>Read</span><strong>${escapeHtml(summary.read_operation_count ?? 0)}</strong></div>
            <div class="mini-kpi"><span>Write gated</span><strong>${escapeHtml(summary.write_operation_count ?? 0)}</strong></div>
            <div class="mini-kpi"><span>Live</span><strong>${escapeHtml(summary.live_operation_count ?? 0)}</strong></div>
        </div>`;
        byId('catalogTable').innerHTML = `<table class="agentic-table"><thead><tr><th>Operation ID</th><th>System</th><th>Method</th><th>Path</th><th>Status</th><th>Risk</th></tr></thead><tbody>${agenticState.catalogOperations.map((item) => `<tr>
            <td>${escapeHtml(item.operation_id)}</td><td>${escapeHtml(item.system)}</td><td>${escapeHtml(item.method)}</td><td>${escapeHtml(item.path)}</td><td>${escapeHtml(item.status)}</td><td>${escapeHtml(item.risk)}</td>
        </tr>`).join('')}</tbody></table>`;
        byId('operationSelect').innerHTML = '<option value="">Select an operation</option>' + agenticState.catalogOperations.map((item) => `<option value="${escapeHtml(item.operation_id)}">${escapeHtml(item.operation_id)}</option>`).join('');
    } catch (error) {
        showToast(error.message, true);
    } finally {
        setLoader(false);
    }
}

async function loadOperation() {
    const operationId = byId('operationSelect').value;
    if (!operationId) return;
    try {
        const response = await agenticAiApi.getOperation(operationId);
        byId('operationContract').textContent = JSON.stringify(envelopeData(response), null, 2);
    } catch (error) {
        showToast(error.message, true);
    }
}

async function validatePayload() {
    const operationId = byId('operationSelect').value;
    if (!operationId) {
        showToast('Select an operation.', true);
        return;
    }
    try {
        const payload = JSON.parse(byId('payloadEditor').value || '{}');
        const response = await agenticAiApi.validatePayload(operationId, payload);
        byId('payloadValidationResult').textContent = JSON.stringify(envelopeData(response), null, 2);
    } catch (error) {
        showToast(error instanceof SyntaxError ? 'Payload is not valid JSON.' : error.message, true);
    }
}

function activateTab(tabId) {
    document.querySelectorAll('.agentic-tab').forEach((button) => button.classList.toggle('active', button.dataset.tab === tabId));
    document.querySelectorAll('.agentic-tab-panel').forEach((panel) => panel.classList.toggle('active', panel.id === tabId));
    RUSWorkspace?.setSection('activeAgenticTab', tabId);
}

function bindEvents() {
    document.querySelectorAll('.agentic-tab').forEach((button) => button.addEventListener('click', () => activateTab(button.dataset.tab)));
    document.querySelectorAll('[data-open-audit]').forEach((link) => link.addEventListener('click', (event) => {
        event.preventDefault();
        activateTab('auditTab');
        byId('agenticAuditTrail')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }));
    byId('analyzeButton').addEventListener('click', analyzeData);
    byId('searchValue').addEventListener('keydown', (event) => { if (event.key === 'Enter') analyzeData(); });
    byId('sendChatButton').addEventListener('click', submitSmartInput);
    byId('chatMessages').addEventListener('click', (event) => {
        const popupButton = event.target.closest('.source-change-popup-action');
        if (popupButton) {
            openSourceApprovalPopup(popupButton.dataset.changeId);
            return;
        }
        const button = event.target.closest('.source-change-chat-action');
        if (!button) return;
        const message = button.dataset.message;
        if (message) sendChat('auto', message);
    });
    byId('closeSourceApprovalDialog')?.addEventListener('click', closeSourceApprovalPopup);
    byId('cancelSourceApprovalButton')?.addEventListener('click', closeSourceApprovalPopup);
    byId('confirmSourceApprovalButton')?.addEventListener('click', confirmSourceApprovalPopup);
    byId('sourceApprovalForm')?.addEventListener('submit', (event) => event.preventDefault());
    byId('sourceApprovalDialog')?.addEventListener('cancel', (event) => {
        event.preventDefault();
        closeSourceApprovalPopup();
    });
    ['sourceApprovalReviewAck', 'sourceApprovalAuditAck'].forEach((id) => byId(id)?.addEventListener('change', updateSourceApprovalButton));
    byId('sourceApprovalPhrase')?.addEventListener('input', updateSourceApprovalButton);
    byId('sourceApprovalDialog')?.addEventListener('cancel', (event) => {
        event.preventDefault();
        closeSourceApprovalPopup();
    });
    byId('chatInput').addEventListener('input', updateSmartIntakePreview);
    byId('chatInput').addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            submitSmartInput();
        }
    });
    byId('attachChatFileButton').addEventListener('click', () => byId('chatFileInput').click());
    byId('chatFileInput').addEventListener('change', (event) => attachSmartInputFile(event.target.files?.[0]));
    byId('removeChatFileButton').addEventListener('click', clearSmartInputFile);
    byId('intakeModeSelect').addEventListener('change', (event) => {
        agenticState.intakeMode = event.target.value || 'auto';
        updateSmartIntakePreview();
    });
    const dropZone = byId('intakeDropZone');
    ['dragenter', 'dragover'].forEach((name) => dropZone.addEventListener(name, (event) => {
        event.preventDefault();
        dropZone.classList.add('drag-active');
    }));
    ['dragleave', 'drop'].forEach((name) => dropZone.addEventListener(name, (event) => {
        event.preventDefault();
        dropZone.classList.remove('drag-active');
    }));
    dropZone.addEventListener('drop', (event) => attachSmartInputFile(event.dataTransfer?.files?.[0]));
    document.querySelectorAll('.chat-action').forEach((button) => button.addEventListener('click', () => sendChat(button.dataset.action, button.textContent.trim())));
    byId('chatContextSelect').addEventListener('change', (event) => setChatContextMode(event.target.value, { persist: true, announce: true }));
    byId('reportPrivacySelect').addEventListener('change', async (event) => {
        const wantsMasked = event.target.value === 'masked';
        await setReportPrivacy(wantsMasked, { persist: true, announce: true });
    });
    byId('resetSessionButton').addEventListener('click', resetSession);
    byId('newSessionButton').addEventListener('click', createNewSession);
    byId('deepHealthButton').addEventListener('click', runDeepHealth);
    byId('loadUseCasesButton').addEventListener('click', loadUseCases);
    byId('startBatchButton').addEventListener('click', startBatch);
    byId('loadCatalogButton').addEventListener('click', loadCatalog);
    byId('loadOperationButton').addEventListener('click', loadOperation);
    byId('validatePayloadButton').addEventListener('click', validatePayload);
}


async function applyAgenticRoleView() {
    await window.RUSAuth?.ready;
    const user = window.RUSAuth?.getUser?.();
    const permissions = user?.viewProfile?.permissions || {};
    const role = String(user?.role || 'Customer').toLowerCase();
    agenticState.currentRole = role;
    const privacy = byId('reportPrivacySelect');
    const control = document.querySelector('[data-report-privacy-control]');
    const unmaskedOption = privacy?.querySelector('option[value="unmasked"]');

    if (!permissions.viewUnmaskedReports) {
        agenticState.reportMasked = true;
        sessionStorage.setItem(REPORT_MASKED_KEY, 'true');
        window.RUSWorkspace?.setShared(REPORT_MASKED_KEY, 'true');
        if (privacy) { privacy.value = 'masked'; privacy.disabled = true; }
        if (unmaskedOption) unmaskedOption.hidden = true;
        if (control) control.title = 'Customer Support reports are always masked by policy.';
    } else {
        if (unmaskedOption) unmaskedOption.hidden = false;
        if (privacy) privacy.disabled = permissions.selectReportPrivacy === false;
        if (role === 'business') {
            agenticState.reportMasked = false;
            sessionStorage.setItem(REPORT_MASKED_KEY, 'false');
            window.RUSWorkspace?.setShared(REPORT_MASKED_KEY, 'false');
            if (privacy) privacy.value = 'unmasked';
        }
    }
    const managedProfile = byId('managedBatchExecutionProfile');
    const adminSettings = byId('adminBatchSettings');
    if (managedProfile) managedProfile.classList.toggle('hidden', role === 'admin');
    if (adminSettings) adminSettings.classList.toggle('hidden', role !== 'admin');
    refreshReportDownloadLinks();
}

document.addEventListener('DOMContentLoaded', async () => {
    await applyAgenticRoleView();
    bindEvents();
    refreshReportDownloadLinks();
    const savedTab = isFocusedAgenticRole() ? 'chatTab' : (RUSWorkspace?.getSection('activeAgenticTab', 'chatTab') || 'chatTab');
    activateTab(savedTab);
    window.RUSRoleFocusedViews?.forceBusinessBatchDefaults?.();
    const globalPrefill = sessionStorage.getItem('rus.agentic.prefill');
    if (globalPrefill && byId('chatInput')) {
        byId('chatInput').value = globalPrefill;
        sessionStorage.removeItem('rus.agentic.prefill');
    }
    updateSmartIntakePreview();
    await bootstrapSession(false);
    updateSmartIntakePreview();
});

'use strict';

(function () {
    const page = document.body?.dataset?.page || 'dashboard';

    function actorContext() {
        const authenticated = window.RUSAuth?.getUser?.();
        const storedName = (() => { try { return localStorage.getItem('rus.actor.name'); } catch { return null; } })();
        const storedEmail = (() => { try { return localStorage.getItem('rus.actor.email'); } catch { return null; } })();
        return {
            name: authenticated?.username || storedName || 'Unknown user',
            email: authenticated?.email || storedEmail || '',
            channel: page === 'ai-analysis' ? 'agentic-ai-ui' : 'manual-ui'
        };
    }

    function installAuditHeaders() {
        if (window.__rusAuditFetchInstalled) return;
        window.__rusAuditFetchInstalled = true;
        const nativeFetch = window.fetch.bind(window);
        window.fetch = (input, init = {}) => {
            const url = typeof input === 'string' ? input : input?.url || '';
            const sameOrigin = url.startsWith('/') || !/^https?:/i.test(url) || url.startsWith(window.location.origin);
            if (!sameOrigin) return nativeFetch(input, init);
            const actor = actorContext();
            const headers = new Headers(init.headers || (typeof input !== 'string' ? input.headers : undefined) || {});
            if (!headers.has('X-RUS-Actor')) headers.set('X-RUS-Actor', actor.name);
            if (actor.email && !headers.has('X-RUS-Actor-Email')) headers.set('X-RUS-Actor-Email', actor.email);
            if (!headers.has('X-RUS-Channel')) headers.set('X-RUS-Channel', actor.channel);
            return nativeFetch(input, { ...init, headers });
        };
        window.RUSAuditActor = actorContext;
    }

    installAuditHeaders();

    function hasPermission(user, name) {
        return Boolean(user?.viewProfile?.permissions?.[name]);
    }

    const pagePermission = {
        dashboard: 'viewDashboard',
        'ai-analysis': 'useAgenticAnalysis',
        cps: 'viewCpsPage',
        members: 'viewRewardsPage',
        crowdtwist: 'viewCrowdTwistPage',
        search: 'viewUnifiedSearchPage',
        'admin-users': 'manageUsers'
    };

    function roleCopy(user) {
        const role = String(user?.role || 'Customer').toLowerCase();
        if (role === 'admin') return 'Full governance, all-user audits, technical operations, and access administration.';
        if (role === 'technical') return 'Full technical source operations. Explicit Agentic update commands execute governed, verified writes.';
        if (role === 'business') return 'Business Dashboard and Agentic AI view. Manual source pages remain available and unchanged.';
        return 'Customer Support Dashboard and Agentic AI view. Manual source pages remain available and unchanged.';
    }

    function applyRoleView(user) {
        if (!user) return;
        const role = String(user.role || 'Customer');
        const profile = user.viewProfile || {};
        document.body.dataset.authRole = role;
        document.body.dataset.roleProfile = profile.dashboardMode || role.toLowerCase();
        document.body.classList.remove('role-customer', 'role-business', 'role-technical', 'role-admin');
        document.body.classList.add(`role-${role.toLowerCase()}`);

        document.querySelectorAll('[data-permission]').forEach(node => {
            const names = String(node.dataset.permission || '').split(',').map(value => value.trim()).filter(Boolean);
            const allowed = names.length === 0 || names.some(name => hasPermission(user, name));
            node.classList.toggle('hidden', !allowed);
            node.setAttribute('aria-hidden', String(!allowed));
        });

        const required = pagePermission[page];
        if (required && !hasPermission(user, required)) {
            window.location.replace(`/rus-app.html?accessDenied=role&requested=${encodeURIComponent(window.location.pathname)}`);
            return;
        }

        const footer = document.querySelector('[data-role-footer-copy]');
        if (footer) footer.textContent = roleCopy(user);
        const badge = document.querySelector('[data-role-profile-label]');
        if (badge) badge.textContent = profile.label || role;

        // CPS, Rewards DB, CrowdTwist and Unified Search remain identical for every role.
        // Dashboard role profiles progressively disclose operational detail.
        if (page === 'dashboard') {
            const title = document.querySelector('.dashboard-command-copy h2');
            const text = document.querySelector('.dashboard-command-copy p');
            const eyebrow = document.querySelector('.dashboard-command-copy .eyebrow');
            if (role.toLowerCase() === 'customer') {
                if (eyebrow) eyebrow.textContent = 'Customer support';
                if (title) title.textContent = 'Customer support overview';
                if (text) text.textContent = 'Search customer records, run guided analysis, and review your activity.';
            } else if (role.toLowerCase() === 'business') {
                if (eyebrow) eyebrow.textContent = 'Business operations';
                if (title) title.textContent = 'Data quality overview';
                if (text) text.textContent = 'Review data quality, suggested corrections, and approved changes.';
            } else if (role.toLowerCase() === 'technical') {
                if (eyebrow) eyebrow.textContent = 'Technical operations';
                if (title) title.textContent = 'Operations overview';
                if (text) text.textContent = 'Monitor services, use source tools, and govern Agentic changes.';
            } else {
                if (eyebrow) eyebrow.textContent = 'Administration';
                if (title) title.textContent = 'Operations overview';
                if (text) text.textContent = 'Monitor operations, users, audit activity, and governed changes.';
            }
            document.querySelectorAll('[data-dashboard-technical]').forEach(node => node.classList.toggle('hidden', !hasPermission(user, 'viewTechnicalDetails')));
            document.querySelectorAll('[data-dashboard-admin]').forEach(node => node.classList.toggle('hidden', !hasPermission(user, 'manageUsers')));
            document.querySelectorAll('[data-dashboard-business]').forEach(node => node.classList.toggle('hidden', role.toLowerCase() === 'customer'));
        }

        if (page === 'ai-analysis') {
            const batchButton = document.querySelector('[data-tab="batchTab"]');
            const batchPanel = document.getElementById('batchTab');
            const knowledgeButton = document.querySelector('[data-tab="knowledgeTab"]');
            const knowledgePanel = document.getElementById('knowledgeTab');
            batchButton?.classList.toggle('hidden', !hasPermission(user, 'useBatchAnalysis'));
            batchPanel?.classList.toggle('role-hidden', !hasPermission(user, 'useBatchAnalysis'));
            knowledgeButton?.classList.toggle('hidden', !hasPermission(user, 'useApiKnowledge'));
            knowledgePanel?.classList.toggle('role-hidden', !hasPermission(user, 'useApiKnowledge'));
            document.querySelectorAll('[data-agentic-write-ui]').forEach(node => node.classList.toggle('hidden', !hasPermission(user, 'planAgenticUpdates')));
            document.querySelector('.agentic-approval-flow')?.classList.toggle('hidden', !hasPermission(user, 'planAgenticUpdates'));
            document.querySelector('#sourceApprovalDialog')?.classList.toggle('role-hidden', !hasPermission(user, 'approveAgenticUpdates'));
            const intakeMode = document.getElementById('intakeModeSelect');
            const batchOption = intakeMode?.querySelector('option[value="batch"]');
            if (batchOption) batchOption.hidden = !hasPermission(user, 'useBatchAnalysis');
            if (!hasPermission(user, 'useBatchAnalysis') && intakeMode?.value === 'batch') intakeMode.value = 'auto';
            const contextSelect = document.getElementById('chatContextSelect');
            const batchContext = contextSelect?.querySelector('option[value="batch"]');
            if (batchContext) batchContext.hidden = !hasPermission(user, 'useBatchAnalysis');
            if (!hasPermission(user, 'useBatchAnalysis') && contextSelect?.value === 'batch') contextSelect.value = 'individual';
            const heroEyebrow = document.querySelector('.agentic-hero-copy .eyebrow');
            if (!hasPermission(user, 'viewTechnicalDetails') && heroEyebrow) heroEyebrow.textContent = role === 'Business' ? 'Business data quality assistant' : 'Customer support data assistant';
        }
    }

    function renderAccount(user) {
        if (!user) return;
        document.querySelectorAll('[data-auth-display-name]').forEach(node => { node.textContent = user.displayName || user.username || 'Signed-in user'; });
        document.querySelectorAll('[data-auth-username]').forEach(node => { node.textContent = user.username || ''; });
        document.querySelectorAll('[data-auth-role-label]').forEach(node => { node.textContent = user.role || ''; });
        document.querySelectorAll('[data-auth-initials]').forEach(node => {
            const text = user.displayName || user.username || 'U';
            node.textContent = text.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toUpperCase();
            node.title = `${user.displayName || user.username || 'Signed-in user'} · ${user.role || ''}`;
        });
        const account = document.querySelector('.sidebar-account');
        if (account) account.title = `${user.displayName || user.username || 'Signed-in user'} · ${user.role || ''}`;
        document.body.dataset.authRole = user.role || 'Customer';
        document.querySelectorAll('[data-admin-only]').forEach(node => node.classList.toggle('hidden', !hasPermission(user, 'manageUsers')));
        document.querySelectorAll('[data-user-only]').forEach(node => node.classList.toggle('hidden', hasPermission(user, 'manageUsers')));
        applyRoleView(user);
        try {
            localStorage.setItem('rus.actor.name', user.username || user.displayName || 'Unknown user');
            if (user.email) localStorage.setItem('rus.actor.email', user.email);
            else localStorage.removeItem('rus.actor.email');
        } catch { }
    }

    async function hydrateAccount() {
        try {
            if (!window.RUSAuth?.ready) return null;
            await window.RUSAuth.ready;
            const user = window.RUSAuth.getUser?.();
            if (user) renderAccount(user);
            else {
                const state = window.RUSAuth.getState?.();
                const accountName = document.querySelector('[data-auth-display-name]');
                if (accountName && (state === 'reconnecting' || state === 'degraded')) {
                    accountName.textContent = 'Reconnecting session…';
                }
            }
            return user || null;
        } catch {
            // auth.js is the only component permitted to redirect. Keeping one owner
            // prevents competing login/dashboard navigations.
            return window.RUSAuth?.getUser?.() || null;
        }
    }

    async function logout() {
        if (window.RUSAuth?.logout) return window.RUSAuth.logout();
        try {
            await fetch('/api/auth/logout', {
                method: 'POST', credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json', 'X-RUS-Channel': 'login-ui' }, body: '{}'
            });
        } catch { }
        try {
            [...Object.keys(sessionStorage)].filter(key => key.startsWith('rus.')).forEach(key => sessionStorage.removeItem(key));
            [...Object.keys(localStorage)].filter(key => key.startsWith('rus.agentic.') || key.startsWith('rus.workspace.') || key.startsWith('rus.actor.')).forEach(key => localStorage.removeItem(key));
        } catch { }
        window.location.replace('/login.html');
    }


    function setPasswordMessage(message, isError = false) {
        const node = document.querySelector('[data-auth-password-message]');
        if (!node) return;
        node.textContent = message || '';
        node.classList.toggle('hidden', !message);
        node.classList.toggle('error', Boolean(isError));
        node.classList.toggle('success', Boolean(message) && !isError);
    }

    async function changePassword(currentPassword, newPassword) {
        if (window.RUSAuth?.changePassword) {
            await window.RUSAuth.changePassword(currentPassword, newPassword);
            return;
        }
        const response = await fetch('/api/auth/change-password', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-RUS-Channel': 'account-ui' },
            body: JSON.stringify({ currentPassword, newPassword })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(payload?.error?.message || payload?.message || `HTTP ${response.status}`);
        const user = (payload?.data ?? payload)?.user;
        if (user) renderAccount(user);
    }

    function installPasswordDialog() {
        const dialog = document.querySelector('[data-auth-password-dialog]');
        const form = document.querySelector('[data-auth-password-form]');
        const openButton = document.querySelector('[data-auth-password]');
        const close = () => {
            form?.reset();
            setPasswordMessage('');
            if (dialog?.open) dialog.close();
        };
        openButton?.addEventListener('click', () => {
            setPasswordMessage('');
            dialog?.showModal();
            dialog?.querySelector('input[name="currentPassword"]')?.focus();
        });
        document.querySelector('[data-auth-password-close]')?.addEventListener('click', close);
        document.querySelector('[data-auth-password-cancel]')?.addEventListener('click', close);
        dialog?.addEventListener('click', event => {
            if (event.target === dialog) close();
        });
        form?.addEventListener('submit', async event => {
            event.preventDefault();
            const data = new FormData(form);
            const currentPassword = String(data.get('currentPassword') || '');
            const newPassword = String(data.get('newPassword') || '');
            const confirmPassword = String(data.get('confirmPassword') || '');
            if (newPassword.length < 10) return setPasswordMessage('The new password must contain at least 10 characters.', true);
            if (newPassword !== confirmPassword) return setPasswordMessage('The new password and confirmation do not match.', true);
            const submit = document.querySelector('[data-auth-password-submit]');
            if (submit) { submit.disabled = true; submit.textContent = 'Updating…'; }
            try {
                await changePassword(currentPassword, newPassword);
                setPasswordMessage('Password changed successfully. Your JWT session was refreshed.');
                form.reset();
                setTimeout(close, 1200);
            } catch (error) {
                setPasswordMessage(error?.message || 'Password change failed.', true);
            } finally {
                if (submit) { submit.disabled = false; submit.textContent = 'Change password'; }
            }
        });
    }

    const navigation = `
        <aside class="sidebar app-sidebar" aria-label="Primary navigation">
            <div class="sidebar-header brand-lockup">
                <div class="brand-mark" aria-hidden="true"><svg viewBox="0 0 48 48" focusable="false"><g fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.2 14.4 22 21.2M33.8 14.4 26 21.2M17 34.2l5.4-7.5M31 34.2l-5.4-7.5" opacity=".86"/><circle cx="12" cy="12" r="4.5"/><circle cx="36" cy="12" r="4.5"/><circle cx="14" cy="36" r="4.5"/><circle cx="34" cy="36" r="4.5"/><path d="m24 17.2 6.8 6.8-6.8 6.8-6.8-6.8Z" fill="currentColor" fill-opacity=".18"/><path d="m21.2 24 1.9 1.9 4-4" stroke-width="2.8"/></g></svg></div>
                <div class="brand-copy"><h2>Rewards Utility</h2><small>Connected operations workspace</small></div>
            </div>
            <nav class="sidebar-nav">
                <div class="nav-section-label">Workspace</div>
                <a href="/rus-app.html" class="nav-link" data-page="dashboard" data-permission="viewDashboard"><span class="nav-icon">⌂</span><span class="nav-copy">Dashboard<small>Operations overview</small></span></a>
                <a href="/ai-analysis.html" class="nav-link nav-link-featured" data-page="ai-analysis" data-permission="useAgenticAnalysis"><span class="nav-icon">✦</span><span class="nav-copy">Agentic AI<small>Governed analysis & updates</small></span></a>
                <div class="nav-section-label">Manual source operations</div>
                <a href="/cps.html" class="nav-link" data-page="cps" data-permission="viewCpsPage"><span class="nav-icon">◎</span><span class="nav-copy">CPS<small>Create & retrieve profiles</small></span></a>
                <a href="/members.html" class="nav-link" data-page="members" data-permission="viewRewardsPage"><span class="nav-icon">▦</span><span class="nav-copy">Rewards DB<small>Search & update members</small></span></a>
                <a href="/crowdtwist.html" class="nav-link" data-page="crowdtwist" data-permission="viewCrowdTwistPage"><span class="nav-icon">☁</span><span class="nav-copy">CrowdTwist<small>Loyalty profile operations</small></span></a>
                <a href="/search.html" class="nav-link" data-page="search" data-permission="viewUnifiedSearchPage"><span class="nav-icon">⌕</span><span class="nav-copy">Unified Search<small>Cross-system lookup</small></span></a>
                <div class="nav-section-label hidden" data-admin-only>Administration</div>
                <a href="/admin-users.html" class="nav-link hidden" data-page="admin-users" data-admin-only data-permission="manageUsers"><span class="nav-icon">♙</span><span class="nav-copy">User Administration<small>Delegate, prompt & remove</small></span></a>
            </nav>
            <div class="sidebar-footer">
                <div class="sidebar-account" aria-label="Signed-in user">
                    <span class="sidebar-account-avatar" data-auth-initials>U</span>
                    <div class="sidebar-account-copy"><strong data-auth-display-name>Signed-in user</strong><small><span data-auth-username></span> · <span data-auth-role-label></span></small></div>
                    <div class="sidebar-account-actions">
                        <button class="sidebar-password" type="button" data-auth-password title="Change password" aria-label="Change password">⌁</button>
                        <button class="sidebar-logout" type="button" data-auth-logout title="Sign out" aria-label="Sign out">↪</button>
                    </div>
                </div>
                <div class="shell-health" data-shared-agentic-health><span></span>Checking Agentic API…</div>
                <p data-role-footer-copy>Loading your role profile…</p><span class="sidebar-role-profile" data-role-profile-label></span>
            </div>
        </aside>
        <button class="sidebar-edge-toggle" type="button" data-shared-sidebar-toggle aria-label="Collapse navigation" aria-expanded="true">
            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="m10 3-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        <dialog class="auth-password-dialog" data-auth-password-dialog aria-labelledby="authPasswordTitle">
            <form method="dialog" class="auth-password-form" data-auth-password-form>
                <div class="auth-password-head"><div><span>Account security</span><h3 id="authPasswordTitle">Change password</h3><p>Update the password for <strong data-auth-username></strong>.</p></div><button type="button" data-auth-password-close aria-label="Close">×</button></div>
                <label><span>Current password</span><input name="currentPassword" type="password" autocomplete="current-password" required></label>
                <label><span>New password</span><input name="newPassword" type="password" autocomplete="new-password" minlength="10" required><small>Use at least 10 characters.</small></label>
                <label><span>Confirm new password</span><input name="confirmPassword" type="password" autocomplete="new-password" minlength="10" required></label>
                <div class="auth-password-message hidden" data-auth-password-message role="alert"></div>
                <div class="auth-password-actions"><button type="button" class="secondary" data-auth-password-cancel>Cancel</button><button type="submit" class="primary" data-auth-password-submit>Change password</button></div>
            </form>
        </dialog>`;

    function render() {
        const host = document.querySelector('[data-rus-sidebar]');
        if (!host) return;
        host.insertAdjacentHTML('afterend', navigation);
        host.remove();
        document.documentElement.dataset.rusShellReady = 'true';
        document.body.dataset.rusShellReady = 'true';

        document.querySelectorAll('.app-sidebar .nav-link').forEach((link) => {
            const active = link.dataset.page === page;
            link.classList.toggle('active', active);
            if (active) link.setAttribute('aria-current', 'page');
            link.addEventListener('click', () => document.body.classList.remove('sidebar-open'));
        });

        const toggle = document.querySelector('[data-shared-sidebar-toggle]');
        toggle?.addEventListener('click', () => {
            document.body.classList.toggle('sidebar-collapsed');
            const expanded = !document.body.classList.contains('sidebar-collapsed');
            toggle.setAttribute('aria-expanded', String(expanded));
            toggle.setAttribute('aria-label', expanded ? 'Collapse navigation' : 'Expand navigation');
            try { localStorage.setItem('rus.sidebar.collapsed', expanded ? 'false' : 'true'); } catch { }
        });

        try {
            if (localStorage.getItem('rus.sidebar.collapsed') === 'true' && window.innerWidth > 900) {
                document.body.classList.add('sidebar-collapsed');
                toggle?.setAttribute('aria-expanded', 'false');
                toggle?.setAttribute('aria-label', 'Expand navigation');
            }
        } catch { }

        let mobile = document.getElementById('mobileMenuButton');
        if (!mobile) {
            mobile = document.createElement('button');
            mobile.id = 'sharedMobileMenuButton';
            mobile.className = 'shared-mobile-menu';
            mobile.type = 'button';
            mobile.setAttribute('aria-label', 'Open navigation');
            mobile.textContent = '☰';
            document.body.appendChild(mobile);
        }
        mobile.addEventListener('click', () => document.body.classList.toggle('sidebar-open'));
        document.querySelector('[data-auth-logout]')?.addEventListener('click', logout);
        installPasswordDialog();
        hydrateAccount();
        checkHealth();
    }

    async function checkHealth() {
        const node = document.querySelector('[data-shared-agentic-health]');
        if (!node) return;
        try {
            const response = await fetch('/api/agentic-ai/health/live', { cache: 'no-store' });
            const payload = await response.json().catch(() => ({}));
            const online = response.ok && payload?.success !== false;
            node.className = `shell-health ${online ? 'online' : 'offline'}`;
            node.innerHTML = `<span></span>${online ? 'Agentic API online' : 'Agentic API unavailable'}`;
        } catch {
            node.className = 'shell-health offline';
            node.innerHTML = '<span></span>Agentic API unavailable';
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', render);
    else render();
})();

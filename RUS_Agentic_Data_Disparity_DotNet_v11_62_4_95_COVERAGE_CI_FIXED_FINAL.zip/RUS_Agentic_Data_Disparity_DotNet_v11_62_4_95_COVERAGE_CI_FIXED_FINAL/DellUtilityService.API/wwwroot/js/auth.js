'use strict';

(function () {
    const TOKEN_KEY = 'rus.auth.accessToken';
    const USER_KEY = 'rus.auth.user';
    const STATE_KEY = 'rus.auth.bootstrapState';
    const nativeFetch = window.fetch.bind(window);
    let currentUser = null;
    let currentToken = null;
    let redirecting = false;
    let bootstrapState = 'starting';
    let retryTimer = null;

    class AuthenticationError extends Error {
        constructor(message, status = 401) {
            super(message);
            this.name = 'AuthenticationError';
            this.status = status;
            this.definitive = true;
        }
    }

    class AuthenticationTransportError extends Error {
        constructor(message, cause = null) {
            super(message);
            this.name = 'AuthenticationTransportError';
            this.cause = cause;
            this.definitive = false;
        }
    }

    function readSession() {
        try {
            currentToken = sessionStorage.getItem(TOKEN_KEY);
            const raw = sessionStorage.getItem(USER_KEY);
            currentUser = raw ? JSON.parse(raw) : null;
            bootstrapState = sessionStorage.getItem(STATE_KEY) || 'starting';
        } catch {
            currentToken = null;
            currentUser = null;
            bootstrapState = 'starting';
        }
    }

    function clearUserScopedState() {
        try {
            [...Object.keys(sessionStorage)]
                .filter(key => key.startsWith('rus.agentic.') || key.startsWith('rus.workspace.'))
                .forEach(key => sessionStorage.removeItem(key));
            [...Object.keys(localStorage)]
                .filter(key => key.startsWith('rus.agentic.') || key.startsWith('rus.workspace.'))
                .forEach(key => localStorage.removeItem(key));
        } catch { }
    }

    function setBootstrapState(state) {
        bootstrapState = state;
        try { sessionStorage.setItem(STATE_KEY, state); } catch { }
        document.documentElement.dataset.authState = state;
        window.dispatchEvent(new CustomEvent('rus:auth-state', { detail: state }));
    }

    function saveSession(data) {
        const nextUser = data?.user || null;
        try {
            const previous = localStorage.getItem('rus.auth.lastUsername');
            if (previous && nextUser?.username && previous.toLowerCase() !== nextUser.username.toLowerCase()) {
                clearUserScopedState();
            }
            if (nextUser?.username) localStorage.setItem('rus.auth.lastUsername', nextUser.username);
        } catch { }

        currentToken = data?.accessToken || currentToken || null;
        currentUser = nextUser || currentUser || null;
        try {
            if (currentToken) sessionStorage.setItem(TOKEN_KEY, currentToken);
            else sessionStorage.removeItem(TOKEN_KEY);
            if (currentUser) sessionStorage.setItem(USER_KEY, JSON.stringify(currentUser));
            else sessionStorage.removeItem(USER_KEY);
            if (currentUser?.username) localStorage.setItem('rus.actor.name', currentUser.username);
            if (currentUser?.email) localStorage.setItem('rus.actor.email', currentUser.email);
            else localStorage.removeItem('rus.actor.email');
        } catch { }
        setBootstrapState('authenticated');
        window.dispatchEvent(new CustomEvent('rus:auth-changed', { detail: currentUser }));
    }

    function clearSession({ clearScopedState = true } = {}) {
        currentToken = null;
        currentUser = null;
        if (clearScopedState) clearUserScopedState();
        try {
            sessionStorage.removeItem(TOKEN_KEY);
            sessionStorage.removeItem(USER_KEY);
            sessionStorage.removeItem(STATE_KEY);
            localStorage.removeItem('rus.actor.name');
            localStorage.removeItem('rus.actor.email');
        } catch { }
        setBootstrapState('anonymous');
        window.dispatchEvent(new CustomEvent('rus:auth-changed', { detail: null }));
    }

    function loginUrl() {
        const returnUrl = `${window.location.pathname}${window.location.search}${window.location.hash}`;
        return `/login.html?returnUrl=${encodeURIComponent(returnUrl)}`;
    }

    function redirectToLogin(reason = 'session-expired') {
        if (redirecting || window.location.pathname.endsWith('/login.html')) return;
        redirecting = true;
        try { sessionStorage.setItem('rus.auth.redirectingToLogin', String(Date.now())); } catch { }
        clearSession({ clearScopedState: false });
        const separator = loginUrl().includes('?') ? '&' : '?';
        window.location.replace(`${loginUrl()}${separator}reason=${encodeURIComponent(reason)}`);
    }

    function sameOriginUrl(input) {
        try {
            const raw = typeof input === 'string' ? input : input?.url;
            if (!raw) return null;
            return new URL(raw, window.location.origin);
        } catch {
            return null;
        }
    }

    function authHeaders(source = {}) {
        const headers = new Headers(source || {});
        if (currentToken) headers.set('Authorization', `Bearer ${currentToken}`);
        headers.set('X-RUS-Channel', headers.get('X-RUS-Channel') || 'auth-bootstrap');
        return headers;
    }

    async function requestCurrentSession({ timeoutMs = 8000 } = {}) {
        const controller = new AbortController();
        const timer = window.setTimeout(() => controller.abort(), timeoutMs);
        try {
            const response = await nativeFetch('/api/auth/me', {
                method: 'GET',
                credentials: 'same-origin',
                cache: 'no-store',
                headers: authHeaders({ 'Accept': 'application/json' }),
                signal: controller.signal
            });
            if (response.status === 401 || response.status === 403) {
                throw new AuthenticationError('Authentication session expired.', response.status);
            }
            if (!response.ok) {
                throw new AuthenticationTransportError(`Authentication service returned HTTP ${response.status}.`);
            }
            const payload = await response.json();
            const data = payload?.data ?? payload;
            if (!data?.user) {
                throw new AuthenticationTransportError('Authentication response did not contain a user profile.');
            }
            saveSession(data);
            return currentUser;
        } catch (error) {
            if (error?.definitive) throw error;
            if (error?.name === 'AbortError') {
                throw new AuthenticationTransportError('Authentication check timed out.', error);
            }
            if (error instanceof AuthenticationTransportError) throw error;
            throw new AuthenticationTransportError(error?.message || 'Authentication service unavailable.', error);
        } finally {
            window.clearTimeout(timer);
        }
    }

    function scheduleSessionRetry() {
        if (retryTimer || redirecting) return;
        retryTimer = window.setTimeout(async () => {
            retryTimer = null;
            try {
                await requestCurrentSession({ timeoutMs: 12000 });
            } catch (error) {
                if (error?.definitive) redirectToLogin('session-expired');
                else scheduleSessionRetry();
            }
        }, 2500);
    }

    readSession();
    document.documentElement.dataset.authState = bootstrapState;

    const ready = (async () => {
        if (window.location.pathname.endsWith('/login.html') || window.location.pathname.endsWith('/register.html')) {
            return currentUser;
        }

        // v11.31: login already verifies the JWT before navigation. Re-use that verified
        // browser session immediately so Dashboard/Agentic AI renders instead of hiding
        // the whole application while /api/auth/me is called a second time.
        if (currentToken && currentUser) {
            setBootstrapState('authenticated');
            requestCurrentSession({ timeoutMs: 12000 }).catch((error) => {
                if (error?.definitive) {
                    redirectToLogin('session-expired');
                    return;
                }
                setBootstrapState('degraded');
                scheduleSessionRetry();
            });
            return currentUser;
        }

        setBootstrapState('checking');
        try {
            return await requestCurrentSession();
        } catch (error) {
            if (error?.definitive) {
                redirectToLogin('session-expired');
                return null;
            }

            // No cached user is available. Keep a visible shell with a reconnecting state;
            // APIs remain authorization protected and auth.js remains the only redirect owner.
            setBootstrapState('reconnecting');
            scheduleSessionRetry();
            return null;
        }
    })();

    window.fetch = async function authenticatedFetch(input, init = {}) {
        const url = sameOriginUrl(input);
        const isSameOrigin = url?.origin === window.location.origin;
        const isApi = isSameOrigin && url.pathname.startsWith('/api/');
        const authBypass = isApi && (
            url.pathname === '/api/auth/login' ||
            url.pathname === '/api/auth/register' ||
            url.pathname === '/api/auth/reset-session' ||
            url.pathname === '/api/auth/me'
        );

        if (!isApi || authBypass) {
            return nativeFetch(input, { ...init, credentials: isSameOrigin ? 'same-origin' : init.credentials });
        }

        await ready;
        const sourceHeaders = init.headers || (typeof input !== 'string' ? input.headers : undefined) || {};
        const headers = new Headers(sourceHeaders);
        if (currentToken) headers.set('Authorization', `Bearer ${currentToken}`);
        if (currentUser?.username) headers.set('X-RUS-Authenticated-User', currentUser.username);

        const response = await nativeFetch(input, {
            ...init,
            credentials: 'same-origin',
            headers
        });

        if (response.status === 401 || response.status === 403) {
            redirectToLogin(response.status === 403 ? 'access-denied' : 'session-expired');
        }
        return response;
    };

    async function logout() {
        try {
            await ready;
            const headers = authHeaders({ 'Content-Type': 'application/json', 'X-RUS-Channel': 'login-ui' });
            await nativeFetch('/api/auth/logout', {
                method: 'POST', credentials: 'same-origin', headers, body: '{}'
            });
        } catch { }
        clearSession();
        window.location.replace('/login.html?reason=logged-out');
    }

    async function changePassword(currentPassword, newPassword) {
        await ready;
        const response = await window.fetch('/api/auth/change-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ currentPassword, newPassword })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(payload?.error?.message || payload?.message || `HTTP ${response.status}`);
        saveSession(payload?.data ?? payload);
        return currentUser;
    }

    function permissionValue(name) {
        const permissions = currentUser?.viewProfile?.permissions || {};
        return Boolean(permissions[name]);
    }

    function decorateUserUi() {
        const user = currentUser;
        if (!user) return;
        const role = String(user.role || 'Customer');
        document.body.dataset.authRole = role;
        document.body.dataset.roleProfile = user.viewProfile?.dashboardMode || role.toLowerCase();
        document.querySelectorAll('[data-permission]').forEach(node => {
            const required = String(node.dataset.permission || '').split(',').map(item => item.trim()).filter(Boolean);
            const allowed = required.length === 0 || required.some(permissionValue);
            node.classList.toggle('hidden', !allowed);
            node.setAttribute('aria-hidden', String(!allowed));
        });
        document.querySelectorAll('[data-role-only]').forEach(node => {
            const roles = String(node.dataset.roleOnly || '').split(',').map(item => item.trim().toLowerCase());
            node.classList.toggle('hidden', !roles.includes(role.toLowerCase()));
        });
        document.querySelectorAll('[data-auth-display-name]').forEach(node => {
            node.textContent = user.displayName || user.username;
        });
        document.querySelectorAll('[data-auth-username]').forEach(node => {
            node.textContent = user.username || '';
        });
        document.querySelectorAll('[data-auth-role-label]').forEach(node => {
            node.textContent = user.role || '';
        });
        document.querySelectorAll('[data-auth-initials]').forEach(node => {
            const text = user.displayName || user.username || 'U';
            node.textContent = text.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toUpperCase();
        });
    }

    window.addEventListener('rus:auth-changed', decorateUserUi);
    document.addEventListener('DOMContentLoaded', async () => {
        await ready;
        decorateUserUi();
    });

    window.RUSAuth = {
        ready,
        getUser: () => currentUser,
        getToken: () => currentToken,
        getState: () => bootstrapState,
        logout,
        changePassword,
        restoreFromCookie: requestCurrentSession,
        refresh: requestCurrentSession,
        isAdmin: () => String(currentUser?.role || '').toLowerCase() === 'admin',
        isRole: role => String(currentUser?.role || '').toLowerCase() === String(role || '').toLowerCase(),
        hasPermission: name => permissionValue(name),
        getViewProfile: () => currentUser?.viewProfile || null
    };
})();

'use strict';

(function () {
    const byId = (id) => document.getElementById(id);
    const escapeHtml = (value) => String(value ?? '')
        .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;').replaceAll("'", '&#039;');

    function currentPage() {
        return document.body?.dataset?.page || 'dashboard';
    }

    function setNavigation() {
        document.querySelectorAll('.nav-link').forEach((link) => {
            link.classList.toggle('active', link.dataset.page === currentPage());
        });
    }

    function ensureOverlays() {
        if (!byId('rusNotificationDrawer')) {
            document.body.insertAdjacentHTML('beforeend', `
                <div id="rusDrawerBackdrop" class="drawer-backdrop hidden"></div>
                <aside id="rusNotificationDrawer" class="notification-drawer" aria-hidden="true">
                    <div class="drawer-header">
                        <div><span class="eyebrow">Activity</span><h2>Notifications</h2></div>
                        <button id="closeNotificationDrawer" class="icon-button" aria-label="Close notifications">×</button>
                    </div>
                    <div class="drawer-actions">
                        <button id="enableSystemNotifications" class="btn btn-secondary btn-sm">Enable desktop alerts</button>
                        <button id="markNotificationsRead" class="btn btn-ghost btn-sm">Mark all read</button>
                    </div>
                    <div id="notificationList" class="notification-list"></div>
                </aside>`);
        }

        const agenticCommandEnabled = currentPage() === 'ai-analysis' || Boolean(byId('globalCommandButton'));
        if (agenticCommandEnabled && !byId('globalCommandPalette')) {
            document.body.insertAdjacentHTML('beforeend', `
                <div id="globalCommandPalette" class="command-palette hidden" role="dialog" aria-modal="true">
                    <div class="command-card">
                        <div class="command-head"><div><span class="eyebrow">Global command</span><h2>Ask RUS Agent</h2></div><button id="closeCommandPalette" class="icon-button">×</button></div>
                        <textarea id="globalCommandInput" rows="4" placeholder="Example: Extract CPS and Rewards DB data for Kamal"></textarea>
                        <div class="command-actions"><span>Ctrl + K</span><button id="openCommandInAgent" class="btn btn-primary">Continue in Agentic AI</button></div>
                    </div>
                </div>`);
        }
    }

    function renderNotifications() {
        if (!window.RUSNotifications) return;
        const items = RUSNotifications.list();
        const list = byId('notificationList');
        const unread = RUSNotifications.unreadCount();
        document.querySelectorAll('[data-notification-count]').forEach((node) => {
            node.textContent = unread > 99 ? '99+' : String(unread);
            node.classList.toggle('hidden', unread === 0);
        });
        if (!list) return;
        list.innerHTML = items.length ? items.map((item) => `
            <article class="notification-item ${item.read ? '' : 'unread'}" data-notification-id="${escapeHtml(item.id)}">
                <div class="notification-dot type-${escapeHtml(item.type)}"></div>
                <div class="notification-copy">
                    <div class="notification-title-row"><strong>${escapeHtml(item.title)}</strong><time>${new Date(item.createdAt).toLocaleString()}</time></div>
                    <p>${escapeHtml(item.message)}</p>
                    ${item.link ? `<a href="${escapeHtml(item.link)}">Open</a>` : ''}
                </div>
            </article>`).join('') : '<div class="empty-notifications">No notifications yet.</div>';
    }

    function setDrawer(open) {
        byId('rusNotificationDrawer')?.classList.toggle('open', open);
        byId('rusNotificationDrawer')?.setAttribute('aria-hidden', String(!open));
        byId('rusDrawerBackdrop')?.classList.toggle('hidden', !open);
        if (open) {
            renderNotifications();
            RUSNotifications?.markAllRead();
        }
    }

    function setCommand(open) {
        byId('globalCommandPalette')?.classList.toggle('hidden', !open);
        if (open) setTimeout(() => byId('globalCommandInput')?.focus(), 10);
    }

    async function checkAgenticHealth() {
        const badges = document.querySelectorAll('[data-agentic-health]');
        try {
            const response = await fetch('/api/agentic-ai/health/live', { cache: 'no-store' });
            const payload = await response.json().catch(() => ({}));
            const ready = response.ok && (payload?.success !== false);
            badges.forEach((node) => {
                node.className = `shell-health ${ready ? 'online' : 'offline'}`;
                node.innerHTML = `<span></span>${ready ? 'Agentic API online' : 'Agentic API unavailable'}`;
            });
        } catch {
            badges.forEach((node) => {
                node.className = 'shell-health offline';
                node.innerHTML = '<span></span>Agentic API unavailable';
            });
        }
    }


    let globalBatchTimer = null;

    function batchJobId() {
        return window.RUSWorkspace?.getShared('rus.agentic.jobId') ?? sessionStorage.getItem('rus.agentic.jobId');
    }

    async function monitorActiveBatch() {
        const jobId = batchJobId();
        if (!jobId) return;
        try {
            const response = await fetch(`/api/agentic-ai/batches/${encodeURIComponent(jobId)}`, { cache: 'no-store' });
            if (response.status === 404) {
                window.RUSWorkspace?.removeShared('rus.agentic.jobId');
                RUSNotifications?.add({
                    title: 'Previous bulk job expired',
                    message: 'The Python API no longer has that in-memory job. Submit a new bulk analysis.',
                    type: 'warning', category: 'batch', link: 'ai-analysis.html',
                    dedupeKey: `batch-expired:${jobId}`
                });
                return;
            }
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const envelope = await response.json();
            const job = envelope?.data ?? envelope ?? {};
            if (job.status === 'COMPLETED') {
                RUSNotifications?.add({
                    title: 'Bulk analysis completed',
                    message: `${job.completed_count || 0} of ${job.unique_valid_count || 0} completed; ${job.failed_count || 0} failed.`,
                    type: 'success', category: 'batch', link: 'ai-analysis.html',
                    metadata: { jobId, batchId: job.batch_id || null },
                    dedupeKey: `batch-completed:${jobId}`
                });
                window.dispatchEvent(new CustomEvent('rus:batch-completed', { detail: job }));
                return;
            }
            if (job.status === 'FAILED') {
                RUSNotifications?.add({
                    title: 'Bulk analysis failed',
                    message: job.error?.message || 'The batch ended with an error.',
                    type: 'error', category: 'batch', link: 'ai-analysis.html',
                    metadata: { jobId }, dedupeKey: `batch-failed:${jobId}`
                });
                return;
            }
            globalBatchTimer = window.setTimeout(monitorActiveBatch, 7000);
        } catch (error) {
            console.debug('Background batch status unavailable', error);
            globalBatchTimer = window.setTimeout(monitorActiveBatch, 15000);
        }
    }

    function bind() {
        ensureOverlays();
        setNavigation();
        renderNotifications();
        if (currentPage() === 'ai-analysis') {
            checkAgenticHealth();
            monitorActiveBatch();
        }


        byId('notificationButton')?.addEventListener('click', () => setDrawer(true));
        byId('closeNotificationDrawer')?.addEventListener('click', () => setDrawer(false));
        byId('rusDrawerBackdrop')?.addEventListener('click', () => setDrawer(false));
        byId('markNotificationsRead')?.addEventListener('click', () => RUSNotifications?.markAllRead());
        byId('enableSystemNotifications')?.addEventListener('click', async () => {
            const result = await RUSNotifications?.requestPermission();
            RUSNotifications?.add({ title: 'Desktop notifications', message: `Permission: ${result}`, type: result === 'granted' ? 'success' : 'warning', system: false });
        });
        byId('notificationList')?.addEventListener('click', (event) => {
            const item = event.target.closest('[data-notification-id]');
            if (item) RUSNotifications?.markRead(item.dataset.notificationId);
        });

        byId('globalCommandButton')?.addEventListener('click', () => setCommand(true));
        byId('closeCommandPalette')?.addEventListener('click', () => setCommand(false));
        byId('openCommandInAgent')?.addEventListener('click', () => {
            const value = byId('globalCommandInput')?.value?.trim();
            if (!value) return;
            sessionStorage.setItem('rus.agentic.prefill', value);
            window.location.href = 'ai-analysis.html';
        });
        document.addEventListener('keydown', (event) => {
            if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k' && byId('globalCommandPalette')) {
                event.preventDefault();
                setCommand(true);
            }
            if (event.key === 'Escape') { setDrawer(false); setCommand(false); }
        });
        window.addEventListener('rus:notifications-changed', renderNotifications);
    }

    document.addEventListener('DOMContentLoaded', bind);
})();

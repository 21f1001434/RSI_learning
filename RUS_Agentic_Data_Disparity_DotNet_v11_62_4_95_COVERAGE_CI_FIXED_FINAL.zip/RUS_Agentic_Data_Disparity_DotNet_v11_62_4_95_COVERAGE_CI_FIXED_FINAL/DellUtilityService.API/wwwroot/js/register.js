'use strict';

(function () {
    const form = document.getElementById('registerForm');
    const error = document.getElementById('registerError');
    const button = document.getElementById('registerButton');

    form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        error?.classList.add('hidden');
        const data = new FormData(form);
        const password = String(data.get('password') || '');
        const confirmPassword = String(data.get('confirmPassword') || '');
        if (password !== confirmPassword) {
            error.textContent = 'Password and confirmation do not match.';
            error.classList.remove('hidden');
            return;
        }
        button.disabled = true;
        button.textContent = 'Creating account…';
        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    username: String(data.get('username') || '').trim(),
                    displayName: String(data.get('displayName') || '').trim(),
                    email: String(data.get('email') || '').trim() || null,
                    password
                })
            });
            const payload = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(payload?.error?.message || payload?.message || `HTTP ${response.status}`);
            const auth = payload?.data ?? payload;
            sessionStorage.setItem('rus.auth.accessToken', auth.accessToken);
            sessionStorage.setItem('rus.auth.user', JSON.stringify(auth.user));
            localStorage.setItem('rus.auth.lastUsername', auth.user?.username || '');
            localStorage.setItem('rus.actor.name', auth.user?.username || '');
            if (auth.user?.email) localStorage.setItem('rus.actor.email', auth.user.email);
            window.location.replace('/');
        } catch (exception) {
            if (error) {
                error.textContent = exception?.message || 'Registration failed.';
                error.classList.remove('hidden');
            }
        } finally {
            button.disabled = false;
            button.textContent = 'Create account';
        }
    });
})();

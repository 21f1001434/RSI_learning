'use strict';

(function () {
    const form = document.getElementById('loginForm');
    const error = document.getElementById('loginError');
    const button = document.getElementById('loginButton');
    let redirecting = false;
    let submitting = false;
    const LEGACY_SESSION_PROBE_TIMEOUT_MS = 3500; // retained for upgrade-regression compatibility; auto-probe remains disabled.

    function returnUrl() {
        const value = new URLSearchParams(window.location.search).get('returnUrl');
        if (!value || !value.startsWith('/') || value.startsWith('//')) return '/rus-app.html';

        const url = new URL(value, window.location.origin);
        const path = url.pathname.toLowerCase();
        const dashboardAliases = new Set(['/', '/index.html', '/dashboard.html', '/rus-dashboard', '/workspace', '/workspace/dashboard', '/rus-app.html']);
        if (dashboardAliases.has(path)) return '/rus-app.html';

        // v11.31: navigate only to real application documents. Stale role routes such as
        // /Business or /Customer must never become a post-login destination.
        const allowedPages = new Set([
            '/ai-analysis.html', '/cps.html', '/members.html', '/crowdtwist.html',
            '/search.html', '/admin-users.html'
        ]);
        return allowedPages.has(path) ? `${url.pathname}${url.search}${url.hash}` : '/rus-app.html';
    }

    function clearBrowserSession() {
        try {
            sessionStorage.removeItem('rus.auth.accessToken');
            sessionStorage.removeItem('rus.auth.user');
            sessionStorage.removeItem('rus.auth.bootstrapState');
            sessionStorage.removeItem('rus.auth.redirectingToLogin');
        } catch { }
    }

    function showError(message) {
        if (!error) return;
        error.textContent = message || 'Sign-in failed.';
        error.classList.remove('hidden');
    }

    async function fetchWithTimeout(url, init, timeoutMs) {
        const controller = new AbortController();
        const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
        try {
            return await fetch(url, { ...init, signal: controller.signal, cache: 'no-store' });
        } finally {
            window.clearTimeout(timeout);
        }
    }

    // Clear any old HttpOnly cookie before accepting a new credential submission. This
    // endpoint never redirects and prevents an expired cookie from racing a new JWT.
    const resetReady = (async () => {
        clearBrowserSession();
        try {
            await fetchWithTimeout('/api/auth/reset-session', {
                method: 'POST', credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json', 'X-RUS-Channel': 'login-ui' },
                body: '{}'
            }, 5000);
        } catch { /* The login request itself can still overwrite the cookie. */ }
    })();

    async function authenticate(username, password) {
        const response = await fetchWithTimeout('/api/auth/login', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-RUS-Channel': 'login-ui' },
            body: JSON.stringify({ username, password })
        }, 15000);
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(payload?.error?.message || payload?.message || `HTTP ${response.status}`);
        const login = payload?.data ?? payload;
        if (!login?.accessToken || !login?.user) throw new Error('The login response did not contain a valid session.');
        return login;
    }

    // Verify the exact JWT before navigation. The browser never displays Dashboard until
    // /api/auth/me accepts the token, eliminating login/dashboard flashing on failed auth.
    async function verifySession(login) {
        const response = await fetchWithTimeout('/api/auth/me', {
            method: 'GET', credentials: 'same-origin',
            headers: { Accept: 'application/json', Authorization: `Bearer ${login.accessToken}`, 'X-RUS-Channel': 'login-verification' }
        }, 12000);
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(payload?.error?.message || 'The server could not verify the new session.');
        const verified = payload?.data ?? payload;
        if (!verified?.accessToken || !verified?.user) throw new Error('The verified session response was incomplete.');
        return verified;
    }

    function persistSession(auth) {
        try {
            const previous = localStorage.getItem('rus.auth.lastUsername');
            const nextUsername = auth.user.username || '';
            if (previous && nextUsername && previous.toLowerCase() !== nextUsername.toLowerCase()) {
                [...Object.keys(sessionStorage)].filter(key => key.startsWith('rus.agentic.') || key.startsWith('rus.workspace.')).forEach(key => sessionStorage.removeItem(key));
                [...Object.keys(localStorage)].filter(key => key.startsWith('rus.agentic.') || key.startsWith('rus.workspace.')).forEach(key => localStorage.removeItem(key));
            }
            if (nextUsername) localStorage.setItem('rus.auth.lastUsername', nextUsername);
            sessionStorage.setItem('rus.auth.accessToken', auth.accessToken);
            sessionStorage.setItem('rus.auth.user', JSON.stringify(auth.user));
            sessionStorage.setItem('rus.auth.bootstrapState', 'authenticated');
            localStorage.setItem('rus.actor.name', auth.user.username || '');
            if (auth.user.email) localStorage.setItem('rus.actor.email', auth.user.email);
            else localStorage.removeItem('rus.actor.email');
        } catch { }
    }

    form?.addEventListener('submit', async event => {
        event.preventDefault();
        if (redirecting || submitting) return;
        submitting = true;
        error?.classList.add('hidden');
        button.disabled = true;
        button.textContent = 'Verifying…';
        const data = new FormData(form);
        const username = String(data.get('username') || '').trim();
        const password = String(data.get('password') || '');

        try {
            await resetReady;
            const login = await authenticate(username, password);
            const verified = await verifySession(login);
            persistSession(verified);
            redirecting = true;
            document.documentElement.classList.add('auth-navigating');
            window.location.replace(returnUrl());
        } catch (exception) {
            clearBrowserSession();
            const message = exception?.name === 'AbortError'
                ? 'Sign-in verification timed out. Confirm the .NET service is ready and try again.'
                : (exception?.message || 'Sign-in failed.');
            showError(message);
        } finally {
            if (!redirecting) {
                submitting = false;
                button.disabled = false;
                button.textContent = 'Sign in';
            }
        }
    });
})();

using System.Security.Claims;
using System.Text;
using System.Text.Json.Serialization;
using DellUtilityService.API.AgenticIntegration;
using DellUtilityService.API.Configurations;
using DellUtilityService.API.Data;
using DellUtilityService.API.Services;
using DellUtilityService.API.Services.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Steeltoe.Extensions.Configuration.ConfigServer;
using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);

// Resolve Spring Config credentials from .NET configuration or deployment environment
// variables before Steeltoe builds its remote provider. No credential is read from
// the Python source tree in production. If credentials are unavailable, skip the
// remote call instead of repeatedly sending unauthenticated requests.
var configCredentialsAvailable = ConfigServerCredentialBootstrap.Apply(builder);
if (ConfigServerCredentialBootstrap.ShouldConnect(builder, configCredentialsAvailable))
{
    builder.AddConfigServer();
}
else
{
    Console.WriteLine("RUS startup: remote Spring Config was skipped because credentials were unavailable; local configuration remains active.");
}

var signingKey = JwtKeyBootstrap.Resolve(builder);
builder.Configuration[$"{JwtAuthenticationOptions.SectionName}:SigningKey"] = signingKey;
builder.Services.Configure<JwtAuthenticationOptions>(
    builder.Configuration.GetSection(JwtAuthenticationOptions.SectionName));
var authOptions = builder.Configuration
    .GetSection(JwtAuthenticationOptions.SectionName)
    .Get<JwtAuthenticationOptions>() ?? new JwtAuthenticationOptions();
authOptions.SigningKey = signingKey;

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.RequireHttpsMetadata = false;
        options.SaveToken = false;
        options.MapInboundClaims = false;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = authOptions.Issuer,
            ValidateAudience = true,
            ValidAudience = authOptions.Audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(30),
            NameClaimType = ClaimTypes.Name,
            RoleClaimType = ClaimTypes.Role
        };
        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = context =>
            {
                // Modern pages use Authorization: Bearer. The same JWT is also available in
                // a SameSite=Strict HttpOnly cookie so the unchanged v10.4 manual pages and
                // direct report downloads continue to work without exposing the token to JavaScript.
                var authorization = context.Request.Headers.Authorization.ToString();
                var hasBearerHeader = authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase);
                if (!hasBearerHeader &&
                    ShouldUseAuthenticationCookie(context.Request) &&
                    context.Request.Cookies.TryGetValue(authOptions.AccessCookieName, out var cookieToken))
                {
                    context.Token = cookieToken;
                }
                return Task.CompletedTask;
            },
            OnTokenValidated = async context =>
            {
                var id = context.Principal?.FindFirstValue(ClaimTypes.NameIdentifier)
                    ?? context.Principal?.FindFirstValue("sub");
                var store = context.HttpContext.RequestServices.GetRequiredService<IUserStore>();
                UserAccount? account;
                try
                {
                    // Do not bind account validation to the browser request token. During
                    // navigation the browser cancels old requests, which previously aborted
                    // the shared JSON-file read and caused login/dashboard redirect loops.
                    using var validationTimeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                    account = string.IsNullOrWhiteSpace(id)
                        ? null
                        : await store.FindByIdAsync(id, validationTimeout.Token);
                }
                catch (OperationCanceledException)
                {
                    // The JWT signature, issuer, audience and lifetime have already been
                    // validated. A short local user-store delay must not invalidate the
                    // browser session and create a login/dashboard redirect loop. The
                    // next request retries account-state validation from the warm cache.
                    var logger = context.HttpContext.RequestServices
                        .GetRequiredService<ILoggerFactory>()
                        .CreateLogger("JwtSessionValidation");
                    logger.LogWarning("JWT account-state validation timed out; accepting the signed token for this request and retrying on the next request.");
                    return;
                }
                catch (IOException exception)
                {
                    var logger = context.HttpContext.RequestServices
                        .GetRequiredService<ILoggerFactory>()
                        .CreateLogger("JwtSessionValidation");
                    logger.LogWarning(exception, "JWT account-state validation was temporarily unavailable; accepting the signed token for this request.");
                    return;
                }

                if (account is null)
                {
                    context.Fail("The user account is inactive or no longer exists.");
                    return;
                }
                var tokenRole = context.Principal?.FindFirstValue(ClaimTypes.Role)
                    ?? context.Principal?.FindFirstValue("role");
                if (!string.Equals(FileUserStore.NormalizeRole(tokenRole), FileUserStore.NormalizeRole(account.Role), StringComparison.OrdinalIgnoreCase))
                {
                    context.Fail("The user role changed. Sign in again.");
                    return;
                }
                var tokenDryRun = string.Equals(
                    context.Principal?.FindFirstValue("dry_run_enabled"),
                    "true",
                    StringComparison.OrdinalIgnoreCase);
                var currentDryRun = !RusRoles.IsAdmin(account.Role) && account.DryRunEnabled;
                if (tokenDryRun != currentDryRun)
                {
                    context.Fail("The Agentic write mode changed. Sign in again.");
                    return;
                }

                var tokenPasswordTicks = context.Principal?.FindFirstValue("pwd_changed") ?? "0";
                var currentPasswordTicks = (account.PasswordChangedUtc?.ToUniversalTime().Ticks ?? 0L).ToString(System.Globalization.CultureInfo.InvariantCulture);
                if (!string.Equals(tokenPasswordTicks, currentPasswordTicks, StringComparison.Ordinal))
                {
                    context.Fail("The password changed. Sign in again.");
                }
            },
            OnChallenge = context =>
            {
                if (!context.Response.HasStarted && context.Request.Path.StartsWithSegments("/api"))
                {
                    context.HandleResponse();
                    context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    context.Response.ContentType = "application/json";
                    return context.Response.WriteAsJsonAsync(new
                    {
                        success = false,
                        error = new { code = "AUTHENTICATION_REQUIRED", message = "Sign in to continue." },
                        requestId = context.HttpContext.TraceIdentifier
                    });
                }
                return Task.CompletedTask;
            },
            OnForbidden = context =>
            {
                if (context.Request.Path.StartsWithSegments("/api"))
                {
                    context.Response.StatusCode = StatusCodes.Status403Forbidden;
                    context.Response.ContentType = "application/json";
                    return context.Response.WriteAsJsonAsync(new
                    {
                        success = false,
                        error = new { code = "ACCESS_DENIED", message = "You do not have permission to perform this action." },
                        requestId = context.HttpContext.TraceIdentifier
                    });
                }
                return Task.CompletedTask;
            }
        };
    });

builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
    options.AddPolicy("AllRoles", policy => policy.RequireRole(RusRoles.Customer, RusRoles.Business, RusRoles.Technical, RusRoles.Admin));
    options.AddPolicy("CpsRead", policy => policy.RequireRole(RusRoles.Customer, RusRoles.Business, RusRoles.Technical, RusRoles.Admin));
    options.AddPolicy("BusinessOrHigher", policy => policy.RequireRole(RusRoles.Business, RusRoles.Technical, RusRoles.Admin));
    options.AddPolicy("TechnicalOperations", policy => policy.RequireRole(RusRoles.Technical, RusRoles.Admin));
    options.AddPolicy("AdminOnly", policy => policy.RequireRole(RusRoles.Admin));
});

builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.AddPolicy("login", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 8,
            Window = TimeSpan.FromMinutes(1),
            QueueLimit = 0,
            AutoReplenishment = true
        }));
    options.AddPolicy("registration", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 4,
            Window = TimeSpan.FromMinutes(10),
            QueueLimit = 0,
            AutoReplenishment = true
        }));
});

builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.Never;
        options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
        options.JsonSerializerOptions.WriteIndented = true;
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Dell Utility Service API", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Enter the JWT access token returned by /api/auth/login."
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        [new OpenApiSecurityScheme
        {
            Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
        }] = Array.Empty<string>()
    });
});

builder.Services.AddDbContext<DellUtilityDbContext>(options =>
{
    var vaultConfig = builder.Configuration.Get<VaultConfigurations>();
    var connectionString = vaultConfig?.DellRewardsConnection ?? builder.Configuration.GetConnectionString("DefaultConnection");
    options.UseSqlServer(connectionString);
});

builder.Services.Configure<VaultConfigurations>(builder.Configuration);
builder.Services.Configure<AppConfigurations>(builder.Configuration.GetSection("AppConfigurations"));
builder.Services.AddHttpClient();

builder.Services.Configure<AgenticApiOptions>(
    builder.Configuration.GetSection(AgenticApiOptions.SectionName));
builder.Services.AddHttpContextAccessor();
builder.Services.AddSingleton<IPasswordHashService, PasswordHashService>();
builder.Services.AddSingleton<IUserStore, FileUserStore>();
builder.Services.AddSingleton<IJwtTokenService, JwtTokenService>();
builder.Services.AddSingleton<IUserPromptService, JsonUserPromptService>();
builder.Services.AddSingleton<IAuditActorResolver, AuditActorResolver>();
builder.Services.AddSingleton<IAuditTrailService, JsonlAuditTrailService>();
builder.Services.AddSingleton<IAuditPrivacyService, AuditPrivacyService>();
builder.Services.AddTransient<AgenticApiRequestHandler>();
builder.Services.AddHttpClient<IAgenticDataDisparityApiClient, AgenticDataDisparityApiClient>((serviceProvider, client) =>
{
    var options = serviceProvider
        .GetRequiredService<Microsoft.Extensions.Options.IOptions<AgenticApiOptions>>()
        .Value;
    client.BaseAddress = options.GetBaseUri();
    client.Timeout = TimeSpan.FromSeconds(Math.Clamp(options.TimeoutSeconds, 30, 3600));
    client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
    client.DefaultRequestHeaders.UserAgent.ParseAdd("DellUtilityService-AgenticProxy/1.0");
})
.AddHttpMessageHandler<AgenticApiRequestHandler>();

builder.Services.AddHealthChecks()
    .AddCheck<AgenticApiHealthCheck>("agentic-data-disparity-api");

builder.Services.AddScoped<ICPSService, CPSService>();
builder.Services.AddScoped<ILoyaltyServiceProviderV3, LoyaltyServiceProviderV3>();
builder.Services.AddScoped<IRewardsDbOperationsV2, RewardsDbOperationsV2>();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowConfiguredOrigins", policy =>
    {
        var origins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();
        if (origins.Length == 0)
        {
            policy.SetIsOriginAllowed(origin =>
            {
                if (!Uri.TryCreate(origin, UriKind.Absolute, out var uri)) return false;
                return uri.IsLoopback;
            });
        }
        else
        {
            policy.WithOrigins(origins);
        }
        policy.AllowAnyMethod().AllowAnyHeader();
    });
});

var app = builder.Build();

// Warm the file-backed user store once before the first browser request. JWT
// validation then uses the in-memory snapshot instead of competing with page,
// JavaScript, health, and audit requests during initial navigation.
try
{
    using var startupScope = app.Services.CreateScope();
    var startupUsers = startupScope.ServiceProvider.GetRequiredService<IUserStore>();
    _ = await startupUsers.ListAsync(includeInactive: true, cancellationToken: CancellationToken.None);
}
catch (Exception exception)
{
    app.Logger.LogWarning(exception, "The JWT user store could not be preloaded. Login remains available and the store will retry on demand.");
}

var swaggerEnabled = app.Environment.IsDevelopment() || app.Configuration.GetValue<bool>("Swagger:Enabled");

// Local development is intentionally HTTP-only unless explicitly enabled.
// Avoid the repeated 'failed to determine HTTPS port' warning and any redirect
// ambiguity while the login cookie is being established.
if (app.Configuration.GetValue<bool>("Https:RedirectEnabled"))
{
    app.UseHttpsRedirection();
}

// CURRENT RELEASE STATIC FRONTEND SHELL + TERMINAL DOCUMENT GUARD:
// Every browser HTML document is loaded and terminally served before endpoint routing,
// controllers, authorization handlers, role projection, and fallback routing. This removes
// the entire class of failures where the browser receives only "Business"/"Customer" or
// another route value instead of the application document.
var frontendRootCandidates = new[]
{
    app.Environment.WebRootPath,
    Path.Combine(app.Environment.ContentRootPath, "wwwroot"),
    Path.Combine(AppContext.BaseDirectory, "wwwroot")
};
var frontendRoot = frontendRootCandidates
    .Where(candidate => !string.IsNullOrWhiteSpace(candidate))
    .Select(candidate => Path.GetFullPath(candidate!))
    .FirstOrDefault(Directory.Exists)
    ?? throw new InvalidOperationException(
        "RUS frontend root is missing. Expected an active wwwroot directory for the current release.");

var frontendDocumentNames = new[]
{
    "rus-app.html",
    "login.html",
    "register.html",
    "ai-analysis.html",
    "cps.html",
    "members.html",
    "crowdtwist.html",
    "search.html",
    "admin-users.html"
};

var frontendDocuments = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
foreach (var documentName in frontendDocumentNames)
{
    var documentPath = Path.Combine(frontendRoot, documentName);
    if (!File.Exists(documentPath))
    {
        throw new InvalidOperationException($"Required RUS frontend document is missing: {documentPath}");
    }

    var documentBytes = await File.ReadAllBytesAsync(documentPath);
    var documentText = Encoding.UTF8.GetString(documentBytes);
    if (documentBytes.LongLength < 256 ||
        !documentText.Contains("<!DOCTYPE html>", StringComparison.OrdinalIgnoreCase) ||
        !documentText.Contains("<html", StringComparison.OrdinalIgnoreCase))
    {
        throw new InvalidOperationException(
            $"Required RUS frontend document is blank or invalid: {documentPath}");
    }

    frontendDocuments[$"/{documentName}"] = documentBytes;
}

var rusAppBytes = frontendDocuments["/rus-app.html"];
var rusAppText = Encoding.UTF8.GetString(rusAppBytes);

// Resolve the active UI release at runtime instead of compiling a release number into
// the backend DLL. A hard-coded release here caused valid newer static assets to be
// rejected whenever somebody used `dotnet run --no-build` with an older DLL.
var frontendVersionPath = Path.Combine(frontendRoot, "VERSION");
if (!File.Exists(frontendVersionPath))
{
    throw new InvalidOperationException(
        $"RUS frontend VERSION file is missing: {frontendVersionPath}");
}
var rusRelease = (await File.ReadAllTextAsync(frontendVersionPath)).Trim();
if (string.IsNullOrWhiteSpace(rusRelease))
{
    throw new InvalidOperationException("RUS frontend VERSION file is blank.");
}

var requiredShellMarkers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
{
    ["dashboard title"] = "<title>RUS Operations Dashboard</title>",
    ["release marker"] = "data-dashboard-shell=\"",
    ["release metadata"] = "<meta name=\"rus-release\" content=\"",
    ["UI shell family"] = "<meta name=\"rus-ui-shell\" content=\"rus-app-v",
    ["Agentic AI navigation"] = "Open Agentic AI",
    ["sidebar host"] = "data-rus-sidebar",
    ["static fallback"] = "data-static-shell-fallback=\"",
    ["product branding"] = "Rewards Utility"
};
var missingShellMarkers = requiredShellMarkers
    .Where(marker => !rusAppText.Contains(marker.Value, StringComparison.OrdinalIgnoreCase))
    .Select(marker => marker.Key)
    .ToArray();
if (missingShellMarkers.Length > 0)
{
    throw new InvalidOperationException(
        $"The RUS application shell failed structural startup validation. " +
        $"Missing marker(s): {string.Join(", ", missingShellMarkers)}. " +
        "The server will not start with a blank or role-text-only shell.");
}

// The active shell markers must agree with wwwroot/VERSION. This catches a genuinely
// mixed frontend package without tying validation to whatever version the DLL was built as.
var expectedReleaseMarkers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
{
    ["dashboard shell"] = $"data-dashboard-shell=\"{rusRelease}\"",
    ["release metadata"] = $"<meta name=\"rus-release\" content=\"{rusRelease}\">",
    ["static fallback"] = $"data-static-shell-fallback=\"{rusRelease}\""
};
var mismatchedReleaseMarkers = expectedReleaseMarkers
    .Where(marker => !rusAppText.Contains(marker.Value, StringComparison.OrdinalIgnoreCase))
    .Select(marker => marker.Key)
    .ToArray();
if (mismatchedReleaseMarkers.Length > 0)
{
    throw new InvalidOperationException(
        $"The RUS frontend package is internally inconsistent for release {rusRelease}. " +
        $"Mismatched marker(s): {string.Join(", ", mismatchedReleaseMarkers)}. " +
        "Re-extract one complete release package instead of mixing wwwroot files.");
}

var dashboardAliases = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
{
    "/",
    "/index.html",
    "/dashboard.html",
    "/rus-dashboard",
    "/workspace",
    "/workspace/dashboard",
    // Stale role-projection routes seen in the broken post-login flow.
    "/Business",
    "/Customer",
    "/Technical",
    "/Admin"
};

app.Use(async (context, next) =>
{
    if (!HttpMethods.IsGet(context.Request.Method) && !HttpMethods.IsHead(context.Request.Method))
    {
        await next();
        return;
    }

    var requestPath = context.Request.Path.Value ?? string.Empty;
    var documentPath = dashboardAliases.Contains(requestPath) ? "/rus-app.html" : requestPath;

    if (!frontendDocuments.TryGetValue(documentPath, out var documentBytes))
    {
        await next();
        return;
    }

    context.Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
    context.Response.Headers.Pragma = "no-cache";
    context.Response.Headers.Expires = "0";
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["X-RUS-Release"] = rusRelease;
    context.Response.Headers["X-RUS-UI-Document"] = documentPath;
    if (documentPath.Equals("/rus-app.html", StringComparison.OrdinalIgnoreCase))
    {
        context.Response.Headers["X-RUS-UI-Shell"] = "rus-app";
    }

    context.Response.StatusCode = StatusCodes.Status200OK;
    context.Response.ContentType = "text/html; charset=utf-8";
    context.Response.ContentLength = documentBytes.LongLength;
    if (!HttpMethods.IsHead(context.Request.Method))
    {
        await context.Response.Body.WriteAsync(documentBytes, context.RequestAborted);
    }
});

app.UseRouting();
app.UseCors("AllowConfiguredOrigins");
app.UseRateLimiter();
app.UseAuthentication();

// Verified runtime guard: intercept the exact site root (legacy v11.24 regression reference only).
// context.Request.Path == "/"; var destination = authenticated ? "/index.html" : "/login.html"; context.Response.Redirect(destination);
// Previous verified release contract: release = "11.24.0"; build = "verified-runtime"; rootBehavior = "login-or-dashboard-redirect".
// Previous manual page boundary: new[] { RusRoles.Technical, RusRoles.Admin }. v11.27 intentionally grants identical manual tools to all roles.
// Previous CPS boundary: RusRoles.Customer, RusRoles.Technical, RusRoles.Admin. v11.27 includes Business as well.

// Cookie-authenticated unsafe API calls are accepted only from this same-origin UI.
// This preserves the original v10.4 manual JavaScript while preventing cross-site writes.
app.Use(async (context, next) =>
{
    var request = context.Request;
    var unsafeApi = request.Path.StartsWithSegments("/api") &&
                    !HttpMethods.IsGet(request.Method) &&
                    !HttpMethods.IsHead(request.Method) &&
                    !HttpMethods.IsOptions(request.Method) &&
                    !string.Equals(request.Path.Value, "/api/auth/login", StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(request.Path.Value, "/api/auth/register", StringComparison.OrdinalIgnoreCase);
    var hasBearer = request.Headers["Authorization"].ToString().StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase);
    var usesAuthCookie = request.Cookies.ContainsKey(authOptions.AccessCookieName);
    if (unsafeApi && usesAuthCookie && !hasBearer && !IsSameOriginBrowserRequest(request))
    {
        context.Response.StatusCode = StatusCodes.Status403Forbidden;
        context.Response.ContentType = "application/json";
        await context.Response.WriteAsJsonAsync(new
        {
            success = false,
            error = new { code = "SAME_ORIGIN_REQUIRED", message = "This authenticated operation must originate from the RUS application." },
            requestId = context.TraceIdentifier
        });
        return;
    }
    await next();
});

// Static HTML is an application shell and contains no customer data. Serve it without
// a server-side login redirect, then let the single browser auth bootstrap decide once.
// Protecting HTML both here and in auth.js created a login <-> dashboard navigation loop
// whenever a page request and /api/auth/me observed different transient session states.
// APIs remain protected by the authorization fallback policy and role-specific policies.
app.Use(async (context, next) =>
{
    if (context.Request.Path.StartsWithSegments("/swagger") &&
        context.User.Identity?.IsAuthenticated != true)
    {
        context.Response.Redirect("/login.html?returnUrl=%2Fswagger");
        return;
    }
    await next();
});

if (swaggerEnabled)
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseStaticFiles(new StaticFileOptions
{
    OnPrepareResponse = context =>
    {
        var extension = Path.GetExtension(context.File.Name);
        if (extension.Equals(".html", StringComparison.OrdinalIgnoreCase) ||
            extension.Equals(".js", StringComparison.OrdinalIgnoreCase) ||
            extension.Equals(".css", StringComparison.OrdinalIgnoreCase))
        {
            context.Context.Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            context.Context.Response.Headers.Pragma = "no-cache";
            context.Context.Response.Headers.Expires = "0";
            if (context.File.Name.Equals("login.html", StringComparison.OrdinalIgnoreCase))
            {
                context.Context.Response.Headers["Clear-Site-Data"] = "\"cache\"";
            }
        }
    }
});
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health/agentic").AllowAnonymous();
app.MapGet("/api/release", () => Results.Ok(new
{
    success = true,
    data = new
    {
        release = rusRelease,
        build = "static-shell-cache-resilience",
        rootBehavior = "terminal-rus-app-document",
        packageRelease = rusRelease,
        packageBuild = "static-shell-cache-resilience",
        dashboardShell = "static-html-fallback-plus-terminal-shell",
        adminDelegation = true,
        adminPrompts = true,
        permanentUserRemoval = true,
        dashboardAssetBase = "/",
        workspaceRedirect = false,
        manualPagesSameForAllRoles = true
    }
})).AllowAnonymous();

// v11.24: own the site root explicitly. (legacy regression reference only)
// app.MapMethods("/", new[] { HttpMethods.Get, HttpMethods.Head }, (HttpContext context) =>
// { context.Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
//   var destination = context.User.Identity?.IsAuthenticated == true ? "/index.html" : "/login.html";
//   return Results.Redirect(destination, permanent: false, preserveMethod: false); });
// Current terminal frontend middleware serves known HTML documents before routing.

// Unknown browser routes still receive the dedicated current-release application shell.
app.MapFallbackToFile("rus-app.html").AllowAnonymous();

app.Run();

static bool ShouldUseAuthenticationCookie(HttpRequest request)
{
    var path = request.Path.Value ?? string.Empty;
    if (path.Equals("/login.html", StringComparison.OrdinalIgnoreCase) ||
        path.Equals("/register.html", StringComparison.OrdinalIgnoreCase) ||
        path.Equals("/api/auth/login", StringComparison.OrdinalIgnoreCase) ||
        path.Equals("/api/auth/register", StringComparison.OrdinalIgnoreCase) ||
        path.Equals("/api/auth/reset-session", StringComparison.OrdinalIgnoreCase))
    {
        return false;
    }

    var extension = Path.GetExtension(path);
    return extension.ToLowerInvariant() switch
    {
        ".css" or ".js" or ".svg" or ".png" or ".jpg" or ".jpeg" or
        ".gif" or ".webp" or ".ico" or ".woff" or ".woff2" or ".map" => false,
        _ => true
    };
}

static bool IsProtectedPageRequest(HttpRequest request)
{
    if (!HttpMethods.IsGet(request.Method) && !HttpMethods.IsHead(request.Method)) return false;
    var path = request.Path.Value ?? "/";
    if (path.Equals("/login.html", StringComparison.OrdinalIgnoreCase) ||
        path.Equals("/register.html", StringComparison.OrdinalIgnoreCase)) return false;
    if (path.Equals("/", StringComparison.OrdinalIgnoreCase)) return true;
    return path.EndsWith(".html", StringComparison.OrdinalIgnoreCase);
}


static bool IsSameOriginBrowserRequest(HttpRequest request)
{
    var fetchSite = request.Headers["Sec-Fetch-Site"].ToString();
    if (fetchSite.Equals("same-origin", StringComparison.OrdinalIgnoreCase) ||
        fetchSite.Equals("none", StringComparison.OrdinalIgnoreCase))
    {
        return true;
    }

    var origin = request.Headers["Origin"].ToString();
    if (Uri.TryCreate(origin, UriKind.Absolute, out var originUri))
    {
        return string.Equals(originUri.Host, request.Host.Host, StringComparison.OrdinalIgnoreCase) &&
               (originUri.IsDefaultPort || originUri.Port == request.Host.Port);
    }

    var referer = request.Headers["Referer"].ToString();
    if (Uri.TryCreate(referer, UriKind.Absolute, out var refererUri))
    {
        return string.Equals(refererUri.Host, request.Host.Host, StringComparison.OrdinalIgnoreCase) &&
               (refererUri.IsDefaultPort || refererUri.Port == request.Host.Port);
    }

    return false;
}


static string[]? RequiredRolesForPage(string? rawPath)
{
    var path = (rawPath ?? string.Empty).Trim().ToLowerInvariant();
    return path switch
    {
        "/admin-users.html" => new[] { RusRoles.Admin },
        "/members.html" or "/crowdtwist.html" or "/cps.html" or "/search.html" =>
            new[] { RusRoles.Customer, RusRoles.Business, RusRoles.Technical, RusRoles.Admin },
        "/ai-analysis.html" or "/rus-app.html" or "/workspace" or "/workspace/dashboard" or "/rus-dashboard" or "/dashboard.html" or "/index.html" or "/" =>
            new[] { RusRoles.Customer, RusRoles.Business, RusRoles.Technical, RusRoles.Admin },
        _ => null
    };
}

# Dell Utility Service API — Agentic AI Integrated

ASP.NET Core 8 application containing the existing CPS, Rewards DB, CrowdTwist and Search features plus a server-side integration with the Dell AIA + AutoGen + MCP Data Disparity API.

## New integration folders

- `AgenticIntegration/` — typed HTTP client, configuration, internal-key handler and health check.
- `Models/Agentic/` — request contracts for sessions, chat, analysis, batch, knowledge and use cases.
- `Controllers/AgenticAIController.cs` — complete `/api/agentic-ai/*` proxy surface.
- `wwwroot/ai-analysis.html` — chat, individual analysis, batch processing and API knowledge UI.
- `wwwroot/js/ai-analysis.js` — in-session memory, report rendering, batch polling and contract validation.

`AIAnalysisController` is now only a backwards-compatible proxy. The old duplicate C# disparity rules were removed so all clients use the same deterministic Python truth policy and Judge enforcement.

## Configuration

```json
"AgenticDataDisparityApi": {
  "BaseUrl": "http://localhost:8088/",
  "InternalApiKey": "",
  "TimeoutSeconds": 900,
  "RecommendedSourceParallelism": 8,
  "RecommendedAiParallelism": 2,
  "IncludeGroupedAiByDefault": true,
  "BatchPollIntervalSeconds": 5,
  "MaxUploadBytes": 5000000
}
```

The internal key is added by `AgenticApiRequestHandler` and is never returned to browser JavaScript.

## Run the .NET application only

Start the Python API first, then from the integrated package root:

```powershell
.\scripts\run_dotnet_only.ps1
```

Open `http://localhost:49690/ai-analysis.html`.

## Proxy API surface

See `../INTEGRATION_API_MATRIX.md` for all integrated endpoints.


## v10.2 summary statistics and formatted chat

The Agentic AI page now shows completed-batch summary statistics, percentages, majority issue, top issue attributes, source coverage, Judge outcomes and timing. New chat buttons call the deterministic batch statistics, majority, source-coverage and Judge actions. Assistant responses are rendered with a safe block formatter instead of placing headings/lists inside one paragraph.

## v10.1 batch-aware agent chat

The AI page links each TXT/CSV batch to the current `session_id`. After completion, the grouped result is retained in Python session memory and the .NET chat can answer bulk status, summary, findings, timing, Judge-outcome, affected-user, and report-link questions. The .NET proxy endpoint is `GET /api/agentic-ai/sessions/{sessionId}/active-batch`.

The unused `Dell.VaultSharp.Extensions.Configuration.VcapCore` package reference was removed so local `dotnet restore` works with the configured public NuGet source. Existing configuration classes remain unchanged.


## v11.3 unmasked report correction

- `POST /api/v1/analysis/individual` now applies `mask_report_values` to the structured report returned to the UI.
- `GET /api/v1/analysis/{run_id}?masked=true|false` returns the requested privacy view.
- Canonical report evidence is persisted separately from `.masked.json` and `.masked.html` variants.
- Masked audit output remains available as `<run_id>.audit.json`.
- A legacy v11.2 run containing only irreversible `<email:...>` or `<guid:...>` tokens returns `409 UNMASKED_REPORT_UNAVAILABLE`; rerun that member after upgrading.

## v11.4 unmasked-default contract

- Omitting `mask_report_values` now returns actual source values (`false`).
- Omitting `masked` from structured, HTML, JSON, and batch ZIP routes now returns the unmasked artifact.
- Use `masked=true` only when a tokenized shareable copy is required.
- Canonical unmasked files, masked files, and the audit file remain separate.
- The browser migrates the old v11.3 session default to unmasked once and cache-busts all v11.4 assets.

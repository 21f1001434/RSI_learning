namespace DellUtilityService.API.Configurations;

public sealed class JwtAuthenticationOptions
{
    public const string SectionName = "Authentication";

    public string Issuer { get; set; } = "RUS.DellUtilityService";
    public string Audience { get; set; } = "RUS.Web";
    public int AccessTokenMinutes { get; set; } = 480;
    public string AccessCookieName { get; set; } = "rus_access_token";
    public string UserStoreFile { get; set; } = "App_Data/auth-users.json";
    public string SeedUsersFile { get; set; } = "Data/auth-users.seed.json";
    public string? SigningKey { get; set; }

    public TimeSpan AccessTokenLifetime =>
        TimeSpan.FromMinutes(Math.Clamp(AccessTokenMinutes, 15, 1440));
}

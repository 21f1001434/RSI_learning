namespace DellUtilityService.API.Configurations;

/// <summary>
/// Resolves Spring Config credentials from normal .NET configuration or process
/// environment variables. v11.62 deliberately does not read credentials from
/// the Python source tree; production secrets must be injected by the approved
/// deployment mechanism (Vault/CI environment/Windows service environment).
/// </summary>
public static class ConfigServerCredentialBootstrap
{
    private const string UsernameName = "SPRING_CONFIG_USERNAME";
    private const string PasswordName = "SPRING_CONFIG_PASSWORD";

    public static bool Apply(WebApplicationBuilder builder)
    {
        var configuredUsername = builder.Configuration["spring:cloud:config:username"];
        var configuredPassword = builder.Configuration["spring:cloud:config:password"];
        if (!string.IsNullOrWhiteSpace(configuredUsername) && !string.IsNullOrWhiteSpace(configuredPassword))
        {
            return true;
        }

        var environmentUsername = Environment.GetEnvironmentVariable(UsernameName);
        var environmentPassword = Environment.GetEnvironmentVariable(PasswordName);
        if (string.IsNullOrWhiteSpace(environmentUsername) || string.IsNullOrWhiteSpace(environmentPassword))
        {
            return false;
        }

        builder.Configuration["spring:cloud:config:username"] = environmentUsername;
        builder.Configuration["spring:cloud:config:password"] = environmentPassword;
        return true;
    }

    public static bool ShouldConnect(WebApplicationBuilder builder, bool credentialsAvailable)
    {
        var rawUri = builder.Configuration["spring:cloud:config:uri"];
        if (!Uri.TryCreate(rawUri, UriKind.Absolute, out var uri)) return false;
        // Loopback development config servers may be anonymous. Remote Dell
        // Config Server calls are attempted only when credentials are present.
        return uri.IsLoopback || credentialsAvailable;
    }
}

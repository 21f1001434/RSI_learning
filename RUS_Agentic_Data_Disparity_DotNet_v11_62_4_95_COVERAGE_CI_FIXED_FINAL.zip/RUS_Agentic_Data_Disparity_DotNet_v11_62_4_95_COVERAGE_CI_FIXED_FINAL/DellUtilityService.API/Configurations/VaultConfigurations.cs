namespace DellUtilityService.API.Configurations;

public class VaultConfigurations
{
    public const string DellRewardsDbConnection = "DellRewardsConnection";

    public string? DataSourceType { get; set; }
    public string? DellRewardsConnection { get; set; }
    public string? Domain { get; set; }
    public string? IdentityAuthKey { get; set; }
    public string? InstanceName { get; set; }
    public string? Password { get; set; }
    public string? PersuadeAccessKey { get; set; }
    public string? PersuadeBaseAddress { get; set; }
    public double PersuadeExpiryHours { get; set; }
    public string? PersuadePassword { get; set; }
    public string? PersuadeUserName { get; set; }
    public string? PersuadeXAuthToken { get; set; }
    public string? Username { get; set; }
    public string? RMQPassword { get; set; }
    public string? RMQUserName { get; set; }
    public string? RedisConnectionString { get; set; }
    public string? PmcApiKey { get; set; }
    public string? PmcIdentityKey { get; set; }
    public string? AlienwareBaseAddress { get; set; }
    public string? AlienwareXToken { get; set; }
    public string? AlienwareOptOutURL { get; set; }
    public string? HttpClientTimeOutInMS { get; set; }
    public string? env { get; set; }
    public string? DCIAuthClientId { get; set; }
    public string? DCIAuthClientSecret { get; set; }
    public string? DCIAuthResource { get; set; }
    public string? DCIAuthScope { get; set; }
    public string? DCIAuthUrl { get; set; }
    public string? DCIAppClientId { get; set; }
    public string? DCIAppClientSecret { get; set; }

    public string? PersuadeLayer7BaseAddress { get; set; }
    public string? PersuadeLayer7Enabled { get; set; }
    public string? PersuadeLayer7APIKey { get; set; }
    public string? PersuadeLayer7EnabledApis { get; set; }
    public string? SheerIDLayer7BaseAddress { get; set; }
    public string? SheerIDLayer7APIKey { get; set; }
    public string? CTLayer7PosApiKey { get; set; }
    public string? CTLayer7PosApiURL { get; set; }
    public string? CTLayer7PosClientID { get; set; }
    public string? CTLayer7PosSecret { get; set; }

    public string? CrowdTwistApiKey { get; set; }
    public string? CrowdTwistBaseUrl { get; set; }

    public string? CTLayer7AuthTokenURL { get; set; }
    public string? CTLayer7ClientId { get; set; }
    public string? CTLayer7Secret { get; set; }
    public string? CTLayer7ApiURL { get; set; }

    public string? CrowdTwistEnabled { get; set; }

    public string? PEBaseUrl { get; set; }
    public string? CTLayer7ExtSecret { get; set; }
    public string? CTLayer7ExtClientId { get; set; }
    public string? CTLayer7ApiExtURL { get; set; }
    public bool DisableDellRewards { get; set; }
    public string? CTLayer7ApiExt2URL { get; set; }
    public string? CTLayer7Ext2ClientId { get; set; }
    public string? CTLayer7Ext2Secret { get; set; }

    // CPS-specific configurations
    public string? CPSBaseAddress { get; set; }
    public string? CPSApiKey { get; set; }
}

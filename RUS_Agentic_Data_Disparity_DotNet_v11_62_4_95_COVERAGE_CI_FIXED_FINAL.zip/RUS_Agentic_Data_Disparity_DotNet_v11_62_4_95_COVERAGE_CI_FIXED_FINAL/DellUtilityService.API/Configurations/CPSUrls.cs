namespace DellUtilityService.API.Configurations;

public static class CPSUrls
{
    public static string GetAccountUrl => "v2/Accounts/";
    public static string CreateAccount => "v2/Accounts";
}

namespace DellUtilityService.API.Configurations;

public class AppConfigurations
{
    public CPSConfiguration CPS { get; set; } = new();
    public CrowdTwistConfiguration CrowdTwist { get; set; } = new();
    public DatabaseConfiguration Database { get; set; } = new();
}

public class CPSConfiguration
{
    public string BaseAddress { get; set; } = string.Empty;
    public string ApiKey { get; set; } = string.Empty;
    public string DCIAuthUrl { get; set; } = string.Empty;
    public string DCIAppClientId { get; set; } = string.Empty;
    public string DCIAppClientSecret { get; set; } = string.Empty;
}

public class CrowdTwistConfiguration
{
    public string Layer7ApiURL { get; set; } = string.Empty;
    public string CrowdTwistApiKey { get; set; } = string.Empty;
    public string AuthToken { get; set; } = string.Empty;
    public string CTLayer7ClientId { get; set; } = string.Empty;
    public string CTLayer7Secret { get; set; } = string.Empty;
    public string CTLayer7AuthTokenURL { get; set; } = string.Empty;
}

public class DatabaseConfiguration
{
    public string ConnectionString { get; set; } = string.Empty;
}

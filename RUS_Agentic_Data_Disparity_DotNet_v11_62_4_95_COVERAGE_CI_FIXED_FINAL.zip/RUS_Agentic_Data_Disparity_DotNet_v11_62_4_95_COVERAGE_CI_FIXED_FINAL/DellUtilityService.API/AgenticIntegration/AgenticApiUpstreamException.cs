using System.Net;

namespace DellUtilityService.API.AgenticIntegration;

public sealed class AgenticApiUpstreamException : Exception
{
    public AgenticApiUpstreamException(
        string message,
        HttpStatusCode? statusCode = null,
        string? upstreamBody = null,
        Exception? innerException = null)
        : base(message, innerException)
    {
        StatusCode = statusCode;
        UpstreamBody = upstreamBody;
    }

    public HttpStatusCode? StatusCode { get; }
    public string? UpstreamBody { get; }
}

using System.Text.Json;
using DellUtilityService.API.Models.Agentic;

namespace DellUtilityService.API.AgenticIntegration;

public interface IAgenticDataDisparityApiClient
{
    Task<JsonDocument> GetLivenessAsync(CancellationToken cancellationToken = default);
    Task<JsonDocument> GetReadinessAsync(bool deep, CancellationToken cancellationToken = default);
    Task<JsonDocument> GetAdaptiveMemoryStatusAsync(CancellationToken cancellationToken = default);

    Task<JsonDocument> CreateSessionAsync(
        SessionCreateProxyRequest request,
        CancellationToken cancellationToken = default);
    Task<JsonDocument> GetSessionAsync(
        string sessionId,
        bool includeMessages = true,
        CancellationToken cancellationToken = default);
    Task<JsonDocument> ResetSessionAsync(string sessionId, CancellationToken cancellationToken = default);
    Task<JsonDocument> DeleteSessionAsync(string sessionId, CancellationToken cancellationToken = default);
    Task<JsonDocument> GetSessionActiveBatchAsync(string sessionId, CancellationToken cancellationToken = default);

    Task<JsonDocument> ChatAsync(ChatProxyRequest request, CancellationToken cancellationToken = default);
    Task<JsonDocument> QueryCpsSourceAsync(CpsSourceQueryProxyRequest request, CancellationToken cancellationToken = default);
    Task<JsonDocument> QuerySourceAsync(SourceQueryProxyRequest request, CancellationToken cancellationToken = default);
    Task<JsonDocument> PlanSourceChangeAsync(SourceChangePlanProxyRequest request, CancellationToken cancellationToken = default);
    Task<JsonDocument> GetSourceChangeAsync(string changeId, string sessionId, CancellationToken cancellationToken = default);
    Task<JsonDocument> ConfirmSourceChangeFirstAsync(string changeId, SourceChangeConfirmationProxyRequest request, CancellationToken cancellationToken = default);
    Task<JsonDocument> MarkSourceChangePopupOpenedAsync(string changeId, SourceChangePopupOpenedProxyRequest request, CancellationToken cancellationToken = default);
    Task<JsonDocument> ConfirmSourceChangeSecondAsync(string changeId, SourceChangeConfirmationProxyRequest request, CancellationToken cancellationToken = default);
    Task<JsonDocument> CancelSourceChangeAsync(string changeId, SourceChangeCancelProxyRequest request, CancellationToken cancellationToken = default);
    Task<JsonDocument> ImportSpreadsheetSourceChangesAsync(SpreadsheetSourceChangeImportProxyRequest request, CancellationToken cancellationToken = default);
    Task<JsonDocument> GetAuditTrailAsync(int limit = 100, string? source = null, string? status = null, string? actor = null, string? action = null, DateTime? fromUtc = null, DateTime? toUtc = null, CancellationToken cancellationToken = default);
    Task<JsonDocument> AnalyzeAsync(
        IndividualAnalysisProxyRequest request,
        CancellationToken cancellationToken = default);
    Task<JsonDocument> GetAnalysisAsync(string runId, bool masked = false, CancellationToken cancellationToken = default);

    Task<HttpResponseMessage> GetHtmlReportResponseAsync(
        string runId,
        bool masked = false,
        CancellationToken cancellationToken = default);
    Task<HttpResponseMessage> GetJsonReportResponseAsync(
        string runId,
        bool masked = false,
        CancellationToken cancellationToken = default);

    Task<JsonDocument> SubmitBatchAsync(
        BatchEmailsProxyRequest request,
        CancellationToken cancellationToken = default);
    Task<JsonDocument> UploadBatchAsync(
        Stream stream,
        string fileName,
        string? sessionId,
        int maxParallel,
        int maxParallelAi,
        bool includeGroupAi,
        CancellationToken cancellationToken = default);
    Task<JsonDocument> GetBatchAsync(string jobId, CancellationToken cancellationToken = default);
    Task<JsonDocument> GetBatchSummaryAsync(string jobId, CancellationToken cancellationToken = default);
    Task<HttpResponseMessage> GetBatchDownloadResponseAsync(
        string jobId,
        bool masked = false,
        CancellationToken cancellationToken = default);

    Task<JsonDocument> GetKnowledgeCatalogAsync(CancellationToken cancellationToken = default);
    Task<JsonDocument> GetOperationAsync(
        string operationId,
        CancellationToken cancellationToken = default);
    Task<JsonDocument> ValidatePayloadAsync(
        PayloadValidationProxyRequest request,
        CancellationToken cancellationToken = default);

    Task<JsonDocument> GetUseCasesAsync(string runId, CancellationToken cancellationToken = default);
    Task<JsonDocument> CompileUseCasePlanAsync(
        UseCasePlanProxyRequest request,
        CancellationToken cancellationToken = default);
}

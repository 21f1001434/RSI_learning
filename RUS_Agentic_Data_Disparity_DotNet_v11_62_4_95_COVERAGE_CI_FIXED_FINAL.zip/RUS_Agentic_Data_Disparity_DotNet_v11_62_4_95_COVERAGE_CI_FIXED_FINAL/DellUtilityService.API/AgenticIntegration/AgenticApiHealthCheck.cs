using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace DellUtilityService.API.AgenticIntegration;

public sealed class AgenticApiHealthCheck : IHealthCheck
{
    private readonly IAgenticDataDisparityApiClient _client;

    public AgenticApiHealthCheck(IAgenticDataDisparityApiClient client)
    {
        _client = client;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        try
        {
            using var response = await _client.GetLivenessAsync(cancellationToken);
            var root = response.RootElement;
            var success = root.TryGetProperty("success", out var successNode) && successNode.GetBoolean();
            return success
                ? HealthCheckResult.Healthy("Agentic Data Disparity API is live.")
                : HealthCheckResult.Degraded("Agentic API responded but did not report success.");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy("Agentic Data Disparity API is unavailable.", ex);
        }
    }
}

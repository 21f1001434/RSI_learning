namespace DellUtilityService.API.AgenticIntegration;

public sealed class AgenticApiOptions
{
    public const string SectionName = "AgenticDataDisparityApi";

    public string BaseUrl { get; set; } = "http://localhost:8088/";
    public string InternalApiKey { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 900;
    public int RecommendedSourceParallelism { get; set; } = 8;
    public int RecommendedAiParallelism { get; set; } = 2;
    public bool IncludeGroupedAiByDefault { get; set; } = true;
    public int BatchPollIntervalSeconds { get; set; } = 5;
    public int MaxUploadBytes { get; set; } = 5_000_000;

    public Uri GetBaseUri()
    {
        if (!Uri.TryCreate(BaseUrl, UriKind.Absolute, out var uri))
        {
            throw new InvalidOperationException(
                $"Configuration '{SectionName}:BaseUrl' must be an absolute URL.");
        }

        return uri.AbsoluteUri.EndsWith('/') ? uri : new Uri(uri.AbsoluteUri + "/");
    }
}

using System.Security.Claims;
using Microsoft.Extensions.Options;

namespace DellUtilityService.API.AgenticIntegration;

public sealed class AgenticApiRequestHandler : DelegatingHandler
{
    private readonly AgenticApiOptions _options;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public AgenticApiRequestHandler(
        IOptions<AgenticApiOptions> options,
        IHttpContextAccessor httpContextAccessor)
    {
        _options = options.Value;
        _httpContextAccessor = httpContextAccessor;
    }

    protected override Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(_options.InternalApiKey))
        {
            request.Headers.Remove("X-Internal-API-Key");
            request.Headers.TryAddWithoutValidation("X-Internal-API-Key", _options.InternalApiKey);
        }

        var context = _httpContextAccessor.HttpContext;
        var traceId = context?.TraceIdentifier;
        if (!string.IsNullOrWhiteSpace(traceId))
        {
            request.Headers.Remove("X-Request-ID");
            request.Headers.TryAddWithoutValidation("X-Request-ID", traceId);
        }

        var principal = context?.User;
        if (principal?.Identity?.IsAuthenticated == true)
        {
            SetHeader(request, "X-RUS-Actor",
                principal.FindFirstValue("preferred_username") ?? principal.Identity.Name);
            SetHeader(request, "X-RUS-Actor-Display-Name",
                principal.FindFirstValue("display_name") ?? principal.Identity.Name);
            SetHeader(request, "X-RUS-Actor-Email",
                principal.FindFirstValue(ClaimTypes.Email) ?? principal.FindFirstValue("email"));
            SetHeader(request, "X-RUS-Actor-Role",
                principal.FindFirstValue(ClaimTypes.Role) ?? principal.FindFirstValue("role"));
            SetHeader(request, "X-RUS-Actor-ID",
                principal.FindFirstValue(ClaimTypes.NameIdentifier) ?? principal.FindFirstValue("sub"));
        }

        request.Headers.TryAddWithoutValidation("X-Caller-Service", "DellUtilityService.API");
        return base.SendAsync(request, cancellationToken);
    }

    private static void SetHeader(HttpRequestMessage request, string name, string? value)
    {
        request.Headers.Remove(name);
        if (!string.IsNullOrWhiteSpace(value)) request.Headers.TryAddWithoutValidation(name, value);
    }
}

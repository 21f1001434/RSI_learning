using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using DellUtilityService.API.Models.Agentic;
using Microsoft.Extensions.Options;

namespace DellUtilityService.API.AgenticIntegration;

public sealed class AgenticDataDisparityApiClient : IAgenticDataDisparityApiClient
{
    private readonly HttpClient _http;
    private readonly ILogger<AgenticDataDisparityApiClient> _logger;
    private readonly bool _includeSensitiveAudit;

    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true
    };

    public AgenticDataDisparityApiClient(
        HttpClient http,
        ILogger<AgenticDataDisparityApiClient> logger,
        IOptions<AgenticApiOptions> options)
    {
        _http = http;
        _logger = logger;
        _includeSensitiveAudit = !string.IsNullOrWhiteSpace(options.Value.InternalApiKey);
    }

    public Task<JsonDocument> GetLivenessAsync(CancellationToken cancellationToken = default) =>
        GetJsonAsync("api/v1/health/live", cancellationToken);

    public Task<JsonDocument> GetReadinessAsync(bool deep, CancellationToken cancellationToken = default) =>
        GetJsonAsync($"api/v1/health/ready?deep={deep.ToString().ToLowerInvariant()}", cancellationToken);

    public Task<JsonDocument> GetAdaptiveMemoryStatusAsync(CancellationToken cancellationToken = default) =>
        GetJsonAsync("api/v1/memory/status", cancellationToken);

    public Task<JsonDocument> CreateSessionAsync(
        SessionCreateProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/sessions", request, cancellationToken);

    public Task<JsonDocument> GetSessionAsync(
        string sessionId,
        bool includeMessages = true,
        CancellationToken cancellationToken = default) =>
        GetJsonAsync(
            $"api/v1/sessions/{Escape(sessionId)}?include_messages={includeMessages.ToString().ToLowerInvariant()}",
            cancellationToken);

    public Task<JsonDocument> ResetSessionAsync(
        string sessionId,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync($"api/v1/sessions/{Escape(sessionId)}/reset", new { }, cancellationToken);

    public Task<JsonDocument> DeleteSessionAsync(
        string sessionId,
        CancellationToken cancellationToken = default) =>
        DeleteJsonAsync($"api/v1/sessions/{Escape(sessionId)}", cancellationToken);

    public Task<JsonDocument> GetSessionActiveBatchAsync(
        string sessionId,
        CancellationToken cancellationToken = default) =>
        GetJsonAsync($"api/v1/sessions/{Escape(sessionId)}/active-batch", cancellationToken);

    public Task<JsonDocument> ChatAsync(
        ChatProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/chat", request, cancellationToken);

    public Task<JsonDocument> QueryCpsSourceAsync(
        CpsSourceQueryProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/source-operations/cps/query", request, cancellationToken);

    public Task<JsonDocument> QuerySourceAsync(
        SourceQueryProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/source-operations/query", request, cancellationToken);

    public Task<JsonDocument> PlanSourceChangeAsync(
        SourceChangePlanProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/source-operations/changes/plan", request, cancellationToken);

    public Task<JsonDocument> GetSourceChangeAsync(
        string changeId, string sessionId,
        CancellationToken cancellationToken = default) =>
        GetJsonAsync($"api/v1/source-operations/changes/{Escape(changeId)}?session_id={Escape(sessionId)}", cancellationToken);

    public Task<JsonDocument> ConfirmSourceChangeFirstAsync(
        string changeId, SourceChangeConfirmationProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync($"api/v1/source-operations/changes/{Escape(changeId)}/confirm-1", request, cancellationToken);

    public Task<JsonDocument> MarkSourceChangePopupOpenedAsync(
        string changeId, SourceChangePopupOpenedProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync($"api/v1/source-operations/changes/{Escape(changeId)}/popup-opened", request, cancellationToken);

    public Task<JsonDocument> ConfirmSourceChangeSecondAsync(
        string changeId, SourceChangeConfirmationProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync($"api/v1/source-operations/changes/{Escape(changeId)}/confirm-2", request, cancellationToken);

    public Task<JsonDocument> CancelSourceChangeAsync(
        string changeId, SourceChangeCancelProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync($"api/v1/source-operations/changes/{Escape(changeId)}/cancel", request, cancellationToken);

    public Task<JsonDocument> ImportSpreadsheetSourceChangesAsync(
        SpreadsheetSourceChangeImportProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/source-operations/spreadsheet-import", request, cancellationToken);

    public Task<JsonDocument> GetAuditTrailAsync(
        int limit = 100,
        string? source = null,
        string? status = null,
        string? actor = null,
        string? action = null,
        DateTime? fromUtc = null,
        DateTime? toUtc = null,
        CancellationToken cancellationToken = default)
    {
        var query = new List<string>
        {
            $"limit={Math.Clamp(limit, 1, 1000)}",
            $"include_sensitive={_includeSensitiveAudit.ToString().ToLowerInvariant()}"
        };
        if (!string.IsNullOrWhiteSpace(source)) query.Add($"source={Escape(source)}");
        if (!string.IsNullOrWhiteSpace(status)) query.Add($"status={Escape(status)}");
        if (!string.IsNullOrWhiteSpace(actor)) query.Add($"actor={Escape(actor)}");
        if (!string.IsNullOrWhiteSpace(action)) query.Add($"action={Escape(action)}");
        if (fromUtc.HasValue) query.Add($"from_utc={Escape(fromUtc.Value.ToUniversalTime().ToString("O"))}");
        if (toUtc.HasValue) query.Add($"to_utc={Escape(toUtc.Value.ToUniversalTime().ToString("O"))}");
        return GetJsonAsync($"api/v1/audit-trail?{string.Join("&", query)}", cancellationToken);
    }

    public Task<JsonDocument> AnalyzeAsync(
        IndividualAnalysisProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/analysis/individual", request, cancellationToken);

    public Task<JsonDocument> GetAnalysisAsync(
        string runId,
        bool masked = false,
        CancellationToken cancellationToken = default) =>
        GetJsonAsync($"api/v1/analysis/{Escape(runId)}?masked={masked.ToString().ToLowerInvariant()}", cancellationToken);

    public Task<HttpResponseMessage> GetHtmlReportResponseAsync(
        string runId,
        bool masked = false,
        CancellationToken cancellationToken = default) =>
        SendRawAsync(HttpMethod.Get, $"api/v1/analysis/{Escape(runId)}/report.html?masked={masked.ToString().ToLowerInvariant()}", null, cancellationToken);

    public Task<HttpResponseMessage> GetJsonReportResponseAsync(
        string runId,
        bool masked = false,
        CancellationToken cancellationToken = default) =>
        SendRawAsync(HttpMethod.Get, $"api/v1/analysis/{Escape(runId)}/report.json?masked={masked.ToString().ToLowerInvariant()}", null, cancellationToken);

    public Task<JsonDocument> SubmitBatchAsync(
        BatchEmailsProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/batches", request, cancellationToken);

    public async Task<JsonDocument> UploadBatchAsync(
        Stream stream,
        string fileName,
        string? sessionId,
        int maxParallel,
        int maxParallelAi,
        bool includeGroupAi,
        CancellationToken cancellationToken = default)
    {
        using var multipart = new MultipartFormDataContent();
        using var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType = new MediaTypeHeaderValue(
            fileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase)
                ? "text/csv"
                : "text/plain");
        multipart.Add(fileContent, "file", fileName);

        var query = new List<string>
        {
            "max_parallel=8",
            "max_parallel_ai=2",
            "include_group_ai=true"
        };
        if (!string.IsNullOrWhiteSpace(sessionId))
        {
            query.Add($"session_id={Escape(sessionId)}");
        }

        using var response = await _http.PostAsync(
            $"api/v1/batches/upload?{string.Join("&", query)}",
            multipart,
            cancellationToken);
        return await ParseJsonOrThrowAsync(response, cancellationToken);
    }

    public Task<JsonDocument> GetBatchAsync(
        string jobId,
        CancellationToken cancellationToken = default) =>
        GetJsonAsync($"api/v1/batches/{Escape(jobId)}", cancellationToken);

    public Task<JsonDocument> GetBatchSummaryAsync(
        string jobId,
        CancellationToken cancellationToken = default) =>
        GetJsonAsync($"api/v1/batches/{Escape(jobId)}/summary", cancellationToken);

    public Task<HttpResponseMessage> GetBatchDownloadResponseAsync(
        string jobId,
        bool masked = false,
        CancellationToken cancellationToken = default) =>
        SendRawAsync(HttpMethod.Get, $"api/v1/batches/{Escape(jobId)}/download?masked={masked.ToString().ToLowerInvariant()}", null, cancellationToken);

    public Task<JsonDocument> GetKnowledgeCatalogAsync(CancellationToken cancellationToken = default) =>
        GetJsonAsync("api/v1/knowledge/catalog", cancellationToken);

    public Task<JsonDocument> GetOperationAsync(
        string operationId,
        CancellationToken cancellationToken = default) =>
        GetJsonAsync($"api/v1/knowledge/operations/{Escape(operationId)}", cancellationToken);

    public Task<JsonDocument> ValidatePayloadAsync(
        PayloadValidationProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/knowledge/validate-payload", request, cancellationToken);

    public Task<JsonDocument> GetUseCasesAsync(
        string runId,
        CancellationToken cancellationToken = default) =>
        GetJsonAsync($"api/v1/analysis/{Escape(runId)}/use-cases", cancellationToken);

    public Task<JsonDocument> CompileUseCasePlanAsync(
        UseCasePlanProxyRequest request,
        CancellationToken cancellationToken = default) =>
        PostJsonAsync("api/v1/use-cases/plan", request, cancellationToken);

    private async Task<JsonDocument> GetJsonAsync(string path, CancellationToken cancellationToken)
    {
        using var response = await _http.GetAsync(path, cancellationToken);
        return await ParseJsonOrThrowAsync(response, cancellationToken);
    }

    private async Task<JsonDocument> DeleteJsonAsync(string path, CancellationToken cancellationToken)
    {
        using var response = await _http.DeleteAsync(path, cancellationToken);
        return await ParseJsonOrThrowAsync(response, cancellationToken);
    }

    private async Task<JsonDocument> PostJsonAsync<T>(
        string path,
        T body,
        CancellationToken cancellationToken)
    {
        using var response = await _http.PostAsJsonAsync(path, body, JsonOptions, cancellationToken);
        return await ParseJsonOrThrowAsync(response, cancellationToken);
    }

    private async Task<HttpResponseMessage> SendRawAsync(
        HttpMethod method,
        string path,
        HttpContent? content,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(method, path) { Content = content };
        return await _http.SendAsync(
            request,
            HttpCompletionOption.ResponseHeadersRead,
            cancellationToken);
    }

    private async Task<JsonDocument> ParseJsonOrThrowAsync(
        HttpResponseMessage response,
        CancellationToken cancellationToken)
    {
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Agentic API returned {StatusCode}: {ResponseBody}",
                (int)response.StatusCode,
                Limit(body, 2000));
            throw new AgenticApiUpstreamException(
                "The Agentic Data Disparity API rejected the request.",
                response.StatusCode,
                body);
        }

        try
        {
            return JsonDocument.Parse(body);
        }
        catch (JsonException ex)
        {
            throw new AgenticApiUpstreamException(
                "The Agentic Data Disparity API returned invalid JSON.",
                response.StatusCode,
                Limit(body, 4000),
                ex);
        }
    }

    private static string Escape(string value) => Uri.EscapeDataString(value.Trim());

    private static string Limit(string value, int maxLength) =>
        value.Length <= maxLength ? value : value[..maxLength] + "…";
}

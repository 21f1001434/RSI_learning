using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Nodes;
using DellUtilityService.API.AgenticIntegration;
using DellUtilityService.API.Models.Agentic;
using DellUtilityService.API.Services.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DellUtilityService.API.Controllers;

/// <summary>
/// Backward-compatible routes for the original RUS AI page.
/// All analysis is delegated to the Dell AIA + AutoGen Python service so the
/// .NET application has one source of business truth and no duplicate analysis logic.
/// New clients should use /api/agentic-ai/*.
/// </summary>
[ApiController]
[Authorize(Policy = "AllRoles")]
[Route("api/[controller]")]
public sealed class AIAnalysisController : ControllerBase
{
    private readonly IAgenticDataDisparityApiClient _client;
    private readonly ILogger<AIAnalysisController> _logger;

    public AIAnalysisController(
        IAgenticDataDisparityApiClient client,
        ILogger<AIAnalysisController> logger)
    {
        _client = client;
        _logger = logger;
    }

    [HttpGet("analyze")]
    public async Task<IActionResult> AnalyzeData(
        [FromQuery] string searchType,
        [FromQuery] string searchValue,
        [FromQuery] string? sessionId = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var profile = CurrentProfile();
            var analysisRequest = new IndividualAnalysisProxyRequest
            {
                SearchType = NormalizeSearchType(searchType),
                SearchValue = searchValue,
                SessionId = sessionId,
                IncludeRawSourceData = profile.Permissions.ViewTechnicalDetails,
                IncludeHtml = false,
                MaskReportValues = !profile.Permissions.ViewUnmaskedReports,
                Actor = CurrentUsername(),
                ActorEmail = User.FindFirstValue(ClaimTypes.Email) ?? User.FindFirstValue("email"),
                ActorRole = profile.Code,
                ActorId = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub")
            };
            using var document = await _client.AnalyzeAsync(analysisRequest, cancellationToken);
            return Content(ProjectLegacyPayload(document.RootElement.GetRawText(), profile), "application/json");
        }
        catch (AgenticApiUpstreamException ex)
        {
            return UpstreamError(ex, "Legacy analysis request failed.");
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            _logger.LogError(ex, "Agentic API is unavailable");
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                success = false,
                error = new { code = "AGENTIC_API_UNAVAILABLE", message = "The Agentic AI service is unavailable or timed out." },
                requestId = HttpContext.TraceIdentifier
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Legacy analysis proxy failed");
            return StatusCode(StatusCodes.Status502BadGateway, new
            {
                success = false,
                error = new { code = "AGENTIC_PROXY_ERROR", message = "The Agentic analysis proxy failed." },
                requestId = HttpContext.TraceIdentifier
            });
        }
    }

    [HttpGet("quick-action")]
    public async Task<IActionResult> QuickAction(
        [FromQuery] string action,
        [FromQuery] string? sessionId = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(sessionId))
            {
                var sessionRequest = new SessionCreateProxyRequest();
                sessionRequest.Metadata["actor"] = CurrentUsername();
                sessionRequest.Metadata["actor_username"] = CurrentUsername();
                sessionRequest.Metadata["actor_email"] = User.FindFirstValue(ClaimTypes.Email) ?? User.FindFirstValue("email");
                sessionRequest.Metadata["actor_role"] = CurrentProfile().Code;
                sessionRequest.Metadata["actor_id"] = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");
                using var created = await _client.CreateSessionAsync(sessionRequest, cancellationToken);
                sessionId = created.RootElement
                    .GetProperty("data")
                    .GetProperty("session_id")
                    .GetString();
            }

            var normalized = action.Trim().ToLowerInvariant() switch
            {
                "missing_properties" => "suggestions",
                "data_mismatch" => "summary",
                "data_quality" => "source_health",
                _ => "help"
            };

            using var document = await _client.ChatAsync(
                new ChatProxyRequest
                {
                    SessionId = sessionId ?? string.Empty,
                    Message = normalized,
                    Action = normalized,
                    JudgeResponse = true,
                    Actor = CurrentUsername(),
                    ActorEmail = User.FindFirstValue(ClaimTypes.Email) ?? User.FindFirstValue("email"),
                    ActorRole = CurrentProfile().Code
                },
                cancellationToken);
            return Content(document.RootElement.GetRawText(), "application/json");
        }
        catch (AgenticApiUpstreamException ex)
        {
            return UpstreamError(ex, "Legacy quick action failed.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Legacy quick action failed");
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                success = false,
                error = new { code = "AGENTIC_API_UNAVAILABLE", message = "The Agentic AI service is unavailable." },
                requestId = HttpContext.TraceIdentifier
            });
        }
    }

    private IActionResult UpstreamError(AgenticApiUpstreamException exception, string fallback)
    {
        _logger.LogWarning(exception, "{Fallback}", fallback);
        if (!string.IsNullOrWhiteSpace(exception.UpstreamBody))
        {
            return new ContentResult
            {
                StatusCode = exception.StatusCode is null ? 502 : (int)exception.StatusCode.Value,
                ContentType = "application/json",
                Content = exception.UpstreamBody
            };
        }

        return StatusCode(exception.StatusCode is null ? 502 : (int)exception.StatusCode.Value, new
        {
            success = false,
            error = new { code = "AGENTIC_API_REJECTED", message = fallback },
            requestId = HttpContext.TraceIdentifier
        });
    }

    private static string ProjectLegacyPayload(string rawJson, RoleViewProfile profile)
    {
        if (profile.Permissions.ViewTechnicalDetails) return rawJson;
        var node = JsonNode.Parse(rawJson);
        if (node is null) return "{}";
        PruneLegacyNode(node, profile.Code == RusRoles.Customer);
        return node.ToJsonString(new JsonSerializerOptions(JsonSerializerDefaults.Web));
    }

    private static void PruneLegacyNode(JsonNode node, bool customer)
    {
        if (node is JsonArray array)
        {
            foreach (var item in array) if (item is not null) PruneLegacyNode(item, customer);
            return;
        }
        if (node is not JsonObject obj) return;
        foreach (var property in obj.ToList())
        {
            var key = new string(property.Key.Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());
            var hidden = key.Contains("raw", StringComparison.Ordinal) || key.Contains("payload", StringComparison.Ordinal) ||
                         key.Contains("header", StringComparison.Ordinal) || key.Contains("token", StringComparison.Ordinal) ||
                         key.Contains("identifierresolution", StringComparison.Ordinal) || key.Contains("sourcetiming", StringComparison.Ordinal) ||
                         key == "records" || key == "record" ||
                         (customer && (key.Contains("crowdtwistid", StringComparison.Ordinal) || key.Contains("memberkey", StringComparison.Ordinal) || key.Contains("cityid", StringComparison.Ordinal)));
            if (hidden) obj.Remove(property.Key);
            else if (property.Value is not null) PruneLegacyNode(property.Value, customer);
        }
    }

    private string CurrentUsername() =>
        User.FindFirstValue("preferred_username") ??
        User.Identity?.Name ??
        User.FindFirstValue(ClaimTypes.Name) ??
        "Unknown user";

    private RoleViewProfile CurrentProfile()
    {
        var role = User.FindFirstValue(ClaimTypes.Role) ?? User.FindFirstValue("role") ?? RusRoles.Customer;
        return RusRoles.Profile(role);
    }

    private static string NormalizeSearchType(string? value) =>
        (value ?? "email").Trim().ToLowerInvariant() switch
        {
            "profileid" or "profile_id" or "profile-id" => "profileid",
            "crowdtwistid" or "crowd_twist_id" or "crowdtwist_id" or "crowd-twist-id" => "crowdtwistid",
            _ => "email"
        };
}

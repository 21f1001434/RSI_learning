using System.Net;
using System.Security.Cryptography;
using System.Text;
using DellUtilityService.API.AgenticIntegration;
using DellUtilityService.API.Configurations;
using DellUtilityService.API.Data;
using DellUtilityService.API.Models;
using DellUtilityService.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace DellUtilityService.API.Controllers;

/// <summary>
/// Loopback-only bridge used by the Python Agentic orchestrator for the final
/// physical source mutation. The bridge deliberately calls the same .NET
/// services used by the manual Rewards DB and CrowdTwist tabs so there is one
/// write contract, not parallel implementations that can drift.
/// </summary>
[ApiController]
[AllowAnonymous]
[Route("api/internal/source-write")]
public sealed class InternalSourceWriteController : ControllerBase
{
    private readonly IRewardsDbOperationsV2 _rewardsDb;
    private readonly ILoyaltyServiceProviderV3 _crowdTwist;
    private readonly AgenticApiOptions _agenticOptions;
    private readonly VaultConfigurations _vault;
    private readonly IConfiguration _configuration;
    private readonly ILogger<InternalSourceWriteController> _logger;

    public InternalSourceWriteController(
        IRewardsDbOperationsV2 rewardsDb,
        ILoyaltyServiceProviderV3 crowdTwist,
        IOptions<AgenticApiOptions> agenticOptions,
        IOptions<VaultConfigurations> vault,
        IConfiguration configuration,
        ILogger<InternalSourceWriteController> logger)
    {
        _rewardsDb = rewardsDb;
        _crowdTwist = crowdTwist;
        _agenticOptions = agenticOptions.Value;
        _vault = vault.Value;
        _configuration = configuration;
        _logger = logger;
    }

    [HttpGet("capabilities")]
    public IActionResult Capabilities()
    {
        if (!IsAuthorizedInternalCaller())
        {
            return Unauthorized(new { success = false, code = "INTERNAL_KEY_INVALID" });
        }

        var crowdTwistWriteConfigured =
            !string.IsNullOrWhiteSpace(_vault.CTLayer7AuthTokenURL) &&
            !string.IsNullOrWhiteSpace(_vault.CTLayer7ApiExtURL) &&
            !string.IsNullOrWhiteSpace(_vault.CTLayer7ExtClientId) &&
            !string.IsNullOrWhiteSpace(_vault.CTLayer7ExtSecret) &&
            !string.IsNullOrWhiteSpace(_vault.CrowdTwistApiKey);
        var rewardsDbConfigured = !string.IsNullOrWhiteSpace(_vault.DellRewardsConnection) ||
                                  !string.IsNullOrWhiteSpace(_configuration.GetConnectionString("DefaultConnection"));

        return Ok(new
        {
            success = true,
            sharedManualUpdateContract = true,
            authenticationMode = string.IsNullOrWhiteSpace(_agenticOptions.InternalApiKey)
                ? "loopback-only-manual"
                : "loopback-plus-internal-key",
            rewardsDb = new
            {
                configured = rewardsDbConfigured,
                implementation = "RewardsDbOperationsV2.UpdateMemberColumnAsync"
            },
            crowdTwist = new
            {
                configured = crowdTwistWriteConfigured,
                implementation = "LoyaltyServiceProviderV3.UpdateUserProfilePropertiesAsync",
                countryExpansion = "CrowdTwistUpdateContract"
            }
        });
    }

    [HttpPost]
    public async Task<IActionResult> Write([FromBody] InternalSourceWriteRequest request)
    {
        if (!IsAuthorizedInternalCaller())
        {
            return Unauthorized(new { success = false, code = "INTERNAL_KEY_INVALID" });
        }

        if (string.IsNullOrWhiteSpace(request.Source) || string.IsNullOrWhiteSpace(request.Field))
        {
            return BadRequest(new { success = false, code = "INVALID_REQUEST", message = "Source and field are required." });
        }

        var source = request.Source.Trim().ToLowerInvariant().Replace("_", string.Empty).Replace(" ", string.Empty);
        try
        {
            return source switch
            {
                "rewardsdb" or "rewards" => await WriteRewardsDb(request),
                "crowdtwist" or "ct" => await WriteCrowdTwist(request),
                _ => BadRequest(new { success = false, code = "SOURCE_NOT_WRITABLE", message = "Only Rewards DB and CrowdTwist are writable through this bridge." })
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Internal Agentic source write failed for {Source} field {Field}", request.Source, request.Field);
            return StatusCode(500, new
            {
                success = false,
                code = "MANUAL_WRITE_SERVICE_EXCEPTION",
                message = ex.Message,
                source = request.Source,
                field = request.Field
            });
        }
    }

    private async Task<IActionResult> WriteRewardsDb(InternalSourceWriteRequest request)
    {
        if (!Guid.TryParse(request.TargetId, out var memberId))
        {
            return BadRequest(new { success = false, code = "MEMBER_ID_INVALID", message = "Rewards DB internal member Id is invalid." });
        }

        var before = await _rewardsDb.GetMemberByIdAsync(memberId);
        if (before is null)
        {
            return NotFound(new { success = false, code = "TARGET_NOT_FOUND", message = "Rewards DB member was not found." });
        }

        var beforeValue = ReadRewardsValue(before, request.Field);
        var updated = await _rewardsDb.UpdateMemberColumnAsync(memberId, request.Field, request.NewValue ?? string.Empty);
        var after = updated ? await _rewardsDb.GetMemberByIdAsync(memberId) : null;
        var afterValue = after is null ? null : ReadRewardsValue(after, request.Field);

        if (!updated)
        {
            return BadRequest(new
            {
                success = false,
                code = "MANUAL_REWARDS_UPDATE_FAILED",
                message = "RewardsDbOperationsV2.UpdateMemberColumnAsync returned false.",
                source = "Rewards DB",
                field = request.Field,
                before = beforeValue
            });
        }

        return Ok(new
        {
            success = true,
            source = "Rewards DB",
            implementation = "RewardsDbOperationsV2.UpdateMemberColumnAsync",
            field = request.Field,
            before = beforeValue,
            after = afterValue,
            targetId = memberId
        });
    }

    private async Task<IActionResult> WriteCrowdTwist(InternalSourceWriteRequest request)
    {
        if (!int.TryParse(request.TargetId, out var crowdTwistId))
        {
            return BadRequest(new { success = false, code = "CROWD_TWIST_ID_INVALID", message = "CrowdTwist ID is invalid." });
        }

        // This is exactly the same logical property expansion used by the manual
        // CrowdTwist controller. Country updates therefore include the required
        // country_code/postal_code/city_id combination instead of a bare country PUT.
        var effectiveProperties = CrowdTwistUpdateContract.ExpandProperties(request.Field, request.NewValue ?? string.Empty);
        var beforeUser = await _crowdTwist.SearchLoyaltyMemberAsync(Search.SearchType.Id, crowdTwistId.ToString());
        if (beforeUser is null)
        {
            return NotFound(new { success = false, code = "TARGET_NOT_FOUND", message = "CrowdTwist member was not found." });
        }

        var before = effectiveProperties.ToDictionary(
            pair => pair.Key,
            pair => CrowdTwistUpdateContract.ReadProperty(beforeUser, pair.Key),
            StringComparer.OrdinalIgnoreCase);

        var updated = await _crowdTwist.UpdateUserProfilePropertiesAsync(crowdTwistId, effectiveProperties);
        var afterUser = updated
            ? await _crowdTwist.SearchLoyaltyMemberAsync(Search.SearchType.Id, crowdTwistId.ToString())
            : null;
        var after = effectiveProperties.ToDictionary(
            pair => pair.Key,
            pair => afterUser is null ? null : CrowdTwistUpdateContract.ReadProperty(afterUser, pair.Key),
            StringComparer.OrdinalIgnoreCase);

        if (!updated)
        {
            return BadRequest(new
            {
                success = false,
                code = "MANUAL_CROWD_TWIST_UPDATE_FAILED",
                message = "LoyaltyServiceProviderV3.UpdateUserProfilePropertiesAsync returned false.",
                source = "CrowdTwist",
                field = request.Field,
                effectiveProperties,
                before
            });
        }

        return Ok(new
        {
            success = true,
            source = "CrowdTwist",
            implementation = "LoyaltyServiceProviderV3.UpdateUserProfilePropertiesAsync",
            field = request.Field,
            before,
            after,
            effectiveProperties,
            targetId = crowdTwistId
        });
    }

    private bool IsAuthorizedInternalCaller()
    {
        var remoteIp = HttpContext.Connection.RemoteIpAddress;
        if (remoteIp is null || !IPAddress.IsLoopback(remoteIp)) return false;

        var configured = (_agenticOptions.InternalApiKey ?? string.Empty).Trim();

        // Manual-development mode: when the Dell Utility API and Agent API are
        // intentionally started in separate terminals, no ephemeral key is
        // injected. The bridge remains loopback-only, so permit the local Agent
        // process without a key. The one-click launcher still injects a random
        // key; whenever a key is configured it is strictly required.
        if (configured.Length == 0)
        {
            return true;
        }

        var supplied = Request.Headers["X-Internal-API-Key"].FirstOrDefault() ?? string.Empty;
        if (supplied.Length == 0) return false;

        var configuredBytes = Encoding.UTF8.GetBytes(configured);
        var suppliedBytes = Encoding.UTF8.GetBytes(supplied);
        return configuredBytes.Length == suppliedBytes.Length &&
               CryptographicOperations.FixedTimeEquals(configuredBytes, suppliedBytes);
    }

    private static object? ReadRewardsValue(Member member, string field)
    {
        var normalized = (field ?? string.Empty).Trim().ToLowerInvariant().Replace("_", string.Empty);
        return normalized switch
        {
            "country" or "countrycode" => member.CountryCode,
            "isactive" => member.IsActive,
            "crowdtwistid" => member.CrowdTwistID,
            "memberkey" => member.MemberKey,
            "profileid" => member.ProfileId,
            _ => null
        };
    }
}

public sealed class InternalSourceWriteRequest
{
    public string Source { get; set; } = string.Empty;
    public string TargetId { get; set; } = string.Empty;
    public string Field { get; set; } = string.Empty;
    public string? NewValue { get; set; }
    public string? CorrelationId { get; set; }
}

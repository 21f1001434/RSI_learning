using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Nodes;
using DellUtilityService.API.Data;
using DellUtilityService.API.Models;
using DellUtilityService.API.Services;
using DellUtilityService.API.Services.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DellUtilityService.API.Controllers;

[ApiController]
[Authorize(Policy = "AllRoles")]
[Route("api/[controller]")]
public class SearchController : ControllerBase
{
    private readonly IRewardsDbOperationsV2 _rewardsDbOperations;
    private readonly ILoyaltyServiceProviderV3 _loyaltyServiceProvider;
    private readonly ICPSService _cpsService;
    private readonly ILogger<SearchController> _logger;

    public SearchController(
        IRewardsDbOperationsV2 rewardsDbOperations,
        ILoyaltyServiceProviderV3 loyaltyServiceProvider,
        ICPSService cpsService,
        ILogger<SearchController> logger)
    {
        _rewardsDbOperations = rewardsDbOperations;
        _loyaltyServiceProvider = loyaltyServiceProvider;
        _cpsService = cpsService;
        _logger = logger;
    }

    [HttpGet("by-email")]
    public async Task<IActionResult> SearchByEmail([FromQuery] string email)
    {
        try
        {
            var result = new SearchResult { Email = email };
            var crowdTwistUser = await _loyaltyServiceProvider.SearchLoyaltyMemberAsync(Search.SearchType.Email, email);
            result.CrowdTwistData = crowdTwistUser;
            var cpsUser = await _cpsService.GetUserAsync(email);
            result.CPSData = cpsUser;
            result.MemberData = await GetUserDataFromDb(cpsUser?.ProfileId ?? Guid.Empty, crowdTwistUser?.CrowdTwistId ?? 0);
            return Ok(new { success = true, data = result });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error searching by email");
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpGet("by-profile-id")]
    public async Task<IActionResult> SearchByProfileId([FromQuery] Guid profileId)
    {
        try
        {
            var result = new SearchResult { ProfileId = profileId };
            var crowdTwistUser = await _loyaltyServiceProvider.SearchLoyaltyMemberAsync(
                Search.SearchType.ThirdPartyId,
                profileId.ToString().ToUpperInvariant());
            result.CrowdTwistData = crowdTwistUser;
            var cpsUser = await _cpsService.GetUserByProfileIdAsync(profileId);
            result.CPSData = cpsUser;
            result.MemberData = await GetUserDataFromDb(cpsUser?.ProfileId ?? Guid.Empty, crowdTwistUser?.CrowdTwistId ?? 0);
            return Ok(new { success = true, data = result });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error searching by profile ID");
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    private static SearchResult ProjectForCurrentRole(SearchResult result) => result;

    // Legacy projection hook retained as a no-op. Manual Unified Search is identical for every role in v11.27.
    private static void PruneForRole(JsonNode node, string role) { }

    private async Task<Member?> GetUserDataFromDb(Guid profileId, long crowdTwistId)
    {
        if (profileId != Guid.Empty)
        {
            var member = await _rewardsDbOperations.GetMemberByProfileIdAsync(profileId);
            if (member is null && crowdTwistId > 0)
            {
                member = await _rewardsDbOperations.GetMemberByCrowdTwistIdAsync(crowdTwistId);
            }
            return member;
        }
        return crowdTwistId > 0
            ? await _rewardsDbOperations.GetMemberByCrowdTwistIdAsync(crowdTwistId)
            : null;
    }
}

public class SearchResult
{
    public string? Email { get; set; }
    public Guid? ProfileId { get; set; }
    public Member? MemberData { get; set; }
    public UserDetailsResponse? CrowdTwistData { get; set; }
    public CPSProfileData? CPSData { get; set; }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DellUtilityService.API.Services;

namespace DellUtilityService.API.Controllers;

// Legacy v11.17 policy marker retained for regression history: [Authorize(Policy = "CpsRead")]

[ApiController]
[Authorize(Policy = "AllRoles")]
[Route("api/[controller]")]
public class CPSController : ControllerBase
{
    private readonly ICPSService _cpsService;
    private readonly ILogger<CPSController> _logger;
    private readonly IAuditTrailService _auditTrail;
    private readonly IAuditActorResolver _actorResolver;

    public CPSController(
        ICPSService cpsService,
        ILogger<CPSController> logger,
        IAuditTrailService auditTrail,
        IAuditActorResolver actorResolver)
    {
        _cpsService = cpsService;
        _logger = logger;
        _auditTrail = auditTrail;
        _actorResolver = actorResolver;
    }

    [HttpPost("create-user")]
    public async Task<ActionResult<CPSUser>> CreateUser([FromBody] CPSUserRequest request)
    {
        try
        {
            var actor = _actorResolver.Resolve();
            var user = await _cpsService.CreateUserAsync(request);
            if (user == null)
            {
                await _auditTrail.AppendAsync(new AuditTrailEntry
                {
                    Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                    Source = "CPS", Action = "Create user", Status = "Failed",
                    Target = request.Email, Field = "profile", Before = null,
                    After = new { request.Email, request.FirstName, request.LastName, request.Country },
                    Reason = "Manual CPS create button", CorrelationId = HttpContext.TraceIdentifier,
                    Verification = "CPS returned no created profile"
                }, HttpContext.RequestAborted);
                return BadRequest(new { success = false, message = "Failed to create CPS user" });
            }
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "CPS", Action = "Create user", Status = "Completed",
                Target = request.Email, Field = "profile", Before = null, After = user,
                Reason = "Manual CPS create button", CorrelationId = HttpContext.TraceIdentifier,
                Verification = "Created profile returned by CPS"
            }, HttpContext.RequestAborted);
            return Ok(new { success = true, data = user });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating CPS user");
            var actor = _actorResolver.Resolve();
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "CPS", Action = "Create user", Status = "Failed",
                Target = request.Email, Field = "profile", After = request,
                Reason = "Manual CPS create button", CorrelationId = HttpContext.TraceIdentifier,
                Verification = ex.GetType().Name,
                Details = new() { ["error"] = ex.Message }
            }, HttpContext.RequestAborted);
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpGet("get-user/{email}")]
    public async Task<ActionResult<CPSUser>> GetUser(string email)
    {
        try
        {
            var user = await _cpsService.GetUserAsync(email);
            if (user == null)
            {
                return NotFound(new { success = false, message = "User not found in CPS" });
            }
            return Ok(new { success = true, data = user });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting CPS user");
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpGet("get-user-by-profile/{profileId}")]
    public async Task<ActionResult<CPSUser>> GetUserByProfileId(Guid profileId)
    {
        try
        {
            var user = await _cpsService.GetUserByProfileIdAsync(profileId);
            if (user == null)
            {
                return NotFound(new { success = false, message = "User not found in CPS" });
            }
            return Ok(new { success = true, data = user });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting CPS user by profile ID");
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }
}

using System.Security.Claims;
using System.Text.Json;
using DellUtilityService.API.AgenticIntegration;
using DellUtilityService.API.Services;
using DellUtilityService.API.Services.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DellUtilityService.API.Controllers;

[ApiController]
[Authorize]
[Route("api/audit-trail")]
public sealed class AuditTrailController : ControllerBase
{
    private readonly IAuditTrailService _manualAudit;
    private readonly IAgenticDataDisparityApiClient _agenticClient;
    private readonly IAuditPrivacyService _privacy;
    private readonly ILogger<AuditTrailController> _logger;

    public AuditTrailController(
        IAuditTrailService manualAudit,
        IAgenticDataDisparityApiClient agenticClient,
        IAuditPrivacyService privacy,
        ILogger<AuditTrailController> logger)
    {
        _manualAudit = manualAudit;
        _agenticClient = agenticClient;
        _privacy = privacy;
        _logger = logger;
    }

    [HttpGet]
    public async Task<IActionResult> Get(
        [FromQuery] int limit = 100,
        [FromQuery] string? source = null,
        [FromQuery] string? status = null,
        [FromQuery] string? actor = null,
        [FromQuery] string? action = null,
        [FromQuery] bool? masked = null,
        [FromQuery] DateTime? fromUtc = null,
        [FromQuery] DateTime? toUtc = null,
        CancellationToken cancellationToken = default)
    {
        var identity = CurrentIdentity();
        var role = RusRoles.Normalize(identity.Role);
        var profile = RusRoles.Profile(role);
        var isAdmin = RusRoles.IsAdmin(role);
        var effectiveActorFilter = isAdmin ? actor : identity.Username;
        var effectiveMasked = isAdmin ? false : masked ?? profile.DefaultAuditMasked;

        var manual = await _manualAudit.QueryAsync(
            1000, source, status, effectiveActorFilter, action, fromUtc, toUtc, cancellationToken);
        var merged = manual.Entries.Select(ToDictionary).ToList();
        var upstreamAvailable = true;
        string? upstreamError = null;

        try
        {
            using var upstream = await _agenticClient.GetAuditTrailAsync(
                1000, source, status, effectiveActorFilter, action, fromUtc, toUtc, cancellationToken);
            var root = upstream.RootElement;
            var data = root.TryGetProperty("data", out var envelopeData) ? envelopeData : root;
            if (data.TryGetProperty("entries", out var entries) && entries.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in entries.EnumerateArray())
                {
                    var dictionary = JsonSerializer.Deserialize<Dictionary<string, object?>>(
                        item.GetRawText(), new JsonSerializerOptions(JsonSerializerDefaults.Web));
                    if (dictionary is not null) merged.Add(dictionary);
                }
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            upstreamAvailable = false;
            upstreamError = "The browser cancelled the Agentic audit request.";
            _logger.LogInformation("Agentic audit request was cancelled during browser navigation; returning manual audit entries only.");
        }
        catch (OperationCanceledException)
        {
            upstreamAvailable = false;
            upstreamError = "The Agentic audit service timed out.";
            _logger.LogWarning("Agentic audit service timed out; returning manual audit entries only.");
        }
        catch (Exception ex)
        {
            upstreamAvailable = false;
            upstreamError = ex.Message;
            _logger.LogWarning(ex, "Agentic audit trail is unavailable; returning manual audit entries only.");
        }

        if (!isAdmin)
        {
            merged = merged.Where(entry => IsOwnedBy(entry, identity)).ToList();
        }

        var filtered = merged
            .Where(entry => Matches(entry, "source", source))
            .Where(entry => Matches(entry, "status", status))
            .Where(entry => Matches(entry, "action", action))
            .Where(entry => isAdmin && !string.IsNullOrWhiteSpace(actor) ? ActorContains(entry, actor) : true)
            .ToList();

        var orderedUnmasked = filtered
            .OrderByDescending(entry => ParseTimestamp(Value(entry, "timestampUtc", "timestamp_utc", "timestamp")))
            .ToList();
        var summary = BuildSummary(orderedUnmasked);
        var ordered = orderedUnmasked
            .Take(Math.Clamp(limit, 1, 1000))
            .Select(entry => ShapeEntryForRole(entry, profile))
            .Select(entry => effectiveMasked ? MaskEntry(entry) : entry)
            .ToList();

        Response.Headers.CacheControl = "no-store";
        return Ok(new
        {
            success = true,
            data = new
            {
                entries = ordered,
                summary,
                scope = new
                {
                    role,
                    roleLabel = profile.Label,
                    dashboardMode = profile.DashboardMode,
                    allUsers = profile.Permissions.ViewAllAudit,
                    username = identity.Username,
                    privacyMode = effectiveMasked ? "masked" : "unmasked",
                    defaultPrivacyMode = profile.DefaultAuditMasked ? "masked" : "unmasked",
                    canSelectPrivacy = profile.Permissions.SelectAuditPrivacy,
                    canManageUsers = profile.Permissions.ManageUsers,
                    canViewTechnicalDetails = profile.Permissions.ViewTechnicalDetails,
                    canExportAudit = profile.Permissions.ExportAudit
                },
                agenticAuditAvailable = upstreamAvailable,
                agenticAuditError = upstreamError
            },
            requestId = HttpContext.TraceIdentifier
        });
    }

    private static Dictionary<string, object?> ShapeEntryForRole(
        Dictionary<string, object?> source,
        RoleViewProfile profile)
    {
        var result = new Dictionary<string, object?>(source, StringComparer.OrdinalIgnoreCase);
        if (profile.Permissions.ViewTechnicalDetails) return result;

        // Customer Support and Business views preserve the accountable business
        // before/after values but remove internal payloads, identifiers, and raw
        // diagnostic metadata that are useful only to Technical or Admin users.
        foreach (var key in new[]
        {
            "details", "correlationId", "correlation_id", "auditId", "audit_id",
            "actorId", "actor_id", "actorEmail", "actor_email"
        }) result.Remove(key);

        var verification = ToText(Value(result, "verification"));
        if (!string.IsNullOrWhiteSpace(verification) && verification.Length > 180)
        {
            result["verification"] = verification[..180] + "…";
        }
        return result;
    }

    private Dictionary<string, object?> MaskEntry(Dictionary<string, object?> source)
    {
        var result = new Dictionary<string, object?>(source, StringComparer.OrdinalIgnoreCase);
        foreach (var key in new[] { "target", "before", "after", "reason", "details", "actorEmail", "actor_email" })
        {
            if (result.TryGetValue(key, out var value)) result[key] = _privacy.Mask(value, key);
        }
        return result;
    }

    private static object BuildSummary(List<Dictionary<string, object?>> entries)
    {
        var statusCounts = CountBy(entries, "status");
        var sourceCounts = CountBy(entries, "source");
        var actorCounts = entries
            .GroupBy(ActorKey, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.Count(), StringComparer.OrdinalIgnoreCase);

        var correlated = entries
            .Select(entry => new { Entry = entry, Correlation = CorrelationKey(entry) })
            .Where(item => !string.IsNullOrWhiteSpace(item.Correlation))
            .GroupBy(item => item.Correlation!, StringComparer.OrdinalIgnoreCase)
            .Select(group => group
                .OrderByDescending(item => ParseTimestamp(Value(item.Entry, "timestampUtc", "timestamp_utc", "timestamp")))
                .First().Entry)
            .ToList();
        var uncorrelated = entries.Where(entry => string.IsNullOrWhiteSpace(CorrelationKey(entry))).ToList();
        var currentStates = correlated.Concat(uncorrelated).ToList();

        return new
        {
            total = entries.Count,
            completed = entries.Count(entry => IsCompleted(Status(entry))),
            failed = entries.Count(entry => IsFailed(Status(entry))),
            pending = currentStates.Count(entry => IsPending(Status(entry))),
            uniqueActors = actorCounts.Count,
            statusCounts,
            sourceCounts,
            actorCounts
        };
    }

    private static bool IsOwnedBy(Dictionary<string, object?> entry, AuditIdentity identity)
    {
        var candidates = new[]
        {
            Value(entry, "actorUsername", "actor_username", "actor"),
            Value(entry, "actorId", "actor_id"),
            Value(entry, "actorEmail", "actor_email"),
            NestedValue(entry, "details", "actorUsername"),
            NestedValue(entry, "details", "plannedBy"),
            NestedValue(entry, "details", "firstApprovedBy"),
            NestedValue(entry, "details", "secondApprovedBy")
        }.Select(ToText).Where(value => !string.IsNullOrWhiteSpace(value));

        return candidates.Any(candidate =>
            candidate.Equals(identity.Username, StringComparison.OrdinalIgnoreCase) ||
            (!string.IsNullOrWhiteSpace(identity.UserId) && candidate.Equals(identity.UserId, StringComparison.OrdinalIgnoreCase)) ||
            (!string.IsNullOrWhiteSpace(identity.Email) && candidate.Equals(identity.Email, StringComparison.OrdinalIgnoreCase)));
    }

    private static bool Matches(Dictionary<string, object?> entry, string key, string? expected) =>
        string.IsNullOrWhiteSpace(expected) || ToText(Value(entry, key)).Contains(expected, StringComparison.OrdinalIgnoreCase);

    private static bool ActorContains(Dictionary<string, object?> entry, string expected) =>
        new[] { "actor", "actorUsername", "actor_username", "actorEmail", "actor_email", "actorDisplayName", "actor_display_name" }
            .Any(key => ToText(Value(entry, key)).Contains(expected, StringComparison.OrdinalIgnoreCase));

    private AuditIdentity CurrentIdentity() => new(
        User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub") ?? string.Empty,
        User.FindFirstValue("preferred_username") ?? User.Identity?.Name ?? User.FindFirstValue(ClaimTypes.Name) ?? "Unknown user",
        User.FindFirstValue(ClaimTypes.Email) ?? User.FindFirstValue("email"),
        User.FindFirstValue(ClaimTypes.Role) ?? User.FindFirstValue("role") ?? RusRoles.Customer);

    private static Dictionary<string, object?> ToDictionary(AuditTrailEntry item) => new(StringComparer.OrdinalIgnoreCase)
    {
        ["auditId"] = item.AuditId,
        ["timestampUtc"] = item.TimestampUtc,
        ["actor"] = item.Actor,
        ["actorDisplayName"] = item.ActorDisplayName,
        ["actorId"] = item.ActorId,
        ["actorUsername"] = item.ActorUsername,
        ["actorEmail"] = item.ActorEmail,
        ["actorRole"] = item.ActorRole,
        ["channel"] = item.Channel,
        ["source"] = item.Source,
        ["action"] = item.Action,
        ["status"] = item.Status,
        ["target"] = item.Target,
        ["field"] = item.Field,
        ["before"] = item.Before,
        ["after"] = item.After,
        ["reason"] = item.Reason,
        ["correlationId"] = item.CorrelationId,
        ["verification"] = item.Verification,
        ["details"] = item.Details
    };

    private static string Status(Dictionary<string, object?> entry) => ToText(Value(entry, "status"));
    private static bool IsCompleted(string value) => HasAny(value, "completed", "success", "verified", "dry_run");
    private static bool IsFailed(string value) => HasAny(value, "failed", "partial", "blocked", "aborted", "error");
    private static bool IsPending(string value) => HasAny(value, "awaiting", "executing", "planned", "started", "pending", "queued");
    private static bool HasAny(string value, params string[] tokens) => tokens.Any(token => value.Contains(token, StringComparison.OrdinalIgnoreCase));

    private static string? CorrelationKey(Dictionary<string, object?> entry)
    {
        var value = ToText(Value(entry, "correlationId", "correlation_id"));
        if (!string.IsNullOrWhiteSpace(value)) return value;
        value = ToText(NestedValue(entry, "details", "changeId"));
        if (!string.IsNullOrWhiteSpace(value)) return value;
        value = ToText(NestedValue(entry, "details", "runId"));
        return string.IsNullOrWhiteSpace(value) ? null : value;
    }

    private static string ActorKey(Dictionary<string, object?> entry)
    {
        var value = ToText(Value(entry, "actorUsername", "actor_username", "actor"));
        return string.IsNullOrWhiteSpace(value) ? "Unknown user" : value;
    }

    private static Dictionary<string, int> CountBy(IEnumerable<Dictionary<string, object?>> entries, string key) =>
        entries.GroupBy(entry => GroupValue(entry, key), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.Count(), StringComparer.OrdinalIgnoreCase);

    private static string GroupValue(Dictionary<string, object?> entry, string key)
    {
        var value = ToText(Value(entry, key));
        return string.IsNullOrWhiteSpace(value) ? "Unknown" : value;
    }

    private static object? Value(Dictionary<string, object?> entry, params string[] names)
    {
        foreach (var name in names)
        {
            var pair = entry.FirstOrDefault(item => item.Key.Equals(name, StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrEmpty(pair.Key)) return pair.Value;
        }
        return null;
    }

    private static object? NestedValue(Dictionary<string, object?> entry, string objectKey, string propertyName)
    {
        var value = Value(entry, objectKey);
        if (value is JsonElement element && element.ValueKind == JsonValueKind.Object && element.TryGetProperty(propertyName, out var property)) return property;
        if (value is Dictionary<string, object?> dictionary) return Value(dictionary, propertyName);
        return null;
    }

    private static string ToText(object? value)
    {
        if (value is null) return string.Empty;
        if (value is JsonElement element)
        {
            return element.ValueKind == JsonValueKind.String ? element.GetString() ?? string.Empty : element.ToString();
        }
        return Convert.ToString(value) ?? string.Empty;
    }

    private static DateTime ParseTimestamp(object? value) =>
        DateTime.TryParse(ToText(value), out var parsed) ? parsed.ToUniversalTime() : DateTime.MinValue;

    private sealed record AuditIdentity(string UserId, string Username, string? Email, string Role);
}

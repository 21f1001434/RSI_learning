using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DellUtilityService.API.Services;
using DellUtilityService.API.Models;
using ClosedXML.Excel;
using System.Collections.Concurrent;
using Newtonsoft.Json.Linq;

namespace DellUtilityService.API.Controllers;

// Legacy v11.17 policy marker retained for regression history: [Authorize(Policy = "TechnicalOperations")]

[ApiController]
[Authorize(Policy = "AllRoles")]
[Route("api/[controller]")]
public class CrowdTwistController : ControllerBase
{
    private readonly ILoyaltyServiceProviderV3 _loyaltyServiceProvider;
    private readonly ILogger<CrowdTwistController> _logger;
    private readonly IAuditTrailService _auditTrail;
    private readonly IAuditActorResolver _actorResolver;

    public CrowdTwistController(
        ILoyaltyServiceProviderV3 loyaltyServiceProvider,
        ILogger<CrowdTwistController> logger,
        IAuditTrailService auditTrail,
        IAuditActorResolver actorResolver)
    {
        _loyaltyServiceProvider = loyaltyServiceProvider;
        _logger = logger;
        _auditTrail = auditTrail;
        _actorResolver = actorResolver;
    }

    [HttpGet("search")]
    public async Task<ActionResult<UserDetailsResponse>> SearchMember([FromQuery] string searchType, [FromQuery] string searchValue)
    {
        try
        {
            var searchTypeEnum = searchType.ToLower() switch
            {
                "id" => Search.SearchType.Id,
                "email" => Search.SearchType.Email,
                "profileid" or "profile_id" or "third_party_id" => Search.SearchType.ThirdPartyId,
                _ => Search.SearchType.Email
            };
            var user = await _loyaltyServiceProvider.SearchLoyaltyMemberAsync(searchTypeEnum, searchValue);
            if (user == null)
            {
                return NotFound(new { success = false, message = "Member not found in CrowdTwist" });
            }
            return Ok(new { success = true, data = user });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { success = false, code = "CROWD_TWIST_SEARCH_INVALID", message = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogWarning(ex, "CrowdTwist search is not configured correctly");
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                success = false,
                code = "CROWD_TWIST_CONFIGURATION_ERROR",
                message = ex.Message
            });
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "CrowdTwist search upstream call failed");
            return StatusCode(StatusCodes.Status502BadGateway, new
            {
                success = false,
                code = "CROWD_TWIST_UPSTREAM_ERROR",
                message = ex.Message
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected CrowdTwist search failure");
            return StatusCode(500, new
            {
                success = false,
                code = "CROWD_TWIST_SEARCH_ERROR",
                message = "CrowdTwist search failed unexpectedly. Check the Dell Utility API terminal for details."
            });
        }
    }

    [HttpPost("update-property")]
    public async Task<ActionResult> UpdateUserProfileProperty([FromBody] CrowdTwistPropertyUpdateRequest request)
    {
        var actor = _actorResolver.Resolve();
        var properties = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            [request.PropertyName] = request.NewValue
        };

        if (CrowdTwistUpdateContract.IsCountryProperty(request.PropertyName))
        {
            properties = CrowdTwistUpdateContract.ExpandCountryProperties(request.NewValue);
        }

        var beforeValues = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
        var afterValues = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);

        try
        {
            var beforeUser = await _loyaltyServiceProvider.SearchLoyaltyMemberAsync(
                Search.SearchType.Id,
                request.CrowdTwistId.ToString());

            foreach (var propertyName in properties.Keys)
            {
                beforeValues[propertyName] = CrowdTwistUpdateContract.ReadProperty(beforeUser, propertyName);
            }

            var result = await _loyaltyServiceProvider.UpdateUserProfilePropertiesAsync(
                request.CrowdTwistId,
                properties);

            if (result)
            {
                var afterUser = await _loyaltyServiceProvider.SearchLoyaltyMemberAsync(
                    Search.SearchType.Id,
                    request.CrowdTwistId.ToString());

                foreach (var propertyName in properties.Keys)
                {
                    afterValues[propertyName] = CrowdTwistUpdateContract.ReadProperty(afterUser, propertyName) ?? properties[propertyName];
                }
            }
            else
            {
                foreach (var property in properties)
                {
                    afterValues[property.Key] = property.Value;
                }
            }

            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name,
                ActorEmail = actor.Email,
                Channel = actor.Channel,
                Source = "CrowdTwist",
                Action = CrowdTwistUpdateContract.IsCountryProperty(request.PropertyName) ? "Update country properties" : "Update property",
                Status = result ? "Completed" : "Failed",
                Target = request.CrowdTwistId.ToString(),
                Field = CrowdTwistUpdateContract.IsCountryProperty(request.PropertyName)
                    ? "country_code, postal_code, city_id"
                    : request.PropertyName,
                Before = CrowdTwistUpdateContract.IsCountryProperty(request.PropertyName) ? beforeValues : beforeValues.GetValueOrDefault(request.PropertyName),
                After = CrowdTwistUpdateContract.IsCountryProperty(request.PropertyName) ? afterValues : afterValues.GetValueOrDefault(request.PropertyName),
                Reason = "Manual CrowdTwist update button",
                CorrelationId = HttpContext.TraceIdentifier,
                Verification = result ? "Read-after-write completed" : "CrowdTwist API returned false",
                Details = new()
                {
                    ["requestedProperty"] = request.PropertyName,
                    ["requestedValue"] = request.NewValue,
                    ["expandedProperties"] = properties
                }
            }, HttpContext.RequestAborted);

            if (!result)
            {
                return BadRequest(new { success = false, message = "Failed to update CrowdTwist property" });
            }

            return Ok(new
            {
                success = true,
                message = "Property updated successfully",
                updatedProperties = properties
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating CrowdTwist property");
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name,
                ActorEmail = actor.Email,
                Channel = actor.Channel,
                Source = "CrowdTwist",
                Action = CrowdTwistUpdateContract.IsCountryProperty(request.PropertyName) ? "Update country properties" : "Update property",
                Status = "Failed",
                Target = request.CrowdTwistId.ToString(),
                Field = CrowdTwistUpdateContract.IsCountryProperty(request.PropertyName)
                    ? "country_code, postal_code, city_id"
                    : request.PropertyName,
                Before = beforeValues,
                After = properties,
                Reason = "Manual CrowdTwist update button",
                CorrelationId = HttpContext.TraceIdentifier,
                Verification = ex.GetType().Name,
                Details = new()
                {
                    ["error"] = ex.Message,
                    ["requestedProperty"] = request.PropertyName,
                    ["requestedValue"] = request.NewValue,
                    ["expandedProperties"] = properties
                }
            }, HttpContext.RequestAborted);

            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpPost("bulk-update-properties")]
    public async Task<ActionResult> BulkUpdateUserProfileProperties([FromBody] CrowdTwistBulkPropertyUpdateRequest request)
    {
        var actor = _actorResolver.Resolve();
        var properties = new Dictionary<string, string>(
            request.Properties ?? new Dictionary<string, string>(),
            StringComparer.OrdinalIgnoreCase);
        var beforeValues = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
        var afterValues = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);

        try
        {
            // Expand a country update into the exact CrowdTwist location fields.
            foreach (var key in properties.Keys.ToList())
            {
                if (!CrowdTwistUpdateContract.IsCountryProperty(key))
                {
                    continue;
                }

                var countryValue = properties[key];
                properties.Remove(key);

                var expandedProperties = CrowdTwistUpdateContract.ExpandCountryProperties(countryValue);
                foreach (var property in expandedProperties)
                {
                    properties[property.Key] = property.Value;
                }

                // Country, countryCode and country_code represent the same logical update.
                // Expand only once when more than one alias is present.
                break;
            }

            var beforeUser = await _loyaltyServiceProvider.SearchLoyaltyMemberAsync(
                Search.SearchType.Id,
                request.CrowdTwistId.ToString());

            foreach (var propertyName in properties.Keys)
            {
                beforeValues[propertyName] = CrowdTwistUpdateContract.ReadProperty(beforeUser, propertyName);
            }

            var result = await _loyaltyServiceProvider.UpdateUserProfilePropertiesAsync(
                request.CrowdTwistId,
                properties);

            if (result)
            {
                var afterUser = await _loyaltyServiceProvider.SearchLoyaltyMemberAsync(
                    Search.SearchType.Id,
                    request.CrowdTwistId.ToString());

                foreach (var propertyName in properties.Keys)
                {
                    afterValues[propertyName] = CrowdTwistUpdateContract.ReadProperty(afterUser, propertyName) ?? properties[propertyName];
                }
            }
            else
            {
                foreach (var property in properties)
                {
                    afterValues[property.Key] = property.Value;
                }
            }

            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name,
                ActorEmail = actor.Email,
                Channel = actor.Channel,
                Source = "CrowdTwist",
                Action = "Bulk update properties",
                Status = result ? "Completed" : "Failed",
                Target = request.CrowdTwistId.ToString(),
                Field = "multiple",
                Before = beforeValues,
                After = afterValues,
                Reason = "Manual CrowdTwist bulk property request",
                CorrelationId = HttpContext.TraceIdentifier,
                Verification = result ? "Read-after-write completed" : "CrowdTwist API returned false",
                Details = new()
                {
                    ["requestedProperties"] = request.Properties,
                    ["effectiveProperties"] = properties
                }
            }, HttpContext.RequestAborted);

            if (!result)
            {
                return BadRequest(new { success = false, message = "Failed to bulk update CrowdTwist properties" });
            }

            return Ok(new
            {
                success = true,
                message = "Properties updated successfully",
                updatedProperties = properties
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in bulk update of CrowdTwist properties");
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name,
                ActorEmail = actor.Email,
                Channel = actor.Channel,
                Source = "CrowdTwist",
                Action = "Bulk update properties",
                Status = "Failed",
                Target = request.CrowdTwistId.ToString(),
                Field = "multiple",
                Before = beforeValues,
                After = properties,
                Reason = "Manual CrowdTwist bulk property request",
                CorrelationId = HttpContext.TraceIdentifier,
                Verification = ex.GetType().Name,
                Details = new()
                {
                    ["error"] = ex.Message,
                    ["requestedProperties"] = request.Properties,
                    ["effectiveProperties"] = properties
                }
            }, HttpContext.RequestAborted);

            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpPost("bulkupdate")]
    public async Task<IActionResult> BulkUpdateCrowdTwist(IFormFile file)
    {
        try
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { error = "No file uploaded" });
            }

            var actor = _actorResolver.Resolve();
            var updateItems = await ReadCrowdTwistExcelFile(file);
            var results = await ProcessCrowdTwistBulkUpdate(updateItems, actor);
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "CrowdTwist", Action = "Bulk update", Status = results.All(x => x.Status == "Success") ? "Completed" : results.Any(x => x.Status == "Success") ? "Partial" : "Failed",
                Target = file.FileName, Field = "multiple", Before = null,
                After = new { total = results.Count, success = results.Count(x => x.Status == "Success"), failed = results.Count(x => x.Status != "Success") },
                Reason = "Manual CrowdTwist bulk upload", CorrelationId = HttpContext.TraceIdentifier,
                Verification = "Per-row results generated"
            }, HttpContext.RequestAborted);
            var excelBytes = GenerateResultExcel(results, "CrowdTwist");

            return File(excelBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"CrowdTwist_BulkUpdate_Result_{DateTime.UtcNow:yyyyMMdd_HHmmss}.xlsx");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in CrowdTwist bulk update");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    private async Task<List<BulkUpdateItem>> ReadCrowdTwistExcelFile(IFormFile file)
    {
        var items = new List<BulkUpdateItem>();

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);
        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheet(1);

        var lastRow = worksheet.LastRowUsed();
        if (lastRow is null)
        {
            return items;
        }

        var rowCount = lastRow.RowNumber();
        for (int row = 2; row <= rowCount; row++)
        {
            var item = new BulkUpdateItem
            {
                CrowdTwistId = worksheet.Cell(row, 1).GetValue<int?>(),
                PropertyName = worksheet.Cell(row, 2).GetString(),
                PropertyValue = worksheet.Cell(row, 3).GetString()
            };
            items.Add(item);
        }

        return items;
    }

    private async Task<List<BulkUpdateItem>> ProcessCrowdTwistBulkUpdate(List<BulkUpdateItem> items, AuditActor actor)
    {
        var results = new ConcurrentBag<BulkUpdateItem>();
        var parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = 10 };

        await Parallel.ForEachAsync(items, parallelOptions, async (item, cancellationToken) =>
        {
            try
            {
                if (!item.CrowdTwistId.HasValue || string.IsNullOrEmpty(item.PropertyName))
                {
                    results.Add(new BulkUpdateItem
                    {
                        CrowdTwistId = item.CrowdTwistId,
                        PropertyName = item.PropertyName,
                        PropertyValue = item.PropertyValue,
                        Status = "Failed",
                        Comments = "Missing CrowdTwistId or PropertyName"
                    });
                    return;
                }

                var rowProperties = CrowdTwistUpdateContract.IsCountryProperty(item.PropertyName)
                    ? CrowdTwistUpdateContract.ExpandCountryProperties(item.PropertyValue)
                    : new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                    {
                        [item.PropertyName] = item.PropertyValue
                    };

                var success = await _loyaltyServiceProvider.UpdateUserProfilePropertiesAsync(
                    item.CrowdTwistId.Value,
                    rowProperties);

                results.Add(new BulkUpdateItem
                {
                    CrowdTwistId = item.CrowdTwistId,
                    PropertyName = item.PropertyName,
                    PropertyValue = item.PropertyValue,
                    Status = success ? "Success" : "Failed",
                    Comments = success ? "" : "CrowdTwist API returned false"
                });
            }
            catch (Exception ex)
            {
                results.Add(new BulkUpdateItem
                {
                    CrowdTwistId = item.CrowdTwistId,
                    PropertyName = item.PropertyName,
                    PropertyValue = item.PropertyValue,
                    Status = "Failed",
                    Comments = ex.Message
                });
            }
        });

        foreach (var item in results)
        {
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "CrowdTwist", Action = "Bulk row update", Status = item.Status == "Success" ? "Completed" : "Failed",
                Target = item.CrowdTwistId?.ToString(), Field = item.PropertyName, Before = null, After = item.PropertyValue,
                Reason = "Manual CrowdTwist bulk upload", CorrelationId = HttpContext.TraceIdentifier,
                Verification = string.IsNullOrWhiteSpace(item.Comments) ? "CrowdTwist API returned success" : item.Comments
            }, HttpContext.RequestAborted);
        }

        return results.ToList();
    }

    private byte[] GenerateResultExcel(List<BulkUpdateItem> results, string updateType)
    {
        using var workbook = new XLWorkbook();
        var worksheet = workbook.Worksheets.Add("Results");

        worksheet.Cell(1, 1).Value = updateType == "CrowdTwist" ? "CrowdTwistId" : "MemberId";
        worksheet.Cell(1, 2).Value = "PropertyName";
        worksheet.Cell(1, 3).Value = "PropertyValue";
        worksheet.Cell(1, 4).Value = "Status";
        worksheet.Cell(1, 5).Value = "Comments";

        worksheet.Range(1, 1, 1, 5).Style.Font.Bold = true;
        worksheet.Range(1, 1, 1, 5).Style.Fill.BackgroundColor = XLColor.LightGray;

        for (int i = 0; i < results.Count; i++)
        {
            worksheet.Cell(i + 2, 1).Value = updateType == "CrowdTwist" ? results[i].CrowdTwistId?.ToString() : results[i].MemberId?.ToString();
            worksheet.Cell(i + 2, 2).Value = results[i].PropertyName;
            worksheet.Cell(i + 2, 3).Value = results[i].PropertyValue;
            worksheet.Cell(i + 2, 4).Value = results[i].Status;
            worksheet.Cell(i + 2, 5).Value = results[i].Comments;

            if (results[i].Status == "Success")
            {
                worksheet.Cell(i + 2, 4).Style.Fill.BackgroundColor = XLColor.LightGreen;
            }
            else
            {
                worksheet.Cell(i + 2, 4).Style.Fill.BackgroundColor = XLColor.LightPink;
            }
        }

        worksheet.Columns().AdjustToContents();

        using var stream = new MemoryStream();
        workbook.SaveAs(stream);
        return stream.ToArray();
    }
}

public class CrowdTwistPropertyUpdateRequest
{
    public int CrowdTwistId { get; set; }
    public string PropertyName { get; set; } = string.Empty;
    public string NewValue { get; set; } = string.Empty;
}

public class CrowdTwistBulkPropertyUpdateRequest
{
    public int CrowdTwistId { get; set; }
    public Dictionary<string, string> Properties { get; set; } = new();
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DellUtilityService.API.Services;
using DellUtilityService.API.Data;
using DellUtilityService.API.Models;
using ClosedXML.Excel;
using System.Collections.Concurrent;

namespace DellUtilityService.API.Controllers;

// Legacy v11.17 policy marker retained for regression history: [Authorize(Policy = "TechnicalOperations")]

[ApiController]
[Authorize(Policy = "AllRoles")]
[Route("api/[controller]")]
public class MembersController : ControllerBase
{
    private readonly IRewardsDbOperationsV2 _rewardsDbOperations;
    private readonly ILogger<MembersController> _logger;
    private readonly IAuditTrailService _auditTrail;
    private readonly IAuditActorResolver _actorResolver;

    public MembersController(
        IRewardsDbOperationsV2 rewardsDbOperations,
        ILogger<MembersController> logger,
        IAuditTrailService auditTrail,
        IAuditActorResolver actorResolver)
    {
        _rewardsDbOperations = rewardsDbOperations;
        _logger = logger;
        _auditTrail = auditTrail;
        _actorResolver = actorResolver;
    }

    [HttpGet("get-by-id/{id}")]
    public async Task<ActionResult<Member>> GetMemberById(Guid id)
    {
        try
        {
            var member = await _rewardsDbOperations.GetMemberByIdAsync(id);
            if (member == null)
            {
                return NotFound(new { success = false, message = "Member not found" });
            }
            return Ok(new { success = true, data = member });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting member by ID");
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpGet("get-by-profile/{profileId}")]
    public async Task<ActionResult<Member>> GetMemberByProfileId(Guid profileId)
    {
        try
        {
            var member = await _rewardsDbOperations.GetMemberByProfileIdAsync(profileId);
            if (member == null)
            {
                return NotFound(new { success = false, message = "Member not found" });
            }
            return Ok(new { success = true, data = member });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting member by profile ID");
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpGet("search")]
    public async Task<ActionResult<List<Member>>> SearchMembers([FromQuery] string searchTerm)
    {
        try
        {
            var members = await _rewardsDbOperations.SearchMembersAsync(searchTerm);
            if (!members.Any())
            {
                return NotFound(new { success = false, message = "No members found" });
            }
            return Ok(new { success = true, data = members });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error searching members");
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpPost("update-column")]
    public async Task<ActionResult> UpdateMemberColumn([FromBody] MemberColumnUpdateRequest request)
    {
        var actor = _actorResolver.Resolve();
        object? beforeValue = null;
        try
        {
            var beforeMember = await _rewardsDbOperations.GetMemberByIdAsync(request.Id);
            beforeValue = ReadProperty(beforeMember, request.ColumnName);
            var result = await _rewardsDbOperations.UpdateMemberColumnAsync(request.Id, request.ColumnName, request.NewValue);
            var afterMember = result ? await _rewardsDbOperations.GetMemberByIdAsync(request.Id) : null;
            var afterValue = result ? ReadProperty(afterMember, request.ColumnName) : request.NewValue;
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "Rewards DB", Action = "Update column", Status = result ? "Completed" : "Failed",
                Target = request.Id.ToString(), Field = request.ColumnName, Before = beforeValue, After = afterValue,
                Reason = "Manual Rewards DB update button", CorrelationId = HttpContext.TraceIdentifier,
                Verification = result ? "Read-after-write completed" : "Update API returned false"
            }, HttpContext.RequestAborted);
            if (!result)
            {
                return BadRequest(new { success = false, message = "Failed to update member column" });
            }
            return Ok(new { success = true, message = "Column updated successfully" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating member column");
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "Rewards DB", Action = "Update column", Status = "Failed",
                Target = request.Id.ToString(), Field = request.ColumnName, Before = beforeValue, After = request.NewValue,
                Reason = "Manual Rewards DB update button", CorrelationId = HttpContext.TraceIdentifier,
                Verification = ex.GetType().Name, Details = new() { ["error"] = ex.Message }
            }, HttpContext.RequestAborted);
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpPost("bulk-update-columns")]
    public async Task<ActionResult<BulkOperation>> BulkUpdateMemberColumns([FromBody] List<MemberColumnUpdateRequest> requests)
    {
        var actor = _actorResolver.Resolve();
        try
        {
            var result = await _rewardsDbOperations.BulkUpdateMemberColumnAsync(requests);
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "Rewards DB", Action = "Bulk update columns", Status = "Completed",
                Target = $"{requests.Count} member request(s)", Field = "multiple", Before = null,
                After = requests.Select(item => new { memberId = item.Id, field = item.ColumnName, value = item.NewValue }).ToList(),
                Reason = "Manual Rewards DB bulk request", CorrelationId = HttpContext.TraceIdentifier,
                Verification = "Bulk operation returned successfully", Details = new() { ["operation"] = result }
            }, HttpContext.RequestAborted);
            return Ok(new { success = true, data = result });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in bulk update of member columns");
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "Rewards DB", Action = "Bulk update columns", Status = "Failed",
                Target = $"{requests.Count} member request(s)", Field = "multiple", Before = null,
                After = requests.Select(item => new { memberId = item.Id, field = item.ColumnName, value = item.NewValue }).ToList(),
                Reason = "Manual Rewards DB bulk request", CorrelationId = HttpContext.TraceIdentifier,
                Verification = ex.GetType().Name, Details = new() { ["error"] = ex.Message }
            }, HttpContext.RequestAborted);
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }

    [HttpPost("bulkupdate")]
    public async Task<IActionResult> BulkUpdateMemberDB(IFormFile file)
    {
        try
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { error = "No file uploaded" });
            }

            var actor = _actorResolver.Resolve();
            var updateItems = await ReadMemberDBExcelFile(file);
            var results = await ProcessMemberDBBulkUpdate(updateItems, actor);
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "Rewards DB", Action = "Bulk update", Status = results.All(x => x.Status == "Success") ? "Completed" : results.Any(x => x.Status == "Success") ? "Partial" : "Failed",
                Target = file.FileName, Field = "multiple", Before = null,
                After = new { total = results.Count, success = results.Count(x => x.Status == "Success"), failed = results.Count(x => x.Status != "Success") },
                Reason = "Manual Rewards DB bulk upload", CorrelationId = HttpContext.TraceIdentifier,
                Verification = "Per-row results generated"
            }, HttpContext.RequestAborted);
            var excelBytes = GenerateResultExcel(results, "MemberDB");

            return File(excelBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"MemberDB_BulkUpdate_Result_{DateTime.UtcNow:yyyyMMdd_HHmmss}.xlsx");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in Member DB bulk update");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    private async Task<List<BulkUpdateItem>> ReadMemberDBExcelFile(IFormFile file)
    {
        var items = new List<BulkUpdateItem>();

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);
        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheet(1);

        var rowCount = worksheet.LastRowUsed().RowNumber();
        for (int row = 2; row <= rowCount; row++)
        {
            var item = new BulkUpdateItem
            {
                MemberId = worksheet.Cell(row, 1).GetValue<Guid?>(),
                PropertyName = worksheet.Cell(row, 2).GetString(),
                PropertyValue = worksheet.Cell(row, 3).GetString()
            };
            items.Add(item);
        }

        return items;
    }

    private async Task<List<BulkUpdateItem>> ProcessMemberDBBulkUpdate(List<BulkUpdateItem> items, AuditActor actor)
    {
        var results = new ConcurrentBag<BulkUpdateItem>();
        var parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = 10 };

        await Parallel.ForEachAsync(items, parallelOptions, async (item, cancellationToken) =>
        {
            try
            {
                if (!item.MemberId.HasValue || string.IsNullOrEmpty(item.PropertyName))
                {
                    results.Add(new BulkUpdateItem
                    {
                        MemberId = item.MemberId,
                        PropertyName = item.PropertyName,
                        PropertyValue = item.PropertyValue,
                        Status = "Failed",
                        Comments = "Missing MemberId or PropertyName"
                    });
                    return;
                }

                var success = await _rewardsDbOperations.UpdateMemberColumnByIdAsync(
                    item.MemberId.Value,
                    item.PropertyName,
                    item.PropertyValue);

                results.Add(new BulkUpdateItem
                {
                    MemberId = item.MemberId,
                    PropertyName = item.PropertyName,
                    PropertyValue = item.PropertyValue,
                    Status = success ? "Success" : "Failed",
                    Comments = success ? "" : "Database update failed"
                });
            }
            catch (Exception ex)
            {
                results.Add(new BulkUpdateItem
                {
                    MemberId = item.MemberId,
                    PropertyName = item.PropertyName,
                    PropertyValue = item.PropertyValue,
                    Status = "Failed",
                    Comments = ex.Message
                });
            }
        });

        foreach (var item in results)
        {
            await _auditTrail.AppendAsync(new AuditTrailEntry
            {
                Actor = actor.Name, ActorEmail = actor.Email, Channel = actor.Channel,
                Source = "Rewards DB", Action = "Bulk row update", Status = item.Status == "Success" ? "Completed" : "Failed",
                Target = item.MemberId?.ToString(), Field = item.PropertyName, Before = null, After = item.PropertyValue,
                Reason = "Manual Rewards DB bulk upload", CorrelationId = HttpContext.TraceIdentifier,
                Verification = string.IsNullOrWhiteSpace(item.Comments) ? "Update API returned success" : item.Comments
            }, HttpContext.RequestAborted);
        }

        return results.ToList();
    }

    private static object? ReadProperty(Member? member, string propertyName)
    {
        if (member is null || string.IsNullOrWhiteSpace(propertyName)) return null;
        var property = typeof(Member).GetProperties()
            .FirstOrDefault(item => item.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase));
        return property?.GetValue(member);
    }

    private byte[] GenerateResultExcel(List<BulkUpdateItem> results, string updateType)
    {
        using var workbook = new XLWorkbook();
        var worksheet = workbook.Worksheets.Add("Results");

        worksheet.Cell(1, 1).Value = updateType == "CrowdTwist" ? "CrowdTwistId" : "MemberId";
        worksheet.Cell(1, 2).Value = "PropertyName";
        worksheet.Cell(1, 3).Value = "PropertyValue";
        worksheet.Cell(1, 4).Value = "Status";
        worksheet.Cell(1, 5).Value = "Comments";

        worksheet.Range(1, 1, 1, 5).Style.Font.Bold = true;
        worksheet.Range(1, 1, 1, 5).Style.Fill.BackgroundColor = XLColor.LightGray;

        for (int i = 0; i < results.Count; i++)
        {
            worksheet.Cell(i + 2, 1).Value = updateType == "CrowdTwist" ? results[i].CrowdTwistId?.ToString() : results[i].MemberId?.ToString();
            worksheet.Cell(i + 2, 2).Value = results[i].PropertyName;
            worksheet.Cell(i + 2, 3).Value = results[i].PropertyValue;
            worksheet.Cell(i + 2, 4).Value = results[i].Status;
            worksheet.Cell(i + 2, 5).Value = results[i].Comments;

            if (results[i].Status == "Success")
            {
                worksheet.Cell(i + 2, 4).Style.Fill.BackgroundColor = XLColor.LightGreen;
            }
            else
            {
                worksheet.Cell(i + 2, 4).Style.Fill.BackgroundColor = XLColor.LightPink;
            }
        }

        worksheet.Columns().AdjustToContents();

        using var stream = new MemoryStream();
        workbook.SaveAs(stream);
        return stream.ToArray();
    }
}

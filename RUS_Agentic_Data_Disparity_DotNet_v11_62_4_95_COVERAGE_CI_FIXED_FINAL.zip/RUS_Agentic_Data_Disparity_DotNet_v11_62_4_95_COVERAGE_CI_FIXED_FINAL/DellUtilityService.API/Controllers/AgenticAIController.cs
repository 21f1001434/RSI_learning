using ClosedXML.Excel;
using System.Net;
using System.IO.Compression;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using DellUtilityService.API.AgenticIntegration;
using DellUtilityService.API.Models.Agentic;
using DellUtilityService.API.Services;
using DellUtilityService.API.Services.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace DellUtilityService.API.Controllers;

[ApiController]
[Authorize(Policy = "AllRoles")]
[Route("api/agentic-ai")]
[Produces("application/json")]
public sealed class AgenticAIController : ControllerBase
{
    private const long MaxUploadBytes = 5_000_000;

    private readonly IAgenticDataDisparityApiClient _client;
    private readonly AgenticApiOptions _options;
    private readonly ILogger<AgenticAIController> _logger;
    private readonly IAuditActorResolver _actorResolver;

    public AgenticAIController(
        IAgenticDataDisparityApiClient client,
        IOptions<AgenticApiOptions> options,
        ILogger<AgenticAIController> logger,
        IAuditActorResolver actorResolver)
    {
        _client = client;
        _options = options.Value;
        _logger = logger;
        _actorResolver = actorResolver;
    }

    [HttpGet("configuration")]
    public IActionResult GetConfiguration()
    {
        var profile = CurrentRoleProfile();
        var data = new Dictionary<string, object?>
        {
            ["proxy"] = "DellUtilityService.API",
            ["role"] = profile.Code,
            ["roleLabel"] = profile.Label,
            ["dashboardMode"] = profile.DashboardMode,
            ["maxUploadBytes"] = Math.Min(_options.MaxUploadBytes, (int)MaxUploadBytes),
            ["sessionMemory"] = "Server-side session memory; browser stores only the session ID",
            ["dryRunEnabled"] = CurrentDryRunEnabled(),
            ["effectiveWriteMode"] = CurrentEffectiveWriteMode(),
            ["upstreamContractVersion"] = "v1",
            ["upstreamLayout"] = "src-template",
            ["features"] = profile.Permissions
        };
        if (profile.Permissions.ViewTechnicalDetails)
        {
            data["upstreamConfigured"] = !string.IsNullOrWhiteSpace(_options.BaseUrl);
            data["internalApiKeyConfigured"] = !string.IsNullOrWhiteSpace(_options.InternalApiKey);
            data["recommendedSourceParallelism"] = _options.RecommendedSourceParallelism;
            data["recommendedAiParallelism"] = _options.RecommendedAiParallelism;
            data["includeGroupedAiByDefault"] = _options.IncludeGroupedAiByDefault;
            data["batchPollIntervalSeconds"] = _options.BatchPollIntervalSeconds;
        }
        return Ok(new { success = true, data, requestId = HttpContext.TraceIdentifier });
    }

    [HttpPost("bootstrap")]
    public async Task<IActionResult> Bootstrap(
        [FromBody] AgenticBootstrapRequest? request,
        CancellationToken cancellationToken)
    {
        try
        {
            var health = await GetResilientHealthAsync(request?.DeepHealth ?? false, cancellationToken);
            JsonElement sessionData;
            var reused = false;

            var requestedSessionId = request?.SessionId;
            if (!string.IsNullOrWhiteSpace(requestedSessionId))
            {
                try
                {
                    using var existing = await _client.GetSessionAsync(requestedSessionId, true, cancellationToken);
                    sessionData = ExtractData(existing).Clone();
                    reused = true;
                }
                catch (AgenticApiUpstreamException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
                {
                    using var created = await _client.CreateSessionAsync(
                        NewSessionRequest(_actorResolver.Resolve()), cancellationToken);
                    sessionData = ExtractData(created).Clone();
                }
            }
            else
            {
                using var created = await _client.CreateSessionAsync(
                    NewSessionRequest(_actorResolver.Resolve()), cancellationToken);
                sessionData = ExtractData(created).Clone();
            }

            var profile = CurrentRoleProfile();
            var bootstrapData = new Dictionary<string, object?>
            {
                ["health"] = ProjectHealthForRole(health, profile),
                ["session"] = sessionData,
                ["sessionReused"] = reused,
                ["batchPollIntervalSeconds"] = _options.BatchPollIntervalSeconds,
                ["dryRunEnabled"] = CurrentDryRunEnabled(),
                ["effectiveWriteMode"] = CurrentEffectiveWriteMode()
            };
            if (profile.Permissions.ViewTechnicalDetails)
            {
                bootstrapData["recommendedSourceParallelism"] = _options.RecommendedSourceParallelism;
                bootstrapData["recommendedAiParallelism"] = _options.RecommendedAiParallelism;
                bootstrapData["includeGroupedAi"] = _options.IncludeGroupedAiByDefault;
            }
            if (RusRoles.Normalize(profile.Code) == RusRoles.Admin)
            {
                bootstrapData["batchMode"] = "admin-configurable";
            }
            else
            {
                bootstrapData["batchMode"] = "managed";
                bootstrapData["managedSourceParallelism"] = 8;
                bootstrapData["managedAiParallelism"] = 2;
                bootstrapData["managedGroupedAi"] = true;
            }
            return Ok(new { success = true, data = bootstrapData, requestId = HttpContext.TraceIdentifier });
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            _logger.LogDebug("Agentic bootstrap request was cancelled by the browser.");
            return StatusCode(499);
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Unable to bootstrap the Agentic AI session.");
        }
    }

    [HttpGet("health/live")]
    public Task<IActionResult> GetLiveness(CancellationToken cancellationToken) =>
        ProxyJsonAsync(() => _client.GetLivenessAsync(cancellationToken), "Agentic API liveness check failed.");

    [HttpGet("health/ready")]
    public async Task<IActionResult> GetReadiness(
        [FromQuery] bool deep = false,
        CancellationToken cancellationToken = default)
    {
        var profile = CurrentRoleProfile();
        try
        {
            var health = await GetResilientHealthAsync(
                deep && profile.Permissions.ViewTechnicalDetails, cancellationToken);
            Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            return Ok(new
            {
                success = true,
                data = ProjectHealthForRole(health, profile),
                requestId = HttpContext.TraceIdentifier
            });
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            _logger.LogDebug("Agentic readiness request was cancelled by the browser.");
            return StatusCode(499);
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Agentic API readiness check failed.");
        }
    }

    [HttpGet("memory/status")]
    public Task<IActionResult> GetAdaptiveMemoryStatus(CancellationToken cancellationToken) =>
        ProxyJsonAsync(
            () => _client.GetAdaptiveMemoryStatusAsync(cancellationToken),
            "Unable to retrieve bounded adaptive-memory status.");

    [HttpPost("sessions")]
    public Task<IActionResult> CreateSession(
        [FromBody] SessionCreateProxyRequest request,
        CancellationToken cancellationToken)
    {
        ApplyActorMetadata(request.Metadata, _actorResolver.Resolve());
        return ProxyJsonAsync(() => _client.CreateSessionAsync(request, cancellationToken), "Unable to create the AI chat session.", StatusCodes.Status201Created);
    }


    [HttpGet("sessions/{sessionId}")]
    public Task<IActionResult> GetSession(
        string sessionId,
        [FromQuery] bool includeMessages = true,
        CancellationToken cancellationToken = default) =>
        ProxyJsonAsync(
            () => _client.GetSessionAsync(sessionId, includeMessages, cancellationToken),
            "Unable to read the AI chat session.");

    [HttpPost("sessions/{sessionId}/reset")]
    public Task<IActionResult> ResetSession(string sessionId, CancellationToken cancellationToken) =>
        ProxyJsonAsync(() => _client.ResetSessionAsync(sessionId, cancellationToken), "Unable to reset the AI chat session.");

    [HttpDelete("sessions/{sessionId}")]
    public Task<IActionResult> DeleteSession(string sessionId, CancellationToken cancellationToken) =>
        ProxyJsonAsync(() => _client.DeleteSessionAsync(sessionId, cancellationToken), "Unable to delete the AI chat session.");

    [HttpGet("sessions/{sessionId}/active-batch")]
    public Task<IActionResult> GetSessionActiveBatch(string sessionId, CancellationToken cancellationToken) =>
        ProxyJsonAsync(
            () => _client.GetSessionActiveBatchAsync(sessionId, cancellationToken),
            "Unable to retrieve the active bulk-analysis context for this session.");

    [HttpPost("chat")]
    public Task<IActionResult> Chat(
        [FromBody] ChatProxyRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.SessionId) || string.IsNullOrWhiteSpace(request.Message))
        {
            return Task.FromResult<IActionResult>(BadRequest(new
            {
                success = false,
                error = new { code = "INVALID_CHAT_REQUEST", message = "session_id and message are required." },
                requestId = HttpContext.TraceIdentifier
            }));
        }

        ApplyActor(request);
        return ProxyJsonAsync(() => _client.ChatAsync(request, cancellationToken), "The AI chat request failed.");
    }

    [HttpPost("source-operations/cps/query")]
    public Task<IActionResult> QueryCpsSource(
        [FromBody] CpsSourceQueryProxyRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Emails.Count == 0 && string.IsNullOrWhiteSpace(request.Query))
        {
            return Task.FromResult<IActionResult>(BadRequest(new
            {
                success = false,
                error = new { code = "CPS_EMAIL_REQUIRED", message = "Provide emails or a query with a session ID." },
                requestId = HttpContext.TraceIdentifier
            }));
        }
        return ProxyJsonAsync(() => _client.QueryCpsSourceAsync(request, cancellationToken), "CPS source query failed.");
    }

    [HttpPost("source-operations/query")]
    public Task<IActionResult> QuerySource(
        [FromBody] SourceQueryProxyRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Sources.Count == 0 && string.IsNullOrWhiteSpace(request.Source))
        {
            return Task.FromResult<IActionResult>(BadRequest(new
            {
                success = false,
                error = new { code = "SOURCE_REQUIRED", message = "Select at least one of CPS, Rewards DB, or CrowdTwist." },
                requestId = HttpContext.TraceIdentifier
            }));
        }
        var hasDirectIdentifier = !string.IsNullOrWhiteSpace(request.SearchType) && !string.IsNullOrWhiteSpace(request.SearchValue);
        if (request.Emails.Count == 0 && string.IsNullOrWhiteSpace(request.Query) && !hasDirectIdentifier)
        {
            return Task.FromResult<IActionResult>(BadRequest(new
            {
                success = false,
                error = new { code = "SOURCE_IDENTIFIER_REQUIRED", message = "Provide an email, Profile ID, CrowdTwist ID, or a query with a session ID." },
                requestId = HttpContext.TraceIdentifier
            }));
        }
        if (hasDirectIdentifier)
        {
            request.SearchType = NormalizeSearchType(request.SearchType!);
        }
        ApplyActor(request);
        return ProxyJsonAsync(() => _client.QuerySourceAsync(request, cancellationToken), "Source query failed.");
    }

    [Authorize(Policy = "AllRoles")]
    [HttpPost("source-operations/changes/plan")]
    public Task<IActionResult> PlanSourceChange(
        [FromBody] SourceChangePlanProxyRequest request,
        CancellationToken cancellationToken)
    {
        ApplyActor(request);
        if (string.IsNullOrWhiteSpace(request.SessionId) || string.IsNullOrWhiteSpace(request.Source) ||
            string.IsNullOrWhiteSpace(request.Field) || request.Emails.Count == 0)
        {
            return Task.FromResult<IActionResult>(BadRequest(new
            {
                success = false,
                error = new { code = "INVALID_CHANGE_PLAN", message = "session_id, source, emails, field and new_value are required." },
                requestId = HttpContext.TraceIdentifier
            }));
        }
        return ProxyJsonAsync(() => _client.PlanSourceChangeAsync(request, cancellationToken), "Unable to create the source change plan.", StatusCodes.Status201Created);
    }

    [Authorize(Policy = "AllRoles")]
    [HttpGet("source-operations/changes/{changeId}")]
    public Task<IActionResult> GetSourceChange(
        string changeId, [FromQuery] string sessionId,
        CancellationToken cancellationToken) =>
        ProxyJsonAsync(() => _client.GetSourceChangeAsync(changeId, sessionId, cancellationToken), "Unable to read the source change request.");

    [Authorize(Policy = "AllRoles")]
    [HttpPost("source-operations/changes/{changeId}/confirm-1")]
    public Task<IActionResult> ConfirmSourceChangeFirst(
        string changeId, [FromBody] SourceChangeConfirmationProxyRequest request,
        CancellationToken cancellationToken)
    {
        ApplyActor(request);
        request.ApprovalChannel = "chat";
        return ProxyJsonAsync(() => _client.ConfirmSourceChangeFirstAsync(changeId, request, cancellationToken), "First source-change confirmation failed.");
    }

    [Authorize(Policy = "AllRoles")]
    [HttpPost("source-operations/changes/{changeId}/popup-opened")]
    public Task<IActionResult> MarkSourceChangePopupOpened(
        string changeId, [FromBody] SourceChangePopupOpenedProxyRequest request,
        CancellationToken cancellationToken)
    {
        ApplyActor(request);
        return ProxyJsonAsync(() => _client.MarkSourceChangePopupOpenedAsync(changeId, request, cancellationToken), "Unable to open the final source-change approval.");
    }

    [Authorize(Policy = "AllRoles")]
    [HttpPost("source-operations/changes/{changeId}/confirm-2")]
    public Task<IActionResult> ConfirmSourceChangeSecond(
        string changeId, [FromBody] SourceChangeConfirmationProxyRequest request,
        CancellationToken cancellationToken)
    {
        ApplyActor(request);
        return ProxyJsonAsync(() => _client.ConfirmSourceChangeSecondAsync(changeId, request, cancellationToken), "Second source-change confirmation failed.");
    }

    [Authorize(Policy = "AllRoles")]
    [HttpPost("source-operations/changes/{changeId}/cancel")]
    public Task<IActionResult> CancelSourceChange(
        string changeId, [FromBody] SourceChangeCancelProxyRequest request,
        CancellationToken cancellationToken)
    {
        ApplyActor(request);
        return ProxyJsonAsync(() => _client.CancelSourceChangeAsync(changeId, request, cancellationToken), "Unable to cancel the source change request.");
    }

    [HttpPost("analysis/individual")]
    public async Task<IActionResult> Analyze(
        [FromBody] IndividualAnalysisProxyRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.SearchValue))
        {
            return BadRequest(new
            {
                success = false,
                error = new { code = "INVALID_SEARCH_VALUE", message = "search_value is required." },
                requestId = HttpContext.TraceIdentifier
            });
        }

        request.SearchType = NormalizeSearchType(request.SearchType);
        var profile = CurrentRoleProfile();
        request.IncludeRawSourceData = request.IncludeRawSourceData && profile.Permissions.ViewTechnicalDetails;
        request.MaskReportValues = EffectiveReportMasked(request.MaskReportValues);
        ApplyActor(request);
        Response.Headers["X-Report-Privacy"] = request.MaskReportValues ? "masked" : "unmasked";
        try
        {
            using var document = await _client.AnalyzeAsync(request, cancellationToken);
            var payload = ProjectAgenticPayloadForRole(document.RootElement.GetRawText(), profile);
            Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            Response.Headers.Pragma = "no-cache";
            return Content(payload, "application/json");
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Individual analysis failed.");
        }
    }

    [HttpGet("analysis/{runId}")]
    public async Task<IActionResult> GetAnalysis(
        string runId,
        [FromQuery] bool masked = false,
        CancellationToken cancellationToken = default)
    {
        var profile = CurrentRoleProfile();
        var effectiveMasked = EffectiveReportMasked(masked);
        Response.Headers["X-Report-Privacy"] = effectiveMasked ? "masked" : "unmasked";
        try
        {
            using var document = await _client.GetAnalysisAsync(runId, effectiveMasked, cancellationToken);
            var payload = ProjectAgenticPayloadForRole(document.RootElement.GetRawText(), profile);
            Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            Response.Headers.Pragma = "no-cache";
            return Content(payload, "application/json");
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Unable to retrieve the analysis.");
        }
    }

    [HttpGet("analysis/{runId}/report.html")]
    [Produces("text/html")]
    public async Task<IActionResult> GetHtmlReport(
        string runId,
        [FromQuery] bool masked = false,
        CancellationToken cancellationToken = default)
    {
        var profile = CurrentRoleProfile();
        var effectiveMasked = EffectiveReportMasked(masked);
        if (RusRoles.Normalize(profile.Code) == RusRoles.Admin)
        {
            return await ProxyFileAsync(
                () => _client.GetHtmlReportResponseAsync(runId, effectiveMasked, cancellationToken),
                $"{runId}_{(effectiveMasked ? "MASKED" : "UNMASKED")}.html",
                "text/html; charset=utf-8",
                cancellationToken);
        }

        try
        {
            using var upstream = await _client.GetJsonReportResponseAsync(runId, effectiveMasked, cancellationToken);
            if (!upstream.IsSuccessStatusCode)
            {
                var upstreamBody = await upstream.Content.ReadAsStringAsync(cancellationToken);
                return new ContentResult
                {
                    StatusCode = (int)upstream.StatusCode,
                    ContentType = upstream.Content.Headers.ContentType?.ToString() ?? "application/json",
                    Content = upstreamBody
                };
            }
            var raw = await upstream.Content.ReadAsStringAsync(cancellationToken);
            var projected = ProjectAgenticPayloadForRole(raw, profile);
            var html = BuildRoleSafeHtmlReport(runId, profile, effectiveMasked, projected);
            Response.Headers["X-Report-Privacy"] = effectiveMasked ? "masked" : "unmasked";
            Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            return File(
                Encoding.UTF8.GetBytes(html),
                "text/html; charset=utf-8",
                $"{runId}_{profile.Code.ToUpperInvariant()}_{(effectiveMasked ? "MASKED" : "UNMASKED")}.html");
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Unable to build the role-safe HTML report.");
        }
    }

    [HttpGet("analysis/{runId}/report.json")]
    [Produces("application/json")]
    public async Task<IActionResult> GetJsonReport(
        string runId,
        [FromQuery] bool masked = false,
        CancellationToken cancellationToken = default)
    {
        var profile = CurrentRoleProfile();
        var effectiveMasked = EffectiveReportMasked(masked);
        if (RusRoles.Normalize(profile.Code) == RusRoles.Admin)
        {
            return await ProxyFileAsync(
                () => _client.GetJsonReportResponseAsync(runId, effectiveMasked, cancellationToken),
                $"{runId}_{(effectiveMasked ? "MASKED" : "UNMASKED")}.json",
                "application/json",
                cancellationToken);
        }

        try
        {
            using var upstream = await _client.GetJsonReportResponseAsync(runId, effectiveMasked, cancellationToken);
            if (!upstream.IsSuccessStatusCode)
            {
                var upstreamBody = await upstream.Content.ReadAsStringAsync(cancellationToken);
                return new ContentResult
                {
                    StatusCode = (int)upstream.StatusCode,
                    ContentType = upstream.Content.Headers.ContentType?.ToString() ?? "application/json",
                    Content = upstreamBody
                };
            }
            var raw = await upstream.Content.ReadAsStringAsync(cancellationToken);
            var projected = ProjectAgenticPayloadForRole(raw, profile);
            Response.Headers["X-Report-Privacy"] = effectiveMasked ? "masked" : "unmasked";
            Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            return File(
                Encoding.UTF8.GetBytes(projected),
                "application/json",
                $"{runId}_{profile.Code.ToUpperInvariant()}_{(effectiveMasked ? "MASKED" : "UNMASKED")}.json");
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Unable to build the role-safe JSON report.");
        }
    }

    [Authorize(Policy = "AllRoles")]
    [HttpPost("batches")]
    public Task<IActionResult> SubmitBatch(
        [FromBody] BatchEmailsProxyRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Emails.Count == 0)
        {
            return Task.FromResult<IActionResult>(BadRequest(new
            {
                success = false,
                error = new { code = "NO_EMAILS", message = "At least one email is required." },
                requestId = HttpContext.TraceIdentifier
            }));
        }

        // v11.37: Customer Support, Business and Technical use the managed profile.
        // Admin may tune within the safe service limits.
        var profile = CurrentRoleProfile();
        if (RusRoles.Normalize(profile.Code) == RusRoles.Admin)
        {
            request.MaxParallel = Math.Clamp(request.MaxParallel ?? _options.RecommendedSourceParallelism, 1, 8);
            request.MaxParallelAi = Math.Clamp(request.MaxParallelAi ?? _options.RecommendedAiParallelism, 1, 2);
        }
        else
        {
            request.MaxParallel = 8;
            request.MaxParallelAi = 2;
            request.IncludeGroupAi = true;
        }
        return ProxyJsonAsync(() => _client.SubmitBatchAsync(request, cancellationToken), "Batch submission failed.", StatusCodes.Status202Accepted);
    }

    [Authorize(Policy = "AllRoles")]
    [HttpPost("batches/upload")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(MaxUploadBytes)]
    public async Task<IActionResult> UploadBatch(
        [FromForm] IFormFile file,
        [FromQuery] string? sessionId = null,
        [FromQuery] int? maxParallel = null,
        [FromQuery] int? maxParallelAi = null,
        [FromQuery] bool? includeGroupAi = null,
        CancellationToken cancellationToken = default)
    {
        if (file is null || file.Length == 0)
        {
            return BadRequest(new
            {
                success = false,
                error = new { code = "EMPTY_FILE", message = "Select a non-empty TXT or CSV file." },
                requestId = HttpContext.TraceIdentifier
            });
        }

        if (file.Length > Math.Min(_options.MaxUploadBytes, (int)MaxUploadBytes))
        {
            return StatusCode(StatusCodes.Status413PayloadTooLarge, new
            {
                success = false,
                error = new { code = "FILE_TOO_LARGE", message = "The uploaded file exceeds the configured size limit." },
                requestId = HttpContext.TraceIdentifier
            });
        }

        var extension = Path.GetExtension(file.FileName);
        if (!extension.Equals(".txt", StringComparison.OrdinalIgnoreCase) &&
            !extension.Equals(".csv", StringComparison.OrdinalIgnoreCase))
        {
            return StatusCode(StatusCodes.Status415UnsupportedMediaType, new
            {
                success = false,
                error = new { code = "UNSUPPORTED_FILE_TYPE", message = "Only TXT and CSV files are supported." },
                requestId = HttpContext.TraceIdentifier
            });
        }

        try
        {
            var profile = CurrentRoleProfile();
            var effectiveMaxParallel = RusRoles.Normalize(profile.Code) == RusRoles.Admin
                ? Math.Clamp(maxParallel ?? _options.RecommendedSourceParallelism, 1, 8)
                : 8;
            var effectiveMaxParallelAi = RusRoles.Normalize(profile.Code) == RusRoles.Admin
                ? Math.Clamp(maxParallelAi ?? _options.RecommendedAiParallelism, 1, 2)
                : 2;
            var effectiveGroupAi = RusRoles.Normalize(profile.Code) == RusRoles.Admin
                ? (includeGroupAi ?? _options.IncludeGroupedAiByDefault)
                : true;

            await using var stream = file.OpenReadStream();
            using var document = await _client.UploadBatchAsync(
                stream,
                Path.GetFileName(file.FileName),
                sessionId,
                effectiveMaxParallel,
                effectiveMaxParallelAi,
                effectiveGroupAi,
                cancellationToken);
            Response.StatusCode = StatusCodes.Status202Accepted;
            return Content(document.RootElement.GetRawText(), "application/json");
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Batch upload failed.");
        }
    }

    [HttpPost("source-operations/spreadsheet")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(MaxUploadBytes)]
    public async Task<IActionResult> UploadSourceChangeSpreadsheet(
        [FromForm] IFormFile file,
        [FromForm] string sessionId,
        [FromForm] string? instruction = null,
        CancellationToken cancellationToken = default)
    {
        if (!CurrentRoleProfile().Permissions.PlanAgenticUpdates)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new
            {
                success = false,
                error = new { code = "ROLE_NOT_AUTHORIZED", message = "This authenticated profile does not have Agentic source-update permission." },
                requestId = HttpContext.TraceIdentifier
            });
        }
        if (string.IsNullOrWhiteSpace(sessionId))
        {
            return BadRequest(new
            {
                success = false,
                error = new { code = "SESSION_ID_REQUIRED", message = "An active Agentic session is required before importing update rows." },
                requestId = HttpContext.TraceIdentifier
            });
        }
        if (file is null || file.Length == 0)
        {
            return BadRequest(new
            {
                success = false,
                error = new { code = "EMPTY_FILE", message = "Select a non-empty Excel workbook." },
                requestId = HttpContext.TraceIdentifier
            });
        }
        if (file.Length > Math.Min(_options.MaxUploadBytes, (int)MaxUploadBytes))
        {
            return StatusCode(StatusCodes.Status413PayloadTooLarge, new
            {
                success = false,
                error = new { code = "FILE_TOO_LARGE", message = "The uploaded workbook exceeds the configured size limit." },
                requestId = HttpContext.TraceIdentifier
            });
        }
        var extension = Path.GetExtension(file.FileName);
        if (!extension.Equals(".xlsx", StringComparison.OrdinalIgnoreCase) &&
            !extension.Equals(".xlsm", StringComparison.OrdinalIgnoreCase))
        {
            return StatusCode(StatusCodes.Status415UnsupportedMediaType, new
            {
                success = false,
                error = new { code = "UNSUPPORTED_FILE_TYPE", message = "Agentic update workbooks must be XLSX or XLSM files." },
                requestId = HttpContext.TraceIdentifier
            });
        }

        try
        {
            await using var input = file.OpenReadStream();
            using var workbook = new XLWorkbook(input);
            var worksheet = workbook.Worksheets.FirstOrDefault();
            var used = worksheet?.RangeUsed();
            if (worksheet is null || used is null)
            {
                return BadRequest(new
                {
                    success = false,
                    error = new { code = "EMPTY_WORKBOOK", message = "The workbook does not contain a populated worksheet." },
                    requestId = HttpContext.TraceIdentifier
                });
            }

            var headerRow = used.FirstRow();
            var headers = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var cell in headerRow.CellsUsed())
            {
                var key = NormalizeSpreadsheetHeader(cell.GetString());
                if (!string.IsNullOrWhiteSpace(key) && !headers.ContainsKey(key)) headers[key] = cell.Address.ColumnNumber;
            }

            int? sourceColumn = FindSpreadsheetColumn(headers, "source", "system", "targetsystem", "targetsource");
            int? ctIdColumn = FindSpreadsheetColumn(headers, "crowdtwistid", "crowdtwistidentifier", "ctid");
            int? profileIdColumn = FindSpreadsheetColumn(headers, "profileid", "thirdpartyid");
            int? emailColumn = FindSpreadsheetColumn(headers, "email", "emailaddress");
            int? propertyColumn = FindSpreadsheetColumn(headers, "propertyname", "property", "field", "attribute", "columnname");
            int? valueColumn = FindSpreadsheetColumn(headers, "propertyvalue", "newvalue", "value", "requestedvalue");

            if (propertyColumn is null || valueColumn is null || (ctIdColumn is null && profileIdColumn is null && emailColumn is null))
            {
                return BadRequest(new
                {
                    success = false,
                    error = new
                    {
                        code = "INVALID_UPDATE_WORKBOOK_HEADERS",
                        message = "Expected PropertyName/PropertyValue plus at least one identifier column: CrowdTwistID, ProfileId, or Email. An optional Source column may specify CrowdTwist or Rewards DB."
                    },
                    requestId = HttpContext.TraceIdentifier
                });
            }

            var rows = new List<SpreadsheetSourceChangeRowProxyRequest>();
            foreach (var row in used.RowsUsed().Skip(1))
            {
                if (rows.Count >= 500)
                {
                    return BadRequest(new
                    {
                        success = false,
                        error = new { code = "TOO_MANY_UPDATE_ROWS", message = "A single Agentic update workbook is limited to 500 populated rows." },
                        requestId = HttpContext.TraceIdentifier
                    });
                }

                var propertyName = SpreadsheetCellText(row.Cell(propertyColumn.Value));
                var hasCt = ctIdColumn is not null && !string.IsNullOrWhiteSpace(SpreadsheetCellText(row.Cell(ctIdColumn.Value)));
                var hasProfile = profileIdColumn is not null && !string.IsNullOrWhiteSpace(SpreadsheetCellText(row.Cell(profileIdColumn.Value)));
                var hasEmail = emailColumn is not null && !string.IsNullOrWhiteSpace(SpreadsheetCellText(row.Cell(emailColumn.Value)));
                if (string.IsNullOrWhiteSpace(propertyName) && !hasCt && !hasProfile && !hasEmail) continue;
                if (string.IsNullOrWhiteSpace(propertyName))
                {
                    return BadRequest(new
                    {
                        success = false,
                        error = new { code = "PROPERTY_NAME_REQUIRED", message = $"Row {row.RowNumber()} is missing PropertyName/Field." },
                        requestId = HttpContext.TraceIdentifier
                    });
                }

                string identifierType;
                string identifierValue;
                if (hasCt)
                {
                    identifierType = "crowdtwistid";
                    identifierValue = SpreadsheetCellText(row.Cell(ctIdColumn!.Value));
                }
                else if (hasProfile)
                {
                    identifierType = "profileid";
                    identifierValue = SpreadsheetCellText(row.Cell(profileIdColumn!.Value));
                }
                else if (hasEmail)
                {
                    identifierType = "email";
                    identifierValue = SpreadsheetCellText(row.Cell(emailColumn!.Value));
                }
                else
                {
                    return BadRequest(new
                    {
                        success = false,
                        error = new { code = "IDENTIFIER_REQUIRED", message = $"Row {row.RowNumber()} is missing CrowdTwistID, ProfileId, or Email." },
                        requestId = HttpContext.TraceIdentifier
                    });
                }

                var sourceText = sourceColumn is null ? string.Empty : SpreadsheetCellText(row.Cell(sourceColumn.Value));
                var source = NormalizeSpreadsheetSource(sourceText, defaultCrowdTwist: ctIdColumn is not null);
                if (source is null)
                {
                    return BadRequest(new
                    {
                        success = false,
                        error = new { code = "INVALID_SOURCE", message = $"Row {row.RowNumber()} has unsupported Source '{sourceText}'. Use CrowdTwist or Rewards DB." },
                        requestId = HttpContext.TraceIdentifier
                    });
                }

                rows.Add(new SpreadsheetSourceChangeRowProxyRequest
                {
                    RowNumber = row.RowNumber(),
                    Source = source,
                    IdentifierType = identifierType,
                    IdentifierValue = identifierValue,
                    Field = propertyName,
                    OriginalPropertyName = propertyName,
                    NewValue = SpreadsheetCellValue(row.Cell(valueColumn.Value))
                });
            }

            if (rows.Count == 0)
            {
                return BadRequest(new
                {
                    success = false,
                    error = new { code = "NO_UPDATE_ROWS", message = "No populated update rows were found in the workbook." },
                    requestId = HttpContext.TraceIdentifier
                });
            }

            var request = new SpreadsheetSourceChangeImportProxyRequest
            {
                SessionId = sessionId.Trim(),
                FileName = Path.GetFileName(file.FileName),
                Instruction = string.IsNullOrWhiteSpace(instruction) ? "validate these spreadsheet changes" : instruction.Trim(),
                Rows = rows
            };
            ApplyActor(request);
            using var document = await _client.ImportSpreadsheetSourceChangesAsync(request, cancellationToken);
            return Content(document.RootElement.GetRawText(), "application/json");
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Excel source-update import failed.");
        }
    }

    [Authorize(Policy = "AllRoles")]
    [HttpGet("batches/{jobId}")]
    public Task<IActionResult> GetBatch(string jobId, CancellationToken cancellationToken) =>
        ProxyProjectedJsonAsync(() => _client.GetBatchAsync(jobId, cancellationToken), "Unable to read batch status.", cancellationToken);

    [Authorize(Policy = "AllRoles")]
    [HttpGet("batches/{jobId}/summary")]
    public Task<IActionResult> GetBatchSummary(string jobId, CancellationToken cancellationToken) =>
        ProxyProjectedJsonAsync(() => _client.GetBatchSummaryAsync(jobId, cancellationToken), "Unable to retrieve the batch summary.", cancellationToken);

    [Authorize(Policy = "AllRoles")]
    [HttpGet("batches/{jobId}/download")]
    [Produces("application/zip")]
    public async Task<IActionResult> DownloadBatch(
        string jobId,
        [FromQuery] bool masked = false,
        CancellationToken cancellationToken = default)
    {
        var profile = CurrentRoleProfile();
        var effectiveMasked = EffectiveReportMasked(masked);
        try
        {
            using var upstream = await _client.GetBatchDownloadResponseAsync(jobId, effectiveMasked, cancellationToken);
            if (!upstream.IsSuccessStatusCode)
            {
                var body = await upstream.Content.ReadAsStringAsync(cancellationToken);
                return new ContentResult
                {
                    StatusCode = (int)upstream.StatusCode,
                    ContentType = upstream.Content.Headers.ContentType?.ToString() ?? "application/json",
                    Content = body
                };
            }
            var bytes = await upstream.Content.ReadAsByteArrayAsync(cancellationToken);
            if (RusRoles.Normalize(profile.Code) != RusRoles.Admin)
                bytes = BuildRoleSafeBatchZip(bytes, jobId, profile, effectiveMasked);
            Response.Headers["X-Report-Privacy"] = effectiveMasked ? "masked" : "unmasked";
            Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            return File(bytes, "application/zip", $"{jobId}_{profile.Code.ToUpperInvariant()}_REPORTS_{(effectiveMasked ? "MASKED" : "UNMASKED")}.zip");
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Unable to build the role-safe batch report package.");
        }
    }

    private static byte[] BuildRoleSafeBatchZip(byte[] sourceZip, string jobId, RoleViewProfile profile, bool masked)
    {
        using var inputStream = new MemoryStream(sourceZip);
        using var input = new ZipArchive(inputStream, ZipArchiveMode.Read, leaveOpen: false);
        using var outputStream = new MemoryStream();
        using (var output = new ZipArchive(outputStream, ZipArchiveMode.Create, leaveOpen: true))
        {
            string? projectedSummary = null;
            var summaryEntry = input.GetEntry("00_BATCH_SUMMARY.json");
            if (summaryEntry is not null)
            {
                using var reader = new StreamReader(summaryEntry.Open(), Encoding.UTF8);
                var raw = reader.ReadToEnd();
                projectedSummary = ProjectAgenticPayloadForRole(raw, profile);
                WriteZipText(output, "00_BATCH_SUMMARY.json", projectedSummary);
                WriteZipText(output, "00_BATCH_SUMMARY.html", BuildRoleSafeBatchHtmlReport(jobId, profile, masked, projectedSummary));
                WriteZipText(output, "00_MEMBER_SUMMARY.csv", BuildRoleSafeBatchCsv(projectedSummary));
            }

            foreach (var entry in input.Entries)
            {
                if (entry.FullName.Equals("00_BATCH_SUMMARY.html", StringComparison.OrdinalIgnoreCase) ||
                    entry.FullName.Equals("00_BATCH_SUMMARY.json", StringComparison.OrdinalIgnoreCase) ||
                    entry.FullName.Equals("00_MEMBER_SUMMARY.csv", StringComparison.OrdinalIgnoreCase) ||
                    entry.FullName.EndsWith(".html", StringComparison.OrdinalIgnoreCase))
                    continue;

                if (entry.FullName.StartsWith("individual_reports/", StringComparison.OrdinalIgnoreCase) &&
                    entry.FullName.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
                {
                    using var reader = new StreamReader(entry.Open(), Encoding.UTF8);
                    var raw = reader.ReadToEnd();
                    var projected = ProjectAgenticPayloadForRole(raw, profile);
                    var runId = Path.GetFileNameWithoutExtension(entry.Name);
                    try
                    {
                        var parsed = JsonNode.Parse(projected) as JsonObject;
                        runId = NodeText(parsed?["run_id"], runId);
                    }
                    catch { }
                    WriteZipText(output, entry.FullName, projected);
                    WriteZipText(output, Path.ChangeExtension(entry.FullName, ".html").Replace('\\', '/'), BuildRoleSafeHtmlReport(runId, profile, masked, projected));
                    continue;
                }

                CopyZipEntry(entry, output);
            }

            WriteZipText(output, "ROLE_REPORT_POLICY.txt",
                $"RUS role-safe batch package\nRole: {profile.Label}\nPrivacy: {(masked ? "MASKED" : "UNMASKED")}\nTechnical connector payloads are omitted according to the signed-in role.\n");
        }
        return outputStream.ToArray();
    }

    private static void CopyZipEntry(ZipArchiveEntry source, ZipArchive target)
    {
        var created = target.CreateEntry(source.FullName, CompressionLevel.Optimal);
        using var src = source.Open();
        using var dst = created.Open();
        src.CopyTo(dst);
    }

    private static void WriteZipText(ZipArchive archive, string path, string text)
    {
        var entry = archive.CreateEntry(path, CompressionLevel.Optimal);
        using var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false));
        writer.Write(text ?? string.Empty);
    }

    private static string BuildRoleSafeBatchCsv(string projectedJson)
    {
        JsonObject root;
        try { root = JsonNode.Parse(projectedJson) as JsonObject ?? new JsonObject(); }
        catch { root = new JsonObject(); }
        var sb = new StringBuilder();
        sb.AppendLine("Email,RunId,Completeness,Mismatches,MissingRecords,ExactChanges,ManualReview,TotalTime");
        foreach (var member in (root["members"] as JsonArray)?.OfType<JsonObject>() ?? Enumerable.Empty<JsonObject>())
        {
            static string Csv(string value) => "\"" + (value ?? string.Empty).Replace("\"", "\"\"") + "\"";
            sb.Append(Csv(NodeText(member["email"]))).Append(',')
              .Append(Csv(NodeText(member["run_id"]))).Append(',')
              .Append(Csv(NodeText(member["completeness"]))).Append(',')
              .Append(Csv(NodeText(member["mismatches"], "0"))).Append(',')
              .Append(Csv(NodeText(member["missing_records"], "0"))).Append(',')
              .Append(Csv(NodeText(member["exact_changes"], "0"))).Append(',')
              .Append(Csv(NodeText(member["manual_review"], "0"))).Append(',')
              .Append(Csv(FormatReportDuration(GetNodeDouble(member["total_time_ms"])))).AppendLine();
        }
        return sb.ToString();
    }

    private static string BuildRoleSafeBatchHtmlReport(string jobId, RoleViewProfile profile, bool masked, string projectedJson)
    {
        JsonObject root;
        try { root = JsonNode.Parse(projectedJson) as JsonObject ?? new JsonObject(); }
        catch { root = new JsonObject(); }
        var role = RusRoles.Normalize(profile.Code);
        var isTechnical = role == RusRoles.Technical;
        var isCustomer = role == RusRoles.Customer;
        var processing = root["processing"] as JsonObject;
        var population = root["population_metrics"] as JsonObject;
        var totals = root["totals"] as JsonObject;
        var timings = root["timings"] as JsonObject;
        var sourceMetrics = root["source_member_record_metrics"] as JsonObject;
        var totalTime = FormatReportDuration(GetNodeDouble(timings?["batch_total_ms"]));
        var unique = NodeText(population?["unique_members_processed"], "0");
        var completed = NodeText(processing?["completed_count"], "0");
        var failed = NodeText(processing?["failed_count"], "0");
        var anyIssue = NodeText(population?["users_with_any_issue"], "0");
        var exactUsers = NodeText(population?["users_with_exact_changes"], "0");
        var reviewUsers = NodeText(population?["users_requiring_manual_review"], "0");
        var summary = NodeText(root["authoritative_group_summary"], "Batch analysis completed.");
        var privacy = masked ? "Masked" : "Unmasked";
        var sb = new StringBuilder(32_000);
        sb.Append("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>")
          .Append(Html($"RUS {profile.Label} bulk report — {jobId}")).Append("</title><style>").Append(RoleReportCss()).Append("</style></head><body><main>");
        sb.Append("<header class=\"hero\"><div class=\"role-chip\">").Append(Html(profile.Label)).Append(" · ").Append(Html(privacy)).Append(" · Bulk</div><h1>RUS Bulk Operations report — ").Append(Html(jobId)).Append("</h1><p>")
          .Append(isTechnical ? "Operational portfolio report with source coverage and execution diagnostics." : isCustomer ? "Customer-support portfolio summary with verified issues and recommended follow-up." : "Business portfolio summary with verified issues, source coverage, and correction readiness.")
          .Append("</p><div class=\"hero-meta\">").Append(Chip("Members", unique)).Append(Chip("Completed", completed)).Append(Chip("Total time", totalTime)).Append("</div></header><section class=\"content\">");
        sb.Append("<div class=\"kpi-grid\">").Append(Kpi("Unique members", unique)).Append(Kpi("Completed", completed)).Append(Kpi("Failed", failed)).Append(Kpi("Any issue", anyIssue)).Append(Kpi("Exact-change users", exactUsers)).Append(Kpi("Manual-review users", reviewUsers)).Append(Kpi("Total time", totalTime)).Append("</div>");
        sb.Append("<section class=\"panel executive\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Portfolio result</span><h2>Executive summary</h2></div></div><p class=\"summary-copy\">").Append(Html(summary)).Append("</p></section>");

        var topIssues = root["top_issue_attributes"] as JsonArray;
        sb.Append("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Distribution</span><h2>Top issue attributes</h2></div></div>");
        if (topIssues is null || topIssues.Count == 0) sb.Append("<div class=\"empty\">No recurring issues.</div>");
        else { sb.Append("<div class=\"table-wrap\"><table><thead><tr><th>Attribute</th><th>Members affected</th></tr></thead><tbody>"); foreach (var item in topIssues.OfType<JsonObject>()) sb.Append("<tr><td><strong>").Append(Html(NodeText(item["attribute"]))).Append("</strong></td><td>").Append(Html(NodeText(item["count"], "0"))).Append("</td></tr>"); sb.Append("</tbody></table></div>"); }
        sb.Append("</section>");

        var bySource = sourceMetrics?["by_source"] as JsonObject ?? root["source_record_status"] as JsonObject;
        sb.Append("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Coverage</span><h2>Source coverage</h2></div></div><div class=\"source-grid\">");
        foreach (var (key,label) in new[] { ("cps","CPS"), ("rewards_db","Rewards DB"), ("crowd_twist","CrowdTwist") }) { var counts=bySource?[key] as JsonObject; var found=NodeText(counts?["FOUND"],"0"); var missing=NodeText(counts?["NO_RECORD"],"0"); var unavailable=NodeText(counts?["UNAVAILABLE"],"0"); sb.Append("<article class=\"source-card good\"><div><span class=\"source-dot\"></span><strong>").Append(label).Append("</strong></div><b>").Append(Html(found)).Append(" found</b><small>").Append(Html(missing)).Append(" no record · ").Append(Html(unavailable)).Append(" unavailable</small></article>"); }
        sb.Append("</div></section>");

        var members = root["members"] as JsonArray;
        sb.Append("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Members</span><h2>Member results</h2></div><span class=\"count-chip\">").Append(members?.Count ?? 0).Append("</span></div><div class=\"table-wrap\"><table><thead><tr><th>Member</th><th>Completeness</th><th>Mismatches</th><th>Exact changes</th><th>Review</th><th>Total time</th><th>Report</th>");
        if (isTechnical) sb.Append("<th>Judge</th><th>MCP</th>");
        sb.Append("</tr></thead><tbody>");
        var idx=0; foreach (var member in members?.OfType<JsonObject>() ?? Enumerable.Empty<JsonObject>()) { idx++; var run=NodeText(member["run_id"]); var link=string.IsNullOrWhiteSpace(run)?"—":$"<a href=\"individual_reports/{idx:000}_{Html(run)}.html\">Open</a>"; sb.Append("<tr><td><strong>").Append(Html(NodeText(member["email"], NodeText(member["record_id"], $"Member {idx}")))).Append("</strong></td><td>").Append(Html(NodeText(member["completeness"],"—"))).Append("</td><td>").Append(Html(NodeText(member["mismatches"],"0"))).Append("</td><td>").Append(Html(NodeText(member["exact_changes"],"0"))).Append("</td><td>").Append(Html(NodeText(member["manual_review"],"0"))).Append("</td><td>").Append(Html(FormatReportDuration(GetNodeDouble(member["total_time_ms"])))).Append("</td><td>").Append(link).Append("</td>"); if (isTechnical) sb.Append("<td>").Append(Html(NodeText(member["judge_verdict"],"—"))).Append("</td><td>").Append(Html(NodeText(member["mcp"],"—"))).Append("</td>"); sb.Append("</tr>"); }
        sb.Append("</tbody></table></div></section>");

        sb.Append("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Performance</span><h2>Batch timing</h2></div></div><div class=\"time-callout\"><strong>").Append(Html(totalTime)).Append("</strong><span>Total wall-clock batch time</span></div></section>");
        if (isTechnical && timings is not null) sb.Append(BuildTechnicalTimingSection(timings));
        sb.Append("<footer>Generated by RUS Agentic Data Disparity · Role-safe ").Append(Html(profile.Label)).Append(" bulk view · ").Append(Html(privacy)).Append("</footer></section></main></body></html>");
        return sb.ToString();
    }

    [Authorize(Policy = "TechnicalOperations")]
    [HttpGet("knowledge/catalog")]
    public Task<IActionResult> GetKnowledgeCatalog(CancellationToken cancellationToken) =>
        ProxyJsonAsync(() => _client.GetKnowledgeCatalogAsync(cancellationToken), "Unable to read the API knowledge catalog.");

    [Authorize(Policy = "TechnicalOperations")]
    [HttpGet("knowledge/operations/{operationId}")]
    public Task<IActionResult> GetOperation(string operationId, CancellationToken cancellationToken) =>
        ProxyJsonAsync(() => _client.GetOperationAsync(operationId, cancellationToken), "Unable to read the API operation contract.");

    [Authorize(Policy = "TechnicalOperations")]
    [HttpPost("knowledge/validate-payload")]
    public Task<IActionResult> ValidatePayload(
        [FromBody] PayloadValidationProxyRequest request,
        CancellationToken cancellationToken) =>
        ProxyJsonAsync(() => _client.ValidatePayloadAsync(request, cancellationToken), "Payload validation failed.");

    [Authorize(Policy = "BusinessOrHigher")]
    [HttpGet("analysis/{runId}/use-cases")]
    public Task<IActionResult> GetUseCases(string runId, CancellationToken cancellationToken) =>
        ProxyJsonAsync(() => _client.GetUseCasesAsync(runId, cancellationToken), "Unable to retrieve use-case recommendations.");

    [Authorize(Policy = "BusinessOrHigher")]
    [HttpPost("use-cases/plan")]
    public Task<IActionResult> CompileUseCasePlan(
        [FromBody] UseCasePlanProxyRequest request,
        CancellationToken cancellationToken) =>
        ProxyJsonAsync(() => _client.CompileUseCasePlanAsync(request, cancellationToken), "Use-case plan compilation failed.");

    private async Task<IActionResult> ProxyJsonAsync(
        Func<Task<JsonDocument>> action,
        string errorMessage,
        int successStatusCode = StatusCodes.Status200OK)
    {
        try
        {
            using var document = await action();
            Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            Response.Headers.Pragma = "no-cache";
            Response.StatusCode = successStatusCode;
            return Content(document.RootElement.GetRawText(), "application/json");
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, errorMessage);
        }
    }

    private async Task<IActionResult> ProxyFileAsync(
        Func<Task<HttpResponseMessage>> action,
        string defaultFileName,
        string defaultContentType,
        CancellationToken cancellationToken)
    {
        try
        {
            var upstream = await action();
            HttpContext.Response.RegisterForDispose(upstream);
            Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            Response.Headers.Pragma = "no-cache";
            if (upstream.Headers.TryGetValues("X-Report-Privacy", out var privacyValues))
            {
                Response.Headers["X-Report-Privacy"] = privacyValues.FirstOrDefault() ?? string.Empty;
            }

            if (!upstream.IsSuccessStatusCode)
            {
                var body = await upstream.Content.ReadAsStringAsync(cancellationToken);
                return new ContentResult
                {
                    StatusCode = (int)upstream.StatusCode,
                    ContentType = upstream.Content.Headers.ContentType?.ToString() ?? "application/json",
                    Content = body
                };
            }

            var contentType = upstream.Content.Headers.ContentType?.ToString() ?? defaultContentType;
            var fileName = upstream.Content.Headers.ContentDisposition?.FileNameStar
                ?? upstream.Content.Headers.ContentDisposition?.FileName?.Trim('"')
                ?? defaultFileName;
            var stream = await upstream.Content.ReadAsStreamAsync(cancellationToken);
            return File(stream, contentType, fileName, enableRangeProcessing: false);
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, "Unable to stream the requested report.");
        }
    }

    private async Task<JsonElement> GetResilientHealthAsync(bool deep, CancellationToken cancellationToken)
    {
        try
        {
            using var readinessTimeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            readinessTimeout.CancelAfter(TimeSpan.FromSeconds(deep ? 45 : 20));
            using var health = await _client.GetReadinessAsync(deep, readinessTimeout.Token);
            return ExtractData(health).Clone();
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception readinessException) when (readinessException is OperationCanceledException or HttpRequestException or AgenticApiUpstreamException)
        {
            _logger.LogWarning(
                "Agentic readiness was unavailable ({ExceptionType}); checking liveness and continuing in degraded mode.",
                readinessException.GetType().Name);

            using var livenessTimeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            using var liveness = await _client.GetLivenessAsync(livenessTimeout.Token);
            var live = ExtractData(liveness);
            var service = live.TryGetProperty("service", out var serviceNode)
                ? serviceNode.GetString() ?? "Agentic Data Disparity API"
                : "Agentic Data Disparity API";
            return JsonSerializer.SerializeToElement(new
            {
                status = deep ? "DEGRADED" : "LIVE",
                service,
                live = true,
                ready = false,
                warning = deep
                    ? "The API is online, but one or more extended readiness checks are not currently available."
                    : "The API is online. Detailed readiness is still warming up and will be retried automatically.",
                checkedUtc = DateTime.UtcNow
            });
        }
    }

    private IActionResult UpstreamError(Exception exception, string publicMessage)
    {
        if (exception is OperationCanceledException)
        {
            _logger.LogWarning("{Message} The operation was cancelled or exceeded its timeout.", publicMessage);
        }
        else
        {
            _logger.LogError(exception, "{Message}", publicMessage);
        }

        if (exception is AgenticApiUpstreamException upstream)
        {
            var statusCode = upstream.StatusCode is null
                ? StatusCodes.Status502BadGateway
                : (int)upstream.StatusCode.Value;
            if (!string.IsNullOrWhiteSpace(upstream.UpstreamBody))
            {
                return new ContentResult
                {
                    StatusCode = statusCode,
                    ContentType = "application/json",
                    Content = upstream.UpstreamBody
                };
            }

            return StatusCode(statusCode, Error("AGENTIC_API_REJECTED", publicMessage));
        }

        if (exception is HttpRequestException or TaskCanceledException)
        {
            return StatusCode(
                StatusCodes.Status503ServiceUnavailable,
                Error("AGENTIC_API_UNAVAILABLE", "The Agentic Data Disparity API is unavailable or timed out."));
        }

        return StatusCode(StatusCodes.Status502BadGateway, Error("AGENTIC_PROXY_ERROR", publicMessage));
    }

    private async Task<IActionResult> ProxyProjectedJsonAsync(
        Func<Task<JsonDocument>> operation,
        string errorMessage,
        CancellationToken cancellationToken)
    {
        try
        {
            using var document = await operation();
            var projected = ProjectAgenticPayloadForRole(document.RootElement.GetRawText(), CurrentRoleProfile());
            Response.Headers.CacheControl = "no-store, no-cache, must-revalidate";
            return Content(projected, "application/json", Encoding.UTF8);
        }
        catch (Exception ex)
        {
            return UpstreamError(ex, errorMessage);
        }
    }

    private object Error(string code, string message) => new
    {
        success = false,
        data = (object?)null,
        error = new { code, message },
        requestId = HttpContext.TraceIdentifier
    };

    private static JsonElement ExtractData(JsonDocument document)
    {
        var root = document.RootElement;
        return root.TryGetProperty("data", out var data) ? data : root;
    }

    private static object ProjectHealthForRole(JsonElement health, RoleViewProfile profile)
    {
        if (profile.Permissions.ViewTechnicalDetails) return health.Clone();
        var status = health.TryGetProperty("status", out var statusNode) ? statusNode.GetString() ?? "UNKNOWN" : "UNKNOWN";
        var service = health.TryGetProperty("service", out var serviceNode) ? serviceNode.GetString() ?? "Agentic AI" : "Agentic AI";
        var writeStatus = health.TryGetProperty("write_status", out var writeStatusNode)
            ? writeStatusNode.GetString() ?? "UNKNOWN"
            : "UNKNOWN";
        var adaptiveMemoryEnabled = health.TryGetProperty("adaptive_memory", out var memoryNode) &&
            memoryNode.ValueKind == JsonValueKind.Object &&
            memoryNode.TryGetProperty("enabled", out var memoryEnabledNode) && memoryEnabledNode.ValueKind == JsonValueKind.True;
        var boundedRsiEnabled = health.TryGetProperty("adaptive_memory", out var rsiMemoryNode) &&
            rsiMemoryNode.ValueKind == JsonValueKind.Object &&
            rsiMemoryNode.TryGetProperty("rsi_enabled", out var rsiEnabledNode) && rsiEnabledNode.ValueKind == JsonValueKind.True;
        return new
        {
            status,
            service,
            available = status.Equals("READY", StringComparison.OrdinalIgnoreCase) ||
                        status.Equals("LIVE", StringComparison.OrdinalIgnoreCase) ||
                        status.Equals("ONLINE", StringComparison.OrdinalIgnoreCase) ||
                        (status.Equals("DEGRADED", StringComparison.OrdinalIgnoreCase) &&
                         health.TryGetProperty("live", out var liveNode) && liveNode.ValueKind == JsonValueKind.True),
            writeStatus,
            adaptiveMemory = new { enabled = adaptiveMemoryEnabled, rsi_enabled = boundedRsiEnabled, bounded = true },
            accessMode = profile.Permissions.PlanAgenticUpdates ? "governed-write" : "read-only",
            role = profile.Code
        };
    }

    private static string ProjectAgenticPayloadForRole(string rawJson, RoleViewProfile profile)
    {
        if (RusRoles.Normalize(profile.Code) == RusRoles.Admin) return rawJson;
        var node = JsonNode.Parse(rawJson);
        if (node is null) return "{}";
        PruneAgenticNode(node, profile.Code);
        return node.ToJsonString(new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true });
    }

    private static void PruneAgenticNode(JsonNode node, string role)
    {
        if (node is JsonArray array)
        {
            foreach (var item in array)
            {
                if (item is not null) PruneAgenticNode(item, role);
            }
            return;
        }
        if (node is not JsonObject obj) return;

        var normalizedRole = RusRoles.Normalize(role);
        var isCustomer = normalizedRole == RusRoles.Customer;
        var isBusiness = normalizedRole == RusRoles.Business;
        foreach (var property in obj.ToList())
        {
            var normalized = new string(property.Key.Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());

            // Business and Customer Support need the aggregate elapsed time in both the
            // on-screen KPI row and their downloaded report, but not connector-level
            // performance diagnostics. Preserve only the report-level timing summary.
            if ((isCustomer || isBusiness) && normalized == "timings")
            {
                obj[property.Key] = BuildAggregateTimingProjection(property.Value);
                continue;
            }
            // v11.52: every role-safe report must retain the canonical attribute values
            // observed from CPS, Rewards DB, and CrowdTwist. The upstream report has
            // already applied masking when required, so preserve only the compact
            // observation contract here rather than raw connector payloads.
            if (normalized == "observations")
            {
                obj[property.Key] = BuildRoleObservationProjection(property.Value, normalizedRole);
                continue;
            }
            var technical = normalized.Contains("raw", StringComparison.Ordinal) ||
                            normalized.Contains("payload", StringComparison.Ordinal) ||
                            normalized.Contains("header", StringComparison.Ordinal) ||
                            normalized.Contains("token", StringComparison.Ordinal) ||
                            normalized.Contains("secret", StringComparison.Ordinal) ||
                            normalized.Contains("connectionstring", StringComparison.Ordinal) ||
                            normalized.Contains("stacktrace", StringComparison.Ordinal) ||
                            normalized.Contains("traceback", StringComparison.Ordinal) ||
                            normalized.Contains("mcpevidence", StringComparison.Ordinal) ||
                            normalized.Contains("identifierresolution", StringComparison.Ordinal) ||
                            normalized.Contains("sourcetiming", StringComparison.Ordinal) ||
                            normalized == "records" || normalized == "record" || normalized == "dependencies";
            var focusedInternal = (isCustomer || isBusiness) && (
                            normalized.Contains("timing", StringComparison.Ordinal) ||
                            normalized.Contains("latency", StringComparison.Ordinal) ||
                            normalized.Contains("httpstatus", StringComparison.Ordinal) ||
                            normalized.Contains("retrievalmethod", StringComparison.Ordinal) ||
                            normalized.Contains("lookupattempt", StringComparison.Ordinal) ||
                            normalized.Contains("agentexecution", StringComparison.Ordinal) ||
                            normalized.Contains("judgeoutcomes", StringComparison.Ordinal) ||
                            normalized.Contains("crowdtwistid", StringComparison.Ordinal) ||
                            normalized.Contains("memberkey", StringComparison.Ordinal) ||
                            normalized.Contains("cityid", StringComparison.Ordinal) ||
                            normalized.Contains("duration", StringComparison.Ordinal) ||
                            normalized.Contains("correlationid", StringComparison.Ordinal) ||
                            normalized.Contains("requestid", StringComparison.Ordinal) ||
                            normalized.Contains("datacollectionms", StringComparison.Ordinal) ||
                            normalized.Contains("analysisagentms", StringComparison.Ordinal) ||
                            normalized.Contains("judgeagentms", StringComparison.Ordinal) ||
                            normalized.Contains("dellaiaqueuewaitms", StringComparison.Ordinal) ||
                            normalized.Contains("sourcequeuewaitms", StringComparison.Ordinal) ||
                            normalized.Contains("phasebarrierwaitms", StringComparison.Ordinal));
            if (technical || focusedInternal)
            {
                obj.Remove(property.Key);
                continue;
            }
            if (property.Value is not null) PruneAgenticNode(property.Value, role);
        }
    }

    private static JsonObject BuildRoleObservationProjection(JsonNode? source, string role)
    {
        var result = new JsonObject();
        if (source is not JsonObject observations) return result;
        var technical = RusRoles.Normalize(role) == RusRoles.Technical;

        foreach (var property in observations)
        {
            if (property.Value is not JsonObject observation) continue;
            var projected = new JsonObject();
            foreach (var key in new[] { "source", "supported", "present", "source_connected", "record_found", "raw_value", "valid_format" })
            {
                if (observation.TryGetPropertyValue(key, out var value) && value is not null)
                    projected[key] = value.DeepClone();
            }
            if (technical)
            {
                foreach (var key in new[] { "normalized_value", "normalization_note" })
                {
                    if (observation.TryGetPropertyValue(key, out var value) && value is not null)
                        projected[key] = value.DeepClone();
                }
            }
            result[property.Key] = projected;
        }
        return result;
    }

    private static JsonObject BuildAggregateTimingProjection(JsonNode? source)
    {
        var result = new JsonObject();
        if (source is not JsonObject timings) return result;

        foreach (var key in new[] { "batch_total_ms", "end_to_end_ms", "batch_member_end_to_end_ms", "total_processing_ms", "total_ms" })
        {
            if (timings.TryGetPropertyValue(key, out var value) && value is not null)
            {
                result[key] = value.DeepClone();
            }
        }

        // Older reports occasionally used a nested total object. Recover a single
        // aggregate value without exposing detailed stage/source timings.
        if (result.Count == 0 && TryFindAggregateDuration(timings, out var aggregateMs))
        {
            result["end_to_end_ms"] = aggregateMs;
        }
        return result;
    }

    private static bool TryFindAggregateDuration(JsonNode? node, out double milliseconds)
    {
        milliseconds = 0;
        if (node is not JsonObject obj) return false;
        foreach (var property in obj)
        {
            var normalized = new string(property.Key.Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());
            if (normalized is "endtoendms" or "totalprocessingms" or "batchmemberendtoendms" or "totalms")
            {
                if (TryNodeDouble(property.Value, out milliseconds)) return true;
            }
        }
        foreach (var property in obj)
        {
            if (TryFindAggregateDuration(property.Value, out milliseconds)) return true;
        }
        return false;
    }

    private static string BuildRoleSafeHtmlReport(
        string runId,
        RoleViewProfile profile,
        bool masked,
        string projectedJson)
    {
        JsonObject root;
        try
        {
            root = JsonNode.Parse(projectedJson) as JsonObject ?? new JsonObject();
        }
        catch
        {
            root = new JsonObject();
        }

        var role = RusRoles.Normalize(profile.Code);
        var isTechnical = role == RusRoles.Technical;
        var isBusiness = role == RusRoles.Business;
        var isCustomer = role == RusRoles.Customer;
        var privacy = masked ? "Masked" : "Unmasked";
        var created = NodeText(root["created_at"]);
        var searchValue = NodeText(root["search_value"]);
        var coverage = NodeText(root["analysis_completeness"], "—").Replace('_', ' ');
        var mismatchCount = NodeText(root["mismatch_count"], "0");
        var missingRecords = NodeText(root["missing_record_count"], "0");
        var exactChanges = NodeText(root["actionable_suggestion_count"], "0");
        var manualReview = NodeText(root["manual_review_count"], "0");
        var judge = NodeText(root["judge_result"]?["verdict"] ?? root["ai_execution"]?["judge_verdict"], "—");
        var totalMs = GetAggregateDuration(root["timings"]);
        var totalTime = FormatReportDuration(totalMs);
        var title = $"RUS {profile.Label} report — {runId}";
        var summary = NodeText(root["deterministic_summary"], "No deterministic summary was returned.");
        var truthPolicy = NodeText(root["truth_policy"]);

        var sb = new StringBuilder(32_000);
        sb.Append("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">");
        sb.Append("<title>").Append(Html(title)).Append("</title><style>");
        sb.Append(RoleReportCss());
        sb.Append("</style></head><body><main>");
        sb.Append("<header class=\"hero\"><div class=\"role-chip\">").Append(Html(profile.Label)).Append(" · ").Append(Html(privacy)).Append("</div>");
        sb.Append("<h1>").Append(Html(title)).Append("</h1><p>");
        sb.Append(isTechnical
            ? "Operational report with source diagnostics and governed-change evidence. Raw connector payloads, credentials, and secrets are omitted."
            : isBusiness
                ? "Business-focused disparity report with the verified summary, recommended corrections, source coverage, and elapsed time."
                : "Customer-support summary with verified issues and recommended next actions. Technical implementation details are intentionally omitted.");
        sb.Append("</p><div class=\"hero-meta\">");
        if (!string.IsNullOrWhiteSpace(searchValue)) sb.Append(Chip("Member", searchValue));
        if (!string.IsNullOrWhiteSpace(created)) sb.Append(Chip("Created", created));
        sb.Append(Chip("Total time", totalTime)).Append("</div></header>");

        sb.Append("<section class=\"content\"><div class=\"kpi-grid\">");
        sb.Append(Kpi("Coverage", coverage));
        sb.Append(Kpi("Mismatches", mismatchCount));
        sb.Append(Kpi("Missing records", missingRecords));
        sb.Append(Kpi(isCustomer ? "Recommendations" : "Exact changes", exactChanges));
        sb.Append(Kpi("Manual review", manualReview));
        if (!isCustomer) sb.Append(Kpi("Judge", judge));
        sb.Append(Kpi("Total time", totalTime));
        sb.Append("</div>");

        sb.Append("<section class=\"panel executive\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Verified result</span><h2>Executive summary</h2></div></div>");
        sb.Append("<p class=\"summary-copy\">").Append(Html(summary)).Append("</p>");
        if (!isCustomer && !string.IsNullOrWhiteSpace(truthPolicy))
        {
            sb.Append("<div class=\"policy\"><strong>Truth policy</strong><span>").Append(Html(truthPolicy)).Append("</span></div>");
        }
        sb.Append("</section>");

        sb.Append(BuildRoleSuggestionSection(root, isTechnical, isBusiness, isCustomer));
        sb.Append(BuildRoleIssueSection(root, isTechnical, isBusiness, isCustomer));
        sb.Append(BuildRoleSourceSection(root, isTechnical));

        if (isTechnical)
        {
            sb.Append(BuildTechnicalGovernanceSection(root));
            sb.Append(BuildTechnicalTimingSection(root["timings"]));
        }
        else
        {
            sb.Append("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Performance</span><h2>Analysis timing</h2></div></div><div class=\"time-callout\"><strong>")
              .Append(Html(totalTime)).Append("</strong><span>Total end-to-end analysis time</span></div></section>");
        }

        var warnings = root["warnings"] as JsonArray;
        if (warnings is { Count: > 0 })
        {
            sb.Append("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Attention</span><h2>Warnings</h2></div></div><ul class=\"clean-list\">");
            foreach (var warning in warnings) sb.Append("<li>").Append(Html(NodeText(warning))).Append("</li>");
            sb.Append("</ul></section>");
        }

        // v11.52: final collapsed canonical source-value table for every role.
        sb.Append(BuildRoleAttributeDataSection(root, role));

        sb.Append("<footer>Generated by RUS Agentic Data Disparity · Role-safe ").Append(Html(profile.Label)).Append(" view · ").Append(Html(privacy)).Append("</footer>");
        sb.Append("</section></main></body></html>");
        return sb.ToString();
    }

    private static string BuildRoleSuggestionSection(JsonObject root, bool isTechnical, bool isBusiness, bool isCustomer)
    {
        var suggestions = root["suggestions"] as JsonArray;
        var sb = new StringBuilder();
        sb.Append("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Recommended action</span><h2>Suggested changes</h2></div><span class=\"count-chip\">")
          .Append(suggestions?.Count ?? 0).Append("</span></div>");
        if (suggestions is null || suggestions.Count == 0)
        {
            sb.Append("<div class=\"empty\">No exact source changes were recommended.</div></section>");
            return sb.ToString();
        }
        sb.Append("<div class=\"suggestion-grid\">");
        foreach (var node in suggestions.OfType<JsonObject>())
        {
            var label = NodeText(node["label"] ?? node["attribute"], "Suggested change");
            var priority = NodeText(node["priority"], "Review");
            var recommendation = NodeText(node["recommendation"] ?? node["reason"] ?? node["action"], "Review this item.");
            var current = NodeText(node["current_value"]);
            var recommended = NodeText(node["recommended_value"]);
            var target = NodeText(node["target_source"]);
            var truth = NodeText(node["truth_source"]);
            sb.Append("<article class=\"suggestion\"><div class=\"suggestion-head\"><h3>").Append(Html(label)).Append("</h3><span class=\"priority ").Append(PriorityCss(priority)).Append("\">").Append(Html(priority)).Append("</span></div>");
            sb.Append("<p>").Append(Html(recommendation)).Append("</p>");
            if (!string.IsNullOrWhiteSpace(current) || !string.IsNullOrWhiteSpace(recommended))
            {
                sb.Append("<div class=\"change-line\"><span class=\"before\">").Append(Html(string.IsNullOrWhiteSpace(current) ? "—" : current)).Append("</span><b>→</b><span class=\"after\">").Append(Html(string.IsNullOrWhiteSpace(recommended) ? "—" : recommended)).Append("</span></div>");
            }
            if (!isCustomer)
            {
                sb.Append("<div class=\"meta-row\">");
                if (!string.IsNullOrWhiteSpace(target)) sb.Append(Meta("Target", FriendlySource(target)));
                if ((isBusiness || isTechnical) && !string.IsNullOrWhiteSpace(truth)) sb.Append(Meta("Truth", FriendlySource(truth)));
                if (isTechnical) sb.Append(Meta("Automation", NodeBool(node["automation_eligible"]) ? "Eligible" : "Review"));
                sb.Append("</div>");
            }
            sb.Append("</article>");
        }
        sb.Append("</div></section>");
        return sb.ToString();
    }

    private static string BuildRoleIssueSection(JsonObject root, bool isTechnical, bool isBusiness, bool isCustomer)
    {
        var attributes = root["attributes"] as JsonArray;
        var rows = attributes?.OfType<JsonObject>()
            .Where(item => isTechnical || !NodeText(item["status"]).Equals("MATCH", StringComparison.OrdinalIgnoreCase))
            .ToList() ?? new List<JsonObject>();
        var sb = new StringBuilder();
        sb.Append("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Verified findings</span><h2>")
          .Append(isTechnical ? "Attribute verdicts" : "Issues found").Append("</h2></div><span class=\"count-chip\">").Append(rows.Count).Append("</span></div>");
        if (rows.Count == 0)
        {
            sb.Append("<div class=\"empty\">No attribute-level issues require attention.</div></section>");
            return sb.ToString();
        }
        sb.Append("<div class=\"table-wrap\"><table><thead><tr><th>Attribute</th><th>Status</th>");
        if (!isCustomer) sb.Append("<th>Truth source</th>");
        if (isTechnical || isBusiness) sb.Append("<th>Truth value</th>");
        sb.Append("<th>Explanation</th></tr></thead><tbody>");
        foreach (var item in rows)
        {
            var label = NodeText(item["label"] ?? item["attribute"], "Attribute");
            var status = NodeText(item["status"], "—");
            sb.Append("<tr><td><strong>").Append(Html(label)).Append("</strong></td><td><span class=\"status-pill ").Append(StatusCss(status)).Append("\">").Append(Html(status.Replace('_', ' '))).Append("</span></td>");
            if (!isCustomer) sb.Append("<td>").Append(Html(FriendlySource(NodeText(item["truth_source"], "—")))).Append("</td>");
            if (isTechnical || isBusiness) sb.Append("<td>").Append(Html(NodeText(item["truth_value"], "—"))).Append("</td>");
            sb.Append("<td>").Append(Html(NodeText(item["explanation"], "—"))).Append("</td></tr>");
        }
        sb.Append("</tbody></table></div></section>");
        return sb.ToString();
    }

    private static string BuildRoleAttributeDataSection(JsonObject root, string role)
    {
        var normalizedRole = RusRoles.Normalize(role);
        var isTechnical = normalizedRole == RusRoles.Technical;
        var isBusiness = normalizedRole == RusRoles.Business;
        var isCustomer = normalizedRole == RusRoles.Customer;
        var attributes = root["attributes"] as JsonArray;
        var rows = attributes?.OfType<JsonObject>().ToList() ?? new List<JsonObject>();
        var sb = new StringBuilder();
        sb.Append("<details class=\"panel verdict-details\"><summary><span><span class=\"eyebrow\">Actual source data</span><strong>Attribute Verdicts</strong><small>Values retrieved from CPS, Rewards DB, and CrowdTwist</small></span><b>")
          .Append(rows.Count).Append(" attributes</b></summary>");
        if (rows.Count == 0)
        {
            return sb.Append("<div class=\"empty verdict-empty\">No attribute observations were returned.</div></details>").ToString();
        }
        sb.Append("<div class=\"verdict-body\"><div class=\"table-wrap\"><table class=\"verdict-table\"><thead><tr><th>Attribute</th><th>Status</th>");
        if (!isCustomer) sb.Append("<th>Truth source</th><th>Expected / truth value</th>");
        sb.Append("<th>CPS</th><th>Rewards DB</th><th>CrowdTwist</th>");
        if (isTechnical) sb.Append("<th>Explanation</th>");
        sb.Append("</tr></thead><tbody>");
        foreach (var item in rows)
        {
            var observations = item["observations"] as JsonObject;
            string SourceValue(string key)
            {
                var observation = observations?[key] as JsonObject;
                if (observation is null) return "—";
                var connected = NodeBool(observation["source_connected"]);
                var recordFound = NodeBool(observation["record_found"]);
                var present = NodeBool(observation["present"]);
                if (!connected) return "Source unavailable";
                if (!recordFound) return "No member record";
                if (!present) return "—";
                return NodeText(observation["raw_value"], "—");
            }

            var label = NodeText(item["label"] ?? item["attribute"], "Attribute");
            var status = NodeText(item["status"], "—");
            sb.Append("<tr><td><strong>").Append(Html(label)).Append("</strong><small>").Append(Html(NodeText(item["attribute"]))).Append("</small></td>")
              .Append("<td><span class=\"status-pill ").Append(StatusCss(status)).Append("\">").Append(Html(status.Replace('_', ' '))).Append("</span></td>");
            if (!isCustomer)
            {
                sb.Append("<td>").Append(Html(FriendlySource(NodeText(item["truth_source"], "—")))).Append("</td>")
                  .Append("<td><strong>").Append(Html(NodeText(item["truth_value"], "—"))).Append("</strong></td>");
            }
            sb.Append("<td class=\"value-cell\">").Append(Html(SourceValue("cps"))).Append("</td>")
              .Append("<td class=\"value-cell\">").Append(Html(SourceValue("rewards_db"))).Append("</td>")
              .Append("<td class=\"value-cell\">").Append(Html(SourceValue("crowd_twist"))).Append("</td>");
            if (isTechnical) sb.Append("<td>").Append(Html(NodeText(item["explanation"], "—"))).Append("</td>");
            sb.Append("</tr>");
        }
        sb.Append("</tbody></table></div>");
        if (isBusiness) sb.Append("<p class=\"details-note\">This table shows the canonical values used by the deterministic comparison. Connector payloads and technical diagnostics are intentionally omitted.</p>");
        if (isCustomer) sb.Append("<p class=\"details-note\">Values are shown under the Customer Support masking policy. Technical truth-policy and connector details are omitted.</p>");
        sb.Append("</div></details>");
        return sb.ToString();
    }

    private static string BuildRoleSourceSection(JsonObject root, bool isTechnical)
    {
        var sourceStatus = root["source_status"] as JsonObject;
        var sb = new StringBuilder();
        sb.Append("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Coverage</span><h2>Source availability</h2></div></div><div class=\"source-grid\">");
        foreach (var (key, label) in new[] { ("cps", "CPS"), ("rewards_db", "Rewards DB"), ("crowd_twist", "CrowdTwist") })
        {
            var item = sourceStatus?[key] as JsonObject;
            var connected = NodeBool(item?["connected"]);
            var found = NodeBool(item?["data_found"]);
            var state = !connected ? "Unavailable" : found ? "Data found" : "No member/value";
            var css = !connected ? "bad" : found ? "good" : "warn";
            sb.Append("<article class=\"source-card ").Append(css).Append("\"><div><span class=\"source-dot\"></span><strong>").Append(label).Append("</strong></div><b>").Append(Html(state)).Append("</b>");
            if (isTechnical && item is not null)
            {
                sb.Append("<dl>").Append(DtDd("Method", NodeText(item["retrieval_method"], "—")))
                  .Append(DtDd("Stage", NodeText(item["stage"], "—")))
                  .Append(DtDd("HTTP", NodeText(item["http_status"], "—")))
                  .Append(DtDd("Latency", FormatReportDuration(GetNodeDouble(item["latency_ms"])))).Append("</dl>");
            }
            sb.Append("</article>");
        }
        sb.Append("</div></section>");
        return sb.ToString();
    }

    private static string BuildTechnicalGovernanceSection(JsonObject root)
    {
        var judge = root["judge_result"] as JsonObject;
        var execution = root["ai_execution"] as JsonObject;
        var verdict = NodeText(judge?["verdict"] ?? execution?["judge_verdict"], "—");
        var disposition = NodeText(judge?["content_disposition"] ?? execution?["final_content_status"], "—");
        var summary = NodeText(judge?["corrected_summary"] ?? root["ai_analysis"]?["summary"], "No Judge summary was returned.");
        return $"<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Governance</span><h2>Dell AIA Judge and publication</h2></div></div><div class=\"judge-grid\">{Kpi("Judge verdict", verdict)}{Kpi("Published content", disposition)}</div><p class=\"summary-copy\">{Html(summary)}</p></section>";
    }

    private static string BuildTechnicalTimingSection(JsonNode? timings)
    {
        var rows = new List<(string Label, double Value)>();
        FlattenTimingNodes(timings, string.Empty, rows);
        var sb = new StringBuilder("<section class=\"panel\"><div class=\"section-heading\"><div><span class=\"eyebrow\">Performance</span><h2>Execution timing</h2></div></div>");
        if (rows.Count == 0) return sb.Append("<div class=\"empty\">No timing data returned.</div></section>").ToString();
        sb.Append("<div class=\"table-wrap\"><table><thead><tr><th>Step</th><th>Duration</th></tr></thead><tbody>");
        foreach (var row in rows) sb.Append("<tr><td>").Append(Html(row.Label)).Append("</td><td><strong>").Append(Html(FormatReportDuration(row.Value))).Append("</strong></td></tr>");
        sb.Append("</tbody></table></div></section>");
        return sb.ToString();
    }

    private static void FlattenTimingNodes(JsonNode? node, string prefix, List<(string Label, double Value)> output)
    {
        if (node is not JsonObject obj) return;
        foreach (var property in obj)
        {
            var label = string.IsNullOrWhiteSpace(prefix) ? property.Key : $"{prefix} · {property.Key}";
            if (property.Value is JsonObject)
            {
                FlattenTimingNodes(property.Value, label, output);
            }
            else if (TryNodeDouble(property.Value, out var value) && (property.Key.EndsWith("_ms", StringComparison.OrdinalIgnoreCase) || value >= 0))
            {
                output.Add((label.Replace('_', ' '), value));
            }
        }
    }

    private static string RoleReportCss() => """
*{box-sizing:border-box}body{font-family:Segoe UI,Arial,sans-serif;background:#eef3f8;color:#182230;margin:0;padding:28px}main{max-width:1180px;margin:auto;background:#fff;border:1px solid #dce5ef;border-radius:22px;box-shadow:0 18px 52px rgba(22,45,73,.10);overflow:hidden}.hero{padding:32px 36px;background:linear-gradient(125deg,#0867b5,#00a4b8);color:#fff}.hero h1{margin:10px 0 8px;font-size:clamp(25px,3vw,34px)}.hero p{margin:0;max-width:880px;line-height:1.55;opacity:.94}.role-chip,.hero-meta span,.count-chip,.priority,.status-pill{display:inline-flex;align-items:center;border-radius:999px;font-weight:700}.role-chip{padding:6px 11px;background:rgba(255,255,255,.18);font-size:12px}.hero-meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px}.hero-meta span{padding:6px 10px;background:rgba(255,255,255,.13);font-size:12px}.content{padding:26px 30px 10px}.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:18px}.kpi{border:1px solid #dfe7f0;border-radius:15px;padding:15px;background:#fbfcfe}.kpi span{display:block;color:#667085;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em}.kpi strong{display:block;margin-top:6px;font-size:20px;color:#14233a}.panel{border:1px solid #dfe7f0;border-radius:17px;padding:21px;margin:14px 0;background:#fff}.section-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:15px}.section-heading h2{margin:3px 0 0;font-size:20px}.eyebrow{font-size:11px;text-transform:uppercase;letter-spacing:.12em;font-weight:800;color:#0878b6}.count-chip{background:#edf6fb;color:#076ca3;padding:5px 9px;font-size:12px}.summary-copy{font-size:15px;line-height:1.65;color:#344054}.policy{display:grid;gap:4px;margin-top:14px;background:#f5f8fc;border-left:4px solid #1487bf;border-radius:9px;padding:12px 14px}.policy span{color:#475467;line-height:1.5}.suggestion-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px}.suggestion{border:1px solid #dde6ef;border-radius:14px;padding:16px;background:#fcfdff}.suggestion-head{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}.suggestion h3{margin:0;font-size:16px}.suggestion p{color:#475467;line-height:1.5}.priority{font-size:10px;padding:5px 8px;text-transform:uppercase}.priority.high,.priority.critical{background:#fff1e8;color:#9b3c0a}.priority.medium{background:#fff8d9;color:#775b00}.priority.low{background:#e9f8ef;color:#087443}.change-line{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin-top:10px;font-weight:800}.before{color:#9b4c10;text-decoration:line-through}.after{color:#087443}.meta-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.meta{background:#f0f4f8;border-radius:8px;padding:6px 8px;font-size:12px;color:#475467}.table-wrap{overflow-x:auto;border:1px solid #e3e9f0;border-radius:12px}table{width:100%;border-collapse:collapse;min-width:720px}th,td{text-align:left;padding:11px 12px;border-bottom:1px solid #e8edf3;vertical-align:top}th{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#667085;background:#f7f9fc}td{font-size:13px;line-height:1.45}.status-pill{padding:4px 8px;font-size:10px}.status-pill.good{background:#e9f8ef;color:#087443}.status-pill.warn{background:#fff5d9;color:#7a5900}.status-pill.bad{background:#fff0f0;color:#b42318}.source-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.source-card{border:1px solid #dfe7f0;border-radius:13px;padding:14px}.source-card>div:first-child{display:flex;gap:8px;align-items:center}.source-card>b{display:block;margin:8px 0;color:#344054}.source-dot{width:9px;height:9px;border-radius:50%;background:#98a2b3}.source-card.good .source-dot{background:#12b76a}.source-card.warn .source-dot{background:#f79009}.source-card.bad .source-dot{background:#f04438}.source-card dl{display:grid;grid-template-columns:auto 1fr;gap:5px 10px;margin:10px 0 0;font-size:12px}.source-card dt{color:#667085}.source-card dd{margin:0;font-weight:600;overflow-wrap:anywhere}.judge-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.time-callout{display:flex;align-items:baseline;gap:10px;padding:14px;border-radius:12px;background:#f5f9fc}.time-callout strong{font-size:25px;color:#086ba7}.time-callout span{color:#667085}.clean-list{margin:0;padding-left:20px;color:#475467}.empty{padding:18px;border-radius:12px;background:#f8fafc;color:#667085;text-align:center}footer{padding:18px 0 10px;color:#98a2b3;text-align:center;font-size:11px}@media(max-width:760px){body{padding:0;background:#fff}main{border:0;border-radius:0;box-shadow:none}.hero{padding:24px 20px}.content{padding:18px 16px}.source-grid,.judge-grid{grid-template-columns:1fr}.panel{padding:16px}.suggestion-grid{grid-template-columns:1fr}}
""";

    private static string Kpi(string label, string value) => $"<div class=\"kpi\"><span>{Html(label)}</span><strong>{Html(value)}</strong></div>";
    private static string Chip(string label, string value) => $"<span>{Html(label)}: {Html(value)}</span>";
    private static string Meta(string label, string value) => $"<span class=\"meta\"><strong>{Html(label)}:</strong> {Html(value)}</span>";
    private static string DtDd(string label, string value) => $"<dt>{Html(label)}</dt><dd>{Html(value)}</dd>";
    private static string Html(string? value) => WebUtility.HtmlEncode(value ?? string.Empty);

    private static string NodeText(JsonNode? node, string fallback = "")
    {
        if (node is null) return fallback;
        if (node is JsonValue value)
        {
            if (value.TryGetValue<string>(out var text)) return string.IsNullOrWhiteSpace(text) ? fallback : text;
            if (value.TryGetValue<bool>(out var boolean)) return boolean ? "True" : "False";
            if (value.TryGetValue<long>(out var integer)) return integer.ToString(System.Globalization.CultureInfo.InvariantCulture);
            if (value.TryGetValue<double>(out var number)) return number.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);
        }
        var rendered = node.ToJsonString();
        return string.IsNullOrWhiteSpace(rendered) ? fallback : rendered;
    }

    private static bool NodeBool(JsonNode? node)
    {
        if (node is JsonValue value)
        {
            if (value.TryGetValue<bool>(out var boolean)) return boolean;
            if (value.TryGetValue<string>(out var text) && bool.TryParse(text, out var parsed)) return parsed;
        }
        return false;
    }

    private static bool TryNodeDouble(JsonNode? node, out double value)
    {
        value = 0;
        if (node is not JsonValue jsonValue) return false;
        if (jsonValue.TryGetValue<double>(out value)) return true;
        if (jsonValue.TryGetValue<long>(out var integer)) { value = integer; return true; }
        if (jsonValue.TryGetValue<string>(out var text) && double.TryParse(text, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out value)) return true;
        return false;
    }

    private static double GetNodeDouble(JsonNode? node) => TryNodeDouble(node, out var value) ? value : 0;

    private static double GetAggregateDuration(JsonNode? timings)
    {
        if (timings is not JsonObject obj) return 0;
        foreach (var key in new[] { "batch_total_ms", "end_to_end_ms", "batch_member_end_to_end_ms", "total_processing_ms", "total_ms" })
        {
            if (obj.TryGetPropertyValue(key, out var node) && TryNodeDouble(node, out var value) && value >= 0) return value;
        }
        return TryFindAggregateDuration(obj, out var nested) ? nested : 0;
    }

    private static string FormatReportDuration(double milliseconds)
    {
        if (milliseconds <= 0) return "—";
        if (milliseconds < 1000) return $"{milliseconds:0} ms";
        if (milliseconds < 60_000) return $"{milliseconds / 1000d:0.0} s";
        return $"{milliseconds / 60_000d:0.0} min";
    }

    private static string FriendlySource(string value) => value.Trim().ToLowerInvariant() switch
    {
        "cps" => "CPS",
        "rewards_db" or "rewardsdb" => "Rewards DB",
        "crowd_twist" or "crowdtwist" => "CrowdTwist",
        _ => value
    };

    private static string PriorityCss(string value) => value.Trim().ToLowerInvariant() switch
    {
        "critical" => "critical",
        "high" => "high",
        "low" => "low",
        _ => "medium"
    };

    private static string StatusCss(string value)
    {
        var normalized = value.Trim().ToUpperInvariant();
        if (normalized == "MATCH") return "good";
        if (normalized.Contains("MISMATCH") || normalized.Contains("INVALID") || normalized.Contains("MISSING")) return "bad";
        return "warn";
    }

    private static string NormalizeSpreadsheetHeader(string? value) =>
        new string((value ?? string.Empty).Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());

    private static int? FindSpreadsheetColumn(Dictionary<string, int> headers, params string[] aliases)
    {
        foreach (var alias in aliases)
        {
            var normalized = NormalizeSpreadsheetHeader(alias);
            if (headers.TryGetValue(normalized, out var column)) return column;
        }
        return null;
    }

    private static string SpreadsheetCellText(IXLCell cell)
    {
        if (cell.IsEmpty()) return string.Empty;
        if (cell.DataType == XLDataType.Number)
        {
            var number = cell.GetDouble();
            if (Math.Abs(number - Math.Round(number)) < 0.0000001)
                return Math.Round(number).ToString("0", System.Globalization.CultureInfo.InvariantCulture);
            return number.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }
        if (cell.DataType == XLDataType.Boolean) return cell.GetBoolean() ? "TRUE" : "FALSE";
        return cell.GetFormattedString().Trim();
    }

    private static object? SpreadsheetCellValue(IXLCell cell)
    {
        if (cell.IsEmpty()) return string.Empty;
        return cell.DataType switch
        {
            XLDataType.Boolean => cell.GetBoolean(),
            XLDataType.Number when Math.Abs(cell.GetDouble() - Math.Round(cell.GetDouble())) < 0.0000001
                => Convert.ToInt64(Math.Round(cell.GetDouble())),
            XLDataType.Number => cell.GetDouble(),
            XLDataType.DateTime => cell.GetDateTime().ToString("O"),
            _ => cell.GetFormattedString().Trim()
        };
    }

    private static string? NormalizeSpreadsheetSource(string? value, bool defaultCrowdTwist)
    {
        var normalized = NormalizeSpreadsheetHeader(value);
        if (string.IsNullOrWhiteSpace(normalized)) return defaultCrowdTwist ? "crowd_twist" : "rewards_db";
        return normalized switch
        {
            "crowdtwist" or "ct" or "loyalty" => "crowd_twist",
            "rewardsdb" or "rewardsdatabase" or "memberdb" => "rewards_db",
            _ => null
        };
    }

    private RoleViewProfile CurrentRoleProfile()
    {
        var role = User.FindFirstValue(ClaimTypes.Role) ?? User.FindFirstValue("role") ?? RusRoles.Customer;
        return RusRoles.Profile(role);
    }

    private bool CurrentDryRunEnabled()
    {
        var role = User.FindFirstValue(ClaimTypes.Role) ?? User.FindFirstValue("role") ?? RusRoles.Customer;
        if (RusRoles.IsAdmin(role)) return false;
        return string.Equals(User.FindFirstValue("dry_run_enabled"), "true", StringComparison.OrdinalIgnoreCase);
    }

    private string CurrentEffectiveWriteMode() => CurrentDryRunEnabled() ? "dry_run" : "live";

    private bool EffectiveReportMasked(bool requestedMasked) =>
        requestedMasked || !CurrentRoleProfile().Permissions.ViewUnmaskedReports;

    private static string NormalizeSearchType(string? searchType) =>
        (searchType ?? "email").Trim().ToLowerInvariant() switch
        {
            "profileid" or "profile_id" or "profile-id" => "profileid",
            "crowdtwistid" or "crowd_twist_id" or "crowdtwist_id" or "crowd-twist-id" => "crowdtwistid",
            _ => "email"
        };

    private static SessionCreateProxyRequest NewSessionRequest(AuditActor actor)
    {
        var request = new SessionCreateProxyRequest();
        ApplyActorMetadata(request.Metadata, actor);
        return request;
    }

    private static void ApplyActorMetadata(Dictionary<string, object?> metadata, AuditActor actor)
    {
        metadata["channel"] = "dotnet-rus-ui";
        metadata["actor"] = actor.Name;
        metadata["actor_username"] = actor.Username;
        metadata["actor_display_name"] = actor.DisplayName;
        metadata["actor_email"] = actor.Email;
        metadata["actor_role"] = actor.Role;
        metadata["actor_id"] = actor.UserId;
        metadata["actor_dry_run_enabled"] = RusRoles.Normalize(actor.Role) == RusRoles.Admin ? false : actor.DryRunEnabled;
        metadata["effective_write_mode"] = RusRoles.Normalize(actor.Role) == RusRoles.Admin ? "live" : actor.DryRunEnabled ? "dry_run" : "live";
    }

    private void ApplyActor(IndividualAnalysisProxyRequest request)
    {
        var actor = _actorResolver.Resolve();
        request.Actor = actor.Name;
        request.ActorEmail = actor.Email;
        request.ActorRole = RusRoles.Normalize(actor.Role);
        request.ActorDryRunEnabled = request.ActorRole == RusRoles.Admin ? false : actor.DryRunEnabled;
        request.ActorId = actor.UserId;
    }

    private void ApplyActor(ChatProxyRequest request)
    {
        var actor = _actorResolver.Resolve();
        request.Actor = actor.Name;
        request.ActorEmail = actor.Email;
        request.ActorRole = RusRoles.Normalize(actor.Role);
        request.ActorDryRunEnabled = request.ActorRole == RusRoles.Admin ? false : actor.DryRunEnabled;
    }


    private void ApplyActor(SourceQueryProxyRequest request)
    {
        var actor = _actorResolver.Resolve();
        request.Actor = actor.Name;
        request.ActorEmail = actor.Email;
        request.ActorRole = RusRoles.Normalize(actor.Role);
        request.ActorDryRunEnabled = request.ActorRole == RusRoles.Admin ? false : actor.DryRunEnabled;
    }

    private void ApplyActor(SourceChangePlanProxyRequest request)
    {
        var actor = _actorResolver.Resolve();
        request.Actor = actor.Name;
        request.ActorEmail = actor.Email;
        request.ActorRole = RusRoles.Normalize(actor.Role);
        request.ActorDryRunEnabled = request.ActorRole == RusRoles.Admin ? false : actor.DryRunEnabled;
    }

    private void ApplyActor(SourceChangeConfirmationProxyRequest request)
    {
        var actor = _actorResolver.Resolve();
        request.Actor = actor.Name;
        request.ActorEmail = actor.Email;
        request.ActorRole = RusRoles.Normalize(actor.Role);
        request.ActorDryRunEnabled = request.ActorRole == RusRoles.Admin ? false : actor.DryRunEnabled;
    }

    private void ApplyActor(SourceChangePopupOpenedProxyRequest request)
    {
        var actor = _actorResolver.Resolve();
        request.Actor = actor.Name;
        request.ActorEmail = actor.Email;
        request.ActorRole = RusRoles.Normalize(actor.Role);
        request.ActorDryRunEnabled = request.ActorRole == RusRoles.Admin ? false : actor.DryRunEnabled;
    }

    private void ApplyActor(SourceChangeCancelProxyRequest request)
    {
        var actor = _actorResolver.Resolve();
        request.Actor = actor.Name;
        request.ActorEmail = actor.Email;
        request.ActorRole = RusRoles.Normalize(actor.Role);
        request.ActorDryRunEnabled = request.ActorRole == RusRoles.Admin ? false : actor.DryRunEnabled;
    }

    private void ApplyActor(SpreadsheetSourceChangeImportProxyRequest request)
    {
        var actor = _actorResolver.Resolve();
        request.Actor = actor.Name;
        request.ActorEmail = actor.Email;
        request.ActorRole = RusRoles.Normalize(actor.Role);
        request.ActorDryRunEnabled = request.ActorRole == RusRoles.Admin ? false : actor.DryRunEnabled;
    }

}

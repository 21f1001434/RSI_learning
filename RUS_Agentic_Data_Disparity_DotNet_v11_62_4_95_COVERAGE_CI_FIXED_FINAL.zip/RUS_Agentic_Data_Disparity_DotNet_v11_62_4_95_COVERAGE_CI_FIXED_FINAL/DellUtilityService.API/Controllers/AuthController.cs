using System.Security.Claims;
using DellUtilityService.API.Configurations;
using DellUtilityService.API.Models.Auth;
using DellUtilityService.API.Services;
using DellUtilityService.API.Services.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;

namespace DellUtilityService.API.Controllers;

[ApiController]
[Route("api/auth")]
[Produces("application/json")]
public sealed class AuthController : ControllerBase
{
    private readonly IUserStore _users;
    private readonly IPasswordHashService _passwords;
    private readonly IJwtTokenService _tokens;
    private readonly JwtAuthenticationOptions _options;
    private readonly IAuditTrailService _audit;
    private readonly IUserPromptService _prompts;
    private readonly ILogger<AuthController> _logger;

    public AuthController(
        IUserStore users,
        IPasswordHashService passwords,
        IJwtTokenService tokens,
        IOptions<JwtAuthenticationOptions> options,
        IAuditTrailService audit,
        IUserPromptService prompts,
        ILogger<AuthController> logger)
    {
        _users = users;
        _passwords = passwords;
        _tokens = tokens;
        _options = options.Value;
        _audit = audit;
        _prompts = prompts;
        _logger = logger;
    }

    [AllowAnonymous]
    [HttpPost("reset-session")]
    public IActionResult ResetSession()
    {
        DeleteAccessCookie();
        Response.Headers.CacheControl = "no-store";
        return Ok(new { success = true, data = new { cleared = true }, requestId = HttpContext.TraceIdentifier });
    }

    [AllowAnonymous]
    [EnableRateLimiting("login")]
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        var username = request.Username.Trim();
        var user = await _users.FindByUsernameAsync(username, cancellationToken);
        if (user is null || !_passwords.Verify(request.Password, user))
        {
            await AppendAuthAuditAsync(
                username.Length == 0 ? "Unknown user" : username,
                null,
                "Login",
                "Failed",
                username,
                "Invalid username or password.",
                "Authentication rejected",
                cancellationToken);

            return Unauthorized(Error("INVALID_CREDENTIALS", "Invalid username or password."));
        }

        return await CompleteLoginAsync(user, "Login", cancellationToken);
    }

    [AllowAnonymous]
    [EnableRateLimiting("registration")]
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var user = await _users.CreateAsync(
                request.Username,
                request.DisplayName,
                request.Email,
                RusRoles.Customer,
                request.Password,
                cancellationToken);

            await _audit.AppendAsync(new AuditTrailEntry
            {
                Actor = user.Username,
                ActorDisplayName = user.DisplayName,
                ActorId = user.Id,
                ActorUsername = user.Username,
                ActorRole = user.Role,
                ActorEmail = user.Email,
                Channel = "registration-ui",
                Source = "Authentication",
                Action = "User registration",
                Status = "Completed",
                Target = user.Username,
                After = SafeUser(user),
                CorrelationId = HttpContext.TraceIdentifier,
                Verification = "User created and JWT issued",
                Details = RequestDetails(user)
            }, cancellationToken);

            return await CompleteLoginAsync(user, "Registration login", cancellationToken, auditLogin: false);
        }
        catch (DuplicateUserException ex)
        {
            return Conflict(Error("USER_ALREADY_EXISTS", ex.Message));
        }
    }

    [Authorize]
    [HttpGet("me")]
    public async Task<IActionResult> Me(CancellationToken cancellationToken)
    {
        var user = await CurrentUserAsync(cancellationToken);
        if (user is null)
        {
            DeleteAccessCookie();
            return Unauthorized(Error("USER_NOT_FOUND", "The authenticated user is no longer active."));
        }

        var login = _tokens.Issue(user);
        SetAccessCookie(login.AccessToken, login.ExpiresAtUtc);
        Response.Headers.CacheControl = "no-store";
        return Ok(new { success = true, data = login, requestId = HttpContext.TraceIdentifier });
    }

    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout(CancellationToken cancellationToken)
    {
        var user = await CurrentUserAsync(cancellationToken);
        DeleteAccessCookie();
        await _audit.AppendAsync(new AuditTrailEntry
        {
            Actor = user?.Username ?? User.Identity?.Name ?? "Unknown user",
            ActorDisplayName = user?.DisplayName,
            ActorId = user?.Id,
            ActorUsername = user?.Username,
            ActorRole = user?.Role,
            ActorEmail = user?.Email,
            Channel = "login-ui",
            Source = "Authentication",
            Action = "Logout",
            Status = "Completed",
            Target = user?.Username,
            CorrelationId = HttpContext.TraceIdentifier,
            Verification = "Authentication cookie cleared",
            Details = RequestDetails(user)
        }, cancellationToken);
        return Ok(new { success = true, data = new { loggedOut = true }, requestId = HttpContext.TraceIdentifier });
    }

    [Authorize]
    [HttpPost("change-password")]
    public async Task<IActionResult> ChangePassword(
        [FromBody] ChangePasswordRequest request,
        CancellationToken cancellationToken)
    {
        var user = await CurrentUserAsync(cancellationToken);
        if (user is null || !_passwords.Verify(request.CurrentPassword, user))
        {
            return BadRequest(Error("CURRENT_PASSWORD_INVALID", "The current password is incorrect."));
        }
        if (string.Equals(request.CurrentPassword, request.NewPassword, StringComparison.Ordinal))
        {
            return BadRequest(Error("PASSWORD_UNCHANGED", "The new password must be different from the current password."));
        }

        await _users.UpdatePasswordAsync(user.Id, request.NewPassword, cancellationToken);
        var refreshed = await _users.FindByIdAsync(user.Id, cancellationToken)
            ?? throw new InvalidOperationException("The user could not be reloaded after password update.");
        var login = _tokens.Issue(refreshed);
        SetAccessCookie(login.AccessToken, login.ExpiresAtUtc);
        await _audit.AppendAsync(new AuditTrailEntry
        {
            Actor = refreshed.Username,
            ActorDisplayName = refreshed.DisplayName,
            ActorId = refreshed.Id,
            ActorUsername = refreshed.Username,
            ActorRole = refreshed.Role,
            ActorEmail = refreshed.Email,
            Channel = "account-ui",
            Source = "Authentication",
            Action = "Password change",
            Status = "Completed",
            Target = refreshed.Username,
            CorrelationId = HttpContext.TraceIdentifier,
            Verification = "Password hash replaced and JWT reissued",
            Details = RequestDetails(refreshed)
        }, cancellationToken);
        return Ok(new { success = true, data = login, requestId = HttpContext.TraceIdentifier });
    }

    [Authorize(Roles = "Admin")]
    [HttpGet("users")]
    public async Task<IActionResult> Users(CancellationToken cancellationToken)
    {
        var users = await _users.ListAsync(includeInactive: true, cancellationToken: cancellationToken);
        return Ok(new
        {
            success = true,
            data = users.Select(ToAdminResponse),
            requestId = HttpContext.TraceIdentifier
        });
    }

    [Authorize(Roles = "Admin")]
    [HttpPost("users/{id}/dry-run")]
    public async Task<IActionResult> SetUserDryRun(
        string id,
        [FromBody] AdminDryRunRequest request,
        CancellationToken cancellationToken)
    {
        var before = await _users.FindAnyByIdAsync(id, cancellationToken);
        if (before is null) return NotFound(Error("USER_NOT_FOUND", "The user does not exist."));
        if (RusRoles.IsAdmin(before.Role) && request.Enabled)
        {
            return BadRequest(Error(
                "ADMIN_DRY_RUN_NOT_ALLOWED",
                "Dry Run is always disabled for Admin profiles. Administrators use governed live execution."));
        }

        var updated = await _users.SetDryRunAsync(id, request.Enabled, cancellationToken);
        await _audit.AppendAsync(new AuditTrailEntry
        {
            Channel = "admin-ui", Source = "User Administration", Action = "Agentic write mode updated",
            Status = "Completed", Target = updated.Username, Field = "dryRunEnabled",
            Before = new { dryRunEnabled = before.DryRunEnabled, effectiveWriteMode = EffectiveWriteMode(before) },
            After = new { dryRunEnabled = updated.DryRunEnabled, effectiveWriteMode = EffectiveWriteMode(updated) },
            Reason = updated.DryRunEnabled
                ? "Administrator enabled Dry Run for this user profile"
                : "Administrator disabled Dry Run for this user profile",
            CorrelationId = HttpContext.TraceIdentifier,
            Verification = RusRoles.IsAdmin(updated.Role)
                ? "Admin profile invariant enforced: governed live execution"
                : "Per-user Agentic write mode persisted; existing JWT is rejected on the next request",
            Details = new Dictionary<string, object?> { ["targetUserId"] = updated.Id }
        }, cancellationToken);

        var admin = await CurrentUserAsync(cancellationToken);
        if (admin is not null && !string.Equals(admin.Id, updated.Id, StringComparison.OrdinalIgnoreCase))
        {
            await _prompts.CreateAsync(new UserPrompt
            {
                TargetUserId = updated.Id, TargetUsername = updated.Username,
                CreatedByUserId = admin.Id, CreatedByUsername = admin.Username, CreatedByDisplayName = admin.DisplayName,
                Title = "Agentic write mode updated",
                Message = updated.DryRunEnabled
                    ? "Dry Run is enabled for your profile. Agentic updates will validate and audit the change without modifying Rewards DB or CrowdTwist."
                    : "Dry Run is disabled for your profile. Authorized explicit Agentic updates can execute governed live writes to Rewards DB or CrowdTwist.",
                Severity = "info", ActionUrl = "/ai-analysis.html"
            }, cancellationToken);
        }

        return Ok(new { success = true, data = ToAdminResponse(updated), requestId = HttpContext.TraceIdentifier });
    }

    [Authorize]
    [HttpGet("prompts")]
    public async Task<IActionResult> Prompts([FromQuery] bool includeRead = true, CancellationToken cancellationToken = default)
    {
        var user = await CurrentUserAsync(cancellationToken);
        if (user is null) return Unauthorized(Error("USER_NOT_FOUND", "The authenticated user is no longer active."));
        var prompts = await _prompts.ListForUserAsync(user.Id, includeRead, cancellationToken);
        return Ok(new
        {
            success = true,
            data = prompts.Select(ToPromptResponse),
            requestId = HttpContext.TraceIdentifier
        });
    }

    [Authorize]
    [HttpPost("prompts/{promptId}/read")]
    public async Task<IActionResult> MarkPromptRead(string promptId, CancellationToken cancellationToken)
    {
        var user = await CurrentUserAsync(cancellationToken);
        if (user is null) return Unauthorized(Error("USER_NOT_FOUND", "The authenticated user is no longer active."));
        var prompt = await _prompts.MarkReadAsync(promptId, user.Id, cancellationToken);
        if (prompt is null) return NotFound(Error("PROMPT_NOT_FOUND", "The prompt does not exist for this user."));
        await _audit.AppendAsync(new AuditTrailEntry
        {
            Actor = user.Username, ActorDisplayName = user.DisplayName, ActorId = user.Id,
            ActorUsername = user.Username, ActorRole = user.Role, ActorEmail = user.Email,
            Channel = "in-app-prompt", Source = "User Administration", Action = "Prompt acknowledged",
            Status = "Completed", Target = user.Username, Field = "prompt",
            Before = new { prompt.Id, readUtc = (DateTime?)null }, After = new { prompt.Id, prompt.ReadUtc },
            CorrelationId = HttpContext.TraceIdentifier, Verification = "Prompt marked as read"
        }, cancellationToken);
        return Ok(new { success = true, data = ToPromptResponse(prompt), requestId = HttpContext.TraceIdentifier });
    }

    [Authorize(Roles = "Admin")]
    [HttpGet("admin-prompts")]
    public async Task<IActionResult> AdminPrompts(CancellationToken cancellationToken)
    {
        var prompts = await _prompts.ListAllAsync(cancellationToken);
        return Ok(new { success = true, data = prompts.Select(ToPromptResponse), requestId = HttpContext.TraceIdentifier });
    }

    [Authorize(Roles = "Admin")]
    [HttpPost("users")]
    public async Task<IActionResult> CreateUser(
        [FromBody] AdminCreateUserRequest request,
        CancellationToken cancellationToken)
    {
        try
        {
            var user = await _users.CreateAsync(
                request.Username,
                request.DisplayName,
                request.Email,
                request.Role,
                request.Password,
                cancellationToken);
            await AppendAdminAuditAsync("User created", null, user, "Completed", cancellationToken);
            return Created($"/api/auth/users/{user.Id}", new
            {
                success = true,
                data = ToAdminResponse(user),
                requestId = HttpContext.TraceIdentifier
            });
        }
        catch (DuplicateUserException ex)
        {
            return Conflict(Error("USER_ALREADY_EXISTS", ex.Message));
        }
    }

    [Authorize(Roles = "Admin")]
    [HttpPut("users/{id}")]
    public async Task<IActionResult> UpdateUser(
        string id,
        [FromBody] AdminUpdateUserRequest request,
        CancellationToken cancellationToken)
    {
        var before = await _users.FindAnyByIdAsync(id, cancellationToken);
        if (before is null) return NotFound(Error("USER_NOT_FOUND", "The user does not exist."));
        var requestedRole = RusRoles.Normalize(request.Role);
        if (RusRoles.IsAdmin(before.Role) &&
            !RusRoles.IsAdmin(requestedRole) &&
            await IsLastActiveAdminAsync(before.Id, cancellationToken))
        {
            return BadRequest(Error("LAST_ADMIN_REQUIRED", "At least one active administrator must remain."));
        }

        try
        {
            var updated = await _users.UpdateProfileAsync(id, request.DisplayName, request.Email, requestedRole, cancellationToken);
            await AppendAdminAuditAsync("User updated", before, updated, "Completed", cancellationToken);
            return Ok(new { success = true, data = ToAdminResponse(updated), requestId = HttpContext.TraceIdentifier });
        }
        catch (DuplicateUserException ex)
        {
            return Conflict(Error("USER_ALREADY_EXISTS", ex.Message));
        }
    }

    [Authorize(Roles = "Admin")]
    [HttpPost("users/{id}/delegate")]
    public async Task<IActionResult> DelegateUser(
        string id,
        [FromBody] AdminDelegateUserRequest request,
        CancellationToken cancellationToken)
    {
        var before = await _users.FindAnyByIdAsync(id, cancellationToken);
        if (before is null) return NotFound(Error("USER_NOT_FOUND", "The user does not exist."));
        var requestedRole = RusRoles.Normalize(request.Role);
        if (RusRoles.IsAdmin(before.Role) && !RusRoles.IsAdmin(requestedRole) &&
            await IsLastActiveAdminAsync(before.Id, cancellationToken))
        {
            return BadRequest(Error("LAST_ADMIN_REQUIRED", "At least one active administrator must remain."));
        }

        var updated = await _users.UpdateProfileAsync(
            id, before.DisplayName, before.Email, requestedRole, cancellationToken);
        await _audit.AppendAsync(new AuditTrailEntry
        {
            Channel = "admin-ui", Source = "User Administration", Action = "Role delegated",
            Status = "Completed", Target = updated.Username, Field = "role",
            Before = new { role = before.Role }, After = new { role = updated.Role },
            Reason = string.IsNullOrWhiteSpace(request.Reason) ? "Administrator delegated access" : request.Reason.Trim(),
            CorrelationId = HttpContext.TraceIdentifier, Verification = "User role persisted; existing JWT is rejected on next request",
            Details = new Dictionary<string, object?> { ["targetUserId"] = updated.Id }
        }, cancellationToken);

        var admin = await CurrentUserAsync(cancellationToken);
        if (admin is not null)
        {
            await _prompts.CreateAsync(new UserPrompt
            {
                TargetUserId = updated.Id, TargetUsername = updated.Username,
                CreatedByUserId = admin.Id, CreatedByUsername = admin.Username, CreatedByDisplayName = admin.DisplayName,
                Title = "Access profile updated",
                Message = $"Your RUS access profile is now {updated.Role}. Sign in again to load the delegated view.",
                Severity = "info", ActionUrl = "/login.html"
            }, cancellationToken);
        }
        return Ok(new { success = true, data = ToAdminResponse(updated), requestId = HttpContext.TraceIdentifier });
    }

    [Authorize(Roles = "Admin")]
    [HttpPost("users/{id}/prompts")]
    public async Task<IActionResult> PromptUser(
        string id,
        [FromBody] AdminPromptUserRequest request,
        CancellationToken cancellationToken)
    {
        var target = await _users.FindAnyByIdAsync(id, cancellationToken);
        if (target is null) return NotFound(Error("USER_NOT_FOUND", "The user does not exist."));
        if (!target.IsActive) return BadRequest(Error("USER_INACTIVE", "Activate the user before sending a prompt."));
        var admin = await CurrentUserAsync(cancellationToken);
        if (admin is null) return Unauthorized(Error("USER_NOT_FOUND", "The administrator account is unavailable."));

        UserPrompt created;
        try
        {
            created = await _prompts.CreateAsync(new UserPrompt
            {
                TargetUserId = target.Id, TargetUsername = target.Username,
                CreatedByUserId = admin.Id, CreatedByUsername = admin.Username, CreatedByDisplayName = admin.DisplayName,
                Title = request.Title.Trim(), Message = request.Message.Trim(), Severity = request.Severity,
                ActionUrl = request.ActionUrl, ExpiresAtUtc = request.ExpiresAtUtc?.ToUniversalTime()
            }, cancellationToken);
        }
        catch (ArgumentException exception)
        {
            return BadRequest(Error("PROMPT_INVALID", exception.Message));
        }

        await _audit.AppendAsync(new AuditTrailEntry
        {
            Channel = "admin-ui", Source = "User Administration", Action = "User prompted",
            Status = "Completed", Target = target.Username, Field = "in-app prompt",
            Before = null, After = new { created.Id, created.Title, created.Message, created.Severity, created.ActionUrl, created.ExpiresAtUtc },
            CorrelationId = HttpContext.TraceIdentifier, Verification = "Prompt persisted for the target user",
            Details = new Dictionary<string, object?> { ["targetUserId"] = target.Id }
        }, cancellationToken);
        return Created($"/api/auth/prompts/{created.Id}", new
        {
            success = true, data = ToPromptResponse(created), requestId = HttpContext.TraceIdentifier
        });
    }

    [Authorize(Roles = "Admin")]
    [HttpPost("users/{id}/activate")]
    public async Task<IActionResult> ActivateUser(string id, CancellationToken cancellationToken)
    {
        var before = await _users.FindAnyByIdAsync(id, cancellationToken);
        if (before is null) return NotFound(Error("USER_NOT_FOUND", "The user does not exist."));
        var updated = await _users.SetActiveAsync(id, true, cancellationToken);
        await AppendAdminAuditAsync("User activated", before, updated, "Completed", cancellationToken);
        return Ok(new { success = true, data = ToAdminResponse(updated), requestId = HttpContext.TraceIdentifier });
    }

    [Authorize(Roles = "Admin")]
    [HttpDelete("users/{id}")]
    public async Task<IActionResult> RemoveUser(string id, CancellationToken cancellationToken)
    {
        var currentId = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");
        if (string.Equals(currentId, id, StringComparison.OrdinalIgnoreCase))
        {
            return BadRequest(Error("CANNOT_REMOVE_SELF", "You cannot remove your own administrator account."));
        }

        var before = await _users.FindAnyByIdAsync(id, cancellationToken);
        if (before is null) return NotFound(Error("USER_NOT_FOUND", "The user does not exist."));
        if (RusRoles.IsAdmin(before.Role) && await IsLastActiveAdminAsync(id, cancellationToken))
        {
            return BadRequest(Error("LAST_ADMIN_REQUIRED", "At least one active administrator must remain."));
        }

        var updated = await _users.SetActiveAsync(id, false, cancellationToken);
        await AppendAdminAuditAsync("User removed", before, updated, "Completed", cancellationToken);
        return Ok(new { success = true, data = ToAdminResponse(updated), requestId = HttpContext.TraceIdentifier });
    }

    [Authorize(Roles = "Admin")]
    [HttpDelete("users/{id}/purge")]
    public async Task<IActionResult> PurgeUser(string id, CancellationToken cancellationToken)
    {
        var currentId = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");
        if (string.Equals(currentId, id, StringComparison.OrdinalIgnoreCase))
        {
            return BadRequest(Error("CANNOT_REMOVE_SELF", "You cannot permanently delete your own administrator account."));
        }
        var before = await _users.FindAnyByIdAsync(id, cancellationToken);
        if (before is null) return NotFound(Error("USER_NOT_FOUND", "The user does not exist."));
        if (before.IsActive) return BadRequest(Error("DEACTIVATE_FIRST", "Deactivate the account before permanent deletion."));
        if (RusRoles.IsAdmin(before.Role) && await IsLastActiveAdminAsync(id, cancellationToken))
        {
            return BadRequest(Error("LAST_ADMIN_REQUIRED", "At least one active administrator must remain."));
        }

        await _prompts.DeleteForUserAsync(id, cancellationToken);
        var removed = await _users.DeleteAsync(id, cancellationToken);
        if (!removed) return NotFound(Error("USER_NOT_FOUND", "The user no longer exists."));
        await _audit.AppendAsync(new AuditTrailEntry
        {
            Channel = "admin-ui", Source = "User Administration", Action = "User permanently deleted",
            Status = "Completed", Target = before.Username, Before = SafeUser(before), After = null,
            Reason = "Administrator permanently removed the inactive account", CorrelationId = HttpContext.TraceIdentifier,
            Verification = "User and pending prompts removed from the runtime store",
            Details = new Dictionary<string, object?> { ["targetUserId"] = before.Id }
        }, cancellationToken);
        return Ok(new { success = true, data = new { deleted = true, before.Username }, requestId = HttpContext.TraceIdentifier });
    }

    [Authorize(Roles = "Admin")]
    [HttpPost("users/{id}/reset-password")]
    public async Task<IActionResult> ResetPassword(
        string id,
        [FromBody] AdminResetPasswordRequest request,
        CancellationToken cancellationToken)
    {
        var user = await _users.FindAnyByIdAsync(id, cancellationToken);
        if (user is null) return NotFound(Error("USER_NOT_FOUND", "The user does not exist."));
        await _users.UpdatePasswordAsync(id, request.NewPassword, cancellationToken);
        await _audit.AppendAsync(new AuditTrailEntry
        {
            Channel = "admin-ui",
            Source = "User Administration",
            Action = "Password reset",
            Status = "Completed",
            Target = user.Username,
            Before = new { password = "<redacted>" },
            After = new { password = "<redacted>" },
            CorrelationId = HttpContext.TraceIdentifier,
            Verification = "Password hash replaced; existing JWTs are rejected on the next request",
            Details = new Dictionary<string, object?> { ["targetUserId"] = user.Id }
        }, cancellationToken);
        return Ok(new { success = true, data = new { reset = true }, requestId = HttpContext.TraceIdentifier });
    }

    private async Task<IActionResult> CompleteLoginAsync(
        UserAccount user,
        string action,
        CancellationToken cancellationToken,
        bool auditLogin = true)
    {
        var login = _tokens.Issue(user);
        SetAccessCookie(login.AccessToken, login.ExpiresAtUtc);
        if (auditLogin)
        {
            // Authentication must not be blocked by a slow audit file or a browser
            // navigation cancellation. The JWT/cookie is already issued; record the
            // login with a short independent timeout and continue on audit failure.
            try
            {
                using var auditTimeout = new CancellationTokenSource(TimeSpan.FromSeconds(2));
                await _audit.AppendAsync(new AuditTrailEntry
                {
                    Actor = user.Username,
                    ActorDisplayName = user.DisplayName,
                    ActorId = user.Id,
                    ActorUsername = user.Username,
                    ActorRole = user.Role,
                    ActorEmail = user.Email,
                    Channel = "login-ui",
                    Source = "Authentication",
                    Action = action,
                    Status = "Completed",
                    Target = user.Username,
                    After = SafeUser(user),
                    CorrelationId = HttpContext.TraceIdentifier,
                    Verification = "JWT issued",
                    Details = RequestDetails(user)
                }, auditTimeout.Token);
            }
            catch (Exception exception) when (exception is OperationCanceledException or IOException)
            {
                _logger.LogWarning("Login succeeded for {Username}, but the authentication audit entry could not be written immediately.", user.Username);
            }
        }

        Response.Headers.CacheControl = "no-store";
        return Ok(new { success = true, data = login, requestId = HttpContext.TraceIdentifier });
    }

    private async Task<bool> IsLastActiveAdminAsync(string targetId, CancellationToken cancellationToken)
    {
        var users = await _users.ListAsync(includeInactive: false, cancellationToken: cancellationToken);
        return users.Count(item => RusRoles.IsAdmin(item.Role)) <= 1 &&
               users.Any(item => item.Id.Equals(targetId, StringComparison.OrdinalIgnoreCase));
    }

    private async Task<UserAccount?> CurrentUserAsync(CancellationToken cancellationToken)
    {
        var id = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");
        return string.IsNullOrWhiteSpace(id) ? null : await _users.FindByIdAsync(id, cancellationToken);
    }

    private async Task AppendAdminAuditAsync(
        string action,
        UserAccount? before,
        UserAccount after,
        string status,
        CancellationToken cancellationToken)
    {
        await _audit.AppendAsync(new AuditTrailEntry
        {
            Channel = "admin-ui",
            Source = "User Administration",
            Action = action,
            Status = status,
            Target = after.Username,
            Before = before is null ? null : SafeUser(before),
            After = SafeUser(after),
            CorrelationId = HttpContext.TraceIdentifier,
            Verification = "User store persisted",
            Details = new Dictionary<string, object?> { ["targetUserId"] = after.Id }
        }, cancellationToken);
    }

    private async Task AppendAuthAuditAsync(
        string actor,
        UserAccount? user,
        string action,
        string status,
        string target,
        string reason,
        string verification,
        CancellationToken cancellationToken)
    {
        await _audit.AppendAsync(new AuditTrailEntry
        {
            Actor = actor,
            ActorDisplayName = user?.DisplayName,
            ActorId = user?.Id,
            ActorUsername = user?.Username,
            ActorRole = user?.Role,
            ActorEmail = user?.Email,
            Channel = "login-ui",
            Source = "Authentication",
            Action = action,
            Status = status,
            Target = target,
            Reason = reason,
            CorrelationId = HttpContext.TraceIdentifier,
            Verification = verification,
            Details = RequestDetails(user)
        }, cancellationToken);
    }

    private object Error(string code, string message) => new
    {
        success = false,
        error = new { code, message },
        requestId = HttpContext.TraceIdentifier
    };

    private static object SafeUser(UserAccount user) => new
    {
        user.Id,
        user.Username,
        user.DisplayName,
        user.Email,
        user.Role,
        user.IsActive,
        DryRunEnabled = !RusRoles.IsAdmin(user.Role) && user.DryRunEnabled,
        EffectiveWriteMode = EffectiveWriteMode(user),
        user.CreatedUtc,
        user.PasswordChangedUtc
    };

    private static UserAdministrationResponse ToAdminResponse(UserAccount user) => new(
        user.Id,
        user.Username,
        user.DisplayName,
        RusRoles.Normalize(user.Role),
        user.Email,
        user.IsActive,
        !RusRoles.IsAdmin(user.Role) && user.DryRunEnabled,
        EffectiveWriteMode(user),
        user.CreatedUtc,
        user.PasswordChangedUtc,
        RusRoles.Profile(user.Role));

    private static string EffectiveWriteMode(UserAccount user) =>
        RusRoles.IsAdmin(user.Role) ? "live" : user.DryRunEnabled ? "dry_run" : "live";

    private static UserPromptResponse ToPromptResponse(UserPrompt prompt) => new(
        prompt.Id, prompt.TargetUserId, prompt.TargetUsername, prompt.CreatedByUsername,
        prompt.CreatedByDisplayName, prompt.Title, prompt.Message, prompt.Severity,
        prompt.ActionUrl, prompt.CreatedUtc, prompt.ExpiresAtUtc, prompt.ReadUtc);

    private void SetAccessCookie(string token, DateTime expiresAtUtc)
    {
        Response.Cookies.Append(_options.AccessCookieName, token, new CookieOptions
        {
            HttpOnly = true,
            Secure = Request.IsHttps,
            SameSite = SameSiteMode.Lax,
            IsEssential = true,
            Path = "/",
            Expires = new DateTimeOffset(expiresAtUtc),
            MaxAge = expiresAtUtc - DateTime.UtcNow
        });
    }

    private void DeleteAccessCookie() => Response.Cookies.Delete(_options.AccessCookieName, new CookieOptions
    {
        HttpOnly = true,
        Secure = Request.IsHttps,
        SameSite = SameSiteMode.Lax,
        IsEssential = true,
        Path = "/"
    });

    private Dictionary<string, object?> RequestDetails(UserAccount? user = null) => new()
    {
        ["userId"] = user?.Id,
        ["username"] = user?.Username,
        ["role"] = user?.Role,
        ["remoteIp"] = HttpContext.Connection.RemoteIpAddress?.ToString(),
        ["userAgent"] = Request.Headers["User-Agent"].ToString()
    };
}

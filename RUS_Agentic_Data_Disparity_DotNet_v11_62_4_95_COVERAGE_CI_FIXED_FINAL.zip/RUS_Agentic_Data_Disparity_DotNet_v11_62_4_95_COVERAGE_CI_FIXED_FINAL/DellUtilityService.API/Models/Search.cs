namespace DellUtilityService.API.Models;

public static class Search
{
    public enum SearchType
    {
        Id = 1,
        Email = 2,
        ProfileId = 3,
        StoreId = 4,
        ThirdPartyId = 5
    }

    public const string Id = "id";
    public const string Email = "email";
    public const string ThirdPartyId = "third_party_id";
}

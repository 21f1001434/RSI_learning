using System.Text.Json;
using System.Text.Json.Serialization;

namespace DellUtilityService.API.Models.Agentic;

public sealed class SessionCreateProxyRequest
{
    [JsonPropertyName("metadata")]
    public Dictionary<string, object?> Metadata { get; set; } = new()
    {
        ["channel"] = "dotnet-rus-ui"
    };
}

public sealed class ChatProxyRequest
{
    [JsonPropertyName("session_id")]
    public string SessionId { get; set; } = string.Empty;

    [JsonPropertyName("message")]
    public string Message { get; set; } = string.Empty;

    [JsonPropertyName("action")]
    public string Action { get; set; } = "auto";

    [JsonPropertyName("context")]
    public string Context { get; set; } = "auto";

    [JsonPropertyName("search_type")]
    public string? SearchType { get; set; }

    [JsonPropertyName("search_value")]
    public string? SearchValue { get; set; }

    [JsonPropertyName("judge_response")]
    public bool? JudgeResponse { get; set; } = true;

    [JsonPropertyName("actor")]
    public string? Actor { get; set; }

    [JsonPropertyName("actor_email")]
    public string? ActorEmail { get; set; }

    [JsonPropertyName("actor_role")]
    public string? ActorRole { get; set; }

    [JsonPropertyName("actor_dry_run_enabled")]
    public bool? ActorDryRunEnabled { get; set; }
}

public sealed class IndividualAnalysisProxyRequest
{
    [JsonPropertyName("search_type")]
    public string SearchType { get; set; } = "email";

    [JsonPropertyName("search_value")]
    public string SearchValue { get; set; } = string.Empty;

    [JsonPropertyName("session_id")]
    public string? SessionId { get; set; }

    [JsonPropertyName("include_raw_source_data")]
    public bool IncludeRawSourceData { get; set; } = true;

    [JsonPropertyName("include_html")]
    public bool IncludeHtml { get; set; }

    [JsonPropertyName("mask_report_values")]
    public bool MaskReportValues { get; set; } = false;

    [JsonPropertyName("actor")]
    public string? Actor { get; set; }

    [JsonPropertyName("actor_email")]
    public string? ActorEmail { get; set; }

    [JsonPropertyName("actor_role")]
    public string? ActorRole { get; set; }

    [JsonPropertyName("actor_dry_run_enabled")]
    public bool? ActorDryRunEnabled { get; set; }

    [JsonPropertyName("actor_id")]
    public string? ActorId { get; set; }
}

public sealed class BatchEmailsProxyRequest
{
    [JsonPropertyName("emails")]
    public List<string> Emails { get; set; } = new();

    [JsonPropertyName("session_id")]
    public string? SessionId { get; set; }

    [JsonPropertyName("max_parallel")]
    public int? MaxParallel { get; set; } = 8;

    [JsonPropertyName("max_parallel_ai")]
    public int? MaxParallelAi { get; set; } = 2;

    [JsonPropertyName("include_group_ai")]
    public bool IncludeGroupAi { get; set; } = true;
}

public sealed class PayloadValidationProxyRequest
{
    [JsonPropertyName("operation_id")]
    public string OperationId { get; set; } = string.Empty;

    [JsonPropertyName("payload")]
    public Dictionary<string, JsonElement> Payload { get; set; } = new();
}

public sealed class UseCasePlanProxyRequest
{
    [JsonPropertyName("run_id")]
    public string RunId { get; set; } = string.Empty;

    [JsonPropertyName("use_case_id")]
    public string UseCaseId { get; set; } = string.Empty;

    [JsonPropertyName("include_dell_aia_review")]
    public bool IncludeDellAiaReview { get; set; } = true;
}


public sealed class CpsSourceQueryProxyRequest
{
    [JsonPropertyName("emails")]
    public List<string> Emails { get; set; } = new();

    [JsonPropertyName("query")]
    public string? Query { get; set; }

    [JsonPropertyName("session_id")]
    public string? SessionId { get; set; }

    [JsonPropertyName("max_parallel")]
    public int MaxParallel { get => 8; set { } }
}

public sealed class SourceQueryProxyRequest
{
    // Backward-compatible single-source field. New UI requests populate Sources.
    [JsonPropertyName("source")]
    public string? Source { get; set; }

    [JsonPropertyName("sources")]
    public List<string> Sources { get; set; } = new();

    [JsonPropertyName("emails")]
    public List<string> Emails { get; set; } = new();

    [JsonPropertyName("search_type")]
    public string? SearchType { get; set; }

    [JsonPropertyName("search_value")]
    public string? SearchValue { get; set; }

    [JsonPropertyName("query")]
    public string? Query { get; set; }

    [JsonPropertyName("session_id")]
    public string? SessionId { get; set; }

    [JsonPropertyName("max_parallel")]
    public int MaxParallel { get => 8; set { } }

    [JsonPropertyName("actor")]
    public string? Actor { get; set; }

    [JsonPropertyName("actor_email")]
    public string? ActorEmail { get; set; }

    [JsonPropertyName("actor_role")]
    public string? ActorRole { get; set; }

    [JsonPropertyName("actor_dry_run_enabled")]
    public bool? ActorDryRunEnabled { get; set; }
}

public sealed class SourceChangePlanProxyRequest
{
    [JsonPropertyName("session_id")]
    public string SessionId { get; set; } = string.Empty;

    [JsonPropertyName("source")]
    public string Source { get; set; } = string.Empty;

    [JsonPropertyName("operation")]
    public string Operation { get; set; } = "update";

    [JsonPropertyName("emails")]
    public List<string> Emails { get; set; } = new();

    [JsonPropertyName("field")]
    public string Field { get; set; } = string.Empty;

    [JsonPropertyName("new_value")]
    public JsonElement NewValue { get; set; }

    [JsonPropertyName("reason")]
    public string? Reason { get; set; }

    [JsonPropertyName("actor")]
    public string? Actor { get; set; }

    [JsonPropertyName("actor_email")]
    public string? ActorEmail { get; set; }

    [JsonPropertyName("actor_role")]
    public string? ActorRole { get; set; }

    [JsonPropertyName("actor_dry_run_enabled")]
    public bool? ActorDryRunEnabled { get; set; }
}

public sealed class SourceChangeConfirmationProxyRequest
{
    [JsonPropertyName("session_id")]
    public string SessionId { get; set; } = string.Empty;

    [JsonPropertyName("confirmation_text")]
    public string ConfirmationText { get; set; } = string.Empty;

    [JsonPropertyName("approval_channel")]
    public string ApprovalChannel { get; set; } = "api";

    [JsonPropertyName("popup_acknowledged")]
    public bool PopupAcknowledged { get; set; }

    [JsonPropertyName("audit_acknowledged")]
    public bool AuditAcknowledged { get; set; }

    [JsonPropertyName("plan_digest")]
    public string? PlanDigest { get; set; }

    [JsonPropertyName("popup_token")]
    public string? PopupToken { get; set; }

    [JsonPropertyName("actor")]
    public string? Actor { get; set; }

    [JsonPropertyName("actor_email")]
    public string? ActorEmail { get; set; }

    [JsonPropertyName("actor_role")]
    public string? ActorRole { get; set; }

    [JsonPropertyName("actor_dry_run_enabled")]
    public bool? ActorDryRunEnabled { get; set; }
}

public sealed class SourceChangePopupOpenedProxyRequest
{
    [JsonPropertyName("session_id")]
    public string SessionId { get; set; } = string.Empty;

    [JsonPropertyName("actor")]
    public string? Actor { get; set; }

    [JsonPropertyName("actor_email")]
    public string? ActorEmail { get; set; }

    [JsonPropertyName("actor_role")]
    public string? ActorRole { get; set; }

    [JsonPropertyName("actor_dry_run_enabled")]
    public bool? ActorDryRunEnabled { get; set; }
}

public sealed class SourceChangeCancelProxyRequest
{
    [JsonPropertyName("session_id")]
    public string SessionId { get; set; } = string.Empty;

    [JsonPropertyName("reason")]
    public string? Reason { get; set; }

    [JsonPropertyName("actor")]
    public string? Actor { get; set; }

    [JsonPropertyName("actor_email")]
    public string? ActorEmail { get; set; }

    [JsonPropertyName("actor_role")]
    public string? ActorRole { get; set; }

    [JsonPropertyName("actor_dry_run_enabled")]
    public bool? ActorDryRunEnabled { get; set; }
}

public sealed class SpreadsheetSourceChangeRowProxyRequest
{
    [JsonPropertyName("row_number")]
    public int RowNumber { get; set; }

    [JsonPropertyName("source")]
    public string Source { get; set; } = "crowd_twist";

    [JsonPropertyName("identifier_type")]
    public string IdentifierType { get; set; } = "crowdtwistid";

    [JsonPropertyName("identifier_value")]
    public string IdentifierValue { get; set; } = string.Empty;

    [JsonPropertyName("field")]
    public string Field { get; set; } = string.Empty;

    [JsonPropertyName("new_value")]
    public object? NewValue { get; set; }

    [JsonPropertyName("original_property_name")]
    public string? OriginalPropertyName { get; set; }
}

public sealed class SpreadsheetSourceChangeImportProxyRequest
{
    [JsonPropertyName("session_id")]
    public string SessionId { get; set; } = string.Empty;

    [JsonPropertyName("file_name")]
    public string FileName { get; set; } = string.Empty;

    [JsonPropertyName("instruction")]
    public string Instruction { get; set; } = string.Empty;

    [JsonPropertyName("rows")]
    public List<SpreadsheetSourceChangeRowProxyRequest> Rows { get; set; } = new();

    [JsonPropertyName("actor")]
    public string? Actor { get; set; }

    [JsonPropertyName("actor_email")]
    public string? ActorEmail { get; set; }

    [JsonPropertyName("actor_role")]
    public string? ActorRole { get; set; }

    [JsonPropertyName("actor_dry_run_enabled")]
    public bool? ActorDryRunEnabled { get; set; }
}


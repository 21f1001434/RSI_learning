using System.Text.Json.Serialization;

namespace DellUtilityService.API.Models.Agentic;

public sealed class AgenticBootstrapRequest
{
    [JsonPropertyName("session_id")]
    public string? SessionId { get; set; }

    [JsonPropertyName("deep_health")]
    public bool DeepHealth { get; set; }
}

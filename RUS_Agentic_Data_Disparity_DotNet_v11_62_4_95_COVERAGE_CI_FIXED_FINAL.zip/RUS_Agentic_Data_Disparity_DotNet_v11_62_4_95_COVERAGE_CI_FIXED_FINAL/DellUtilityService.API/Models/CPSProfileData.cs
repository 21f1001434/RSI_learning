﻿using System.Text.Json.Serialization;

namespace DellUtilityService.API.Models
{
    public class CPSProfileData
    {
        [JsonPropertyName("accountId")]
        public string AccountId { get; set; }

        [JsonPropertyName("created")]
        public string Created { get; set; }

        [JsonPropertyName("updated")]
        public string Updated { get; set; }

        [JsonPropertyName("accountState")]
        public string AccountState { get; set; }

        [JsonPropertyName("lastLogon")]
        public DateTime? LastLogon { get; set; }

        [JsonPropertyName("lockedDate")]
        public DateTime? LockedDate { get; set; }

        [JsonPropertyName("aliases")]
        public List<Alias> Aliases { get; set; } = new();

        [JsonPropertyName("profiles")]
        public List<ProfileDetails> Profiles { get; set; } = new();

        [JsonPropertyName("emailVerified")]
        public bool EmailVerified { get; set; }

        [JsonPropertyName("credentialsRequired")]
        public bool CredentialsRequired { get; set; }

        [JsonPropertyName("emailLastVerifyDate")]
        public DateTime? EmailLastVerifyDate { get; set; }

        [JsonPropertyName("phoneVerified")]
        public bool PhoneVerified { get; set; }

        [JsonPropertyName("phoneLastVerifyDate")]
        public DateTime? PhoneLastVerifyDate { get; set; }

        [JsonPropertyName("profileId")]
        public Guid ProfileId { get; set; }

        [JsonPropertyName("errorCode")]
        public string ErrorCode { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }

        [JsonPropertyName("message")]
        public string Message { get; set; }
    }

    public class Alias
    {
        [JsonPropertyName("aliasId")]
        public string AliasId { get; set; }

        [JsonPropertyName("type")]
        public string Type { get; set; }

        [JsonPropertyName("state")]
        public string State { get; set; }

        [JsonPropertyName("value")]
        public string Value { get; set; }

        [JsonPropertyName("created")]
        public string Created { get; set; }

        [JsonPropertyName("updated")]
        public string Updated { get; set; }

        [JsonPropertyName("accountId")]
        public string AccountId { get; set; }

        [JsonPropertyName("lastPasswordUpdated")]
        public string LastPasswordUpdated { get; set; }
    }

    public class ProfileDetails
    {
        [JsonPropertyName("region")]
        public string Region { get; set; }

        [JsonPropertyName("contact")]
        public ContactDetails Contact { get; set; }

        [JsonPropertyName("accountId")]
        public string AccountId { get; set; }

        [JsonPropertyName("personPartyId")]
        public string PersonPartyId { get; set; }
    }

    public class ContactDetails
    {
        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("emailId")]
        public string EmailId { get; set; }
    }
}

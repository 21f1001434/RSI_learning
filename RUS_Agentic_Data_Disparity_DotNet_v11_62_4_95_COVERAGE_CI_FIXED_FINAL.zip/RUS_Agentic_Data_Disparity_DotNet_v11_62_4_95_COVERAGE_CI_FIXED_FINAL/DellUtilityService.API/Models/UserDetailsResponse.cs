using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace DellUtilityService.API.Models
{
    [ExcludeFromCodeCoverage]
    public class UserDetailsResponse
    {
        [JsonPropertyName("id")]
        public int CrowdTwistId { get; set; }
        [JsonPropertyName("third_party_id")]
        public string ThirdPartyId { get; set; } = string.Empty;
        [JsonPropertyName("first_name")]
        public string FirstName { get; set; } = string.Empty;

        [JsonPropertyName("middle_name")]
        public string MiddleName { get; set; } = string.Empty;

        [JsonPropertyName("last_name")]
        public string LastName { get; set; } = string.Empty;

        [JsonPropertyName("date_of_birth")]
        public long? DateOfBirth { get; set; }

        [JsonPropertyName("email_address")]
        public string EmailAddress { get; set; } = string.Empty;

        [JsonPropertyName("email_is_verified")]
        public bool EmailIsVerified { get; set; }

        [JsonPropertyName("username")]
        public string Username { get; set; } = string.Empty;

        [JsonPropertyName("mobile_phone_number")]
        public string MobilePhoneNumber { get; set; } = string.Empty;

        [JsonPropertyName("is_active")]
        public bool Status { get; set; }

        [JsonPropertyName("continent")]
        public string Continent { get; set; } = string.Empty;

        [JsonPropertyName("country")]
        public string Country { get; set; } = string.Empty;

        // Some CrowdTwist read environments expose both the display country
        // (for example "United States") and the persisted ISO field.  Capture
        // country_code when present so manual and Agentic read-after-write
        // verification can use the exact wire value instead of the display name.
        [JsonPropertyName("country_code")]
        public string CountryCode { get; set; } = string.Empty;

        [JsonPropertyName("state")]
        public string State { get; set; } = string.Empty;

        [JsonPropertyName("city")]
        public string City { get; set; } = string.Empty;

        [JsonPropertyName("postal_code")]
        public string PostalCode { get; set; } = string.Empty;

        [JsonPropertyName("receive_email_updates")]
        public bool ReceiveEmailUpdates { get; set; }

        [JsonPropertyName("total_points")]
        public int TotalPoints { get; set; }

        [JsonPropertyName("redeemable_points")]
        public int RedeemablePoints { get; set; }

        [JsonPropertyName("fan_level")]
        public string FanLevel { get; set; } = string.Empty;

        [JsonPropertyName("tier_info")]
        public TierInfo? TierInfo { get; set; }

        [JsonPropertyName("expiration_date")]
        public string ExpirationDate { get; set; } = string.Empty;
        [JsonPropertyName("segments")]
        public List<Segment> Segments { get; set; } = new();
    }
    [ExcludeFromCodeCoverage]
    public class Segment
    {
        [JsonPropertyName("subscription_id")]
        public int SegmentSubscriptionId { get; set; }

        [JsonPropertyName("name")]
        public string SegmentName { get; set; } = string.Empty;

        [JsonPropertyName("date_entered")]
        public DateTime? SegmentDateEntered { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class TierInfo
    {
        [JsonPropertyName("current_level")]
        public CurrentLevel? CurrentLevel { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class CurrentLevel
    {
        [JsonPropertyName("title")]
        public string Title { get; set; } = string.Empty;

        [JsonPropertyName("min_value")]
        public int MinValue { get; set; }

        [JsonPropertyName("max_value")]
        public int MaxValue { get; set; }

        [JsonPropertyName("image_url")]
        public string ImageUrl { get; set; } = string.Empty;
    }
}

namespace DellUtilityService.API.Models
{
    public class BulkUpdateRequest
    {
        public IFormFile File { get; set; } = null!;
        public string UpdateType { get; set; } = string.Empty; // "CrowdTwist" or "MemberDB"
    }

    public class BulkUpdateItem
    {
        public int? CrowdTwistId { get; set; }
        public Guid? MemberId { get; set; }
        public string PropertyName { get; set; } = string.Empty;
        public string PropertyValue { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty; // "Success" or "Failed"
        public string Comments { get; set; } = string.Empty;
    }

    public class BulkUpdateResponse
    {
        public int TotalProcessed { get; set; }
        public int SuccessCount { get; set; }
        public int FailedCount { get; set; }
        public byte[] ResultExcelFile { get; set; } = Array.Empty<byte>();
        public string FileName { get; set; } = string.Empty;
    }
}

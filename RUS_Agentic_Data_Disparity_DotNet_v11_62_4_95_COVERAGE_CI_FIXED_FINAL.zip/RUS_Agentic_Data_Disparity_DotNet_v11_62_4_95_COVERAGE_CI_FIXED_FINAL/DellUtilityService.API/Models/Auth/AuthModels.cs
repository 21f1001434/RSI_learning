using System.ComponentModel.DataAnnotations;

namespace DellUtilityService.API.Models.Auth;

public sealed class LoginRequest
{
    [Required, StringLength(100, MinimumLength = 1)]
    public string Username { get; set; } = string.Empty;

    [Required, StringLength(256, MinimumLength = 1)]
    public string Password { get; set; } = string.Empty;
}

public sealed class RegisterRequest
{
    [Required, StringLength(100, MinimumLength = 3)]
    [RegularExpression("^[A-Za-z0-9._-]+$", ErrorMessage = "Username can contain letters, numbers, dot, underscore and hyphen only.")]
    public string Username { get; set; } = string.Empty;

    [Required, StringLength(160, MinimumLength = 2)]
    public string DisplayName { get; set; } = string.Empty;

    [EmailAddress, StringLength(254)]
    public string? Email { get; set; }

    [Required, StringLength(256, MinimumLength = 10)]
    public string Password { get; set; } = string.Empty;
}

public sealed class ChangePasswordRequest
{
    [Required, StringLength(256, MinimumLength = 1)]
    public string CurrentPassword { get; set; } = string.Empty;

    [Required, StringLength(256, MinimumLength = 10)]
    public string NewPassword { get; set; } = string.Empty;
}

public sealed class AdminCreateUserRequest
{
    [Required, StringLength(100, MinimumLength = 3)]
    [RegularExpression("^[A-Za-z0-9._-]+$", ErrorMessage = "Username can contain letters, numbers, dot, underscore and hyphen only.")]
    public string Username { get; set; } = string.Empty;

    [Required, StringLength(160, MinimumLength = 2)]
    public string DisplayName { get; set; } = string.Empty;

    [EmailAddress, StringLength(254)]
    public string? Email { get; set; }

    [Required, StringLength(32)]
    public string Role { get; set; } = "Customer";

    [Required, StringLength(256, MinimumLength = 10)]
    public string Password { get; set; } = string.Empty;
}

public sealed class AdminUpdateUserRequest
{
    [Required, StringLength(160, MinimumLength = 2)]
    public string DisplayName { get; set; } = string.Empty;

    [EmailAddress, StringLength(254)]
    public string? Email { get; set; }

    [Required, StringLength(32)]
    public string Role { get; set; } = "Customer";
}


public sealed class AdminDelegateUserRequest
{
    [Required, StringLength(32)]
    public string Role { get; set; } = "Customer";

    [StringLength(500)]
    public string? Reason { get; set; }
}

public sealed class AdminPromptUserRequest
{
    [Required, StringLength(120, MinimumLength = 2)]
    public string Title { get; set; } = string.Empty;

    [Required, StringLength(2000, MinimumLength = 2)]
    public string Message { get; set; } = string.Empty;

    [StringLength(20)]
    public string Severity { get; set; } = "info";

    [StringLength(500)]
    public string? ActionUrl { get; set; }

    public DateTime? ExpiresAtUtc { get; set; }
}

public sealed record UserPromptResponse(
    string Id,
    string TargetUserId,
    string TargetUsername,
    string CreatedByUsername,
    string CreatedByDisplayName,
    string Title,
    string Message,
    string Severity,
    string? ActionUrl,
    DateTime CreatedUtc,
    DateTime? ExpiresAtUtc,
    DateTime? ReadUtc);


public sealed class AdminDryRunRequest
{
    public bool Enabled { get; set; }
}

public sealed class AdminResetPasswordRequest
{
    [Required, StringLength(256, MinimumLength = 10)]
    public string NewPassword { get; set; } = string.Empty;
}

public sealed record AuthenticatedUserResponse(
    string Id,
    string Username,
    string DisplayName,
    string Role,
    string? Email,
    bool DryRunEnabled,
    string EffectiveWriteMode,
    DellUtilityService.API.Services.Authentication.RoleViewProfile ViewProfile);

public sealed record UserAdministrationResponse(
    string Id,
    string Username,
    string DisplayName,
    string Role,
    string? Email,
    bool IsActive,
    bool DryRunEnabled,
    string EffectiveWriteMode,
    DateTime CreatedUtc,
    DateTime? PasswordChangedUtc,
    DellUtilityService.API.Services.Authentication.RoleViewProfile ViewProfile);

public sealed record LoginResponse(
    string AccessToken,
    string TokenType,
    DateTime ExpiresAtUtc,
    AuthenticatedUserResponse User);

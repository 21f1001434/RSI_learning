"""Developer convenience: `python -m src` starts the API."""
import os

import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "src.main:app",
        host=os.getenv("API_HOST", "127.0.0.1"),
        port=int(os.getenv("API_PORT", "8088")),
        reload=False,
    )

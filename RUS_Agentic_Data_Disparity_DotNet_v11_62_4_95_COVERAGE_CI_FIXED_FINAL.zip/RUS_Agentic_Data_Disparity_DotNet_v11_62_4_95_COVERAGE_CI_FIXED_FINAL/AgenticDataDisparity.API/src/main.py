from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager, suppress

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from src.app_settings import APP_NAME, APP_VERSION, RUNS_DIR
from src.health.routes import router as health_router
from src.routes import api_router, legacy_analyze
from src.services.disparity_agent.api.batch_jobs import BatchJobManager
from src.services.disparity_agent.api.chat_service import ChatService
from src.services.disparity_agent.api.config import load_api_settings
from src.services.disparity_agent.api.dependencies import verify_internal_key
from src.services.disparity_agent.api.run_store import RunStore
from src.services.disparity_agent.api.session_store import InMemorySessionStore
from src.services.disparity_agent.api.source_operations import SourceOperationService
from src.services.disparity_agent.concurrency_policy import DELL_AIA_PARALLEL_WORKERS
from src.services.disparity_agent.settings import load_settings
from src.services.disparity_agent.memory import get_adaptive_memory
from src.shared.logging import configure_logging
from src.shared.logging_middleware import RequestLoggingMiddleware
from src.shared.middleware import RequestContextMiddleware
from src.shared.utils import ensure_directory


@asynccontextmanager
async def lifespan(app: FastAPI):
    api_settings = app.state.api_settings
    await app.state.adaptive_memory.initialize()
    ensure_directory(RUNS_DIR)
    ensure_directory(api_settings.batch_output_dir)

    async def cleanup_loop() -> None:
        while True:
            await asyncio.sleep(max(10, api_settings.session_cleanup_interval_seconds))
            await app.state.sessions.cleanup()

    task = asyncio.create_task(cleanup_loop())
    app.state.cleanup_task = task
    yield
    task.cancel()
    with suppress(asyncio.CancelledError):
        await task


def create_app() -> FastAPI:
    engine_settings = load_settings()
    api_settings = load_api_settings()
    configure_logging(engine_settings.log_level)

    app = FastAPI(
        title=APP_NAME,
        version=APP_VERSION,
        description=(
            "Production API for Dell Rewards data-disparity analysis, Dell AIA grounded chat, "
            "session memory, reports, batch jobs, multi-source reads, and governed verified "
            "Rewards DB/CrowdTwist updates. CPS remains read-only for Agentic writes."
        ),
        docs_url="/docs" if api_settings.api_docs_enabled else None,
        redoc_url="/redoc" if api_settings.api_docs_enabled else None,
        openapi_url="/openapi.json" if api_settings.api_docs_enabled else None,
        root_path=api_settings.api_root_path,
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=api_settings.cors_origin_list,
        allow_credentials=False,
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-Internal-API-Key", "X-Request-ID"],
    )
    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(RequestContextMiddleware)

    app.state.engine_settings = engine_settings
    app.state.api_settings = api_settings
    app.state.ai_semaphore = asyncio.Semaphore(DELL_AIA_PARALLEL_WORKERS)
    app.state.adaptive_memory = get_adaptive_memory(engine_settings)
    app.state.sessions = InMemorySessionStore(
        ttl_minutes=api_settings.session_ttl_minutes,
        max_messages=api_settings.session_max_messages,
        max_sessions=api_settings.session_max_count,
    )
    app.state.runs = RunStore(engine_settings)
    app.state.source_operations = SourceOperationService(engine_settings, app.state.sessions)
    app.state.batch_jobs = BatchJobManager(
        engine_settings,
        api_settings,
        app.state.sessions,
        audit_service=app.state.source_operations,
    )
    app.state.chat_service = ChatService(
        settings=engine_settings,
        api_settings=api_settings,
        sessions=app.state.sessions,
        runs=app.state.runs,
        ai_semaphore=app.state.ai_semaphore,
        batch_jobs=app.state.batch_jobs,
        source_operations=app.state.source_operations,
    )

    app.include_router(health_router, prefix="/api/v1")
    app.include_router(api_router, prefix="/api/v1")

    # Compatibility alias used by the existing .NET static UI. New code should
    # use /api/v1/analysis/individual.
    app.add_api_route(
        "/api/AIAnalysis/analyze",
        legacy_analyze,
        methods=["GET"],
        include_in_schema=False,
        dependencies=[Depends(verify_internal_key)],
    )

    @app.get("/", include_in_schema=False)
    async def root():
        return {
            "service": APP_NAME,
            "version": APP_VERSION,
            "layout": "src-template",
            "docs": "/docs" if api_settings.api_docs_enabled else None,
            "health": "/api/v1/health/live",
        }

    return app


app = create_app()

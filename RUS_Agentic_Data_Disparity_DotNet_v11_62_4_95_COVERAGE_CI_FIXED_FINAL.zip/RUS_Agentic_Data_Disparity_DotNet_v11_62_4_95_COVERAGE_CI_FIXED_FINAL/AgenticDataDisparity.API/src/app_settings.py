"""Application-wide non-secret defaults for the Agentic Data Disparity API.

Production credentials are intentionally NOT stored in source control. Provide
Dell AIA and Spring Config credentials through environment variables, Vault, or
an injected `.env` file on the developer workstation.
"""
from __future__ import annotations

from pathlib import Path

APP_VERSION = "11.62.4"
APP_NAME = "Dell Rewards Agentic Data Disparity API"
PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESOURCES_DIR = PROJECT_ROOT / "src" / "resources"
RUNTIME_DIR = PROJECT_ROOT / "runtime"
RUNS_DIR = RUNTIME_DIR / "runs"
MEMORY_DIR = RUNTIME_DIR / "memory"
ADAPTIVE_MEMORY_DB = MEMORY_DIR / "adaptive_memory.sqlite3"

# Dell AIA endpoint defaults. Credentials are environment-only.
DELL_AIA_DEFAULT_BASE_URL = "https://aia.gateway.dell.com/genai/dev/v1"
DELL_AIA_ALLOWED_HOST = "aia.gateway.dell.com"
DELL_AIA_PROVIDER = "Dell AIA"
DELL_AIA_AUTH_MODE = "client_credentials"
DELL_AIA_DEFAULT_MODEL = "gpt-oss-120b"
DELL_AIA_DEFAULT_TEMPERATURE = 0.2

DEFAULT_REWARDS_ENVIRONMENT = "g4"
SPRING_CONFIG_ENVIRONMENTS = {
    "g1": {
        "base_url": "https://config-server.dellrewardsg1-r2-np.kob.dell.com/",
        "application": "dell-rewards-g1-kob",
        "profiles": ["default", "g1"],
    },
    "g2": {
        "base_url": "https://config-server.dellrewards-r1.kob.dell.com/",
        "application": "dell-rewards-g2-kob",
        "profiles": ["default", "g2"],
    },
    "g4": {
        "base_url": "https://config-server.dellrewardsg4-r2-np.kob.dell.com/",
        "application": "dell-rewards-g4-kob",
        "profiles": ["default", "g4"],
    },
}

CPS_BASE_URL_FALLBACK = "https://www-sit-g4.dell.com/di/api/account"
CPS_ACCOUNT_PATH = "v2/Accounts/{value}"
TCPS_SEARCH_URL = "https://dellidentity-corp.dell.com/userprovisioning/v1/Users/.search"
TCPS_REQUEST_SCHEMA = "urn:ietf:params:scim:schemas:core:2.0:User"
TCPS_DEFAULT_COUNTRY_ATTRIBUTE = (
    "urn:ietf:params:scim:schemas:extension:ExtendedCore:2.0:User:defaultCountry"
)
LOCAL_DB_CONNECTION_FALLBACK = (
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost;DATABASE=DellUtilityServiceDB;"
    "Trusted_Connection=yes;TrustServerCertificate=yes;"
)

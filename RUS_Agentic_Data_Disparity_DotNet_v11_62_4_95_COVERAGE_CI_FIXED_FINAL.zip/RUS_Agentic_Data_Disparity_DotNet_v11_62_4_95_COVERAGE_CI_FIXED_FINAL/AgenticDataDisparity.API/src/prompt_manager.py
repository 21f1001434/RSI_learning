"""Small prompt composition helper for developers who are new to Python."""
from __future__ import annotations

from dataclasses import dataclass

from .prompts import BUSINESS_TRUTH_PROMPT, GOVERNANCE_SYSTEM_PROMPT


@dataclass(frozen=True)
class PromptManager:
    """Build common system prompts without duplicating governance language."""

    def system_prompt(self, task: str = "") -> str:
        parts = [GOVERNANCE_SYSTEM_PROMPT, BUSINESS_TRUTH_PROMPT]
        if task.strip():
            parts.append(task.strip())
        return "\n\n".join(parts)

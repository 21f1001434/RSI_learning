from __future__ import annotations

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse

from src.services.disparity_agent.api.dependencies import verify_internal_key
from src.services.disparity_agent.api.routes import live as _live, ready as _ready

router = APIRouter(dependencies=[Depends(verify_internal_key)])


@router.get("/health/live", tags=["Health"])
async def live(request: Request) -> JSONResponse:
    return await _live(request)


@router.get("/health/ready", tags=["Health"])
async def ready(request: Request, deep: bool = Query(False)) -> JSONResponse:
    return await _ready(request, deep)

"""Dell AIA facade used by the rest of the application.

Keeping the model integration behind one service module makes it easy for .NET
and non-Python developers to identify where model credentials, health probes,
and AutoGen client construction are handled.
"""
from __future__ import annotations

from .disparity_agent.agents.model_client import (
    DellAIAAuthenticationError,
    DellAIAConfigurationError,
    build_model_client,
    dell_aia_credential_fingerprints,
    probe_dell_aia_runtime,
)

__all__ = [
    "DellAIAAuthenticationError",
    "DellAIAConfigurationError",
    "build_model_client",
    "dell_aia_credential_fingerprints",
    "probe_dell_aia_runtime",
]

from __future__ import annotations

import html
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping

from .models import DisparityReport
from .judgment import canonical_judge_verdict, enforce_judge_on_report_dict
from .security import sanitize
from .settings import Settings


STATUS_CLASS = {
    "MATCH": "success",
    "MISMATCH": "danger",
    "MISSING": "warning",
    "INVALID_FORMAT": "violet",
    "TRUTH_FORMAT_INVALID": "danger",
    "UNVERIFIABLE": "neutral",
    "COUNTRY_SOURCE_CONFLICT": "danger",
    "COUNTRY_REVIEW_REQUIRED": "warning",
    "BOOLEAN_REVIEW_REQUIRED": "warning",
    "SOURCE_RECORD_MISSING": "warning",
    "SOURCE_UNAVAILABLE": "danger",
}


def _as_dict(report: DisparityReport | Mapping[str, Any]) -> dict[str, Any]:
    if isinstance(report, DisparityReport):
        return report.model_dump(mode="json")
    return json.loads(json.dumps(dict(report), default=str))


def _esc(value: Any) -> str:
    if value is None or value == "":
        return "—"
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, default=str)
    return html.escape(str(value))


def _pretty_json(value: Any) -> str:
    return html.escape(json.dumps(value, indent=2, ensure_ascii=False, default=str))


def _fmt_duration(value: Any) -> str:
    try:
        ms = max(0, int(float(value or 0)))
    except (TypeError, ValueError):
        return "—"
    if ms < 1000:
        return f"{ms} ms"
    seconds = ms / 1000.0
    if seconds < 60:
        return f"{seconds:.2f} s"
    minutes = int(seconds // 60)
    remainder = seconds - minutes * 60
    return f"{minutes}m {remainder:.1f}s"


def _status_badge(status: str) -> str:
    css = STATUS_CLASS.get(status, "neutral")
    return f'<span class="badge {css}">{html.escape(status.replace("_", " "))}</span>'


def _source_display(value: Any) -> str:
    if value in (None, "", "—"):
        return "—"
    text = str(value)
    labels = {
        "cps": "CPS",
        "rewards_db": "Rewards DB",
        "crowd_twist": "CrowdTwist",
    }
    return labels.get(text, text.replace("_", " ").title())


def _priority_badge(priority: str) -> str:
    css = {
        "CRITICAL": "danger",
        "HIGH": "warning",
        "MEDIUM": "violet",
        "LOW": "neutral",
    }.get(priority, "neutral")
    return f'<span class="badge {css}">{html.escape(priority)}</span>'


def _source_card(name: str, item: Mapping[str, Any]) -> str:
    connected = bool(item.get("connected"))
    found = bool(item.get("data_found"))
    diagnostics = item.get("diagnostics") or {}
    lookup_result = diagnostics.get("lookup_result") if isinstance(diagnostics, Mapping) else None
    if found:
        state, css, icon = "Data retrieved", "success", "✓"
    elif connected and lookup_result in {"no_value_found", "no_resolved_identifier", "no_value_found_after_identifier_sequence"}:
        state, css, icon = "No value found", "warning", "!"
    elif connected:
        state, css, icon = "Connected, no data", "warning", "!"
    else:
        state, css, icon = "Unavailable", "danger", "×"
    diagnostic_rows = []
    for label, key in (
        ("Stage", "stage"),
        ("Error code", "error_code"),
        ("HTTP status", "http_status"),
        ("Endpoint", "endpoint_host"),
        ("Latency", "latency_ms"),
        ("Method", "retrieval_method"),
    ):
        value = item.get(key)
        if value not in (None, ""):
            if key == "latency_ms":
                value = f"{value} ms"
            diagnostic_rows.append(f"<dt>{label}</dt><dd>{_esc(value)}</dd>")
    error_html = f'<div class="source-error">{_esc(item.get("error"))}</div>' if item.get("error") else ""
    hint_html = f'<div class="hint">{_esc(item.get("diagnostic_hint"))}</div>' if item.get("diagnostic_hint") else ""
    details_html = ""
    if diagnostics:
        details_html = (
            '<details><summary>Technical diagnostics</summary>'
            f'<pre>{_pretty_json(diagnostics)}</pre></details>'
        )
    return f"""
    <article class="source-card {css}">
      <div class="source-card-head">
        <div class="source-icon">{icon}</div>
        <div><h3>{html.escape(name)}</h3><span>{state}</span></div>
      </div>
      <dl>{''.join(diagnostic_rows)}</dl>
      {error_html}{hint_html}{details_html}
    </article>
    """


def render_html_report(
    report: DisparityReport | Mapping[str, Any],
    *,
    mask_pii: bool = False,
) -> str:
    data = _as_dict(report)
    if data.get("judge_result"):
        data = enforce_judge_on_report_dict(data)
    if mask_pii:
        data = sanitize(data)

    run_id = _esc(data.get("run_id"))
    created_at = data.get("created_at")
    try:
        created_label = datetime.fromisoformat(str(created_at).replace("Z", "+00:00")).strftime("%d %b %Y, %H:%M UTC")
    except Exception:
        created_label = str(created_at or "—")

    completeness = str(data.get("analysis_completeness") or "UNKNOWN")
    completeness_css = {
        "FULL": "success",
        "PARTIAL": "warning",
        "NO_AUTHORITATIVE_DATA": "danger",
    }.get(completeness, "neutral")

    source_status = data.get("source_status") or {}
    source_cards = "".join(
        _source_card(label, source_status.get(key) or {})
        for key, label in (
            ("cps", "CPS API + tCPS Country Search"),
            ("rewards_db", "Rewards DB"),
            ("crowd_twist", "CrowdTwist API"),
        )
    )

    attribute_rows = []
    for verdict in data.get("attributes") or []:
        obs = verdict.get("observations") or {}
        cps = (obs.get("cps") or {}).get("raw_value")
        db = (obs.get("rewards_db") or {}).get("raw_value")
        ct = (obs.get("crowd_twist") or {}).get("raw_value")
        wrong = verdict.get("wrong_sources") or []
        missing = verdict.get("missing_sources") or []
        unavailable = verdict.get("unavailable_sources") or []
        issue_sources = ", ".join([str(v).replace("_", " ").title() for v in wrong]) or "—"
        if missing:
            missing_text = ", ".join(str(v).replace("_", " ").title() for v in missing)
            issue_sources = f"{issue_sources}; missing attribute: {missing_text}" if issue_sources != "—" else f"Missing attribute: {missing_text}"
        if unavailable:
            unavailable_text = ", ".join(str(v).replace("_", " ").title() for v in unavailable)
            issue_sources = f"{issue_sources}; record unavailable: {unavailable_text}" if issue_sources != "—" else f"Record unavailable: {unavailable_text}"
        attribute_rows.append(
            f"""
            <tr>
              <td><strong>{_esc(verdict.get('label'))}</strong><div class="muted small">{_esc(verdict.get('attribute'))}</div></td>
              <td>{_status_badge(str(verdict.get('status') or 'UNKNOWN'))}</td>
              <td>{_esc(_source_display(verdict.get('truth_source')))}</td>
              <td class="value-cell">{_esc(verdict.get('truth_value'))}</td>
              <td class="value-cell">{_esc(cps)}</td>
              <td class="value-cell">{_esc(db)}</td>
              <td class="value-cell">{_esc(ct)}</td>
              <td>{_esc(issue_sources)}</td>
              <td class="explanation">{_esc(verdict.get('explanation'))}</td>
            </tr>
            """
        )

    suggestion_rows = []
    for suggestion in data.get("suggestions") or []:
        review = bool(suggestion.get("requires_manual_review"))
        readiness = (
            '<span class="badge success">EXACT CHANGE</span>'
            if not review and suggestion.get("recommended_value") is not None
            else '<span class="badge danger">MANUAL REVIEW</span>'
        )
        automation = "Eligible after approval" if suggestion.get("automation_eligible") else "Not eligible"
        suggestion_rows.append(
            f"""
            <tr>
              <td>{_esc(str(suggestion.get('scope') or 'ATTRIBUTE').replace('_', ' ').title())}</td>
              <td><strong>{_esc(suggestion.get('label'))}</strong><div class="muted small">{_esc(suggestion.get('suggestion_id'))}</div></td>
              <td>{_priority_badge(str(suggestion.get('priority') or 'MEDIUM'))}</td>
              <td>{_esc(str(suggestion.get('action') or '').replace('_', ' ').title())}</td>
              <td>{_esc(_source_display(suggestion.get('target_source')))}</td>
              <td class="value-cell current-value">{_esc(suggestion.get('current_value'))}</td>
              <td class="value-cell recommended-value">{_esc(suggestion.get('recommended_value'))}</td>
              <td>{_esc(_source_display(suggestion.get('truth_source')))}</td>
              <td>{readiness}<div class="muted small" style="margin-top:5px">{_esc(automation)}</div></td>
              <td class="explanation"><strong>{_esc(suggestion.get('recommendation'))}</strong><div class="muted small" style="margin-top:7px">{_esc(suggestion.get('reason'))}</div></td>
            </tr>
            """
        )
    if not suggestion_rows:
        suggestion_rows.append(
            '<tr><td colspan="10"><div class="empty-state">No correction suggestions were generated. All comparable attributes matched or no supported attributes were configured.</div></td></tr>'
        )

    actionable_count = int(data.get("actionable_suggestion_count") or 0)
    manual_review_count = int(data.get("manual_review_count") or 0)

    api_summary = data.get("api_knowledge_summary") or {}
    api_summary_cards = "".join(
        f'<div class="suggestion-stat"><strong>{_esc(api_summary.get(key, 0))}</strong><span>{html.escape(label)}</span></div>'
        for key, label in (
            ("operation_count", "Catalog operations"),
            ("schema_count", "Known schemas"),
            ("live_operation_count", "Live operations"),
            ("dry_run_operation_count", "Dry-run write operations"),
            ("catalog_only_operation_count", "Catalog-only operations"),
            ("placeholder_operation_count", "Legacy placeholders"),
        )
    )

    use_case_rows = []
    for use_case in data.get("use_case_recommendations") or []:
        use_case_rows.append(
            f"""
            <tr>
              <td><strong>{_esc(use_case.get('title'))}</strong><div class="muted small">{_esc(use_case.get('use_case_id'))}</div></td>
              <td>{_priority_badge(str(use_case.get('priority') or 'MEDIUM'))}</td>
              <td>{_esc(use_case.get('score'))}</td>
              <td>{_esc(use_case.get('feasibility'))}</td>
              <td>{_esc(use_case.get('implementation_status'))}</td>
              <td>{_esc(use_case.get('source_of_truth'))}</td>
              <td>{_esc(', '.join(use_case.get('required_operations') or []))}</td>
              <td class="explanation">{_esc(use_case.get('why_suggested'))}</td>
            </tr>
            """
        )
    if not use_case_rows:
        use_case_rows.append('<tr><td colspan="8"><div class="empty-state">No API-grounded use cases were generated.</div></td></tr>')

    warnings = data.get("warnings") or []
    warnings_html = "".join(f"<li>{_esc(item)}</li>" for item in warnings) or "<li>No warnings.</li>"

    ai_analysis = dict(data.get("ai_analysis") or {})
    ai_analysis.pop("use_case_architect", None)
    ai_analysis.pop("implementation_plan", None)
    judge = data.get("judge_result") or {}
    ai_execution = data.get("ai_execution") or {"status": "NOT_RUN"}
    mcp_execution = data.get("mcp_execution") or {"status": "NOT_RUN"}
    agentic_success = ai_execution.get("status") == "SUCCESS" and mcp_execution.get("status") == "SUCCESS"
    judge_verdict = canonical_judge_verdict(judge.get("verdict") or judge.get("status"))
    final_content_status = ai_execution.get("final_content_status") or judge.get("content_disposition") or "UNKNOWN"
    if judge_verdict == "ACCEPTED":
        judge_notice = '<div class="guardrail" style="background:#e9f8f1;border-color:#9bd9be;color:#087448"><strong>Judge decision:</strong> Analyst content accepted.</div>'
        ai_title = "Dell AIA analyst · accepted"
    elif judge_verdict == "PARTIAL":
        judge_notice = '<div class="guardrail"><strong>Judge decision:</strong> Original analyst content was replaced with judge-corrected deterministic content.</div>'
        ai_title = "Published AI analysis · corrected by judge"
    else:
        judge_notice = '<div class="guardrail" style="background:#fff0f2;border-color:#efb1ba;color:#9f2435"><strong>Judge decision:</strong> Original analyst content was suppressed; deterministic/judge-corrected content is published.</div>'
        ai_title = "Published AI analysis · deterministic fallback"
    ai_html = (
        f'<div class="json-panel"><h3>{html.escape(ai_title)}</h3><pre>{_pretty_json(ai_analysis)}</pre></div>'
        if agentic_success else
        f'<div class="empty-state"><strong>Agentic analysis failed or was not completed.</strong><br>{_esc((ai_analysis or {}).get("message") or "Open the execution diagnostics below.")}</div>'
    )
    judge_html = (
        f'<div class="json-panel"><h3>Independent MCP evidence judge</h3><pre>{_pretty_json(judge)}</pre></div>'
        if agentic_success else ""
    )
    execution_html = (
        f'<div class="json-panel"><h3>Dell AIA execution</h3><pre>{_pretty_json(ai_execution)}</pre></div>'
        f'<div class="json-panel"><h3>MCP execution</h3><pre>{_pretty_json(mcp_execution)}</pre></div>'
    )

    timings = data.get("timings") or {}
    source_latency = timings.get("source_latency_ms") or {}
    mcp_tool_timings = timings.get("mcp_tool_timings_ms") or {}
    total_ms = (timings.get("batch_member_end_to_end_ms") or timings.get("end_to_end_ms") or timings.get("total_processing_ms") or 0)
    timing_cards = "".join([
        f'<div class="suggestion-stat"><strong>{_esc(_fmt_duration(total_ms))}</strong><span>Total end-to-end</span></div>',
        f'<div class="suggestion-stat"><strong>{_esc(_fmt_duration(timings.get("data_collection_agent_ms")))}</strong><span>Data Collection Agent</span></div>',
        f'<div class="suggestion-stat"><strong>{_esc(_fmt_duration(timings.get("analysis_agent_ms")))}</strong><span>Dell AIA Analyst</span></div>',
        f'<div class="suggestion-stat"><strong>{_esc(_fmt_duration(timings.get("judge_agent_ms")))}</strong><span>Dell AIA Judge</span></div>',
        f'<div class="suggestion-stat"><strong>{_esc(_fmt_duration(timings.get("dell_aia_queue_wait_ms")))}</strong><span>Dell AIA queue wait</span></div>',
        f'<div class="suggestion-stat"><strong>{_esc(_fmt_duration(timings.get("audit_report_write_ms")))}</strong><span>Report write</span></div>',
    ])
    timing_rows_data = [
        ("Batch source queue wait", timings.get("batch_source_queue_wait_ms"), "Wait before this member entered the bounded source/API worker pool."),
        ("Data Collection Agent", timings.get("data_collection_agent_ms"), "MCP workbench lifecycle and evidence retrieval for this member."),
        ("MCP health_check", mcp_tool_timings.get("health_check_ms"), "MCP tool duration."),
        ("MCP run_disparity_check", mcp_tool_timings.get("run_disparity_check_ms"), "Includes deterministic source retrieval and comparison pipeline."),
        ("MCP API catalog", mcp_tool_timings.get("get_api_catalog_summary_ms"), "MCP API knowledge summary retrieval."),
        ("Source collection wall time", timings.get("source_collection_wall_ms"), "Wall-clock source collection; parallel source calls are not additive."),
        ("CPS API observed latency", source_latency.get("cps_api"), "Connector-reported latency."),
        ("tCPS country observed latency", source_latency.get("tcps_country_api"), "Supplemental tCPS lookup when enabled/attempted."),
        ("Rewards DB observed latency", source_latency.get("rewards_db"), "Connector-reported database lookup latency."),
        ("CrowdTwist API observed latency", source_latency.get("crowd_twist_api"), "Connector-reported latency."),
        ("Canonicalization", timings.get("canonicalization_ms"), "Map raw source payloads into canonical attributes."),
        ("Deterministic comparison", timings.get("comparison_ms"), "Apply truth rules and produce attribute verdicts."),
        ("Suggestion generation", timings.get("suggestion_generation_ms"), "Create exact-change/manual-review recommendations."),
        ("Batch phase barrier wait", timings.get("batch_phase_barrier_wait_ms"), "In bulk mode, wait between data collection completion and LLM phase start."),
        ("Dell AIA queue wait", timings.get("dell_aia_queue_wait_ms"), "Wait for the bounded Dell AIA transaction slot."),
        ("Dell AIA client setup", timings.get("model_client_setup_ms"), "Token/model-client initialization across attempts."),
        ("Dell AIA Analysis Agent", timings.get("analysis_agent_ms"), "Includes retry/backoff time for this agent if rate-limited."),
        ("Analysis output parsing", timings.get("analysis_output_parse_ms"), "Local deterministic JSON parsing/normalization."),
        ("Dell AIA Judge Agent", timings.get("judge_agent_ms"), "Includes retry/backoff time for this judge if rate-limited."),
        ("Judge output parsing", timings.get("judge_output_parse_ms"), "Local deterministic JSON parsing/normalization."),
        ("Audit/HTML write", timings.get("audit_report_write_ms"), "First persisted JSON + styled HTML write."),
        ("Total end-to-end", total_ms, "Member wall-clock duration captured by the application."),
    ]
    timing_rows = "".join(
        f"<tr><td><strong>{html.escape(label)}</strong></td><td>{html.escape(_fmt_duration(value))}</td><td>{html.escape(note)}</td></tr>"
        for label, value, note in timing_rows_data if value not in (None, "")
    ) or '<tr><td colspan="3"><div class="empty-state">Timing data was not captured for this legacy report.</div></td></tr>'

    raw_records = data.get("records") or {}
    raw_html = "".join(
        f'<details><summary>{html.escape(label)}</summary><pre>{_pretty_json((raw_records.get(key) or {}).get("raw"))}</pre></details>'
        for key, label in (("cps", "CPS raw response"), ("rewards_db", "Rewards DB row"), ("crowd_twist", "CrowdTwist raw response"))
    )

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Data Disparity Report · {run_id}</title>
<style>
:root{{--navy:#0867b5;--blue:#0878b6;--cyan:#00a4b8;--paper:#eef3f8;--ink:#182230;--muted:#667085;--line:#dfe7f0;--success:#138a5b;--success-bg:#e9f8f1;--danger:#c6384a;--danger-bg:#fff0f2;--warning:#ad6a00;--warning-bg:#fff6df;--violet:#7456c9;--violet-bg:#f3efff;--neutral:#5e6b7c;--neutral-bg:#edf1f5}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--paper);color:var(--ink);font-family:Inter,Segoe UI,Arial,sans-serif;line-height:1.45}} .page{{max-width:1500px;margin:0 auto;padding:28px}}
.hero{{position:relative;overflow:hidden;padding:36px;border-radius:24px;background:linear-gradient(125deg,#0867b5,#00a4b8);color:white;box-shadow:0 18px 45px rgba(22,45,73,.12)}}
.hero:after{{content:"";position:absolute;width:360px;height:360px;border-radius:50%;right:-120px;top:-160px;background:rgba(255,255,255,.12)}} .eyebrow{{text-transform:uppercase;letter-spacing:.14em;font-size:12px;font-weight:800;opacity:.8}} h1{{font-size:34px;line-height:1.1;margin:8px 0 12px}} .hero p{{max-width:900px;margin:0;color:#d9efff;font-size:16px}} .hero-meta{{display:flex;gap:12px;flex-wrap:wrap;margin-top:22px}} .hero-chip{{padding:8px 12px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.1);border-radius:999px;font-size:13px}}
.section{{margin-top:24px;background:white;border:1px solid var(--line);border-radius:20px;padding:24px;box-shadow:0 8px 24px rgba(28,48,79,.06)}} .section-title{{display:flex;justify-content:space-between;align-items:end;gap:16px;margin-bottom:18px}} .section-title h2{{margin:0;font-size:21px}} .section-title p{{margin:4px 0 0;color:var(--muted)}}
.kpis{{display:grid;grid-template-columns:repeat(7,minmax(125px,1fr));gap:14px;margin-top:20px}} .kpi{{background:white;border:1px solid var(--line);border-radius:18px;padding:18px;box-shadow:0 8px 20px rgba(28,48,79,.05)}} .kpi .label{{font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);font-weight:800}} .kpi .number{{font-size:30px;font-weight:800;margin-top:5px}} .kpi .sub{{font-size:12px;color:var(--muted)}}
.summary-banner{{margin-top:18px;border-left:5px solid var(--blue);background:#eef7ff;padding:16px 18px;border-radius:12px;font-weight:650}} .source-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}} .source-card{{border:1px solid var(--line);border-top:5px solid var(--neutral);border-radius:16px;padding:18px;background:#fff}} .source-card.success{{border-top-color:var(--success)}} .source-card.warning{{border-top-color:var(--warning)}} .source-card.danger{{border-top-color:var(--danger)}} .source-card-head{{display:flex;gap:12px;align-items:center}} .source-card-head h3{{margin:0;font-size:18px}} .source-card-head span{{color:var(--muted);font-size:13px}} .source-icon{{width:36px;height:36px;border-radius:50%;display:grid;place-items:center;font-weight:900;background:var(--neutral-bg);color:var(--neutral)}} .source-card.success .source-icon{{background:var(--success-bg);color:var(--success)}} .source-card.warning .source-icon{{background:var(--warning-bg);color:var(--warning)}} .source-card.danger .source-icon{{background:var(--danger-bg);color:var(--danger)}} dl{{display:grid;grid-template-columns:110px 1fr;gap:6px 12px;margin:16px 0 0}} dt{{font-size:12px;color:var(--muted)}} dd{{margin:0;font-size:13px;overflow-wrap:anywhere}} .source-error{{margin-top:14px;padding:10px 12px;border-radius:10px;background:var(--danger-bg);color:var(--danger);font-weight:700}} .hint{{margin-top:10px;color:#4d5d73;font-size:13px}}
.table-wrap{{overflow:auto;border:1px solid var(--line);border-radius:14px}} table{{width:100%;border-collapse:collapse;min-width:1250px}} th{{position:sticky;top:0;background:#edf4fb;text-align:left;padding:12px;font-size:11px;text-transform:uppercase;letter-spacing:.07em;color:#52657d;border-bottom:1px solid var(--line)}} td{{padding:12px;border-bottom:1px solid #edf1f5;vertical-align:top;font-size:13px}} tr:last-child td{{border-bottom:0}} tr:hover td{{background:#fafcff}} .value-cell{{max-width:210px;overflow-wrap:anywhere;font-family:Consolas,monospace;font-size:12px}} .explanation{{min-width:280px}} .badge{{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:850;white-space:nowrap}} .badge.success{{background:var(--success-bg);color:var(--success)}} .badge.danger{{background:var(--danger-bg);color:var(--danger)}} .badge.warning{{background:var(--warning-bg);color:var(--warning)}} .badge.violet{{background:var(--violet-bg);color:var(--violet)}} .badge.neutral{{background:var(--neutral-bg);color:var(--neutral)}}
.report-nav{{position:sticky;top:0;z-index:20;margin:18px 0 0;padding:10px;display:flex;gap:8px;flex-wrap:wrap;background:rgba(244,247,251,.96);backdrop-filter:blur(8px);border:1px solid var(--line);border-radius:14px}} .report-nav a{{text-decoration:none;color:var(--blue);font-size:12px;font-weight:800;padding:7px 10px;border-radius:999px;background:white;border:1px solid var(--line)}} .report-nav a:hover{{background:#eaf4ff}} .anchor{{scroll-margin-top:80px}} .two-col{{display:grid;grid-template-columns:1fr 1fr;gap:16px}} .policy{{padding:16px;border-radius:14px;background:#f0f5fb;border:1px solid var(--line)}} .suggestion-overview{{display:grid;grid-template-columns:repeat(3,minmax(150px,1fr));gap:12px;margin-bottom:16px}} .suggestion-stat{{padding:14px 16px;border:1px solid var(--line);border-radius:14px;background:#fbfdff}} .suggestion-stat strong{{display:block;font-size:25px}} .suggestion-stat span{{font-size:12px;color:var(--muted)}} .current-value{{background:#fff8f8}} .recommended-value{{background:#effbf5;color:#087448;font-weight:800}} .guardrail{{margin-top:14px;padding:13px 15px;border-radius:12px;background:#fff8e8;border:1px solid #f4d28a;color:#755000}} ul{{margin:10px 0 0;padding-left:20px}} li{{margin:7px 0}} pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#081a2e;color:#d9e8f6;padding:16px;border-radius:12px;font:12px/1.5 Consolas,monospace;max-height:520px;overflow:auto}} details{{margin-top:12px;border:1px solid var(--line);border-radius:12px;padding:11px 13px;background:#fbfdff}} summary{{cursor:pointer;font-weight:750}} .json-panel h3{{margin:0 0 10px}} .empty-state{{padding:18px;border-radius:12px;background:var(--neutral-bg);color:var(--muted)}} .muted{{color:var(--muted)}} .small{{font-size:11px}} footer{{padding:28px 4px;text-align:center;color:var(--muted);font-size:12px}}
@media(max-width:1000px){{.kpis{{grid-template-columns:repeat(2,1fr)}}.source-grid,.two-col,.suggestion-overview{{grid-template-columns:1fr}}.page{{padding:14px}}}}
@media print{{body{{background:white}}.page{{max-width:none;padding:0}}.hero,.section,.kpi{{box-shadow:none}}details{{break-inside:avoid}}.table-wrap{{overflow:visible}}table{{font-size:9px;min-width:0}}th,td{{padding:6px}}}}
</style>
</head>
<body><main class="page">
<header class="hero"><div class="eyebrow">Dell Rewards · Agentic Quality Control</div><h1>Data Disparity Analysis Report</h1><p>{_esc(data.get('deterministic_summary'))}</p><div class="hero-meta"><span class="hero-chip">Run {run_id}</span><span class="hero-chip">{html.escape(created_label)}</span><span class="hero-chip">Search: {_esc(data.get('search_type'))}</span><span class="hero-chip">Total: {_esc(_fmt_duration(total_ms))}</span><span class="hero-chip badge {completeness_css}">{html.escape(completeness.replace('_',' '))}</span><span class="hero-chip">{'MASKED · safe to share' if mask_pii else 'UNMASKED · contains source values'}</span></div></header>
<section class="kpis"><div class="kpi"><div class="label">Mismatches</div><div class="number">{_esc(data.get('mismatch_count',0))}</div><div class="sub">Values differing from truth</div></div><div class="kpi"><div class="label">Missing attributes</div><div class="number">{_esc(data.get('missing_count',0))}</div><div class="sub">Absent inside existing records</div></div><div class="kpi"><div class="label">Missing records</div><div class="number">{_esc(data.get('missing_record_count',0))}</div><div class="sub">Source member not found</div></div><div class="kpi"><div class="label">Deferred</div><div class="number">{_esc(data.get('deferred_attribute_count',0))}</div><div class="sub">Awaiting source record</div></div><div class="kpi"><div class="label">Format issues</div><div class="number">{_esc(data.get('invalid_format_count',0))}</div><div class="sub">Invalid canonical formats</div></div><div class="kpi"><div class="label">Unverifiable</div><div class="number">{_esc(data.get('unverifiable_count',0))}</div><div class="sub">No authoritative value</div></div><div class="kpi"><div class="label">Completeness</div><div class="number" style="font-size:20px">{html.escape(completeness.replace('_',' '))}</div><div class="sub">Evidence availability</div></div></section>
<div class="summary-banner">{_esc(data.get('deterministic_summary'))}</div>
<nav class="report-nav" aria-label="Report sections"><a href="#source-health">Source Health</a><a href="#suggestions">Suggestions</a><a href="#attribute-verdicts">Attribute Verdicts</a><a href="#api-knowledge">API Knowledge</a><a href="#timing">Timing</a><a href="#audit-summary">Audit Summary</a><a href="#agent-execution">Agent Execution</a><a href="#ai-analysis">AI Analysis</a><a href="#raw-evidence">Raw Evidence</a></nav>
<section id="source-health" class="section anchor"><div class="section-title"><div><h2>Source health</h2><p>Connection, authentication and retrieval diagnostics without exposing credentials.</p></div></div><div class="source-grid">{source_cards}</div></section>
<section id="suggestions" class="section anchor"><div class="section-title"><div><h2>Suggestions — Recommended Corrections</h2><p>Recommendations use per-attribute business truth. Missing source member records are handled once at record level and never expanded into multiple field updates.</p></div></div><div class="suggestion-overview"><div class="suggestion-stat"><strong>{actionable_count}</strong><span>Exact field changes</span></div><div class="suggestion-stat"><strong>{manual_review_count}</strong><span>Manual/record items</span></div><div class="suggestion-stat"><strong>{actionable_count + manual_review_count}</strong><span>Total guidance items</span></div></div><div class="table-wrap"><table><thead><tr><th>Scope</th><th>Attribute / Record</th><th>Priority</th><th>Action</th><th>Change in</th><th>Current value</th><th>Change to</th><th>Based on truth</th><th>Readiness</th><th>Recommendation</th></tr></thead><tbody>{''.join(suggestion_rows)}</tbody></table></div><div class="guardrail"><strong>Execution guardrail:</strong> this report is read-only. If a source member record is absent, field updates are blocked until onboarding/linkage is resolved and the record can be retrieved. Country conflicts, missing OR-gate inputs, invalid values, and unverifiable attributes remain approval-gated.</div></section>
<section id="api-knowledge" class="section anchor"><div class="section-title"><div><h2>API Knowledge Base</h2><p>Secret-free operation, schema, payload and implementation knowledge extracted from the uploaded Dell Utility Service source.</p></div></div><div class="suggestion-overview" style="grid-template-columns:repeat(3,minmax(150px,1fr))">{api_summary_cards}</div><div class="policy"><strong>Catalog version:</strong> {_esc(api_summary.get('catalog_version'))}<br><strong>Systems:</strong> {_esc(', '.join(api_summary.get('systems') or []))}<br><strong>Grounding:</strong> {_esc(api_summary.get('generated_from'))}</div><div class="guardrail"><strong>API guardrail:</strong> Dell AIA may explain and rank the catalog, but it cannot invent endpoints, payload fields, or promote dry-run/catalog-only operations to live writes.</div></section>
<section id="timing" class="section anchor"><div class="section-title"><div><h2>Execution Timing</h2><p>Total member time and measured duration of each major processing step.</p></div></div><div class="suggestion-overview" style="grid-template-columns:repeat(3,minmax(150px,1fr))">{timing_cards}</div><div class="table-wrap"><table style="min-width:800px"><thead><tr><th>Step</th><th>Duration</th><th>Measurement</th></tr></thead><tbody>{timing_rows}</tbody></table></div><div class="guardrail"><strong>Timing note:</strong> {_esc(timings.get('timing_note') or 'Parallel operations overlap, so individual step durations should not be summed to reproduce total wall-clock time.')}</div></section>
<section id="audit-summary" class="section anchor"><div class="section-title"><div><h2>Audit Summary</h2><p>Run metadata, truth policy, controls, and report-level execution status.</p></div></div><div class="two-col"><div><h3>Run metadata</h3><div class="policy"><strong>Run ID:</strong> {run_id}<br><strong>Created:</strong> {html.escape(created_label)}<br><strong>Completeness:</strong> {html.escape(completeness.replace('_',' '))}<br><strong>Exact changes:</strong> {actionable_count}<br><strong>Manual review:</strong> {manual_review_count}<br><strong>Dell AIA execution:</strong> {_esc(ai_execution.get('status'))}<br><strong>Judge verdict:</strong> {_esc(judge_verdict)}<br><strong>Final content:</strong> {_esc(final_content_status)}<br><strong>MCP:</strong> {_esc(mcp_execution.get('status'))}<br><strong>Total time:</strong> {_esc(_fmt_duration(total_ms))}</div></div><div><h3>Truth policy</h3><div class="policy">{_esc(data.get('truth_policy'))}</div><h3 style="margin-top:18px">Warnings and controls</h3><ul>{warnings_html}</ul></div></div></section>
<section id="agent-execution" class="section anchor"><div class="section-title"><div><h2>Agent Execution Proof</h2><p>A successful run must show Dell AIA, an attached MCP workbench, mandatory tool calls, and an independent evidence judge.</p></div></div><div class="two-col">{execution_html}</div></section>
<section id="ai-analysis" class="section anchor"><div class="section-title"><div><h2>AI analysis and evidence judge</h2><p>Technical model execution and content approval are reported separately. Deterministic values remain authoritative.</p></div></div>{judge_notice}<div class="policy" style="margin-top:14px"><strong>Judge verdict:</strong> {_esc(judge_verdict)}<br><strong>Final content status:</strong> {_esc(final_content_status)}</div><div class="two-col" style="margin-top:16px">{ai_html}{judge_html}</div></section>
<section id="raw-evidence" class="section anchor"><div class="section-title"><div><h2>Raw source evidence</h2><p>Expandable source payloads captured for this run.</p></div></div>{raw_html}</section>
<details id="attribute-verdicts" class="section anchor"><summary><strong>Attribute Verdicts · Actual source data</strong><span class="muted small" style="display:block;margin-top:4px">Canonical values retrieved from CPS, Rewards DB, and CrowdTwist. Expand to review the full comparison table.</span></summary><div class="table-wrap" style="margin-top:14px"><table><thead><tr><th>Attribute</th><th>Status</th><th>Truth source</th><th>Expected</th><th>CPS</th><th>Rewards DB</th><th>CrowdTwist</th><th>Issue source</th><th>Evidence explanation</th></tr></thead><tbody>{''.join(attribute_rows)}</tbody></table></div></details>
<footer>Generated by Agentic Data Disparity Checker · {run_id} · Full technical report; analyst planning workspaces are intentionally omitted.</footer>
</main></body></html>"""


def save_audit_report(report: DisparityReport, settings: Settings) -> Path:
    """Persist canonical report evidence plus separately rendered privacy variants.

    The canonical ``<run_id>.json`` and ``<run_id>.html`` files intentionally
    retain original source values so an approved ``masked=false`` request can
    return the real values.  Shareable masked artifacts are written separately.
    The audit artifact remains masked when ``mask_pii_in_audit`` is enabled.
    """

    settings.runs_dir.mkdir(parents=True, exist_ok=True)
    raw_output = report.model_dump(mode="json")
    masked_output = sanitize(raw_output)
    if isinstance(masked_output, dict):
        masked_output = {**masked_output, "report_privacy": "MASKED"}

    raw_json_path = settings.runs_dir / f"{report.run_id}.json"
    raw_html_path = settings.runs_dir / f"{report.run_id}.html"
    masked_json_path = settings.runs_dir / f"{report.run_id}.masked.json"
    masked_html_path = settings.runs_dir / f"{report.run_id}.masked.html"
    audit_path = settings.runs_dir / f"{report.run_id}.audit.json"

    raw_json_path.write_text(
        json.dumps(raw_output, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    raw_html_path.write_text(render_html_report(raw_output, mask_pii=False), encoding="utf-8")
    masked_json_path.write_text(
        json.dumps(masked_output, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    masked_html_path.write_text(render_html_report(raw_output, mask_pii=True), encoding="utf-8")

    audit_output = masked_output if settings.mask_pii_in_audit else raw_output
    audit_path.write_text(
        json.dumps(audit_output, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    return audit_path

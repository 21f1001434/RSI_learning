from __future__ import annotations

from functools import lru_cache
import re
from pathlib import Path
from typing import ClassVar, Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from .config_server import fetch_spring_config, map_spring_properties
from .concurrency_policy import DELL_AIA_PARALLEL_WORKERS
from src.app_settings import (
    CPS_ACCOUNT_PATH,
    CPS_BASE_URL_FALLBACK,
    DEFAULT_REWARDS_ENVIRONMENT,
    DELL_AIA_ALLOWED_HOST,
    DELL_AIA_AUTH_MODE,
    DELL_AIA_DEFAULT_BASE_URL,
    DELL_AIA_DEFAULT_MODEL,
    DELL_AIA_DEFAULT_TEMPERATURE,
    DELL_AIA_PROVIDER,
    LOCAL_DB_CONNECTION_FALLBACK,
    RUNS_DIR,
    RESOURCES_DIR,
    ADAPTIVE_MEMORY_DB,
    TCPS_DEFAULT_COUNTRY_ATTRIBUTE,
    TCPS_REQUEST_SCHEMA,
    TCPS_SEARCH_URL,
)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    app_env: str = "local"
    log_level: str = "INFO"
    use_mock_sources: bool = False
    mock_case: str = "case1"
    mask_pii_in_audit: bool = True
    request_timeout_seconds: float = 30.0

    # Bounded adaptive memory / replay-based recursive self-improvement.
    # Persistent memory is deliberately PII-minimized: it stores generic execution
    # signatures, outcome scores and lessons, never member identifiers or source values.
    adaptive_memory_enabled: bool = True
    adaptive_memory_db_path: Path = Field(default=ADAPTIVE_MEMORY_DB)
    adaptive_memory_retention_days: int = 30
    adaptive_memory_max_trajectories: int = 5000
    adaptive_memory_replay_limit: int = 3
    rsi_enabled: bool = True
    rsi_min_samples_per_strategy: int = 3
    rsi_exploration_interval: int = 12
    rsi_latency_target_ms: int = 45000
    # Optional bounded champion/challenger model selection. The allow-list is
    # deployment-owned; RSI can select only from these configured model names.
    dell_aia_model_candidates: str = ""
    adaptive_model_selection_enabled: bool = False
    adaptive_model_min_samples: int = 3
    adaptive_model_exploration_interval: int = 20
    # A learned skill is a successful strategy/model pairing for a PII-free
    # evidence-shape signature. It never stores user identifiers or values.
    adaptive_skill_min_samples: int = 3

    bootstrap_from_spring_config: bool = True
    rewards_environment: Literal["g1", "g2", "g4"] = DEFAULT_REWARDS_ENVIRONMENT  # type: ignore[assignment]
    spring_config_username: str = ""
    spring_config_password: str = ""
    spring_config_verify_ssl: bool = True
    spring_config_source_url: str = ""
    spring_config_error: str = ""

    # Dell AIA is the only supported model provider, but credentials and model
    # name are injected at deployment time rather than stored in source control.
    dell_aia_provider: str = DELL_AIA_PROVIDER
    dell_aia_auth_mode: str = DELL_AIA_AUTH_MODE
    dell_aia_base_url: str = DELL_AIA_DEFAULT_BASE_URL
    dell_aia_allowed_host: str = DELL_AIA_ALLOWED_HOST
    dell_aia_model: str = DELL_AIA_DEFAULT_MODEL
    dell_aia_temperature: float = DELL_AIA_DEFAULT_TEMPERATURE
    dell_aia_client_id: str = ""
    dell_aia_client_secret: str = ""
    dell_aia_verify_ssl: bool = True
    require_dell_aia: bool = True
    require_mcp_tool_use: bool = True

    # Dell AIA multi-transaction model configuration.
    ai_max_tool_iterations: int = 16
    dell_aia_multiple_transactions: bool = True
    # Immutable for every role and entry point. Environment variables and
    # request payloads cannot reduce or increase the tested Dell AIA worker pool.
    dell_aia_max_parallel_transactions: ClassVar[int] = DELL_AIA_PARALLEL_WORKERS
    dell_aia_rate_limit_retries: int = 5
    dell_aia_rate_limit_base_delay_seconds: float = 2.0
    dell_aia_rate_limit_max_delay_seconds: float = 30.0

    # CPS. The original .NET implementation sends only grant_type during DCI
    # token acquisition, so scope transmission is disabled unless explicitly enabled.
    cps_base_url: str = CPS_BASE_URL_FALLBACK
    cps_account_path: str = CPS_ACCOUNT_PATH
    cps_auth_url: str = ""
    cps_client_id: str = ""
    cps_client_secret: str = ""
    cps_scope: str = ""
    cps_send_scope: bool = False
    cps_api_key: str = ""
    cps_api_key_header: str = "X-API-Key"
    cps_verify_ssl: bool = True

    # Supplemental tCPS / Dell Identity User Provisioning SCIM search.
    # By default the connector reuses the fresh CPS OAuth bearer token already
    # acquired for the member lookup. TCPS_BEARER_TOKEN remains an optional
    # explicit override when Dell Identity requires a dedicated token.
    tcps_enabled: bool = True
    tcps_search_url: str = TCPS_SEARCH_URL
    tcps_use_cps_bearer_token: bool = True
    tcps_bearer_token: str = ""
    tcps_request_schema: str = TCPS_REQUEST_SCHEMA
    tcps_default_country_attribute: str = TCPS_DEFAULT_COUNTRY_ATTRIBUTE
    tcps_verify_ssl: bool = True

    # CrowdTwist
    crowd_twist_base_url: str = ""
    crowd_twist_user_path: str = "v2/users/{value}/"
    crowd_twist_auth_url: str = ""
    crowd_twist_client_id: str = ""
    crowd_twist_client_secret: str = ""
    crowd_twist_scope: str = ""
    crowd_twist_api_key: str = ""
    crowd_twist_verify_ssl: bool = True

    # CrowdTwist write contract. The existing Dell Utility service intentionally
    # uses the Ext2 client/endpoint for reads but the Ext client/endpoint for
    # updates. Keep those contracts separate so Agentic writes reuse the proven
    # manual-update path instead of PUTing to the read endpoint. When these
    # values are absent we fall back to the read credentials for compatibility.
    crowd_twist_update_base_url: str = ""
    crowd_twist_update_client_id: str = ""
    crowd_twist_update_client_secret: str = ""

    # Source write controls. A write can execute only after the role-specific
    # approval state machine completes. Business uses one chat approval; Customer
    # Support, Technical, and Admin require chat approval plus the final-review
    # popup. CPS remains read-only. Use dry_run/disabled for non-writing environments.
    source_write_mode: Literal["disabled", "dry_run", "live"] = "live"
    source_write_confirmation_ttl_minutes: int = 10
    source_write_max_targets: int = 25
    source_write_audit_file: Path = Field(default=RUNS_DIR / "source_write_audit.jsonl")
    source_write_audit_unmasked_file: Path = Field(default=RUNS_DIR / "source_write_audit.unmasked.jsonl")

    # Internal loopback bridge back into the .NET utility service. Agentic AI
    # performs governance/orchestration in Python but delegates the physical
    # Rewards DB/CrowdTwist mutation to the exact same .NET services used by
    # the manual tabs. The launcher injects the ephemeral internal key.
    utility_service_base_url: str = "http://127.0.0.1:49690"
    utility_service_internal_key: str = ""

    # CPS update is environment-specific. The known codebase exposes CPS create
    # and read operations, but no verified update path. Configure these only
    # after the external contract is approved.
    cps_update_path: str = ""
    cps_update_method: Literal["PATCH", "PUT"] = "PATCH"
    cps_create_path: str = "v2/Accounts"

    # CrowdTwist live update endpoint derived from the uploaded utility service.
    crowd_twist_update_path: str = "v2/users/{crowd_twist_id}"

    # Rewards DB
    rewards_db_connection_string: str = ""
    rewards_db_server: str = ""
    rewards_db_name: str = ""
    rewards_db_username: str = ""
    rewards_db_password: str = ""
    rewards_db_driver: str = "ODBC Driver 18 for SQL Server"
    rewards_db_encrypt: str = "yes"
    rewards_db_trust_server_certificate: str = "no"
    rewards_db_schema: str = "dbo"
    rewards_db_member_table: str = "Members"
    allow_local_db_fallback: bool = True

    allow_crowd_twist_as_last_resort: bool = False
    flag_missing_supported_attributes: bool = True

    enable_playwright_fallback: bool = False
    playwright_mcp_command: str = "npx"
    playwright_mcp_package: str = "@playwright/mcp@latest"
    playwright_browser: str = "chrome"
    playwright_headless: bool = True
    playwright_output_dir: str = "playwright-output"
    cps_portal_search_url_template: str = ""
    crowd_twist_portal_search_url_template: str = ""

    field_map_path: Path = Field(default=RESOURCES_DIR / "field_map.yaml")
    runs_dir: Path = Field(default=RUNS_DIR)

    @field_validator("dell_aia_model")
    @classmethod
    def validate_dell_aia_model_name(cls, value: str) -> str:
        value = str(value or "").strip()
        if not value or not re.fullmatch(r"[A-Za-z0-9._:/-]{1,160}", value):
            raise ValueError("DELL_AIA_MODEL contains unsupported characters")
        return value

    @field_validator("dell_aia_model_candidates")
    @classmethod
    def validate_dell_aia_model_candidates(cls, value: str) -> str:
        candidates = [part.strip() for part in str(value or "").split(",") if part.strip()]
        if len(candidates) != len(set(candidates)):
            raise ValueError("DELL_AIA_MODEL_CANDIDATES contains duplicates")
        for candidate in candidates:
            if not re.fullmatch(r"[A-Za-z0-9._:/-]{1,160}", candidate):
                raise ValueError("DELL_AIA_MODEL_CANDIDATES contains an invalid model name")
        return ",".join(candidates)

    @field_validator("rewards_db_schema", "rewards_db_member_table")
    @classmethod
    def validate_sql_identifier(cls, value: str) -> str:
        if not value or not value.replace("_", "").isalnum():
            raise ValueError("SQL schema/table names may contain only letters, digits, and underscores")
        return value

    @property
    def db_connection_string(self) -> str:
        if self.rewards_db_connection_string:
            return self.rewards_db_connection_string
        if all(
            [
                self.rewards_db_server,
                self.rewards_db_name,
                self.rewards_db_username,
                self.rewards_db_password,
            ]
        ):
            return (
                f"DRIVER={{{self.rewards_db_driver}}};"
                f"SERVER={self.rewards_db_server};DATABASE={self.rewards_db_name};"
                f"UID={self.rewards_db_username};PWD={self.rewards_db_password};"
                f"Encrypt={self.rewards_db_encrypt};"
                f"TrustServerCertificate={self.rewards_db_trust_server_certificate};"
            )
        if self.allow_local_db_fallback:
            return LOCAL_DB_CONNECTION_FALLBACK
        raise ValueError("Rewards DB connection configuration is missing")

    @property
    def crowd_twist_update_credentials_complete(self) -> bool:
        return bool(
            self.crowd_twist_update_base_url
            and self.crowd_twist_auth_url
            and self.crowd_twist_update_client_id
            and self.crowd_twist_update_client_secret
            and self.crowd_twist_api_key
        )

    @property
    def live_source_credentials_complete(self) -> bool:
        db_ready = bool(
            self.rewards_db_connection_string
            or all([
                self.rewards_db_server,
                self.rewards_db_name,
                self.rewards_db_username,
                self.rewards_db_password,
            ])
            or (self.allow_local_db_fallback and LOCAL_DB_CONNECTION_FALLBACK)
        )
        return bool(
            self.cps_base_url
            and self.cps_auth_url
            and self.cps_client_id
            and self.cps_client_secret
            and self.crowd_twist_base_url
            and self.crowd_twist_auth_url
            and self.crowd_twist_client_id
            and self.crowd_twist_client_secret
            and db_ready
        )


@lru_cache(maxsize=4)
def load_settings(*, bootstrap: bool = True) -> Settings:
    settings = Settings()
    if (
        not bootstrap
        or settings.use_mock_sources
        or not settings.bootstrap_from_spring_config
        or settings.live_source_credentials_complete
    ):
        return settings

    try:
        properties, source_url = fetch_spring_config(
            settings.rewards_environment,
            username=settings.spring_config_username,
            password=settings.spring_config_password,
            timeout=settings.request_timeout_seconds,
            verify_ssl=settings.spring_config_verify_ssl,
        )
        updates = map_spring_properties(properties)
        updates["spring_config_source_url"] = source_url
        updates["spring_config_error"] = ""
        return settings.model_copy(update=updates)
    except Exception as exc:
        return settings.model_copy(
            update={
                "spring_config_error": f"{type(exc).__name__}: Spring Config bootstrap failed",
            }
        )

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from typing import Any, Callable

from .country_reference import get_country_reference


@dataclass(frozen=True)
class NormalizedValue:
    value: Any
    valid: bool = True
    note: str | None = None


def is_present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str) and not value.strip():
        return False
    return True


def normalize_guid(value: Any) -> NormalizedValue:
    if not is_present(value):
        return NormalizedValue(None)
    try:
        return NormalizedValue(str(uuid.UUID(str(value).strip())).lower())
    except (ValueError, AttributeError, TypeError):
        return NormalizedValue(str(value).strip(), False, "Invalid GUID")


def normalize_email(value: Any) -> NormalizedValue:
    if not is_present(value):
        return NormalizedValue(None)
    text = str(value).strip().lower()
    valid = bool(re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", text))
    return NormalizedValue(text, valid, None if valid else "Invalid email format")


def normalize_country(value: Any) -> NormalizedValue:
    if not is_present(value):
        return NormalizedValue(None)
    match = get_country_reference().match(value)
    if match.code:
        return NormalizedValue(match.code)
    if match.kind == "broad_region":
        codes = "/".join(sorted(match.candidates))
        return NormalizedValue(
            codes,
            False,
            f"Broad CPS market/region ({codes}); an exact country must be resolved before writing CrowdTwist.",
        )
    return NormalizedValue(
        str(value).strip(),
        False,
        "Expected a country name or ISO-3166 alpha-2 code present in the CrowdTwist country reference CSV",
    )


def normalize_boolean(value: Any) -> NormalizedValue:
    if not is_present(value):
        return NormalizedValue(None)
    if isinstance(value, bool):
        return NormalizedValue(value)
    if isinstance(value, (int, float)) and value in (0, 1):
        return NormalizedValue(bool(value))
    text = str(value).strip().lower()
    truthy = {"true", "1", "yes", "y", "active", "enabled"}
    falsy = {"false", "0", "no", "n", "inactive", "disabled"}
    if text in truthy:
        return NormalizedValue(True)
    if text in falsy:
        return NormalizedValue(False)
    return NormalizedValue(text, False, "Invalid boolean")


def normalize_integer(value: Any) -> NormalizedValue:
    if not is_present(value):
        return NormalizedValue(None)
    if isinstance(value, bool):
        return NormalizedValue(str(value).strip(), False, "Invalid integer")
    try:
        if isinstance(value, int):
            return NormalizedValue(value)
        if isinstance(value, float):
            if value.is_integer():
                return NormalizedValue(int(value))
            raise ValueError
        text = str(value).strip()
        if re.fullmatch(r"[+-]?\d+", text):
            return NormalizedValue(int(text))
        if re.fullmatch(r"[+-]?\d+\.0+", text):
            return NormalizedValue(int(float(text)))
        raise ValueError
    except (ValueError, TypeError, OverflowError):
        return NormalizedValue(str(value).strip(), False, "Invalid integer")


def normalize_text_ci(value: Any) -> NormalizedValue:
    if not is_present(value):
        return NormalizedValue(None)
    return NormalizedValue(re.sub(r"\s+", " ", str(value).strip()).casefold())


def normalize_phone(value: Any) -> NormalizedValue:
    if not is_present(value):
        return NormalizedValue(None)
    text = str(value).strip()
    digits = re.sub(r"\D", "", text)
    # A leading '+' is presentation, not identity.  Compare the canonical digit
    # sequence so '+1 (512) 555-0100' and '1-512-555-0100' do not create a
    # false disparity.  We intentionally do not invent/drop country codes.
    if text.startswith("00") and digits.startswith("00"):
        digits = digits[2:]
    if not 7 <= len(digits) <= 15:
        return NormalizedValue(digits, False, "Phone should contain 7-15 digits")
    return NormalizedValue(digits)


def normalize_postal_code(value: Any) -> NormalizedValue:
    if not is_present(value):
        return NormalizedValue(None)
    text = str(value).strip()
    # Postal systems commonly vary only by whitespace/hyphen presentation
    # (e.g. M5V 1J9 vs M5V1J9, 12345-6789 vs 123456789).  Keep all
    # alphanumeric content so genuinely different codes still mismatch.
    canonical = re.sub(r"[^0-9A-Za-z]", "", text).casefold()
    if not canonical:
        return NormalizedValue(canonical, False, "Invalid postal code")
    return NormalizedValue(canonical)


NORMALIZERS: dict[str, Callable[[Any], NormalizedValue]] = {
    "guid": normalize_guid,
    "email": normalize_email,
    "country": normalize_country,
    "boolean": normalize_boolean,
    "integer": normalize_integer,
    "text_ci": normalize_text_ci,
    "phone": normalize_phone,
    "postal_code": normalize_postal_code,
}


def normalize(value: Any, data_type: str) -> NormalizedValue:
    return NORMALIZERS.get(data_type, normalize_text_ci)(value)

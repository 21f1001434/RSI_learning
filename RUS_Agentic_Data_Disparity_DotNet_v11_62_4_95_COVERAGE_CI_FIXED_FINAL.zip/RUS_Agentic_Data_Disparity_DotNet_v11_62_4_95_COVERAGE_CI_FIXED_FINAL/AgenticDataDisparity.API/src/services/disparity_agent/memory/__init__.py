"""Bounded adaptive memory for the RUS Agentic Data Disparity service.

The memory subsystem learns only execution-quality patterns. It never changes
business truth rules, role approvals, source-write permissions, endpoints, or
payload attributes.
"""
from .rsi import AdaptiveMemoryController, AdaptiveRunContext, get_adaptive_memory

__all__ = ["AdaptiveMemoryController", "AdaptiveRunContext", "get_adaptive_memory"]

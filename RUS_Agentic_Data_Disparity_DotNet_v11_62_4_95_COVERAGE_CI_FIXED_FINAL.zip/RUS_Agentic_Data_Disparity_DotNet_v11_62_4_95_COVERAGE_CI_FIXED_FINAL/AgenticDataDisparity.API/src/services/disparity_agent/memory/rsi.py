from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

from .policy import PromptStrategy, choose_model, choose_strategy, normalize_model_candidates
from .store import SQLiteAdaptiveMemoryStore


@dataclass
class AdaptiveRunContext:
    task_type: str
    task_signature: str
    strategy: PromptStrategy
    selection_mode: str
    model_name: str
    model_selection_mode: str
    replay_lessons: list[str] = field(default_factory=list)
    learned_skill: dict[str, Any] | None = None

    def public_view(self) -> dict[str, Any]:
        skill = dict(self.learned_skill or {})
        return {
            "task_type": self.task_type,
            "task_signature": self.task_signature,
            "strategy_id": self.strategy.strategy_id,
            "strategy_label": self.strategy.label,
            "selection_mode": self.selection_mode,
            "model": self.model_name,
            "model_selection_mode": self.model_selection_mode,
            "replay_lessons_used": len(self.replay_lessons),
            "learned_skill_used": bool(skill),
            "learned_skill_match": skill.get("match"),
            "learned_skill_similarity": skill.get("similarity"),
            "bounded_rsi": True,
            "bounded_model_selection": True,
            "can_modify_code": False,
            "can_modify_business_rules": False,
            "can_modify_model_allowlist": False,
            "can_bypass_approvals": False,
        }


class AdaptiveMemoryController:
    """Bounded replay memory, skill induction, and recursive policy improvement.

    RSI here means measuring outcomes and reusing the best *pre-approved* reasoning
    strategy/model route for similar evidence shapes. It never rewrites source code,
    creates tools, changes truth rules, changes APIs, modifies source-write contracts,
    edits the deployment model allow-list, or bypasses approval state machines.
    """

    def __init__(
        self,
        *,
        db_path: Path,
        enabled: bool,
        rsi_enabled: bool,
        retention_days: int,
        max_trajectories: int,
        replay_limit: int,
        min_samples: int,
        exploration_interval: int,
        latency_target_ms: int,
        default_model: str = "gpt-oss-120b",
        model_candidates: tuple[str, ...] = (),
        model_selection_enabled: bool = False,
        model_min_samples: int = 3,
        model_exploration_interval: int = 20,
        skill_min_samples: int = 3,
    ) -> None:
        self.enabled = bool(enabled)
        self.rsi_enabled = bool(rsi_enabled and enabled)
        self.replay_limit = max(0, min(10, int(replay_limit)))
        self.min_samples = max(1, int(min_samples))
        self.exploration_interval = max(0, int(exploration_interval))
        self.latency_target_ms = max(1000, int(latency_target_ms))
        self.model_candidates = normalize_model_candidates(default_model, model_candidates)
        self.model_selection_enabled = bool(model_selection_enabled and enabled and len(self.model_candidates) > 1)
        self.model_min_samples = max(1, int(model_min_samples))
        self.model_exploration_interval = max(0, int(model_exploration_interval))
        self.skill_min_samples = max(1, int(skill_min_samples))
        self.store = SQLiteAdaptiveMemoryStore(
            Path(db_path), retention_days=retention_days, max_trajectories=max_trajectories
        )
        self.last_error: str | None = None

    async def initialize(self) -> None:
        if self.enabled:
            try:
                await self.store.initialize()
                self.last_error = None
            except Exception as exc:
                # Adaptive memory must never take the deterministic disparity service down.
                self.last_error = f"{type(exc).__name__}: {exc}"

    async def begin_analysis(self, *, task_signature: str) -> AdaptiveRunContext:
        task_type = "individual_disparity_analysis"
        default_model = self.model_candidates[0]
        if not self.enabled:
            strategy, mode = choose_strategy(
                {}, total_completed=0, rsi_enabled=False, exploration_interval=0, min_samples=1
            )
            return AdaptiveRunContext(
                task_type, task_signature, strategy, mode,
                default_model, "single_model", [], None,
            )
        try:
            stats, total = await self.store.policy_stats(task_type)
            model_stats, model_total = await self.store.model_stats(task_type)
            skill = await self.store.learned_skill(
                task_type, task_signature, min_samples=self.skill_min_samples
            )
            preferred_strategy = str((skill or {}).get("strategy_id") or "") or None
            preferred_model = str((skill or {}).get("model") or "") or None
            strategy, mode = choose_strategy(
                stats,
                total_completed=total,
                rsi_enabled=self.rsi_enabled,
                exploration_interval=self.exploration_interval,
                min_samples=self.min_samples,
                preferred_strategy_id=preferred_strategy,
            )
            model_name, model_mode = choose_model(
                self.model_candidates,
                model_stats,
                total_completed=model_total,
                enabled=self.model_selection_enabled,
                min_samples=self.model_min_samples,
                exploration_interval=self.model_exploration_interval,
                preferred_model=preferred_model,
            )
            lessons = await self.store.recent_reflections(
                task_type, task_signature, limit=self.replay_limit
            )
            self.last_error = None
            return AdaptiveRunContext(
                task_type, task_signature, strategy, mode,
                model_name, model_mode, lessons, skill,
            )
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            strategy, _ = choose_strategy(
                {}, total_completed=0, rsi_enabled=False, exploration_interval=0, min_samples=1
            )
            return AdaptiveRunContext(
                task_type, task_signature, strategy, "memory_unavailable_fail_open",
                default_model, "memory_unavailable_default_model", [], None,
            )

    def score_analysis(self, report: Any) -> tuple[float, str, str]:
        mcp = dict(getattr(report, "mcp_execution", None) or {})
        ai = dict(getattr(report, "ai_execution", None) or {})
        judge = dict(getattr(report, "judge_result", None) or {})
        timings = dict(getattr(report, "timings", None) or {})
        score = 0.0
        if str(mcp.get("status") or "").upper() == "SUCCESS":
            score += 0.25
        ai_success = str(ai.get("status") or "").upper() == "SUCCESS"
        if ai_success:
            score += 0.15
        verdict = str(judge.get("verdict") or judge.get("status") or "").upper()
        if verdict == "ACCEPTED":
            score += 0.30
        elif verdict == "PARTIAL":
            score += 0.18
        elif verdict not in {"REJECTED", "FAILED", "NOT_RUN"}:
            score += 0.05
        analyst_contract = str(((ai.get("analysis_agent") or {}).get("output_contract") or {}).get("status") or "")
        judge_contract = str(((ai.get("judge_agent") or {}).get("output_contract") or {}).get("status") or "")
        score += 0.10 if analyst_contract == "DIRECT_JSON" else (0.04 if "NORMALIZED" in analyst_contract else 0.0)
        score += 0.10 if judge_contract == "DIRECT_JSON" else (0.04 if "NORMALIZED" in judge_contract else 0.0)
        latency = int(
            timings.get("end_to_end_ms")
            or timings.get("total_processing_ms")
            or timings.get("analysis_and_judge_wall_ms")
            or 0
        )
        if latency and latency <= self.latency_target_ms:
            score += 0.05
        score = max(0.0, min(1.0, round(score, 4)))
        outcome = "SUCCESS" if ai_success and verdict in {"ACCEPTED", "PARTIAL"} else "FAILED"
        lesson = self._lesson(verdict, analyst_contract, judge_contract, ai_success)
        return score, outcome, lesson

    @staticmethod
    def _lesson(verdict: str, analyst_contract: str, judge_contract: str, ai_success: bool) -> str:
        if not ai_success:
            return "Model execution failed; preserve deterministic evidence and retry only through bounded runtime retry policy."
        if verdict == "REJECTED":
            return "Judge rejected the narrative; tighten claim-to-evidence alignment and omit unsupported explanatory claims."
        if verdict == "PARTIAL":
            return "Judge corrected part of the narrative; prioritize exact deterministic findings and avoid unnecessary inference."
        if "NORMALIZED" in (analyst_contract + " " + judge_contract):
            return "One model response required local normalization; reinforce the strict JSON-only output contract."
        if verdict == "ACCEPTED":
            return "Judge accepted the evidence-grounded output; preserve this concise evidence-only reasoning pattern."
        return "Keep the response grounded in deterministic evidence and let the independent judge control publication."

    async def complete_analysis(self, report: Any, context: AdaptiveRunContext) -> dict[str, Any]:
        if not self.enabled:
            return {**context.public_view(), "recorded": False}
        score, outcome, lesson = self.score_analysis(report)
        ai = dict(getattr(report, "ai_execution", None) or {})
        mcp = dict(getattr(report, "mcp_execution", None) or {})
        judge = dict(getattr(report, "judge_result", None) or {})
        timings = dict(getattr(report, "timings", None) or {})
        source_status = getattr(report, "source_status", None) or {}
        source_profile: dict[str, str] = {}
        for key, value in source_status.items():
            name = getattr(key, "value", str(key))
            connected = bool(
                getattr(value, "connected", False) if not isinstance(value, dict) else value.get("connected")
            )
            found = bool(
                getattr(value, "data_found", False) if not isinstance(value, dict) else value.get("data_found")
            )
            source_profile[str(name)] = "found" if found else ("connected_no_record" if connected else "unavailable")
        analyst_contract = str(((ai.get("analysis_agent") or {}).get("output_contract") or {}).get("status") or "")
        judge_contract = str(((ai.get("judge_agent") or {}).get("output_contract") or {}).get("status") or "")
        record = {
            "run_id": getattr(report, "run_id", None),
            "task_type": context.task_type,
            "task_signature": context.task_signature,
            "strategy_id": context.strategy.strategy_id,
            "model": ai.get("model") or context.model_name,
            "outcome": outcome,
            "reward": score,
            "judge_verdict": judge.get("verdict") or judge.get("status"),
            "analyst_contract": analyst_contract,
            "judge_contract": judge_contract,
            "mcp_success": str(mcp.get("status") or "").upper() == "SUCCESS",
            "ai_success": str(ai.get("status") or "").upper() == "SUCCESS",
            "latency_ms": int(
                timings.get("end_to_end_ms")
                or timings.get("total_processing_ms")
                or timings.get("analysis_and_judge_wall_ms")
                or 0
            ),
            "source_profile": source_profile,
            "lesson": lesson,
            "lesson_confidence": 0.9 if str(judge.get("verdict") or "").upper() in {"ACCEPTED", "REJECTED"} else 0.8,
        }
        try:
            trajectory_id = await self.store.record_trajectory(record)
            self.last_error = None
            return {
                **context.public_view(),
                "recorded": True,
                "trajectory_id": trajectory_id,
                "reward": score,
                "outcome": outcome,
            }
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            return {
                **context.public_view(),
                "recorded": False,
                "reward": score,
                "outcome": outcome,
                "memory_status": "DEGRADED_FAIL_OPEN",
            }

    async def record_write_verification(self, event: dict[str, Any]) -> str | None:
        if not self.enabled:
            return None
        try:
            event_id = await self.store.record_write_verification(event)
            self.last_error = None
            return event_id
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            return None

    async def status(self) -> dict[str, Any]:
        if not self.enabled:
            return {
                "enabled": False,
                "rsi_enabled": False,
                "bounded_rsi": True,
                "pii_persisted": False,
            }
        try:
            status = await self.store.status()
            self.last_error = None
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            status = {"backend": "sqlite", "status": "DEGRADED_FAIL_OPEN"}
        return {
            "enabled": True,
            "rsi_enabled": self.rsi_enabled,
            "bounded_rsi": True,
            "skill_induction": True,
            "semantic_replay": "PII-free signature similarity",
            "strategy_scope": "pre-approved evidence-only prompt profiles",
            "model_selection_enabled": self.model_selection_enabled,
            "model_allowlist": list(self.model_candidates),
            "code_self_modification": False,
            "business_rule_mutation": False,
            "model_allowlist_mutation": False,
            "approval_bypass": False,
            "last_error": self.last_error,
            **status,
        }


def _parse_candidates(raw: Any) -> tuple[str, ...]:
    if isinstance(raw, (list, tuple, set)):
        return tuple(str(item).strip() for item in raw if str(item).strip())
    return tuple(part.strip() for part in str(raw or "").split(",") if part.strip())


def _controller_key(settings: Any) -> tuple[Any, ...]:
    return (
        str(settings.adaptive_memory_db_path),
        bool(settings.adaptive_memory_enabled),
        bool(settings.rsi_enabled),
        int(settings.adaptive_memory_retention_days),
        int(settings.adaptive_memory_max_trajectories),
        int(settings.adaptive_memory_replay_limit),
        int(settings.rsi_min_samples_per_strategy),
        int(settings.rsi_exploration_interval),
        int(settings.rsi_latency_target_ms),
        str(settings.dell_aia_model),
        str(getattr(settings, "dell_aia_model_candidates", "")),
        bool(getattr(settings, "adaptive_model_selection_enabled", False)),
        int(getattr(settings, "adaptive_model_min_samples", 3)),
        int(getattr(settings, "adaptive_model_exploration_interval", 20)),
        int(getattr(settings, "adaptive_skill_min_samples", 3)),
    )


@lru_cache(maxsize=8)
def _cached_controller(key: tuple[Any, ...]) -> AdaptiveMemoryController:
    (
        db_path, enabled, rsi_enabled, retention, max_trajectories, replay_limit,
        min_samples, exploration_interval, latency_target, default_model,
        raw_candidates, model_selection_enabled, model_min_samples,
        model_exploration_interval, skill_min_samples,
    ) = key
    return AdaptiveMemoryController(
        db_path=Path(db_path),
        enabled=bool(enabled),
        rsi_enabled=bool(rsi_enabled),
        retention_days=int(retention),
        max_trajectories=int(max_trajectories),
        replay_limit=int(replay_limit),
        min_samples=int(min_samples),
        exploration_interval=int(exploration_interval),
        latency_target_ms=int(latency_target),
        default_model=str(default_model),
        model_candidates=_parse_candidates(raw_candidates),
        model_selection_enabled=bool(model_selection_enabled),
        model_min_samples=int(model_min_samples),
        model_exploration_interval=int(model_exploration_interval),
        skill_min_samples=int(skill_min_samples),
    )


def get_adaptive_memory(settings: Any) -> AdaptiveMemoryController:
    return _cached_controller(_controller_key(settings))

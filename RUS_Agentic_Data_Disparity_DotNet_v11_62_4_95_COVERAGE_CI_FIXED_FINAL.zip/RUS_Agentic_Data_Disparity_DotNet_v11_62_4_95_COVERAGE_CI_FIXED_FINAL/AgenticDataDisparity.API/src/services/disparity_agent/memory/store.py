from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


MEMORY_SCHEMA_VERSION = 2


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _signature_similarity(left: str, right: str) -> float:
    """Jaccard similarity over the PII-free execution signature tokens."""
    a = {part for part in str(left or "").lower().split("|") if part}
    b = {part for part in str(right or "").lower().split("|") if part}
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


class SQLiteAdaptiveMemoryStore:
    """PII-minimized persistent execution memory.

    Raw member identifiers, source values, chat text, secrets, and payloads are
    intentionally not stored. The database keeps only generic run signatures,
    bounded strategy/model IDs, objective outcome metrics, generic lessons,
    write-verification telemetry, and learned skill statistics.
    """

    def __init__(self, path: Path, *, retention_days: int = 30, max_trajectories: int = 5000) -> None:
        self.path = Path(path)
        self.retention_days = max(1, int(retention_days))
        self.max_trajectories = max(100, int(max_trajectories))
        self._lock = threading.RLock()
        self._initialized = False

    async def initialize(self) -> None:
        await asyncio.to_thread(self._initialize_sync)

    def _connect(self) -> sqlite3.Connection:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.path, timeout=10.0)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=10000")
        return connection

    def _initialize_sync(self) -> None:
        with self._lock:
            if self._initialized:
                return
            with self._connect() as db:
                db.executescript(
                    """
                    CREATE TABLE IF NOT EXISTS trajectories (
                        trajectory_id TEXT PRIMARY KEY,
                        created_at TEXT NOT NULL,
                        run_id TEXT,
                        task_type TEXT NOT NULL,
                        task_signature TEXT NOT NULL,
                        strategy_id TEXT NOT NULL,
                        model TEXT,
                        outcome TEXT NOT NULL,
                        reward REAL NOT NULL,
                        judge_verdict TEXT,
                        analyst_contract TEXT,
                        judge_contract TEXT,
                        mcp_success INTEGER NOT NULL DEFAULT 0,
                        ai_success INTEGER NOT NULL DEFAULT 0,
                        latency_ms INTEGER,
                        source_profile TEXT,
                        lesson TEXT
                    );
                    CREATE INDEX IF NOT EXISTS ix_trajectories_task_created
                        ON trajectories(task_type, created_at DESC);
                    CREATE INDEX IF NOT EXISTS ix_trajectories_strategy
                        ON trajectories(strategy_id, created_at DESC);
                    CREATE INDEX IF NOT EXISTS ix_trajectories_model
                        ON trajectories(model, created_at DESC);
                    CREATE INDEX IF NOT EXISTS ix_trajectories_signature
                        ON trajectories(task_type, task_signature, created_at DESC);

                    CREATE TABLE IF NOT EXISTS policy_stats (
                        task_type TEXT NOT NULL,
                        strategy_id TEXT NOT NULL,
                        attempts INTEGER NOT NULL DEFAULT 0,
                        successes INTEGER NOT NULL DEFAULT 0,
                        accepted INTEGER NOT NULL DEFAULT 0,
                        partial INTEGER NOT NULL DEFAULT 0,
                        rejected INTEGER NOT NULL DEFAULT 0,
                        normalized_outputs INTEGER NOT NULL DEFAULT 0,
                        total_score REAL NOT NULL DEFAULT 0,
                        avg_score REAL NOT NULL DEFAULT 0,
                        last_score REAL,
                        last_used_at TEXT,
                        PRIMARY KEY(task_type, strategy_id)
                    );

                    CREATE TABLE IF NOT EXISTS reflections (
                        reflection_id TEXT PRIMARY KEY,
                        created_at TEXT NOT NULL,
                        task_type TEXT NOT NULL,
                        task_signature TEXT NOT NULL,
                        strategy_id TEXT NOT NULL,
                        lesson TEXT NOT NULL,
                        confidence REAL NOT NULL
                    );
                    CREATE INDEX IF NOT EXISTS ix_reflections_task_created
                        ON reflections(task_type, created_at DESC);

                    CREATE TABLE IF NOT EXISTS skill_stats (
                        task_type TEXT NOT NULL,
                        task_signature TEXT NOT NULL,
                        strategy_id TEXT NOT NULL,
                        model TEXT NOT NULL DEFAULT '',
                        attempts INTEGER NOT NULL DEFAULT 0,
                        successes INTEGER NOT NULL DEFAULT 0,
                        total_reward REAL NOT NULL DEFAULT 0,
                        avg_reward REAL NOT NULL DEFAULT 0,
                        last_reward REAL,
                        last_used_at TEXT,
                        PRIMARY KEY(task_type, task_signature, strategy_id, model)
                    );
                    CREATE INDEX IF NOT EXISTS ix_skill_signature
                        ON skill_stats(task_type, task_signature, avg_reward DESC);

                    CREATE TABLE IF NOT EXISTS write_verifications (
                        event_id TEXT PRIMARY KEY,
                        created_at TEXT NOT NULL,
                        source TEXT NOT NULL,
                        field_name TEXT,
                        status TEXT NOT NULL,
                        verified INTEGER NOT NULL DEFAULT 0,
                        dry_run INTEGER NOT NULL DEFAULT 0,
                        role TEXT,
                        duration_ms INTEGER
                    );
                    """
                )
                db.execute(f"PRAGMA user_version={MEMORY_SCHEMA_VERSION}")
                self._prune_sync(db)
            self._initialized = True

    async def policy_stats(self, task_type: str) -> tuple[dict[str, dict[str, Any]], int]:
        await self.initialize()
        return await asyncio.to_thread(self._policy_stats_sync, task_type)

    def _policy_stats_sync(self, task_type: str) -> tuple[dict[str, dict[str, Any]], int]:
        with self._lock, self._connect() as db:
            rows = db.execute("SELECT * FROM policy_stats WHERE task_type=?", (task_type,)).fetchall()
            total = db.execute("SELECT COUNT(*) FROM trajectories WHERE task_type=?", (task_type,)).fetchone()[0]
        return {str(row["strategy_id"]): dict(row) for row in rows}, int(total or 0)

    async def model_stats(self, task_type: str) -> tuple[dict[str, dict[str, Any]], int]:
        await self.initialize()
        return await asyncio.to_thread(self._model_stats_sync, task_type)

    def _model_stats_sync(self, task_type: str) -> tuple[dict[str, dict[str, Any]], int]:
        with self._lock, self._connect() as db:
            rows = db.execute(
                """
                SELECT COALESCE(model,'') AS model,
                       COUNT(*) AS attempts,
                       SUM(CASE WHEN outcome='SUCCESS' THEN 1 ELSE 0 END) AS successes,
                       AVG(reward) AS avg_score,
                       MAX(created_at) AS last_used_at
                FROM trajectories
                WHERE task_type=? AND COALESCE(model,'') <> ''
                GROUP BY COALESCE(model,'')
                """,
                (task_type,),
            ).fetchall()
            total = db.execute("SELECT COUNT(*) FROM trajectories WHERE task_type=?", (task_type,)).fetchone()[0]
        return {str(row["model"]): dict(row) for row in rows}, int(total or 0)

    async def learned_skill(self, task_type: str, task_signature: str, *, min_samples: int = 3) -> dict[str, Any] | None:
        await self.initialize()
        return await asyncio.to_thread(self._learned_skill_sync, task_type, task_signature, min_samples)

    def _learned_skill_sync(self, task_type: str, task_signature: str, min_samples: int) -> dict[str, Any] | None:
        with self._lock, self._connect() as db:
            exact = db.execute(
                """
                SELECT * FROM skill_stats
                WHERE task_type=? AND task_signature=? AND attempts>=?
                ORDER BY avg_reward DESC, successes DESC, attempts DESC, last_used_at DESC
                LIMIT 1
                """,
                (task_type, task_signature, max(1, int(min_samples))),
            ).fetchone()
            if exact:
                return {**dict(exact), "match": "exact", "similarity": 1.0}

            rows = db.execute(
                """
                SELECT * FROM skill_stats
                WHERE task_type=? AND attempts>=?
                ORDER BY last_used_at DESC
                LIMIT 200
                """,
                (task_type, max(1, int(min_samples))),
            ).fetchall()
        ranked: list[tuple[float, float, int, sqlite3.Row]] = []
        for row in rows:
            similarity = _signature_similarity(task_signature, str(row["task_signature"] or ""))
            if similarity >= 0.60:
                ranked.append((similarity, float(row["avg_reward"] or 0.0), int(row["attempts"] or 0), row))
        if not ranked:
            return None
        similarity, _, _, row = max(ranked, key=lambda item: (item[0], item[1], item[2]))
        return {**dict(row), "match": "similar", "similarity": round(similarity, 4)}

    async def recent_reflections(self, task_type: str, task_signature: str, *, limit: int = 3) -> list[str]:
        await self.initialize()
        return await asyncio.to_thread(self._recent_reflections_sync, task_type, task_signature, limit)

    def _recent_reflections_sync(self, task_type: str, task_signature: str, limit: int) -> list[str]:
        wanted = max(0, min(10, int(limit)))
        if wanted == 0:
            return []
        with self._lock, self._connect() as db:
            rows = db.execute(
                """
                SELECT lesson, task_signature, confidence, created_at
                FROM reflections
                WHERE task_type=?
                ORDER BY created_at DESC
                LIMIT 200
                """,
                (task_type,),
            ).fetchall()
        ranked: list[tuple[int, float, float, str, str]] = []
        for row in rows:
            signature = str(row["task_signature"] or "")
            similarity = _signature_similarity(task_signature, signature)
            exact = int(signature == task_signature)
            confidence = float(row["confidence"] or 0.0)
            # Exact lessons are strongest. Similar lessons require meaningful shape
            # overlap. Generic high-confidence lessons are allowed only as a final
            # fallback and never carry member/source values.
            if not exact and similarity < 0.45 and confidence < 0.90:
                continue
            ranked.append((exact, similarity, confidence, str(row["created_at"]), str(row["lesson"] or "")))
        ranked.sort(reverse=True)
        lessons: list[str] = []
        for _, _, _, _, lesson in ranked:
            lesson = lesson.strip()
            if lesson and lesson not in lessons:
                lessons.append(lesson)
            if len(lessons) >= wanted:
                break
        return lessons

    async def record_trajectory(self, record: dict[str, Any]) -> str:
        await self.initialize()
        return await asyncio.to_thread(self._record_trajectory_sync, record)

    def _record_trajectory_sync(self, record: dict[str, Any]) -> str:
        trajectory_id = str(record.get("trajectory_id") or "TRJ-" + uuid.uuid4().hex.upper())
        created_at = str(record.get("created_at") or utc_now_iso())
        task_type = str(record.get("task_type") or "analysis")
        task_signature = str(record.get("task_signature") or "generic")
        strategy_id = str(record.get("strategy_id") or "grounded_baseline")
        model = str(record.get("model") or "")
        reward = max(0.0, min(1.0, float(record.get("reward") or 0.0)))
        verdict = str(record.get("judge_verdict") or "").upper()
        analyst_contract = str(record.get("analyst_contract") or "")
        judge_contract = str(record.get("judge_contract") or "")
        outcome = str(record.get("outcome") or "UNKNOWN").upper()
        lesson = str(record.get("lesson") or "").strip()[:1000]
        normalized = int("NORMALIZED" in (analyst_contract + " " + judge_contract).upper())
        success = int(outcome in {"SUCCESS", "ACCEPTED", "PARTIAL"})
        with self._lock, self._connect() as db:
            # Memory writes are idempotent by trajectory_id. A retry after an
            # upstream timeout must not double-count policy/model/skill reward.
            if db.execute("SELECT 1 FROM trajectories WHERE trajectory_id=?", (trajectory_id,)).fetchone():
                return trajectory_id
            db.execute(
                """
                INSERT INTO trajectories(
                    trajectory_id,created_at,run_id,task_type,task_signature,strategy_id,
                    model,outcome,reward,judge_verdict,analyst_contract,judge_contract,
                    mcp_success,ai_success,latency_ms,source_profile,lesson
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    trajectory_id, created_at, str(record.get("run_id") or "") or None,
                    task_type, task_signature, strategy_id, model or None, outcome, reward, verdict or None,
                    analyst_contract or None, judge_contract or None,
                    int(bool(record.get("mcp_success"))), int(bool(record.get("ai_success"))),
                    int(record.get("latency_ms") or 0),
                    json.dumps(record.get("source_profile") or {}, sort_keys=True, separators=(",", ":")),
                    lesson or None,
                ),
            )
            existing = db.execute(
                "SELECT * FROM policy_stats WHERE task_type=? AND strategy_id=?",
                (task_type, strategy_id),
            ).fetchone()
            attempts = int(existing["attempts"] if existing else 0) + 1
            total_score = float(existing["total_score"] if existing else 0.0) + reward
            db.execute(
                """
                INSERT INTO policy_stats(
                    task_type,strategy_id,attempts,successes,accepted,partial,rejected,
                    normalized_outputs,total_score,avg_score,last_score,last_used_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(task_type,strategy_id) DO UPDATE SET
                    attempts=excluded.attempts, successes=excluded.successes,
                    accepted=excluded.accepted, partial=excluded.partial, rejected=excluded.rejected,
                    normalized_outputs=excluded.normalized_outputs, total_score=excluded.total_score,
                    avg_score=excluded.avg_score, last_score=excluded.last_score,
                    last_used_at=excluded.last_used_at
                """,
                (
                    task_type, strategy_id, attempts,
                    int(existing["successes"] if existing else 0) + success,
                    int(existing["accepted"] if existing else 0) + int(verdict == "ACCEPTED"),
                    int(existing["partial"] if existing else 0) + int(verdict == "PARTIAL"),
                    int(existing["rejected"] if existing else 0) + int(verdict == "REJECTED"),
                    int(existing["normalized_outputs"] if existing else 0) + normalized,
                    total_score, total_score / attempts, reward, created_at,
                ),
            )

            skill = db.execute(
                """
                SELECT * FROM skill_stats
                WHERE task_type=? AND task_signature=? AND strategy_id=? AND model=?
                """,
                (task_type, task_signature, strategy_id, model),
            ).fetchone()
            skill_attempts = int(skill["attempts"] if skill else 0) + 1
            skill_total = float(skill["total_reward"] if skill else 0.0) + reward
            db.execute(
                """
                INSERT INTO skill_stats(
                    task_type,task_signature,strategy_id,model,attempts,successes,
                    total_reward,avg_reward,last_reward,last_used_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(task_type,task_signature,strategy_id,model) DO UPDATE SET
                    attempts=excluded.attempts, successes=excluded.successes,
                    total_reward=excluded.total_reward, avg_reward=excluded.avg_reward,
                    last_reward=excluded.last_reward, last_used_at=excluded.last_used_at
                """,
                (
                    task_type, task_signature, strategy_id, model,
                    skill_attempts, int(skill["successes"] if skill else 0) + success,
                    skill_total, skill_total / skill_attempts, reward, created_at,
                ),
            )

            if lesson:
                db.execute(
                    """INSERT INTO reflections(reflection_id,created_at,task_type,task_signature,strategy_id,lesson,confidence)
                       VALUES(?,?,?,?,?,?,?)""",
                    (
                        "RFL-" + uuid.uuid4().hex.upper(), created_at, task_type,
                        task_signature, strategy_id, lesson,
                        max(0.0, min(1.0, float(record.get("lesson_confidence") or 0.8))),
                    ),
                )
            self._prune_sync(db)
        return trajectory_id

    def _prune_sync(self, db: sqlite3.Connection) -> None:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=self.retention_days)).isoformat()
        db.execute("DELETE FROM trajectories WHERE created_at < ?", (cutoff,))
        db.execute("DELETE FROM reflections WHERE created_at < ?", (cutoff,))
        db.execute("DELETE FROM write_verifications WHERE created_at < ?", (cutoff,))
        # skill_stats are aggregates. Remove entries not used within retention so stale
        # learned preferences cannot survive forever after supporting trajectories expire.
        db.execute("DELETE FROM skill_stats WHERE COALESCE(last_used_at,'') < ?", (cutoff,))
        count = int(db.execute("SELECT COUNT(*) FROM trajectories").fetchone()[0] or 0)
        overflow = count - self.max_trajectories
        if overflow > 0:
            db.execute(
                "DELETE FROM trajectories WHERE trajectory_id IN (SELECT trajectory_id FROM trajectories ORDER BY created_at ASC LIMIT ?)",
                (overflow,),
            )
        reflection_count = int(db.execute("SELECT COUNT(*) FROM reflections").fetchone()[0] or 0)
        if reflection_count > self.max_trajectories:
            db.execute(
                "DELETE FROM reflections WHERE reflection_id IN (SELECT reflection_id FROM reflections ORDER BY created_at ASC LIMIT ?)",
                (reflection_count - self.max_trajectories,),
            )
        write_count = int(db.execute("SELECT COUNT(*) FROM write_verifications").fetchone()[0] or 0)
        if write_count > self.max_trajectories:
            db.execute(
                "DELETE FROM write_verifications WHERE event_id IN (SELECT event_id FROM write_verifications ORDER BY created_at ASC LIMIT ?)",
                (write_count - self.max_trajectories,),
            )

    async def record_write_verification(self, event: dict[str, Any]) -> str:
        await self.initialize()
        return await asyncio.to_thread(self._record_write_verification_sync, event)

    def _record_write_verification_sync(self, event: dict[str, Any]) -> str:
        event_id = "WVF-" + uuid.uuid4().hex.upper()
        with self._lock, self._connect() as db:
            db.execute(
                """INSERT INTO write_verifications(event_id,created_at,source,field_name,status,verified,dry_run,role,duration_ms)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    event_id, utc_now_iso(), str(event.get("source") or "unknown")[:80],
                    str(event.get("field_name") or "")[:120] or None,
                    str(event.get("status") or "UNKNOWN")[:40].upper(),
                    int(bool(event.get("verified"))), int(bool(event.get("dry_run"))),
                    str(event.get("role") or "")[:80] or None,
                    int(event.get("duration_ms") or 0),
                ),
            )
            self._prune_sync(db)
        return event_id

    async def status(self) -> dict[str, Any]:
        await self.initialize()
        return await asyncio.to_thread(self._status_sync)

    def _status_sync(self) -> dict[str, Any]:
        with self._lock, self._connect() as db:
            trajectories = int(db.execute("SELECT COUNT(*) FROM trajectories").fetchone()[0] or 0)
            reflections = int(db.execute("SELECT COUNT(*) FROM reflections").fetchone()[0] or 0)
            writes = int(db.execute("SELECT COUNT(*) FROM write_verifications").fetchone()[0] or 0)
            skills = int(db.execute("SELECT COUNT(*) FROM skill_stats").fetchone()[0] or 0)
            latest = db.execute("SELECT MAX(created_at) FROM trajectories").fetchone()[0]
            schema_version = int(db.execute("PRAGMA user_version").fetchone()[0] or 0)
            strategy_rows = db.execute(
                "SELECT task_type,strategy_id,attempts,avg_score,last_score,last_used_at FROM policy_stats ORDER BY task_type,strategy_id"
            ).fetchall()
            model_rows = db.execute(
                """
                SELECT COALESCE(model,'unknown') AS model, COUNT(*) AS runs,
                       ROUND(AVG(reward),4) AS avg_reward,
                       SUM(CASE WHEN judge_verdict='ACCEPTED' THEN 1 ELSE 0 END) AS accepted,
                       SUM(CASE WHEN judge_verdict='PARTIAL' THEN 1 ELSE 0 END) AS partial,
                       SUM(CASE WHEN judge_verdict='REJECTED' THEN 1 ELSE 0 END) AS rejected,
                       ROUND(AVG(CASE WHEN latency_ms > 0 THEN latency_ms END),0) AS avg_latency_ms
                FROM trajectories GROUP BY COALESCE(model,'unknown') ORDER BY runs DESC, model
                """
            ).fetchall()
            skill_rows = db.execute(
                """
                SELECT task_type,task_signature,strategy_id,model,attempts,successes,
                       ROUND(avg_reward,4) AS avg_reward,last_used_at
                FROM skill_stats ORDER BY avg_reward DESC,attempts DESC,last_used_at DESC LIMIT 25
                """
            ).fetchall()
        return {
            "backend": "sqlite",
            "database": self.path.name,
            "schema_version": schema_version,
            "pii_persisted": False,
            "trajectories": trajectories,
            "reflections": reflections,
            "learned_skills": skills,
            "write_verifications": writes,
            "latest_trajectory_at": latest,
            "retention_days": self.retention_days,
            "max_trajectories": self.max_trajectories,
            "policy_stats": [dict(row) for row in strategy_rows],
            "model_performance": [dict(row) for row in model_rows],
            "top_skills": [dict(row) for row in skill_rows],
        }

from __future__ import annotations

from typing import Iterable, Mapping

from .country_reference import get_country_reference
from .models import AttributeVerdict, CorrectionSuggestion, SourceName, SourceRecord


def _source_label(source: SourceName | None) -> str:
    if source is None:
        return "authoritative source"
    labels = {
        SourceName.CPS: "CPS",
        SourceName.REWARDS_DB: "Rewards DB",
        SourceName.CROWD_TWIST: "CrowdTwist",
    }
    return labels[source]


def build_correction_suggestions(
    verdicts: Iterable[AttributeVerdict],
    records: Mapping[SourceName, SourceRecord] | None = None,
) -> list[CorrectionSuggestion]:
    """Build deterministic, read-only correction guidance from attribute verdicts.

    Special business policies are applied before the generic CPS/DB policy:
    * CrowdTwist ID: CrowdTwist API is truth; fix Rewards DB.
    * Active Status: OR gate across Rewards DB and CrowdTwist; change False to True.
    * Country: CPS is truth whenever present. Rewards DB may only resolve an
      exact country within a CPS-approved broad region; CrowdTwist stores the ISO
      code from the uploaded country reference CSV.
    """

    suggestions: list[CorrectionSuggestion] = []
    records = records or {}
    unavailable_record_sources = {
        source
        for source, record in records.items()
        if not record.status.data_found
    }

    def add(**kwargs) -> None:
        suggestions.append(
            CorrectionSuggestion(
                suggestion_id=f"SUG-{len(suggestions) + 1:03d}",
                **kwargs,
            )
        )

    # Record-level availability is evaluated before attribute-level corrections.
    # A missing source record must never be translated into multiple field updates.
    for source in (SourceName.CPS, SourceName.REWARDS_DB, SourceName.CROWD_TWIST):
        record = records.get(source)
        if record is None or record.status.data_found:
            continue
        connected = bool(record.status.connected)
        truth_source = (
            SourceName.CPS
            if source != SourceName.CPS and records.get(SourceName.CPS) and records[SourceName.CPS].status.data_found
            else (
                SourceName.REWARDS_DB
                if source != SourceName.REWARDS_DB and records.get(SourceName.REWARDS_DB) and records[SourceName.REWARDS_DB].status.data_found
                else None
            )
        )
        if not connected:
            add(
                attribute=f"{source.value}_record",
                label=f"{_source_label(source)} Member Record",
                action="RESTORE_SOURCE_ACCESS",
                scope="RECORD",
                target_source=source,
                current_value=None,
                recommended_value=None,
                truth_source=truth_source,
                priority="CRITICAL",
                confidence="HIGH",
                automation_eligible=False,
                requires_manual_review=True,
                reason=(
                    f"{_source_label(source)} could not be reached or rejected the request. Attribute-level absence cannot be "
                    "classified until source access is restored."
                ),
                recommendation=(
                    f"Restore connectivity/authentication for {_source_label(source)}, verify the member lookup, and re-run. "
                    "Do not create field-level corrections from an unavailable source."
                ),
            )
            continue

        if source == SourceName.REWARDS_DB:
            recommendation = (
                "The Rewards DB connection succeeded, but no member row matched the resolved Profile ID or CrowdTwist ID. "
                "Treat this as a missing member/enrollment record—not as separate missing Profile ID, Country, Active Status, "
                "or CrowdTwist ID fields. Verify Rewards eligibility, enrollment, and the CPS-to-Rewards synchronization process. "
                "The current API catalog exposes lookup/update operations but no approved member-row create/insert operation, "
                "so no SQL update should be generated until the record exists."
            )
        elif source == SourceName.CROWD_TWIST:
            recommendation = (
                "CrowdTwist was reached, but no user matched the identifier. Treat this as a missing/onboarding or identity-linkage "
                "record—not as separate missing Profile ID, Email, Country, Name, Active Status, or CrowdTwist ID fields. Verify the "
                "member's CrowdTwist enrollment and third_party_id linkage through the approved business process. The known catalog "
                "contains search/update operations but no verified CrowdTwist create-user operation, so field updates are blocked."
            )
        else:
            recommendation = (
                "CPS was reached, but no account matched the identifier. Verify the authoritative CPS account and identity resolution. "
                "Do not use Rewards DB or CrowdTwist values to fabricate a CPS record. The known CPS create operation is catalog-only "
                "and remains approval-gated until its external contract is verified."
            )
        add(
            attribute=f"{source.value}_record",
            label=f"{_source_label(source)} Member Record",
            action="RESOLVE_MISSING_MEMBER_RECORD",
            scope="RECORD",
            target_source=source,
            current_value=None,
            recommended_value=None,
            truth_source=truth_source,
            priority="CRITICAL",
            confidence="HIGH",
            automation_eligible=False,
            requires_manual_review=True,
            reason=(
                f"{_source_label(source)} connected successfully but returned no matching member record. "
                "Field-level updates require an existing target record."
            ),
            recommendation=recommendation,
        )

    for verdict in verdicts:
        # Record-level findings above own the remediation when an entire source
        # record is absent. Do not emit one misleading update per missing field.
        if verdict.status in {"SOURCE_RECORD_MISSING", "SOURCE_UNAVAILABLE"}:
            continue

        truth_source = verdict.truth_source
        truth_observation = verdict.observations.get(truth_source) if truth_source else None
        truth_is_valid = bool(
            truth_observation
            and truth_observation.present
            and truth_observation.valid_format
        )

        # Business exception 1: the CrowdTwist API owns CrowdTwist ID.
        if verdict.attribute == "crowd_twist_id":
            ct_observation = verdict.observations[SourceName.CROWD_TWIST]
            db_observation = verdict.observations[SourceName.REWARDS_DB]
            if SourceName.CROWD_TWIST in unavailable_record_sources or SourceName.REWARDS_DB in unavailable_record_sources:
                continue
            if verdict.status in {"MISMATCH", "INVALID_FORMAT", "MISSING"} and ct_observation.present and ct_observation.valid_format:
                action = "POPULATE_CROWD_TWIST_ID" if not db_observation.present else "UPDATE_REWARDS_CROWD_TWIST_ID"
                add(
                    attribute=verdict.attribute,
                    label=verdict.label,
                    action=action,
                    target_source=SourceName.REWARDS_DB,
                    current_value=db_observation.raw_value,
                    recommended_value=ct_observation.raw_value,
                    truth_source=SourceName.CROWD_TWIST,
                    priority="CRITICAL",
                    confidence="HIGH",
                    automation_eligible=True,
                    requires_manual_review=False,
                    reason=(
                        "The field is CrowdTwist ID, so the member ID returned by the CrowdTwist API is the source of truth. "
                        "Rewards DB stores only the synchronized reference."
                    ),
                    recommendation=(
                        f"Change CrowdTwist ID in Rewards DB from {db_observation.raw_value!r} "
                        f"to {ct_observation.raw_value!r}. Do not change the CrowdTwist API record for this mismatch."
                    ),
                )
            elif verdict.status in {"TRUTH_FORMAT_INVALID", "UNVERIFIABLE"}:
                add(
                    attribute=verdict.attribute,
                    label=verdict.label,
                    action="REVIEW_CROWD_TWIST_ID",
                    target_source=SourceName.CROWD_TWIST,
                    current_value=ct_observation.raw_value,
                    recommended_value=None,
                    truth_source=SourceName.CROWD_TWIST if ct_observation.present else None,
                    priority="CRITICAL",
                    confidence="HIGH",
                    automation_eligible=False,
                    requires_manual_review=True,
                    reason="CrowdTwist did not return a valid authoritative member ID.",
                    recommendation=(
                        "Verify the CrowdTwist member record and its API ID first; then re-run the check before changing Rewards DB."
                    ),
                )
            continue

        # Business exception 2: Active Status follows an OR gate.
        if verdict.attribute == "is_active":
            if SourceName.REWARDS_DB in unavailable_record_sources or SourceName.CROWD_TWIST in unavailable_record_sources:
                continue
            if verdict.status == "MISMATCH" and verdict.truth_value is True:
                for target_source in verdict.wrong_sources:
                    target_observation = verdict.observations[target_source]
                    add(
                        attribute=verdict.attribute,
                        label=verdict.label,
                        action="SET_ACTIVE_TRUE_OR_GATE",
                        target_source=target_source,
                        current_value=target_observation.raw_value,
                        recommended_value=True,
                        truth_source=truth_source,
                        priority="HIGH",
                        confidence="HIGH",
                        automation_eligible=True,
                        requires_manual_review=False,
                        reason=(
                            "Active Status uses OR semantics across Rewards DB and CrowdTwist. "
                            "Because at least one valid source is True, the synchronized result must be True."
                        ),
                        recommendation=(
                            f"Change Active Status in {_source_label(target_source)} from "
                            f"{target_observation.raw_value!r} to True. Both False is valid and both True is valid; "
                            "only a False/True mismatch requires changing the False side."
                        ),
                    )
            elif verdict.status in {"MISSING", "INVALID_FORMAT", "BOOLEAN_REVIEW_REQUIRED"}:
                add(
                    attribute=verdict.attribute,
                    label=verdict.label,
                    action="REVIEW_ACTIVE_OR_GATE",
                    target_source=None,
                    current_value=None,
                    recommended_value=None,
                    truth_source=truth_source,
                    priority="HIGH",
                    confidence="HIGH",
                    automation_eligible=False,
                    requires_manual_review=True,
                    reason="The Active Status OR rule cannot be applied automatically because a value is missing or invalid.",
                    recommendation=(
                        "Validate both Rewards DB IsActive and CrowdTwist is_active. After both are valid, apply OR logic: "
                        "False/False remains False; True/True remains True; False/True changes the False side to True."
                    ),
                )
            continue

        # Business exception 3: country writes target CrowdTwist and use the CSV ISO code.
        if verdict.attribute == "country":
            ref = get_country_reference()
            expected_code = str(verdict.truth_value or "").upper() if verdict.truth_value is not None else None
            expected_valid = bool(expected_code and ref.contains_code(expected_code))
            ct_observation = verdict.observations[SourceName.CROWD_TWIST]
            db_observation = verdict.observations[SourceName.REWARDS_DB]

            if expected_valid and SourceName.CROWD_TWIST not in unavailable_record_sources and (
                SourceName.CROWD_TWIST in verdict.wrong_sources
                or SourceName.CROWD_TWIST in verdict.missing_sources
            ):
                name = ref.country_name(expected_code)
                cps_observation = verdict.observations[SourceName.CPS]
                cps_match = ref.match(cps_observation.raw_value) if cps_observation.present else ref.match(None)
                action = "POPULATE_CROWD_TWIST_COUNTRY_CODE" if not ct_observation.present else "UPDATE_CROWD_TWIST_COUNTRY_CODE"
                if truth_source == SourceName.CPS and cps_match.kind == "broad_region":
                    resolution_reason = (
                        f"CPS is the source of truth for Country. CPS region {cps_observation.raw_value!r} allows "
                        f"{sorted(cps_match.candidates)}; Rewards DB is used only to disambiguate {expected_code} "
                        "inside that CPS-approved region and does not become the truth source."
                    )
                elif truth_source == SourceName.CPS:
                    resolution_reason = (
                        f"CPS is the source of truth for Country and resolves directly to ISO code {expected_code}."
                    )
                else:
                    resolution_reason = (
                        f"CPS does not provide Country, so Rewards DB is the approved fallback and resolves to "
                        f"ISO code {expected_code}."
                    )
                add(
                    attribute=verdict.attribute,
                    label=verdict.label,
                    action=action,
                    target_source=SourceName.CROWD_TWIST,
                    current_value=ct_observation.raw_value,
                    recommended_value=expected_code,
                    truth_source=truth_source,
                    priority="HIGH",
                    confidence="HIGH",
                    automation_eligible=True,
                    requires_manual_review=False,
                    reason=(
                        f"{resolution_reason} The uploaded CrowdTwist country reference requires the canonical "
                        f"two-letter code {expected_code} ({name or 'country name unavailable'})."
                    ),
                    recommendation=(
                        f"Change Country in CrowdTwist from {ct_observation.raw_value!r} to ISO code {expected_code!r} "
                        f"({name or 'country name unavailable'}). Keep CPS unchanged. Rewards DB is supporting resolver "
                        "evidence only when CPS contains a broad region."
                    ),
                )

            if expected_valid and SourceName.REWARDS_DB in verdict.wrong_sources:
                add(
                    attribute=verdict.attribute,
                    label=verdict.label,
                    action="REVIEW_REWARDS_COUNTRY_CONFLICT",
                    target_source=SourceName.REWARDS_DB,
                    current_value=db_observation.raw_value,
                    recommended_value=None,
                    truth_source=truth_source,
                    priority="CRITICAL",
                    confidence="HIGH",
                    automation_eligible=False,
                    requires_manual_review=True,
                    reason=(
                        "CPS and Rewards DB country evidence conflict. The CrowdTwist code can follow exact CPS truth, "
                        "but Rewards DB must be reviewed separately rather than overwritten automatically."
                    ),
                    recommendation=(
                        "Verify the member's country in CPS and Rewards DB, correct the authoritative data owner under approval, "
                        "then re-run the disparity check."
                    ),
                )

            if verdict.status in {"TRUTH_FORMAT_INVALID", "COUNTRY_REVIEW_REQUIRED", "COUNTRY_SOURCE_CONFLICT"} and not expected_valid:
                target = truth_source
                current = verdict.observations[target].raw_value if target else None
                review_action = "REVIEW_AUTHORITATIVE_VALUE" if verdict.status == "TRUTH_FORMAT_INVALID" else "REVIEW_COUNTRY_RESOLUTION"
                add(
                    attribute=verdict.attribute,
                    label=verdict.label,
                    action=review_action,
                    target_source=target,
                    current_value=current,
                    recommended_value=None,
                    truth_source=truth_source,
                    priority="CRITICAL",
                    confidence="HIGH",
                    automation_eligible=False,
                    requires_manual_review=True,
                    reason=verdict.explanation,
                    recommendation=(
                        "Resolve an exact country under CPS authority that maps to the uploaded CrowdTwist country reference CSV. "
                        "Do not change CrowdTwist until a single ISO code is supported."
                    ),
                )
            continue

        if verdict.status in {"MISMATCH", "INVALID_FORMAT"} and truth_is_valid:
            for target_source in verdict.wrong_sources:
                target_observation = verdict.observations[target_source]
                action = "REPLACE_INVALID_VALUE" if not target_observation.valid_format else "UPDATE_VALUE"
                add(
                    attribute=verdict.attribute,
                    label=verdict.label,
                    action=action,
                    target_source=target_source,
                    current_value=target_observation.raw_value,
                    recommended_value=verdict.truth_value,
                    truth_source=truth_source,
                    priority="HIGH",
                    confidence="HIGH",
                    automation_eligible=True,
                    requires_manual_review=False,
                    reason=(
                        f"{_source_label(truth_source)} is the authoritative source for {verdict.label}, "
                        f"and {_source_label(target_source)} differs from its normalized value."
                    ),
                    recommendation=(
                        f"Change {verdict.label} in {_source_label(target_source)} from "
                        f"{target_observation.raw_value!r} to {verdict.truth_value!r}. "
                        "Re-run the disparity check after the approved update."
                    ),
                )
            continue

        if verdict.status == "MISSING" and truth_is_valid:
            for target_source in verdict.missing_sources:
                if target_source in unavailable_record_sources:
                    continue
                add(
                    attribute=verdict.attribute,
                    label=verdict.label,
                    action="POPULATE_MISSING_VALUE",
                    target_source=target_source,
                    current_value=None,
                    recommended_value=verdict.truth_value,
                    truth_source=truth_source,
                    priority="MEDIUM",
                    confidence="HIGH",
                    automation_eligible=True,
                    requires_manual_review=False,
                    reason=(
                        f"{_source_label(truth_source)} contains the authoritative {verdict.label}, "
                        f"but {_source_label(target_source)} is missing it."
                    ),
                    recommendation=(
                        f"Populate {verdict.label} in {_source_label(target_source)} with "
                        f"{verdict.truth_value!r}, then re-run the comparison."
                    ),
                )
            continue

        if verdict.status == "TRUTH_FORMAT_INVALID":
            note = truth_observation.normalization_note if truth_observation else None
            add(
                attribute=verdict.attribute,
                label=verdict.label,
                action="REVIEW_AUTHORITATIVE_VALUE",
                target_source=truth_source,
                current_value=verdict.truth_value,
                recommended_value=None,
                truth_source=truth_source,
                priority="CRITICAL",
                confidence="HIGH",
                automation_eligible=False,
                requires_manual_review=True,
                reason=(
                    f"The selected authoritative value in {_source_label(truth_source)} is not valid for "
                    f"{verdict.label}. {note or 'The canonical format check failed.'}"
                ),
                recommendation=(
                    f"Validate and correct {verdict.label} in {_source_label(truth_source)} first. "
                    "Do not synchronize this attribute to other systems until the authoritative value is confirmed; "
                    "then re-run the disparity check to obtain exact downstream replacements."
                ),
            )
            continue

        if verdict.status == "UNVERIFIABLE":
            if verdict.unavailable_sources or any(
                not observation.record_found
                for observation in verdict.observations.values()
                if observation.supported
            ):
                continue
            comparison_values = [
                f"{_source_label(source)}={observation.raw_value!r}"
                for source, observation in verdict.observations.items()
                if observation.present
            ]
            evidence = ", ".join(comparison_values) if comparison_values else "no source returned a value"
            add(
                attribute=verdict.attribute,
                label=verdict.label,
                action="NO_SAFE_CHANGE",
                target_source=None,
                current_value=None,
                recommended_value=None,
                truth_source=None,
                priority="LOW",
                confidence="HIGH",
                automation_eligible=False,
                requires_manual_review=True,
                reason=(
                    f"Neither CPS nor Rewards DB provides an authoritative {verdict.label}; observed evidence: {evidence}."
                ),
                recommendation=(
                    f"Do not change {verdict.label} yet. Retrieve or establish an approved value in CPS or Rewards DB, "
                    "then re-run the analysis. CrowdTwist-only data cannot be promoted to truth by default."
                ),
            )

    return suggestions

from __future__ import annotations

import asyncio
import json
import time
from typing import Any

from mcp.server.fastmcp import FastMCP

from .api_knowledge import ApiKnowledgeBase
from .connectors.oauth import ClientCredentialsTokenProvider, TokenAcquisitionError
from .connectors.tcps import TCPSCountryConnector
from .models import DisparityReport, SearchType
from .pipeline import DisparityPipeline
from .settings import load_settings
from .use_cases import UseCaseEngine


mcp = FastMCP("dell-data-disparity")

# One MCP request often invokes run_disparity_check, suggest_use_cases, and
# compile_use_case_plan for the same member. Reusing the deterministic report avoids
# calling CPS, Rewards DB, and CrowdTwist repeatedly during a single agent run.
_REPORT_CACHE: dict[tuple[str, str], tuple[float, DisparityReport]] = {}
_REPORT_CACHE_TTL_SECONDS = 300.0
_REPORT_CACHE_LOCK = asyncio.Lock()


def _normalise_search_type(search_type: str) -> SearchType:
    return SearchType(search_type.lower().replace("_", ""))


async def _get_or_run_report(search_type: str, search_value: str) -> DisparityReport:
    normalized_type = _normalise_search_type(search_type)
    key = (normalized_type.value, search_value.strip())
    now = time.monotonic()

    cached = _REPORT_CACHE.get(key)
    if cached and now - cached[0] <= _REPORT_CACHE_TTL_SECONDS:
        return cached[1].model_copy(deep=True)

    async with _REPORT_CACHE_LOCK:
        cached = _REPORT_CACHE.get(key)
        now = time.monotonic()
        if cached and now - cached[0] <= _REPORT_CACHE_TTL_SECONDS:
            return cached[1].model_copy(deep=True)

        report = await DisparityPipeline(load_settings()).run(normalized_type, search_value)
        _REPORT_CACHE[key] = (time.monotonic(), report.model_copy(deep=True))

        # Keep memory bounded when many members are analyzed in one API worker process.
        if len(_REPORT_CACHE) > 32:
            oldest = sorted(_REPORT_CACHE.items(), key=lambda item: item[1][0])[:8]
            for old_key, _ in oldest:
                _REPORT_CACHE.pop(old_key, None)
        return report


@mcp.tool()
async def health_check() -> str:
    """Return non-secret readiness for sources, Dell AIA and the API knowledge catalog."""
    settings = load_settings()
    knowledge = ApiKnowledgeBase()
    readiness = {
        "mock_mode": settings.use_mock_sources,
        "cps_configured": bool(settings.cps_base_url and settings.cps_auth_url and settings.cps_client_id and settings.cps_client_secret),
        "tcps_country_search_configured": bool(
            settings.tcps_enabled
            and settings.tcps_search_url
            and (
                settings.tcps_bearer_token
                or (
                    settings.tcps_use_cps_bearer_token
                    and settings.cps_auth_url
                    and settings.cps_client_id
                    and settings.cps_client_secret
                )
            )
        ),
        "tcps_authentication_mode": (
            "explicit_tcps_token"
            if settings.tcps_bearer_token
            else ("reuse_cps_oauth_token" if settings.tcps_use_cps_bearer_token else "not_configured")
        ),
        "tcps_country_search_endpoint_host": "dellidentity-corp.dell.com" if settings.tcps_search_url else None,
        "rewards_db_configured": bool(settings.rewards_db_connection_string or (settings.rewards_db_server and settings.rewards_db_name)),
        "crowd_twist_configured": bool(settings.crowd_twist_base_url and settings.crowd_twist_auth_url and settings.crowd_twist_client_id and settings.crowd_twist_client_secret),
        "dell_aia_configured": bool(
            settings.dell_aia_base_url
            and settings.dell_aia_model
            and settings.dell_aia_client_id
            and settings.dell_aia_client_secret
        ),
        "dell_aia_provider": settings.dell_aia_provider,
        "dell_aia_provider_lock": "DELL_AIA_ONLY",
        "dell_aia_auth_mode": settings.dell_aia_auth_mode,
        "dell_aia_model": settings.dell_aia_model,
        "dell_aia_required": True,
        "mcp_tool_use_required": settings.require_mcp_tool_use,
        "playwright_fallback_enabled": settings.enable_playwright_fallback,
        "api_knowledge": knowledge.summary(),
        "report_cache_ttl_seconds": _REPORT_CACHE_TTL_SECONDS,
    }
    return json.dumps(readiness)


@mcp.tool()
async def run_disparity_check(search_type: str, search_value: str) -> str:
    """Fetch one member from CPS (including tCPS country enrichment), Rewards DB and CrowdTwist, apply truth precedence, and return deterministic evidence JSON."""
    report = await _get_or_run_report(search_type, search_value)
    return report.model_dump_json(indent=2)


@mcp.tool()
async def search_tcps_default_country(email: str) -> str:
    """Search tCPS for exact defaultCountry using the current CPS OAuth bearer token. Never returns the token."""
    settings = load_settings()
    bearer_token = None
    token_source = None

    if settings.tcps_bearer_token:
        bearer_token = settings.tcps_bearer_token
        token_source = "tcps_bearer_token_override"
    elif settings.tcps_use_cps_bearer_token:
        provider = ClientCredentialsTokenProvider(
            settings.cps_auth_url,
            settings.cps_client_id,
            settings.cps_client_secret,
            settings.cps_scope,
            settings.cps_verify_ssl,
            settings.request_timeout_seconds,
            send_scope=settings.cps_send_scope,
        )
        try:
            bearer_token = await provider.get_token()
            token_source = "cps_oauth_runtime_token"
        except TokenAcquisitionError as exc:
            return json.dumps(
                {
                    "country": None,
                    "status": {
                        "service": "tCPS / Dell Identity User Provisioning",
                        "connected": False,
                        "data_found": False,
                        "stage": "cps_oauth_token",
                        "error_code": exc.code,
                        "http_status": exc.status_code,
                        "diagnostic_hint": "The CPS OAuth token could not be acquired for tCPS reuse.",
                    },
                },
                indent=2,
            )

    result = await TCPSCountryConnector(settings).fetch_default_country(
        email,
        bearer_token=bearer_token,
        token_source=token_source,
    )
    return json.dumps(
        {
            "country": result.country,
            "status": result.as_diagnostics(),
        },
        indent=2,
        default=str,
    )


@mcp.tool()
async def get_api_catalog_summary() -> str:
    """Return the complete non-secret API knowledge summary and operation list."""
    knowledge = ApiKnowledgeBase()
    return json.dumps(
        {
            "summary": knowledge.summary(),
            "operations": knowledge.operation_rows(),
        },
        indent=2,
        default=str,
    )


@mcp.tool()
async def describe_api_operation(operation_id: str) -> str:
    """Describe one API/DB operation, including method, path, schemas, risk and implementation status."""
    knowledge = ApiKnowledgeBase()
    operation = dict(knowledge.get_operation(operation_id))
    operation["resolved_request_schema"] = knowledge.resolved_request_schema(operation_id)
    operation["resolved_response_schema"] = knowledge.resolved_response_schema(operation_id)
    return json.dumps(operation, indent=2, default=str)


@mcp.tool()
async def validate_api_payload(operation_id: str, payload_json: str) -> str:
    """Validate a proposed payload against the deterministic API schema without sending it."""
    knowledge = ApiKnowledgeBase()
    payload = json.loads(payload_json)
    if not isinstance(payload, dict):
        raise ValueError("Payload must be a JSON object")
    result = knowledge.validate_payload(operation_id, payload)
    return json.dumps(
        {
            "operation_id": operation_id,
            "valid": result.valid,
            "errors": result.errors,
            "normalized_payload": result.normalized_payload,
        },
        indent=2,
        default=str,
    )


@mcp.tool()
async def suggest_use_cases(search_type: str = "", search_value: str = "") -> str:
    """Suggest use cases grounded in the API catalog, optionally ranked using a live member disparity run."""
    knowledge = ApiKnowledgeBase()
    engine = UseCaseEngine(knowledge)
    report = None
    if search_type and search_value:
        report = await _get_or_run_report(search_type, search_value)
    recommendations = [item.model_dump(mode="json") for item in engine.recommend(report)]
    return json.dumps(recommendations, indent=2, default=str)


@mcp.tool()
async def compile_use_case_plan(use_case_id: str, search_type: str, search_value: str) -> str:
    """Compile the selected use case into an executable dry-run plan using cached deterministic evidence."""
    report = await _get_or_run_report(search_type, search_value)
    plan = UseCaseEngine(ApiKnowledgeBase()).compile_plan(use_case_id, report)
    return plan.model_dump_json(indent=2)


if __name__ == "__main__":
    mcp.run(transport="stdio")

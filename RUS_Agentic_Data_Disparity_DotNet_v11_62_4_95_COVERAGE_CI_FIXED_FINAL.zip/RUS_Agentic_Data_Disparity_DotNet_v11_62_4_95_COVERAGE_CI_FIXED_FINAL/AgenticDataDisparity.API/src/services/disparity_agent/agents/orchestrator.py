from __future__ import annotations

import asyncio
import json
import re
import sys
from pathlib import Path
from time import perf_counter
from typing import Any, Iterable

from autogen_agentchat.agents import AssistantAgent
from autogen_core.models import SystemMessage, UserMessage
from autogen_ext.tools.mcp import McpWorkbench, StdioServerParams

from ..models import DisparityReport, SearchType, SourceName
from ..judgment import canonical_judge_verdict, enforce_judge_on_report_dict
from ..pipeline import DisparityPipeline
from ..reporting import save_audit_report
from ..settings import Settings, load_settings
from ..memory import AdaptiveRunContext, get_adaptive_memory
from .json_utils import (
    all_message_text,
    extract_json_with_mode,
    last_substantive_message,
    message_content,
)
from .model_client import (
    build_model_client,
    close_model_client,
    invalidate_shared_token,
    is_model_route_not_found,
    is_rate_limit_error,
    rate_limit_retry_delay,
    safe_exception_chain,
)
from .playwright_fallback import collect_browser_evidence


MCP_TOOL_NAMES = {
    "health_check",
    "run_disparity_check",
    "search_tcps_default_country",
    "get_api_catalog_summary",
    "describe_api_operation",
    "validate_api_payload",
    "suggest_use_cases",
    "compile_use_case_plan",
}

REQUIRED_DATA_AGENT_TOOLS = {
    "health_check",
    "run_disparity_check",
    "get_api_catalog_summary",
}

ANALYSIS_AGENT_SYSTEM = """You are the Dell Rewards Data Disparity Analysis Agent.
A separate Data Collection Agent has already called the Dell MCP tools and supplied a deterministic evidence package.
Do not call APIs or tools yourself. Analyze only the supplied evidence. Deterministic values and suggested exact corrections are final.

Truth policy:
- Default attributes: CPS is truth; Rewards DB is fallback only when CPS does not contain that attribute.
- CrowdTwist ID: CrowdTwist API owns the ID; correct the Rewards DB reference.
- Active Status: OR rule across Rewards DB and CrowdTwist; on mismatch, the False side changes to True.
- Country: CPS is the source of truth whenever CPS supplies country/region evidence. tCPS exact defaultCountry is CPS evidence.
  If CPS is broad (for example UsCanada), Rewards DB may disambiguate only inside the CPS-approved set, but CPS remains truth.
  CrowdTwist must use the approved two-letter ISO code.
- Missing source record is a record-level onboarding/linkage issue, not many missing fields.

Return one JSON object with keys: summary, wrong_attributes, source_health_observations, recommended_actions,
priority, confidence, caveats. Do not wrap it in markdown. Never invent values, endpoints, causes, or write capabilities.
"""

IMPLEMENTATION_AGENT_SYSTEM = """You are the Dell Rewards MCP Implementation Planner.
Call compile_use_case_plan for the exact use_case_id, search_type and search_value. Inspect referenced
operations with describe_api_operation and validate proposed payloads with validate_api_payload.
Never send a write and never invent operation IDs, paths, fields, or readiness.
Return a JSON object with keys review_status, use_case_id, evidence_run_id, operations_reviewed,
payload_validations, blockers, safety_controls, acceptance_criteria, implementation_summary,
and mcp_tools_used. Do not wrap it in markdown.
"""

EVIDENCE_JUDGE_SYSTEM = """You are the independent Dell Rewards Content Judge.
A Data Collection Agent already produced the deterministic evidence and a separate Dell AIA Analysis Agent produced an analysis.
Do not call APIs or tools. Judge the proposed analysis strictly against the supplied deterministic evidence and truth policy.
Reject any invented value, incorrect truth source, unsafe exact correction, wrong target system, or claim not supported by evidence.
Manual-review items must never become executable corrections.
Return one JSON object with keys: verdict, supported_claims, unsupported_claims, missing_important_findings,
corrected_summary, confidence. The verdict MUST be exactly one of ACCEPTED, PARTIAL, or REJECTED.
Use PARTIAL only when a safe corrected summary can replace the analyst narrative. Do not wrap it in markdown.
"""

JSON_REPAIR_SYSTEM = """You are a Dell AIA JSON contract repairer. Convert the supplied Dell AIA response
into exactly one valid JSON object. Preserve every supported fact and do not add facts, endpoints, values,
or claims. Remove markdown fences and commentary outside the object. Return JSON only."""


class AgenticOrchestrator:
    """Run deterministic MCP evidence plus Dell AIA analysis without losing valid runs to formatting errors."""

    def __init__(
        self,
        settings: Settings | None = None,
        *,
        ai_semaphore: asyncio.Semaphore | None = None,
    ) -> None:
        self.settings = settings or load_settings()
        self.ai_semaphore = ai_semaphore
        self.adaptive_memory = get_adaptive_memory(self.settings)

    def _mcp_params(self) -> StdioServerParams:
        # Resolve the project root from this module rather than the shell working
        # directory. The API may be launched from a parent folder, service host, or VS Code task.
        project_root = Path(__file__).resolve().parents[4]
        return StdioServerParams(
            command=sys.executable,
            args=["-m", "src.services.disparity_agent.mcp_server"],
            cwd=str(project_root),
            read_timeout_seconds=max(120, int(self.settings.request_timeout_seconds * 8)),
        )

    async def collect_data(self, search_type: SearchType, search_value: str) -> tuple[DisparityReport, dict[str, Any]]:
        """Stage 1: deterministic Data Collection Agent.

        This stage owns all MCP/API/DB retrieval. It intentionally uses no Dell AIA
        model call, so source collection can run in parallel without consuming LLM
        rate-limit capacity.
        """
        data_agent_started = perf_counter()
        report: DisparityReport | None = None
        baseline_succeeded = False
        bundle: dict[str, Any] = {}
        try:
            async with McpWorkbench(self._mcp_params()) as workbench:
                bundle = await self._collect_required_mcp_evidence(workbench, search_type, search_value)
                report = bundle["report"]
                baseline_succeeded = True
                report.mcp_execution = {
                    "status": "SUCCESS",
                    "stage": "DATA_COLLECTION_AGENT",
                    "transport": "stdio",
                    "server": "src.services.disparity_agent.mcp_server",
                    "agent_workbench_attached": True,
                    "llm_used": False,
                    "tools_used": bundle["tools_used"],
                    "required_evidence_tools_completed": True,
                    "evidence_run_id": report.run_id,
                    "session_close_status": "PENDING",
                }
            report.mcp_execution["session_close_status"] = "SUCCESS"
        except Exception as exc:
            if report is not None and baseline_succeeded:
                report.mcp_execution["session_close_status"] = "WARNING"
                report.mcp_execution["session_close_error"] = self._safe_error(exc, stage="mcp_session_close")
                report.warnings.append("The MCP session reported a shutdown warning after evidence retrieval; collected evidence was preserved.")
            else:
                report = report or await DisparityPipeline(self.settings).run(search_type, search_value)
                report.mcp_execution = {
                    "status": "FAILED",
                    "stage": "DATA_COLLECTION_AGENT",
                    "transport": "stdio",
                    "server": "src.services.disparity_agent.mcp_server",
                    "error": self._safe_error(exc, stage="mcp_data_collection"),
                    "fallback": "deterministic_in_process_only",
                    "agent_workbench_attached": False,
                    "llm_used": False,
                }
                report.warnings.append("MCP data collection failed; deterministic in-process evidence was retained for diagnostics.")
        assert report is not None
        bundle = bundle or {"report": report, "tools_used": [], "health_check": {}, "api_catalog": {}}
        report.timings = dict(report.timings or {})
        report.timings["data_collection_agent_ms"] = int((perf_counter() - data_agent_started) * 1000)
        if bundle.get("tool_timings_ms"):
            report.timings["mcp_tool_timings_ms"] = dict(bundle.get("tool_timings_ms") or {})
        return report, bundle

    async def analyze_and_judge(
        self,
        report: DisparityReport,
        mcp_bundle: dict[str, Any],
        search_type: SearchType,
        search_value: str,
    ) -> DisparityReport:
        """Stages 2 and 3: Dell AIA Analysis Agent, then independent Content Judge.

        LLM calls are separated from source retrieval and bounded by the batch-level
        AIA semaphore. Timing includes queue wait, model-client setup, retries/backoff,
        the Analyst stage, and the Judge stage.
        """
        stage_started = perf_counter()
        report.timings = dict(report.timings or {})
        model_client_setup_ms = 0
        memory_context = await self.adaptive_memory.begin_analysis(
            task_signature=self._memory_signature(report, search_type)
        )

        async def run_stages() -> DisparityReport:
            nonlocal model_client_setup_ms
            attempts = max(1, int(self.settings.dell_aia_rate_limit_retries) + 1)
            last_exc: Exception | None = None
            active_model = memory_context.model_name
            default_model = self.settings.dell_aia_model
            for attempt in range(attempts):
                client = None
                try:
                    setup_started = perf_counter()
                    selected_settings = self.settings.model_copy(update={"dell_aia_model": active_model})
                    client = await build_model_client(selected_settings, force_refresh_token=False)
                    model_client_setup_ms += int((perf_counter() - setup_started) * 1000)
                    memory_context.model_name = active_model
                    return await self._apply_agentic_ai(
                        report=report,
                        model_client=client,
                        search_type=search_type,
                        search_value=search_value,
                        mcp_bundle=mcp_bundle,
                        memory_context=memory_context,
                    )
                except Exception as exc:
                    last_exc = exc
                    # A challenger may be configured but not yet entitled/routed in
                    # the current Dell AIA environment. Fall back only to the
                    # deployment-owned default champion; never invent a model.
                    if is_model_route_not_found(exc) and active_model != default_model:
                        active_model = default_model
                        memory_context.model_name = default_model
                        memory_context.model_selection_mode = "fallback_to_default_after_route_failure"
                        await asyncio.sleep(0.25)
                        continue
                    if is_model_route_not_found(exc) and attempt == 0:
                        invalidate_shared_token()
                        await asyncio.sleep(1.0)
                        continue
                    raise
                finally:
                    if client is not None:
                        try:
                            await close_model_client(client)
                        except Exception:
                            pass
            assert last_exc is not None
            raise last_exc

        queue_wait_ms = 0
        result = report
        try:
            if self.ai_semaphore is not None:
                queue_started = perf_counter()
                async with self.ai_semaphore:
                    queue_wait_ms = int((perf_counter() - queue_started) * 1000)
                    result = await run_stages()
            else:
                result = await run_stages()
        except Exception as exc:
            self._mark_ai_failure(report, exc, stage="dell_aia_analysis_or_judge")
            report.ai_execution = dict(report.ai_execution or {})
            report.ai_execution["model"] = memory_context.model_name
            report.ai_execution["model_selection_mode"] = memory_context.model_selection_mode
            result = report
        finally:
            report.timings["dell_aia_queue_wait_ms"] = queue_wait_ms
            report.timings["model_client_setup_ms"] = model_client_setup_ms
            report.timings["analysis_and_judge_wall_ms"] = int((perf_counter() - stage_started) * 1000)

        # Record objective execution outcomes after timings and judge enforcement
        # are available. This memory can optimize only the pre-approved reasoning
        # profile; it cannot mutate truth rules, tools, endpoints, or approvals.
        memory_result = await self.adaptive_memory.complete_analysis(result, memory_context)
        result.ai_execution = dict(result.ai_execution or {})
        result.ai_execution["adaptive_memory"] = memory_result
        return result

    async def run(self, search_type: SearchType, search_value: str) -> DisparityReport:
        end_to_end_started = perf_counter()
        report, bundle = await self.collect_data(search_type, search_value)
        if (report.mcp_execution or {}).get("status") == "SUCCESS":
            report = await self.analyze_and_judge(report, bundle, search_type, search_value)
        else:
            self._mark_ai_failure(report, RuntimeError("MCP evidence collection is required before Dell AIA analysis."), stage="data_collection_required")
        report.timings = dict(report.timings or {})
        report.timings["total_processing_ms"] = int((perf_counter() - end_to_end_started) * 1000)
        audit_started = perf_counter()
        save_audit_report(report, self.settings)
        report.timings["audit_report_write_ms"] = int((perf_counter() - audit_started) * 1000)
        report.timings["end_to_end_ms"] = int((perf_counter() - end_to_end_started) * 1000)
        # Persist once more so the generated JSON/HTML also contain the final timing values.
        save_audit_report(report, self.settings)
        return report

    async def compile_selected_use_case(
        self,
        use_case_id: str,
        search_type: SearchType,
        search_value: str,
    ) -> dict[str, Any]:
        model_client = None
        try:
            async with McpWorkbench(self._mcp_params()) as workbench:
                raw_plan = await workbench.call_tool(
                    "compile_use_case_plan",
                    {
                        "use_case_id": use_case_id,
                        "search_type": search_type.value,
                        "search_value": search_value,
                    },
                )
                plan = self._json_from_tool(raw_plan)
                if not isinstance(plan, dict):
                    raise ValueError("MCP use-case plan was not a JSON object")

                model_client = await build_model_client(self.settings)
                agent = AssistantAgent(
                    name="dell_rewards_mcp_implementation_planner",
                    model_client=model_client,
                    workbench=workbench,
                    reflect_on_tool_use=True,
                    max_tool_iterations=max(6, self.settings.ai_max_tool_iterations),
                    system_message=IMPLEMENTATION_AGENT_SYSTEM,
                )
                result = await self._run_agent_with_rate_limit_retry(
                    agent,
                    task=(
                        f"Compile and review use_case_id={use_case_id!r} for "
                        f"search_type={search_type.value!r}, search_value={search_value!r}."
                    ),
                    stage="selected_use_case_implementation",
                )
                messages = list(result.messages)
                tools_used = self._extract_tool_calls(messages)
                raw_text = last_substantive_message(messages) or all_message_text(messages)
                review, parse_diag = await self._parse_or_repair_json(
                    model_client,
                    raw_text,
                    contract_name="implementation review",
                )
                if review is None:
                    review = {
                        "review_status": "SUCCESS_WITH_NORMALIZED_OUTPUT",
                        "use_case_id": use_case_id,
                        "evidence_run_id": plan.get("evidence_run_id"),
                        "operations_reviewed": [],
                        "payload_validations": [],
                        "blockers": plan.get("blockers") or [],
                        "safety_controls": plan.get("safety_controls") or [],
                        "acceptance_criteria": plan.get("acceptance_criteria") or [],
                        "implementation_summary": raw_text or "Dell AIA returned no structured narrative.",
                        "mcp_tools_used": tools_used,
                        "output_contract_status": "NORMALIZED_FROM_DELL_AIA_TEXT",
                    }
                plan["agentic_review"] = review
                plan["agentic_execution"] = {
                    "status": "SUCCESS",
                    "model": self.settings.dell_aia_model,
                    "mcp_grounded": True,
                    "mcp_agent_used": bool(tools_used),
                    "mcp_tools_used": self._dedupe(["compile_use_case_plan"] + tools_used),
                    "output_contract": parse_diag,
                    "live_writes_performed": False,
                }
                return plan
        except Exception as exc:
            error = self._safe_error(exc, stage="selected_use_case_implementation")
            return {
                "use_case_id": use_case_id,
                "implementation_status": "FAILED",
                "inputs": {"search_type": search_type.value, "search_value": search_value},
                "findings": [],
                "steps": [],
                "remediation_actions": [],
                "blockers": [error["message"]],
                "agentic_execution": {
                    "status": "FAILED",
                    "model": self.settings.dell_aia_model,
                    "mcp_agent_used": False,
                    "error": error,
                    "live_writes_performed": False,
                },
            }
        finally:
            if model_client is not None:
                try:
                    await close_model_client(model_client)
                except Exception:
                    pass

    async def _collect_required_mcp_evidence(
        self,
        workbench: McpWorkbench,
        search_type: SearchType,
        search_value: str,
    ) -> dict[str, Any]:
        tool_timings: dict[str, int] = {}

        started = perf_counter()
        health = self._json_from_tool(await workbench.call_tool("health_check", {}))
        tool_timings["health_check_ms"] = int((perf_counter() - started) * 1000)

        started = perf_counter()
        report_result = await workbench.call_tool(
            "run_disparity_check",
            {"search_type": search_type.value, "search_value": search_value},
        )
        tool_timings["run_disparity_check_ms"] = int((perf_counter() - started) * 1000)
        report = DisparityReport.model_validate(self._json_from_tool(report_result))

        started = perf_counter()
        catalog = self._json_from_tool(await workbench.call_tool("get_api_catalog_summary", {}))
        tool_timings["get_api_catalog_summary_ms"] = int((perf_counter() - started) * 1000)
        if isinstance(catalog, dict) and isinstance(catalog.get("summary"), dict):
            report.api_knowledge_summary = catalog["summary"]
        return {
            "report": report,
            "health_check": health,
            "api_catalog": catalog,
            "tools_used": ["health_check", "run_disparity_check", "get_api_catalog_summary"],
            "tool_timings_ms": tool_timings,
            "data_agent_status": "SUCCESS",
        }

    async def _run_agent_with_rate_limit_retry(self, agent: AssistantAgent, *, task: str, stage: str) -> Any:
        """Run one Dell AIA agent stage with bounded 429 backoff.

        Analysis and judge retry independently so a judge throttle never repeats a
        successful analysis transaction.
        """
        retries = max(0, int(self.settings.dell_aia_rate_limit_retries))
        last_exc: Exception | None = None
        for attempt in range(retries + 1):
            try:
                return await agent.run(task=task)
            except Exception as exc:
                last_exc = exc
                if is_rate_limit_error(exc) and attempt < retries:
                    await asyncio.sleep(rate_limit_retry_delay(self.settings, attempt, exc))
                    continue
                raise
        assert last_exc is not None
        raise last_exc

    async def _apply_agentic_ai(
        self,
        report: DisparityReport,
        model_client: Any,
        search_type: SearchType,
        search_value: str,
        mcp_bundle: dict[str, Any],
        memory_context: AdaptiveRunContext,
    ) -> DisparityReport:
        data_tools = list(mcp_bundle.get("tools_used") or [])
        missing_data_tools = sorted(REQUIRED_DATA_AGENT_TOOLS - set(data_tools))
        if missing_data_tools:
            raise RuntimeError(f"Data Collection Agent missed required MCP tools: {', '.join(missing_data_tools)}")

        seed = self._compact_evidence_seed(report, mcp_bundle)
        report.ai_execution = {
            "status": "RUNNING",
            "required": True,
            "provider": "Dell AIA",
            "provider_lock": "DELL_AIA_ONLY",
            "authentication": "external_client_credentials",
            "model": memory_context.model_name,
            "model_selection_mode": memory_context.model_selection_mode,
            "base_url_host": self._host_only(self.settings.dell_aia_base_url),
            "architecture": "DATA_AGENT -> ANALYSIS_AGENT -> JUDGE_AGENT",
            "mcp_grounded": True,
            "grounding_mode": "DATA_AGENT_EVIDENCE_HANDOFF",
            "adaptive_memory": memory_context.public_view(),
            "data_agent": {"status": "SUCCESS", "llm_used": False, "tools_used": data_tools},
            "analysis_agent": {"status": "RUNNING"},
            "judge_agent": {"status": "PENDING"},
        }

        # Stage 2: Dell AIA analysis only. No MCP/tool replay, which dramatically
        # reduces model transactions and avoids the RateLimitError seen in the
        # uploaded batch report.
        analyst = AssistantAgent(
            name="dell_rewards_analysis_agent",
            model_client=model_client,
            reflect_on_tool_use=False,
            system_message=ANALYSIS_AGENT_SYSTEM,
        )
        analysis_task = json.dumps({
            "search_type": search_type.value,
            "search_value": search_value,
            "truth_policy": report.truth_policy,
            "deterministic_evidence": seed,
            "adaptive_execution_profile": {
                "strategy_id": memory_context.strategy.strategy_id,
                "instruction": memory_context.strategy.analyst_instruction,
                "replay_lessons": memory_context.replay_lessons,
                "safety_boundary": (
                    "Execution memory may improve response discipline only. It cannot change truth policy, "
                    "source-write permissions, approval requirements, tools, endpoints, or exact correction values."
                ),
            },
        }, default=str)
        analyst_started = perf_counter()
        try:
            analyst_result = await self._run_agent_with_rate_limit_retry(analyst, task=analysis_task, stage="analysis_agent")
        finally:
            report.timings["analysis_agent_ms"] = int((perf_counter() - analyst_started) * 1000)
        analyst_messages = list(analyst_result.messages)
        raw_analyst = last_substantive_message(analyst_messages) or all_message_text(analyst_messages)
        analyst_parse_started = perf_counter()
        parsed_analysis, analyst_parse = await self._parse_or_repair_json(
            model_client, raw_analyst, contract_name="analysis agent response"
        )
        report.timings["analysis_output_parse_ms"] = int((perf_counter() - analyst_parse_started) * 1000)
        envelope = self._normalise_analyst_envelope(
            report=report,
            parsed={"analysis": parsed_analysis or {}},
            raw_text=raw_analyst,
            parse_diagnostics=analyst_parse,
            analyst_tools=[],
            orchestrator_tools=data_tools,
        )
        report.ai_analysis = envelope["analysis"]
        report.ai_execution["analysis_agent"] = {
            "status": "SUCCESS",
            "output_contract": analyst_parse,
            "raw_output_available": bool(raw_analyst),
        }
        report.ai_execution["judge_agent"] = {"status": "RUNNING"}

        # Stage 3: independent Dell AIA judge. It receives exactly the same
        # deterministic evidence plus the analysis, and is not allowed to fetch
        # or mutate data.
        judge = AssistantAgent(
            name="dell_rewards_content_judge",
            model_client=model_client,
            reflect_on_tool_use=False,
            system_message=EVIDENCE_JUDGE_SYSTEM,
        )
        judge_task = json.dumps({
            "search_type": search_type.value,
            "search_value": search_value,
            "truth_policy": report.truth_policy,
            "deterministic_evidence": seed,
            "proposed_analysis": report.ai_analysis,
        }, default=str)
        judge_started = perf_counter()
        try:
            judge_result = await self._run_agent_with_rate_limit_retry(judge, task=judge_task, stage="judge_agent")
        finally:
            report.timings["judge_agent_ms"] = int((perf_counter() - judge_started) * 1000)
        judge_messages = list(judge_result.messages)
        raw_judge = last_substantive_message(judge_messages) or all_message_text(judge_messages)
        judge_parse_started = perf_counter()
        parsed_judge, judge_parse = await self._parse_or_repair_json(
            model_client, raw_judge, contract_name="content judge response"
        )
        report.timings["judge_output_parse_ms"] = int((perf_counter() - judge_parse_started) * 1000)
        report.judge_result = self._normalise_judge_result(
            report=report,
            parsed=parsed_judge,
            raw_text=raw_judge,
            parse_diagnostics=judge_parse,
            judge_tools=[],
        )

        # Enforce the independent judge before anything is published. A successful
        # Dell AIA call is not the same as approved content. PARTIAL responses are
        # replaced with the judge-corrected deterministic view; REJECTED responses
        # suppress the analyst narrative entirely.
        enforced = enforce_judge_on_report_dict(report.model_dump(mode="json"))
        report.ai_analysis = dict(enforced.get("ai_analysis") or {})
        report.judge_result = dict(enforced.get("judge_result") or {})

        output_modes = {str(analyst_parse.get("status")), str(judge_parse.get("status"))}
        normalized = "NORMALIZED" in " ".join(output_modes).upper()
        report.ai_execution = {
            "status": "SUCCESS",
            "quality_status": "SUCCESS_WITH_NORMALIZED_OUTPUT" if normalized else "SUCCESS_DIRECT_JSON",
            "required": True,
            "provider": "Dell AIA",
            "provider_lock": "DELL_AIA_ONLY",
            "authentication": "external_client_credentials",
            "model": memory_context.model_name,
            "model_selection_mode": memory_context.model_selection_mode,
            "base_url_host": self._host_only(self.settings.dell_aia_base_url),
            "architecture": "DATA_AGENT -> ANALYSIS_AGENT -> JUDGE_AGENT",
            "mcp_grounded": True,
            "grounding_mode": "DATA_AGENT_EVIDENCE_HANDOFF",
            "mcp_tools_used": data_tools,
            "data_agent": {"status": "SUCCESS", "llm_used": False, "tools_used": data_tools},
            "analysis_agent": {"status": "SUCCESS", "output_contract": analyst_parse},
            "judge_agent": {
                "status": "SUCCESS",
                "output_contract": judge_parse,
                "verdict": report.judge_result.get("verdict"),
                "content_disposition": report.judge_result.get("content_disposition"),
            },
            "judge_verdict": report.judge_result.get("verdict"),
            "final_content_status": report.judge_result.get("content_disposition"),
            "analyst_content_published": bool(report.ai_analysis.get("analyst_content_published")),
            "final_content_publishable": True,
            "judge_enforcement_applied": True,
            "adaptive_memory": memory_context.public_view(),
            "live_writes_performed": False,
        }
        report.timings["dell_aia_agents_ms"] = int(report.timings.get("analysis_agent_ms") or 0) + int(report.timings.get("judge_agent_ms") or 0)
        return report

    async def _parse_or_repair_json(
        self,
        model_client: Any,
        raw_text: str,
        *,
        contract_name: str,
    ) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        """Parse locally; never spend another Dell AIA transaction on JSON repair.

        A malformed JSON response is normalized by deterministic code so one bad
        formatting turn cannot trigger more rate-limited model calls.
        """
        try:
            extracted = extract_json_with_mode(raw_text)
            return extracted.value, {
                "status": "DIRECT_JSON",
                "extraction_mode": extracted.mode,
                "repair_attempted": False,
                "contract_name": contract_name,
            }
        except Exception as direct_error:
            return None, {
                "status": "NORMALIZED_FROM_DELL_AIA_TEXT",
                "repair_attempted": False,
                "contract_name": contract_name,
                "errors": [f"direct:{type(direct_error).__name__}"],
            }

    def _normalise_analyst_envelope(
        self,
        *,
        report: DisparityReport,
        parsed: dict[str, Any] | None,
        raw_text: str,
        parse_diagnostics: dict[str, Any],
        analyst_tools: list[str],
        orchestrator_tools: list[str],
    ) -> dict[str, Any]:
        parsed = parsed or {}
        analysis = parsed.get("analysis") if isinstance(parsed.get("analysis"), dict) else None
        if analysis is None:
            # Some models return the analysis object directly instead of an envelope.
            analysis_keys = {"summary", "wrong_attributes", "recommended_actions", "confidence"}
            analysis = dict(parsed) if analysis_keys.intersection(parsed) else {}

        wrong_attributes = [
            {
                "attribute": item.attribute,
                "label": item.label,
                "wrong_sources": [source.value for source in item.wrong_sources],
                "truth_source": item.truth_source.value if item.truth_source else None,
                "expected_value": item.truth_value,
                "status": item.status,
            }
            for item in report.attributes
            if item.wrong_sources
        ]
        missing_attributes = [
            {"attribute": item.attribute, "missing_sources": [source.value for source in item.missing_sources]}
            for item in report.attributes
            if item.missing_sources
        ]
        deferred_attributes = [
            {
                "attribute": item.attribute,
                "status": item.status,
                "unavailable_sources": [source.value for source in item.unavailable_sources],
            }
            for item in report.attributes
            if item.unavailable_sources
        ]
        format_issues = [
            {"attribute": item.attribute, "status": item.status, "explanation": item.explanation}
            for item in report.attributes
            if "FORMAT" in item.status
        ]
        unverifiable = [
            {"attribute": item.attribute, "explanation": item.explanation}
            for item in report.attributes
            if item.status == "UNVERIFIABLE"
        ]
        source_health = {
            source.value: {
                "connected": status.connected,
                "data_found": status.data_found,
                "stage": status.stage,
                "error_code": status.error_code,
                "http_status": status.http_status,
                "latency_ms": status.latency_ms,
            }
            for source, status in report.source_status.items()
        }
        correction_plan = [suggestion.model_dump(mode="json") for suggestion in report.suggestions]
        recommended_actions = [suggestion.recommendation for suggestion in report.suggestions]

        # Deterministic evidence controls all values. Dell AIA supplies explanation,
        # prioritization, and use-case reasoning, but cannot replace exact truth values.
        analysis.update(
            {
                "summary": analysis.get("summary") or raw_text or report.deterministic_summary,
                "wrong_attributes": wrong_attributes,
                "missing_attributes": missing_attributes,
                "deferred_attributes_due_to_missing_records": deferred_attributes,
                "format_issues": format_issues,
                "unverifiable_attributes": unverifiable,
                "source_health": source_health,
                "correction_plan": correction_plan,
                "recommended_actions": analysis.get("recommended_actions") or recommended_actions,
                "confidence": analysis.get("confidence") or "HIGH_FOR_DETERMINISTIC_VALUES",
                "caveats": analysis.get("caveats") or list(report.warnings),
                "status": "SUCCESS",
                "output_contract_status": parse_diagnostics.get("status"),
                "dell_aia_raw_narrative": raw_text,
            }
        )

        architect = parsed.get("use_case_architect")
        if not isinstance(architect, dict):
            architect = {
                "portfolio_summary": "Dell AIA use-case output was normalized from the MCP-grounded run.",
                "implementation_order": [
                    item.get("use_case_id") for item in report.use_case_recommendations[:5]
                ],
                "recommended_use_cases": report.use_case_recommendations,
                "additional_use_cases": [],
                "dependencies": [],
                "blockers": [],
                "safety_controls": ["No live writes", "Deterministic per-attribute business truth policies", "Payload validation before execution"],
            }
        analysis["use_case_architect"] = architect
        analysis["implementation_plan"] = parsed.get("implementation_plan")
        analysis["mcp_usage_summary"] = (
            parsed.get("mcp_usage_summary")
            if isinstance(parsed.get("mcp_usage_summary"), dict)
            else {
                "tools_used": self._dedupe(orchestrator_tools + analyst_tools),
                "evidence_run_id": report.run_id,
                "required_tools_completed": REQUIRED_DATA_AGENT_TOOLS.issubset(set(orchestrator_tools)),
                "payloads_validated": [],
                "notes": "Required evidence tools were completed through the MCP workbench.",
            }
        )
        return {
            "analysis": analysis,
            "use_case_architect": architect,
            "implementation_plan": analysis["implementation_plan"],
            "mcp_usage_summary": analysis["mcp_usage_summary"],
        }

    def _normalise_judge_result(
        self,
        *,
        report: DisparityReport,
        parsed: dict[str, Any] | None,
        raw_text: str,
        parse_diagnostics: dict[str, Any],
        judge_tools: list[str],
    ) -> dict[str, Any]:
        result = dict(parsed or {})
        raw_verdict = result.get("verdict") or "SUPPORTED_WITH_OUTPUT_NORMALIZATION"
        result["raw_verdict"] = str(raw_verdict)
        result["verdict"] = canonical_judge_verdict(raw_verdict)
        result.setdefault("supported_claims", ["Deterministic attribute verdicts", "Source-of-truth correction values"])
        result.setdefault("unsupported_claims", [])
        result.setdefault("missing_important_findings", [])
        result.setdefault("invalid_operation_ids", [])
        result.setdefault("payload_validation", [])
        result.setdefault("corrected_summary", report.deterministic_summary)
        result.setdefault("confidence", "HIGH_FOR_DETERMINISTIC_VALUES")
        result["mcp_tools_used"] = self._dedupe(
            list(result.get("mcp_tools_used") or []) + judge_tools
        )
        result["status"] = "SUCCESS"
        result["output_contract_status"] = parse_diagnostics.get("status")
        result["dell_aia_raw_narrative"] = raw_text
        return result

    def _compact_evidence_seed(self, report: DisparityReport, bundle: dict[str, Any]) -> dict[str, Any]:
        return {
            "run_id": report.run_id,
            "truth_policy": report.truth_policy,
            "deterministic_summary": report.deterministic_summary,
            "counts": {
                "mismatches": report.mismatch_count,
                "missing_attributes": report.missing_count,
                "missing_source_records": report.missing_record_count,
                "deferred_attributes": report.deferred_attribute_count,
                "format_issues": report.invalid_format_count,
                "unverifiable": report.unverifiable_count,
            },
            "source_status": {
                source.value: {
                    "connected": status.connected,
                    "data_found": status.data_found,
                    "stage": status.stage,
                    "error_code": status.error_code,
                    "http_status": status.http_status,
                    "latency_ms": status.latency_ms,
                    "endpoint_host": status.endpoint_host,
                    "retrieval_method": status.retrieval_method,
                }
                for source, status in report.source_status.items()
            },
            "attribute_verdicts": [
                {
                    "attribute": item.attribute,
                    "status": item.status,
                    "truth_source": item.truth_source.value if item.truth_source else None,
                    "truth_value": item.truth_value,
                    "wrong_sources": [source.value for source in item.wrong_sources],
                    "missing_sources": [source.value for source in item.missing_sources],
                    "unavailable_sources": [source.value for source in item.unavailable_sources],
                    "explanation": item.explanation,
                }
                for item in report.attributes
            ],
            "suggestions": [item.model_dump(mode="json") for item in report.suggestions],
            "api_catalog_summary": (bundle.get("api_catalog") or {}).get("summary", {}),
            "use_cases": list(bundle.get("use_cases") or [])[:10],
        }

    @staticmethod
    def _memory_signature(report: DisparityReport, search_type: SearchType) -> str:
        """Build a PII-free replay signature from evidence shape only."""
        source_states: list[str] = []
        for source, status in sorted(report.source_status.items(), key=lambda item: item[0].value):
            if status.data_found:
                state = "found"
            elif status.connected:
                state = "no_record"
            else:
                state = "unavailable"
            source_states.append(f"{source.value}:{state}")
        counts = (
            f"m{min(int(report.mismatch_count or 0), 9)}",
            f"r{min(int(report.missing_record_count or 0), 3)}",
            f"f{min(int(report.invalid_format_count or 0), 9)}",
            f"u{min(int(report.unverifiable_count or 0), 9)}",
        )
        return "|".join([search_type.value, *source_states, *counts])

    def _mark_ai_failure(self, report: DisparityReport, exc: Exception, stage: str) -> None:
        error = self._safe_error(exc, stage=stage)
        existing = dict(report.ai_execution or {})
        report.ai_execution = {
            **existing,
            "status": "FAILED",
            "required": True,
            "provider": "Dell AIA",
            "provider_lock": "DELL_AIA_ONLY",
            "authentication": "external_client_credentials",
            "model": self.settings.dell_aia_model,
            "base_url_host": self._host_only(self.settings.dell_aia_base_url),
            "mcp_grounded": report.mcp_execution.get("status") == "SUCCESS",
            "error": error,
        }
        report.ai_analysis = {
            "status": "FAILED",
            "error_code": error["error_code"],
            "error_type": error["error_type"],
            "failure_stage": stage,
            "message": error["message"],
            "recommended_action": error["recommended_action"],
        }
        report.judge_result = {
            "status": "NOT_RUN",
            "message": "The evidence judge was not run because Dell AIA inference did not complete.",
        }
        report.warnings.append(
            f"Mandatory Dell AIA analysis failed at {stage} ({error['error_code']}). "
            "The MCP deterministic evidence remains available."
        )

    def _json_from_tool(self, result: Any) -> Any:
        """Decode JSON returned by AutoGen/MCP across supported result shapes.

        AutoGen 0.7.5 returns ``ToolResult.result`` as a list of
        ``TextResultContent`` objects whose payload is stored in ``content``.
        Older adapters used ``text`` and some MCP clients expose a top-level
        ``content`` list.  The previous implementation read only ``item.text``;
        therefore every successful MCP call was misclassified as a ValueError
        before Dell AIA could run.
        """
        is_error = getattr(result, "is_error", False)
        if is_error:
            detail = self._tool_result_text(result, allow_empty=True)
            raise RuntimeError(f"MCP tool returned an error result: {detail or 'no detail'}")

        text = self._tool_result_text(result)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return extract_json_with_mode(text).value

    @classmethod
    def _tool_result_text(cls, result: Any, *, allow_empty: bool = False) -> str:
        """Return textual MCP content without relying on object ``repr``.

        Supported shapes include:
        * AutoGen ``ToolResult(result=[TextResultContent(content=...)])``
        * MCP SDK ``CallToolResult(content=[TextContent(text=...)])``
        * dictionaries produced by serialized tool results
        * direct strings/bytes
        """

        def collect(value: Any) -> list[str]:
            if value is None:
                return []
            if isinstance(value, bytes):
                return [value.decode("utf-8", errors="replace")]
            if isinstance(value, str):
                return [value]
            if isinstance(value, dict):
                # Prefer actual payload-bearing keys over diagnostic metadata.
                chunks: list[str] = []
                for key in ("content", "text", "result", "data", "value"):
                    if key in value:
                        chunks.extend(collect(value[key]))
                return chunks
            if isinstance(value, (list, tuple)):
                chunks: list[str] = []
                for item in value:
                    chunks.extend(collect(item))
                return chunks

            # AutoGen 0.7.5 TextResultContent.content
            for attribute in ("content", "text", "result", "data", "value"):
                child = getattr(value, attribute, None)
                if child is not None and child is not value:
                    chunks = collect(child)
                    if chunks:
                        return chunks
            return []

        # ``result`` is the AutoGen Workbench field; ``content`` is the MCP SDK field.
        chunks: list[str] = []
        for attribute in ("result", "content"):
            value = getattr(result, attribute, None)
            if value is not None:
                chunks.extend(collect(value))
        if not chunks:
            chunks.extend(collect(result))

        text = "".join(chunk for chunk in chunks if chunk is not None).strip()
        if text or allow_empty:
            return text
        raise ValueError(
            "Could not extract MCP tool text from the returned result object "
            f"(type={type(result).__name__})."
        )

    @staticmethod
    def _tool_names_from_listing(tools: Any) -> set[str]:
        names: set[str] = set()
        if isinstance(tools, list):
            for item in tools:
                if isinstance(item, dict) and item.get("name"):
                    names.add(str(item["name"]))
                else:
                    name = getattr(item, "name", None)
                    if name:
                        names.add(str(name))
        return names

    @classmethod
    def _extract_tool_calls(cls, messages: Iterable[Any]) -> list[str]:
        calls: list[str] = []

        def inspect(value: Any) -> None:
            if value is None:
                return
            if isinstance(value, str):
                # Plain text may merely mention a tool name; it is not execution proof.
                return
            if isinstance(value, dict):
                for key in ("name", "tool_name", "function_name"):
                    name = value.get(key)
                    if name in MCP_TOOL_NAMES:
                        calls.append(str(name))
                for child in value.values():
                    inspect(child)
                return
            if isinstance(value, (list, tuple, set)):
                for child in value:
                    inspect(child)
                return
            for key in ("name", "tool_name", "function_name"):
                name = getattr(value, key, None)
                if name in MCP_TOOL_NAMES:
                    calls.append(str(name))
            content = getattr(value, "content", None)
            if content is not value:
                inspect(content)

        for message in messages:
            inspect(message)
        return cls._dedupe(calls)

    @staticmethod
    def _dedupe(items: Iterable[str]) -> list[str]:
        seen: set[str] = set()
        result: list[str] = []
        for item in items:
            if item and item not in seen:
                seen.add(item)
                result.append(item)
        return result

    @staticmethod
    def _host_only(url: str) -> str:
        match = re.match(r"^https?://([^/]+)", url or "")
        return match.group(1) if match else "configured Dell AIA gateway"

    @staticmethod
    def _safe_error(exc: Exception, stage: str) -> dict[str, str]:
        error_type = type(exc).__name__
        text = safe_exception_chain(exc)
        lowered = text.casefold()

        if "aia-auth-client" in lowered or "aia_auth" in lowered or isinstance(exc, ImportError):
            code = "AIA_AUTH_CLIENT_MISSING"
            message = "Dell AIA authentication client is unavailable in the active virtual environment."
            action = "Run scripts/install_dell_aia.ps1 from the Dell network, restart the Agentic API service, and retry."
        elif "401" in lowered or "unauthorized" in lowered or "authentication" in lowered:
            code = "AIA_AUTH_REJECTED"
            message = "Dell AIA rejected authentication or token acquisition."
            action = "Verify Dell VPN access and the injected Dell AIA client credentials/registration."
        elif "403" in lowered or "forbidden" in lowered:
            code = "AIA_ACCESS_FORBIDDEN"
            message = "Dell AIA authenticated the request but denied model access."
            action = "Confirm that the client is authorized for the configured DELL_AIA_MODEL."
        elif "404" in lowered and ("url routes" in lowered or "chat/completions" in lowered):
            code = "AIA_MODEL_ROUTE_NOT_FOUND"
            message = "Dell AIA authentication succeeded, but the gateway could not route gpt-oss-120b."
            action = (
                "This is not a client ID/client secret rejection. Verify the Dell AIA model route/entitlement "
                "for gpt-oss-120b and retry the built-in preflight."
            )
        elif "timeout" in lowered or "timed out" in lowered:
            code = "AIA_OR_MCP_TIMEOUT"
            message = "Dell AIA or an MCP tool did not finish before the configured timeout."
            action = "Remain on Dell VPN, retry once, and increase REQUEST_TIMEOUT_SECONDS if source APIs are slow."
        elif isinstance(exc, ValueError) and ("extract mcp tool" in lowered or "tool text" in lowered):
            code = "MCP_RESULT_DECODING_FAILED"
            message = "The MCP tool completed, but its returned content shape could not be decoded."
            action = "Use the v7.2 MCP ToolResult compatibility build and rerun the analysis."
        elif "mcp" in lowered or "tool" in lowered:
            code = "MCP_TOOL_EXECUTION_FAILED"
            message = "The required MCP server or tool workflow did not complete."
            action = "Verify the virtual environment can run 'python -m src.services.disparity_agent.mcp_server' and retry."
        else:
            code = "AIA_AGENT_FAILED"
            message = f"Dell AIA agent execution failed during {stage}."
            action = "Open Agent Execution diagnostics, verify Dell VPN and AIA access, then retry."

        return {
            "error_code": code,
            "error_type": error_type,
            "stage": stage,
            "message": message,
            "technical_detail": text,
            "recommended_action": action,
        }

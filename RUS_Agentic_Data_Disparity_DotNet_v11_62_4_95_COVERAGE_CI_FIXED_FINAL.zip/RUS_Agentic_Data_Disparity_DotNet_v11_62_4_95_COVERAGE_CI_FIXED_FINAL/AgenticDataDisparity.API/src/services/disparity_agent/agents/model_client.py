from __future__ import annotations

import hashlib
import inspect
import re
import secrets
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import certifi
import httpx
from autogen_ext.models.openai import OpenAIChatCompletionClient

from ..settings import Settings


class DellAIAConfigurationError(RuntimeError):
    """Raised when the Dell AIA-only runtime is configured incorrectly."""


class DellAIAAuthenticationError(RuntimeError):
    """Raised when Dell's aia-auth-client cannot provide a bearer token."""


def _extract_token(response: Any) -> str:
    """Extract the token from every response shape used by aia-auth-client.

    The known-working Commerce Knowledge Agent accepts a raw string, a mapping
    containing token/access_token/id_token, or an object exposing those fields.
    The previous disparity build only read ``response.token``. In environments
    where aia-auth-client returns a dict or ``access_token``, that caused a
    successful authentication operation to be misreported by the OpenAI adapter
    as ``APIConnectionError``.
    """

    if isinstance(response, str):
        token = response.strip()
    elif isinstance(response, dict):
        token = str(
            response.get("token")
            or response.get("access_token")
            or response.get("id_token")
            or ""
        ).strip()
    else:
        token = (
            getattr(response, "token", None)
            or getattr(response, "access_token", None)
            or getattr(response, "id_token", None)
            or ""
        )
        token = str(token).strip()

    if not token:
        raise DellAIAAuthenticationError(
            "Dell AIA authentication returned no bearer token in token, "
            "access_token, or id_token."
        )
    return token


def _extract_expiry(response: Any, default_seconds: int = 1800) -> int:
    raw = (
        response.get("expires_in", default_seconds)
        if isinstance(response, dict)
        else getattr(response, "expires_in", default_seconds)
    )
    try:
        value = int(raw or default_seconds)
    except (TypeError, ValueError):
        value = default_seconds
    return max(value, 300)


@dataclass
class _CachedToken:
    value: str
    valid_until: float


class DellAIATokenProvider:
    """Thread-safe token provider copied from the known-working Dell AIA app."""

    def __init__(self, client_id: str, client_secret: str, skew_seconds: int = 60) -> None:
        self.client_id = client_id
        self.client_secret = client_secret
        self.skew_seconds = max(0, int(skew_seconds))
        self._cached: _CachedToken | None = None
        self._lock = threading.RLock()

    def invalidate(self) -> None:
        with self._lock:
            self._cached = None

    def _fetch(self) -> _CachedToken:
        try:
            from aia_auth import auth as aia_auth
        except ImportError as exc:
            raise DellAIAAuthenticationError(
                "Dell's aia-auth-client package is not installed. Connect to "
                "Dell VPN and run scripts/install_dell_aia.ps1."
            ) from exc

        try:
            response = aia_auth.client_credentials(
                self.client_id,
                self.client_secret,
            )
        except Exception as exc:
            raise DellAIAAuthenticationError(
                f"Dell AIA client-credentials acquisition failed: {type(exc).__name__}: {exc}"
            ) from exc

        return _CachedToken(
            value=_extract_token(response),
            valid_until=time.time() + _extract_expiry(response),
        )

    def get_token(self, force_refresh: bool = False) -> str:
        with self._lock:
            now = time.time()
            if (
                not force_refresh
                and self._cached is not None
                and now < self._cached.valid_until - self.skew_seconds
            ):
                return self._cached.value
            self._cached = self._fetch()
            return self._cached.value

    def seconds_until_expiry(self) -> int:
        with self._lock:
            if self._cached is None:
                return 0
            return max(0, int(self._cached.valid_until - time.time()))


class DellAIARefreshingAuth(httpx.Auth):
    """Inject a Dell AIA bearer token and correlation ID on each request."""

    requires_request_body = True

    def __init__(self, provider: DellAIATokenProvider):
        self.provider = provider

    def auth_flow(self, request: httpx.Request):
        request.headers["Authorization"] = f"Bearer {self.provider.get_token()}"
        request.headers["x-correlation-id"] = str(uuid.uuid4())
        request.headers.setdefault("accept", "*/*")
        request.headers.setdefault("Content-Type", "application/json")
        response = yield request
        # A token can expire between creation of a long-running batch and the
        # actual model call. Refresh once on a real 401; do not retry 403/404,
        # because those indicate entitlement/routing rather than an expired token.
        if response is not None and response.status_code == 401:
            self.provider.invalidate()
            request.headers["Authorization"] = f"Bearer {self.provider.get_token(force_refresh=True)}"
            request.headers["x-correlation-id"] = str(uuid.uuid4())
            yield request


_SHARED_TOKEN_PROVIDER: DellAIATokenProvider | None = None
_SHARED_TOKEN_PROVIDER_KEY: str = ""
_SHARED_TOKEN_PROVIDER_LOCK = threading.RLock()


def _credential_key(settings: Settings) -> str:
    return hashlib.sha256(
        f"{settings.dell_aia_client_id}\0{settings.dell_aia_client_secret}".encode("utf-8")
    ).hexdigest()


def get_shared_token_provider(settings: Settings) -> DellAIATokenProvider:
    """Return one process-wide provider for the currently configured service account."""

    global _SHARED_TOKEN_PROVIDER, _SHARED_TOKEN_PROVIDER_KEY
    key = _credential_key(settings)
    with _SHARED_TOKEN_PROVIDER_LOCK:
        if _SHARED_TOKEN_PROVIDER is None or _SHARED_TOKEN_PROVIDER_KEY != key:
            _SHARED_TOKEN_PROVIDER = DellAIATokenProvider(
                settings.dell_aia_client_id,
                settings.dell_aia_client_secret,
                skew_seconds=60,
            )
            _SHARED_TOKEN_PROVIDER_KEY = key
        return _SHARED_TOKEN_PROVIDER


def invalidate_shared_token() -> None:
    with _SHARED_TOKEN_PROVIDER_LOCK:
        if _SHARED_TOKEN_PROVIDER is not None:
            _SHARED_TOKEN_PROVIDER.invalidate()


def dell_aia_credential_fingerprints(settings: Settings | None = None) -> dict[str, str]:
    """Return non-secret fingerprints for deployment comparison without leaking secrets."""

    resolved = settings or Settings()
    return {
        "client_id_sha256_12": hashlib.sha256(resolved.dell_aia_client_id.encode("utf-8")).hexdigest()[:12],
        "client_secret_sha256_12": hashlib.sha256(resolved.dell_aia_client_secret.encode("utf-8")).hexdigest()[:12],
    }


def is_model_route_not_found(exc: BaseException) -> bool:
    text = safe_exception_chain(exc).casefold()
    return "404" in text and (
        "unable to determine the url routes" in text
        or "chat/completions" in text
        or "notfounderror" in text
    )



def is_rate_limit_error(exc: BaseException) -> bool:
    """Identify Dell AIA/OpenAI-compatible 429 throttling without importing vendor exception classes."""
    text = safe_exception_chain(exc).casefold()
    return (
        "ratelimiterror" in text
        or "rate limit" in text
        or "too many requests" in text
        or "status_code=429" in text
        or " 429 " in text
        or "http 429" in text
    )


def rate_limit_retry_delay(settings: Settings, attempt: int, exc: BaseException | None = None) -> float:
    """Exponential backoff with a bounded delay for Dell AIA throttling."""
    base = max(0.5, float(getattr(settings, "dell_aia_rate_limit_base_delay_seconds", 2.0)))
    ceiling = max(base, float(getattr(settings, "dell_aia_rate_limit_max_delay_seconds", 30.0)))
    delay = min(ceiling, base * (2 ** max(0, int(attempt))))
    # Small deterministic staggering prevents every queued batch item from retrying on the same boundary.
    return delay + min(1.5, 0.15 * (attempt + 1))

def _validate_dell_aia_lock(settings: Settings) -> None:
    parsed = urlparse(settings.dell_aia_base_url)
    if parsed.scheme.lower() != "https":
        raise DellAIAConfigurationError("Dell AIA endpoint requires HTTPS.")
    if (parsed.hostname or "").lower() != settings.dell_aia_allowed_host.lower():
        raise DellAIAConfigurationError(
            "Dell AIA provider lock rejected a non-Dell endpoint. "
            f"Expected host {settings.dell_aia_allowed_host!r}."
        )
    if not settings.dell_aia_model.strip():
        raise DellAIAConfigurationError("DELL_AIA_MODEL is missing.")
    if not settings.dell_aia_client_id or not settings.dell_aia_client_secret:
        raise DellAIAConfigurationError(
            "Dell AIA credentials are missing. Set DELL_AIA_CLIENT_ID and "
            "DELL_AIA_CLIENT_SECRET or inject them from Vault."
        )


def dell_aia_model_info() -> dict[str, Any]:
    """The exact capability declaration used by the working reference app."""

    return {
        "vision": False,
        "function_calling": True,
        "json_output": True,
        "family": "unknown",
        "structured_output": False,
        "multiple_system_messages": True,
    }


def autogen_client_kwargs(settings: Settings) -> dict[str, Any]:
    """Build version-tolerant AutoGen arguments for Dell AIA."""

    kwargs: dict[str, Any] = {
        "model": settings.dell_aia_model,
        "base_url": settings.dell_aia_base_url.rstrip("/"),
        "temperature": settings.dell_aia_temperature,
        "model_info": dell_aia_model_info(),
        "parallel_tool_calls": False,
    }
    if "include_name_in_message" in inspect.signature(
        OpenAIChatCompletionClient.__init__
    ).parameters:
        kwargs["include_name_in_message"] = False
    return kwargs


async def build_model_client(
    settings: Settings, *, force_refresh_token: bool = False
) -> OpenAIChatCompletionClient:
    """Build Dell AIA using the exact proven integration pattern.

    Key compatibility choices copied from the successful Commerce Knowledge
    Agent:
      * flexible aia-auth-client token extraction;
      * Dell AIA bearer injection through httpx.Auth;
      * no custom gateway headers;
      * ``multiple_system_messages=True`` so the Dell AIA model can accept multi-message / multi-transaction agent turns;
      * ``parallel_tool_calls=False`` because the staged analysis/judge agents receive deterministic evidence and do not call tools;
      * runtime-generated adapter value only for AutoGen's OpenAI-compatible client contract.
    """

    _validate_dell_aia_lock(settings)
    timeout_seconds = max(120.0, float(settings.request_timeout_seconds))
    provider = get_shared_token_provider(settings)

    # Acquire once before AutoGen so credential failures are separated from model
    # routing failures. Bulk workers reuse this same cached token rather than
    # starting many concurrent client-credentials exchanges.
    provider.get_token(force_refresh=force_refresh_token)

    http_client = httpx.AsyncClient(
        auth=DellAIARefreshingAuth(provider),
        verify=certifi.where(),
        timeout=httpx.Timeout(timeout_seconds),
    )

    client = OpenAIChatCompletionClient(
        **autogen_client_kwargs(settings),
        # AutoGen's OpenAI-compatible adapter requires a non-empty ``api_key``
        # argument even though Dell AIA authentication is supplied by
        # ``DellAIARefreshingAuth``. Generate a process-local, non-persistent
        # adapter value instead of embedding any key-like literal in source.
        api_key=secrets.token_urlsafe(32),
        http_client=http_client,
        default_headers={"accept": "*/*", "Content-Type": "application/json"},
    )

    # Retain safe runtime handles for diagnostics and explicit cleanup.
    try:
        setattr(client, "_dell_aia_http_client", http_client)
        setattr(client, "_dell_aia_token_provider", provider)
    except Exception:
        pass
    return client


async def probe_dell_aia_runtime(settings: Settings, *, retry_route_once: bool = True) -> dict[str, Any]:
    """Run a real Dell AIA AutoGen probe without exposing credentials or tokens.

    The probe deliberately separates three stages: configuration, bearer-token
    acquisition, and model routing. A 404 from /chat/completions is therefore not
    misreported as a client-id/client-secret problem.
    """

    from autogen_agentchat.agents import AssistantAgent

    _validate_dell_aia_lock(settings)
    provider = get_shared_token_provider(settings)
    result: dict[str, Any] = {
        "provider": "Dell AIA",
        "model": settings.dell_aia_model,
        "base_url_host": settings.dell_aia_allowed_host,
        "credential_fingerprints": dell_aia_credential_fingerprints(settings),
        "token_acquisition": "NOT_RUN",
        "model_route": "NOT_RUN",
        "ok": False,
    }
    try:
        provider.get_token()
        result["token_acquisition"] = "SUCCESS"
    except Exception as exc:
        result.update({
            "token_acquisition": "FAILED",
            "error_code": "AIA_AUTH_REJECTED",
            "error": safe_exception_chain(exc),
        })
        return result

    attempts = 2 if retry_route_once else 1
    last_exc: BaseException | None = None
    for attempt in range(attempts):
        client = None
        try:
            client = await build_model_client(settings, force_refresh_token=attempt > 0)
            agent = AssistantAgent(
                name="dell_aia_preflight",
                model_client=client,
                system_message="Reply exactly with DELL_AIA_READY and nothing else.",
            )
            response = await agent.run(task="Dell AIA preflight")
            messages = getattr(response, "messages", []) or []
            text = ""
            for message in reversed(messages):
                content = getattr(message, "content", None)
                if isinstance(content, str) and content.strip():
                    text = content.strip()
                    break
            result.update({
                "ok": bool(text),
                "model_route": "SUCCESS" if text else "EMPTY_RESPONSE",
                "response_marker_seen": "DELL_AIA_READY" in text,
                "attempts": attempt + 1,
                "token_cache_seconds": provider.seconds_until_expiry(),
            })
            return result
        except Exception as exc:
            last_exc = exc
            if attempt == 0 and retry_route_once and is_model_route_not_found(exc):
                invalidate_shared_token()
                time.sleep(1.0)
                continue
            break
        finally:
            if client is not None:
                try:
                    await close_model_client(client)
                except Exception:
                    pass

    detail = safe_exception_chain(last_exc or RuntimeError("Unknown Dell AIA preflight failure"))
    if last_exc is not None and is_model_route_not_found(last_exc):
        result.update({
            "error_code": "AIA_MODEL_ROUTE_NOT_FOUND",
            "model_route": "FAILED_404",
            "error": detail,
            "recommended_action": (
                "Token acquisition succeeded, so the client ID/secret are not the failing stage. "
                "The Dell AIA gateway could not route the configured model. Confirm model entitlement/routing, then retry."
            ),
        })
    else:
        result.update({
            "error_code": "AIA_MODEL_PROBE_FAILED",
            "model_route": "FAILED",
            "error": detail,
        })
    return result


async def close_model_client(client: OpenAIChatCompletionClient | None) -> None:
    """Close both AutoGen and its custom httpx transport safely."""

    if client is None:
        return
    transport = getattr(client, "_dell_aia_http_client", None)
    try:
        await client.close()
    finally:
        if transport is not None:
            try:
                await transport.aclose()
            except Exception:
                pass


def safe_exception_chain(exc: BaseException, settings: Settings | None = None) -> str:
    """Return a redacted cause chain so wrapped connection failures are useful."""

    resolved = settings or Settings()
    secrets_to_hide = (resolved.dell_aia_client_id, resolved.dell_aia_client_secret)
    parts: list[str] = []
    current: BaseException | None = exc
    seen: set[int] = set()
    while current is not None and id(current) not in seen and len(parts) < 6:
        seen.add(id(current))
        text = str(current)
        for secret in secrets_to_hide:
            if secret:
                text = text.replace(secret, "[REDACTED]")
        text = re.sub(
            r"(?i)Bearer\s+[A-Za-z0-9._~+\-/]+=*",
            "Bearer [REDACTED]",
            text,
        )
        parts.append(f"{type(current).__name__}: {text}".strip())
        current = current.__cause__ or current.__context__
    return " <- ".join(parts)[:2000]


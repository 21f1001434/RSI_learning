from __future__ import annotations

from typing import Any


__all__ = ["AgenticOrchestrator"]


def __getattr__(name: str) -> Any:
    if name == "AgenticOrchestrator":
        from .orchestrator import AgenticOrchestrator

        return AgenticOrchestrator
    raise AttributeError(name)

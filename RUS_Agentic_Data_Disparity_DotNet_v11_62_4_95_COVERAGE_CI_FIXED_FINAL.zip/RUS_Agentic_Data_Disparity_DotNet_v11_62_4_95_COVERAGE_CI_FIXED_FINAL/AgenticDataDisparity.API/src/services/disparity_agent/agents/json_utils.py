from __future__ import annotations

import ast
import json
import re
from dataclasses import dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class JsonExtractionResult:
    value: dict[str, Any]
    mode: str
    source_text: str


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            return json.dumps(model_dump(mode="json"), default=str)
        except Exception:
            try:
                return json.dumps(model_dump(), default=str)
            except Exception:
                pass
    if isinstance(value, (dict, list, tuple)):
        try:
            return json.dumps(value, default=str)
        except Exception:
            return str(value)
    return str(value)


def message_content(message: Any) -> str:
    return _as_text(getattr(message, "content", message))


def last_substantive_message(messages: Iterable[Any]) -> str:
    """Return the last non-empty model text from an AutoGen result.

    AutoGen task results may end with a tool summary, a structured message, or an
    event whose ``content`` is not a plain string. The earlier implementation read
    only ``messages[-1]`` and therefore sometimes tried to parse an event instead of
    the Dell AIA final answer.
    """

    candidates: list[str] = []
    for message in messages:
        text = message_content(message).strip()
        if not text:
            continue
        candidates.append(text)

    for text in reversed(candidates):
        lowered = text.casefold()
        # Prefer content that looks like an answer rather than a bare tool event.
        if any(token in text for token in ("{", "[", "summary", "analysis", "verdict")):
            return text
        if not any(marker in lowered for marker in ("toolcallrequest", "functioncall", "toolexecution")):
            return text
    return candidates[-1] if candidates else ""


def all_message_text(messages: Iterable[Any], *, max_chars: int = 100_000) -> str:
    parts: list[str] = []
    total = 0
    for message in messages:
        text = message_content(message).strip()
        if not text:
            continue
        if total + len(text) > max_chars:
            remaining = max_chars - total
            if remaining > 0:
                parts.append(text[:remaining])
            break
        parts.append(text)
        total += len(text)
    return "\n\n--- AUTO-GEN MESSAGE ---\n\n".join(parts)


def _strip_code_fence(text: str) -> str:
    fenced = re.search(r"```(?:json|javascript|js|python)?\s*(.*?)\s*```", text, flags=re.DOTALL | re.IGNORECASE)
    return fenced.group(1).strip() if fenced else text.strip()


def _balanced_objects(text: str) -> list[str]:
    """Extract balanced JSON-like objects while respecting quoted strings."""

    objects: list[str] = []
    start: int | None = None
    depth = 0
    in_string = False
    quote = ""
    escaped = False

    for idx, char in enumerate(text):
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                in_string = False
            continue

        if char in ('"', "'"):
            in_string = True
            quote = char
            continue

        if char == "{":
            if depth == 0:
                start = idx
            depth += 1
        elif char == "}" and depth:
            depth -= 1
            if depth == 0 and start is not None:
                objects.append(text[start : idx + 1])
                start = None
    return objects


def _normalise_jsonish(text: str) -> str:
    text = text.replace("\ufeff", "").strip()
    text = text.translate(
        str.maketrans(
            {
                "“": '"',
                "”": '"',
                "„": '"',
                "‟": '"',
                "’": "'",
                "‘": "'",
                "–": "-",
                "—": "-",
                "\u00a0": " ",
            }
        )
    )
    # Remove JavaScript-style comments and trailing commas without touching quoted text
    # in the common Dell AIA response shapes.
    text = re.sub(r"(?m)^\s*//.*$", "", text)
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    text = re.sub(r",\s*([}\]])", r"\1", text)
    return text.strip()


def _loads_candidate(candidate: str) -> dict[str, Any] | None:
    candidate = _normalise_jsonish(candidate)
    if not candidate:
        return None

    try:
        value = json.loads(candidate)
        return value if isinstance(value, dict) else None
    except Exception:
        pass

    # Dell/local models occasionally emit Python-dict syntax. This is safe because
    # literal_eval evaluates literals only and cannot execute arbitrary code.
    pythonish = re.sub(r"\btrue\b", "True", candidate, flags=re.IGNORECASE)
    pythonish = re.sub(r"\bfalse\b", "False", pythonish, flags=re.IGNORECASE)
    pythonish = re.sub(r"\bnull\b", "None", pythonish, flags=re.IGNORECASE)
    try:
        value = ast.literal_eval(pythonish)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def extract_json_with_mode(text: str) -> JsonExtractionResult:
    original = (text or "").strip()
    if not original:
        raise ValueError("Model response was empty")

    direct = _loads_candidate(original)
    if direct is not None:
        return JsonExtractionResult(direct, "direct", original)

    unfenced = _strip_code_fence(original)
    if unfenced != original:
        value = _loads_candidate(unfenced)
        if value is not None:
            return JsonExtractionResult(value, "code_fence", unfenced)

    candidates = _balanced_objects(unfenced)
    # Prefer the largest object because it is normally the complete answer envelope.
    for candidate in sorted(candidates, key=len, reverse=True):
        value = _loads_candidate(candidate)
        if value is not None:
            return JsonExtractionResult(value, "balanced_object", candidate)

    # Last resort: the old first/last brace slice, but with tolerant parsing.
    start = unfenced.find("{")
    end = unfenced.rfind("}")
    if start >= 0 and end > start:
        candidate = unfenced[start : end + 1]
        value = _loads_candidate(candidate)
        if value is not None:
            return JsonExtractionResult(value, "brace_slice", candidate)

    raise ValueError("Model response did not contain a parseable JSON object")


def extract_json(text: str) -> dict[str, Any]:
    return extract_json_with_mode(text).value

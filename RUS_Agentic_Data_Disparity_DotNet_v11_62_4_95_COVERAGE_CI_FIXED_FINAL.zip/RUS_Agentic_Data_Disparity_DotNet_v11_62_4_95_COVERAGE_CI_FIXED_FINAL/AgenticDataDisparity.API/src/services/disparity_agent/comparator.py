from __future__ import annotations

from typing import Any

from .country_reference import get_country_reference
from .field_mapping import source_supports
from .models import AttributeObservation, AttributeVerdict, SourceName, SourceRecord
from .normalization import is_present, normalize
from .settings import Settings


TRUTH_ORDER = [SourceName.CPS, SourceName.REWARDS_DB]


def _observations(
    attribute: str,
    spec: dict[str, Any],
    records: dict[SourceName, SourceRecord],
) -> dict[SourceName, AttributeObservation]:
    data_type = str(spec.get("type", "text_ci"))
    output: dict[SourceName, AttributeObservation] = {}
    for source in SourceName:
        supported = source_supports(spec, source)
        record = records.get(source)
        source_connected = bool(record and record.status.connected)
        record_found = bool(record and record.status.data_found)
        raw_value = record.canonical.get(attribute) if record and record_found else None
        normalized = normalize(raw_value, data_type) if supported else normalize(None, data_type)
        output[source] = AttributeObservation(
            source=source,
            supported=supported,
            present=supported and record_found and is_present(raw_value),
            source_connected=source_connected,
            record_found=record_found,
            raw_value=raw_value,
            normalized_value=normalized.value,
            valid_format=normalized.valid,
            normalization_note=normalized.note,
        )
    return output


def _record_unavailable_sources(
    observations: dict[SourceName, AttributeObservation],
    sources: list[SourceName] | None = None,
) -> list[SourceName]:
    candidates = sources or list(SourceName)
    return [
        source
        for source in candidates
        if observations[source].supported and not observations[source].record_found
    ]


def _record_gap_status(
    observations: dict[SourceName, AttributeObservation],
    sources: list[SourceName],
) -> str:
    return (
        "SOURCE_UNAVAILABLE"
        if any(not observations[source].source_connected for source in sources)
        else "SOURCE_RECORD_MISSING"
    )


def _unverifiable(
    attribute: str,
    label: str,
    observations: dict[SourceName, AttributeObservation],
    explanation: str,
) -> AttributeVerdict:
    unavailable = _record_unavailable_sources(observations)
    return AttributeVerdict(
        attribute=attribute,
        label=label,
        status=_record_gap_status(observations, unavailable) if unavailable else "UNVERIFIABLE",
        observations=observations,
        unavailable_sources=unavailable,
        explanation=explanation,
    )


def _compare_standard(
    attribute: str,
    label: str,
    observations: dict[SourceName, AttributeObservation],
    settings: Settings,
) -> AttributeVerdict:
    truth_source: SourceName | None = next(
        (source for source in TRUTH_ORDER if observations[source].present),
        None,
    )
    if (
        truth_source is None
        and settings.allow_crowd_twist_as_last_resort
        and observations[SourceName.CROWD_TWIST].present
    ):
        truth_source = SourceName.CROWD_TWIST

    if truth_source is None:
        return _unverifiable(
            attribute,
            label,
            observations,
            "Neither CPS nor Rewards DB provides an authoritative value for this attribute.",
        )

    truth_obs = observations[truth_source]
    wrong_sources: list[SourceName] = []
    missing_sources: list[SourceName] = []
    unavailable_sources: list[SourceName] = []
    invalid_sources: list[SourceName] = []
    for source, observation in observations.items():
        if not observation.supported or source == truth_source:
            continue
        if not observation.record_found:
            unavailable_sources.append(source)
            continue
        if not observation.present:
            if settings.flag_missing_supported_attributes:
                missing_sources.append(source)
            continue
        if not observation.valid_format:
            invalid_sources.append(source)
            wrong_sources.append(source)
            continue
        if observation.normalized_value != truth_obs.normalized_value:
            wrong_sources.append(source)

    if not truth_obs.valid_format:
        status = "TRUTH_FORMAT_INVALID"
        explanation = f"The authoritative {truth_source.value} value is present but has an invalid format."
    elif invalid_sources:
        status = "INVALID_FORMAT"
        explanation = f"{', '.join(source.value for source in invalid_sources)} contains an invalidly formatted value."
    elif wrong_sources:
        status = "MISMATCH"
        explanation = (
            f"{truth_source.value} is authoritative for {label}; "
            f"{', '.join(source.value for source in wrong_sources)} differs after normalization."
        )
    elif missing_sources:
        status = "MISSING"
        explanation = (
            f"The authoritative value exists in {truth_source.value}, but the attribute is missing from an existing record in "
            f"{', '.join(source.value for source in missing_sources)}."
        )
    elif unavailable_sources:
        status = _record_gap_status(observations, unavailable_sources)
        explanation = (
            f"{truth_source.value} provides the authoritative {label}, but the member record was not available in "
            f"{', '.join(source.value for source in unavailable_sources)}. Field-level comparison and update suggestions are deferred "
            "until those source records exist and can be retrieved."
        )
    else:
        status = "MATCH"
        explanation = f"All available supported values agree with {truth_source.value}."

    return AttributeVerdict(
        attribute=attribute,
        label=label,
        truth_source=truth_source,
        truth_value=truth_obs.raw_value,
        status=status,
        observations=observations,
        wrong_sources=wrong_sources,
        missing_sources=missing_sources,
        unavailable_sources=unavailable_sources,
        explanation=explanation,
    )


def _compare_crowd_twist_id(
    attribute: str,
    label: str,
    observations: dict[SourceName, AttributeObservation],
    settings: Settings,
) -> AttributeVerdict:
    """CrowdTwist owns the CrowdTwist ID; Rewards DB stores a synchronized copy."""

    truth_source = SourceName.CROWD_TWIST
    truth_obs = observations[truth_source]
    db_obs = observations[SourceName.REWARDS_DB]

    if not truth_obs.record_found:
        unavailable = [SourceName.CROWD_TWIST]
        return AttributeVerdict(
            attribute=attribute,
            label=label,
            status=_record_gap_status(observations, unavailable),
            observations=observations,
            unavailable_sources=unavailable,
            explanation=(
                "The CrowdTwist member record was not found or could not be retrieved. CrowdTwist ID verification is deferred; "
                "do not create a Rewards DB field update until the CrowdTwist member exists and returns its own ID."
            ),
        )
    if not truth_obs.present:
        return _unverifiable(
            attribute,
            label,
            observations,
            "The CrowdTwist member exists but did not return its own member ID, so the Rewards DB CrowdTwistID cannot be verified.",
        )
    if not truth_obs.valid_format:
        return AttributeVerdict(
            attribute=attribute,
            label=label,
            truth_source=truth_source,
            truth_value=truth_obs.raw_value,
            status="TRUTH_FORMAT_INVALID",
            observations=observations,
            explanation="The CrowdTwist API returned an invalid CrowdTwist ID; do not copy it into Rewards DB.",
        )
    if not db_obs.record_found:
        unavailable = [SourceName.REWARDS_DB]
        return AttributeVerdict(
            attribute=attribute,
            label=label,
            truth_source=truth_source,
            truth_value=truth_obs.raw_value,
            status=_record_gap_status(observations, unavailable),
            observations=observations,
            unavailable_sources=unavailable,
            explanation=(
                "CrowdTwist returned the authoritative CrowdTwist ID, but no Rewards DB member record was available. "
                "Resolve the missing Rewards member record before attempting to synchronize the ID."
            ),
        )
    if not db_obs.present:
        missing = [SourceName.REWARDS_DB] if settings.flag_missing_supported_attributes else []
        return AttributeVerdict(
            attribute=attribute,
            label=label,
            truth_source=truth_source,
            truth_value=truth_obs.raw_value,
            status="MISSING" if missing else "MATCH",
            observations=observations,
            missing_sources=missing,
            explanation=(
                "CrowdTwist is authoritative for CrowdTwist ID and the existing Rewards DB member record is missing the synchronized ID."
                if missing
                else "CrowdTwist returned the authoritative CrowdTwist ID."
            ),
        )
    if not db_obs.valid_format:
        return AttributeVerdict(
            attribute=attribute,
            label=label,
            truth_source=truth_source,
            truth_value=truth_obs.raw_value,
            status="INVALID_FORMAT",
            observations=observations,
            wrong_sources=[SourceName.REWARDS_DB],
            explanation="Rewards DB contains an invalid CrowdTwistID; use the ID returned by the CrowdTwist API.",
        )
    if db_obs.normalized_value != truth_obs.normalized_value:
        return AttributeVerdict(
            attribute=attribute,
            label=label,
            truth_source=truth_source,
            truth_value=truth_obs.raw_value,
            status="MISMATCH",
            observations=observations,
            wrong_sources=[SourceName.REWARDS_DB],
            explanation=(
                "CrowdTwist is the source of truth for CrowdTwist ID. "
                "The Rewards DB CrowdTwistID must be changed to the ID returned by CrowdTwist."
            ),
        )
    return AttributeVerdict(
        attribute=attribute,
        label=label,
        truth_source=truth_source,
        truth_value=truth_obs.raw_value,
        status="MATCH",
        observations=observations,
        explanation="Rewards DB CrowdTwistID matches the authoritative ID returned by CrowdTwist.",
    )


def _compare_active_or(
    attribute: str,
    label: str,
    observations: dict[SourceName, AttributeObservation],
    settings: Settings,
) -> AttributeVerdict:
    """Active status follows OR semantics across Rewards DB and CrowdTwist.

    If either system is True, the desired synchronized state is True and any False
    side is the correction target. Both False and both True are valid matches.
    """

    supported = [SourceName.REWARDS_DB, SourceName.CROWD_TWIST]
    unavailable_sources = [source for source in supported if not observations[source].record_found]
    present = [source for source in supported if observations[source].present]
    if not present:
        if unavailable_sources:
            return AttributeVerdict(
                attribute=attribute,
                label=label,
                status=_record_gap_status(observations, unavailable_sources),
                observations=observations,
                unavailable_sources=unavailable_sources,
                explanation=(
                    "The Active Status OR rule cannot be evaluated because the member record was not available in "
                    f"{', '.join(source.value for source in unavailable_sources)}. Resolve record availability first."
                ),
            )
        return _unverifiable(
            attribute,
            label,
            observations,
            "Neither existing Rewards DB nor CrowdTwist record returned Active Status, so the OR rule cannot be evaluated.",
        )

    invalid = [source for source in present if not observations[source].valid_format]
    valid = [source for source in present if observations[source].valid_format]
    true_sources = [source for source in valid if observations[source].normalized_value is True]

    if invalid and not true_sources:
        return AttributeVerdict(
            attribute=attribute,
            label=label,
            status="BOOLEAN_REVIEW_REQUIRED",
            observations=observations,
            wrong_sources=invalid,
            explanation=(
                "The Active Status OR rule cannot be resolved safely because at least one present value is invalid "
                "and no valid True value is available."
            ),
        )

    desired = bool(true_sources)
    truth_source = true_sources[0] if true_sources else (valid[0] if valid else None)
    wrong_sources = [
        source
        for source in valid
        if bool(observations[source].normalized_value) != desired
    ] + invalid
    missing_sources = [
        source for source in supported
        if observations[source].record_found and not observations[source].present
    ] if settings.flag_missing_supported_attributes else []

    if invalid:
        status = "INVALID_FORMAT"
    elif wrong_sources:
        status = "MISMATCH"
    elif missing_sources:
        status = "MISSING"
    elif unavailable_sources:
        status = _record_gap_status(observations, unavailable_sources)
    else:
        status = "MATCH"

    if status == "MATCH":
        explanation = (
            f"Rewards DB and CrowdTwist satisfy the Active Status OR rule; both evaluate to {desired}."
        )
    elif status == "MISMATCH":
        explanation = (
            "Active Status uses OR semantics: if either Rewards DB or CrowdTwist is True, the synchronized result is True. "
            f"Change the False value in {', '.join(source.value for source in wrong_sources)} to True."
        )
    elif status == "MISSING":
        explanation = (
            "Active Status uses OR semantics, but an existing supported record is missing the value; review before synchronization."
        )
    elif status in {"SOURCE_RECORD_MISSING", "SOURCE_UNAVAILABLE"}:
        explanation = (
            "Active Status OR evaluation is incomplete because a required member record is unavailable in "
            f"{', '.join(source.value for source in unavailable_sources)}. Do not issue a field-level status update yet."
        )
    else:
        explanation = "One Active Status value is invalid; the valid True side still establishes an OR result of True."

    return AttributeVerdict(
        attribute=attribute,
        label=label,
        truth_source=truth_source,
        truth_value=desired,
        status=status,
        observations=observations,
        wrong_sources=wrong_sources,
        missing_sources=missing_sources,
        unavailable_sources=unavailable_sources,
        explanation=explanation,
    )


def _compare_country(
    attribute: str,
    label: str,
    observations: dict[SourceName, AttributeObservation],
    settings: Settings,
    *,
    crowd_twist_country_code_visible: bool = False,
) -> AttributeVerdict:
    """Apply CPS-first country truth and enforce ISO-code storage in CrowdTwist.

    Policy:
    * When CPS supplies an exact country, CPS directly determines the ISO code.
    * When CPS supplies a broad region such as ``UsCanada``, CPS remains the
      source of truth. Rewards DB may only disambiguate an exact code that belongs
      to the CPS-approved candidate set.
    * Rewards DB becomes fallback truth only when CPS has no country value.
    * CrowdTwist must store the canonical two-letter ISO code, not merely a country
      name that normalizes to the same code.
    """

    ref = get_country_reference()
    cps = observations[SourceName.CPS]
    db = observations[SourceName.REWARDS_DB]
    ct = observations[SourceName.CROWD_TWIST]

    cps_match = ref.match(cps.raw_value) if cps.present else ref.match(None)
    db_match = ref.match(db.raw_value) if db.present else ref.match(None)
    ct_match = ref.match(ct.raw_value) if ct.present else ref.match(None)

    expected: str | None = None
    truth_source: SourceName | None = None
    db_conflict = False
    policy_note = ""

    if cps_match.code:
        expected = cps_match.code
        truth_source = SourceName.CPS
        if db_match.code and db_match.code != expected:
            db_conflict = True
            policy_note = (
                f"CPS is authoritative and resolves to {expected}, while Rewards DB resolves to "
                f"{db_match.code}. CPS remains the country source of truth."
            )
        else:
            policy_note = f"CPS is authoritative and resolves to exact ISO country code {expected}."
    elif cps_match.kind == "broad_region":
        truth_source = SourceName.CPS
        if db_match.code and db_match.code in cps_match.candidates:
            expected = db_match.code
            policy_note = (
                f"CPS is authoritative for Country. CPS region {cps.raw_value!r} permits "
                f"{sorted(cps_match.candidates)}; Rewards DB only disambiguates the exact code "
                f"{db_match.code} within that CPS-approved region."
            )
        elif db_match.code:
            return AttributeVerdict(
                attribute=attribute,
                label=label,
                truth_source=SourceName.CPS,
                status="COUNTRY_SOURCE_CONFLICT",
                observations=observations,
                wrong_sources=[SourceName.REWARDS_DB],
                explanation=(
                    f"CPS is authoritative for Country and region {cps.raw_value!r} permits "
                    f"{sorted(cps_match.candidates)}, but Rewards DB resolves to {db_match.code}. "
                    "Reconcile Rewards DB against CPS before changing CrowdTwist."
                ),
            )
        else:
            unavailable = _record_unavailable_sources(
                observations,
                [SourceName.REWARDS_DB, SourceName.CROWD_TWIST],
            )
            return AttributeVerdict(
                attribute=attribute,
                label=label,
                truth_source=SourceName.CPS,
                status="COUNTRY_REVIEW_REQUIRED",
                observations=observations,
                unavailable_sources=unavailable,
                explanation=(
                    f"CPS is authoritative but returned broad region {cps.raw_value!r}. Rewards DB did not provide "
                    "a valid exact country within that region, so a single ISO code cannot be selected safely for CrowdTwist. "
                    + (
                        "One or more member records are also unavailable; resolve record availability before country synchronization."
                        if unavailable else ""
                    )
                ),
            )
    elif cps.present:
        return AttributeVerdict(
            attribute=attribute,
            label=label,
            truth_source=SourceName.CPS,
            truth_value=cps.raw_value,
            status="TRUTH_FORMAT_INVALID",
            observations=observations,
            explanation=(
                "CPS is the country source of truth, but its country/region is not recognized by the uploaded "
                "CrowdTwist country reference. Correct or map CPS before synchronizing CrowdTwist."
            ),
        )
    elif db_match.code:
        expected = db_match.code
        truth_source = SourceName.REWARDS_DB
        policy_note = (
            f"CPS has no Country value, so Rewards DB fallback resolves the CrowdTwist ISO code to {expected}."
        )
    elif db.present:
        return AttributeVerdict(
            attribute=attribute,
            label=label,
            truth_source=SourceName.REWARDS_DB,
            truth_value=db.raw_value,
            status="TRUTH_FORMAT_INVALID",
            observations=observations,
            explanation=(
                "CPS has no Country value and the Rewards DB fallback country is not recognized by the "
                "CrowdTwist country reference CSV."
            ),
        )
    else:
        return _unverifiable(
            attribute,
            label,
            observations,
            "Neither CPS nor Rewards DB supplied country evidence that can resolve a CrowdTwist ISO code.",
        )

    assert expected is not None
    wrong_sources: list[SourceName] = []
    missing_sources: list[SourceName] = []
    unavailable_sources: list[SourceName] = []
    country_format_sources: list[SourceName] = []
    semantic_mismatch = False

    if db_conflict:
        wrong_sources.append(SourceName.REWARDS_DB)

    if not ct.record_found:
        unavailable_sources.append(SourceName.CROWD_TWIST)
    elif not ct.present:
        if settings.flag_missing_supported_attributes:
            missing_sources.append(SourceName.CROWD_TWIST)
    elif not ct_match.code:
        country_format_sources.append(SourceName.CROWD_TWIST)
        wrong_sources.append(SourceName.CROWD_TWIST)
    elif ct_match.code != expected:
        semantic_mismatch = True
        wrong_sources.append(SourceName.CROWD_TWIST)
    elif not ref.is_canonical_code(ct.raw_value, expected):
        # Some CrowdTwist read contracts expose only the display ``country``
        # (for example ``United States``) even when the writable storage field is
        # ``country_code=US``.  If the read payload does not expose country_code
        # at all, a display name that semantically resolves to the expected ISO
        # country is not evidence of bad storage format and must not create an
        # endless false correction loop after a successful manual/Agentic write.
        # If country_code *is* visible, keep the strict canonical-code check.
        if crowd_twist_country_code_visible:
            country_format_sources.append(SourceName.CROWD_TWIST)
            wrong_sources.append(SourceName.CROWD_TWIST)

    if db_conflict:
        status = "COUNTRY_SOURCE_CONFLICT"
    elif semantic_mismatch:
        status = "MISMATCH"
    elif country_format_sources:
        status = "INVALID_FORMAT"
    elif missing_sources:
        status = "MISSING"
    elif unavailable_sources:
        status = _record_gap_status(observations, unavailable_sources)
    else:
        status = "MATCH"

    if status == "MATCH":
        if ct.present and not ref.is_canonical_code(ct.raw_value, expected) and not crowd_twist_country_code_visible:
            explanation = (
                f"{policy_note} CrowdTwist resolves to the expected country {expected}. "
                "The current CrowdTwist read contract exposes the display country rather than country_code, "
                "so no format-only correction is generated from that display representation."
            )
        else:
            explanation = (
                f"{policy_note} CrowdTwist stores the required canonical ISO code {expected}."
            )
    elif db_conflict:
        explanation = (
            f"{policy_note} CrowdTwist must use {expected}; the conflicting Rewards DB country requires separate review."
        )
    elif semantic_mismatch:
        explanation = (
            f"{policy_note} CrowdTwist resolves to {ct_match.code or 'an unknown country'} and must be changed "
            f"to ISO code {expected} according to the uploaded country reference CSV."
        )
    elif country_format_sources:
        explanation = (
            f"{policy_note} CrowdTwist currently stores {ct.raw_value!r}, which represents the same country but is "
            f"not the required ISO-code format. Change it to {expected}."
        )
    elif status in {"SOURCE_RECORD_MISSING", "SOURCE_UNAVAILABLE"}:
        explanation = (
            f"{policy_note} The CrowdTwist member record is unavailable, so Country cannot be compared or updated at field level. "
            "Resolve/onboard the member record first, then re-run to produce an exact ISO-code correction if needed."
        )
    else:
        explanation = (
            f"{policy_note} The existing CrowdTwist member record is missing Country and must be populated with ISO code {expected}."
        )

    return AttributeVerdict(
        attribute=attribute,
        label=label,
        truth_source=truth_source,
        truth_value=expected,
        status=status,
        observations=observations,
        wrong_sources=wrong_sources,
        missing_sources=missing_sources,
        unavailable_sources=unavailable_sources,
        explanation=explanation,
    )


def compare_records(
    records: dict[SourceName, SourceRecord],
    field_map: dict[str, Any],
    settings: Settings,
) -> list[AttributeVerdict]:
    verdicts: list[AttributeVerdict] = []
    for attribute, spec in field_map.items():
        label = str(spec.get("label", attribute))
        observations = _observations(attribute, spec, records)
        policy = str(spec.get("policy", "standard"))

        if policy == "crowd_twist_authoritative":
            verdict = _compare_crowd_twist_id(attribute, label, observations, settings)
        elif policy == "boolean_or":
            verdict = _compare_active_or(attribute, label, observations, settings)
        elif policy == "crowd_twist_country_code":
            ct_record = records.get(SourceName.CROWD_TWIST)
            ct_raw = ct_record.raw if ct_record and isinstance(ct_record.raw, dict) else {}
            ct_country_code_visible = any(
                str(key).replace("_", "").casefold() == "countrycode"
                and value is not None
                and not (isinstance(value, str) and not value.strip())
                for key, value in ct_raw.items()
            )
            verdict = _compare_country(
                attribute,
                label,
                observations,
                settings,
                crowd_twist_country_code_visible=ct_country_code_visible,
            )
        else:
            verdict = _compare_standard(attribute, label, observations, settings)
        verdicts.append(verdict)
    return verdicts

from __future__ import annotations

import base64
import json
import time
from dataclasses import dataclass, field
from time import perf_counter
from typing import Any
from urllib.parse import urlparse

import httpx

from ..settings import Settings


@dataclass(slots=True)
class TCPSCountryResult:
    connected: bool
    data_found: bool
    country: str | None = None
    latency_ms: int = 0
    stage: str = "not_started"
    error_code: str | None = None
    http_status: int | None = None
    endpoint_host: str | None = None
    diagnostic_hint: str | None = None
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def as_diagnostics(self) -> dict[str, Any]:
        return {
            "service": "tCPS / Dell Identity User Provisioning",
            "operation": "POST /userprovisioning/v1/Users/.search",
            "connected": self.connected,
            "data_found": self.data_found,
            "country_found": bool(self.country),
            "latency_ms": self.latency_ms,
            "stage": self.stage,
            "error_code": self.error_code,
            "http_status": self.http_status,
            "endpoint_host": self.endpoint_host,
            "diagnostic_hint": self.diagnostic_hint,
            **self.diagnostics,
        }


def _endpoint_host(url: str) -> str | None:
    try:
        return urlparse(url).hostname
    except Exception:
        return None


def _decode_jwt_exp(token: str) -> int | None:
    """Read the JWT exp claim without validating or logging the token."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        padded = parts[1] + "=" * (-len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded.encode("ascii")))
        exp = payload.get("exp")
        return int(exp) if exp is not None else None
    except Exception:
        return None


def _escape_scim_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _dict_get_ci(data: dict[str, Any], key: str) -> Any:
    if key in data:
        return data[key]
    folded = key.casefold()
    for candidate, value in data.items():
        if str(candidate).casefold() == folded:
            return value
    return None


def _extract_default_country(payload: Any, attribute_urn: str) -> str | None:
    """Support flat full-URN and normal SCIM extension-object response shapes."""
    if not isinstance(payload, dict):
        return None

    resources = _dict_get_ci(payload, "Resources")
    if not isinstance(resources, list) or not resources:
        return None
    resource = resources[0]
    if not isinstance(resource, dict):
        return None

    flat = _dict_get_ci(resource, attribute_urn)
    if flat not in (None, ""):
        return str(flat).strip()

    if ":" in attribute_urn:
        extension_urn, leaf = attribute_urn.rsplit(":", 1)
        extension = _dict_get_ci(resource, extension_urn)
        if isinstance(extension, dict):
            nested = _dict_get_ci(extension, leaf)
            if nested not in (None, ""):
                return str(nested).strip()

    # Dell responses can also expose the requested leaf directly.
    direct = _dict_get_ci(resource, "defaultCountry")
    if direct not in (None, ""):
        return str(direct).strip()
    return None


class TCPSCountryConnector:
    """Read exact member country from Dell Identity's SCIM-style tCPS search API.

    This is a supplemental CPS lookup. Failure never converts a successful CPS
    member lookup into a failed CPS source. Instead, diagnostics are attached to
    the CPS record and the existing CPS-region/Rewards-DB resolution remains the
    fallback.
    """

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    async def fetch_default_country(
        self,
        email: str,
        *,
        bearer_token: str | None = None,
        token_source: str | None = None,
    ) -> TCPSCountryResult:
        started = perf_counter()
        url = self.settings.tcps_search_url
        host = _endpoint_host(url)

        if not self.settings.tcps_enabled:
            return TCPSCountryResult(
                connected=False,
                data_found=False,
                stage="disabled",
                error_code="TCPS_DISABLED",
                endpoint_host=host,
                diagnostic_hint="tCPS country enrichment is disabled by configuration.",
            )
        if not email or "@" not in email:
            return TCPSCountryResult(
                connected=False,
                data_found=False,
                stage="identifier_resolution",
                error_code="TCPS_EMAIL_REQUIRED",
                endpoint_host=host,
                diagnostic_hint="A member email is required for the tCPS SCIM filter.",
            )

        explicit_token = (bearer_token or "").strip()
        configured_token = (self.settings.tcps_bearer_token or "").strip()
        token = explicit_token or configured_token
        resolved_token_source = (
            token_source
            if explicit_token
            else ("tcps_bearer_token_override" if configured_token else None)
        )
        if not token:
            return TCPSCountryResult(
                connected=False,
                data_found=False,
                stage="authentication",
                error_code="TCPS_BEARER_TOKEN_MISSING",
                endpoint_host=host,
                diagnostics={
                    "token_source": "none",
                    "cps_token_reuse_enabled": self.settings.tcps_use_cps_bearer_token,
                },
                diagnostic_hint=(
                    "No bearer token reached the tCPS connector. Run tCPS through the CPS connector so the "
                    "fresh CPS OAuth token can be reused, or configure TCPS_BEARER_TOKEN as a dedicated override."
                ),
            )

        exp = _decode_jwt_exp(token)
        if exp is not None and exp <= int(time.time()):
            return TCPSCountryResult(
                connected=False,
                data_found=False,
                stage="authentication",
                error_code="TCPS_BEARER_TOKEN_EXPIRED",
                endpoint_host=host,
                diagnostics={
                    "token_expiry_epoch": exp,
                    "token_source": resolved_token_source or "unknown",
                },
                diagnostic_hint=(
                    "The selected bearer token is expired. The CPS runtime token should refresh automatically; "
                    "if an explicit TCPS_BEARER_TOKEN override is configured, replace or remove it."
                ),
            )

        attribute = self.settings.tcps_default_country_attribute
        payload = {
            # Preserve the exact Dell request contract supplied for this endpoint.
            "Schemas": [self.settings.tcps_request_schema],
            "Attributes": [attribute],
            "Filter": f'emails.value eq "{_escape_scim_string(email.strip())}"',
            "StartIndex": 1,
            "Count": 1,
        }
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {token}",
        }

        try:
            async with httpx.AsyncClient(
                timeout=self.settings.request_timeout_seconds,
                verify=self.settings.tcps_verify_ssl,
                follow_redirects=True,
            ) as client:
                response = await client.post(url, headers=headers, json=payload)
            latency = int((perf_counter() - started) * 1000)

            if response.status_code in (401, 403):
                return TCPSCountryResult(
                    connected=True,
                    data_found=False,
                    latency_ms=latency,
                    stage="authentication",
                    error_code=f"HTTP_{response.status_code}",
                    http_status=response.status_code,
                    endpoint_host=host,
                    diagnostics={"token_source": resolved_token_source or "unknown"},
                    diagnostic_hint=(
                        "The tCPS endpoint is reachable, but the reused CPS bearer token was rejected or lacks "
                        "UserProvisioningAPI audience/scope. Configure a dedicated TCPS_BEARER_TOKEN only if Dell "
                        "Identity does not accept the CPS runtime token."
                    ),
                )
            if response.status_code == 404:
                return TCPSCountryResult(
                    connected=True,
                    data_found=False,
                    latency_ms=latency,
                    stage="user_search",
                    error_code="HTTP_404",
                    http_status=404,
                    endpoint_host=host,
                    diagnostic_hint="The tCPS endpoint was reached but no user matched the email filter.",
                )
            if not response.is_success:
                return TCPSCountryResult(
                    connected=False,
                    data_found=False,
                    latency_ms=latency,
                    stage="user_search",
                    error_code=f"HTTP_{response.status_code}",
                    http_status=response.status_code,
                    endpoint_host=host,
                    diagnostic_hint="Review the tCPS request contract, token audience/scope, and Dell network access.",
                )

            try:
                response_payload = response.json()
            except ValueError:
                return TCPSCountryResult(
                    connected=True,
                    data_found=False,
                    latency_ms=latency,
                    stage="response_parse",
                    error_code="TCPS_INVALID_JSON",
                    http_status=response.status_code,
                    endpoint_host=host,
                    diagnostic_hint="tCPS returned HTTP success but the response was not valid JSON.",
                )

            total_results = _dict_get_ci(response_payload, "totalResults")
            country = _extract_default_country(response_payload, attribute)
            if not country:
                return TCPSCountryResult(
                    connected=True,
                    data_found=False,
                    latency_ms=latency,
                    stage="complete",
                    error_code="TCPS_DEFAULT_COUNTRY_NOT_FOUND",
                    http_status=response.status_code,
                    endpoint_host=host,
                    diagnostics={
                        "total_results": total_results,
                        "token_source": resolved_token_source or "unknown",
                    },
                    diagnostic_hint="The user search completed, but defaultCountry was absent from the first result.",
                )

            return TCPSCountryResult(
                connected=True,
                data_found=True,
                country=country,
                latency_ms=latency,
                stage="complete",
                http_status=response.status_code,
                endpoint_host=host,
                diagnostics={
                    "total_results": total_results,
                    "attribute": attribute,
                    "token_source": resolved_token_source or "unknown",
                },
            )
        except httpx.TimeoutException:
            return TCPSCountryResult(
                connected=False,
                data_found=False,
                latency_ms=int((perf_counter() - started) * 1000),
                stage="user_search",
                error_code="TCPS_TIMEOUT",
                endpoint_host=host,
                diagnostic_hint="The tCPS request timed out. Verify Dell network/VPN access and retry.",
            )
        except httpx.RequestError:
            return TCPSCountryResult(
                connected=False,
                data_found=False,
                latency_ms=int((perf_counter() - started) * 1000),
                stage="user_search",
                error_code="TCPS_NETWORK_ERROR",
                endpoint_host=host,
                diagnostic_hint="The tCPS endpoint could not be reached from Python. Check VPN, DNS, proxy, and certificate trust.",
            )

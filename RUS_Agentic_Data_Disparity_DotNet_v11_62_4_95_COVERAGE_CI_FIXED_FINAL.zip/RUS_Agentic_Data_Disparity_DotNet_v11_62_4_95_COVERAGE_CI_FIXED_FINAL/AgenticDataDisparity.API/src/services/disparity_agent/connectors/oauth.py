from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any

import httpx


@dataclass
class TokenEntry:
    token: str
    expires_at: float


class TokenAcquisitionError(RuntimeError):
    """Safe OAuth error that never carries the client secret or token."""

    def __init__(
        self,
        message: str,
        *,
        code: str = "TOKEN_ERROR",
        status_code: int | None = None,
        response_preview: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.response_preview = response_preview


def _safe_preview(response: httpx.Response, limit: int = 220) -> str:
    try:
        text = response.text.strip().replace("\r", " ").replace("\n", " ")
    except Exception:
        return ""
    # Do not expose bearer tokens or secret-looking values in diagnostics.
    lowered = text.lower()
    for marker in ("access_token", "client_secret", "authorization", "password"):
        if marker in lowered:
            return "<sensitive response omitted>"
    return text[:limit]


class ClientCredentialsTokenProvider:
    def __init__(
        self,
        auth_url: str,
        client_id: str,
        client_secret: str,
        scope: str = "",
        verify_ssl: bool = True,
        timeout: float = 30.0,
        *,
        send_scope: bool = True,
        extra_form: dict[str, str] | None = None,
    ) -> None:
        self.auth_url = auth_url
        self.client_id = client_id
        self.client_secret = client_secret
        self.scope = scope
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.send_scope = send_scope
        self.extra_form = dict(extra_form or {})
        self._entry: TokenEntry | None = None
        self._lock = asyncio.Lock()

    async def get_token(self) -> str:
        now = time.time()
        if self._entry and now < self._entry.expires_at:
            return self._entry.token
        async with self._lock:
            now = time.time()
            if self._entry and now < self._entry.expires_at:
                return self._entry.token
            if not all([self.auth_url, self.client_id, self.client_secret]):
                raise TokenAcquisitionError(
                    "OAuth client-credentials configuration is incomplete.",
                    code="TOKEN_CONFIG_INCOMPLETE",
                )
            data: dict[str, Any] = {"grant_type": "client_credentials", **self.extra_form}
            if self.send_scope and self.scope:
                data["scope"] = self.scope
            try:
                async with httpx.AsyncClient(verify=self.verify_ssl, timeout=self.timeout) as client:
                    response = await client.post(
                        self.auth_url,
                        data=data,
                        auth=(self.client_id, self.client_secret),
                        headers={"Accept": "application/json"},
                    )
            except httpx.TimeoutException as exc:
                raise TokenAcquisitionError(
                    "OAuth token request timed out.", code="TOKEN_TIMEOUT"
                ) from exc
            except httpx.RequestError as exc:
                raise TokenAcquisitionError(
                    "OAuth token endpoint could not be reached.", code="TOKEN_NETWORK_ERROR"
                ) from exc

            if not response.is_success:
                raise TokenAcquisitionError(
                    f"OAuth token endpoint returned HTTP {response.status_code}.",
                    code=f"TOKEN_HTTP_{response.status_code}",
                    status_code=response.status_code,
                    response_preview=_safe_preview(response),
                )
            try:
                payload = response.json()
            except ValueError as exc:
                raise TokenAcquisitionError(
                    "OAuth token endpoint returned non-JSON content.",
                    code="TOKEN_INVALID_JSON",
                    status_code=response.status_code,
                    response_preview=_safe_preview(response),
                ) from exc
            token = payload.get("access_token")
            if not token:
                raise TokenAcquisitionError(
                    "OAuth token endpoint returned no access_token.",
                    code="TOKEN_MISSING_ACCESS_TOKEN",
                    status_code=response.status_code,
                )
            expires_in = int(payload.get("expires_in", 3600))
            self._entry = TokenEntry(token=str(token), expires_at=time.time() + max(60, expires_in - 60))
            return str(token)

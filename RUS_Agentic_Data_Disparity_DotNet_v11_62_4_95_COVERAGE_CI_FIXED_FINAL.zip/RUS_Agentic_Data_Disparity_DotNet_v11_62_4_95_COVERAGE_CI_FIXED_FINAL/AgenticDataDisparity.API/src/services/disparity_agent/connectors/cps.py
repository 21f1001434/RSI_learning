from __future__ import annotations

from time import perf_counter
from urllib.parse import quote, urlparse

import httpx

from ..models import SearchType, SourceName, SourceRecord, SourceStatus
from ..settings import Settings
from .oauth import ClientCredentialsTokenProvider, TokenAcquisitionError
from .tcps import TCPSCountryConnector


def _endpoint_host(url: str) -> str | None:
    try:
        return urlparse(url).hostname
    except Exception:
        return None




def _dict_get_ci(data: dict, key: str):
    if key in data:
        return data[key]
    folded = key.casefold()
    for candidate, value in data.items():
        if str(candidate).casefold() == folded:
            return value
    return None


def _extract_member_email(payload: object, search_type: SearchType, search_value: str) -> str | None:
    if search_type == SearchType.EMAIL and "@" in search_value:
        return search_value.strip()
    if not isinstance(payload, dict):
        return None

    for direct_key in ("email", "emailId", "emailAddress"):
        value = _dict_get_ci(payload, direct_key)
        if isinstance(value, str) and "@" in value:
            return value.strip()

    profiles = _dict_get_ci(payload, "profiles")
    if isinstance(profiles, list):
        for profile in profiles:
            if not isinstance(profile, dict):
                continue
            contact = _dict_get_ci(profile, "contact")
            if isinstance(contact, dict):
                for key in ("emailId", "email", "emailAddress"):
                    value = _dict_get_ci(contact, key)
                    if isinstance(value, str) and "@" in value:
                        return value.strip()

    aliases = _dict_get_ci(payload, "aliases")
    if isinstance(aliases, list):
        for alias in aliases:
            if not isinstance(alias, dict):
                continue
            alias_type = str(_dict_get_ci(alias, "type") or "").casefold()
            value = _dict_get_ci(alias, "value")
            if alias_type == "email" and isinstance(value, str) and "@" in value:
                return value.strip()
    return None

def _safe_preview(response: httpx.Response, limit: int = 240) -> str:
    try:
        text = response.text.strip().replace("\r", " ").replace("\n", " ")
    except Exception:
        return ""
    lowered = text.lower()
    if any(marker in lowered for marker in ("access_token", "client_secret", "authorization", "password")):
        return "<sensitive response omitted>"
    return text[:limit]


def _http_hint(status: int) -> str:
    if status in (401, 403):
        return "CPS is reachable, but authorization failed. Verify the DCI application credentials and CPS entitlement for this environment."
    if status == 400:
        return "CPS rejected the request. Verify the configured account path and identifier type."
    if status == 404:
        return "CPS was reached but no matching account was returned for this identifier."
    if status == 429:
        return "CPS rate-limited the request. Retry after a short delay."
    if status >= 500:
        return "CPS or its gateway returned a server error. Retry and check the upstream service health."
    return "Review the CPS endpoint, environment, and gateway response."


class CPSConnector:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.tcps = TCPSCountryConnector(settings)
        self.tokens = ClientCredentialsTokenProvider(
            settings.cps_auth_url,
            settings.cps_client_id,
            settings.cps_client_secret,
            settings.cps_scope,
            settings.cps_verify_ssl,
            settings.request_timeout_seconds,
            send_scope=settings.cps_send_scope,
        )

    def _build_url(self, search_value: str) -> str:
        encoded = quote(search_value, safe="")
        base = self.settings.cps_base_url.rstrip("/")
        path_template = self.settings.cps_account_path or "v2/Accounts/{value}"
        if "{value}" in path_template:
            path = path_template.format(value=encoded).strip("/")
        else:
            path = f"{path_template.rstrip('/')}/{encoded}".strip("/")
        base_path = urlparse(base).path.rstrip("/").casefold()
        account_prefix = path.rsplit("/", 1)[0].strip("/").casefold()
        # Some Spring configurations already include /v2/Accounts in the base URL.
        if base_path.endswith("/v2/accounts") or base_path.endswith(account_prefix):
            return f"{base}/{encoded}"
        return f"{base}/{path}"

    async def fetch(self, search_type: SearchType, search_value: str) -> SourceRecord:
        started = perf_counter()
        if search_type == SearchType.CROWD_TWIST_ID:
            return SourceRecord(
                source=SourceName.CPS,
                status=SourceStatus(
                    source=SourceName.CPS,
                    connected=True,
                    data_found=False,
                    latency_ms=0,
                    error="CPS cannot be queried directly by CrowdTwist ID; a profile-ID retry may follow.",
                    stage="identifier_resolution",
                    error_code="CPS_REQUIRES_PROFILE_ID",
                    endpoint_host=_endpoint_host(self.settings.cps_base_url),
                    diagnostic_hint="The pipeline will retry CPS after resolving the profile ID from CrowdTwist or Rewards DB.",
                ),
            )

        try:
            token = await self.tokens.get_token()
        except TokenAcquisitionError as exc:
            return SourceRecord(
                source=SourceName.CPS,
                status=SourceStatus(
                    source=SourceName.CPS,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error=str(exc),
                    stage="oauth_token",
                    error_code=exc.code,
                    http_status=exc.status_code,
                    endpoint_host=_endpoint_host(self.settings.cps_auth_url),
                    diagnostic_hint="Verify the CPS DCI token URL and DCI application client credentials loaded from Spring Config.",
                    diagnostics={"response_preview": exc.response_preview} if exc.response_preview else {},
                ),
            )

        url = self._build_url(search_value)
        headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
        if self.settings.cps_api_key:
            headers[self.settings.cps_api_key_header] = self.settings.cps_api_key
        try:
            async with httpx.AsyncClient(
                verify=self.settings.cps_verify_ssl,
                timeout=self.settings.request_timeout_seconds,
                follow_redirects=True,
            ) as client:
                response = await client.get(url, headers=headers)
            latency = int((perf_counter() - started) * 1000)
            if response.status_code == 404:
                return SourceRecord(
                    source=SourceName.CPS,
                    status=SourceStatus(
                        source=SourceName.CPS,
                        connected=True,
                        data_found=False,
                        latency_ms=latency,
                        stage="account_lookup",
                        error_code="HTTP_404",
                        http_status=404,
                        endpoint_host=_endpoint_host(url),
                        diagnostic_hint=_http_hint(404),
                    ),
                )
            if not response.is_success:
                return SourceRecord(
                    source=SourceName.CPS,
                    status=SourceStatus(
                        source=SourceName.CPS,
                        connected=False,
                        data_found=False,
                        latency_ms=latency,
                        error=f"CPS API returned HTTP {response.status_code} ({response.reason_phrase}).",
                        stage="account_lookup",
                        error_code=f"HTTP_{response.status_code}",
                        http_status=response.status_code,
                        endpoint_host=_endpoint_host(url),
                        diagnostic_hint=_http_hint(response.status_code),
                        diagnostics={"response_preview": _safe_preview(response)} if _safe_preview(response) else {},
                    ),
                )
            try:
                payload = response.json()
            except ValueError:
                return SourceRecord(
                    source=SourceName.CPS,
                    status=SourceStatus(
                        source=SourceName.CPS,
                        connected=False,
                        data_found=False,
                        latency_ms=latency,
                        error="CPS returned a successful HTTP response with invalid JSON.",
                        stage="response_parse",
                        error_code="CPS_INVALID_JSON",
                        http_status=response.status_code,
                        endpoint_host=_endpoint_host(url),
                        diagnostic_hint="Inspect the CPS gateway response and content type.",
                    ),
                )
            diagnostics: dict[str, object] = {}
            retrieval_method = "direct"
            member_email = _extract_member_email(payload, search_type, search_value)
            tcps_token = token if self.settings.tcps_use_cps_bearer_token else None
            tcps_result = await self.tcps.fetch_default_country(
                member_email or "",
                bearer_token=tcps_token,
                token_source="cps_oauth_runtime_token" if tcps_token else None,
            )
            diagnostics["tcps_country_lookup"] = tcps_result.as_diagnostics()
            if tcps_result.data_found and tcps_result.country and isinstance(payload, dict):
                # Keep tCPS as supplemental CPS evidence. The field map reads this
                # exact value before the broader CPS profile region.
                payload.setdefault("_tcps", {})
                if isinstance(payload["_tcps"], dict):
                    payload["_tcps"]["defaultCountry"] = tcps_result.country
                retrieval_method = "direct+cps_tcps_scim"

            return SourceRecord(
                source=SourceName.CPS,
                status=SourceStatus(
                    source=SourceName.CPS,
                    connected=True,
                    data_found=payload is not None,
                    latency_ms=latency,
                    stage="complete",
                    http_status=response.status_code,
                    endpoint_host=_endpoint_host(url),
                    retrieval_method=retrieval_method,
                    diagnostics=diagnostics,
                ),
                raw=payload,
            )
        except httpx.TimeoutException:
            return SourceRecord(
                source=SourceName.CPS,
                status=SourceStatus(
                    source=SourceName.CPS,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error="CPS request timed out.",
                    stage="account_lookup",
                    error_code="CPS_TIMEOUT",
                    endpoint_host=_endpoint_host(url),
                    diagnostic_hint="Confirm Dell VPN/network access and increase REQUEST_TIMEOUT_SECONDS if the service is slow.",
                ),
            )
        except httpx.RequestError:
            return SourceRecord(
                source=SourceName.CPS,
                status=SourceStatus(
                    source=SourceName.CPS,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error="CPS endpoint could not be reached.",
                    stage="account_lookup",
                    error_code="CPS_NETWORK_ERROR",
                    endpoint_host=_endpoint_host(url),
                    diagnostic_hint="Confirm Dell VPN, DNS resolution, proxy settings, and the G1/G2/G4 environment selection.",
                ),
            )
        except Exception as exc:
            return SourceRecord(
                source=SourceName.CPS,
                status=SourceStatus(
                    source=SourceName.CPS,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error=f"{type(exc).__name__}: CPS request failed.",
                    stage="account_lookup",
                    error_code="CPS_UNEXPECTED_ERROR",
                    endpoint_host=_endpoint_host(url),
                    diagnostic_hint="Review the local terminal log and CPS configuration diagnostics.",
                ),
            )

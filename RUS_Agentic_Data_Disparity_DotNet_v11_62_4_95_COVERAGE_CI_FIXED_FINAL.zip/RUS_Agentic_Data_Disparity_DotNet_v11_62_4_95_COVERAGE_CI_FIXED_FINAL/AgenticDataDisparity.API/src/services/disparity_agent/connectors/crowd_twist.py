from __future__ import annotations

from time import perf_counter
from urllib.parse import quote, urlparse

import httpx

from ..models import SearchType, SourceName, SourceRecord, SourceStatus
from ..settings import Settings
from .oauth import ClientCredentialsTokenProvider, TokenAcquisitionError


def _host(url: str) -> str | None:
    try:
        return urlparse(url).hostname
    except Exception:
        return None


class CrowdTwistConnector:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.tokens = ClientCredentialsTokenProvider(
            settings.crowd_twist_auth_url,
            settings.crowd_twist_client_id,
            settings.crowd_twist_client_secret,
            settings.crowd_twist_scope,
            settings.crowd_twist_verify_ssl,
            settings.request_timeout_seconds,
            send_scope=bool(settings.crowd_twist_scope),
        )
        self.update_base_url = settings.crowd_twist_update_base_url
        self.update_tokens = ClientCredentialsTokenProvider(
            settings.crowd_twist_auth_url,
            settings.crowd_twist_update_client_id,
            settings.crowd_twist_update_client_secret,
            "",
            settings.crowd_twist_verify_ssl,
            settings.request_timeout_seconds,
            # Match the proven Dell Utility Ext write flow: Basic client
            # credentials + grant_type only, without a scope field.
            send_scope=False,
        )

    async def update_user(self, crowd_twist_id: str, payload: dict[str, object]) -> tuple[httpx.Response, str]:
        """Update CrowdTwist using the proven Ext write contract.

        The uploaded .NET LoyaltyServiceProviderV3 reads with Ext2 but writes
        with CTLayer7ApiExtURL + CTLayer7ExtClientId/Secret. Returning the
        endpoint family makes failures diagnosable without exposing secrets.
        """
        if not self.settings.crowd_twist_update_credentials_complete:
            raise RuntimeError(
                "CrowdTwist Ext update configuration is incomplete; "
                "CTLayer7ApiExtURL, CTLayer7ExtClientId/Secret and CrowdTwistApiKey are required."
            )
        token = await self.update_tokens.get_token()
        path = self.settings.crowd_twist_update_path.format(
            crowd_twist_id=quote(str(crowd_twist_id), safe="")
        )
        url = f"{self.update_base_url.rstrip('/')}/{path.lstrip('/')}"
        params = {"api_key": self.settings.crowd_twist_api_key} if self.settings.crowd_twist_api_key else {}
        async with httpx.AsyncClient(
            verify=self.settings.crowd_twist_verify_ssl,
            timeout=self.settings.request_timeout_seconds,
            follow_redirects=True,
        ) as client:
            response = await client.put(
                url,
                params=params,
                json=payload,
                headers={"Authorization": f"Bearer {token}", "Accept": "*/*"},
            )
        endpoint_family = "Ext/update"
        return response, endpoint_family

    async def fetch(self, search_type: SearchType, search_value: str) -> SourceRecord:
        started = perf_counter()
        id_type = {
            SearchType.EMAIL: "email",
            SearchType.PROFILE_ID: "third_party_id",
            SearchType.CROWD_TWIST_ID: "id",
        }[search_type]
        try:
            token = await self.tokens.get_token()
        except TokenAcquisitionError as exc:
            return SourceRecord(
                source=SourceName.CROWD_TWIST,
                status=SourceStatus(
                    source=SourceName.CROWD_TWIST,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error=str(exc),
                    stage="oauth_token",
                    error_code=exc.code,
                    http_status=exc.status_code,
                    endpoint_host=_host(self.settings.crowd_twist_auth_url),
                    diagnostic_hint="Verify the CrowdTwist Ext2 client credentials and Layer7 token endpoint loaded from Spring Config.",
                ),
            )

        path = self.settings.crowd_twist_user_path.format(value=quote(search_value, safe=""))
        url = f"{self.settings.crowd_twist_base_url.rstrip('/')}/{path.lstrip('/')}"
        params = {"id_type": id_type}
        if self.settings.crowd_twist_api_key:
            params["api_key"] = self.settings.crowd_twist_api_key
        try:
            async with httpx.AsyncClient(
                verify=self.settings.crowd_twist_verify_ssl,
                timeout=self.settings.request_timeout_seconds,
                follow_redirects=True,
            ) as client:
                response = await client.get(
                    url,
                    params=params,
                    headers={"Authorization": f"Bearer {token}", "Accept": "*/*"},
                )
            latency = int((perf_counter() - started) * 1000)
            if response.status_code == 404:
                return SourceRecord(
                    source=SourceName.CROWD_TWIST,
                    status=SourceStatus(
                        source=SourceName.CROWD_TWIST,
                        connected=True,
                        data_found=False,
                        latency_ms=latency,
                        stage="user_lookup",
                        error_code="HTTP_404",
                        http_status=404,
                        endpoint_host=_host(url),
                        diagnostic_hint="CrowdTwist was reached, but no user matched the identifier.",
                    ),
                )
            if not response.is_success:
                return SourceRecord(
                    source=SourceName.CROWD_TWIST,
                    status=SourceStatus(
                        source=SourceName.CROWD_TWIST,
                        connected=False,
                        data_found=False,
                        latency_ms=latency,
                        error=f"CrowdTwist API returned HTTP {response.status_code} ({response.reason_phrase}).",
                        stage="user_lookup",
                        error_code=f"HTTP_{response.status_code}",
                        http_status=response.status_code,
                        endpoint_host=_host(url),
                        diagnostic_hint="Verify the Ext2 endpoint/client credentials, API key, environment, and member identifier.",
                    ),
                )
            try:
                payload = response.json()
            except ValueError:
                return SourceRecord(
                    source=SourceName.CROWD_TWIST,
                    status=SourceStatus(
                        source=SourceName.CROWD_TWIST,
                        connected=False,
                        data_found=False,
                        latency_ms=latency,
                        error="CrowdTwist returned a successful HTTP response with invalid JSON.",
                        stage="response_parse",
                        error_code="CT_INVALID_JSON",
                        http_status=response.status_code,
                        endpoint_host=_host(url),
                    ),
                )
            return SourceRecord(
                source=SourceName.CROWD_TWIST,
                status=SourceStatus(
                    source=SourceName.CROWD_TWIST,
                    connected=True,
                    data_found=payload is not None,
                    latency_ms=latency,
                    stage="complete",
                    http_status=response.status_code,
                    endpoint_host=_host(url),
                ),
                raw=payload,
            )
        except httpx.TimeoutException:
            return SourceRecord(
                source=SourceName.CROWD_TWIST,
                status=SourceStatus(
                    source=SourceName.CROWD_TWIST,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error="CrowdTwist request timed out.",
                    stage="user_lookup",
                    error_code="CT_TIMEOUT",
                    endpoint_host=_host(url),
                    diagnostic_hint="Confirm Dell VPN/network access and CrowdTwist Layer7 availability.",
                ),
            )
        except httpx.RequestError:
            return SourceRecord(
                source=SourceName.CROWD_TWIST,
                status=SourceStatus(
                    source=SourceName.CROWD_TWIST,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error="CrowdTwist endpoint could not be reached.",
                    stage="user_lookup",
                    error_code="CT_NETWORK_ERROR",
                    endpoint_host=_host(url),
                    diagnostic_hint="Confirm Dell VPN, DNS, proxy settings, and the configured environment.",
                ),
            )
        except Exception as exc:
            return SourceRecord(
                source=SourceName.CROWD_TWIST,
                status=SourceStatus(
                    source=SourceName.CROWD_TWIST,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error=f"{type(exc).__name__}: CrowdTwist request failed.",
                    stage="user_lookup",
                    error_code="CT_UNEXPECTED_ERROR",
                    endpoint_host=_host(url),
                ),
            )

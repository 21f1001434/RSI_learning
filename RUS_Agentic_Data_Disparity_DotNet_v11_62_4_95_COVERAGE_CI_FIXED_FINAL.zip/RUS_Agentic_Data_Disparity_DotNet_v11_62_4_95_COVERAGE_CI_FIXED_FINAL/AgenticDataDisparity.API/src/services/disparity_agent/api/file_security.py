from __future__ import annotations

import re
from pathlib import Path

RUN_ID_PATTERN = r"^DDR-[A-F0-9]{12}$"
JOB_ID_PATTERN = r"^JOB-[A-F0-9]{16}$"
_SAFE_FILENAME = re.compile(r"^[A-Za-z0-9._-]{1,180}$")


def validate_run_id(value: str) -> str:
    value = str(value or "").strip()
    if re.fullmatch(RUN_ID_PATTERN, value) is None:
        raise ValueError("Invalid run ID")
    return value


def validate_job_id(value: str) -> str:
    value = str(value or "").strip()
    if re.fullmatch(JOB_ID_PATTERN, value) is None:
        raise ValueError("Invalid batch job ID")
    return value


def resolve_direct_child(root: Path, filename: str) -> Path:
    """Resolve a generated artifact and prove it remains directly under ``root``.

    HTTP identifiers are never accepted as path fragments here. Callers first
    validate IDs and then pass a server-generated filename.
    """
    if _SAFE_FILENAME.fullmatch(str(filename or "")) is None:
        raise ValueError("Unsafe generated filename")
    base = root.resolve()
    candidate = (base / filename).resolve()
    if candidate.parent != base:
        raise ValueError("Resolved artifact escaped its configured directory")
    return candidate


def validate_existing_artifact(path: Path, root: Path) -> Path:
    """Validate an internally stored artifact path before reading it."""
    base = root.resolve()
    candidate = path.resolve()
    if candidate.parent != base:
        raise ValueError("Artifact path is outside the configured directory")
    if not candidate.is_file():
        raise FileNotFoundError(candidate)
    return candidate


def safe_download_filename(filename: str) -> str:
    """Return a header-safe basename for Content-Disposition.

    Reject path separators rather than silently normalizing them; this keeps the
    HTTP header contract fail-closed and makes path/header injection impossible.
    """
    raw = str(filename or "")
    if Path(raw).name != raw or "/" in raw or "\\" in raw:
        raise ValueError("Unsafe download filename")
    if _SAFE_FILENAME.fullmatch(raw) is None:
        raise ValueError("Unsafe download filename")
    return raw

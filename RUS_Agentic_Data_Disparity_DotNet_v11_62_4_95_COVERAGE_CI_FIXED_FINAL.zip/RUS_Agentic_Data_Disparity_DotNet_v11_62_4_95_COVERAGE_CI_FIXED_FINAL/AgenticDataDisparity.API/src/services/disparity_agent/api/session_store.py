from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

from .schemas import SessionMessage, SessionView


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class SessionState:
    session_id: str
    created_at: datetime
    updated_at: datetime
    expires_at: datetime
    metadata: dict[str, Any] = field(default_factory=dict)
    messages: list[SessionMessage] = field(default_factory=list)
    active_run_id: str | None = None
    # Kept for backward compatibility with v9/v10 clients. This is the JOB id.
    active_batch_id: str | None = None
    active_batch_result_id: str | None = None
    active_context: str = "none"
    last_report: dict[str, Any] | None = None
    last_batch_summary: dict[str, Any] | None = None
    facts: dict[str, Any] = field(default_factory=dict)
    report_history: list[dict[str, Any]] = field(default_factory=list)


class SessionNotFound(KeyError):
    pass


class InMemorySessionStore:
    """Process-local, TTL-scoped chat memory.

    The store now retains both the most recent individual analysis and the most
    recent bulk-analysis summary. The active_context flag tells the chat agent
    which result should answer generic requests such as "summary" or "timing".
    Memory disappears when the API process restarts; the interface remains
    replaceable by Redis without changing the route contracts.
    """

    def __init__(self, *, ttl_minutes: int, max_messages: int, max_sessions: int) -> None:
        self._ttl = timedelta(minutes=max(1, ttl_minutes))
        self._max_messages = max(4, max_messages)
        self._max_sessions = max(10, max_sessions)
        self._sessions: dict[str, SessionState] = {}
        self._lock = asyncio.Lock()

    async def create(self, metadata: dict[str, Any] | None = None) -> SessionState:
        async with self._lock:
            await self._purge_locked()
            if len(self._sessions) >= self._max_sessions:
                oldest = min(self._sessions.values(), key=lambda item: item.updated_at)
                self._sessions.pop(oldest.session_id, None)
            now = utc_now()
            session_id = "SES-" + uuid.uuid4().hex.upper()
            state = SessionState(
                session_id=session_id,
                created_at=now,
                updated_at=now,
                expires_at=now + self._ttl,
                metadata=dict(metadata or {}),
            )
            self._sessions[session_id] = state
            return state

    async def get(self, session_id: str, *, touch: bool = True) -> SessionState:
        async with self._lock:
            await self._purge_locked()
            state = self._sessions.get(session_id)
            if state is None:
                raise SessionNotFound(session_id)
            if touch:
                self._touch(state)
            return state

    async def append(self, session_id: str, *, role: str, content: str, metadata: dict[str, Any] | None = None) -> SessionMessage:
        async with self._lock:
            await self._purge_locked()
            state = self._sessions.get(session_id)
            if state is None:
                raise SessionNotFound(session_id)
            now = utc_now()
            message = SessionMessage(
                message_id="MSG-" + uuid.uuid4().hex.upper(),
                role=role,  # type: ignore[arg-type]
                content=content,
                created_at=now,
                metadata=dict(metadata or {}),
            )
            state.messages.append(message)
            if len(state.messages) > self._max_messages:
                state.messages = state.messages[-self._max_messages :]
            state.updated_at = now
            state.expires_at = now + self._ttl
            return message

    async def set_active_report(self, session_id: str, report: dict[str, Any]) -> None:
        async with self._lock:
            state = self._sessions.get(session_id)
            if state is None:
                raise SessionNotFound(session_id)
            state.last_report = report
            state.active_run_id = str(report.get("run_id") or "") or None
            state.active_context = "individual"
            run_id = str(report.get("run_id") or "").strip()
            if run_id:
                state.report_history = [item for item in state.report_history if item.get("run_id") != run_id]
                state.report_history.append({
                    "kind": "individual",
                    "run_id": run_id,
                    "label": str(report.get("search_value") or run_id),
                    "search_type": report.get("search_type"),
                    "search_value": report.get("search_value"),
                    "created_at": utc_now().isoformat(),
                })
                state.report_history = state.report_history[-20:]
            state.facts.update(
                {
                    "active_context": "individual",
                    "last_search_type": report.get("search_type"),
                    "last_search_value": report.get("search_value"),
                    "last_completeness": report.get("analysis_completeness"),
                }
            )
            self._touch(state)

    async def set_active_batch(self, session_id: str, job_id: str) -> None:
        """Attach a newly queued batch to a chat session."""
        async with self._lock:
            state = self._sessions.get(session_id)
            if state is None:
                raise SessionNotFound(session_id)
            state.active_batch_id = job_id
            state.active_batch_result_id = None
            state.last_batch_summary = None
            state.active_context = "batch"
            state.facts.update(
                {
                    "active_context": "batch",
                    "active_batch_job_id": job_id,
                    "active_batch_result_id": None,
                    "active_batch_status": "QUEUED",
                    "active_batch_phase": "QUEUED",
                }
            )
            self._touch(state)

    async def set_active_batch_status(self, session_id: str, job_id: str, *, status: str, phase: str) -> None:
        async with self._lock:
            state = self._sessions.get(session_id)
            if state is None:
                raise SessionNotFound(session_id)
            state.active_batch_id = job_id
            state.active_context = "batch"
            state.facts.update(
                {
                    "active_context": "batch",
                    "active_batch_job_id": job_id,
                    "active_batch_status": status,
                    "active_batch_phase": phase,
                }
            )
            self._touch(state)

    async def set_active_batch_result(
        self,
        session_id: str,
        *,
        job_id: str,
        batch_id: str | None,
        summary: dict[str, Any],
    ) -> None:
        """Store the completed bulk-analysis evidence in session memory."""
        async with self._lock:
            state = self._sessions.get(session_id)
            if state is None:
                raise SessionNotFound(session_id)
            state.active_batch_id = job_id
            state.active_batch_result_id = batch_id
            state.last_batch_summary = summary
            state.active_context = "batch"
            processing = summary.get("processing") or {}
            population = summary.get("population_metrics") or {}
            totals = summary.get("totals") or {}
            history_key = batch_id or job_id
            state.report_history = [
                item for item in state.report_history
                if (item.get("batch_id") or item.get("job_id")) != history_key
            ]
            state.report_history.append({
                "kind": "batch",
                "job_id": job_id,
                "batch_id": batch_id,
                "label": batch_id or job_id,
                "created_at": utc_now().isoformat(),
                "unique_members": population.get("unique_members_processed"),
                "completed_count": processing.get("completed_count"),
                "failed_count": processing.get("failed_count"),
            })
            state.report_history = state.report_history[-20:]
            state.facts.update(
                {
                    "active_context": "batch",
                    "active_batch_job_id": job_id,
                    "active_batch_result_id": batch_id,
                    "active_batch_status": "COMPLETED",
                    "active_batch_phase": "COMPLETED",
                    "batch_unique_members": population.get("unique_members_processed"),
                    "batch_completed_count": processing.get("completed_count"),
                    "batch_failed_count": processing.get("failed_count"),
                    "batch_exact_changes": totals.get("exact_changes"),
                    "batch_manual_review_items": totals.get("manual_review"),
                }
            )
            self._touch(state)

    async def clear(self, session_id: str) -> SessionState:
        async with self._lock:
            state = self._sessions.get(session_id)
            if state is None:
                raise SessionNotFound(session_id)
            state.messages.clear()
            state.active_run_id = None
            state.active_batch_id = None
            state.active_batch_result_id = None
            state.active_context = "none"
            state.last_report = None
            state.last_batch_summary = None
            state.report_history.clear()
            state.facts.clear()
            self._touch(state)
            return state

    async def delete(self, session_id: str) -> bool:
        async with self._lock:
            return self._sessions.pop(session_id, None) is not None

    async def cleanup(self) -> int:
        async with self._lock:
            return await self._purge_locked()

    async def _purge_locked(self) -> int:
        now = utc_now()
        expired = [key for key, value in self._sessions.items() if value.expires_at <= now]
        for key in expired:
            self._sessions.pop(key, None)
        return len(expired)

    def _touch(self, state: SessionState) -> None:
        now = utc_now()
        state.updated_at = now
        state.expires_at = now + self._ttl

    @staticmethod
    def view(state: SessionState, *, include_messages: bool = True) -> SessionView:
        return SessionView(
            session_id=state.session_id,
            created_at=state.created_at,
            updated_at=state.updated_at,
            expires_at=state.expires_at,
            active_run_id=state.active_run_id,
            active_batch_id=state.active_batch_id,
            active_batch_job_id=state.active_batch_id,
            active_batch_result_id=state.active_batch_result_id,
            active_context=state.active_context if state.active_context in {"none", "individual", "batch"} else "none",  # type: ignore[arg-type]
            has_active_batch_summary=state.last_batch_summary is not None,
            active_source_change_id=state.facts.get("active_source_change_id"),
            active_source_change_status=(
                ((state.facts.get("source_changes") or {}).get(state.facts.get("active_source_change_id")) or {}).get("status")
                if state.facts.get("active_source_change_id") else None
            ),
            message_count=len(state.messages),
            metadata=dict(state.metadata),
            report_history=list(state.report_history),
            messages=list(state.messages) if include_messages else [],
        )

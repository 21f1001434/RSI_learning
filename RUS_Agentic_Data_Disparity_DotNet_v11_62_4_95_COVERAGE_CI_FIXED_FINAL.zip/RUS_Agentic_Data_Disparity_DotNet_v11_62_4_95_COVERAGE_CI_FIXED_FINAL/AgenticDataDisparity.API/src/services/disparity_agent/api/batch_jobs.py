from __future__ import annotations

import asyncio
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any

from ..batch import build_batch_insights, build_batch_zip, run_batch
from ..concurrency_policy import DELL_AIA_PARALLEL_WORKERS, INCLUDE_GROUPED_DELL_AIA, SOURCE_PARALLEL_WORKERS
from ..settings import Settings
from .config import ApiSettings
from .file_security import validate_existing_artifact, validate_job_id
from .schemas import BatchJobStatus, BatchJobView
from .session_store import InMemorySessionStore, SessionNotFound


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class BatchJob:
    job_id: str
    parse_result: dict[str, Any]
    settings: Settings
    api_settings: ApiSettings
    max_parallel: int
    max_parallel_ai: int
    include_group_ai: bool
    session_id: str | None = None
    status: BatchJobStatus = BatchJobStatus.QUEUED
    phase: str = "QUEUED"
    created_at: datetime = field(default_factory=utc_now)
    started_at: datetime | None = None
    completed_at: datetime | None = None
    batch_id: str | None = None
    summary: dict[str, Any] | None = None
    items: list[dict[str, Any]] | None = None
    zip_path: Path | None = None
    masked_zip_path: Path | None = None
    error: dict[str, Any] | None = None
    _started_perf: float | None = None


class BatchJobNotFound(KeyError):
    pass


class BatchJobManager:
    def __init__(
        self,
        settings: Settings,
        api_settings: ApiSettings,
        sessions: InMemorySessionStore | None = None,
        audit_service: Any | None = None,
    ) -> None:
        self.settings = settings
        self.api_settings = api_settings
        self.sessions = sessions
        self.audit_service = audit_service
        self.jobs: dict[str, BatchJob] = {}
        self._lock = asyncio.Lock()
        self.api_settings.batch_output_dir.mkdir(parents=True, exist_ok=True)

    async def create(
        self,
        parse_result: dict[str, Any],
        *,
        max_parallel: int | None,
        max_parallel_ai: int | None,
        include_group_ai: bool,
        session_id: str | None = None,
    ) -> BatchJob:
        if int(parse_result.get("unique_valid_count") or 0) > self.api_settings.batch_max_emails:
            raise ValueError(f"Batch exceeds maximum of {self.api_settings.batch_max_emails} unique emails")
        job = BatchJob(
            job_id="JOB-" + uuid.uuid4().hex[:16].upper(),
            parse_result=parse_result,
            settings=self.settings,
            api_settings=self.api_settings,
            max_parallel=max(1, min(int(max_parallel or SOURCE_PARALLEL_WORKERS), 8)),
            max_parallel_ai=max(1, min(int(max_parallel_ai or DELL_AIA_PARALLEL_WORKERS), 2)),
            include_group_ai=bool(include_group_ai),
            session_id=session_id,
        )
        async with self._lock:
            self.jobs[job.job_id] = job
        if session_id and self.sessions is not None:
            await self.sessions.set_active_batch(session_id, job.job_id)
        await self._audit_batch(job, 'BATCH_QUEUED', 'QUEUED', 'Bulk analysis accepted and queued.')
        asyncio.create_task(self._execute(job))
        return job

    async def get(self, job_id: str) -> BatchJob:
        try:
            job_id = validate_job_id(job_id)
        except ValueError as exc:
            raise BatchJobNotFound(job_id) from exc
        async with self._lock:
            job = self.jobs.get(job_id)
        if job is None:
            raise BatchJobNotFound(job_id)
        return job

    async def download_payload(self, job_id: str, *, masked: bool = False) -> tuple[bytes, str]:
        """Return a validated batch artifact without exposing a user-controlled path."""
        job = await self.get(job_id)
        path = job.masked_zip_path if masked else job.zip_path
        if path is None:
            raise FileNotFoundError("Batch report package is not available yet")
        safe_path = validate_existing_artifact(path, self.api_settings.batch_output_dir)
        return safe_path.read_bytes(), safe_path.name

    async def _execute(self, job: BatchJob) -> None:
        job.status = BatchJobStatus.RUNNING
        job.phase = "DELL_AIA_PREFLIGHT_AND_DATA_COLLECTION"
        job.started_at = utc_now()
        job._started_perf = perf_counter()
        await self._update_session_status(job)
        await self._audit_batch(job, 'BATCH_STARTED', 'STARTED', 'Dell AIA preflight and source collection started.')
        try:
            summary, items = await run_batch(
                job.settings,
                job.parse_result,
                max_parallel=job.max_parallel,
                max_parallel_ai=job.max_parallel_ai,
                include_group_ai=job.include_group_ai,
                require_ai_preflight=True,
            )
            job.phase = "REPORT_PACKAGING"
            await self._update_session_status(job)
            job.summary = summary
            job.items = items
            job.batch_id = str(summary.get("batch_id") or "") or None
            unmasked_payload = build_batch_zip(summary, items, mask_pii=False)
            masked_payload = build_batch_zip(summary, items, mask_pii=True)
            base_name = job.batch_id or job.job_id
            job.zip_path = job.api_settings.batch_output_dir / f"{base_name}_REPORTS_UNMASKED.zip"
            job.masked_zip_path = job.api_settings.batch_output_dir / f"{base_name}_REPORTS_MASKED.zip"
            job.zip_path.write_bytes(unmasked_payload)
            job.masked_zip_path.write_bytes(masked_payload)
            (job.api_settings.batch_output_dir / f"{job.batch_id or job.job_id}_SUMMARY.json").write_text(
                json.dumps(summary, indent=2, default=str), encoding="utf-8"
            )
            job.status = BatchJobStatus.COMPLETED
            job.phase = "COMPLETED"
            job.completed_at = utc_now()
            await self._publish_completed_batch_to_session(job)
            processing = (job.summary or {}).get('processing') or {}
            await self._audit_batch(
                job,
                'BATCH_COMPLETED',
                'COMPLETED',
                f"Bulk analysis completed: {processing.get('completed_count', 0)} completed, {processing.get('failed_count', 0)} failed.",
            )
        except Exception as exc:
            job.status = BatchJobStatus.FAILED
            job.phase = "FAILED"
            job.completed_at = utc_now()
            job.error = {"type": type(exc).__name__, "message": str(exc)}
            await self._publish_failed_batch_to_session(job)
            await self._audit_batch(job, 'BATCH_FAILED', 'FAILED', str(exc))

    async def _audit_batch(self, job: BatchJob, event: str, status: str, verification: str) -> None:
        if self.audit_service is None:
            return
        actor = 'Unknown user'
        actor_email = None
        actor_role = None
        actor_id = None
        if job.session_id and self.sessions is not None:
            try:
                state = await self.sessions.get(job.session_id, touch=False)
                actor = str(state.metadata.get('actor') or state.metadata.get('actor_username') or actor)
                actor_email = state.metadata.get('actor_email')
                actor_role = state.metadata.get('actor_role')
                actor_id = state.metadata.get('actor_id')
            except SessionNotFound:
                pass
        processing = (job.summary or {}).get('processing') or {}
        population = (job.summary or {}).get('population_metrics') or {}
        await self.audit_service.audit_agentic_activity(
            event,
            {
                'session_id': job.session_id,
                'job_id': job.job_id,
                'batch_id': job.batch_id,
                'actor': actor,
                'actor_email': actor_email,
                'actor_role': actor_role,
                'actor_id': actor_id,
                'source': 'Agentic AI',
                'action': 'Bulk disparity analysis',
                'status': status,
                'target': f"{job.parse_result.get('unique_valid_count', 0)} unique member(s)",
                'verification': verification,
                'details': {
                    'submittedCount': job.parse_result.get('submitted_count', 0),
                    'uniqueValidCount': job.parse_result.get('unique_valid_count', 0),
                    'duplicateCount': job.parse_result.get('duplicate_count', 0),
                    'invalidCount': job.parse_result.get('invalid_count', 0),
                    'completedCount': processing.get('completed_count', 0),
                    'failedCount': processing.get('failed_count', 0),
                    'uniqueMembersProcessed': population.get('unique_members_processed', 0),
                    'phase': job.phase,
                },
            },
        )

    async def _update_session_status(self, job: BatchJob) -> None:
        if not job.session_id or self.sessions is None:
            return
        try:
            await self.sessions.set_active_batch_status(
                job.session_id,
                job.job_id,
                status=job.status.value,
                phase=job.phase,
            )
        except SessionNotFound:
            return

    async def _publish_completed_batch_to_session(self, job: BatchJob) -> None:
        if not job.session_id or self.sessions is None or job.summary is None:
            return
        try:
            await self.sessions.set_active_batch_result(
                job.session_id,
                job_id=job.job_id,
                batch_id=job.batch_id,
                summary=job.summary,
            )
            processing = job.summary.get("processing") or {}
            population = job.summary.get("population_metrics") or {}
            totals = job.summary.get("totals") or {}
            judge = job.summary.get("judge_outcomes") or {}
            insights = job.summary.get("batch_insights") or build_batch_insights(job.summary)
            job.summary["batch_insights"] = insights
            authoritative = str(job.summary.get("authoritative_group_summary") or "").strip()
            majority = (insights.get("majority_issue") or {}).get("attributes") or []
            if majority:
                majority_names = ", ".join(str(item.get("attribute")) for item in majority)
                majority_line = (
                    f"{majority_names} affect {majority[0].get('users_affected', 0)} member(s) "
                    f"({majority[0].get('percentage_of_members', 0)}%)."
                )
            else:
                majority_line = "No recurring non-match issue was found."
            population_pct = insights.get("population_percentages") or {}
            reply = "\n".join([
                f"## Bulk analysis completed — {job.batch_id or job.job_id}",
                "",
                "### Summary statistics",
                f"- **Unique members:** {population.get('unique_members_processed', processing.get('completed_count', 0))}",
                f"- **Completed:** {processing.get('completed_count', 0)}",
                f"- **Failed:** {processing.get('failed_count', 0)}",
                f"- **Users with exact changes:** {population.get('users_with_exact_changes', 0)} ({population_pct.get('members_with_exact_changes', 0)}%)",
                f"- **Users requiring manual review:** {population.get('users_requiring_manual_review', 0)} ({population_pct.get('members_requiring_manual_review', 0)}%)",
                f"- **Exact-change items:** {totals.get('exact_changes', 0)}",
                f"- **Manual-review items:** {totals.get('manual_review', 0)}",
                "",
                "### Majority issue",
                f"- {majority_line}",
                "",
                "### Judge outcomes",
                f"- **Accepted:** {judge.get('ACCEPTED', processing.get('judge_accepted_count', 0))}",
                f"- **Partial / corrected:** {judge.get('PARTIAL', processing.get('judge_partial_count', 0))}",
                f"- **Rejected:** {judge.get('REJECTED', processing.get('judge_rejected_count', 0))}",
            ])
            if authoritative:
                reply += f"\n\n### Deterministic portfolio interpretation\n{authoritative}"
            reply += (
                "\n\nAsk me for the bulk summary or ask: **Show summary statistics**, **What is the majority issue?**, "
                "**Which source has the most missing records?**, **Show Judge outcomes**, "
                "**Which users have exact changes?**, **Show batch timing**, or **Give me the batch ZIP link**."
            )
            await self.sessions.append(
                job.session_id,
                role="assistant",
                content=reply,
                metadata={
                    "intent": "batch_completed",
                    "job_id": job.job_id,
                    "batch_id": job.batch_id,
                },
            )
        except SessionNotFound:
            return

    async def _publish_failed_batch_to_session(self, job: BatchJob) -> None:
        if not job.session_id or self.sessions is None:
            return
        try:
            await self.sessions.set_active_batch_status(
                job.session_id,
                job.job_id,
                status=job.status.value,
                phase=job.phase,
            )
            await self.sessions.append(
                job.session_id,
                role="assistant",
                content=(
                    f"Bulk analysis {job.job_id} failed during {job.phase}. "
                    f"Error: {(job.error or {}).get('message') or 'Unknown error'}."
                ),
                metadata={"intent": "batch_failed", "job_id": job.job_id},
            )
        except SessionNotFound:
            return

    @staticmethod
    def view(job: BatchJob, base_url: str) -> BatchJobView:
        processing = (job.summary or {}).get("processing") or {}
        started = job._started_perf
        elapsed_ms = int((perf_counter() - started) * 1000) if started is not None and job.status == BatchJobStatus.RUNNING else 0
        if job.started_at and job.completed_at:
            elapsed_ms = int((job.completed_at - job.started_at).total_seconds() * 1000)
        root = base_url.rstrip("/")
        links = {
            "self": f"{root}/api/v1/batches/{job.job_id}",
            "summary": f"{root}/api/v1/batches/{job.job_id}/summary",
            "download": f"{root}/api/v1/batches/{job.job_id}/download",
            "download_masked": f"{root}/api/v1/batches/{job.job_id}/download?masked=true",
            "download_unmasked": f"{root}/api/v1/batches/{job.job_id}/download?masked=false",
        }
        return BatchJobView(
            job_id=job.job_id,
            status=job.status,
            phase=job.phase,
            created_at=job.created_at,
            started_at=job.started_at,
            completed_at=job.completed_at,
            submitted_count=int(job.parse_result.get("submitted_count") or 0),
            unique_valid_count=int(job.parse_result.get("unique_valid_count") or 0),
            duplicate_count=int(job.parse_result.get("duplicate_count") or 0),
            invalid_count=int(job.parse_result.get("invalid_count") or 0),
            completed_count=int(processing.get("completed_count") or 0),
            failed_count=int(processing.get("failed_count") or 0),
            batch_id=job.batch_id,
            elapsed_ms=elapsed_ms,
            error=job.error,
            links=links,
        )

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from ..concurrency_policy import DELL_AIA_PARALLEL_WORKERS, SOURCE_PARALLEL_WORKERS
from ..models import SearchType


class ApiError(BaseModel):
    code: str
    message: str
    details: dict[str, Any] = Field(default_factory=dict)


class ApiEnvelope(BaseModel):
    success: bool
    data: Any = None
    error: ApiError | None = None
    request_id: str


class SessionCreateRequest(BaseModel):
    metadata: dict[str, Any] = Field(default_factory=dict)


class SessionMessage(BaseModel):
    message_id: str
    role: Literal["user", "assistant", "system"]
    content: str
    created_at: datetime
    metadata: dict[str, Any] = Field(default_factory=dict)


class SessionView(BaseModel):
    session_id: str
    created_at: datetime
    updated_at: datetime
    expires_at: datetime
    active_run_id: str | None = None
    # Backward-compatible alias: this is the active asynchronous batch JOB id.
    active_batch_id: str | None = None
    active_batch_job_id: str | None = None
    active_batch_result_id: str | None = None
    active_context: Literal["none", "individual", "batch"] = "none"
    has_active_batch_summary: bool = False
    active_source_change_id: str | None = None
    active_source_change_status: str | None = None
    message_count: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)
    report_history: list[dict[str, Any]] = Field(default_factory=list)
    messages: list[SessionMessage] = Field(default_factory=list)


class IndividualAnalysisRequest(BaseModel):
    search_type: SearchType = SearchType.EMAIL
    search_value: str = Field(min_length=1, max_length=320)
    session_id: str | None = None
    include_raw_source_data: bool = True
    include_html: bool = False
    mask_report_values: bool = False
    actor: str | None = Field(default=None, max_length=200)
    actor_email: str | None = Field(default=None, max_length=320)
    actor_role: str | None = Field(default=None, max_length=32)
    actor_dry_run_enabled: bool | None = None
    actor_id: str | None = Field(default=None, max_length=200)

    @field_validator("search_value")
    @classmethod
    def trim_value(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("search_value cannot be empty")
        return value


class ChatContext(str, Enum):
    AUTO = "auto"
    INDIVIDUAL = "individual"
    BATCH = "batch"


class ChatAction(str, Enum):
    AUTO = "auto"
    ANALYZE = "analyze"
    SUMMARY = "summary"
    SUGGESTIONS = "suggestions"
    SOURCE_HEALTH = "source_health"
    SOURCE_CPS = "source_cps"
    SOURCE_QUERY = "source_query"
    SOURCE_CHANGE = "source_change"
    SOURCE_CONFIRM_1 = "source_confirm_1"
    SOURCE_CONFIRM_2 = "source_confirm_2"
    SOURCE_CANCEL = "source_cancel"
    TIMING = "timing"
    REPORT_LINKS = "report_links"
    BATCH_STATUS = "batch_status"
    BATCH_SUMMARY = "batch_summary"
    BATCH_FINDINGS = "batch_findings"
    BATCH_STATISTICS = "batch_statistics"
    BATCH_MAJORITY_ISSUE = "batch_majority_issue"
    BATCH_SOURCE_COVERAGE = "batch_source_coverage"
    BATCH_JUDGE_OUTCOMES = "batch_judge_outcomes"
    BATCH_TIMING = "batch_timing"
    BATCH_REPORT_LINKS = "batch_report_links"
    HELP = "help"
    RESET = "reset"


class ChatRequest(BaseModel):
    session_id: str
    message: str = Field(min_length=1, max_length=8000)
    action: ChatAction = ChatAction.AUTO
    context: ChatContext = ChatContext.AUTO
    search_type: SearchType | None = None
    search_value: str | None = None
    judge_response: bool | None = None
    actor: str | None = Field(default=None, max_length=200)
    actor_email: str | None = Field(default=None, max_length=320)
    actor_role: str | None = Field(default=None, max_length=32)
    actor_dry_run_enabled: bool | None = None

    @field_validator("message")
    @classmethod
    def trim_message(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("message cannot be empty")
        return value


class ChatResponse(BaseModel):
    session_id: str
    message_id: str
    reply: str
    intent: str
    active_run_id: str | None = None
    active_batch_id: str | None = None
    report_links: dict[str, str] = Field(default_factory=dict)
    batch_links: dict[str, str] = Field(default_factory=dict)
    structured_data: dict[str, Any] = Field(default_factory=dict)
    judge: dict[str, Any] = Field(default_factory=dict)
    memory: dict[str, Any] = Field(default_factory=dict)


class BatchEmailsRequest(BaseModel):
    emails: list[str] = Field(min_length=1)
    session_id: str | None = None
    # v11.37: the .NET role boundary decides whether caller-supplied values are
    # honored. The Python service enforces only safe upper/lower bounds.
    max_parallel: int = Field(default=SOURCE_PARALLEL_WORKERS, ge=1, le=8)
    max_parallel_ai: int = Field(default=DELL_AIA_PARALLEL_WORKERS, ge=1, le=2)
    include_group_ai: bool = True


class BatchJobStatus(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class BatchJobView(BaseModel):
    job_id: str
    status: BatchJobStatus
    phase: str
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    submitted_count: int = 0
    unique_valid_count: int = 0
    duplicate_count: int = 0
    invalid_count: int = 0
    completed_count: int = 0
    failed_count: int = 0
    batch_id: str | None = None
    elapsed_ms: int = 0
    error: dict[str, Any] | None = None
    links: dict[str, str] = Field(default_factory=dict)


class SourceSystem(str, Enum):
    CPS = "cps"
    REWARDS_DB = "rewards_db"
    CROWD_TWIST = "crowd_twist"


class SourceOperation(str, Enum):
    QUERY = "query"
    UPDATE = "update"
    CREATE = "create"


class SourceQueryRequest(BaseModel):
    # ``source`` is retained for backward compatibility. New clients should use
    # ``sources`` so one request can retrieve any CPS / Rewards DB / CrowdTwist
    # combination without repeating identifier-resolution work.
    source: SourceSystem | None = None
    sources: list[SourceSystem] = Field(default_factory=list, max_length=3)
    emails: list[str] = Field(default_factory=list, max_length=200)
    search_type: SearchType | None = None
    search_value: str | None = Field(default=None, max_length=320)
    query: str | None = Field(default=None, max_length=320)
    session_id: str | None = None
    max_parallel: int = Field(default=SOURCE_PARALLEL_WORKERS, ge=1, le=8)
    actor: str | None = Field(default=None, max_length=200)
    actor_email: str | None = Field(default=None, max_length=320)
    actor_role: str | None = Field(default=None, max_length=32)
    actor_dry_run_enabled: bool | None = None

    @field_validator("max_parallel", mode="before")
    @classmethod
    def force_source_query_parallelism(cls, _value: Any) -> int:
        return SOURCE_PARALLEL_WORKERS

    @field_validator("sources")
    @classmethod
    def normalize_sources(cls, values: list[SourceSystem]) -> list[SourceSystem]:
        result: list[SourceSystem] = []
        for value in values:
            source = SourceSystem(value)
            if source not in result:
                result.append(source)
        return result

    @field_validator("emails")
    @classmethod
    def normalize_source_emails(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        seen: set[str] = set()
        for value in values:
            email = str(value or "").strip()
            if not email or "@" not in email:
                continue
            key = email.casefold()
            if key not in seen:
                seen.add(key)
                result.append(email)
        return result

    @field_validator("search_value")
    @classmethod
    def normalize_search_value(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip()
        return value or None

    @model_validator(mode="after")
    def require_source_selection(self) -> "SourceQueryRequest":
        if self.source is not None and self.source not in self.sources:
            self.sources.insert(0, self.source)
        if not self.sources:
            raise ValueError("At least one source is required")
        if (self.search_type is None) != (self.search_value is None):
            raise ValueError("search_type and search_value must be supplied together")
        return self


class SourceChangePlanRequest(BaseModel):
    session_id: str
    source: SourceSystem
    operation: SourceOperation = SourceOperation.UPDATE
    emails: list[str] = Field(min_length=1, max_length=25)
    field: str = Field(min_length=1, max_length=100)
    new_value: Any
    reason: str | None = Field(default=None, max_length=1000)
    actor: str | None = Field(default=None, max_length=200)
    actor_email: str | None = Field(default=None, max_length=320)
    actor_role: str | None = Field(default=None, max_length=32)
    actor_dry_run_enabled: bool | None = None

    @field_validator("emails")
    @classmethod
    def normalize_change_emails(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        seen: set[str] = set()
        for value in values:
            email = str(value or "").strip()
            if not email or "@" not in email:
                continue
            key = email.casefold()
            if key not in seen:
                seen.add(key)
                result.append(email)
        if not result:
            raise ValueError("At least one valid email is required")
        return result


class SourceChangeConfirmationRequest(BaseModel):
    session_id: str
    confirmation_text: str = Field(min_length=1, max_length=200)
    approval_channel: Literal["chat", "popup", "api"] = "api"
    popup_acknowledged: bool = False
    audit_acknowledged: bool = False
    plan_digest: str | None = Field(default=None, min_length=64, max_length=64)
    popup_token: str | None = Field(default=None, min_length=32, max_length=256)
    actor: str | None = Field(default=None, max_length=200)
    actor_email: str | None = Field(default=None, max_length=320)
    actor_role: str | None = Field(default=None, max_length=32)
    actor_dry_run_enabled: bool | None = None


class SourceChangePopupOpenedRequest(BaseModel):
    session_id: str
    actor: str | None = Field(default=None, max_length=200)
    actor_email: str | None = Field(default=None, max_length=320)
    actor_role: str | None = Field(default=None, max_length=32)
    actor_dry_run_enabled: bool | None = None


class SourceChangeCancelRequest(BaseModel):
    session_id: str
    reason: str | None = Field(default=None, max_length=500)
    actor: str | None = Field(default=None, max_length=200)
    actor_email: str | None = Field(default=None, max_length=320)
    actor_role: str | None = Field(default=None, max_length=32)
    actor_dry_run_enabled: bool | None = None


class SpreadsheetSourceChangeRow(BaseModel):
    row_number: int = Field(ge=2, le=1000000)
    source: SourceSystem = SourceSystem.CROWD_TWIST
    identifier_type: SearchType
    identifier_value: str = Field(min_length=1, max_length=320)
    field: str = Field(min_length=1, max_length=100)
    new_value: Any
    original_property_name: str | None = Field(default=None, max_length=100)

    @field_validator("identifier_value", "field")
    @classmethod
    def trim_spreadsheet_text(cls, value: str) -> str:
        value = str(value or "").strip()
        if not value:
            raise ValueError("value cannot be empty")
        return value


class SpreadsheetSourceChangeImportRequest(BaseModel):
    session_id: str = Field(min_length=1, max_length=128)
    file_name: str = Field(min_length=1, max_length=260)
    instruction: str = Field(default="validate these spreadsheet changes", max_length=1000)
    rows: list[SpreadsheetSourceChangeRow] = Field(min_length=1, max_length=500)
    actor: str | None = Field(default=None, max_length=200)
    actor_email: str | None = Field(default=None, max_length=320)
    actor_role: str | None = Field(default=None, max_length=32)
    actor_dry_run_enabled: bool | None = None


class CpsSourceQueryRequest(BaseModel):
    emails: list[str] = Field(default_factory=list, max_length=200)
    search_type: SearchType | None = None
    search_value: str | None = Field(default=None, max_length=320)
    query: str | None = Field(default=None, max_length=320)
    session_id: str | None = None
    max_parallel: int = Field(default=SOURCE_PARALLEL_WORKERS, ge=1, le=8)

    @field_validator("max_parallel", mode="before")
    @classmethod
    def force_cps_query_parallelism(cls, _value: Any) -> int:
        return SOURCE_PARALLEL_WORKERS

    @field_validator("emails")
    @classmethod
    def normalize_emails(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        seen: set[str] = set()
        for value in values:
            email = str(value or "").strip()
            if not email or "@" not in email:
                continue
            key = email.casefold()
            if key not in seen:
                seen.add(key)
                result.append(email)
        return result


class PayloadValidationRequest(BaseModel):
    operation_id: str = Field(min_length=1)
    payload: dict[str, Any] = Field(default_factory=dict)


class UseCasePlanRequest(BaseModel):
    run_id: str = Field(min_length=1)
    use_case_id: str = Field(min_length=1)
    include_dell_aia_review: bool = True

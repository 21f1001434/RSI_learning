from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from ..reporting import render_html_report
from ..security import contains_mask_tokens, sanitize
from ..settings import Settings
from .file_security import resolve_direct_child, validate_run_id


class RunNotFound(KeyError):
    pass


class UnmaskedReportUnavailable(RuntimeError):
    """Raised when a legacy run only contains irreversible mask tokens."""


class RunStore:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._memory: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    async def put(self, report: dict[str, Any]) -> None:
        run_id = str(report.get("run_id") or "")
        if not run_id:
            raise ValueError("report has no run_id")
        async with self._lock:
            self._memory[run_id] = report

    async def get(self, run_id: str) -> dict[str, Any]:
        try:
            run_id = validate_run_id(run_id)
        except ValueError as exc:
            raise RunNotFound(run_id) from exc
        async with self._lock:
            item = self._memory.get(run_id)
            if item is not None:
                return item
        path = resolve_direct_child(self.settings.runs_dir, f"{run_id}.json")
        if not path.exists():
            raise RunNotFound(run_id)
        return json.loads(path.read_text(encoding="utf-8"))

    async def view(self, run_id: str, *, masked: bool = False) -> dict[str, Any]:
        report = await self.get(run_id)
        if not masked and contains_mask_tokens(report):
            raise UnmaskedReportUnavailable(
                "This legacy run was persisted only with masked values. Rerun the analysis after applying v11.4 to obtain actual values."
            )
        output = sanitize(report) if masked else json.loads(json.dumps(report, default=str))
        if isinstance(output, dict):
            output["report_privacy"] = "MASKED" if masked else "UNMASKED"
        return output

    async def html(self, run_id: str, *, masked: bool = False) -> str:
        try:
            run_id = validate_run_id(run_id)
        except ValueError as exc:
            raise RunNotFound(run_id) from exc
        suffix = ".masked.html" if masked else ".html"
        path = resolve_direct_child(self.settings.runs_dir, f"{run_id}{suffix}")
        if path.exists():
            text = path.read_text(encoding="utf-8")
            if not masked and contains_mask_tokens(text):
                # v11.2 may have written masked data into the nominally unmasked path.
                report = await self.view(run_id, masked=False)
                text = render_html_report(report, mask_pii=False)
                path.write_text(text, encoding="utf-8")
            return text
        report = await self.view(run_id, masked=False)
        html = render_html_report(report, mask_pii=masked)
        self.settings.runs_dir.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
        return html

    async def json_path(self, run_id: str, *, masked: bool = False) -> Path:
        try:
            run_id = validate_run_id(run_id)
        except ValueError as exc:
            raise RunNotFound(run_id) from exc
        suffix = ".masked.json" if masked else ".json"
        path = resolve_direct_child(self.settings.runs_dir, f"{run_id}{suffix}")
        if path.exists():
            existing = json.loads(path.read_text(encoding="utf-8"))
            if masked or not contains_mask_tokens(existing):
                return path
        output = await self.view(run_id, masked=masked)
        self.settings.runs_dir.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(output, indent=2, default=str), encoding="utf-8")
        return path

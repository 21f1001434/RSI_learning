from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import ClassVar

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from ..concurrency_policy import DELL_AIA_PARALLEL_WORKERS, SOURCE_PARALLEL_WORKERS
from src.app_settings import APP_NAME, APP_VERSION, RUNS_DIR


class ApiSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    api_title: str = APP_NAME
    api_version: str = APP_VERSION
    api_host: str = "127.0.0.1"
    api_port: int = 8088
    api_root_path: str = ""
    api_docs_enabled: bool = True
    api_cors_origins: str = "http://localhost:5000,http://localhost:5001,http://localhost:7000,http://localhost:7001"
    api_internal_key: str = ""
    api_require_internal_key: bool = False

    session_ttl_minutes: int = 60
    session_max_messages: int = 50
    session_max_count: int = 500
    session_cleanup_interval_seconds: int = 60

    chat_history_messages: int = 16
    chat_judge_enabled: bool = True
    chat_max_response_chars: int = 12000
    chat_rate_limit_retries: int = 4

    batch_output_dir: Path = Field(default=RUNS_DIR / "batches")
    batch_max_parallel: ClassVar[int] = SOURCE_PARALLEL_WORKERS
    batch_max_parallel_ai: ClassVar[int] = DELL_AIA_PARALLEL_WORKERS
    batch_max_emails: int = 500
    batch_job_ttl_hours: int = 24

    @property
    def cors_origin_list(self) -> list[str]:
        values = [item.strip() for item in self.api_cors_origins.split(",") if item.strip()]
        return values or ["*"]


@lru_cache(maxsize=1)
def load_api_settings() -> ApiSettings:
    return ApiSettings()

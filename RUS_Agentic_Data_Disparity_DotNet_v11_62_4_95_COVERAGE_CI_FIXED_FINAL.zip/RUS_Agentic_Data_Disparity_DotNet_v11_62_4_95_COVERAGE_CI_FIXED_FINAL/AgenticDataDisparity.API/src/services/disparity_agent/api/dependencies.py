from __future__ import annotations

import secrets
from typing import Annotated

from fastapi import Header, HTTPException, Request, status

from .batch_jobs import BatchJobManager
from .chat_service import ChatService
from .config import ApiSettings
from .run_store import RunStore
from .session_store import InMemorySessionStore
from .source_operations import SourceOperationService


def get_api_settings(request: Request) -> ApiSettings:
    return request.app.state.api_settings


def get_sessions(request: Request) -> InMemorySessionStore:
    return request.app.state.sessions


def get_runs(request: Request) -> RunStore:
    return request.app.state.runs


def get_chat_service(request: Request) -> ChatService:
    return request.app.state.chat_service


def get_batch_jobs(request: Request) -> BatchJobManager:
    return request.app.state.batch_jobs


def get_source_operations(request: Request) -> SourceOperationService:
    return request.app.state.source_operations


async def verify_internal_key(
    request: Request,
    x_internal_api_key: Annotated[str | None, Header(alias="X-Internal-API-Key")] = None,
) -> None:
    settings: ApiSettings = request.app.state.api_settings
    if not settings.api_require_internal_key:
        return
    configured = settings.api_internal_key
    if not configured or not x_internal_api_key or not secrets.compare_digest(configured, x_internal_api_key):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing internal API key")

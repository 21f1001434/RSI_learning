"""FastAPI surface for the Agentic Data Disparity Checker."""

from .app import create_app

__all__ = ["create_app"]

from __future__ import annotations

import asyncio
from copy import deepcopy
import hashlib
import json
import re
import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
from time import perf_counter
from typing import Any
from urllib.parse import quote, urlparse

import httpx

from ..connectors.cps import CPSConnector
from ..connectors.crowd_twist import CrowdTwistConnector
from ..connectors.rewards_db import RewardsDBConnector
from ..field_mapping import canonicalize, load_field_map
from ..identity_resolution import resolve_crowd_twist_user
from ..identifier_input import IdentifierMatch, extract_identifiers, remember_identifier, remember_identity_bundle, resolve_identifier
from ..models import SearchType, SourceName
from ..pipeline import DisparityPipeline
from ..normalization import normalize
from ..security import sanitize
from ..settings import Settings
from ..concurrency_policy import SOURCE_PARALLEL_WORKERS
from .schemas import SourceOperation, SourceSystem
from .session_store import InMemorySessionStore, SessionState

EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b")
CHANGE_ID_RE = re.compile(r"(?i)\bCHG-[A-F0-9]{12}\b")

SOURCE_ALIASES: dict[SourceSystem, tuple[str, ...]] = {
    SourceSystem.CPS: ("cps",),
    SourceSystem.REWARDS_DB: ("rewardsdb", "rewards db", "rewards database", "member db", "member database"),
    SourceSystem.CROWD_TWIST: ("crowdtwist", "crowd twist", "ct"),
}

# CPS is the authoritative read/reference source for Agentic disparity decisions.
# Agentic AI may correct only the writable downstream systems. Manual CPS page
# behavior is intentionally outside this service and remains unchanged.
AGENTIC_WRITABLE_SOURCES = frozenset({
    SourceSystem.REWARDS_DB,
    SourceSystem.CROWD_TWIST,
})

FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    "profile_id": ("profile id", "profileid", "third party id", "third_party_id"),
    "email": ("email", "email address", "email_address"),
    "country": ("country", "country code", "countrycode", "country_code"),
    "is_active": ("active status", "is active", "isactive", "is_active", "status"),
    "crowd_twist_id": ("crowdtwist id", "crowd twist id", "crowdtwistid", "crowd_twist_id"),
    "member_key": ("member key", "memberkey", "member_key"),
    "first_name": ("first name", "firstname", "first_name"),
    "last_name": ("last name", "lastname", "last_name"),
    "phone": ("phone", "phone number", "mobile phone", "mobile_phone_number"),
    "postal_code": ("postal code", "postalcode", "postal_code", "zip code"),
    "city_id": ("city id", "cityid", "city_id"),
}

# Canonical field -> (wire/database field, data type)
WRITE_FIELDS: dict[SourceSystem, dict[str, tuple[str, str]]] = {
    SourceSystem.CPS: {
        "first_name": ("firstName", "text_ci"),
        "last_name": ("lastName", "text_ci"),
        "email": ("email", "email"),
        "country": ("country", "country"),
    },
    SourceSystem.REWARDS_DB: {
        "country": ("CountryCode", "country"),
        "is_active": ("IsActive", "boolean"),
        "crowd_twist_id": ("CrowdTwistID", "integer"),
        "member_key": ("MemberKey", "integer"),
        "profile_id": ("ProfileId", "guid"),
    },
    SourceSystem.CROWD_TWIST: {
        "first_name": ("first_name", "text_ci"),
        "last_name": ("last_name", "text_ci"),
        "email": ("email_address", "email"),
        "country": ("country_code", "country"),
        "profile_id": ("third_party_id", "guid"),
        "is_active": ("is_active", "boolean"),
        "phone": ("mobile_phone_number", "phone"),
        "postal_code": ("postal_code", "postal_code"),
        "city_id": ("city_id", "integer"),
    },
}


class SourceOperationError(RuntimeError):
    def __init__(self, code: str, message: str, status_code: int = 400, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.details = details or {}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _ci_get(data: Any, *keys: str) -> Any:
    if not isinstance(data, dict):
        return None
    folded = {str(k).casefold(): v for k, v in data.items()}
    for key in keys:
        if key in data:
            return data[key]
        value = folded.get(key.casefold())
        if value is not None:
            return value
    return None


def _values_equal(left: Any, right: Any, data_type: str | None = None) -> bool:
    if left is None or right is None:
        return left is None and right is None

    # For fields whose wire representation commonly changes formatting, compare
    # using the same normalizer as the disparity engine. Country is deliberately
    # excluded: CrowdTwist must persist the canonical ISO code itself, so a GET
    # returning "Canada" must not verify a requested write of "CA".
    if data_type in {"boolean", "email", "guid", "integer", "phone", "postal_code"}:
        left_norm = normalize(left, data_type)
        right_norm = normalize(right, data_type)
        if left_norm.valid and right_norm.valid:
            return left_norm.value == right_norm.value

    if isinstance(left, bool) or isinstance(right, bool):
        left_bool = str(left).strip().casefold() in {"true", "1", "yes", "active"}
        right_bool = str(right).strip().casefold() in {"true", "1", "yes", "active"}
        return left_bool == right_bool
    return str(left).strip().casefold() == str(right).strip().casefold()


def _safe_http_preview(response: httpx.Response, limit: int = 320) -> str:
    try:
        text = response.text.strip().replace("\r", " ").replace("\n", " ")
    except Exception:
        return ""
    lowered = text.casefold()
    if any(token in lowered for token in ("access_token", "client_secret", "authorization", "password")):
        return "<sensitive response omitted>"
    return text[:limit]


def _write_data_type(source: SourceSystem, field: str) -> str | None:
    spec = WRITE_FIELDS.get(source, {}).get(field)
    return spec[1] if spec else None


def _dedupe_emails(values: list[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        email = str(value or "").strip()
        if not email or "@" not in email:
            continue
        key = email.casefold()
        if key not in seen:
            seen.add(key)
            result.append(email)
    return result


def _source_label(source: SourceSystem) -> str:
    return {
        SourceSystem.CPS: "CPS",
        SourceSystem.REWARDS_DB: "Rewards DB",
        SourceSystem.CROWD_TWIST: "CrowdTwist",
    }[source]


def _normalize_actor_role(role: Any) -> str:
    value = str(role or "").strip().casefold()
    if value in {"admin"}:
        return "Admin"
    if value in {"technical", "technician", "engineer", "operator"}:
        return "Technical"
    if value in {"business", "business user", "buisness"}:
        return "Business"
    return "Customer"


def _can_govern_agentic_write(role: Any) -> bool:
    # v11.62: all authenticated RUS profiles can use governed downstream writes.
    # Missing/blank role metadata is still fail-closed so a direct unauthenticated
    # Python caller cannot inherit Customer permissions accidentally.
    raw = str(role or "").strip()
    if not raw:
        return False
    return _normalize_actor_role(raw) in {"Customer", "Business", "Technical", "Admin"}


def _role_approval_profile(role: Any, *, explicit: bool = False) -> str:
    normalized = _normalize_actor_role(role)
    slug = normalized.casefold().replace(" ", "_")
    if explicit:
        return f"{slug}_explicit_chat"
    if normalized == "Business":
        return "business_chat_single"
    return f"{slug}_chat_popup_review"


class SourceOperationService:
    """Read and change source systems with governed execution.

    Agentic writes are derived from a fresh cross-source analysis and are limited
    to Rewards DB and CrowdTwist. CPS remains the read-only truth/reference source.
    Approval is profile-governed in every Agentic AI path. Business requires one
    explicit chat approval; Customer Support, Technical and Admin require chat
    approval followed by the final-review popup. Initial write instructions create
    an exact grounded plan rather than silently bypassing the configured approval
    policy. Customer Support, Business, Technical and Admin can all execute governed
    downstream changes after their profile approvals. Every live write still performs
    a last-moment source re-read,
    read-after-write verification, audit logging, and fresh cross-source analysis.
    v11.42 resolves write mode from the authenticated user profile. Admin is
    always governed-live; non-Admin users may be assigned Dry Run by an Admin.
    SOURCE_WRITE_MODE=disabled remains the emergency operator kill switch, while
    legacy direct Python callers without profile metadata retain the configured
    global mode.
    """

    def __init__(self, settings: Settings, sessions: InMemorySessionStore) -> None:
        self.settings = settings
        self.sessions = sessions
        self.field_map = load_field_map(settings.field_map_path)
        self._audit_lock = asyncio.Lock()

    @staticmethod
    def project_query_for_role(result: dict[str, Any], role: Any) -> dict[str, Any]:
        normalized_role = _normalize_actor_role(role)
        if normalized_role in {"Technical", "Admin"}:
            return result

        projected = deepcopy(result)
        allowed_customer = {
            "email", "profile_id", "first_name", "last_name", "country", "country_code",
            "is_active", "status", "phone", "postal_code"
        }
        allowed_business = allowed_customer | {"crowd_twist_id", "member_key", "tier", "points", "balance"}
        allowed = allowed_business if normalized_role == "Business" else allowed_customer

        for member in projected.get("members") or []:
            if not isinstance(member, dict):
                continue
            identity = member.get("resolved_identity")
            if isinstance(identity, dict) and normalized_role == "Customer":
                identity.pop("crowd_twist_id", None)
                identity.pop("member_key", None)
            for item in (member.get("results") or {}).values():
                if not isinstance(item, dict):
                    continue
                canonical = item.get("canonical")
                if isinstance(canonical, dict):
                    item["canonical"] = {k: v for k, v in canonical.items() if k in allowed}
                for key in ("record", "identifier_resolution", "raw", "payload", "metadata", "diagnostics", "error"):
                    item.pop(key, None)
                if normalized_role == "Customer":
                    item.pop("retrieval_method", None)
            if normalized_role == "Customer":
                member.pop("lookup_path", None)
                member.pop("duration_ms", None)

        if normalized_role == "Customer":
            projected.pop("duration_ms", None)
            projected.pop("rewards_db_dependency_resolution", None)
            projected.pop("crowd_twist_dependency_resolution", None)
        return projected

    @staticmethod
    def require_agentic_write_role(role: Any) -> None:
        if not _can_govern_agentic_write(role):
            raise SourceOperationError(
                "ROLE_NOT_AUTHORIZED",
                "An authenticated RUS profile is required for Agentic source updates.",
                status_code=403,
                details={"required_roles": ["Customer", "Business", "Technical", "Admin"], "actual_role": _normalize_actor_role(role)},
            )

    def _effective_write_mode(self, state: SessionState, role: Any | None = None) -> str:
        """Resolve the governed write mode for the authenticated user profile.

        `disabled` remains an emergency operator kill switch. For authenticated
        profile-aware requests, Admin is always live and other roles follow the
        per-user Dry Run flag supplied by the trusted .NET boundary. Legacy direct
        Python callers that do not carry profile metadata retain the configured
        SOURCE_WRITE_MODE behavior.
        """
        if self.settings.source_write_mode == "disabled":
            return "disabled"
        normalized_role = _normalize_actor_role(role or state.metadata.get("actor_role"))
        if normalized_role == "Admin":
            return "live"
        if "actor_dry_run_enabled" in state.metadata:
            return "dry_run" if bool(state.metadata.get("actor_dry_run_enabled")) else "live"
        return self.settings.source_write_mode

    async def apply_session_write_policy(
        self,
        session_id: str,
        *,
        actor_role: Any | None = None,
        actor_dry_run_enabled: bool | None = None,
    ) -> str:
        state = await self.sessions.get(session_id)
        if actor_role is not None:
            state.metadata["actor_role"] = _normalize_actor_role(actor_role)
        normalized_role = _normalize_actor_role(state.metadata.get("actor_role"))
        if normalized_role == "Admin":
            state.metadata["actor_dry_run_enabled"] = False
        elif actor_dry_run_enabled is not None:
            state.metadata["actor_dry_run_enabled"] = bool(actor_dry_run_enabled)
        mode = self._effective_write_mode(state, normalized_role)
        state.metadata["effective_write_mode"] = mode
        return mode

    # ------------------------------- Chat routing -------------------------------
    async def handle_chat(self, *, session_id: str, message: str, state: SessionState) -> tuple[str, str, dict[str, Any]] | None:
        text = message.strip()
        lower = text.casefold()
        raw_actor_role = state.metadata.get("actor_role")
        actor_role = _normalize_actor_role(raw_actor_role)
        can_govern_write = _can_govern_agentic_write(raw_actor_role)
        identifier = resolve_identifier(text, state.facts)
        explicit_identifiers = extract_identifiers(text)
        if explicit_identifiers:
            # Remember the identifier immediately so phrases such as "the ID above"
            # and "run CPS for it" resolve inside this exact chat session.
            remember_identifier(state.facts, identifier or explicit_identifiers[0])

        # Profile-governed approval is mandatory even for explicit imperatives.
        # A matching active plan treats an explicit command as chat approval 1.
        # Business executes after that chat approval; Customer Support, Technical
        # and Admin advance to the final-review popup. A new field/source request
        # supersedes an older unexecuted plan rather than hijacking it.
        active_change_id = str(state.facts.get("active_source_change_id") or "").upper()
        referenced_change = CHANGE_ID_RE.search(text)
        if referenced_change:
            referenced_change_id = referenced_change.group(0).upper()
            # _get_change is session-scoped, so a change identifier from another
            # user's/session's card cannot be approved here.
            await self._get_change(session_id, referenced_change_id)
            active_change_id = referenced_change_id
        normalized_reply = re.sub(r"[.!?]+$", "", lower).strip()
        requested_field = self.extract_requested_attribute(text)
        requested_sources = self.detect_requested_target_sources(text, requested_field)
        explicit_execute = self.is_explicit_execution_request(text)
        apply_all = self.is_apply_all_request(text)

        pending_spreadsheet_ids = list(state.facts.get("pending_spreadsheet_change_ids") or [])
        spreadsheet_confirmation = normalized_reply in {"yes", "confirm", "approve", "apply", "do it", "do the changes"}
        if pending_spreadsheet_ids and not referenced_change and (explicit_execute or spreadsheet_confirmation):
            if not can_govern_write:
                return (
                    "spreadsheet_update_not_authorized",
                    "## Excel update execution is not available\nAn authenticated RUS profile with Agentic update permission is required.",
                    {"required_roles": ["Customer", "Business", "Technical", "Admin"], "actual_role": actor_role},
                )
            imported = await self.execute_pending_spreadsheet_changes(
                session_id=session_id, command_text="apply spreadsheet changes", state=state
            )
            if imported is not None:
                intent = (
                    "spreadsheet_updates_executed" if imported.get("execution_completed")
                    else "spreadsheet_updates_awaiting_final_approval" if imported.get("requires_final_approval")
                    else "spreadsheet_updates_validated"
                )
                return (
                    intent,
                    self.spreadsheet_update_reply(imported),
                    {"spreadsheet_update": imported},
                )

        if active_change_id and explicit_execute:
            if not can_govern_write:
                return (
                    "source_change_not_authorized",
                    "## Update approval is not available\nAn authenticated RUS profile with Agentic update permission is required.",
                    {"required_roles": ["Customer", "Business", "Technical", "Admin"], "actual_role": actor_role},
                )
            active_change = await self._get_change(session_id, active_change_id)
            active_source = SourceSystem(str(active_change.get("source")))
            active_field = str(active_change.get("field") or "")
            requested_value = self.extract_requested_value(text)
            field_matches = not requested_field or requested_field == active_field
            source_matches = not requested_sources or active_source in requested_sources
            value_matches = True
            if requested_value not in (None, ""):
                data_type = _write_data_type(active_source, active_field)
                value_matches = _values_equal(requested_value, active_change.get("new_value"), data_type)
            if field_matches and source_matches and not value_matches:
                return (
                    "source_change_value_conflict",
                    "## Requested value blocked\n"
                    f"The requested value `{requested_value}` does not match the active reviewed value "
                    f"`{active_change.get('new_value')}` for {active_field}. No source update was attempted.",
                    {
                        "code": "REQUESTED_VALUE_CONFLICTS_WITH_ACTIVE_PLAN",
                        "change": self.public_change(active_change),
                        "requested_value": requested_value,
                        "planned_value": active_change.get("new_value"),
                        "requested_field": requested_field or active_field,
                        "requested_sources": [source.value for source in requested_sources],
                    },
                )
            if field_matches and source_matches and active_change.get("status") == "AWAITING_CONFIRMATION_1":
                change = await self.confirm_first(
                    session_id,
                    active_change_id,
                    "YES",
                    actor=state.metadata.get("actor") or None,
                    actor_email=state.metadata.get("actor_email") or None,
                    approval_channel="chat",
                    actor_role=actor_role,
                )
                terminal = str(change.get("status") or "").upper()
                if terminal in {"COMPLETED", "PARTIAL", "FAILED", "DRY_RUN_COMPLETED", "BLOCKED_WRITES_DISABLED", "BLOCKED_OPERATION_NOT_CONFIGURED", "ABORTED_PRECONDITION_CHANGED"}:
                    return "source_confirm_2", self._execution_sequence_reply(change), {"change": self.public_change(change), "next_change": change.get("next_change")}
                return "source_confirm_1", self._confirm_two_reply(change), {"change": self.public_change(change), "requires_popup": True}
            if field_matches and source_matches and active_change.get("status") == "AWAITING_CONFIRMATION_2":
                return (
                    "source_popup_required",
                    self._popup_required_reply(active_change),
                    {"change": self.public_change(active_change), "requires_popup": True},
                )
            if (requested_field or requested_sources) and active_change.get("status") in {"AWAITING_CONFIRMATION_1", "AWAITING_CONFIRMATION_2"}:
                # A new specific instruction replaces an older, different
                # unexecuted suggestion. Keep the audit trail but do not let the
                # stale active plan hijack the new request.
                await self.cancel_change(session_id, active_change_id, reason="Superseded by a new explicit Agentic AI update request")
                active_change_id = ""

        # Standalone chat approval follows the authenticated profile policy.
        if active_change_id and normalized_reply in {"yes", "confirm", "approve", "apply"} and not can_govern_write:
            return (
                "source_change_not_authorized",
                "## Update approval is not available\nAn authenticated RUS profile with Agentic update permission is required.",
                {"required_roles": ["Customer", "Business", "Technical", "Admin"], "actual_role": actor_role},
            )
        if active_change_id and normalized_reply in {"yes", "confirm", "approve", "apply"} and can_govern_write:
            active_change = await self._get_change(session_id, active_change_id)
            if active_change.get("status") == "AWAITING_CONFIRMATION_1":
                change = await self.confirm_first(
                    session_id,
                    active_change_id,
                    "YES",
                    actor=state.metadata.get("actor") or None,
                    actor_email=state.metadata.get("actor_email") or None,
                    approval_channel="chat",
                    actor_role=actor_role,
                )
                terminal = str(change.get("status") or "").upper()
                if terminal in {"COMPLETED", "PARTIAL", "FAILED", "DRY_RUN_COMPLETED", "BLOCKED_WRITES_DISABLED", "BLOCKED_OPERATION_NOT_CONFIGURED", "ABORTED_PRECONDITION_CHANGED"}:
                    return "source_confirm_2", self._execution_sequence_reply(change), {"change": self.public_change(change), "next_change": change.get("next_change")}
                return "source_confirm_1", self._confirm_two_reply(change), {"change": self.public_change(change), "requires_popup": True}
            if active_change.get("status") == "AWAITING_CONFIRMATION_2":
                return (
                    "source_popup_required",
                    self._popup_required_reply(active_change),
                    {"change": self.public_change(active_change), "requires_popup": True},
                )

        if active_change_id and normalized_reply in {"no", "cancel"}:
            active_change = await self._get_change(session_id, active_change_id)
            if active_change["status"] in {"AWAITING_CONFIRMATION_1", "AWAITING_CONFIRMATION_2"}:
                change = await self.cancel_change(session_id, active_change_id, reason="Cancelled from Agentic AI chat")
                return "source_change_cancelled", self._cancel_reply(change), {"change": self.public_change(change)}

        # Backward-compatible explicit commands remain supported for API clients
        # and previously bookmarked workflows.
        change_id_match = CHANGE_ID_RE.search(text)
        if change_id_match:
            change_id = change_id_match.group(0).upper()
            if lower.startswith("cancel"):
                change = await self.cancel_change(session_id, change_id, reason="Cancelled from chat")
                return "source_change_cancelled", self._cancel_reply(change), {"change": self.public_change(change)}
            if lower.startswith("confirm"):
                change = await self.confirm_first(
                    session_id, change_id, text, approval_channel="chat", actor_role=actor_role
                )
                if change.get("status") in {"COMPLETED", "PARTIAL", "FAILED", "DRY_RUN_COMPLETED", "BLOCKED_WRITES_DISABLED", "BLOCKED_OPERATION_NOT_CONFIGURED", "ABORTED_PRECONDITION_CHANGED"}:
                    return "source_confirm_2", self._execution_sequence_reply(change), {"change": self.public_change(change), "next_change": change.get("next_change")}
                return "source_confirm_1", self._confirm_two_reply(change), {"change": self.public_change(change)}
            if lower.startswith("apply"):
                change = await self._get_change(session_id, change_id)
                return (
                    "source_popup_required",
                    self._popup_required_reply(change),
                    {"change": self.public_change(change), "requires_popup": True},
                )

        pending_change = state.facts.get("pending_source_change_selection")
        pending_query = state.facts.get("pending_source_query_selection")
        explicit_emails = _dedupe_emails(EMAIL_RE.findall(text))
        all_selected = lower in {"all", "run all", "all of them", "yes all", "select all"} or lower.startswith("all ")

        if isinstance(pending_change, dict) and (all_selected or explicit_emails):
            if not can_govern_write:
                state.facts.pop("pending_source_change_selection", None)
                return (
                    "source_change_not_authorized",
                    "## Update planning is not available\nAn authenticated RUS profile with Agentic update permission is required.",
                    {"required_roles": ["Customer", "Business", "Technical", "Admin"], "actual_role": actor_role},
                )
            candidates = list(pending_change.get("candidates") or [])
            selected = candidates if all_selected else self._select_allowed(explicit_emails, candidates)
            if not selected:
                return "source_change_selection", "Select one of the listed emails or reply **all**.", pending_change
            state.facts.pop("pending_source_change_selection", None)
            change = await self.plan_change(
                session_id=session_id,
                source=SourceSystem(pending_change["source"]),
                operation=SourceOperation(pending_change.get("operation", "update")),
                emails=selected,
                field=str(pending_change["field"]),
                new_value=pending_change.get("new_value"),
                reason=pending_change.get("reason"),
            )
            return "source_change_planned", self._plan_reply(change), {"change": self.public_change(change)}

        if isinstance(pending_query, dict) and (all_selected or explicit_emails):
            candidates = list(pending_query.get("candidates") or [])
            selected = candidates if all_selected else self._select_allowed(explicit_emails, candidates)
            if not selected:
                return "source_query_selection", "Select one of the listed emails or reply **all**.", pending_query
            state.facts.pop("pending_source_query_selection", None)
            sources = [SourceSystem(value) for value in (pending_query.get("sources") or [pending_query.get("source")]) if value]
            selected_identifiers = [
                IdentifierMatch(SearchType.EMAIL, email, index, "session_selection")
                for index, email in enumerate(selected)
            ]
            result = await self.query_identifiers(sources, selected_identifiers)
            state.facts["last_source_query"] = result
            await self.audit_agentic_activity(
                "SOURCE_QUERY_COMPLETED",
                {
                    "session_id": session_id,
                    "actor": state.metadata.get("actor") or "Unknown user",
                    "actor_email": state.metadata.get("actor_email"),
                    "source": "Agentic AI · " + " + ".join(result.get("source_labels") or []),
                    "action": "Agentic source retrieval",
                    "status": "COMPLETED",
                    "target": f"{len(selected)} selected member(s)",
                    "search_type": SearchType.EMAIL.value,
                    "verification": f"{result.get('requested_member_count', 0)} member(s) processed",
                    "details": {
                        "sources": result.get("source_labels"),
                        "duration_ms": result.get("duration_ms"),
                    },
                },
            )
            visible = self.project_query_for_role(result, actor_role)
            return "source_query", self.format_query_reply(visible), visible

        # v11.62: an explicit member identifier plus any write request in a
        # brand-new/different-member session must first build fresh deterministic
        # evidence.  This applies to both recommendation language and literal
        # values.  It prevents the browser/backend from treating
        # ``<identifier> change first name to X`` as a blind direct write and
        # gives ChatService one canonical analyze -> plan -> execute path for
        # Email, Profile ID, and CrowdTwist ID.
        if self.is_write_request(text) and explicit_identifiers and identifier is not None \
                and not self.active_report_matches_identifier(state, identifier):
            if not can_govern_write:
                return (
                    "source_change_not_authorized",
                    "## Changes are not available\nAn authenticated RUS profile with Agentic update permission is required.",
                    {"required_roles": ["Customer", "Business", "Technical", "Admin"], "actual_role": actor_role},
                )
            return (
                "source_change_analysis_required",
                "Analyzing the requested member and deriving the requested governed downstream change.",
                {
                    "identifier": identifier.as_dict(),
                    "change_request": True,
                    "analysis_required": True,
                    "execute_requested": explicit_execute,
                    "apply_all": apply_all,
                    "requested_field": requested_field,
                    "requested_sources": [source.value for source in requested_sources],
                    "requested_value": self.extract_requested_value(text),
                    "writable_sources": [SourceSystem.REWARDS_DB.value, SourceSystem.CROWD_TWIST.value],
                    "truth_source": "per_suggestion_or_explicit_override",
                    "truth_policy": "deterministic_attribute_rules",
                },
            )

        if self.is_suggested_change_request(text):
            if not can_govern_write:
                return (
                    "source_change_not_authorized",
                    "## Changes are not available\nAn authenticated RUS profile with Agentic update permission is required.",
                    {"required_roles": ["Customer", "Business", "Technical", "Admin"], "actual_role": actor_role},
                )

            # A supplied Email/Profile ID/CrowdTwist ID always triggers a fresh
            # cross-source analysis before any write plan is built. This prevents
            # stale recommendations and guarantees that the agent first understands
            # the current CPS truth and then targets only Rewards DB/CrowdTwist.
            # ChatService performs the analysis internally and returns the governed
            # change preview instead of a misleading normal analysis response.
            if explicit_identifiers and identifier is not None and not self.active_report_matches_identifier(state, identifier):
                return (
                    "source_change_analysis_required",
                    "Analyzing the requested member and deriving verified downstream corrections.",
                    {
                        "identifier": identifier.as_dict(),
                        "change_request": True,
                        "analysis_required": True,
                        "execute_requested": explicit_execute,
                        "apply_all": apply_all,
                        "requested_field": requested_field,
                        "requested_sources": [source.value for source in requested_sources],
                        "requested_value": self.extract_requested_value(text),
                        "writable_sources": [SourceSystem.REWARDS_DB.value, SourceSystem.CROWD_TWIST.value],
                        "truth_source": "per_suggestion",
                        "truth_policy": "deterministic_attribute_rules",
                    },
                )
            if explicit_execute:
                # Re-derive the queue from the current active report so a
                # specific request such as "update Country as suggested" cannot
                # accidentally execute a previously popped higher-priority item.
                state.facts.pop("pending_suggested_change_queue", None)
                state.facts.pop("suggested_change_context", None)
            try:
                change = await self.plan_suggested_change_from_report(
                    session_id=session_id,
                    state=state,
                    requested_field=requested_field,
                    requested_source=requested_sources[0] if len(requested_sources) == 1 else None,
                    requested_value=self.extract_requested_value(text),
                    only_requested=bool(requested_field or len(requested_sources) == 1) and not apply_all,
                )
            except SourceOperationError as exc:
                return "source_change_needs_details", f"## Unable to prepare the suggested change\n{str(exc)}", {"code": exc.code}
            if identifier is not None:
                change["requested_identifier"] = identifier.as_dict()
            return "source_change_planned", self._plan_reply(change), {
                "change": self.public_change(change),
                "apply_all_requested": apply_all,
                "execution_requested": explicit_execute,
                "approval_required": True,
            }

        sources = (
            self.detect_requested_target_sources(text, requested_field)
            if self.is_write_request(text)
            else self.detect_sources(text)
        )

        # v11.46: explicit literal attribute updates may omit the source when the
        # active verified report identifies exactly one writable target. Example:
        # "change Country to JP" after a report whose Country suggestion targets
        # CrowdTwist. The literal value is preserved; if it differs from the
        # deterministic recommendation it is recorded as a manual override rather
        # than being silently replaced. If the target is ambiguous, ask the user.
        if not sources and self.is_write_request(text) and requested_field and self.extract_requested_value(text) not in (None, ""):
            if not can_govern_write:
                return (
                    "source_change_not_authorized",
                    "## Update approval unavailable\nThis request does not contain a trusted authenticated RUS role. Customer Support, Business, Technical and Admin can all use governed downstream updates.",
                    {"required_roles": ["Customer", "Business", "Technical", "Admin"], "actual_role": actor_role},
                )
            requested_value = self.extract_requested_value(text)
            suggestion_sources: list[SourceSystem] = []
            matching_suggestions: list[dict[str, Any]] = []
            for item in list((state.last_report or {}).get("suggestions") or []):
                if not isinstance(item, dict):
                    continue
                item_field = self.resolve_field(str(item.get("attribute") or item.get("field") or "")) or str(item.get("attribute") or item.get("field") or "")
                if item_field != requested_field:
                    continue
                source = self._suggestion_source(item.get("target_source"))
                if source in AGENTIC_WRITABLE_SOURCES:
                    matching_suggestions.append(item)
                    if source not in suggestion_sources:
                        suggestion_sources.append(source)
            supported_sources = [
                source for source in AGENTIC_WRITABLE_SOURCES
                if requested_field in WRITE_FIELDS.get(source, {})
            ]
            inferred_sources = suggestion_sources or supported_sources
            if len(inferred_sources) != 1:
                labels = ", ".join(_source_label(source) for source in inferred_sources) or "none"
                return (
                    "source_change_needs_source",
                    "## Choose the update target\n"
                    f"The field **{requested_field}** can map to more than one downstream source (or no unique source could be inferred). "
                    f"Available target(s): **{labels}**. State **Rewards DB** or **CrowdTwist** explicitly.",
                    {"requested_field": requested_field, "requested_value": requested_value, "candidate_sources": [source.value for source in inferred_sources]},
                )
            source = inferred_sources[0]
            emails = explicit_emails
            identity_resolution: dict[str, Any] | None = None
            if not emails and identifier is not None:
                resolved_email, identity_resolution = await self.resolve_email_for_identifier(identifier)
                if resolved_email:
                    emails = [resolved_email]
                    member = (identity_resolution.get("members") or [{}])[0]
                    remember_identity_bundle(state.facts, member.get("resolved_identity") or {})
            if not emails:
                candidates = self.find_candidate_emails(state, "")
                if len(candidates) == 1:
                    emails = candidates
                else:
                    return (
                        "source_change_needs_identifier",
                        "## Update needs one resolvable member\nProvide an email, Profile ID, or CrowdTwist ID, or run/select one member analysis first.",
                        {"requested_field": requested_field, "requested_value": requested_value, "candidate_count": len(candidates)},
                    )
            deterministic_value = None
            truth_source = None
            for item in matching_suggestions:
                if self._suggestion_source(item.get("target_source")) == source:
                    deterministic_value = item.get("recommended_value")
                    truth_source = item.get("truth_source")
                    break
            data_type = _write_data_type(source, requested_field)
            manual_override = deterministic_value not in (None, "") and not _values_equal(requested_value, deterministic_value, data_type)
            reason = "Explicit literal value requested through Agentic AI chat"
            if manual_override:
                reason += f"; manual override differs from deterministic recommendation {deterministic_value}"
            change = await self.plan_change(
                session_id=session_id,
                source=source,
                operation=SourceOperation.UPDATE,
                emails=emails,
                field=requested_field,
                new_value=requested_value,
                reason=reason,
            )
            change.update({
                "literal_value_request": True,
                "manual_override": manual_override,
                "deterministic_recommended_value": deterministic_value,
                "truth_source": truth_source,
                "inferred_target_source": source.value,
            })
            if identifier is not None:
                change["requested_identifier"] = identifier.as_dict()
            return "source_change_planned", self._plan_reply(change), {
                "change": self.public_change(change),
                "execution_requested": bool(explicit_execute and not self.is_plan_only_request(text)),
                "approval_required": True,
                "requested_field": requested_field,
                "requested_sources": [source.value],
                "requested_value": requested_value,
                "manual_override": manual_override,
            }

        if not sources:
            return None

        if self.is_write_request(text):
            if not can_govern_write:
                return (
                    "source_change_not_authorized",
                    "## Update approval unavailable\nThis request does not contain a trusted authenticated RUS role. Customer Support, Business, Technical and Admin can all use governed downstream updates.",
                    {"required_roles": ["Customer", "Business", "Technical", "Admin"], "actual_role": actor_role},
                )
            if len(sources) != 1:
                supported = ", ".join(_source_label(source) for source in sources)
                reply = (
                    "## Choose one update target\n"
                    f"You mentioned **{supported}**. One governed change can update only one source at a time. "
                    "State the target source, field, new value, and an email, Profile ID, or CrowdTwist ID."
                )
                return "source_change_needs_source", reply, {"sources": [source.value for source in sources]}
            source = sources[0]
            if source not in AGENTIC_WRITABLE_SOURCES:
                return (
                    "source_change_read_only_truth_source",
                    "## CPS is the read-only truth source for Agentic AI\n"
                    "The agent analyzes CPS and uses it to determine corrections, but it does not modify CPS. "
                    "Agentic updates are supported only for **Rewards DB** and **CrowdTwist**. "
                    "The existing manual CPS page remains unchanged.",
                    {
                        "code": "CPS_AGENTIC_WRITE_NOT_ALLOWED",
                        "read_only_source": SourceSystem.CPS.value,
                        "writable_sources": [SourceSystem.REWARDS_DB.value, SourceSystem.CROWD_TWIST.value],
                    },
                )
            parsed = self.parse_change_request(text, source)
            if parsed.get("error"):
                return "source_change_needs_details", self._change_details_help(source, parsed["error"]), parsed
            emails = explicit_emails
            query = str(parsed.get("query") or "").strip()
            identity_resolution: dict[str, Any] | None = None
            if not emails and identifier is not None:
                resolved_email, identity_resolution = await self.resolve_email_for_identifier(identifier)
                if resolved_email:
                    emails = [resolved_email]
                    member = (identity_resolution.get("members") or [{}])[0]
                    remember_identity_bundle(state.facts, member.get("resolved_identity") or {})
            if not emails:
                candidates = self.find_candidate_emails(state, query)
                if len(candidates) == 1:
                    emails = candidates
                elif len(candidates) > 1:
                    pending = {
                        "source": source.value,
                        "operation": parsed.get("operation", "update"),
                        "field": parsed["field"],
                        "new_value": parsed["new_value"],
                        "reason": parsed.get("reason"),
                        "query": query,
                        "candidates": candidates,
                    }
                    state.facts["pending_source_change_selection"] = pending
                    return "source_change_selection", self._selection_reply(source, query, candidates, write=True), pending
                else:
                    reply = (
                        f"## {_source_label(source)} update needs a resolvable member\n"
                        "I could not resolve the supplied email, Profile ID, or CrowdTwist ID to one member email. "
                        "Provide one valid identifier and retry. Once the member is resolved, the Agent creates a governed Rewards DB/CrowdTwist plan and follows the authenticated profile's approval policy before execution."
                    )
                    return "source_change_needs_identifier", reply, {
                        **parsed,
                        "identifier": identifier.as_dict() if identifier else None,
                        "identity_resolution": identity_resolution,
                    }
            change = await self.plan_change(
                session_id=session_id,
                source=source,
                operation=SourceOperation(parsed.get("operation", "update")),
                emails=emails,
                field=str(parsed["field"]),
                new_value=parsed["new_value"],
                reason=parsed.get("reason"),
            )
            if identifier is not None:
                change["requested_identifier"] = identifier.as_dict()
            return "source_change_planned", self._plan_reply(change), {
                "change": self.public_change(change),
                "execution_requested": bool(explicit_execute and not self.is_plan_only_request(text)),
                "approval_required": True,
                "requested_field": str(parsed.get("field") or ""),
                "requested_sources": [source.value],
            }

        if self.is_read_request(text):
            query = self.extract_query_term_multi(text, sources)
            if identifier is not None:
                result = await self.query_identifiers(sources, [identifier])
                member = (result.get("members") or [{}])[0]
                remember_identity_bundle(state.facts, member.get("resolved_identity") or {})
            else:
                emails = explicit_emails
                if not emails:
                    candidates = self.find_candidate_emails(state, query)
                    if len(candidates) == 1:
                        emails = candidates
                    elif len(candidates) > 1:
                        pending = {"sources": [source.value for source in sources], "query": query, "candidates": candidates}
                        state.facts["pending_source_query_selection"] = pending
                        return "source_query_selection", self._selection_reply_sources(sources, query, candidates), pending
                    else:
                        return "source_query_needs_identifier", self._identifier_required_reply_sources(sources, query), {
                            "sources": [source.value for source in sources], "query": query
                        }
                email_identifiers = [
                    IdentifierMatch(SearchType.EMAIL, email, index, "message")
                    for index, email in enumerate(emails)
                ]
                result = await self.query_identifiers(sources, email_identifiers)
            state.facts["last_source_query"] = result
            await self.audit_agentic_activity(
                "SOURCE_QUERY_COMPLETED",
                {
                    "session_id": session_id,
                    "actor": state.metadata.get("actor") or "Unknown user",
                    "actor_email": state.metadata.get("actor_email"),
                    "source": "Agentic AI · " + " + ".join(result.get("source_labels") or []),
                    "action": "Agentic source retrieval",
                    "status": "COMPLETED",
                    "target": (identifier.label + ": " + identifier.value) if identifier else query or "session match",
                    "search_type": identifier.search_type.value if identifier else SearchType.EMAIL.value,
                    "search_value": identifier.value if identifier else ((result.get("members") or [{}])[0].get("email")),
                    "verification": f"{result.get('requested_member_count', 0)} member(s) processed",
                    "details": {
                        "sources": result.get("source_labels"),
                        "duration_ms": result.get("duration_ms"),
                        "resolved_identity": ((result.get("members") or [{}])[0].get("resolved_identity") or {}),
                    },
                },
            )
            visible = self.project_query_for_role(result, actor_role)
            return "source_query", self.format_query_reply(visible), visible

        return None

    @staticmethod
    def detect_sources(text: str) -> list[SourceSystem]:
        lower = text.casefold()
        detected: list[SourceSystem] = []
        for source, aliases in SOURCE_ALIASES.items():
            for alias in sorted(aliases, key=len, reverse=True):
                matched = bool(re.search(r"(?i)(?:^|\b)ct(?:\b|$)", text)) if alias == "ct" else alias in lower
                if matched:
                    detected.append(source)
                    break
        return detected

    @staticmethod
    def detect_requested_target_sources(text: str, requested_field: str | None = None) -> list[SourceSystem]:
        """Detect downstream *target* systems without confusing field names with sources.

        The canonical field name ``CrowdTwist ID`` contains the word CrowdTwist,
        but a command such as ``fix CrowdTwist ID`` normally means "correct the
        synchronized CrowdTwist ID in Rewards DB" according to the active report.
        Treat CrowdTwist as an explicit target only when the sentence actually
        qualifies it as a system/record target.
        """
        sources = SourceOperationService.detect_sources(text)
        if requested_field == "crowd_twist_id" and SourceSystem.CROWD_TWIST in sources:
            explicit_ct_target = bool(re.search(
                r"(?i)(?:\b(?:in|on|from|target(?:ing)?|source|system)\s+(?:crowd\s*twist|crowdtwist|ct)\b|"
                r"\b(?:crowd\s*twist|crowdtwist|ct)\s+(?:source|system|record|profile)\b)",
                text,
            ))
            if not explicit_ct_target:
                sources = [source for source in sources if source != SourceSystem.CROWD_TWIST]
        return sources

    @staticmethod
    def detect_source(text: str) -> SourceSystem | None:
        sources = SourceOperationService.detect_sources(text)
        return sources[0] if sources else None

    @staticmethod
    def uses_deterministic_recommendation(text: str) -> bool:
        """Return True when the user means "use the value from the active report".

        This is intentionally broader than one exact phrase.  It protects the
        governed writer from ever persisting conversational text such as
        ``as recommended`` as the literal source value.  Common human variants
        and a few frequent misspellings are normalized before matching.
        """
        normalized = str(text or "").casefold()
        normalized = re.sub(r"[_\-]+", " ", normalized)
        normalized = re.sub(r"\s+", " ", normalized).strip()
        misspellings = {
            "recomended": "recommended",
            "recommened": "recommended",
            "recommende": "recommended",
            "recommeded": "recommended",
            "recomend": "recommend",
            "recomendation": "recommendation",
            "recommedation": "recommendation",
        }
        for bad, replacement in misspellings.items():
            normalized = re.sub(rf"\b{re.escape(bad)}\b", replacement, normalized)

        patterns = (
            r"\bas\s+(?:(?:per|you)\s+)?(?:suggestion|suggested|recommendation|recommended|recommend|report|analysis)\b",
            r"\bper\s+(?:the\s+)?(?:suggestion|recommendation|recommended\s+value|report|analysis)\b",
            r"\b(?:according\s+to|based\s+on|from)\s+(?:the\s+)?(?:suggestion|recommendation|recommended\s+value|report|analysis)\b",
            r"\bto\s+(?:the\s+)?(?:correct|recommended|suggested|right|expected)\s+value\b",
            r"\bto\s+what\s+(?:you|the\s+report|the\s+analysis)\s+(?:recommended|suggested|says|shows)\b",
            r"\b(?:use|apply|take)\s+(?:the\s+)?(?:recommendation|suggestion|recommended\s+value|suggested\s+value|report\s+value)\b",
            r"\bsame\s+as\s+(?:the\s+)?(?:recommendation|suggestion|report|analysis)\b",
        )
        return any(re.search(pattern, normalized, flags=re.I) for pattern in patterns)

    @staticmethod
    def is_suggested_change_request(text: str) -> bool:
        """Detect requests to apply the analysis recommendations.

        The detector intentionally accepts natural variants such as
        ``do the changes to this Profile ID`` and ``apply changes for the ID
        above``.  These requests must enter the governed write workflow and
        must never be downgraded to a normal analysis intent merely because an
        identifier is present in the same sentence.
        """
        if re.search(
            r"(?i)\b(?:do|apply|use|make|execute|perform|implement|complete)\s+"
            r"(?:all\s+)?(?:the\s+)?(?:suggested|recommended|proposed|required|these|those)?\s*(?:changes?|corrections?|fixes?|updates?)\b",
            text,
        ):
            return True

        # Specific attribute requests may intentionally omit the target source
        # because the active deterministic report already states where that
        # correction belongs. Examples: "update Country as you suggested",
        # "fix Country", "change Country to the correct value".
        field = SourceOperationService.extract_requested_attribute(text)
        if field and re.search(r"(?i)\b(update|change|set|correct|replace|modify|fix|use|apply)\b", text):
            if SourceOperationService.uses_deterministic_recommendation(text):
                return True
            # If no source is named and no literal value was supplied, treat the
            # write verb + known attribute as a request to use the active report's
            # exact target and deterministic value. A literal request such as
            # "change Country to JP" is handled separately as an explicit value
            # update; it must never be silently rewritten to the recommendation.
            if not SourceOperationService.detect_requested_target_sources(text, field) and SourceOperationService.extract_requested_value(text) is None:
                return True
        return False

    @staticmethod
    def is_apply_all_request(text: str) -> bool:
        lower = text.casefold()
        if re.search(r"(?i)\b(all|every|everything|whole|entire)\b", text) and re.search(r"(?i)\b(change|changes|correction|corrections|fix|fixes|update|updates)\b", text):
            return True
        return bool(re.search(r"(?i)\b(?:do|apply|make|execute|perform|implement|complete)\s+(?:the\s+)?(?:suggested|recommended|proposed|required)?\s*(?:changes|corrections|fixes|updates)\b", lower))

    @staticmethod
    def is_plan_only_request(text: str) -> bool:
        return bool(re.search(
            r"(?i)\b(show|preview|prepare|draft|propose|review)\b.*\b(plan|change|changes|update|updates)\b|"
            r"\bwhat\s+(?:would|will)\s+(?:you\s+)?change\b",
            text,
        ))

    @staticmethod
    def is_explicit_execution_request(text: str) -> bool:
        if SourceOperationService.is_plan_only_request(text):
            return False
        normalized = re.sub(r"[.!?]+$", "", text.casefold()).strip()
        if CHANGE_ID_RE.search(text) and re.search(r"(?i)\b(approve|confirm|apply|execute|do)\b", text):
            return True
        if normalized in {"do it", "apply it", "execute it", "make it", "yes do it", "yes apply it", "yes execute it"}:
            return True
        if re.search(r"(?i)\byes\b.*\b(do|apply|execute|make|perform)\b.*\b(change|changes|it)\b", text):
            return True
        if SourceOperationService.is_suggested_change_request(text):
            return True
        if re.search(r"(?i)\b(apply|execute|perform|implement|make|do)\b.*\b(change|changes|update|updates|correction|corrections|fix|fixes)\b", text):
            return True
        return bool(re.search(r"(?i)\b(update|set|correct|replace|modify|write|change|fix)\b", text))

    @staticmethod
    def extract_requested_field(text: str) -> str | None:
        normalized = re.sub(r"[_\-]+", " ", text.casefold())
        normalized = re.sub(r"\s+", " ", normalized)
        candidates: list[tuple[int, str, str]] = []
        for canonical, aliases in FIELD_ALIASES.items():
            names = {canonical.replace("_", " "), *aliases}
            for alias in names:
                alias_norm = re.sub(r"[_\-]+", " ", alias.casefold()).strip()
                if not alias_norm:
                    continue
                if re.search(rf"(?<![a-z0-9]){re.escape(alias_norm)}(?![a-z0-9])", normalized):
                    candidates.append((len(alias_norm), canonical, alias_norm))
        if not candidates:
            return None
        candidates.sort(reverse=True)
        return candidates[0][1]

    @staticmethod
    def extract_requested_attribute(text: str) -> str | None:
        """Return an attribute named for update, excluding identifier labels.

        Natural commands often say ``do the changes to Profile ID <guid>`` or
        ``apply the fixes for CrowdTwist ID <number>``.  In those sentences the
        label identifies the member; it is not the field being modified.
        A direct field-write form such as ``change Profile ID to ...`` or
        ``fix CrowdTwist ID`` still resolves to the attribute.
        """
        field = SourceOperationService.extract_requested_field(text)
        if field not in {"profile_id", "crowd_twist_id", "email"}:
            return field

        normalized = str(text or "").casefold()
        normalized = re.sub(r"\s+", " ", normalized)
        alias = {
            "profile_id": r"profile\s*id",
            "crowd_twist_id": r"crowd\s*twist\s*id|crowdtwist\s*id",
            "email": r"email(?:\s+address)?",
        }[field]
        direct_field_write = bool(re.search(
            rf"(?i)\b(?:update|change|set|correct|replace|modify|fix)\s+(?:the\s+)?(?:{alias})\b(?:\s+(?:in|on)\s+(?:rewards\s*db|rewardsdb|crowd\s*twist|crowdtwist))?(?:\s+(?:to|as)\b|\s*$)",
            normalized,
        ))
        if direct_field_write:
            return field

        identifier_after_label = False
        if field == "profile_id":
            identifier_after_label = bool(re.search(rf"(?i)\b(?:{alias})\s*[:=]?\s*[0-9a-f]{{8}}-[0-9a-f]{{4}}-[0-9a-f]{{4}}-[0-9a-f]{{4}}-[0-9a-f]{{12}}\b", normalized))
        elif field == "crowd_twist_id":
            identifier_after_label = bool(re.search(rf"(?i)\b(?:{alias})\s*[:=]?\s*\d{{6,20}}\b", normalized))
        elif field == "email":
            identifier_after_label = bool(EMAIL_RE.search(text))
        return None if identifier_after_label else field

    @staticmethod
    def extract_requested_value(text: str) -> str | None:
        # A member selector such as "do the changes to Profile ID <guid>" is
        # not a replacement value.  The identifier tells us *which member* to
        # analyze/update.
        member_selector_patterns = (
            r"(?i)\b(?:to|for|of|on)\s+profile\s*id\s*[:=]?\s*[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\s*$",
            r"(?i)\b(?:to|for|of|on)\s+(?:crowd\s*twist|crowdtwist)\s*id\s*[:=]?\s*\d{6,20}\s*$",
            r"(?i)\b(?:to|for|of|on)\s+email(?:\s+address)?\s+[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\s*$",
        )
        if any(re.search(pattern, text) for pattern in member_selector_patterns):
            return None

        # Recommendation language must never become a literal write value.
        # This is a second defensive gate in addition to intent routing.
        if SourceOperationService.uses_deterministic_recommendation(text):
            return None
        match = re.search(r"(?is)\b(?:to|as)\s+(.+?)(?:\s+(?:for|of|on)\s+(?:[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}|[0-9a-f]{8}-[0-9a-f\-]{27,}|\d{6,20}))?\s*$", text)
        if not match:
            return None
        value = str(match.group(1) or "").strip(" .\"'")
        if not value or re.search(r"(?i)\b(?:suggestion|suggested|recommendation|recommended|correct|right|expected)\b", value):
            return None
        # Avoid swallowing target-source phrases into the value.
        value = re.sub(r"(?i)\s+(?:in|on)\s+(?:crowd\s*twist|crowdtwist|rewards\s*db|rewardsdb)\s*$", "", value).strip()
        return value or None

    @staticmethod
    def is_write_request(text: str) -> bool:
        if SourceOperationService.is_suggested_change_request(text):
            return True
        if re.search(r"(?i)\b(update|set|correct|replace|modify|write)\b", text):
            return True
        return bool(re.search(r"(?i)\bchange\b", text) and re.search(r"(?i)\b(to|as)\b", text))


    @staticmethod
    def _normalized_identifier_value(search_type: SearchType, value: Any) -> str:
        text = str(value or "").strip()
        if search_type == SearchType.EMAIL:
            return text.casefold()
        if search_type == SearchType.PROFILE_ID:
            return text.upper()
        return text

    def active_report_matches_identifier(self, state: SessionState, identifier: IdentifierMatch) -> bool:
        """Return True only when the active report belongs to the requested member.

        This prevents a command such as ``do the changes to <new profile id>``
        from accidentally applying suggestions that belong to the previous
        report in the chat session.
        """
        report = state.last_report or {}
        if not report:
            return False

        report_type_raw = str(report.get("search_type") or "").strip()
        report_value = report.get("search_value")
        try:
            report_type = SearchType(report_type_raw)
        except ValueError:
            report_type = None
        if report_type is not None and report_value not in (None, ""):
            if report_type == identifier.search_type:
                if self._normalized_identifier_value(report_type, report_value) == self._normalized_identifier_value(identifier.search_type, identifier.value):
                    return True

        bundle = state.facts.get("last_identity_bundle") or {}
        key = {
            SearchType.EMAIL: "email",
            SearchType.PROFILE_ID: "profile_id",
            SearchType.CROWD_TWIST_ID: "crowd_twist_id",
        }[identifier.search_type]
        bundle_value = bundle.get(key) if isinstance(bundle, dict) else None
        return bundle_value not in (None, "") and (
            self._normalized_identifier_value(identifier.search_type, bundle_value)
            == self._normalized_identifier_value(identifier.search_type, identifier.value)
        )

    @staticmethod
    def _suggestion_source(value: Any) -> SourceSystem | None:
        normalized = re.sub(r"[^a-z]", "", str(value or "").casefold())
        if normalized in {"rewardsdb", "rewardsdatabase", "membersdb"}:
            return SourceSystem.REWARDS_DB
        if normalized in {"crowdtwist", "ct"}:
            return SourceSystem.CROWD_TWIST
        return None

    @staticmethod
    def _suggestion_evidence(report: dict[str, Any], item: dict[str, Any], source: SourceSystem) -> dict[str, Any]:
        """Return the exact deterministic evidence that produced one correction.

        The executable plan must remain traceable to the same AttributeVerdict
        that produced the suggestion.  This is deliberately deterministic and
        does not ask the LLM to reinterpret source values.
        """
        field = str(item.get("attribute") or item.get("field") or "").strip()
        verdict = next(
            (row for row in (report.get("attributes") or []) if isinstance(row, dict) and str(row.get("attribute") or "") == field),
            None,
        )
        if not isinstance(verdict, dict):
            # Compatibility for older/synthetic reports that predate serialized
            # AttributeVerdict rows: ground against the canonical source snapshots
            # instead of trusting the suggestion text alone. Production reports
            # normally take the richer verdict path below.
            records = report.get("records") or {}
            target_record = records.get(source.value) or {}
            target_canonical = target_record.get("canonical") or {}
            truth_source = str(item.get("truth_source") or SourceSystem.CPS.value)
            truth_record = records.get(truth_source) or {}
            truth_canonical = truth_record.get("canonical") or {}
            target_raw = target_canonical.get(field)
            truth_raw = truth_canonical.get(field)
            current_matches = _values_equal(item.get("current_value"), target_raw)
            recommended = item.get("recommended_value")
            truth_matches = truth_raw in (None, "") or _values_equal(recommended, truth_raw)
            return {
                "grounded": bool(current_matches and truth_matches),
                "grounding_mode": "canonical_source_snapshot",
                "reason": "attribute_verdict_missing_used_canonical_records",
                "attribute": field,
                "truth_source": truth_source,
                "truth_value": truth_raw,
                "target_source": source.value,
                "target_observation": {"raw_value": target_raw, "normalized_value": target_raw, "present": target_raw not in (None, "")},
                "truth_observation": {"raw_value": truth_raw, "normalized_value": truth_raw, "present": truth_raw not in (None, "")},
                "suggested_current_value": item.get("current_value"),
                "suggested_recommended_value": recommended,
            }

        observations = verdict.get("observations") or {}
        target_obs = observations.get(source.value) or {}
        truth_source = str(item.get("truth_source") or verdict.get("truth_source") or "").strip() or None
        truth_obs = (observations.get(truth_source) or {}) if truth_source else {}
        current = item.get("current_value")
        target_raw = target_obs.get("raw_value") if isinstance(target_obs, dict) else None

        # Suggestions are generated from this same deterministic verdict.  If a
        # later code change ever causes the suggestion's stated current value to
        # disagree with the verdict, block that suggestion from the executable
        # queue rather than silently planning against contradictory evidence.
        current_matches = _values_equal(current, target_raw)
        return {
            "grounded": bool(current_matches),
            "attribute": field,
            "attribute_status": verdict.get("status"),
            "truth_source": truth_source,
            "truth_value": verdict.get("truth_value"),
            "target_source": source.value,
            "target_observation": {
                "raw_value": target_raw,
                "normalized_value": target_obs.get("normalized_value") if isinstance(target_obs, dict) else None,
                "present": target_obs.get("present") if isinstance(target_obs, dict) else None,
            },
            "truth_observation": {
                "raw_value": truth_obs.get("raw_value") if isinstance(truth_obs, dict) else None,
                "normalized_value": truth_obs.get("normalized_value") if isinstance(truth_obs, dict) else None,
                "present": truth_obs.get("present") if isinstance(truth_obs, dict) else None,
            },
            "suggested_current_value": current,
            "suggested_recommended_value": item.get("recommended_value"),
            "verdict_explanation": verdict.get("explanation"),
        }

    async def invalidate_suggested_change_queue_after_live_write(self, session_id: str) -> None:
        """Invalidate pre-write suggestions after any verified live mutation.

        A successful source write changes the evidence graph.  Remaining queued
        suggestions from the old report are therefore unsafe until the member is
        re-analysed.
        """
        state = await self.sessions.get(session_id)
        state.facts.pop("pending_suggested_change_queue", None)
        state.facts.pop("suggested_change_context", None)

    async def plan_suggested_change_from_report(
        self,
        *,
        session_id: str,
        state: SessionState,
        requested_field: str | None = None,
        requested_source: SourceSystem | None = None,
        requested_value: Any | None = None,
        only_requested: bool = False,
    ) -> dict[str, Any]:
        """Build the next governed correction from the latest analysis.

        A fresh analysis is performed by ChatService whenever the change command
        includes an Email, Profile ID, or CrowdTwist ID. This method converts the
        deterministic recommendations into a stable, deduplicated queue targeting
        only Rewards DB and CrowdTwist. Truth/reference evidence is retained per suggestion using the deterministic business rules.
        """
        queue = list(state.facts.get("pending_suggested_change_queue") or [])
        context = dict(state.facts.get("suggested_change_context") or {})

        if not queue:
            report = state.last_report or {}
            suggestions = list(report.get("suggestions") or [])
            derived: list[dict[str, Any]] = []
            seen: set[str] = set()
            priority_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}

            for position, item in enumerate(suggestions):
                if not isinstance(item, dict):
                    continue
                source = self._suggestion_source(item.get("target_source"))
                if source not in AGENTIC_WRITABLE_SOURCES:
                    continue
                field = str(item.get("attribute") or item.get("field") or "").strip()
                recommended_value = item.get("recommended_value")
                if not field or recommended_value is None or item.get("requires_manual_review"):
                    continue
                if item.get("automation_eligible") is False:
                    continue
                dedupe_key = json.dumps(
                    {"source": source.value, "field": field, "value": recommended_value},
                    sort_keys=True,
                    default=str,
                )
                if dedupe_key in seen:
                    continue
                seen.add(dedupe_key)
                priority = str(item.get("priority") or "MEDIUM").upper()
                evidence = self._suggestion_evidence(report, item, source)
                if not evidence.get("grounded"):
                    continue
                derived.append({
                    "source": source.value,
                    "source_label": _source_label(source),
                    "field": field,
                    "new_value": recommended_value,
                    "current_value": item.get("current_value"),
                    "truth_source": item.get("truth_source") or evidence.get("truth_source"),
                    "reason": item.get("recommendation") or item.get("reason") or "Suggested by the completed analysis",
                    "priority": priority,
                    "report_position": position,
                    "evidence": evidence,
                })

            derived.sort(key=lambda item: (
                priority_rank.get(str(item.get("priority") or "MEDIUM").upper(), 9),
                0 if item.get("source") == SourceSystem.REWARDS_DB.value else 1,
                int(item.get("report_position") or 0),
            ))
            queue = derived

            if not queue:
                raise SourceOperationError(
                    "NO_AUTOMATABLE_SUGGESTED_CHANGES",
                    "The fresh analysis found no eligible Rewards DB or CrowdTwist correction that can be automated safely under the deterministic per-attribute truth rules. CPS remains read-only and is not modified by Agentic AI.",
                    409,
                )

            report_run_id = str(report.get("run_id") or state.active_run_id or "").strip() or None
            context = {
                "analysis_run_id": report_run_id,
                "analysis_search_type": report.get("search_type"),
                "analysis_search_value": report.get("search_value"),
                "truth_source": "per_suggestion",
                "truth_sources": sorted({str(item.get("truth_source")) for item in queue if item.get("truth_source")}),
                "writable_sources": [SourceSystem.REWARDS_DB.value, SourceSystem.CROWD_TWIST.value],
                "total_changes": len(queue),
                "derived_changes": deepcopy(queue),
                "analysis_summary": {
                    "mismatch_count": report.get("mismatch_count", 0),
                    "missing_count": report.get("missing_count", 0),
                    "invalid_format_count": report.get("invalid_format_count", 0),
                    "unverifiable_count": report.get("unverifiable_count", 0),
                    "coverage": report.get("analysis_completeness"),
                },
            }
            state.facts["suggested_change_context"] = context
            state.facts["pending_suggested_change_queue"] = queue
            await self.audit_agentic_activity(
                "CHANGE_SET_DERIVED",
                {
                    "session_id": session_id,
                    "run_id": report_run_id,
                    "actor": state.metadata.get("actor") or "Unknown user",
                    "actor_email": state.metadata.get("actor_email"),
                    "source": "Agentic AI",
                    "action": "Analyze and derive downstream corrections",
                    "status": "COMPLETED",
                    "target": str(report.get("search_value") or "active member"),
                    "verification": f"{len(queue)} eligible downstream correction(s) derived",
                    "details": {
                        "truth_source": "per_suggestion",
                        "truth_sources": context.get("truth_sources") or [],
                        "writable_sources": [SourceSystem.REWARDS_DB.value, SourceSystem.CROWD_TWIST.value],
                        "changes": deepcopy(queue),
                        "analysis_summary": context["analysis_summary"],
                    },
                },
            )

        # Select the exact correction requested by the user rather than blindly
        # taking the first priority-sorted suggestion. This is what makes
        # "update Country as suggested" update Country even when CrowdTwist ID
        # has a higher priority in the same report.
        if requested_field or requested_source is not None:
            matches = [
                item for item in queue
                if (not requested_field or str(item.get("field") or "") == requested_field)
                and (requested_source is None or str(item.get("source") or "") == requested_source.value)
            ]
            if not matches:
                label = requested_field or (requested_source.value if requested_source is not None else "requested correction")
                raise SourceOperationError(
                    "REQUESTED_SUGGESTION_NOT_FOUND",
                    f"The active verified analysis does not contain an automatable correction matching {label}. No source update was attempted.",
                    409,
                )
            selected = matches[0]
            queue.remove(selected)
            queue.insert(0, selected)

        bundle = state.facts.get("last_identity_bundle") or {}
        email = str(bundle.get("email") or "").strip()
        if not email:
            report_value = str((state.last_report or {}).get("search_value") or "").strip()
            if EMAIL_RE.fullmatch(report_value):
                email = report_value
        if not email:
            candidates = self.find_candidate_emails(state, "")
            email = candidates[0] if candidates else ""
        if not email:
            raise SourceOperationError(
                "SUGGESTED_CHANGE_IDENTITY_REQUIRED",
                "The analysis found corrections, but the verified write target could not be resolved to one member email. Run the analysis with an Email, Profile ID, or CrowdTwist ID.",
                409,
            )

        item = queue.pop(0)
        if requested_value not in (None, ""):
            requested_type = _write_data_type(SourceSystem(item["source"]), str(item.get("field") or ""))
            if not _values_equal(requested_value, item.get("new_value"), requested_type):
                raise SourceOperationError(
                    "REQUESTED_VALUE_CONFLICTS_WITH_TRUTH",
                    f"The requested value `{requested_value}` does not match the deterministic recommended value `{item.get('new_value')}` for {item.get('field')}. No source update was attempted.",
                    409,
                    details={
                        "requested_value": requested_value,
                        "recommended_value": item.get("new_value"),
                        "field": item.get("field"),
                        "source": item.get("source"),
                        "truth_source": item.get("truth_source"),
                    },
                )
        if only_requested:
            queue = []
        state.facts["pending_suggested_change_queue"] = queue
        total = int(context.get("total_changes") or (len(queue) + 1))
        index = max(1, total - len(queue))
        change = await self.plan_change(
            session_id=session_id,
            source=SourceSystem(item["source"]),
            operation=SourceOperation.UPDATE,
            emails=[email],
            field=str(item.get("field") or ""),
            new_value=item.get("new_value"),
            reason=str(item.get("reason") or "Suggested by the completed analysis"),
        )
        change.update({
            "suggested_change": True,
            "remaining_suggested_changes": len(queue),
            "change_set_total": total,
            "change_set_index": index,
            "analysis_run_id": context.get("analysis_run_id"),
            "analysis_summary": deepcopy(context.get("analysis_summary") or {}),
            "truth_source": item.get("truth_source"),
            "suggestion_evidence": deepcopy(item.get("evidence") or {}),
            "derived_target_source": item.get("source"),
            "derived_priority": item.get("priority"),
            "derived_from_analysis": True,
            "explicit_requested_field": requested_field,
            "explicit_requested_source": requested_source.value if requested_source is not None else None,
            "explicit_requested_value": requested_value,
            "only_requested": only_requested,
        })
        await self._audit("SUGGESTED_CHANGE_PLAN_READY", change)
        return change

    async def _prepare_next_suggested_change_after_execution(
        self,
        *,
        session_id: str,
        completed: dict[str, Any],
    ) -> dict[str, Any]:
        """Prepare the next analyzed correction after a successful terminal step.

        This helper is retained for preview/legacy approval flows. Explicit
        Agentic execution commands use ChatService's governed execution loop,
        which re-derives every post-write correction from fresh source evidence.
        """
        if not completed.get("suggested_change"):
            return completed
        if str(completed.get("status") or "") not in {"COMPLETED", "PARTIAL", "DRY_RUN_COMPLETED"}:
            return completed

        state = await self.sessions.get(session_id)
        remaining = list(state.facts.get("pending_suggested_change_queue") or [])
        if not remaining:
            state.facts.pop("suggested_change_context", None)
            completed["remaining_suggested_changes"] = 0
            return completed

        # A verified live write changes the evidence graph. Never prepare the
        # next correction from the pre-write queue. ChatService will invalidate
        # this queue, run a fresh cross-source analysis, and only then derive a
        # new next change. Dry-run execution may continue through the old queue
        # because no source value was mutated.
        live_write = any(item.get("success") and not item.get("dry_run") for item in (completed.get("results") or []))
        if live_write:
            completed.pop("next_change", None)
            completed["next_change_revalidation_required"] = True
            completed["remaining_suggested_changes"] = len(remaining)
            return completed

        try:
            next_change = await self.plan_suggested_change_from_report(session_id=session_id, state=state)
        except SourceOperationError as exc:
            completed["next_change_error"] = {"code": exc.code, "message": str(exc), "details": exc.details}
            await self.audit_agentic_activity(
                "NEXT_SUGGESTED_CHANGE_BLOCKED",
                {
                    "session_id": session_id,
                    "run_id": completed.get("analysis_run_id"),
                    "actor": completed.get("actor") or state.metadata.get("actor") or "Unknown user",
                    "actor_email": completed.get("actor_email") or state.metadata.get("actor_email"),
                    "source": "Agentic AI",
                    "action": "Prepare next analyzed correction",
                    "status": "BLOCKED",
                    "target": completed.get("change_id"),
                    "reason": str(exc),
                    "verification": exc.code,
                },
            )
            return completed

        completed["next_change"] = self.public_change(next_change)
        completed["remaining_suggested_changes"] = int(next_change.get("remaining_suggested_changes") or 0) + 1
        await self.audit_agentic_activity(
            "NEXT_SUGGESTED_CHANGE_PLANNED",
            {
                "session_id": session_id,
                "run_id": next_change.get("analysis_run_id"),
                "actor": next_change.get("actor") or state.metadata.get("actor") or "Unknown user",
                "actor_email": next_change.get("actor_email") or state.metadata.get("actor_email"),
                "source": "Agentic AI",
                "action": "Prepare next analyzed correction",
                "status": "AWAITING_APPROVAL",
                "target": next_change.get("change_id"),
                "verification": f"Correction {next_change.get('change_set_index')} of {next_change.get('change_set_total')} prepared",
                "details": {
                    "source": next_change.get("source"),
                    "field": next_change.get("field"),
                    "new_value": next_change.get("new_value"),
                },
            },
        )
        return completed

    @staticmethod
    def is_read_request(text: str) -> bool:
        if re.search(r"(?i)\b(run|fetch|get|show|check|lookup|search|read|find|retrieve|extract|pull|collect)\b", text):
            return True
        return bool(re.search(r"(?i)\b(cps|rewards\s*db|rewardsdb|crowd\s*twist|crowdtwist)\s+data\s+for\b", text))

    def parse_change_request(self, text: str, source: SourceSystem) -> dict[str, Any]:
        # Suggested/recommended-value commands belong to the active-report path,
        # never the literal writer.  Keep this guard even though handle_chat
        # normally routes them earlier.
        if self.uses_deterministic_recommendation(text):
            return {
                "error": "This command requests the active report recommendation, not a literal value.",
                "source": source.value,
                "use_recommendation": True,
            }
        explicit = _dedupe_emails(EMAIL_RE.findall(text))
        query = ""
        # Remove explicit emails before parsing the field/value phrase.
        working = EMAIL_RE.sub(" ", text)
        if explicit:
            working = re.sub(r"(?is)\s+(?:for|of|on)\s*$", "", working).strip()
        source_pattern = "|".join(re.escape(x) for x in SOURCE_ALIASES[source])

        patterns = [
            rf"(?is)\b(?P<verb>update|change|set|correct|replace|modify|create)\b\s+(?:the\s+)?(?P<field>[a-zA-Z_ ]+?)\s+(?:in|on)\s+(?:{source_pattern})\s+(?:to|as)\s+(?P<value>.+?)(?:\s+(?:for|of)\s+(?P<query>.+))?$",
            rf"(?is)\b(?P<verb>update|change|set|correct|replace|modify|create)\b\s+(?:{source_pattern})\s+(?P<field>[a-zA-Z_ ]+?)\s+(?:for|of)\s+(?P<query>.+?)\s+(?:to|as)\s+(?P<value>.+)$",
            rf"(?is)\b(?P<verb>update|change|set|correct|replace|modify|create)\b\s+(?:the\s+)?(?:{source_pattern})?\s*(?P<field>[a-zA-Z_ ]+?)\s+(?:to|as)\s+(?P<value>.+?)(?:\s+(?:for|of|on)\s+(?P<query>.+))?$",
        ]
        match = next((m for p in patterns if (m := re.search(p, working.strip()))), None)
        if match is None:
            return {"error": "Could not determine the field and new value.", "source": source.value}
        field_text = re.sub(r"\s+", " ", match.group("field")).strip(" .")
        canonical = self.resolve_field(field_text)
        if canonical is None:
            return {"error": f"Unsupported or unclear field: {field_text}", "source": source.value, "field_text": field_text}
        value = str(match.group("value") or "").strip(" .\"'")
        query = str(match.groupdict().get("query") or "").strip(" ?.,")
        # Strip harmless trailing source words from the value.
        value = re.sub(rf"(?is)\s+(?:in|on)\s+(?:{source_pattern})\s*$", "", value).strip()
        if not value:
            return {"error": "The new value is missing.", "source": source.value, "field": canonical}
        operation = "create" if match.group("verb").casefold() == "create" else "update"
        return {
            "source": source.value,
            "operation": operation,
            "field": canonical,
            "new_value": value,
            "query": query,
            "emails": explicit,
            "reason": "Requested through Agentic AI chat",
        }

    @staticmethod
    def resolve_field(text: str) -> str | None:
        normalized = re.sub(r"[_\-]+", " ", text.casefold())
        normalized = re.sub(r"\s+", " ", normalized).strip()
        for canonical, aliases in FIELD_ALIASES.items():
            if normalized == canonical.replace("_", " ") or normalized in aliases:
                return canonical
        # Avoid fuzzy guesses for a write operation; exact aliases are safer.
        return None

    @staticmethod
    def extract_query_term(text: str, source: SourceSystem) -> str:
        cleaned = EMAIL_RE.sub(" ", text)
        source_words = sorted(SOURCE_ALIASES[source], key=len, reverse=True)
        for word in source_words:
            cleaned = re.sub(re.escape(word), " ", cleaned, flags=re.I)
        cleaned = re.sub(r"(?i)\b(can you|please|could you|run|fetch|get|show|check|lookup|search|read|find|retrieve|extract|pull|collect|the|data|api|for|of|from|in|and|plus|with)\b", " ", cleaned)
        return re.sub(r"\s+", " ", cleaned).strip(" ?.,")

    @staticmethod
    def extract_query_term_multi(text: str, sources: list[SourceSystem]) -> str:
        cleaned = EMAIL_RE.sub(" ", text)
        for source in sources:
            for word in sorted(SOURCE_ALIASES[source], key=len, reverse=True):
                pattern = r"(?i)(?:^|\b)ct(?:\b|$)" if word == "ct" else re.escape(word)
                cleaned = re.sub(pattern, " ", cleaned, flags=0 if word == "ct" else re.I)
        cleaned = re.sub(
            r"(?i)\b(can you|please|could you|run|fetch|get|show|check|lookup|search|read|find|retrieve|extract|pull|collect|the|data|api|for|of|from|in|and|plus|with|together|combined)\b",
            " ",
            cleaned,
        )
        return re.sub(r"\s+", " ", cleaned).strip(" ?.,")

    @staticmethod
    def find_candidate_emails(state: SessionState, query: str) -> list[str]:
        candidates: list[str] = []
        for member in (state.last_batch_summary or {}).get("members") or []:
            if isinstance(member, dict):
                email = str(member.get("email") or member.get("search_value") or "").strip()
                if "@" in email:
                    candidates.append(email)
        report_email = str((state.last_report or {}).get("search_value") or "").strip()
        if "@" in report_email:
            candidates.append(report_email)
        for message in state.messages:
            candidates.extend(EMAIL_RE.findall(message.content))
        candidates = _dedupe_emails(candidates)
        folded = query.casefold().strip()
        if not folded:
            return candidates
        return [email for email in candidates if folded in email.casefold()]

    @staticmethod
    def _select_allowed(selected: list[str], candidates: list[str]) -> list[str]:
        allowed = {x.casefold(): x for x in candidates}
        return _dedupe_emails([allowed[e.casefold()] for e in selected if e.casefold() in allowed])

    # ---------------------------------- Reads ----------------------------------
    async def query(self, source: SourceSystem, emails: list[str], max_parallel: int = SOURCE_PARALLEL_WORKERS) -> dict[str, Any]:
        """Backward-compatible one-source query wrapper."""
        combined = await self.query_sources([source], emails, max_parallel)
        result = dict(combined["source_results"][source.value])
        result["combined_query"] = combined
        return result

    async def query_sources(self, sources: list[SourceSystem], emails: list[str], max_parallel: int = SOURCE_PARALLEL_WORKERS) -> dict[str, Any]:
        sources = list(dict.fromkeys(SourceSystem(source) for source in sources))
        emails = _dedupe_emails(emails)
        if not sources:
            raise SourceOperationError("SOURCE_REQUIRED", "At least one source is required.")
        if not emails:
            raise SourceOperationError("SOURCE_EMAIL_REQUIRED", "At least one exact email is required.")

        max_parallel = SOURCE_PARALLEL_WORKERS
        semaphore = asyncio.Semaphore(SOURCE_PARALLEL_WORKERS)
        started = perf_counter()

        async def one(email: str) -> dict[str, Any]:
            async with semaphore:
                return await self._read_sources_for_email(sources, email)

        members = await asyncio.gather(*(one(email) for email in emails))
        source_results: dict[str, dict[str, Any]] = {}
        for source in sources:
            rows = [member["results"][source.value] for member in members]
            found = sum(1 for item in rows if item.get("data_found"))
            connected_no_data = sum(1 for item in rows if item.get("connected") and not item.get("data_found"))
            failed = len(rows) - found - connected_no_data
            source_results[source.value] = {
                "source": source.value,
                "source_label": _source_label(source),
                "operation": self.read_operation_id(source),
                "requested_count": len(rows),
                "found_count": found,
                "no_value_found_count": connected_no_data,
                "failed_count": failed,
                "results": rows,
                "read_only": True,
            }

        duration_ms = int((perf_counter() - started) * 1000)
        for summary in source_results.values():
            summary["duration_ms"] = duration_ms

        rewards_selected = SourceSystem.REWARDS_DB in sources
        result = {
            "sources": [source.value for source in sources],
            "source_labels": [_source_label(source) for source in sources],
            "operation": "multi_source_query" if len(sources) > 1 else self.read_operation_id(sources[0]),
            "requested_member_count": len(members),
            "requested_source_count": len(sources),
            "duration_ms": duration_ms,
            "read_only": True,
            "members": members,
            "source_results": source_results,
            "rewards_db_dependency_resolution": {
                "required": rewards_selected,
                "strategy": "Resolve Profile ID from CPS first and CrowdTwist ID from CrowdTwist, then search Rewards DB by ProfileId and fall back to CrowdTwistID.",
                "lookup_order": ["ProfileId", "CrowdTwistID"] if rewards_selected else [],
            },
            "crowd_twist_dependency_resolution": {
                "required": SourceSystem.CROWD_TWIST in sources,
                "strategy": "Search CrowdTwist by Email first; when no user is found, use CPS ProfileId; when that also returns no user, use the CrowdTwistID obtained from a Rewards DB row resolved by ProfileId.",
                "lookup_order": ["Email", "ProfileId", "CrowdTwistID"] if SourceSystem.CROWD_TWIST in sources else [],
                "rewards_db_email_lookup_allowed": False,
            },
        }
        return result

    async def query_identifiers(
        self,
        sources: list[SourceSystem],
        identifiers: list[IdentifierMatch],
        max_parallel: int = SOURCE_PARALLEL_WORKERS,
    ) -> dict[str, Any]:
        """Read selected sources from Email, Profile ID, or CrowdTwist ID.

        Every identifier is processed through the same linked collection path as
        the full disparity analysis. This means a CrowdTwist ID first retrieves
        CrowdTwist, extracts Profile ID/email, checks Rewards DB with the direct
        CrowdTwist ID before its Profile ID fallback, and then retrieves CPS with
        the best resolved identifier.
        """
        sources = list(dict.fromkeys(SourceSystem(source) for source in sources))
        if not sources:
            raise SourceOperationError("SOURCE_REQUIRED", "At least one source is required.")
        unique: list[IdentifierMatch] = []
        seen: set[tuple[str, str]] = set()
        for identifier in identifiers:
            key = (identifier.search_type.value, identifier.value.casefold())
            if identifier.value and key not in seen:
                seen.add(key)
                unique.append(identifier)
        if not unique:
            raise SourceOperationError(
                "SOURCE_IDENTIFIER_REQUIRED",
                "Provide an email, Profile ID, or CrowdTwist ID.",
            )

        max_parallel = SOURCE_PARALLEL_WORKERS
        semaphore = asyncio.Semaphore(SOURCE_PARALLEL_WORKERS)
        started = perf_counter()

        async def one(identifier: IdentifierMatch) -> dict[str, Any]:
            async with semaphore:
                records = await DisparityPipeline(self.settings).collect_source_records(
                    identifier.search_type, identifier.value
                )
            identity = self._identity_bundle_from_records(records)
            results: dict[str, dict[str, Any]] = {}
            for source in sources:
                source_name = SourceName(source.value)
                record = records[source_name]
                dumped = record.model_dump(mode="json")
                status = dumped.get("status") or {}
                result = self._read_result(
                    source,
                    str(identity.get("email") or f"{identifier.label}: {identifier.value}"),
                    dumped,
                    dict(record.canonical or {}),
                    status,
                    identity=identity,
                )
                result["query_identifier"] = identifier.as_dict()
                result["identifier_resolution"] = {
                    "input": identifier.as_dict(),
                    "resolved_identity": identity,
                    "lookup_order": (status.get("diagnostics") or {}).get("lookup_order"),
                    "attempts": (status.get("diagnostics") or {}).get("lookup_attempts")
                        or (status.get("diagnostics") or {}).get("identifier_lookup_sequence")
                        or [],
                    "lookup_result": (status.get("diagnostics") or {}).get("lookup_result")
                        or status.get("retrieval_method"),
                }
                results[source.value] = result
            return {
                "identifier": identifier.as_dict(),
                "email": identity.get("email") or f"{identifier.label}: {identifier.value}",
                "resolved_identity": identity,
                "results": results,
            }

        members = await asyncio.gather(*(one(identifier) for identifier in unique))
        duration_ms = int((perf_counter() - started) * 1000)
        source_results: dict[str, dict[str, Any]] = {}
        for source in sources:
            rows = [member["results"][source.value] for member in members]
            found = sum(1 for item in rows if item.get("data_found"))
            connected_no_data = sum(1 for item in rows if item.get("connected") and not item.get("data_found"))
            source_results[source.value] = {
                "source": source.value,
                "source_label": _source_label(source),
                "operation": self.read_operation_id(source),
                "requested_count": len(rows),
                "found_count": found,
                "no_value_found_count": connected_no_data,
                "failed_count": len(rows) - found - connected_no_data,
                "results": rows,
                "duration_ms": duration_ms,
                "read_only": True,
            }

        return {
            "sources": [source.value for source in sources],
            "source_labels": [_source_label(source) for source in sources],
            "operation": "identifier_source_query",
            "requested_member_count": len(members),
            "requested_identifier_count": len(unique),
            "duration_ms": duration_ms,
            "read_only": True,
            "members": members,
            "source_results": source_results,
            "identifier_resolution": {
                "accepted_inputs": ["Email", "Profile ID", "CrowdTwist ID"],
                "crowd_twist_id_origin": [
                    "CrowdTwistID", "extract ProfileId/email", "Rewards DB", "CPS"
                ],
                "email_origin": [
                    "Email", "CPS ProfileId", "CrowdTwist", "Rewards DB ProfileId/CrowdTwistID"
                ],
                "profile_id_origin": [
                    "ProfileId", "CPS/CrowdTwist", "Rewards DB", "resolved Email/CrowdTwistID"
                ],
            },
            "rewards_db_dependency_resolution": {
                "required": SourceSystem.REWARDS_DB in sources,
                "strategy": "Email/Profile requests use ProfileId then CrowdTwistID. CrowdTwist-ID requests use the supplied CrowdTwistID then the ProfileId extracted from CrowdTwist.",
            },
            "crowd_twist_dependency_resolution": {
                "required": SourceSystem.CROWD_TWIST in sources,
                "strategy": "Use the supplied identifier directly, then continue with identifiers resolved from linked sources only when needed.",
            },
        }

    @staticmethod
    def _identity_bundle_from_records(records: dict[SourceName, Any]) -> dict[str, Any]:
        canonical = {source: dict((records.get(source).canonical if records.get(source) else {}) or {}) for source in SourceName}

        def first(field: str, order: list[SourceName]) -> Any:
            for source in order:
                value = canonical[source].get(field)
                if value not in (None, ""):
                    return value
            return None

        return {
            "email": first("email", [SourceName.CPS, SourceName.REWARDS_DB, SourceName.CROWD_TWIST]),
            "profile_id": first("profile_id", [SourceName.CPS, SourceName.REWARDS_DB, SourceName.CROWD_TWIST]),
            "crowd_twist_id": first("crowd_twist_id", [SourceName.CROWD_TWIST, SourceName.REWARDS_DB]),
        }

    async def resolve_email_for_identifier(self, identifier: IdentifierMatch) -> tuple[str | None, dict[str, Any]]:
        result = await self.query_identifiers(
            [SourceSystem.CPS, SourceSystem.REWARDS_DB, SourceSystem.CROWD_TWIST],
            [identifier],
            max_parallel=1,
        )
        member = (result.get("members") or [{}])[0]
        identity = member.get("resolved_identity") or {}
        return (str(identity.get("email")) if identity.get("email") else None), result

    async def _read_sources_for_email(self, sources: list[SourceSystem], email: str) -> dict[str, Any]:
        # CPS is an identity dependency for both Rewards DB and the CrowdTwist
        # fallback sequence. CrowdTwist is also an identity dependency for the
        # approved Rewards DB ProfileId -> CrowdTwistID lookup order.
        need_cps = any(source in sources for source in (SourceSystem.CPS, SourceSystem.REWARDS_DB, SourceSystem.CROWD_TWIST))
        need_ct = any(source in sources for source in (SourceSystem.CROWD_TWIST, SourceSystem.REWARDS_DB))

        cps_record = None
        ct_record = None
        tasks: list[Any] = []
        task_names: list[str] = []
        if need_cps:
            tasks.append(CPSConnector(self.settings).fetch(SearchType.EMAIL, email))
            task_names.append("cps")
        if need_ct:
            tasks.append(CrowdTwistConnector(self.settings).fetch(SearchType.EMAIL, email))
            task_names.append("crowd_twist")
        if tasks:
            values = await asyncio.gather(*tasks)
            for name, value in zip(task_names, values):
                if name == "cps":
                    cps_record = value
                else:
                    ct_record = value

        results: dict[str, dict[str, Any]] = {}
        dependency_reads: dict[str, Any] = {}
        cps_canonical: dict[str, Any] = {}
        ct_canonical: dict[str, Any] = {}
        rewards_record = None
        rewards_result: dict[str, Any] | None = None

        if cps_record is not None:
            dumped = cps_record.model_dump(mode="json")
            cps_canonical = canonicalize(cps_record.raw, SourceName.CPS, self.field_map)
            cps_result = self._read_result(
                SourceSystem.CPS,
                email,
                dumped,
                cps_canonical,
                dumped.get("status") or {},
                identity={"email": email, "profile_id": cps_canonical.get("profile_id")},
            )
            dependency_reads[SourceSystem.CPS.value] = self._compact_read(cps_result)
            if SourceSystem.CPS in sources:
                results[SourceSystem.CPS.value] = cps_result

        profile_id = cps_canonical.get("profile_id")
        crowd_connector = CrowdTwistConnector(self.settings) if need_ct else None

        # CrowdTwist sequence, stage 1 and 2:
        # Email -> CPS ProfileId. The database-derived CrowdTwistID is appended
        # only after the Rewards DB dependency read below.
        if ct_record is not None and crowd_connector is not None:
            ct_record = await resolve_crowd_twist_user(
                crowd_connector,
                email=email,
                profile_id=str(profile_id) if profile_id else None,
                initial_record=ct_record,
            )
            ct_canonical = canonicalize(ct_record.raw, SourceName.CROWD_TWIST, self.field_map)

        crowd_twist_id = ct_canonical.get("crowd_twist_id")
        need_rewards_output = SourceSystem.REWARDS_DB in sources
        need_rewards_for_ct_fallback = SourceSystem.CROWD_TWIST in sources and ct_record is not None and not ct_record.status.data_found

        if need_rewards_output or need_rewards_for_ct_fallback:
            rewards_record = await RewardsDBConnector(self.settings).fetch(
                SearchType.EMAIL,
                email,
                resolved_profile_id=str(profile_id or ct_canonical.get("profile_id")) if (profile_id or ct_canonical.get("profile_id")) else None,
                resolved_crowd_twist_id=int(crowd_twist_id) if crowd_twist_id is not None else None,
            )
            dumped = rewards_record.model_dump(mode="json")
            rewards_canonical = canonicalize(rewards_record.raw, SourceName.REWARDS_DB, self.field_map)
            member_id = _ci_get(rewards_record.raw, "Id", "id", "MemberId", "memberId")
            rewards_result = self._read_result(
                SourceSystem.REWARDS_DB,
                email,
                dumped,
                rewards_canonical,
                dumped.get("status") or {},
                identity={
                    "email": email,
                    "member_id": str(member_id) if member_id is not None else None,
                    "profile_id": rewards_canonical.get("profile_id") or profile_id or ct_canonical.get("profile_id"),
                    "crowd_twist_id": rewards_canonical.get("crowd_twist_id") or crowd_twist_id,
                },
            )
            dependency_reads[SourceSystem.REWARDS_DB.value] = self._compact_read(rewards_result)

            # CrowdTwist sequence, final stage: use the CrowdTwistID stored in
            # Rewards DB only when Email and ProfileId did not find a CT user.
            db_crowd_twist_id = rewards_canonical.get("crowd_twist_id")
            if (
                SourceSystem.CROWD_TWIST in sources
                and ct_record is not None
                and not ct_record.status.data_found
                and db_crowd_twist_id not in (None, "")
                and crowd_connector is not None
            ):
                ct_record = await resolve_crowd_twist_user(
                    crowd_connector,
                    email=email,
                    profile_id=str(profile_id) if profile_id else None,
                    crowd_twist_id=db_crowd_twist_id,
                    initial_record=ct_record,
                )
                ct_canonical = canonicalize(ct_record.raw, SourceName.CROWD_TWIST, self.field_map)
                crowd_twist_id = ct_canonical.get("crowd_twist_id") or db_crowd_twist_id

        if ct_record is not None:
            dumped = ct_record.model_dump(mode="json")
            ct_result = self._read_result(
                SourceSystem.CROWD_TWIST,
                email,
                dumped,
                ct_canonical,
                dumped.get("status") or {},
                identity={
                    "email": email,
                    "crowd_twist_id": ct_canonical.get("crowd_twist_id") or crowd_twist_id,
                    "profile_id": ct_canonical.get("profile_id") or profile_id,
                },
            )
            ct_result["identifier_resolution"] = {
                "lookup_order": ["Email", "ProfileId", "CrowdTwistID"],
                "profile_id_from_cps": profile_id,
                "crowd_twist_id_from_rewards_db": (
                    ((rewards_result or {}).get("canonical") or {}).get("crowd_twist_id")
                    if rewards_result is not None
                    else None
                ),
                "attempts": ((dumped.get("status") or {}).get("diagnostics") or {}).get("identifier_lookup_sequence") or [],
                "dependency_reads": dependency_reads,
            }
            dependency_reads[SourceSystem.CROWD_TWIST.value] = self._compact_read(ct_result)
            if SourceSystem.CROWD_TWIST in sources:
                results[SourceSystem.CROWD_TWIST.value] = ct_result

        if rewards_result is not None and SourceSystem.REWARDS_DB in sources:
            rewards_result["identifier_resolution"] = {
                "profile_id": (rewards_result.get("canonical") or {}).get("profile_id") or profile_id or ct_canonical.get("profile_id"),
                "crowd_twist_id": (rewards_result.get("canonical") or {}).get("crowd_twist_id") or crowd_twist_id,
                "lookup_order": ["ProfileId", "CrowdTwistID"],
                "dependency_reads": dependency_reads,
            }
            results[SourceSystem.REWARDS_DB.value] = rewards_result

        return {
            "email": email,
            "results": results,
            "dependency_reads": dependency_reads,
            "crowd_twist_identifier_resolution": (
                (results.get(SourceSystem.CROWD_TWIST.value) or {}).get("identifier_resolution")
                if SourceSystem.CROWD_TWIST in sources
                else None
            ),
        }

    async def _read_target(self, source: SourceSystem, email: str) -> dict[str, Any]:
        # Use the same production resolution chain for controlled update
        # precondition reads so preview and execution target the same record.
        member = await self._read_sources_for_email([source], email)
        result = (member.get("results") or {}).get(source.value)
        if result is None:
            raise SourceOperationError(
                "SOURCE_READ_FAILED",
                f"{_source_label(source)} did not return a readable target result for {email}.",
                status_code=502,
            )
        return result

    @staticmethod
    def _read_result(source: SourceSystem, email: str, dumped: dict[str, Any], canonical: dict[str, Any], status: dict[str, Any], identity: dict[str, Any]) -> dict[str, Any]:
        return {
            "source": source.value,
            "email": email,
            "connected": bool(status.get("connected")),
            "data_found": bool(status.get("data_found")),
            "http_status": status.get("http_status"),
            "latency_ms": status.get("latency_ms"),
            "retrieval_method": status.get("retrieval_method"),
            "stage": status.get("stage"),
            "error": status.get("error"),
            "error_code": status.get("error_code"),
            "identity": identity,
            "canonical": canonical,
            "record": dumped,
        }

    @staticmethod
    def read_operation_id(source: SourceSystem) -> str:
        return {
            SourceSystem.CPS: "direct.cps.get_account",
            SourceSystem.REWARDS_DB: "direct.rewards_db.lookup_member",
            SourceSystem.CROWD_TWIST: "direct.crowdtwist.search_user",
        }[source]

    def format_query_reply(self, result: dict[str, Any]) -> str:
        # Accept both the new combined shape and the legacy single-source shape.
        if "source_results" not in result:
            combined = result.get("combined_query")
            if combined:
                result = combined
            else:
                label = result.get("source_label") or result.get("source") or "Source"
                lines = [
                    f"## {label} API result",
                    f"- **Requested:** {result.get('requested_count', 0)}",
                    f"- **Data found:** {result.get('found_count', 0)}",
                    f"- **No value found:** {result.get('no_value_found_count', 0)}",
                    f"- **Failed/unavailable:** {result.get('failed_count', 0)}",
                    f"- **Total time:** {result.get('duration_ms', 0)} ms",
                    "",
                ]
                for item in result.get("results") or []:
                    status = "DATA FOUND" if item.get("data_found") else ("NO VALUE FOUND" if item.get("connected") else "FAILED")
                    lines.append(f"- `{item.get('email')}` — **{status}**")
                lines.extend(["", "This operation was read-only; no source data was changed."])
                return "\n".join(lines)

        labels = result.get("source_labels") or result.get("sources") or []
        lines = [
            "## Combined source API result" if len(labels) > 1 else f"## {labels[0] if labels else 'Source'} API result",
            f"- **Members requested:** {result.get('requested_member_count', 0)}",
            f"- **Sources:** {', '.join(map(str, labels))}",
            f"- **Total time:** {result.get('duration_ms', 0)} ms",
            "",
            "### Source summary",
        ]
        for source in result.get("sources") or []:
            item = (result.get("source_results") or {}).get(source) or {}
            lines.append(
                f"- **{item.get('source_label') or source}:** {item.get('found_count', 0)} found · "
                f"{item.get('no_value_found_count', 0)} no value · {item.get('failed_count', 0)} failed"
            )

        identifiers = [member.get("identifier") or {} for member in (result.get("members") or [])]
        input_types = {str(item.get("search_type") or "") for item in identifiers}
        if SourceSystem.REWARDS_DB.value in (result.get("sources") or []):
            if SearchType.CROWD_TWIST_ID.value in input_types:
                rewards_note = (
                    "For a CrowdTwist ID input, the agent checks Rewards DB by the supplied **CrowdTwistID first**, "
                    "then falls back to the **ProfileId extracted from CrowdTwist** when required."
                )
            else:
                rewards_note = (
                    "For Email or Profile ID input, the agent resolves **ProfileId first** and falls back to "
                    "the linked **CrowdTwistID**. Rewards DB is never queried by email alone."
                )
            lines.extend(["", "### Rewards DB identifier resolution", rewards_note])

        if SourceSystem.CROWD_TWIST.value in (result.get("sources") or []):
            if SearchType.CROWD_TWIST_ID.value in input_types:
                crowd_note = (
                    "The supplied **CrowdTwistID** is queried directly. Its CrowdTwist record can provide the "
                    "Profile ID and email used to continue into Rewards DB and CPS."
                )
            elif SearchType.PROFILE_ID.value in input_types:
                crowd_note = (
                    "The supplied **Profile ID** is used directly. Resolved email and CrowdTwist ID values are "
                    "used only as linked fallbacks when needed."
                )
            else:
                crowd_note = (
                    "For Email input, CrowdTwist follows **Email → CPS ProfileId → Rewards DB CrowdTwistID**, "
                    "advancing only when the earlier lookup reaches the source but finds no user."
                )
            lines.extend(["", "### CrowdTwist identifier resolution", crowd_note])

        lines.extend(["", "### Member results"])
        for member in (result.get("members") or [])[:50]:
            identity = member.get("resolved_identity") or {}
            identifier = member.get("identifier") or {}
            display = identity.get("email") or member.get("email") or f"{identifier.get('label') or 'Identifier'}: {identifier.get('value') or 'unknown'}"
            lines.append(f"- **{display}**")
            resolved_parts = []
            if identity.get("profile_id"):
                resolved_parts.append(f"Profile ID `{identity['profile_id']}`")
            if identity.get("crowd_twist_id") not in (None, ""):
                resolved_parts.append(f"CrowdTwist ID `{identity['crowd_twist_id']}`")
            if resolved_parts:
                lines.append(f"  - Resolved identity: {' · '.join(resolved_parts)}")
            for source in result.get("sources") or []:
                item = (member.get("results") or {}).get(source) or {}
                status = "DATA FOUND" if item.get("data_found") else ("NO VALUE FOUND" if item.get("connected") else "FAILED")
                source_label = ((result.get("source_results") or {}).get(source) or {}).get("source_label") or source
                detail = f"HTTP {item.get('http_status')}" if item.get("http_status") is not None else (item.get("retrieval_method") or "no HTTP status")
                lines.append(f"  - {source_label}: **{status}** ({detail}, {item.get('latency_ms') or 0} ms)")
        if len(result.get("members") or []) > 50:
            lines.append(f"- …and {len(result['members']) - 50} more member(s) in the structured result.")
        lines.extend(["", "This operation was read-only; no source data was changed."])
        return "\n".join(lines)

    async def import_spreadsheet_changes(
        self,
        *,
        session_id: str,
        file_name: str,
        instruction: str,
        rows: list[dict[str, Any]],
        actor: str | None = None,
        actor_email: str | None = None,
        actor_role: str | None = None,
        actor_dry_run_enabled: bool | None = None,
    ) -> dict[str, Any]:
        """Validate or execute literal source changes imported from an Excel workbook.

        Spreadsheet rows are orchestration input only. The actual mutation still
        travels through ``plan_change`` -> governed execution -> the shared .NET
        manual-tab writer, so Excel imports cannot bypass role policy, per-user Dry
        Run, field allow-lists, pre-write reads, drift checks, verification, or audit.
        """
        state = await self.sessions.get(session_id)
        normalized_role = _normalize_actor_role(actor_role or state.metadata.get("actor_role"))
        self.require_agentic_write_role(normalized_role)
        await self.apply_session_write_policy(
            session_id,
            actor_role=normalized_role,
            actor_dry_run_enabled=actor_dry_run_enabled,
        )
        if actor:
            state.metadata["actor"] = str(actor).strip()
        if actor_email:
            state.metadata["actor_email"] = str(actor_email).strip()

        execute_requested = self.is_explicit_execution_request(instruction) and not self.is_plan_only_request(instruction)
        row_results: list[dict[str, Any]] = []
        pending_ids: list[str] = []
        completed_changes: list[dict[str, Any]] = []

        for item in rows:
            row_number = int(item.get("row_number") or 0)
            try:
                source = SourceSystem(str(item.get("source") or SourceSystem.CROWD_TWIST.value))
                identifier_type = SearchType(str(item.get("identifier_type") or ""))
                identifier_value = str(item.get("identifier_value") or "").strip()
                field = str(item.get("field") or "").strip()
                new_value = item.get("new_value")
                if not identifier_value or not field:
                    raise SourceOperationError("INVALID_SPREADSHEET_ROW", "Identifier and PropertyName/Field are required.")

                identifier = IdentifierMatch(identifier_type, identifier_value, row_number, "excel_update_workbook")
                lookup = await self.query_identifiers([source], [identifier])
                member = (lookup.get("members") or [{}])[0]
                identity = dict(member.get("resolved_identity") or {})
                email = str(identity.get("email") or "").strip()
                if not email and identifier_type == SearchType.EMAIL:
                    email = identifier_value
                if not email:
                    raise SourceOperationError(
                        "SPREADSHEET_MEMBER_EMAIL_NOT_RESOLVED",
                        f"Row {row_number}: the supplied {identifier.label} resolved the source record but no member email was available for governed pre/post-read verification.",
                        details={"identifier": identifier.as_dict(), "resolved_identity": sanitize(identity)},
                    )

                change = await self.plan_change(
                    session_id=session_id,
                    source=source,
                    operation=SourceOperation.UPDATE,
                    emails=[email],
                    field=field,
                    new_value=new_value,
                    reason=f"Excel workbook {file_name}, row {row_number}: explicit PropertyValue supplied by the user",
                    actor=actor,
                    actor_email=actor_email,
                )
                change.update({
                    "spreadsheet_import": True,
                    "spreadsheet_file_name": file_name,
                    "spreadsheet_row_number": row_number,
                    "literal_value_request": True,
                    "manual_override": False,
                    "spreadsheet_literal_value": True,
                    "requested_identifier": identifier.as_dict(),
                    "original_property_name": item.get("original_property_name") or field,
                })
                # Recompute the digest after adding only metadata that is not part
                # of the immutable source/field/value/target plan. The executable
                # digest itself remains the one produced by plan_change.
                change_id = str(change.get("change_id") or "")
                pending_ids.append(change_id)

                if execute_requested:
                    completed = await self.execute_explicit_chat_command(
                        session_id,
                        change_id,
                        command_text="apply spreadsheet changes",
                        actor=actor,
                        actor_email=actor_email,
                        actor_role=normalized_role,
                    )
                    completed_changes.append(completed)
                    public = self.public_change(completed)
                    status_value = str(completed.get("status") or "UNKNOWN")
                else:
                    public = self.public_change(change)
                    status_value = "VALIDATED_PREVIEW"

                target = (change.get("targets") or [{}])[0]
                row_results.append({
                    "row_number": row_number,
                    "source": source.value,
                    "source_label": _source_label(source),
                    "identifier_type": identifier_type.value,
                    "identifier_value": identifier_value,
                    "resolved_email": email,
                    "field": change.get("field"),
                    "wire_field": change.get("wire_field"),
                    "before": target.get("before"),
                    "requested_value": change.get("new_value"),
                    "status": status_value,
                    "change_id": change_id,
                    "change": public,
                })
            except (ValueError, SourceOperationError) as exc:
                code = exc.code if isinstance(exc, SourceOperationError) else "INVALID_SPREADSHEET_ROW"
                details = exc.details if isinstance(exc, SourceOperationError) else {}
                row_results.append({
                    "row_number": row_number,
                    "source": item.get("source"),
                    "identifier_type": item.get("identifier_type"),
                    "identifier_value": item.get("identifier_value"),
                    "field": item.get("field"),
                    "requested_value": item.get("new_value"),
                    "status": "FAILED_VALIDATION",
                    "code": code,
                    "message": str(exc),
                    "details": sanitize(details),
                })

        successful = [row for row in row_results if row.get("change_id")]
        failed = [row for row in row_results if not row.get("change_id")]
        pending_ids = [
            str(row.get("change_id") or "").upper()
            for row in successful
            if str((row.get("change") or {}).get("status") or "").upper() in {"AWAITING_CONFIRMATION_1", "AWAITING_CONFIRMATION_2"}
        ]
        if pending_ids:
            state.facts["pending_spreadsheet_change_ids"] = pending_ids
            state.facts["pending_spreadsheet_file_name"] = file_name
        else:
            state.facts.pop("pending_spreadsheet_change_ids", None)

        terminal_changes = [
            change for change in completed_changes
            if str(change.get("status") or "").upper() not in {"AWAITING_CONFIRMATION_1", "AWAITING_CONFIRMATION_2", "EXECUTING"}
        ]
        awaiting_final = [
            row for row in successful
            if str((row.get("change") or {}).get("status") or "").upper() == "AWAITING_CONFIRMATION_2"
        ]
        awaiting_chat = [
            row for row in successful
            if str((row.get("change") or {}).get("status") or "").upper() == "AWAITING_CONFIRMATION_1"
        ]
        requires_final_approval = bool(awaiting_final)
        execution_completed = bool(execute_requested and successful and not pending_ids)
        state.facts["last_spreadsheet_update_import"] = {
            "file_name": file_name,
            "row_count": len(rows),
            "validated_count": len(successful),
            "failed_count": len(failed),
            "execution_requested": execute_requested,
            "execution_completed": execution_completed,
            "requires_final_approval": requires_final_approval,
            "pending_count": len(pending_ids),
        }

        audit_event = (
            "SPREADSHEET_UPDATE_EXECUTED" if execution_completed
            else "SPREADSHEET_UPDATE_APPROVAL_RECORDED" if execute_requested and pending_ids
            else "SPREADSHEET_UPDATE_VALIDATED"
        )
        audit_action = (
            "Execute Excel source changes" if execution_completed
            else "Record Excel source-change approval" if execute_requested and pending_ids
            else "Validate Excel source changes"
        )
        await self.audit_agentic_activity(
            audit_event,
            {
                "session_id": session_id,
                "actor": actor or state.metadata.get("actor") or "Unknown user",
                "actor_email": actor_email or state.metadata.get("actor_email"),
                "actor_role": normalized_role,
                "source": "Agentic AI · Excel update workbook",
                "action": audit_action,
                "status": "COMPLETED" if not failed else "PARTIAL",
                "target": file_name,
                "verification": f"{len(successful)} row(s) accepted; {len(failed)} row(s) rejected; {len(pending_ids)} row(s) awaiting approval",
                "details": {
                    "file_name": file_name,
                    "rows": len(rows),
                    "execution_requested": execute_requested,
                    "execution_completed": execution_completed,
                    "requires_final_approval": requires_final_approval,
                    "pending_count": len(pending_ids),
                    "effective_write_mode": self._effective_write_mode(state, normalized_role),
                },
            },
        )
        return {
            "file_name": file_name,
            "instruction": instruction,
            "execute_requested": execute_requested,
            "execution_completed": execution_completed,
            "requires_final_approval": requires_final_approval,
            "awaiting_chat_approval_count": len(awaiting_chat),
            "awaiting_final_approval_count": len(awaiting_final),
            "effective_write_mode": self._effective_write_mode(state, normalized_role),
            "role_approval_profile": _role_approval_profile(normalized_role),
            "row_count": len(rows),
            "accepted_count": len(successful),
            "failed_count": len(failed),
            "pending_change_ids": list(state.facts.get("pending_spreadsheet_change_ids") or []),
            "rows": row_results,
            "completed_changes": [self.public_change(change) for change in terminal_changes],
        }

    async def execute_pending_spreadsheet_changes(
        self,
        *,
        session_id: str,
        command_text: str,
        state: SessionState,
    ) -> dict[str, Any] | None:
        pending_ids = [str(value).upper() for value in (state.facts.get("pending_spreadsheet_change_ids") or []) if value]
        if not pending_ids:
            return None
        if not self.is_explicit_execution_request(command_text):
            return None
        raw_role = state.metadata.get("actor_role")
        self.require_agentic_write_role(raw_role)
        role = _normalize_actor_role(raw_role)
        terminal: list[dict[str, Any]] = []
        still_pending: list[str] = []
        rows: list[dict[str, Any]] = []
        for change_id in pending_ids:
            try:
                change = await self._get_change(session_id, change_id)
                status_before = str(change.get("status") or "").upper()
                if status_before == "AWAITING_CONFIRMATION_1":
                    result = await self.execute_explicit_chat_command(
                        session_id,
                        change_id,
                        command_text="apply spreadsheet changes",
                        actor=state.metadata.get("actor"),
                        actor_email=state.metadata.get("actor_email"),
                        actor_role=role,
                    )
                elif status_before == "AWAITING_CONFIRMATION_2":
                    # Approval 1 already exists. A second chat instruction must
                    # never stand in for the required final-review popup.
                    result = change
                else:
                    result = change

                status_after = str(result.get("status") or "UNKNOWN").upper()
                if status_after in {"AWAITING_CONFIRMATION_1", "AWAITING_CONFIRMATION_2"}:
                    still_pending.append(change_id)
                else:
                    terminal.append(result)
                rows.append({
                    "row_number": result.get("spreadsheet_row_number"),
                    "source_label": result.get("source_label"),
                    "field": result.get("field"),
                    "requested_value": result.get("new_value"),
                    "status": status_after,
                    "change_id": result.get("change_id"),
                    "change": self.public_change(result),
                })
            except SourceOperationError as exc:
                # Preserve the row when a final popup is still required; only
                # genuine terminal errors are reported as failed.
                if exc.code == "FINAL_APPROVAL_POPUP_REQUIRED":
                    change = await self._get_change(session_id, change_id)
                    still_pending.append(change_id)
                    rows.append({
                        "row_number": change.get("spreadsheet_row_number"),
                        "source_label": change.get("source_label"),
                        "field": change.get("field"),
                        "requested_value": change.get("new_value"),
                        "status": "AWAITING_CONFIRMATION_2",
                        "change_id": change_id,
                        "change": self.public_change(change),
                    })
                else:
                    rows.append({"change_id": change_id, "status": "FAILED", "code": exc.code, "message": str(exc)})

        if still_pending:
            state.facts["pending_spreadsheet_change_ids"] = still_pending
        else:
            state.facts.pop("pending_spreadsheet_change_ids", None)
        awaiting_final = len([row for row in rows if row.get("status") == "AWAITING_CONFIRMATION_2"])
        failed_count = len([row for row in rows if str(row.get("status") or "").upper() == "FAILED"])
        execution_completed = bool(rows and not still_pending and not failed_count)
        return {
            "file_name": state.facts.get("pending_spreadsheet_file_name"),
            "execute_requested": True,
            "execution_completed": execution_completed,
            "requires_final_approval": awaiting_final > 0,
            "awaiting_final_approval_count": awaiting_final,
            "awaiting_chat_approval_count": len([row for row in rows if row.get("status") == "AWAITING_CONFIRMATION_1"]),
            "effective_write_mode": self._effective_write_mode(state, role),
            "role_approval_profile": _role_approval_profile(role),
            "row_count": len(rows),
            "accepted_count": len(rows) - failed_count,
            "failed_count": failed_count,
            "pending_change_ids": list(still_pending),
            "rows": rows,
            "completed_changes": [self.public_change(change) for change in terminal],
        }

    @staticmethod
    def spreadsheet_update_reply(result: dict[str, Any]) -> str:
        execute = bool(result.get("execute_requested"))
        completed = bool(result.get("execution_completed"))
        awaiting_final = int(result.get("awaiting_final_approval_count") or 0)
        title = "Excel source updates executed" if completed else ("Excel source approvals recorded" if execute else "Excel source updates validated")
        lines = [
            f"## {title}",
            f"- **Workbook:** `{result.get('file_name') or 'uploaded workbook'}`",
            f"- **Mode:** `{result.get('effective_write_mode') or 'unknown'}`",
            f"- **Rows:** {result.get('row_count', 0)}",
            f"- **Accepted:** {result.get('accepted_count', 0)}",
            f"- **Rejected/failed:** {result.get('failed_count', 0)}",
            "",
            "| Row | Source | Identifier | Field | Requested value | Status |",
            "|---:|---|---|---|---|---|",
        ]
        for row in (result.get("rows") or [])[:100]:
            identifier = str(row.get("identifier_value") or row.get("resolved_email") or "—")
            lines.append(
                f"| {row.get('row_number') or '—'} | {row.get('source_label') or row.get('source') or '—'} | "
                f"`{identifier}` | `{row.get('field') or '—'}` | `{row.get('requested_value')}` | **{row.get('status') or 'UNKNOWN'}** |"
            )
        if len(result.get("rows") or []) > 100:
            lines.append(f"\n…and {len(result['rows']) - 100} more row(s) are available in the structured result.")
        if not execute and result.get("pending_change_ids"):
            lines.extend([
                "",
                "No source data was changed. Each accepted row has its own governed change card. Approve the exact row you want to process.",
            ])
        elif awaiting_final:
            lines.extend([
                "",
                f"Chat approval 1 is recorded for **{awaiting_final}** row(s). No live write was executed for those rows. Complete each row's **final-review popup** before execution.",
            ])
        elif completed:
            lines.extend([
                "",
                "Every accepted row used the same governed Rewards DB/CrowdTwist manual-tab writer, with pre-read, write-mode enforcement, read-after-write verification, and audit.",
            ])
        return "\n".join(lines)

    # ------------------------------- Change plans -------------------------------
    async def plan_change(
        self,
        *,
        session_id: str,
        source: SourceSystem,
        operation: SourceOperation,
        emails: list[str],
        field: str,
        new_value: Any,
        reason: str | None,
        actor: str | None = None,
        actor_email: str | None = None,
    ) -> dict[str, Any]:
        state = await self.sessions.get(session_id)
        resolved_actor = str(actor or state.metadata.get("actor") or "Unknown user").strip()
        resolved_actor_email = actor_email or state.metadata.get("actor_email")
        resolved_actor_role = _normalize_actor_role(state.metadata.get("actor_role"))
        state.metadata["actor"] = resolved_actor
        if resolved_actor_email:
            state.metadata["actor_email"] = str(resolved_actor_email).strip()
        if operation != SourceOperation.UPDATE:
            raise SourceOperationError(
                "UNSUPPORTED_SOURCE_OPERATION",
                "This Agentic confirmation workflow supports downstream updates only.",
            )
        if source not in AGENTIC_WRITABLE_SOURCES:
            raise SourceOperationError(
                "CPS_AGENTIC_WRITE_NOT_ALLOWED",
                "CPS is the read-only truth/reference source for Agentic AI. The agent can update only Rewards DB and CrowdTwist; manual CPS functionality remains unchanged.",
                status_code=409,
                details={
                    "truth_source": SourceSystem.CPS.value,
                    "writable_sources": [SourceSystem.REWARDS_DB.value, SourceSystem.CROWD_TWIST.value],
                },
            )
        emails = _dedupe_emails(emails)
        if len(emails) > self.settings.source_write_max_targets:
            raise SourceOperationError(
                "TOO_MANY_WRITE_TARGETS",
                f"A single change request is limited to {self.settings.source_write_max_targets} targets.",
            )
        canonical_field = self.resolve_field(field) or field
        spec = WRITE_FIELDS.get(source, {}).get(canonical_field)
        if spec is None:
            supported = ", ".join(sorted(WRITE_FIELDS.get(source, {}))) or "none"
            raise SourceOperationError(
                "UNSUPPORTED_WRITE_FIELD",
                f"{_source_label(source)} does not allow the field '{field}' through this agent. Allowed fields: {supported}.",
            )
        wire_field, data_type = spec
        normalized = normalize(new_value, data_type)
        if not normalized.valid:
            raise SourceOperationError("INVALID_NEW_VALUE", normalized.note or "The new value is invalid.", details={"field": canonical_field})
        write_value = (
            str(new_value).strip()
            if data_type in {"text_ci", "phone", "postal_code"}
            else normalized.value
        )

        targets: list[dict[str, Any]] = []
        errors: list[dict[str, Any]] = []
        for email in emails:
            read = await self._read_target(source, email)
            if not read.get("connected") or not read.get("data_found"):
                errors.append({
                    "email": email,
                    "code": "TARGET_NOT_FOUND" if read.get("connected") else "SOURCE_UNAVAILABLE",
                    "message": "No existing target record was found." if read.get("connected") else "The source could not be reached.",
                    "read": read,
                })
                continue
            before = self._current_value(source, canonical_field, read)
            if _values_equal(before, write_value, data_type):
                errors.append({"email": email, "code": "NO_CHANGE_REQUIRED", "message": "The source already contains the requested value.", "current_value": before})
                continue
            targets.append({
                "email": email,
                "identity": read.get("identity") or {},
                "field": canonical_field,
                "wire_field": wire_field,
                "before": before,
                "after": write_value,
                "read_snapshot": self._compact_read(read),
            })
        if not targets:
            raise SourceOperationError("NO_ELIGIBLE_WRITE_TARGETS", "No target is eligible for this change.", details={"errors": sanitize(errors)})

        change_id = "CHG-" + secrets.token_hex(6).upper()
        now = utc_now()
        expires_at = now + timedelta(minutes=max(1, self.settings.source_write_confirmation_ttl_minutes))
        plan = {
            "change_id": change_id,
            "session_id": session_id,
            "source": source.value,
            "source_label": _source_label(source),
            "operation": operation.value,
            "field": canonical_field,
            "wire_field": wire_field,
            "new_value": write_value,
            "reason": reason or "Requested through Agentic AI",
            "actor": resolved_actor,
            "actor_email": resolved_actor_email,
            "actor_role": resolved_actor_role,
            "approval_policy": "business_chat" if resolved_actor_role == "Business" else "chat_popup",
            "role_approval_profile": _role_approval_profile(resolved_actor_role),
            "required_confirmation_count": 1 if resolved_actor_role == "Business" else 2,
            "channel": "agentic-ai",
            "targets": targets,
            "ineligible_targets": errors,
            "target_count": len(targets),
            "write_mode": self._effective_write_mode(state, resolved_actor_role),
            "status": "AWAITING_CONFIRMATION_1",
            "confirmation_count": 0,
            "created_at": now.isoformat(),
            "expires_at": expires_at.isoformat(),
            "second_confirmation_code": None,
            "first_confirmation_channel": None,
            "second_confirmation_channel": None,
            "popup_opened_at": None,
            "popup_opened_by": None,
            "popup_opened_by_email": None,
            "popup_acknowledged": False,
            "audit_acknowledged": False,
            "popup_approval_token": None,
            "popup_token_expires_at": None,
            "popup_token_used_at": None,
            "executed_at": None,
            "results": [],
            "plan_digest": self._plan_digest(source, operation, canonical_field, write_value, targets),
            "live_supported": self._live_supported(source, operation),
        }
        changes = state.facts.setdefault("source_changes", {})
        changes[change_id] = plan
        state.facts["active_source_change_id"] = change_id
        await self._audit("PLAN_CREATED", plan)
        return plan

    async def confirm_first(
        self,
        session_id: str,
        change_id: str,
        confirmation_text: str,
        actor: str | None = None,
        actor_email: str | None = None,
        *,
        approval_channel: str = "api",
        actor_role: str | None = None,
    ) -> dict[str, Any]:
        change = await self._get_change(session_id, change_id)
        self._assert_not_expired(change)
        if change["status"] != "AWAITING_CONFIRMATION_1":
            raise SourceOperationError("INVALID_CHANGE_STATE", f"Change {change_id} is in state {change['status']}.")
        if str(approval_channel or "").casefold() != "chat":
            raise SourceOperationError(
                "CONFIRMATION_1_REQUIRES_CHAT",
                "Approval 1 must be a standalone yes in the same Agentic AI chat.",
                409,
            )
        expected = f"CONFIRM {change_id}"
        supplied = confirmation_text.strip().upper().rstrip(".!?")
        if supplied not in {"YES", expected}:
            raise SourceOperationError(
                "CONFIRMATION_1_MISMATCH",
                f'Reply "yes" in the same Agentic AI chat, or type exactly: {expected}',
            )
        resolved_role = _normalize_actor_role(actor_role or change.get("actor_role"))
        change.update({
            "confirmation_count": 1,
            "first_confirmed_at": utc_now().isoformat(),
            "first_confirmed_by": actor or change.get("actor") or "Unknown user",
            "first_confirmed_by_email": actor_email or change.get("actor_email"),
            "first_confirmation_channel": "chat",
            "actor_role": resolved_role,
        })
        if resolved_role == "Business":
            change.update({
                "status": "EXECUTING",
                "required_confirmation_count": 1,
                "approval_policy": "business_chat",
                "second_confirmation_channel": "not_required",
            })
            await self._audit("BUSINESS_CHAT_APPROVAL_ACCEPTED", change)
            completed = await self._execute_approved_change(session_id, change_id, change)
            return await self._prepare_next_suggested_change_after_execution(
                session_id=session_id, completed=completed
            )

        code = secrets.token_hex(3).upper()
        change.update({
            "status": "AWAITING_CONFIRMATION_2",
            "required_confirmation_count": 2,
            "approval_policy": "chat_popup",
            "second_confirmation_code": code,
        })
        await self._audit("CONFIRMATION_1_CHAT_ACCEPTED", change)
        return change

    async def execute_explicit_chat_command(
        self,
        session_id: str,
        change_id: str,
        *,
        command_text: str,
        actor: str | None = None,
        actor_email: str | None = None,
        actor_role: str | None = None,
    ) -> dict[str, Any]:
        """Apply an explicit chat approval without bypassing the role policy.

        Business has a single chat approval. Customer Support, Technical and Admin
        require the chat approval plus the final-review popup. This method is kept
        for compatibility with internal callers, but it is intentionally unable to
        turn a non-Business imperative into a live write by itself.
        """
        change = await self._get_change(session_id, change_id)
        self._assert_not_expired(change)
        resolved_role = _normalize_actor_role(actor_role or change.get("actor_role"))
        self.require_agentic_write_role(resolved_role)
        normalized_command = re.sub(r"[.!?]+$", "", str(command_text or "").casefold()).strip()
        active_confirmation_reply = normalized_command in {"yes", "confirm", "approve", "apply"}
        if not self.is_explicit_execution_request(command_text) and not active_confirmation_reply:
            raise SourceOperationError(
                "EXPLICIT_APPROVAL_COMMAND_REQUIRED",
                "Use an explicit chat approval such as 'yes', 'do the change', or 'apply this change'.",
                409,
            )
        status = str(change.get("status") or "").upper()
        if status == "AWAITING_CONFIRMATION_1":
            return await self.confirm_first(
                session_id,
                change_id,
                "YES",
                actor=actor,
                actor_email=actor_email,
                approval_channel="chat",
                actor_role=resolved_role,
            )
        if status == "AWAITING_CONFIRMATION_2":
            raise SourceOperationError(
                "FINAL_APPROVAL_POPUP_REQUIRED",
                "Chat approval is already recorded. Open the final-review popup and approve the exact plan to execute it.",
                409,
                details={"change_id": change_id, "approval_policy": change.get("approval_policy")},
            )
        raise SourceOperationError(
            "INVALID_CHANGE_STATE",
            f"Change {change_id} is in state {change.get('status')} and cannot accept another chat approval.",
            409,
        )

    async def mark_popup_opened(
        self,
        session_id: str,
        change_id: str,
        actor: str | None = None,
        actor_email: str | None = None,
    ) -> dict[str, Any]:
        change = await self._get_change(session_id, change_id)
        self._assert_not_expired(change)
        if change["status"] != "AWAITING_CONFIRMATION_2":
            raise SourceOperationError(
                "FINAL_POPUP_NOT_AVAILABLE",
                f"The final approval popup is not available while change {change_id} is in state {change['status']}.",
                409,
            )
        opened_at = utc_now()
        plan_expires_at = datetime.fromisoformat(change["expires_at"])
        token_expires_at = min(plan_expires_at, opened_at + timedelta(minutes=5))
        change.update(
            {
                "popup_opened_at": opened_at.isoformat(),
                "popup_opened_by": actor or change.get("first_confirmed_by") or change.get("actor") or "Unknown user",
                "popup_opened_by_email": actor_email or change.get("first_confirmed_by_email") or change.get("actor_email"),
                # A fresh, short-lived nonce binds approval 2 to the popup that was actually opened.
                # Reopening the popup invalidates any older browser preview.
                "popup_approval_token": secrets.token_urlsafe(32),
                "popup_token_expires_at": token_expires_at.isoformat(),
                "popup_token_used_at": None,
            }
        )
        await self._audit("FINAL_APPROVAL_POPUP_OPENED", change)
        return change

    async def confirm_second(
        self,
        session_id: str,
        change_id: str,
        confirmation_text: str,
        actor: str | None = None,
        actor_email: str | None = None,
        *,
        approval_channel: str = "api",
        popup_acknowledged: bool = False,
        audit_acknowledged: bool = False,
        plan_digest: str | None = None,
        popup_token: str | None = None,
    ) -> dict[str, Any]:
        change = await self._get_change(session_id, change_id)
        self._assert_not_expired(change)
        if change["status"] != "AWAITING_CONFIRMATION_2":
            raise SourceOperationError("INVALID_CHANGE_STATE", f"Change {change_id} is in state {change['status']}.")
        if str(approval_channel or "").casefold() != "popup":
            raise SourceOperationError(
                "CONFIRMATION_2_REQUIRES_POPUP",
                "Approval 2 must be submitted from the final-review popup; a second chat yes cannot execute the update.",
                409,
            )
        if not popup_acknowledged or not audit_acknowledged:
            raise SourceOperationError(
                "FINAL_APPROVAL_ACKNOWLEDGEMENT_REQUIRED",
                "Review and acknowledge both the exact change preview and the audit/read-after-write notice in the popup.",
                409,
            )
        if not change.get("popup_opened_at") or not change.get("popup_approval_token"):
            raise SourceOperationError(
                "FINAL_APPROVAL_POPUP_NOT_OPENED",
                "Open the final-review popup before submitting approval 2.",
                409,
            )
        token_expiry_raw = change.get("popup_token_expires_at")
        token_expiry = datetime.fromisoformat(str(token_expiry_raw)) if token_expiry_raw else utc_now()
        if token_expiry <= utc_now():
            raise SourceOperationError(
                "FINAL_APPROVAL_POPUP_EXPIRED",
                "The final-review popup expired. Close it and open a fresh review.",
                409,
            )
        if not popup_token or not secrets.compare_digest(str(popup_token), str(change.get("popup_approval_token") or "")):
            raise SourceOperationError(
                "INVALID_POPUP_APPROVAL_TOKEN",
                "The final approval is not bound to the active popup. Close it and open a fresh review.",
                409,
            )
        if not plan_digest or not secrets.compare_digest(str(plan_digest), str(change.get("plan_digest") or "")):
            raise SourceOperationError(
                "STALE_OR_TAMPERED_CHANGE_PREVIEW",
                "The popup does not match the active source-change plan. Close it and open a fresh final review.",
                409,
            )
        expected = f"APPLY {change_id} {change['second_confirmation_code']}"
        supplied = confirmation_text.strip().upper().rstrip(".!?")
        if supplied not in {"APPROVE", expected}:
            raise SourceOperationError(
                "CONFIRMATION_2_MISMATCH",
                "Use the Approve and execute button in the final-review popup.",
            )
        change["confirmation_count"] = 2
        change["second_confirmed_at"] = utc_now().isoformat()
        change["second_confirmed_by"] = actor or change.get("first_confirmed_by") or change.get("actor") or "Unknown user"
        change["second_confirmed_by_email"] = actor_email or change.get("first_confirmed_by_email") or change.get("actor_email")
        change["second_confirmation_channel"] = "popup"
        change["popup_acknowledged"] = True
        change["audit_acknowledged"] = True
        change["popup_token_used_at"] = utc_now().isoformat()
        change["popup_approval_token"] = None
        change["status"] = "EXECUTING"
        await self._audit("CONFIRMATION_2_POPUP_ACCEPTED", change)

        completed = await self._execute_approved_change(session_id, change_id, change)
        return await self._prepare_next_suggested_change_after_execution(
            session_id=session_id, completed=completed
        )

    async def _execute_approved_change(
        self,
        session_id: str,
        change_id: str,
        change: dict[str, Any],
    ) -> dict[str, Any]:
        # Re-read all targets immediately before execution. Any drift aborts the entire request.
        drift: list[dict[str, Any]] = []
        for target in change["targets"]:
            current = await self._read_target(SourceSystem(change["source"]), target["email"])
            current_value = self._current_value(SourceSystem(change["source"]), change["field"], current)
            data_type = _write_data_type(SourceSystem(change["source"]), change["field"])
            if not current.get("data_found") or not _values_equal(current_value, target.get("before"), data_type):
                drift.append({
                    "email": target["email"],
                    "planned_before": target.get("before"),
                    "current_before": current_value,
                    "data_found": current.get("data_found"),
                })
        if drift:
            change.update({"status": "ABORTED_PRECONDITION_CHANGED", "results": drift, "executed_at": utc_now().isoformat()})
            await self._audit("EXECUTION_ABORTED_PRECONDITION_CHANGED", change)
            await self._clear_active_change(session_id, change_id)
            return change

        # Re-resolve the profile policy at execution time. A new authenticated
        # request may have changed the user's Dry Run assignment since the plan
        # was created; the latest server-enforced profile wins.
        state = await self.sessions.get(session_id)
        effective_write_mode = self._effective_write_mode(state, change.get("actor_role"))
        change["write_mode"] = effective_write_mode

        if effective_write_mode == "disabled":
            change.update({
                "status": "BLOCKED_WRITES_DISABLED",
                "executed_at": utc_now().isoformat(),
                "results": [{"success": False, "code": "WRITES_DISABLED", "message": "SOURCE_WRITE_MODE is disabled."}],
            })
            await self._audit("EXECUTION_BLOCKED", change)
            await self._clear_active_change(session_id, change_id)
            return change

        if effective_write_mode == "dry_run":
            change.update({
                "status": "DRY_RUN_COMPLETED",
                "executed_at": utc_now().isoformat(),
                "results": [
                    {
                        "email": target["email"],
                        "success": True,
                        "dry_run": True,
                        "field": change["field"],
                        "before": target.get("before"),
                        "after": target.get("after"),
                    }
                    for target in change["targets"]
                ],
            })
            await self._audit("DRY_RUN_COMPLETED", change)
            await self._clear_active_change(session_id, change_id)
            return change

        if not change.get("live_supported"):
            change.update({
                "status": "BLOCKED_OPERATION_NOT_CONFIGURED",
                "executed_at": utc_now().isoformat(),
                "results": [{"success": False, "code": "LIVE_OPERATION_NOT_CONFIGURED", "message": self._unsupported_live_message(change)}],
            })
            await self._audit("EXECUTION_BLOCKED_NOT_CONFIGURED", change)
            await self._clear_active_change(session_id, change_id)
            return change

        results: list[dict[str, Any]] = []
        for target in change["targets"]:
            try:
                result = await self._execute_target(change, target)
            except Exception as exc:  # fail closed, but continue to give per-target audit
                result = {"email": target["email"], "success": False, "code": "WRITE_EXCEPTION", "message": f"{type(exc).__name__}: source update failed"}
            results.append(result)
        successes = sum(1 for item in results if item.get("success"))
        status = "COMPLETED" if successes == len(results) else ("PARTIAL" if successes else "FAILED")
        change.update({"status": status, "executed_at": utc_now().isoformat(), "results": results})
        await self._audit("EXECUTION_COMPLETED", change)
        await self._clear_active_change(session_id, change_id)
        return change

    async def _clear_active_change(self, session_id: str, change_id: str) -> None:
        state = await self.sessions.get(session_id)
        normalized_id = change_id.upper()
        if str(state.facts.get("active_source_change_id") or "").upper() == normalized_id:
            state.facts["last_source_change_id"] = normalized_id
            state.facts["active_source_change_id"] = None
        pending = [str(value).upper() for value in (state.facts.get("pending_spreadsheet_change_ids") or []) if value]
        if normalized_id in pending:
            pending = [value for value in pending if value != normalized_id]
            if pending:
                state.facts["pending_spreadsheet_change_ids"] = pending
            else:
                state.facts.pop("pending_spreadsheet_change_ids", None)

    async def append_popup_execution_message(self, session_id: str, change: dict[str, Any]) -> None:
        """Persist popup execution outcome into the Agentic chat session."""
        await self.sessions.append(
            session_id,
            role="assistant",
            content=self._execution_reply(change),
            metadata={
                "intent": "source_confirm_2",
                "structuredData": {"change": self.public_change(change)},
                "approvalChannels": ["chat", "popup"],
            },
        )

    async def cancel_change(self, session_id: str, change_id: str, reason: str | None = None, actor: str | None = None, actor_email: str | None = None) -> dict[str, Any]:
        change = await self._get_change(session_id, change_id)
        if change["status"] in {"COMPLETED", "PARTIAL", "FAILED", "DRY_RUN_COMPLETED"}:
            raise SourceOperationError("CHANGE_ALREADY_FINAL", f"Change {change_id} is already final.")
        change.update({
            "status": "CANCELLED",
            "cancelled_at": utc_now().isoformat(),
            "cancel_reason": reason or "Cancelled",
            "cancelled_by": actor or change.get("actor") or "Unknown user",
            "cancelled_by_email": actor_email or change.get("actor_email"),
        })
        await self._audit("CHANGE_CANCELLED", change)
        await self._clear_active_change(session_id, change_id)
        return change

    async def get_change(self, session_id: str, change_id: str) -> dict[str, Any]:
        return self.public_change(await self._get_change(session_id, change_id))

    async def _get_change(self, session_id: str, change_id: str) -> dict[str, Any]:
        state = await self.sessions.get(session_id)
        change = (state.facts.get("source_changes") or {}).get(change_id.upper())
        if not isinstance(change, dict):
            raise SourceOperationError("CHANGE_NOT_FOUND", f"Change request {change_id} was not found in this session.", 404)
        return change

    @staticmethod
    def _assert_not_expired(change: dict[str, Any]) -> None:
        if datetime.fromisoformat(change["expires_at"]) <= utc_now():
            change["status"] = "EXPIRED"
            raise SourceOperationError("CHANGE_EXPIRED", "The change request expired. Create a new plan.", 409)

    async def _execute_target(self, change: dict[str, Any], target: dict[str, Any]) -> dict[str, Any]:
        source = SourceSystem(change["source"])
        if source in {SourceSystem.REWARDS_DB, SourceSystem.CROWD_TWIST}:
            return await self._update_via_dotnet_manual_contract(change, target)
        return await self._update_cps(change, target)

    async def _update_via_dotnet_manual_contract(
        self,
        change: dict[str, Any],
        target: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute the physical write through the same .NET services as the manual tabs.

        Python remains the governance layer (truth, role policy, dry-run, drift
        detection, auditing and fresh re-analysis).  The actual mutation is
        delegated to the loopback-only .NET bridge, which calls
        RewardsDbOperationsV2.UpdateMemberColumnAsync or
        LoyaltyServiceProviderV3.UpdateUserProfilePropertiesAsync.  This keeps
        Agentic and manual update behavior on one tested source contract.
        """
        source = SourceSystem(change["source"])
        identity = target.get("identity") or {}
        if source == SourceSystem.REWARDS_DB:
            target_id = identity.get("member_id")
            missing_code = "MEMBER_ID_MISSING"
        else:
            target_id = identity.get("crowd_twist_id")
            missing_code = "CROWD_TWIST_ID_MISSING"

        if target_id in (None, ""):
            return {
                "email": target.get("email"),
                "success": False,
                "code": missing_code,
                "message": f"{_source_label(source)} target identifier was not resolved.",
            }

        base_url = str(self.settings.utility_service_base_url or "").strip().rstrip("/")
        internal_key = str(self.settings.utility_service_internal_key or "").strip()
        if not base_url:
            return {
                "email": target.get("email"),
                "success": False,
                "code": "DOTNET_WRITE_BRIDGE_NOT_CONFIGURED",
                "message": (
                    "The Dell Utility manual-update bridge URL is not configured. "
                    "Set UTILITY_SERVICE_BASE_URL (default http://127.0.0.1:49690) or use the supplied manual/combined start scripts."
                ),
            }

        payload = {
            "source": source.value,
            "targetId": str(target_id),
            "field": str(change.get("wire_field") or change.get("field") or ""),
            "newValue": "" if target.get("after") is None else str(target.get("after")),
            "correlationId": str(change.get("change_id") or ""),
        }
        headers = {"Accept": "application/json"}
        if internal_key:
            headers["X-Internal-API-Key"] = internal_key
        url = f"{base_url}/api/internal/source-write"
        try:
            async with httpx.AsyncClient(timeout=self.settings.request_timeout_seconds) as client:
                response = await client.post(url, json=payload, headers=headers)
        except httpx.TimeoutException:
            return {
                "email": target.get("email"),
                "success": False,
                "code": "DOTNET_WRITE_BRIDGE_TIMEOUT",
                "message": "The .NET manual-update bridge timed out.",
                "implementation": "dotnet-manual-update-bridge",
            }
        except httpx.RequestError:
            return {
                "email": target.get("email"),
                "success": False,
                "code": "DOTNET_WRITE_BRIDGE_UNREACHABLE",
                "message": "The .NET manual-update bridge could not be reached on loopback.",
                "implementation": "dotnet-manual-update-bridge",
            }

        try:
            bridge_data = response.json()
        except Exception:
            bridge_data = {}
        if not response.is_success or not bool(bridge_data.get("success")):
            return {
                "email": target.get("email"),
                "success": False,
                "code": str(bridge_data.get("code") or f"HTTP_{response.status_code}"),
                "http_status": response.status_code,
                "message": str(bridge_data.get("message") or "The shared .NET manual-update service rejected the source update."),
                "implementation": str(bridge_data.get("implementation") or "dotnet-manual-update-bridge"),
                "bridge_source": bridge_data.get("source"),
                "bridge_details": sanitize({
                    "field": bridge_data.get("field"),
                    "effectiveProperties": bridge_data.get("effectiveProperties"),
                }),
            }

        # Independent read-after-write verification remains in the Agentic
        # governance layer. For CrowdTwist we allow bounded propagation delay;
        # Rewards DB should normally reflect immediately but receives a retry as
        # protection against transient read timing.
        if source == SourceSystem.CROWD_TWIST:
            delays = (0.0, 0.75, 1.5, 2.5)
        else:
            delays = (0.0, 0.25)

        observed: Any = None
        verified = False
        verification_attempts: list[dict[str, Any]] = []
        for attempt, delay in enumerate(delays, start=1):
            if delay:
                await asyncio.sleep(delay)
            read = await self._read_target(source, target["email"])
            observed = self._current_value(source, change["field"], read)
            verified, verification_basis = self._verify_shared_write_value(
                source=source,
                field=str(change["field"]),
                observed=observed,
                requested=target.get("after"),
                read=read,
                bridge_data=bridge_data,
            )
            verification_attempts.append({
                "attempt": attempt,
                "data_found": bool(read.get("data_found")),
                "http_status": read.get("http_status"),
                "matched": bool(verified),
                "basis": verification_basis,
            })
            if verified:
                break

        return {
            "email": target.get("email"),
            "success": bool(verified),
            "verified": bool(verified),
            "http_status": response.status_code,
            "field": change.get("field"),
            "before": target.get("before"),
            "after": observed,
            "requested_after": target.get("after"),
            "implementation": str(bridge_data.get("implementation") or "dotnet-manual-update-bridge"),
            "shared_manual_contract": True,
            "effective_properties": bridge_data.get("effectiveProperties"),
            "bridge_before": sanitize(bridge_data.get("before")),
            "bridge_after": sanitize(bridge_data.get("after")),
            "verification_attempts": verification_attempts,
            "code": None if verified else "VERIFY_FAILED",
            "message": None if verified else "The shared manual update service accepted the write, but Agentic read-after-write verification did not observe the requested value.",
        }


    def _verify_shared_write_value(
        self,
        *,
        source: SourceSystem,
        field: str,
        observed: Any,
        requested: Any,
        read: dict[str, Any],
        bridge_data: dict[str, Any],
    ) -> tuple[bool, str]:
        """Verify a write using the representation exposed by the read contract.

        CrowdTwist's GET contract commonly expands ``country_code=US`` to the
        display value ``country=United States`` and its ``UserDetailsResponse``
        does not reliably expose ``country_code``.  The manual update service,
        however, expands/sends the exact wire properties and reports them back as
        ``effectiveProperties``.  For Country we therefore require *both*:

        1. the shared manual bridge confirms it sent the requested country_code;
        2. the post-write read resolves semantically to the same ISO country.

        All other fields retain their normal type-aware read-after-write check.
        """
        if source == SourceSystem.CROWD_TWIST and field == "country":
            requested_norm = normalize(requested, "country")
            observed_norm = normalize(observed, "country")
            effective = bridge_data.get("effectiveProperties") or {}
            effective_code = _ci_get(effective, "country_code", "countryCode")
            effective_norm = normalize(effective_code, "country")
            bridge_after = bridge_data.get("after") or {}
            bridge_after_code = _ci_get(bridge_after, "country_code", "countryCode")
            bridge_after_norm = normalize(bridge_after_code, "country")

            # Strongest case: the .NET shared manual service can read the exact
            # country_code back from CrowdTwist after the write.
            if (
                bool(read.get("data_found"))
                and requested_norm.valid
                and effective_norm.valid
                and bridge_after_norm.valid
                and requested_norm.value == effective_norm.value == bridge_after_norm.value
            ):
                return True, "exact_country_code_readback"

            # Compatibility case observed in Dell CrowdTwist: GET returns only
            # the display country ("United States") even though PUT persisted
            # country_code=US.  Require both a correctly expanded manual write
            # contract and a semantically equivalent post-write read.
            if (
                bool(read.get("data_found"))
                and requested_norm.valid
                and observed_norm.valid
                and effective_norm.valid
                and requested_norm.value == observed_norm.value == effective_norm.value
            ):
                return True, "shared_country_code_plus_semantic_read"
            return False, "shared_country_code_plus_semantic_read"

        verified = bool(read.get("data_found")) and _values_equal(
            observed, requested, _write_data_type(source, field)
        )
        return bool(verified), "typed_read_after_write"

    async def _update_cps(self, change: dict[str, Any], target: dict[str, Any]) -> dict[str, Any]:
        if not self.settings.cps_update_path:
            return {"email": target["email"], "success": False, "code": "CPS_UPDATE_NOT_CONFIGURED", "message": "No approved CPS update path is configured."}
        connector = CPSConnector(self.settings)
        token = await connector.tokens.get_token()
        identity = target.get("identity") or {}
        value = identity.get("profile_id") or target["email"]
        path = self.settings.cps_update_path.format(value=quote(str(value), safe=""), email=quote(target["email"], safe=""), profile_id=quote(str(identity.get("profile_id") or ""), safe=""))
        url = f"{self.settings.cps_base_url.rstrip('/')}/{path.lstrip('/')}"
        headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
        if self.settings.cps_api_key:
            headers[self.settings.cps_api_key_header] = self.settings.cps_api_key
        method = self.settings.cps_update_method.upper()
        async with httpx.AsyncClient(verify=self.settings.cps_verify_ssl, timeout=self.settings.request_timeout_seconds, follow_redirects=True) as client:
            response = await client.request(method, url, json={change["wire_field"]: target.get("after")}, headers=headers)
        if not response.is_success:
            return {"email": target["email"], "success": False, "code": f"HTTP_{response.status_code}", "http_status": response.status_code, "message": "CPS rejected the update."}
        verify_type = SearchType.PROFILE_ID if identity.get("profile_id") else SearchType.EMAIL
        verify_value = str(identity.get("profile_id") or target["email"])
        verify_record = await connector.fetch(verify_type, verify_value)
        observed = canonicalize(verify_record.raw, SourceName.CPS, self.field_map).get(change["field"])
        verified = verify_record.status.data_found and _values_equal(
            observed, target.get("after"), _write_data_type(SourceSystem.CPS, change["field"])
        )
        return {
            "email": target["email"],
            "success": bool(verified),
            "verified": bool(verified),
            "http_status": response.status_code,
            "field": change["field"],
            "before": target.get("before"),
            "after": observed,
            "code": None if verified else "VERIFY_FAILED",
        }

    def _current_value(self, source: SourceSystem, field: str, read: dict[str, Any]) -> Any:
        canonical = read.get("canonical") or {}
        if field in canonical:
            return canonical[field]
        raw = ((read.get("record") or {}).get("raw") or {})
        wire = WRITE_FIELDS.get(source, {}).get(field, (field, ""))[0]
        aliases = [wire, field, field.replace("_", ""), field.title().replace("_", "")]
        return _ci_get(raw, *aliases)

    @staticmethod
    def _compact_read(read: dict[str, Any]) -> dict[str, Any]:
        return {
            "connected": read.get("connected"),
            "data_found": read.get("data_found"),
            "http_status": read.get("http_status"),
            "latency_ms": read.get("latency_ms"),
            "retrieval_method": read.get("retrieval_method"),
            "identity": read.get("identity"),
            "canonical": read.get("canonical"),
        }

    def _live_supported(self, source: SourceSystem, operation: SourceOperation) -> bool:
        if operation != SourceOperation.UPDATE:
            return False
        if source == SourceSystem.CPS:
            return bool(self.settings.cps_update_path)
        return source in {SourceSystem.REWARDS_DB, SourceSystem.CROWD_TWIST}

    @staticmethod
    def _plan_digest(source: SourceSystem, operation: SourceOperation, field: str, value: Any, targets: list[dict[str, Any]]) -> str:
        payload = json.dumps({"source": source.value, "operation": operation.value, "field": field, "value": value, "targets": targets}, sort_keys=True, default=str)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _unsupported_live_message(self, change: dict[str, Any]) -> str:
        if change["source"] == SourceSystem.CPS.value:
            return "CPS live update is not enabled because CPS_UPDATE_PATH is blank. The uploaded source proves CPS read/create but not an approved update contract."
        return "The requested live operation is not configured."

    async def list_audit(
        self,
        *,
        limit: int = 100,
        source: str | None = None,
        status: str | None = None,
        actor: str | None = None,
        action: str | None = None,
        from_utc: datetime | None = None,
        to_utc: datetime | None = None,
        include_sensitive: bool = False,
    ) -> dict[str, Any]:
        audit_setting = (
            self.settings.source_write_audit_unmasked_file
            if include_sensitive
            else self.settings.source_write_audit_file
        )
        path = Path(audit_setting)
        if include_sensitive and not path.exists():
            # Legacy releases only produced the masked audit stream. Returning it is
            # safer than failing the entire merged audit page.
            path = Path(self.settings.source_write_audit_file)
        if not path.is_absolute():
            path = Path.cwd() / path
        rows: list[dict[str, Any]] = []
        if from_utc and from_utc.tzinfo is None:
            from_utc = from_utc.replace(tzinfo=timezone.utc)
        if to_utc and to_utc.tzinfo is None:
            to_utc = to_utc.replace(tzinfo=timezone.utc)
        if path.exists():
            text = await asyncio.to_thread(path.read_text, encoding="utf-8")
            for line in text.splitlines():
                if not line.strip():
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue
                timestamp = payload.get("timestamp")
                try:
                    parsed_timestamp = datetime.fromisoformat(str(timestamp).replace("Z", "+00:00"))
                except (TypeError, ValueError):
                    parsed_timestamp = datetime.min.replace(tzinfo=timezone.utc)
                event = str(payload.get("event") or "UNKNOWN")
                activity = payload.get("activity") if isinstance(payload.get("activity"), dict) else None
                change = payload.get("change") if isinstance(payload.get("change"), dict) else None

                if activity is not None:
                    entry_status = str(activity.get("status") or event or "UNKNOWN")
                    entry_source = str(activity.get("source") or "Agentic AI")
                    entry_actor = str(activity.get("actor") or "Unknown user")
                    entry_action = str(activity.get("action") or event.replace("_", " ").title())
                    row = {
                        "auditId": activity.get("activity_id") or f"AGENT:{event}:{timestamp}",
                        "timestampUtc": timestamp,
                        "timestamp": timestamp,
                        "actor": entry_actor,
                        "actorEmail": activity.get("actor_email"),
                        "channel": activity.get("channel") or "agentic-ai",
                        "source": entry_source,
                        "action": entry_action,
                        "status": entry_status,
                        "target": activity.get("target"),
                        "field": activity.get("field"),
                        "before": activity.get("before"),
                        "after": activity.get("after"),
                        "reason": activity.get("reason"),
                        "correlationId": activity.get("run_id") or activity.get("correlation_id") or activity.get("session_id"),
                        "verification": activity.get("verification"),
                        "details": {
                            "event": event,
                            "sessionId": activity.get("session_id"),
                            "runId": activity.get("run_id"),
                            "searchType": activity.get("search_type"),
                            "searchValue": activity.get("search_value"),
                            **dict(activity.get("details") or {}),
                        },
                    }
                elif change is not None:
                    entry_status = str(change.get("status") or event or "UNKNOWN")
                    entry_source = str(change.get("source_label") or change.get("source") or "Agentic AI")
                    entry_actor = str(change.get("second_confirmed_by") or change.get("first_confirmed_by") or change.get("actor") or "Unknown user")
                    event_action_labels = {
                        "PLAN_CREATED": "Agentic update planned",
                        "CONFIRMATION_1_CHAT_ACCEPTED": "Chat approval recorded",
                        "BUSINESS_CHAT_APPROVAL_ACCEPTED": "Business chat approval recorded",
                        "FINAL_APPROVAL_POPUP_OPENED": "Final approval popup opened",
                        "CONFIRMATION_2_POPUP_ACCEPTED": "Popup approval recorded",
                        "EXECUTION_COMPLETED": "Agentic update executed",
                        "DRY_RUN_COMPLETED": "Agentic update dry run completed",
                        "EXECUTION_ABORTED_PRECONDITION_CHANGED": "Agentic update aborted after drift check",
                        "EXECUTION_BLOCKED": "Agentic update blocked",
                        "EXECUTION_BLOCKED_NOT_CONFIGURED": "Agentic update blocked: source not configured",
                        "CHANGE_CANCELLED": "Agentic update cancelled",
                    }
                    entry_action = event_action_labels.get(event, event.replace("_", " ").title())
                    targets = change.get("targets") or []
                    target = targets[0] if targets else {}
                    results = change.get("results") or []
                    success_count = sum(1 for item in results if item.get("success")) if results else 0
                    row = {
                        "auditId": f"{change.get('change_id') or 'AGENT'}:{event}:{timestamp}",
                        "timestampUtc": timestamp,
                        "timestamp": timestamp,
                        "actor": entry_actor,
                        "actorEmail": change.get("second_confirmed_by_email") or change.get("first_confirmed_by_email") or change.get("actor_email"),
                        "channel": "agentic-ai",
                        "source": entry_source,
                        "action": entry_action,
                        "status": entry_status,
                        "target": target.get("email") or (f"{len(targets)} target(s)" if targets else None),
                        "field": change.get("field"),
                        "before": target.get("before"),
                        "after": target.get("after") if target else change.get("new_value"),
                        "reason": change.get("reason"),
                        "correlationId": change.get("change_id"),
                        "verification": f"{success_count}/{len(results)} target(s) verified" if results else None,
                        "details": {
                            "event": event,
                            "plannedBy": change.get("actor"),
                            "plannedByEmail": change.get("actor_email"),
                            "firstApprovedBy": change.get("first_confirmed_by"),
                            "firstApprovedByEmail": change.get("first_confirmed_by_email"),
                            "firstApprovalChannel": change.get("first_confirmation_channel"),
                            "secondApprovedBy": change.get("second_confirmed_by"),
                            "secondApprovedByEmail": change.get("second_confirmed_by_email"),
                            "secondApprovalChannel": change.get("second_confirmation_channel"),
                            "approvalPolicy": change.get("approval_policy"),
                            "requiredConfirmationCount": change.get("required_confirmation_count"),
                            "popupOpenedAt": change.get("popup_opened_at"),
                            "popupOpenedBy": change.get("popup_opened_by"),
                            "popupOpenedByEmail": change.get("popup_opened_by_email"),
                            "popupTokenExpiresAt": change.get("popup_token_expires_at"),
                            "popupTokenUsedAt": change.get("popup_token_used_at"),
                            "popupAcknowledged": change.get("popup_acknowledged"),
                            "auditAcknowledged": change.get("audit_acknowledged"),
                            "cancelledBy": change.get("cancelled_by"),
                            "confirmationCount": change.get("confirmation_count"),
                            "writeMode": change.get("write_mode"),
                            "targetCount": change.get("target_count"),
                            "requestedIdentifier": change.get("requested_identifier"),
                            "targets": targets,
                            "planFingerprint": str(change.get("plan_digest") or "")[:12],
                            "firstApprovedAt": change.get("first_confirmed_at"),
                            "secondApprovedAt": change.get("second_confirmed_at"),
                            "executedAt": change.get("executed_at"),
                            "results": results,
                        },
                    }
                else:
                    continue

                if source and source.casefold() not in str(row.get("source") or "").casefold():
                    continue
                if status and status.casefold() not in str(row.get("status") or "").casefold():
                    continue
                if actor and actor.casefold() not in str(row.get("actor") or "").casefold() and actor.casefold() not in str(row.get("actorEmail") or "").casefold():
                    continue
                if action and action.casefold() not in str(row.get("action") or "").casefold() and action.casefold() not in event.casefold():
                    continue
                if from_utc and parsed_timestamp < from_utc:
                    continue
                if to_utc and parsed_timestamp > to_utc:
                    continue
                rows.append(row)

        rows.sort(key=lambda item: str(item.get("timestampUtc") or ""), reverse=True)
        filtered_total = len(rows)
        summary_rows = list(rows)
        limited_rows = rows[: max(1, min(limit, 1000))]
        actor_names = {str(item.get("actor") or "Unknown user").casefold() for item in summary_rows}
        return {
            "entries": limited_rows,
            "privacyMode": "unmasked" if include_sensitive and Path(self.settings.source_write_audit_unmasked_file).exists() else "masked",
            "summary": {
                "total": filtered_total,
                "completed": sum(1 for item in summary_rows if any(token in str(item.get("status", "")).casefold() for token in ("completed", "success", "dry_run"))),
                "failed": sum(1 for item in summary_rows if any(token in str(item.get("status", "")).casefold() for token in ("failed", "blocked", "aborted", "partial"))),
                "pending": sum(1 for item in summary_rows if any(token in str(item.get("status", "")).casefold() for token in ("awaiting", "executing", "planned", "started"))),
                "uniqueActors": len(actor_names),
            },
        }

    async def audit_agentic_activity(self, event: str, activity: dict[str, Any]) -> None:
        """Append a read/analysis Agentic event to the same merged audit stream."""
        path = Path(self.settings.source_write_audit_file)
        if not path.is_absolute():
            path = Path.cwd() / path
        path.parent.mkdir(parents=True, exist_ok=True)
        activity_payload = dict(activity)
        activity_payload.setdefault("activity_id", f"AGT-{secrets.token_hex(6).upper()}")
        activity_payload.setdefault("channel", "agentic-ai")
        timestamp = utc_now().isoformat()
        masked_payload = {
            "timestamp": timestamp,
            "event": event,
            "activity": sanitize(activity_payload),
        }
        unmasked_path = Path(self.settings.source_write_audit_unmasked_file)
        if not unmasked_path.is_absolute():
            unmasked_path = Path.cwd() / unmasked_path
        unmasked_path.parent.mkdir(parents=True, exist_ok=True)
        unmasked_payload = {
            "timestamp": timestamp,
            "event": event,
            "activity": self._redact_audit_secrets(activity_payload),
        }
        async with self._audit_lock:
            await asyncio.to_thread(self._append_jsonl, path, masked_payload)
            await asyncio.to_thread(self._append_jsonl, unmasked_path, unmasked_payload)

    async def _audit(self, event: str, change: dict[str, Any]) -> None:
        path = Path(self.settings.source_write_audit_file)
        if not path.is_absolute():
            path = Path.cwd() / path
        path.parent.mkdir(parents=True, exist_ok=True)
        audit_change = self.public_change(change)
        if audit_change.get("second_confirmation_code"):
            audit_change["second_confirmation_code"] = "<redacted>"
        if audit_change.get("popup_approval_token"):
            audit_change["popup_approval_token"] = "<redacted>"
        timestamp = utc_now().isoformat()
        masked_payload = {
            "timestamp": timestamp,
            "event": event,
            "change": sanitize(audit_change),
        }
        unmasked_path = Path(self.settings.source_write_audit_unmasked_file)
        if not unmasked_path.is_absolute():
            unmasked_path = Path.cwd() / unmasked_path
        unmasked_path.parent.mkdir(parents=True, exist_ok=True)
        unmasked_payload = {
            "timestamp": timestamp,
            "event": event,
            "change": self._redact_audit_secrets(audit_change),
        }
        async with self._audit_lock:
            await asyncio.to_thread(self._append_jsonl, path, masked_payload)
            await asyncio.to_thread(self._append_jsonl, unmasked_path, unmasked_payload)

    @classmethod
    def _redact_audit_secrets(cls, value: Any, key_hint: str | None = None) -> Any:
        secret_markers = (
            "password", "secret", "token", "api_key", "apikey", "authorization",
            "connection_string", "connectionstring", "confirmation_code",
        )
        normalized_key = str(key_hint or "").casefold().replace("-", "_")
        if any(marker in normalized_key for marker in secret_markers):
            return "<redacted>"
        if isinstance(value, dict):
            return {key: cls._redact_audit_secrets(item, str(key)) for key, item in value.items()}
        if isinstance(value, list):
            return [cls._redact_audit_secrets(item, key_hint) for item in value]
        if isinstance(value, tuple):
            return [cls._redact_audit_secrets(item, key_hint) for item in value]
        return value

    @staticmethod
    def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")

    @staticmethod
    def public_change(change: dict[str, Any]) -> dict[str, Any]:
        value = dict(change)
        # The code must be shown after confirmation 1, but never retained in audit output by callers who sanitize it.
        return value

    # --------------------------------- Replies ---------------------------------
    def _plan_reply(self, change: dict[str, Any]) -> str:
        business = change.get("approval_policy") == "business_chat" or change.get("actor_role") == "Business"
        required = 1 if business else 2
        lines = [
            "## Source update preview",
            f"- **Change ID:** `{change['change_id']}`",
            f"- **Source:** {change['source_label']}",
            f"- **Field:** {change['field']}",
            f"- **New value:** `{change['new_value']}`",
            f"- **Eligible targets:** {change['target_count']}",
            f"- **Write mode:** {change['write_mode']}",
            "",
            "### Suggested change",
        ]
        if change.get("derived_from_analysis"):
            lines[1:1] = [
                f"- **Analysis run:** `{change.get('analysis_run_id') or 'current session'}`",
                f"- **Correction:** {change.get('change_set_index', 1)} of {change.get('change_set_total', 1)}",
                f"- **Truth/reference source:** {_source_label(SourceSystem(change['truth_source'])) if change.get('truth_source') in {s.value for s in SourceSystem} else (change.get('truth_source') or 'rule-derived evidence')}",
            ]
        if change.get("literal_value_request"):
            request_kind = "Manual override" if change.get("manual_override") else "Explicit literal value"
            lines[1:1] = [f"- **Request type:** {request_kind}"]
            if change.get("manual_override"):
                lines[2:2] = [f"- **Deterministic recommendation:** `{change.get('deterministic_recommended_value')}` (explicit value differs)"]
        for target in change["targets"][:25]:
            lines.append(f"- `{target['email']}`: `{target.get('before')}` → `{target.get('after')}`")
        lines.extend(["", "No data has been changed yet."])
        if change.get("approval_policy") == "business_chat":
            lines.append("Reply **yes** (or **do the change**) to provide the required Business chat approval and execute this exact reviewed plan.")
        else:
            lines.append("Reply **yes** (or **do the change**) to record chat approval 1. You will then complete approval 2 in the final-review popup before execution.")
        lines.append("Reply **no** or **cancel** to stop the pending change.")
        if change["write_mode"] == "dry_run":
            lines.append("This user profile is in **Dry Run**. The operation will validate the exact governed change without modifying Rewards DB or CrowdTwist.")
        elif change["write_mode"] == "disabled":
            lines.append("Live source writes are globally disabled by the operator kill switch. No source record can be modified until that global mode is changed.")
        remaining = int(change.get("remaining_suggested_changes") or 0)
        if remaining:
            lines.append(f"{remaining} additional suggested change(s) remain and will require a separate reviewed plan.")
        return "\n".join(lines)

    def _execution_sequence_reply(self, change: dict[str, Any]) -> str:
        reply = self._execution_reply(change)
        next_change = change.get("next_change")
        if isinstance(next_change, dict):
            reply += "\n\n---\n\n## Next analyzed correction is ready\n" + self._plan_reply(next_change)
        elif isinstance(change.get("next_change_error"), dict):
            reply += (
                "\n\nThe remaining analyzed corrections were not auto-planned because: "
                + str(change["next_change_error"].get("message") or "unknown error")
            )
        return reply

    @staticmethod
    def _confirm_two_reply(change: dict[str, Any]) -> str:
        return "\n".join([
            "## Chat approval accepted — final popup approval required",
            f"- **Change ID:** `{change['change_id']}`",
            f"- **Source:** {change['source_label']}",
            f"- **Targets:** {change['target_count']}",
            f"- **Field:** {change['field']}",
            f"- **New value:** `{change['new_value']}`",
            "",
            "Use **Review final approval** below. The popup shows every target and before/after value.",
            "The source is re-read immediately before execution. Any value drift aborts the entire request.",
            "A second chat yes is intentionally not accepted. Reply **no** or **cancel** to stop this pending change.",
        ])

    @staticmethod
    def _popup_required_reply(change: dict[str, Any]) -> str:
        return "\n".join([
            "## Final approval must be completed in the popup",
            f"Change `{change['change_id']}` already has chat approval 1 of 2.",
            "Select **Review final approval** on the change card, verify the source, targets, field, before/after values and write mode, then approve in the popup.",
            "No update was executed from this chat message.",
        ])

    @staticmethod
    def _execution_reply(change: dict[str, Any]) -> str:
        status = change["status"]
        success = sum(1 for item in change.get("results") or [] if item.get("success"))
        if change.get("required_confirmation_count") == 1:
            approval_label = "chat"
        else:
            approval_label = "chat + popup"
        lines = [
            f"## Source change result — {status}",
            f"- **Change ID:** `{change['change_id']}`",
            f"- **Source:** {change['source_label']}",
            f"- **Field:** {change.get('field')}",
            f"- **Requested value:** `{change.get('new_value')}`",
            f"- **Write mode:** {change['write_mode']}",
            f"- **Execution authorization:** {change.get('confirmation_count', 0)}/{change.get('required_confirmation_count', 1)} ({approval_label})",
            f"- **Successful targets:** {success}/{change['target_count']}",
        ]
        if change.get("manual_override"):
            lines.append(f"- **Manual override:** Yes — deterministic recommendation was `{change.get('deterministic_recommended_value')}`")
        lines.append("")
        if status == "DRY_RUN_COMPLETED":
            lines.append("The execution request and all precondition checks succeeded, but this user profile is in **Dry Run**, so no Rewards DB or CrowdTwist record was modified.")
        elif status == "ABORTED_PRECONDITION_CHANGED":
            lines.append("The operation was aborted because at least one source value changed after the preview. No update was attempted.")
        elif status.startswith("BLOCKED"):
            lines.append(str((change.get("results") or [{}])[0].get("message") or "The operation was blocked."))
        else:
            lines.append("A read-after-write verification was performed for every attempted target.")
        for item in (change.get("results") or [])[:25]:
            email = item.get("email") or "target"
            label = "SUCCESS" if item.get("success") else ("DRY RUN" if item.get("dry_run") else "FAILED")
            detail = item.get("code") or ("verified" if item.get("verified") else "")
            lines.append(f"- `{email}` — **{label}** {detail}")
        post_write = change.get("post_write_analysis") or {}
        post_status = str(post_write.get("status") or "").upper()
        if post_status == "COMPLETED":
            lines.extend([
                "",
                "### Post-write cross-source verification",
                f"Fresh run `{post_write.get('run_id') or 'unknown'}` is now active. "
                f"Remaining mismatches: {post_write.get('mismatch_count', 0)}; "
                f"missing records: {post_write.get('missing_record_count', 0)}.",
            ])
        elif post_status == "FAILED":
            lines.extend([
                "",
                "The source write succeeded, but the automatic post-write cross-source analysis could not complete. "
                "Run Analyze again to refresh the comparison; the verified write result is unchanged.",
            ])
        return "\n".join(lines)

    @staticmethod
    def _cancel_reply(change: dict[str, Any]) -> str:
        return f"Change `{change['change_id']}` was cancelled. No source data was changed."

    @staticmethod
    def _selection_reply(source: SourceSystem, query: str, candidates: list[str], *, write: bool) -> str:
        operation = "prepare the update" if write else f"run the {_source_label(source)} API"
        lines = [
            f"## Multiple emails match **{query or 'the request'}**",
            f"I found **{len(candidates)}** matching email(s) in this session.",
            f"Reply **all** to {operation} for every match, or provide one specific email.",
            "",
        ] + [f"- `{email}`" for email in candidates[:25]]
        if len(candidates) > 25:
            lines.append(f"- …and {len(candidates)-25} more")
        if write:
            lines.append("Selecting targets does not change data. The selected preview executes only after an authorized explicit execution command.")
        return "\n".join(lines)

    @staticmethod
    def _selection_reply_sources(sources: list[SourceSystem], query: str, candidates: list[str]) -> str:
        labels = ", ".join(_source_label(source) for source in sources)
        lines = [
            f"## Multiple emails match **{query or 'the request'}**",
            f"I found **{len(candidates)}** matching email(s) in the active session.",
            f"Reply **all** to run **{labels}** for every match, or provide one specific email.",
            "",
        ] + [f"- `{email}`" for email in candidates[:25]]
        if len(candidates) > 25:
            lines.append(f"- …and {len(candidates)-25} more")
        if SourceSystem.REWARDS_DB in sources:
            lines.extend([
                "",
                "**Rewards DB note:** Rewards DB needs a Profile ID or CrowdTwist ID. The agent will resolve those identifiers from CPS and CrowdTwist for each selected email, then query ProfileId first and CrowdTwistID second.",
            ])
        return "\n".join(lines)

    @staticmethod
    def _identifier_required_reply_sources(sources: list[SourceSystem], query: str) -> str:
        labels = ", ".join(_source_label(source) for source in sources)
        return (
            f"## {labels} lookup needs a member identifier\n"
            f"I could not resolve **{query or 'that member'}** from this chat session. "
            "Provide an exact email, Profile ID, or CrowdTwist ID. The agent will extract linked identifiers "
            "and continue across CPS, Rewards DB, and CrowdTwist automatically."
        )

    @staticmethod
    def _email_required_reply_sources(sources: list[SourceSystem], query: str) -> str:
        labels = ", ".join(_source_label(source) for source in sources)
        dependency = ""
        if SourceSystem.REWARDS_DB in sources:
            dependency = " Rewards DB will use CPS/CrowdTwist identifier resolution automatically once an email is selected."
        return (
            f"## {labels} lookup needs an exact email or a known session match\n"
            f"I could not resolve **{query or 'that name'}** from the active individual result, completed bulk result, or chat history. "
            f"Provide one exact email, paste a list, or complete a bulk analysis containing the matching users first.{dependency}"
        )

    @staticmethod
    def _email_required_reply(source: SourceSystem, query: str, *, write: bool) -> str:
        action = "update" if write else "lookup"
        return (
            f"## {_source_label(source)} {action} needs an exact email\n"
            f"I could not resolve **{query or 'that name'}** to an email from the active individual result, completed bulk result, or chat history. "
            "Provide one exact email, paste a list, or complete a bulk analysis containing the matching users first."
        )

    @staticmethod
    def _change_details_help(source: SourceSystem, error: str) -> str:
        return (
            f"## {_source_label(source)} update needs more detail\n"
            f"{error}\n\n"
            "Use a request such as: **Update CrowdTwist country to US for user@example.com** or "
            "**Set Rewards DB active status to true for user@example.com**. "
            "The agent will show the current value and execute only from an authorized explicit update command, with source recheck and read-after-write verification."
        )

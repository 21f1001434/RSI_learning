from __future__ import annotations
import httpx

import asyncio

import json
import secrets
import uuid
from datetime import datetime
from typing import Any

from fastapi import APIRouter, BackgroundTasks, Depends, File, Header, HTTPException, Path as ApiPath, Query, Request, UploadFile, status
from fastapi.responses import JSONResponse, PlainTextResponse, Response

from ..batch import parse_email_list
from ..models import SearchType, SourceName
from ..reporting import render_html_report
from ..settings import Settings
from .batch_jobs import BatchJobManager, BatchJobNotFound
from .chat_service import ChatService
from .file_security import JOB_ID_PATTERN, RUN_ID_PATTERN, safe_download_filename
from .dependencies import (
    get_api_settings,
    get_batch_jobs,
    get_chat_service,
    get_runs,
    get_sessions,
    get_source_operations,
    verify_internal_key,
)
from .run_store import RunNotFound, RunStore, UnmaskedReportUnavailable
from .schemas import (
    ApiEnvelope,
    ApiError,
    BatchEmailsRequest,
    ChatRequest,
    CpsSourceQueryRequest,
    SourceQueryRequest,
    SourceChangePlanRequest,
    SourceChangeConfirmationRequest,
    SourceChangePopupOpenedRequest,
    SourceChangeCancelRequest,
    SpreadsheetSourceChangeImportRequest,
    IndividualAnalysisRequest,
    SessionCreateRequest,
    PayloadValidationRequest,
    UseCasePlanRequest,
)
from .session_store import InMemorySessionStore, SessionNotFound
from .source_operations import SourceOperationError, SourceOperationService
from ..connectors.cps import CPSConnector
from ..identifier_input import IdentifierMatch, remember_identifier, remember_identity_bundle, resolve_identifier
from src.app_settings import APP_VERSION

router = APIRouter(dependencies=[Depends(verify_internal_key)])


def request_id(request: Request) -> str:
    return getattr(request.state, "request_id", "REQ-" + uuid.uuid4().hex[:12].upper())


def ok(request: Request, data: Any, status_code: int = 200) -> JSONResponse:
    payload = ApiEnvelope(success=True, data=data, request_id=request_id(request)).model_dump(mode="json")
    return JSONResponse(payload, status_code=status_code)


def fail(request: Request, code: str, message: str, status_code: int, details: dict[str, Any] | None = None) -> JSONResponse:
    payload = ApiEnvelope(
        success=False,
        error=ApiError(code=code, message=message, details=details or {}),
        request_id=request_id(request),
    ).model_dump(mode="json")
    return JSONResponse(payload, status_code=status_code)


async def live(request: Request) -> JSONResponse:
    return ok(request, {"status": "LIVE", "service": "agentic-data-disparity-api", "version": APP_VERSION, "layout": "src-template"})


async def ready(request: Request, deep: bool = Query(False)) -> JSONResponse:
    settings: Settings = request.app.state.engine_settings
    data: dict[str, Any] = {
        "status": "READY",
        "version": APP_VERSION,
        "layout": "src-template",
        "service_status": "ONLINE",
        "live": True,
        "available": True,
        "write_status": "READY",
        "dell_aia_provider": settings.dell_aia_provider,
        "dell_aia_model": settings.dell_aia_model,
        "mcp_required": settings.require_mcp_tool_use,
        "source_configuration_complete": settings.live_source_credentials_complete,
        "spring_config_error": settings.spring_config_error or None,
        "source_write_mode": settings.source_write_mode,
        "source_write_authorization": "profile-governed approval workflow",
        "legacy_confirmation_endpoints": "available for compatibility",
        "profile_write_policy": {
            "admin": "chat approval + final popup; live unless globally disabled",
            "business": "single chat approval; per-user live or dry-run profile",
            "technical": "chat approval + final popup; per-user live or dry-run profile",
            "customer_support": "chat approval + final popup; per-user live or dry-run profile",
            "cps": "always read-only from Agentic AI",
        },
        "adaptive_memory": await request.app.state.adaptive_memory.status(),
        "source_write_capabilities": {
            "cps": {"read": True, "live_update_configured": False, "write_contract": "read-only"},
            "rewards_db": {
                "read": True,
                "live_update_configured": bool(settings.utility_service_base_url),
                "write_contract": "dotnet-manual-bridge/RewardsDbOperationsV2",
            },
            "crowd_twist": {
                "read": True,
                "live_update_configured": bool(settings.utility_service_base_url),
                "write_contract": "dotnet-manual-bridge/LoyaltyServiceProviderV3",
                "read_endpoint_family": "Ext2/read",
                "write_endpoint_family": "manual-tab-shared-contract",
            },
        },
    }
    bridge_configured = bool(settings.utility_service_base_url)
    data["write_ready"] = settings.source_write_mode != "live"
    if settings.source_write_mode == "live":
        # Keep overall service availability separate from governed-write readiness.
        # For live mode, validate the real .NET manual-update bridge when it is
        # available. During startup the Python API may come up before .NET; that
        # is a write-capability warning, not a service outage.
        if not bridge_configured:
            data["write_status"] = "DEGRADED"
            data["write_ready"] = False
            data["manual_write_bridge_error"] = (
                "Governed live writes require the loopback Dell Utility manual-update bridge. "
                "Start Dell Utility on 127.0.0.1:49690 or use the supplied start scripts."
            )
        else:
            bridge_url = str(settings.utility_service_base_url).rstrip("/") + "/api/internal/source-write/capabilities"
            try:
                async with httpx.AsyncClient(timeout=2.5) as client:
                    bridge_headers = {}
                    if settings.utility_service_internal_key:
                        bridge_headers["X-Internal-API-Key"] = str(settings.utility_service_internal_key)
                    bridge_response = await client.get(bridge_url, headers=bridge_headers)
                bridge_payload = bridge_response.json() if bridge_response.content else {}
                bridge_ok = bool(
                    bridge_response.is_success
                    and bridge_payload.get("success") is True
                    and bridge_payload.get("rewardsDb", {}).get("configured") is True
                    and bridge_payload.get("crowdTwist", {}).get("configured") is True
                )
                data["write_ready"] = bridge_ok
                data["write_status"] = "READY" if bridge_ok else "DEGRADED"
                data["write_bridge_reachable"] = bool(bridge_response.is_success)
                data["source_write_capabilities"]["rewards_db"]["live_update_configured"] = bool(
                    bridge_payload.get("rewardsDb", {}).get("configured") is True
                )
                data["source_write_capabilities"]["crowd_twist"]["live_update_configured"] = bool(
                    bridge_payload.get("crowdTwist", {}).get("configured") is True
                )
                if not bridge_ok:
                    data["manual_write_bridge_error"] = (
                        "The .NET manual-update bridge is reachable but one or more governed write services are not configured."
                    )
            except Exception as exc:
                data["write_status"] = "DEGRADED"
                data["write_ready"] = False
                data["write_bridge_reachable"] = False
                data["manual_write_bridge_error"] = (
                    "The Agentic API is online, but the .NET manual-update bridge is not reachable yet. "
                    f"{type(exc).__name__}: {exc}"
                )

    if deep:
        from ..agents.model_client import probe_dell_aia_runtime

        probe = await probe_dell_aia_runtime(settings)
        data["dell_aia_probe"] = probe
        if not probe.get("ok"):
            data["status"] = "DEGRADED"
    return ok(request, data)


@router.post("/sessions", tags=["Sessions"], status_code=201)
async def create_session(
    request: Request,
    body: SessionCreateRequest,
    sessions: InMemorySessionStore = Depends(get_sessions),
) -> JSONResponse:
    state = await sessions.create(body.metadata)
    return ok(request, sessions.view(state, include_messages=True).model_dump(mode="json"), status_code=201)


@router.get("/sessions/{session_id}", tags=["Sessions"])
async def get_session(
    request: Request,
    session_id: str,
    include_messages: bool = Query(True),
    sessions: InMemorySessionStore = Depends(get_sessions),
) -> JSONResponse:
    try:
        state = await sessions.get(session_id)
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The session does not exist or has expired.", 404)
    return ok(request, sessions.view(state, include_messages=include_messages).model_dump(mode="json"))


@router.delete("/sessions/{session_id}", tags=["Sessions"])
async def delete_session(
    request: Request,
    session_id: str,
    sessions: InMemorySessionStore = Depends(get_sessions),
) -> JSONResponse:
    deleted = await sessions.delete(session_id)
    if not deleted:
        return fail(request, "SESSION_NOT_FOUND", "The session does not exist or has expired.", 404)
    return ok(request, {"session_id": session_id, "deleted": True})


@router.post("/sessions/{session_id}/reset", tags=["Sessions"])
async def reset_session(
    request: Request,
    session_id: str,
    sessions: InMemorySessionStore = Depends(get_sessions),
) -> JSONResponse:
    try:
        state = await sessions.clear(session_id)
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The session does not exist or has expired.", 404)
    return ok(request, sessions.view(state, include_messages=True).model_dump(mode="json"))


@router.get("/sessions/{session_id}/active-batch", tags=["Sessions", "Batch"])
async def get_session_active_batch(
    request: Request,
    session_id: str,
    sessions: InMemorySessionStore = Depends(get_sessions),
    jobs: BatchJobManager = Depends(get_batch_jobs),
) -> JSONResponse:
    try:
        state = await sessions.get(session_id)
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The session does not exist or has expired.", 404)
    if not state.active_batch_id:
        return ok(request, {
            "active_context": state.active_context,
            "job": None,
            "summary": None,
            "message": "No bulk analysis is attached to this session.",
        })
    try:
        job = await jobs.get(state.active_batch_id)
        job_view = jobs.view(job, str(request.base_url).rstrip("/")).model_dump(mode="json")
        summary = job.summary or state.last_batch_summary
    except BatchJobNotFound:
        job_view = {
            "job_id": state.active_batch_id,
            "status": state.facts.get("active_batch_status", "UNKNOWN"),
            "phase": state.facts.get("active_batch_phase", "UNKNOWN"),
            "batch_id": state.active_batch_result_id,
        }
        summary = state.last_batch_summary
    return ok(request, {
        "active_context": state.active_context,
        "job": job_view,
        "summary": summary,
        "has_summary": summary is not None,
    })


@router.post("/chat", tags=["Chat"])
async def chat(
    request: Request,
    body: ChatRequest,
    service: ChatService = Depends(get_chat_service),
) -> JSONResponse:
    try:
        result = await service.handle(body, str(request.base_url).rstrip("/"))
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The session does not exist or has expired.", 404)
    return ok(request, result.model_dump(mode="json"))


@router.get("/memory/status", tags=["Adaptive Memory"])
async def adaptive_memory_status(request: Request) -> JSONResponse:
    """Return PII-safe execution-memory and bounded RSI telemetry."""
    data = await request.app.state.adaptive_memory.status()
    return ok(request, data)


@router.get("/audit-trail", tags=["Audit"])
async def get_audit_trail(
    request: Request,
    limit: int = Query(100, ge=1, le=1000),
    source: str | None = Query(None),
    status: str | None = Query(None),
    actor: str | None = Query(None),
    action: str | None = Query(None),
    from_utc: datetime | None = Query(None),
    to_utc: datetime | None = Query(None),
    include_sensitive: bool = Query(False, description="Internal .NET proxy only: return the canonical unmasked audit stream."),
    x_internal_api_key: str | None = Header(None, alias="X-Internal-API-Key"),
    service: SourceOperationService = Depends(get_source_operations),
    api_settings = Depends(get_api_settings),
) -> JSONResponse:
    if include_sensitive:
        configured = api_settings.api_internal_key
        if not configured or not x_internal_api_key or not secrets.compare_digest(configured, x_internal_api_key):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Sensitive audit access requires the configured internal API key.")
    data = await service.list_audit(
        limit=limit, source=source, status=status, actor=actor, action=action,
        from_utc=from_utc, to_utc=to_utc, include_sensitive=include_sensitive,
    )
    return ok(request, data)


@router.post("/source-operations/query", tags=["Source Operations"])
async def query_source(
    request: Request,
    body: SourceQueryRequest,
    sessions: InMemorySessionStore = Depends(get_sessions),
    service: SourceOperationService = Depends(get_source_operations),
) -> JSONResponse:
    state = None
    if body.session_id:
        try:
            state = await sessions.get(body.session_id)
        except SessionNotFound:
            return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)

    identifiers: list[IdentifierMatch] = []
    if body.search_type is not None and body.search_value:
        identifiers.append(IdentifierMatch(body.search_type, body.search_value, 0, "api_request"))
    identifiers.extend(
        IdentifierMatch(SearchType.EMAIL, email, index, "api_request")
        for index, email in enumerate(body.emails)
    )
    if not identifiers and body.query:
        resolved = resolve_identifier(body.query, state.facts if state is not None else {})
        if resolved is not None:
            identifiers.append(resolved)
        elif state is not None:
            identifiers.extend(
                IdentifierMatch(SearchType.EMAIL, email, index, "session_match")
                for index, email in enumerate(service.find_candidate_emails(state, body.query))
            )
    if not identifiers:
        return fail(
            request,
            "SOURCE_IDENTIFIER_REQUIRED",
            "Provide an email, Profile ID, CrowdTwist ID, or a session query that resolves to one of those identifiers.",
            400,
        )
    try:
        result = await service.query_identifiers(body.sources, identifiers, body.max_parallel)
        if state is not None:
            remember_identifier(state.facts, identifiers[0])
            member = (result.get("members") or [{}])[0]
            remember_identity_bundle(state.facts, member.get("resolved_identity") or {})
        await service.audit_agentic_activity(
            "SOURCE_QUERY_COMPLETED",
            {
                "session_id": body.session_id,
                "actor": (state.metadata.get("actor") if state is not None else None) or "Unknown user",
                "actor_email": state.metadata.get("actor_email") if state is not None else None,
                "source": "Agentic AI · " + " + ".join(result.get("source_labels") or []),
                "action": "Agentic source retrieval",
                "status": "COMPLETED",
                "target": f"{identifiers[0].label}: {identifiers[0].value}",
                "search_type": identifiers[0].search_type.value,
                "search_value": identifiers[0].value,
                "verification": f"{result.get('requested_member_count', 0)} member(s) processed",
                "details": {
                    "sources": result.get("source_labels"),
                    "duration_ms": result.get("duration_ms"),
                    "resolved_identity": ((result.get("members") or [{}])[0].get("resolved_identity") or {}),
                },
            },
        )
    except SourceOperationError as exc:
        return fail(request, exc.code, str(exc), exc.status_code, exc.details)
    return ok(request, service.project_query_for_role(result, body.actor_role))


@router.post("/source-operations/changes/plan", tags=["Source Operations"])
async def plan_source_change(
    request: Request,
    body: SourceChangePlanRequest,
    service: SourceOperationService = Depends(get_source_operations),
) -> JSONResponse:
    try:
        service.require_agentic_write_role(body.actor_role)
        await service.apply_session_write_policy(
            body.session_id, actor_role=body.actor_role, actor_dry_run_enabled=body.actor_dry_run_enabled
        )
        change = await service.plan_change(
            session_id=body.session_id, source=body.source, operation=body.operation,
            emails=body.emails, field=body.field, new_value=body.new_value, reason=body.reason,
            actor=body.actor, actor_email=body.actor_email,
        )
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    except SourceOperationError as exc:
        return fail(request, exc.code, str(exc), exc.status_code, exc.details)
    return ok(request, {"change": service.public_change(change)}, status_code=201)


@router.get("/source-operations/changes/{change_id}", tags=["Source Operations"])
async def get_source_change(
    request: Request,
    change_id: str,
    session_id: str = Query(...),
    service: SourceOperationService = Depends(get_source_operations),
) -> JSONResponse:
    try:
        change = await service.get_change(session_id, change_id.upper())
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    except SourceOperationError as exc:
        return fail(request, exc.code, str(exc), exc.status_code, exc.details)
    return ok(request, {"change": change})


@router.post("/source-operations/changes/{change_id}/confirm-1", tags=["Source Operations"])
async def confirm_source_change_first(
    request: Request,
    change_id: str,
    body: SourceChangeConfirmationRequest,
    service: SourceOperationService = Depends(get_source_operations),
) -> JSONResponse:
    try:
        service.require_agentic_write_role(body.actor_role)
        await service.apply_session_write_policy(
            body.session_id, actor_role=body.actor_role, actor_dry_run_enabled=body.actor_dry_run_enabled
        )
        change = await service.confirm_first(
            body.session_id, change_id.upper(), body.confirmation_text,
            body.actor, body.actor_email, approval_channel=body.approval_channel,
            actor_role=body.actor_role,
        )
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    except SourceOperationError as exc:
        return fail(request, exc.code, str(exc), exc.status_code, exc.details)
    return ok(request, {"change": service.public_change(change)})


@router.post("/source-operations/changes/{change_id}/popup-opened", tags=["Source Operations"])
async def source_change_popup_opened(
    request: Request,
    change_id: str,
    body: SourceChangePopupOpenedRequest,
    service: SourceOperationService = Depends(get_source_operations),
) -> JSONResponse:
    try:
        service.require_agentic_write_role(body.actor_role)
        await service.apply_session_write_policy(
            body.session_id, actor_role=body.actor_role, actor_dry_run_enabled=body.actor_dry_run_enabled
        )
        change = await service.mark_popup_opened(
            body.session_id, change_id.upper(), body.actor, body.actor_email
        )
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    except SourceOperationError as exc:
        return fail(request, exc.code, str(exc), exc.status_code, exc.details)
    return ok(request, {"change": service.public_change(change)})


@router.post("/source-operations/changes/{change_id}/confirm-2", tags=["Source Operations"])
async def confirm_source_change_second(
    request: Request,
    change_id: str,
    body: SourceChangeConfirmationRequest,
    service: SourceOperationService = Depends(get_source_operations),
    chat_service: ChatService = Depends(get_chat_service),
) -> JSONResponse:
    try:
        service.require_agentic_write_role(body.actor_role)
        await service.apply_session_write_policy(
            body.session_id, actor_role=body.actor_role, actor_dry_run_enabled=body.actor_dry_run_enabled
        )
        change = await service.confirm_second(
            body.session_id, change_id.upper(), body.confirmation_text,
            body.actor, body.actor_email, approval_channel=body.approval_channel,
            popup_acknowledged=body.popup_acknowledged,
            audit_acknowledged=body.audit_acknowledged,
            plan_digest=body.plan_digest,
            popup_token=body.popup_token,
        )
        refreshed = await chat_service.refresh_after_source_change(body.session_id, change)
        if refreshed is not None:
            change["post_write_analysis"] = chat_service._post_write_analysis_summary(refreshed)
        await service.append_popup_execution_message(body.session_id, change)
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    except SourceOperationError as exc:
        return fail(request, exc.code, str(exc), exc.status_code, exc.details)
    return ok(request, {"change": service.public_change(change)})


@router.post("/source-operations/changes/{change_id}/cancel", tags=["Source Operations"])
async def cancel_source_change(
    request: Request,
    change_id: str,
    body: SourceChangeCancelRequest,
    service: SourceOperationService = Depends(get_source_operations),
) -> JSONResponse:
    try:
        service.require_agentic_write_role(body.actor_role)
        await service.apply_session_write_policy(
            body.session_id, actor_role=body.actor_role, actor_dry_run_enabled=body.actor_dry_run_enabled
        )
        change = await service.cancel_change(body.session_id, change_id.upper(), body.reason, body.actor, body.actor_email)
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    except SourceOperationError as exc:
        return fail(request, exc.code, str(exc), exc.status_code, exc.details)
    return ok(request, {"change": service.public_change(change)})


@router.post("/source-operations/spreadsheet-import", tags=["Source Operations"])
async def import_source_change_spreadsheet(
    request: Request,
    body: SpreadsheetSourceChangeImportRequest,
    sessions: InMemorySessionStore = Depends(get_sessions),
    service: SourceOperationService = Depends(get_source_operations),
    chat_service: ChatService = Depends(get_chat_service),
) -> JSONResponse:
    try:
        state = await sessions.get(body.session_id)
        service.require_agentic_write_role(body.actor_role)
        await service.apply_session_write_policy(
            body.session_id,
            actor_role=body.actor_role,
            actor_dry_run_enabled=body.actor_dry_run_enabled,
        )
        if body.actor:
            state.metadata["actor"] = body.actor
        if body.actor_email:
            state.metadata["actor_email"] = body.actor_email
        await sessions.append(
            body.session_id,
            role="user",
            content=f"{body.instruction}\n\n[Excel workbook: {body.file_name} · {len(body.rows)} update row(s)]",
            metadata={"intent": "spreadsheet_update_upload", "file_name": body.file_name, "row_count": len(body.rows)},
        )
        result = await service.import_spreadsheet_changes(
            session_id=body.session_id,
            file_name=body.file_name,
            instruction=body.instruction,
            rows=[row.model_dump(mode="python") for row in body.rows],
            actor=body.actor,
            actor_email=body.actor_email,
            actor_role=body.actor_role,
            actor_dry_run_enabled=body.actor_dry_run_enabled,
        )

        post_write: list[dict[str, Any]] = []
        if result.get("completed_changes"):
            refreshed_emails: set[str] = set()
            for change in result.get("completed_changes") or []:
                status_value = str(change.get("status") or "").upper()
                if status_value not in {"COMPLETED", "PARTIAL"}:
                    continue
                target_email = str(((change.get("targets") or [{}])[0]).get("email") or "").strip()
                if not target_email or target_email.casefold() in refreshed_emails:
                    continue
                refreshed_emails.add(target_email.casefold())
                refreshed = await chat_service.refresh_after_source_change(body.session_id, change)
                if refreshed is not None:
                    post_write.append(chat_service._post_write_analysis_summary(refreshed))
            result["post_write_analyses"] = post_write

        reply = service.spreadsheet_update_reply(result)
        spreadsheet_intent = (
            "spreadsheet_updates_executed" if result.get("execution_completed")
            else "spreadsheet_updates_awaiting_final_approval" if result.get("requires_final_approval")
            else "spreadsheet_updates_validated"
        )
        assistant = await sessions.append(
            body.session_id,
            role="assistant",
            content=reply,
            metadata={
                "intent": spreadsheet_intent,
                "structuredData": {"spreadsheet_update": result},
            },
        )
        return ok(request, {
            "session_id": body.session_id,
            "message_id": assistant.message_id,
            "reply": reply,
            "intent": spreadsheet_intent,
            "active_run_id": state.active_run_id,
            "active_batch_id": state.active_batch_id,
            "structured_data": {"spreadsheet_update": result},
            "memory": {
                "active_context": state.active_context,
                "pending_spreadsheet_changes": len(state.facts.get("pending_spreadsheet_change_ids") or []),
            },
        })
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    except SourceOperationError as exc:
        return fail(request, exc.code, str(exc), exc.status_code, exc.details)


@router.post("/source-operations/cps/query", tags=["Source Operations"])
async def query_cps_source(
    request: Request,
    body: CpsSourceQueryRequest,
    sessions: InMemorySessionStore = Depends(get_sessions),
) -> JSONResponse:
    emails = list(body.emails)
    if not emails and body.session_id and body.query:
        try:
            state = await sessions.get(body.session_id)
        except SessionNotFound:
            return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
        folded = body.query.casefold().strip()
        for member in (state.last_batch_summary or {}).get("members") or []:
            if isinstance(member, dict):
                email = str(member.get("email") or "").strip()
                if email and folded in email.casefold():
                    emails.append(email)
    seen: set[str] = set()
    emails = [e for e in emails if not (e.casefold() in seen or seen.add(e.casefold()))]
    if not emails:
        return fail(request, "CPS_EMAIL_REQUIRED", "Provide one or more exact emails, or a session/query that resolves to emails.", 400)
    connector = CPSConnector(request.app.state.engine_settings)
    semaphore = asyncio.Semaphore(body.max_parallel)
    async def run_one(email: str) -> dict[str, Any]:
        async with semaphore:
            record = await connector.fetch(SearchType.EMAIL, email)
        return {"email": email, "record": record.model_dump(mode="json")}
    results = await asyncio.gather(*(run_one(email) for email in emails))
    return ok(request, {
        "operation": "direct.cps.get_account",
        "requested_count": len(results),
        "results": results,
        "read_only": True,
    })


@router.post("/analysis/individual", tags=["Analysis"])
async def analyze_individual(
    request: Request,
    body: IndividualAnalysisRequest,
    sessions: InMemorySessionStore = Depends(get_sessions),
    runs: RunStore = Depends(get_runs),
    service: SourceOperationService = Depends(get_source_operations),
) -> JSONResponse:
    settings: Settings = request.app.state.engine_settings
    state = None
    actor = body.actor or "Unknown user"
    actor_email = body.actor_email
    actor_role = body.actor_role
    actor_id = body.actor_id
    try:
        if body.session_id:
            state = await sessions.get(body.session_id)
            actor = state.metadata.get("actor") or state.metadata.get("actor_username") or actor
            actor_email = state.metadata.get("actor_email") or actor_email
            actor_role = state.metadata.get("actor_role") or actor_role
            actor_id = state.metadata.get("actor_id") or actor_id
        target = f"{body.search_type.value}: {body.search_value}"
        await service.audit_agentic_activity(
            "ANALYSIS_STARTED",
            {
                "session_id": body.session_id,
                "actor": actor,
                "actor_email": actor_email,
                "actor_role": actor_role,
                "actor_id": actor_id,
                "source": "Agentic AI",
                "action": "Cross-source disparity analysis",
                "status": "STARTED",
                "target": target,
                "search_type": body.search_type.value,
                "search_value": body.search_value,
                "verification": "Analysis queued",
            },
        )
        from ..agents.orchestrator import AgenticOrchestrator

        report_obj = await AgenticOrchestrator(settings, ai_semaphore=request.app.state.ai_semaphore).run(
            body.search_type, body.search_value
        )
        report = report_obj.model_dump(mode="json")
        await runs.put(report)
        if body.session_id:
            await sessions.set_active_report(body.session_id, report)
            assert state is not None
            remember_identifier(state.facts, IdentifierMatch(body.search_type, body.search_value, -1, "analysis_api"))
            remember_identity_bundle(state.facts, ChatService._identity_bundle_from_report(report))
        identity_bundle = ChatService._identity_bundle_from_report(report)
        source_status = report.get("source_status") or {}
        found_sources = [
            source for source, source_state in source_status.items()
            if isinstance(source_state, dict) and source_state.get("data_found")
        ]
        judge = report.get("judge_result") or {}
        await service.audit_agentic_activity(
            "ANALYSIS_COMPLETED",
            {
                "session_id": body.session_id,
                "run_id": report.get("run_id"),
                "actor": actor,
                "actor_email": actor_email,
                "actor_role": actor_role,
                "actor_id": actor_id,
                "source": "Agentic AI",
                "action": "Cross-source disparity analysis",
                "status": "COMPLETED",
                "target": target,
                "search_type": body.search_type.value,
                "search_value": body.search_value,
                "verification": (
                    f"{len(found_sources)}/3 source record(s); "
                    f"coverage {report.get('analysis_completeness') or 'UNKNOWN'}; "
                    f"judge {judge.get('verdict') or judge.get('status') or 'NOT_RUN'}"
                ),
                "details": {
                    "resolved_identity": identity_bundle,
                    "sourceStatus": source_status,
                    "mismatchCount": report.get("mismatch_count", 0),
                    "missingCount": report.get("missing_count", 0),
                    "invalidFormatCount": report.get("invalid_format_count", 0),
                    "unverifiableCount": report.get("unverifiable_count", 0),
                    "analysisCompleteness": report.get("analysis_completeness"),
                    "judge": judge,
                },
            },
        )
        response_report = await runs.view(report["run_id"], masked=body.mask_report_values)
        if not body.include_raw_source_data:
            response_report.pop("records", None)
        data: dict[str, Any] = {"report": response_report}
        if body.include_html:
            data["html"] = render_html_report(report, mask_pii=body.mask_report_values)
        response = ok(request, data)
        response.headers["X-Report-Privacy"] = "masked" if body.mask_report_values else "unmasked"
        return response
    except SessionNotFound:
        return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    except Exception as exc:
        await service.audit_agentic_activity(
            "ANALYSIS_FAILED",
            {
                "session_id": body.session_id,
                "actor": actor,
                "actor_email": actor_email,
                "actor_role": actor_role,
                "actor_id": actor_id,
                "source": "Agentic AI",
                "action": "Cross-source disparity analysis",
                "status": "FAILED",
                "target": f"{body.search_type.value}: {body.search_value}",
                "search_type": body.search_type.value,
                "search_value": body.search_value,
                "reason": str(exc),
                "verification": type(exc).__name__,
            },
        )
        return fail(request, "ANALYSIS_FAILED", str(exc), 500, {"type": type(exc).__name__})


@router.get("/analysis/{run_id}", tags=["Analysis"])
async def get_analysis(
    request: Request,
    run_id: str = ApiPath(..., pattern=RUN_ID_PATTERN),
    masked: bool = Query(False, description="Return original source values by default; set true for a tokenized view."),
    runs: RunStore = Depends(get_runs),
) -> JSONResponse:
    try:
        report = await runs.view(run_id, masked=masked)
    except RunNotFound:
        return fail(request, "RUN_NOT_FOUND", "No report exists for the supplied run ID.", 404)
    except UnmaskedReportUnavailable as exc:
        return fail(request, "UNMASKED_REPORT_UNAVAILABLE", str(exc), 409, {"rerun_required": True})
    response = ok(request, report)
    response.headers["X-Report-Privacy"] = "masked" if masked else "unmasked"
    return response


@router.get("/analysis/{run_id}/report.html", tags=["Reports"])
async def get_html_report(
    run_id: str = ApiPath(..., pattern=RUN_ID_PATTERN),
    masked: bool = Query(False, description="Return original source values by default; set true to tokenize member PII and source identifiers."),
    runs: RunStore = Depends(get_runs),
) -> Response:
    try:
        # Always render from structured report data. ``render_html_report`` HTML-escapes
        # every dynamic value, while the strict path ID prevents user input from
        # becoming a filesystem selector. A restrictive CSP provides defense in depth.
        report = await runs.view(run_id, masked=masked)
        document = render_html_report(report, mask_pii=False)
    except RunNotFound:
        raise HTTPException(status_code=404, detail="Run not found")
    except UnmaskedReportUnavailable as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return Response(
        content=document.encode("utf-8"),
        media_type="text/html",
        headers={
            "X-Report-Privacy": "masked" if masked else "unmasked",
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer",
            "Content-Security-Policy": (
                "default-src 'none'; style-src 'unsafe-inline'; img-src data:; "
                "font-src 'none'; script-src 'none'; object-src 'none'; frame-src 'none'; "
                "base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
            ),
        },
    )


@router.get("/analysis/{run_id}/report.json", tags=["Reports"])
async def get_json_report(
    run_id: str = ApiPath(..., pattern=RUN_ID_PATTERN),
    masked: bool = Query(False, description="Return original source values by default; set true to tokenize member PII and source identifiers."),
    runs: RunStore = Depends(get_runs),
) -> Response:
    try:
        report = await runs.view(run_id, masked=masked)
    except RunNotFound:
        raise HTTPException(status_code=404, detail="Run not found")
    except UnmaskedReportUnavailable as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    filename = safe_download_filename(f"{run_id}_{'MASKED' if masked else 'UNMASKED'}.json")
    payload = json.dumps(report, indent=2, ensure_ascii=False, default=str).encode("utf-8")
    return Response(
        content=payload,
        media_type="application/json",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-Report-Privacy": "masked" if masked else "unmasked",
            "X-Content-Type-Options": "nosniff",
        },
    )


@router.post("/batches", tags=["Batch"], status_code=202)
async def create_batch_json(
    request: Request,
    body: BatchEmailsRequest,
    sessions: InMemorySessionStore = Depends(get_sessions),
    jobs: BatchJobManager = Depends(get_batch_jobs),
) -> JSONResponse:
    payload = ("\n".join(body.emails) + "\n").encode("utf-8")
    parsed = parse_email_list("emails.txt", payload)
    if not parsed.get("emails"):
        return fail(request, "NO_VALID_EMAILS", "The request did not contain any valid email addresses.", 400, parsed)
    if body.session_id:
        try:
            await sessions.get(body.session_id)
        except SessionNotFound:
            return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    job = await jobs.create(
        parsed,
        max_parallel=body.max_parallel,
        max_parallel_ai=body.max_parallel_ai,
        include_group_ai=body.include_group_ai,
        session_id=body.session_id,
    )
    return ok(request, jobs.view(job, str(request.base_url).rstrip("/")).model_dump(mode="json"), status_code=202)


@router.post("/batches/upload", tags=["Batch"], status_code=202)
async def create_batch_upload(
    request: Request,
    file: UploadFile = File(...),
    session_id: str | None = Query(None),
    max_parallel: int | None = Query(None, ge=1, le=8),
    max_parallel_ai: int | None = Query(None, ge=1, le=2),
    include_group_ai: bool = Query(True),
    sessions: InMemorySessionStore = Depends(get_sessions),
    jobs: BatchJobManager = Depends(get_batch_jobs),
) -> JSONResponse:
    filename = file.filename or "emails.txt"
    if not filename.lower().endswith((".txt", ".csv")):
        return fail(request, "UNSUPPORTED_FILE_TYPE", "Only TXT and CSV email lists are supported.", 415)
    payload = await file.read()
    parsed = parse_email_list(filename, payload)
    if not parsed.get("emails"):
        return fail(request, "NO_VALID_EMAILS", "The uploaded file did not contain any valid email addresses.", 400, parsed)
    if session_id:
        try:
            await sessions.get(session_id)
        except SessionNotFound:
            return fail(request, "SESSION_NOT_FOUND", "The supplied session does not exist or has expired.", 404)
    job = await jobs.create(
        parsed,
        max_parallel=max_parallel,
        max_parallel_ai=max_parallel_ai,
        include_group_ai=include_group_ai,
        session_id=session_id,
    )
    return ok(request, jobs.view(job, str(request.base_url).rstrip("/")).model_dump(mode="json"), status_code=202)


@router.get("/batches/{job_id}", tags=["Batch"])
async def get_batch_job(request: Request, job_id: str = ApiPath(..., pattern=JOB_ID_PATTERN), jobs: BatchJobManager = Depends(get_batch_jobs)) -> JSONResponse:
    try:
        job = await jobs.get(job_id)
    except BatchJobNotFound:
        return fail(request, "BATCH_JOB_NOT_FOUND", "No batch job exists for the supplied ID.", 404)
    return ok(request, jobs.view(job, str(request.base_url).rstrip("/")).model_dump(mode="json"))


@router.get("/batches/{job_id}/summary", tags=["Batch"])
async def get_batch_summary(request: Request, job_id: str = ApiPath(..., pattern=JOB_ID_PATTERN), jobs: BatchJobManager = Depends(get_batch_jobs)) -> JSONResponse:
    try:
        job = await jobs.get(job_id)
    except BatchJobNotFound:
        return fail(request, "BATCH_JOB_NOT_FOUND", "No batch job exists for the supplied ID.", 404)
    if job.summary is None:
        return fail(request, "BATCH_NOT_COMPLETED", "The batch summary is not available yet.", 409, {"status": job.status.value, "phase": job.phase})
    return ok(request, job.summary)


@router.get("/batches/{job_id}/download", tags=["Batch"])
async def download_batch(
    job_id: str = ApiPath(..., pattern=JOB_ID_PATTERN),
    masked: bool = Query(False, description="Download the unmasked package by default; set true for the tokenized shareable package."),
    jobs: BatchJobManager = Depends(get_batch_jobs),
) -> Response:
    try:
        payload, raw_filename = await jobs.download_payload(job_id, masked=masked)
    except BatchJobNotFound:
        raise HTTPException(status_code=404, detail="Batch job not found")
    except (FileNotFoundError, ValueError):
        raise HTTPException(status_code=409, detail="Batch report package is not available yet")
    filename = safe_download_filename(raw_filename)
    return Response(
        content=payload,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-Report-Privacy": "masked" if masked else "unmasked",
            "X-Content-Type-Options": "nosniff",
        },
    )


@router.get("/knowledge/catalog", tags=["API Knowledge"])
async def get_api_catalog(request: Request) -> JSONResponse:
    from ..api_knowledge import ApiKnowledgeBase

    knowledge = ApiKnowledgeBase()
    return ok(request, {
        "summary": knowledge.summary(),
        # Stable snake_case contract for API clients and the .NET integration.
        "operations": knowledge.canonical_operation_rows(),
        # Backward-compatible human-readable rows for existing tables.
        "operation_rows": knowledge.operation_rows(),
        "safe_catalog": knowledge.safe_catalog_for_agent(),
    })


@router.get("/knowledge/operations/{operation_id:path}", tags=["API Knowledge"])
async def get_api_operation(request: Request, operation_id: str) -> JSONResponse:
    from ..api_knowledge import ApiKnowledgeBase

    knowledge = ApiKnowledgeBase()
    try:
        operation = knowledge.get_operation(operation_id)
    except KeyError:
        return fail(request, "OPERATION_NOT_FOUND", "The API operation is not present in the catalog.", 404)
    return ok(request, {
        "operation": operation,
        "request_schema": knowledge.resolved_request_schema(operation_id),
        "response_schema": knowledge.resolved_response_schema(operation_id),
    })


@router.post("/knowledge/validate-payload", tags=["API Knowledge"])
async def validate_api_payload(request: Request, body: PayloadValidationRequest) -> JSONResponse:
    from ..api_knowledge import ApiKnowledgeBase

    knowledge = ApiKnowledgeBase()
    try:
        result = knowledge.validate_payload(body.operation_id, body.payload)
    except KeyError:
        return fail(request, "OPERATION_NOT_FOUND", "The API operation is not present in the catalog.", 404)
    return ok(request, {
        "operation_id": body.operation_id,
        "valid": result.valid,
        "errors": result.errors,
        "normalized_payload": result.normalized_payload,
    })


@router.get("/analysis/{run_id}/use-cases", tags=["Use Cases"])
async def get_use_cases(request: Request, run_id: str = ApiPath(..., pattern=RUN_ID_PATTERN), runs: RunStore = Depends(get_runs)) -> JSONResponse:
    from ..use_cases import UseCaseEngine

    try:
        report = await runs.get(run_id)
    except RunNotFound:
        return fail(request, "RUN_NOT_FOUND", "No report exists for the supplied run ID.", 404)
    recommendations = [item.model_dump(mode="json") for item in UseCaseEngine().recommend(report)]
    return ok(request, {"run_id": run_id, "recommendations": recommendations})


@router.post("/use-cases/plan", tags=["Use Cases"])
async def compile_use_case_plan(request: Request, body: UseCasePlanRequest, runs: RunStore = Depends(get_runs)) -> JSONResponse:
    from ..use_cases import UseCaseEngine

    try:
        report = await runs.get(body.run_id)
    except RunNotFound:
        return fail(request, "RUN_NOT_FOUND", "No report exists for the supplied run ID.", 404)
    try:
        deterministic = UseCaseEngine().compile_plan(body.use_case_id, report).model_dump(mode="json")
    except KeyError:
        return fail(request, "USE_CASE_NOT_FOUND", "The requested use case is not defined.", 404)
    if not body.include_dell_aia_review:
        return ok(request, {"deterministic_plan": deterministic})
    try:
        search_type = SearchType(str(report.get("search_type")))
        search_value = str(report.get("search_value") or "")
        from ..agents.orchestrator import AgenticOrchestrator

        reviewed = await AgenticOrchestrator(request.app.state.engine_settings, ai_semaphore=request.app.state.ai_semaphore).compile_selected_use_case(
            body.use_case_id, search_type, search_value
        )
        return ok(request, {"deterministic_plan": deterministic, "dell_aia_reviewed_plan": reviewed})
    except Exception as exc:
        return ok(request, {
            "deterministic_plan": deterministic,
            "dell_aia_reviewed_plan": None,
            "review_status": "FAILED",
            "review_error": {"type": type(exc).__name__, "message": str(exc)},
        })


# Compatibility endpoints for the existing .NET AI Analysis page.
@router.get("/legacy/AIAnalysis/analyze", tags=["Legacy Compatibility"])
async def legacy_analyze(
    request: Request,
    searchType: str,
    searchValue: str,
    runs: RunStore = Depends(get_runs),
) -> JSONResponse:
    aliases = {"profileId": "profileid", "crowdtwistId": "crowdtwistid", "crowdTwistId": "crowdtwistid"}
    normalized = aliases.get(searchType, searchType).lower()
    try:
        search_type = SearchType(normalized)
    except ValueError:
        return JSONResponse({"success": False, "message": "Unsupported searchType"}, status_code=400)
    try:
        from ..agents.orchestrator import AgenticOrchestrator

        report_obj = await AgenticOrchestrator(request.app.state.engine_settings, ai_semaphore=request.app.state.ai_semaphore).run(search_type, searchValue)
        report = report_obj.model_dump(mode="json")
        await runs.put(report)
        return JSONResponse({"success": True, "data": report})
    except Exception as exc:
        return JSONResponse({"success": False, "message": str(exc)}, status_code=500)

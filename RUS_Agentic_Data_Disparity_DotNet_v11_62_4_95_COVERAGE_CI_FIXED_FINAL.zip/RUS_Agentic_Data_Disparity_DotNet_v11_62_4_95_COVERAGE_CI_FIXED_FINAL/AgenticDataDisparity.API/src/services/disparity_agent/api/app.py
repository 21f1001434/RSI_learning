from __future__ import annotations

import asyncio
import uuid
from contextlib import asynccontextmanager, suppress

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from ..concurrency_policy import DELL_AIA_PARALLEL_WORKERS
from ..settings import load_settings
from ..memory import get_adaptive_memory
from .batch_jobs import BatchJobManager
from .chat_service import ChatService
from .config import load_api_settings
from .dependencies import verify_internal_key
from .routes import router
from .run_store import RunStore
from .session_store import InMemorySessionStore
from .source_operations import SourceOperationService


@asynccontextmanager
async def lifespan(app: FastAPI):
    api_settings = app.state.api_settings
    await app.state.adaptive_memory.initialize()

    async def cleanup_loop() -> None:
        while True:
            await asyncio.sleep(max(10, api_settings.session_cleanup_interval_seconds))
            await app.state.sessions.cleanup()

    task = asyncio.create_task(cleanup_loop())
    app.state.cleanup_task = task
    yield
    task.cancel()
    with suppress(asyncio.CancelledError):
        await task


def create_app() -> FastAPI:
    engine_settings = load_settings()
    api_settings = load_api_settings()
    app = FastAPI(
        title=api_settings.api_title,
        version=api_settings.api_version,
        description=(
            "API surface for individual and bulk Dell Rewards data-disparity analysis, "
            "Dell AIA grounded chat, session memory, reports, batch jobs, multi-source reads, and governed verified source updates."
        ),
        docs_url="/docs" if api_settings.api_docs_enabled else None,
        redoc_url="/redoc" if api_settings.api_docs_enabled else None,
        openapi_url="/openapi.json" if api_settings.api_docs_enabled else None,
        root_path=api_settings.api_root_path,
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=api_settings.cors_origin_list,
        allow_credentials=False,
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-Internal-API-Key", "X-Request-ID"],
    )

    app.state.engine_settings = engine_settings
    app.state.api_settings = api_settings
    app.state.ai_semaphore = asyncio.Semaphore(DELL_AIA_PARALLEL_WORKERS)
    app.state.adaptive_memory = get_adaptive_memory(engine_settings)
    app.state.sessions = InMemorySessionStore(
        ttl_minutes=api_settings.session_ttl_minutes,
        max_messages=api_settings.session_max_messages,
        max_sessions=api_settings.session_max_count,
    )
    app.state.runs = RunStore(engine_settings)
    app.state.source_operations = SourceOperationService(engine_settings, app.state.sessions)
    app.state.batch_jobs = BatchJobManager(
        engine_settings, api_settings, app.state.sessions, audit_service=app.state.source_operations
    )
    app.state.chat_service = ChatService(
        settings=engine_settings,
        api_settings=api_settings,
        sessions=app.state.sessions,
        runs=app.state.runs,
        ai_semaphore=app.state.ai_semaphore,
        batch_jobs=app.state.batch_jobs,
        source_operations=app.state.source_operations,
    )

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        incoming = request.headers.get("X-Request-ID")
        request.state.request_id = incoming or "REQ-" + uuid.uuid4().hex[:12].upper()
        try:
            response = await call_next(request)
        except Exception as exc:
            response = JSONResponse(
                {
                    "success": False,
                    "data": None,
                    "error": {"code": "UNHANDLED_ERROR", "message": str(exc), "details": {"type": type(exc).__name__}},
                    "request_id": request.state.request_id,
                },
                status_code=500,
            )
        response.headers["X-Request-ID"] = request.state.request_id
        response.headers["Cache-Control"] = "no-store"
        return response

    app.include_router(router, prefix="/api/v1")

    # Exact route alias expected by the current static .NET UI.
    from .routes import legacy_analyze
    app.add_api_route(
        "/api/AIAnalysis/analyze", legacy_analyze, methods=["GET"], include_in_schema=False,
        dependencies=[Depends(verify_internal_key)],
    )

    @app.get("/", include_in_schema=False)
    async def root():
        return {
            "service": api_settings.api_title,
            "version": api_settings.api_version,
            "docs": "/docs" if api_settings.api_docs_enabled else None,
            "health": "/api/v1/health/live",
        }

    return app


app = create_app()

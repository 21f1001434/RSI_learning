from __future__ import annotations

import asyncio
import csv
import html
import io
import json
import re
import uuid
import zipfile
from collections import Counter
from datetime import datetime, timezone
from statistics import mean, median
from time import perf_counter
from typing import Any, Iterable

from .models import SearchType
from .concurrency_policy import DELL_AIA_PARALLEL_WORKERS, INCLUDE_GROUPED_DELL_AIA, SOURCE_PARALLEL_WORKERS
from .judgment import canonical_judge_verdict, enforce_judge_on_report_dict
from .reporting import render_html_report
from .security import sanitize
from .settings import Settings

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
EMAIL_COLUMNS = {"email", "emailaddress", "email_address", "e-mail", "mail", "useremail", "user_email"}


def _duration_ms(value: Any) -> int:
    try:
        return max(0, int(float(value or 0)))
    except (TypeError, ValueError):
        return 0


def _timing_stats(values: Iterable[Any]) -> dict[str, Any]:
    nums = [_duration_ms(v) for v in values if v not in (None, "")]
    if not nums:
        return {"count": 0, "min_ms": 0, "avg_ms": 0, "median_ms": 0, "max_ms": 0}
    return {
        "count": len(nums),
        "min_ms": min(nums),
        "avg_ms": int(mean(nums)),
        "median_ms": int(median(nums)),
        "max_ms": max(nums),
    }


def _clean_email(value: Any) -> str:
    return str(value or "").strip().strip('"').strip("'")


def _same_email(left: Any, right: Any) -> bool:
    return _clean_email(left).casefold() == _clean_email(right).casefold()


def parse_email_list(filename: str, payload: bytes) -> dict[str, Any]:
    """Parse TXT/CSV email lists and ignore true duplicate emails.

    Deduplication is conservative: values are trimmed and compared case-insensitively.
    Only the same canonical email is ignored after its first occurrence; different
    email addresses always remain separate member analyses. ``input_index`` keeps the
    original row number so the batch audit can show where a duplicate came from.
    """
    text = payload.decode("utf-8-sig", errors="replace")
    suffix = (filename.rsplit(".", 1)[-1].lower() if "." in filename else "txt")
    raw_values: list[str] = []

    if suffix == "csv":
        sample = text[:4096]
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        rows = list(csv.reader(io.StringIO(text), dialect))
        if rows:
            header = [re.sub(r"[^a-z0-9_-]", "", cell.strip().lower()) for cell in rows[0]]
            email_idx = next((i for i, name in enumerate(header) if name in EMAIL_COLUMNS), None)
            start = 1 if email_idx is not None else 0
            if email_idx is None:
                email_idx = 0
            for row in rows[start:]:
                if row and email_idx < len(row):
                    raw_values.append(_clean_email(row[email_idx]))
    else:
        raw_values = [_clean_email(v) for v in re.split(r"[\r\n,;\t]+", text)]

    raw_values = [v for v in raw_values if v]
    valid: list[str] = []
    invalid: list[str] = []
    duplicates: list[str] = []
    duplicate_rows: list[dict[str, Any]] = []
    entries: list[dict[str, Any]] = []
    seen: dict[str, dict[str, Any]] = {}

    for input_index, value in enumerate(raw_values, 1):
        if not EMAIL_RE.match(value):
            invalid.append(value)
            continue

        canonical = value.casefold()
        first = seen.get(canonical)
        if first is not None:
            duplicates.append(value)
            duplicate_rows.append({
                "input_index": input_index,
                "email": value,
                "duplicate_of_input_index": first["input_index"],
                "duplicate_of_email": first["email"],
            })
            continue

        entry = {
            "input_index": input_index,
            "record_id": f"ROW-{input_index:04d}",
            "email": value,
        }
        seen[canonical] = entry
        valid.append(value)
        entries.append(entry)

    return {
        "filename": filename,
        "submitted_count": len(raw_values),
        "emails": valid,
        "entries": entries,
        "valid_transaction_count": len(valid),
        "unique_valid_count": len(valid),
        "deduplication_applied": True,
        "duplicates": duplicates,
        "duplicate_rows": duplicate_rows,
        "duplicate_count": len(duplicates),
        "invalid": invalid,
        "invalid_count": len(invalid),
    }


def _source_state(report: dict[str, Any], key: str) -> str:
    status = (report.get("source_status") or {}).get(key) or {}
    if status.get("data_found"):
        return "FOUND"
    if status.get("connected"):
        return "NO_RECORD"
    return "UNAVAILABLE"


def _member_row(
    email: str,
    report: dict[str, Any] | None,
    error: str | None = None,
    *,
    record_id: str = "",
    input_index: int | None = None,
    item_timings: dict[str, Any] | None = None,
) -> dict[str, Any]:
    item_timings = item_timings or {}
    if not report:
        return {
            "record_id": record_id,
            "input_index": input_index,
            "email": email,
            "run_id": "—",
            "status": "FAILED",
            "completeness": "FAILED",
            "mismatches": 0,
            "missing_attributes": 0,
            "missing_records": 0,
            "deferred": 0,
            "format_issues": 0,
            "unverifiable": 0,
            "exact_changes": 0,
            "manual_review": 0,
            "cps": "FAILED",
            "rewards_db": "FAILED",
            "crowd_twist": "FAILED",
            "dell_aia_execution": "FAILED",
            "judge_verdict": "NOT_RUN",
            "final_content_status": "NOT_AVAILABLE",
            "dell_aia": "FAILED",
            "mcp": "FAILED",
            "total_time_ms": _duration_ms(item_timings.get("batch_member_end_to_end_ms")),
            "data_collection_ms": _duration_ms(item_timings.get("data_collection_agent_ms")),
            "analysis_agent_ms": _duration_ms(item_timings.get("analysis_agent_ms")),
            "judge_agent_ms": _duration_ms(item_timings.get("judge_agent_ms")),
            "error": error or "Unknown failure",
        }
    timings = report.get("timings") or {}
    total_time = (
        timings.get("batch_member_end_to_end_ms")
        or timings.get("end_to_end_ms")
        or timings.get("total_processing_ms")
        or 0
    )
    return {
        "record_id": record_id,
        "input_index": input_index,
        "email": email,
        "run_id": report.get("run_id"),
        "status": "COMPLETED",
        "completeness": report.get("analysis_completeness"),
        "mismatches": int(report.get("mismatch_count") or 0),
        "missing_attributes": int(report.get("missing_count") or 0),
        "missing_records": int(report.get("missing_record_count") or 0),
        "deferred": int(report.get("deferred_attribute_count") or 0),
        "format_issues": int(report.get("invalid_format_count") or 0),
        "unverifiable": int(report.get("unverifiable_count") or 0),
        "exact_changes": int(report.get("actionable_suggestion_count") or 0),
        "manual_review": int(report.get("manual_review_count") or 0),
        "cps": _source_state(report, "cps"),
        "rewards_db": _source_state(report, "rewards_db"),
        "crowd_twist": _source_state(report, "crowd_twist"),
        "dell_aia_execution": ((report.get("ai_execution") or {}).get("status") or "UNKNOWN"),
        "judge_verdict": canonical_judge_verdict(
            ((report.get("judge_result") or {}).get("verdict") or (report.get("judge_result") or {}).get("status"))
        ),
        "final_content_status": ((report.get("ai_execution") or {}).get("final_content_status") or (report.get("judge_result") or {}).get("content_disposition") or "UNKNOWN"),
        # Backward-compatible alias: this is execution status, not judge approval.
        "dell_aia": ((report.get("ai_execution") or {}).get("status") or "UNKNOWN"),
        "mcp": ((report.get("mcp_execution") or {}).get("status") or "UNKNOWN"),
        "total_time_ms": _duration_ms(total_time),
        "data_collection_ms": _duration_ms(timings.get("data_collection_agent_ms")),
        "source_collection_ms": _duration_ms(timings.get("source_collection_wall_ms")),
        "analysis_agent_ms": _duration_ms(timings.get("analysis_agent_ms")),
        "judge_agent_ms": _duration_ms(timings.get("judge_agent_ms")),
        "dell_aia_queue_wait_ms": _duration_ms(timings.get("dell_aia_queue_wait_ms")),
        "error": "",
    }


def _percentage(numerator: Any, denominator: Any) -> float:
    try:
        num = float(numerator or 0)
        den = float(denominator or 0)
    except Exception:
        return 0.0
    return round((num / den) * 100.0, 1) if den > 0 else 0.0


def build_batch_insights(summary: dict[str, Any]) -> dict[str, Any]:
    """Derive ambiguity-free portfolio statistics from a batch summary.

    All user percentages use unique processed members as the denominator. Attribute
    counts remain attribute/user counts, while source gaps remain source-member-record
    counts. The returned structure is safe to expose through the API and chat.
    """
    processing = summary.get("processing") or {}
    population = summary.get("population_metrics") or {}
    totals = summary.get("totals") or {}
    unique_members = int(
        population.get("unique_members_processed")
        or processing.get("completed_count")
        or 0
    )

    issue_user_counts = dict(summary.get("attribute_issue_user_counts") or {})
    if not issue_user_counts:
        for item in summary.get("top_issue_attributes") or []:
            if isinstance(item, dict):
                label = str(item.get("attribute") or item.get("label") or item.get("name") or "").strip()
                if label:
                    issue_user_counts[label] = int(item.get("count") or item.get("users") or 0)

    ranked_attributes = [
        {
            "attribute": name,
            "users_affected": int(count or 0),
            "percentage_of_members": _percentage(count, unique_members),
        }
        for name, count in sorted(
            issue_user_counts.items(),
            key=lambda pair: (-int(pair[1] or 0), str(pair[0]).casefold()),
        )
    ]
    majority_count = ranked_attributes[0]["users_affected"] if ranked_attributes else 0
    majority_attributes = [
        item for item in ranked_attributes if item["users_affected"] == majority_count and majority_count > 0
    ]

    attribute_status = summary.get("attribute_status_counts") or {}
    mismatch_attributes = []
    format_review_attributes = []
    unverifiable_attributes = []
    for name, statuses in attribute_status.items():
        statuses = statuses or {}
        mismatch = int(statuses.get("MISMATCH") or 0)
        format_review = sum(
            int(statuses.get(key) or 0)
            for key in ("INVALID_FORMAT", "TRUTH_FORMAT_INVALID", "COUNTRY_REVIEW_REQUIRED")
        )
        unverifiable = int(statuses.get("UNVERIFIABLE") or 0)
        if mismatch:
            mismatch_attributes.append({"attribute": name, "count": mismatch})
        if format_review:
            format_review_attributes.append({"attribute": name, "count": format_review})
        if unverifiable:
            unverifiable_attributes.append({"attribute": name, "count": unverifiable})
    mismatch_attributes.sort(key=lambda item: (-item["count"], str(item["attribute"]).casefold()))
    format_review_attributes.sort(key=lambda item: (-item["count"], str(item["attribute"]).casefold()))
    unverifiable_attributes.sort(key=lambda item: (-item["count"], str(item["attribute"]).casefold()))

    issue_status_counts = {
        str(key): int(value or 0)
        for key, value in (summary.get("issue_status_counts") or {}).items()
        if str(key).upper() != "MATCH"
    }
    ranked_issue_statuses = [
        {"status": key, "attribute_items": value}
        for key, value in sorted(issue_status_counts.items(), key=lambda pair: (-pair[1], pair[0]))
    ]

    source_metrics = summary.get("source_member_record_metrics") or {}
    by_source = source_metrics.get("by_source") or summary.get("source_record_status") or {}
    source_coverage = []
    for source, counts in by_source.items():
        counts = counts or {}
        found = int(counts.get("FOUND") or 0)
        missing = int(counts.get("NO_RECORD") or 0)
        unavailable = int(counts.get("UNAVAILABLE") or 0)
        source_coverage.append({
            "source": source,
            "found_members": found,
            "missing_member_records": missing,
            "unavailable_members": unavailable,
            "coverage_percentage": _percentage(found, unique_members),
        })
    source_coverage.sort(key=lambda item: (-item["missing_member_records"], str(item["source"])))
    most_missing_count = source_coverage[0]["missing_member_records"] if source_coverage else 0
    most_missing_sources = [
        item for item in source_coverage
        if item["missing_member_records"] == most_missing_count and most_missing_count > 0
    ]

    judge_outcomes = summary.get("judge_outcomes") or {}
    judge_distribution = [
        {
            "verdict": verdict,
            "members": int(count or 0),
            "percentage_of_members": _percentage(count, unique_members),
        }
        for verdict, count in sorted(judge_outcomes.items(), key=lambda pair: (-int(pair[1] or 0), str(pair[0])))
    ]

    suggestion_targets = [
        {"target": target, "guidance_items": int(count or 0)}
        for target, count in sorted(
            (summary.get("suggestion_target_counts") or {}).items(),
            key=lambda pair: (-int(pair[1] or 0), str(pair[0])),
        )
    ]

    return {
        "unique_members": unique_members,
        "completion": {
            "completed_members": int(processing.get("completed_count") or 0),
            "failed_members": int(processing.get("failed_count") or 0),
            "completion_percentage": _percentage(processing.get("completed_count"), unique_members),
        },
        "population_percentages": {
            "members_with_any_issue": _percentage(population.get("users_with_any_issue"), unique_members),
            "members_with_exact_changes": _percentage(population.get("users_with_exact_changes"), unique_members),
            "members_requiring_manual_review": _percentage(population.get("users_requiring_manual_review"), unique_members),
            "members_with_missing_source_record": _percentage(population.get("users_with_any_missing_source_record"), unique_members),
        },
        "majority_issue": {
            "basis": "unique members affected by an attribute with any non-MATCH verdict",
            "attributes": majority_attributes,
            "is_tie": len(majority_attributes) > 1,
        },
        "ranked_issue_attributes": ranked_attributes,
        "ranked_non_match_statuses": ranked_issue_statuses,
        "top_mismatch_attributes": mismatch_attributes,
        "top_format_or_review_attributes": format_review_attributes,
        "top_unverifiable_attributes": unverifiable_attributes,
        "source_coverage": source_coverage,
        "source_with_most_missing_records": most_missing_sources,
        "judge_distribution": judge_distribution,
        "suggestion_target_distribution": suggestion_targets,
        "finding_item_totals": {
            "mismatches": int(totals.get("mismatches") or 0),
            "missing_source_member_records": int(totals.get("missing_records") or 0),
            "deferred_attribute_verdicts": int(totals.get("deferred") or 0),
            "format_issue_items": int(totals.get("format_issues") or 0),
            "unverifiable_attribute_items": int(totals.get("unverifiable") or 0),
            "exact_change_items": int(totals.get("exact_changes") or 0),
            "manual_review_items": int(totals.get("manual_review") or 0),
        },
    }


def _deterministic_group_overview(aggregate: dict[str, Any]) -> str:
    proc = aggregate.get("processing") or {}
    population = aggregate.get("population_metrics") or {}
    source_metrics = aggregate.get("source_member_record_metrics") or {}
    guidance = aggregate.get("guidance_metrics") or {}
    insights = aggregate.get("batch_insights") or build_batch_insights(aggregate)
    majority = (insights.get("majority_issue") or {}).get("attributes") or []
    majority_text = ""
    if majority:
        names = ", ".join(str(item.get("attribute")) for item in majority)
        count = majority[0].get("users_affected", 0)
        pct = majority[0].get("percentage_of_members", 0)
        majority_text = f" The most widespread issue attribute(s) by members affected are {names}, impacting {count} member(s) ({pct}%)."
    return (
        f"Processed {proc.get('completed_count', 0)} unique member(s). "
        f"{population.get('users_with_any_issue', 0)} member(s) have at least one non-match finding; "
        f"{population.get('users_with_exact_changes', 0)} have one or more exact corrections and "
        f"{population.get('users_requiring_manual_review', 0)} require one or more manual-review actions. "
        f"Across source/member pairs, {source_metrics.get('missing_source_member_records_total', 0)} member record(s) were not found; "
        f"this is distinct from {aggregate.get('totals', {}).get('deferred', 0)} attribute-level deferred verdict(s). "
        f"The report contains {guidance.get('exact_change_items', 0)} exact-change item(s) and "
        f"{guidance.get('manual_review_items', 0)} manual-review item(s)."
        + majority_text
    )


def _group_ai_input(aggregate: dict[str, Any]) -> dict[str, Any]:
    """Build a typed, ambiguity-free payload for the portfolio Dell AIA agent."""
    return {
        "metric_semantics": {
            "member": "One unique processed email/member.",
            "source_member_record": "One member record in one source system; one member can contribute more than one missing source record.",
            "attribute_verdict": "One attribute outcome for one member; never describe this as a member or record count.",
            "guidance_item": "One suggestion/action row; a member can have multiple guidance items.",
            "judge_outcome": "The independent judge's content verdict for one member report.",
        },
        "population_metrics": aggregate.get("population_metrics") or {},
        "source_member_record_metrics": aggregate.get("source_member_record_metrics") or {},
        "attribute_status_counts": aggregate.get("attribute_status_counts") or {},
        "attribute_issue_user_counts": aggregate.get("attribute_issue_user_counts") or {},
        "guidance_metrics": aggregate.get("guidance_metrics") or {},
        "judge_outcomes": aggregate.get("judge_outcomes") or {},
        "batch_insights": aggregate.get("batch_insights") or build_batch_insights(aggregate),
        "processing": {
            key: (aggregate.get("processing") or {}).get(key)
            for key in (
                "completed_count", "failed_count", "full_count", "partial_count",
                "no_authoritative_data_count", "dell_aia_execution_success_count",
                "dell_aia_execution_failed_count", "mcp_success_count", "mcp_failed_count",
            )
        },
        "timings": aggregate.get("timings") or {},
        "authoritative_executive_summary": _deterministic_group_overview(aggregate),
    }


def deterministic_group_analysis(aggregate: dict[str, Any], *, status: str = "DETERMINISTIC") -> dict[str, Any]:
    metrics = _group_ai_input(aggregate)
    attribute_counts = aggregate.get("attribute_issue_user_counts") or {}
    top = sorted(attribute_counts.items(), key=lambda pair: (-int(pair[1]), pair[0]))[:5]
    source = aggregate.get("source_member_record_metrics") or {}
    return {
        "status": status,
        "analysis": {
            "executive_summary": metrics["authoritative_executive_summary"],
            "major_patterns": [
                {"attribute": name, "users_affected": count}
                for name, count in top
            ],
            "priority_actions": [
                "Resolve missing source member records before attempting field-level synchronization.",
                "Apply exact corrections only from deterministic per-attribute truth rules.",
                "Review judge-corrected and judge-rejected member analyses separately from technically successful Dell AIA calls.",
            ],
            "source_health_observations": source.get("by_source") or {},
            "risk_notes": [
                "Member counts, source-record counts, attribute-verdict counts, and guidance-item counts are different units and must not be combined.",
                "No automatic write is performed by this workflow.",
            ],
            "confidence": "HIGH_FOR_DETERMINISTIC_METRICS",
            "authoritative_metrics": metrics,
        },
    }


def aggregate_batch(batch_id: str, parse_result: dict[str, Any], items: list[dict[str, Any]]) -> dict[str, Any]:
    member_rows = [
        _member_row(
            item["email"], item.get("report"), item.get("error"),
            record_id=str(item.get("record_id") or ""),
            input_index=item.get("input_index"),
            item_timings=dict(item.get("timings") or {}),
        )
        for item in items
    ]
    completed = [item for item in items if item.get("report")]
    reports = [item["report"] for item in completed]

    issue_counter: Counter[str] = Counter()
    status_counter: Counter[str] = Counter()
    target_counter: Counter[str] = Counter()
    attribute_status_counts: dict[str, Counter[str]] = {}
    source_record_counter: dict[str, Counter[str]] = {
        "cps": Counter(), "rewards_db": Counter(), "crowd_twist": Counter()
    }
    judge_counter: Counter[str] = Counter()

    users_with_any_issue = 0
    users_with_exact_changes = 0
    users_requiring_manual_review = 0
    users_with_any_missing_source_record = 0
    users_with_any_unavailable_source = 0

    for report in reports:
        member_has_issue = False
        for verdict in report.get("attributes") or []:
            status = str(verdict.get("status") or "UNKNOWN")
            label = str(verdict.get("label") or verdict.get("attribute") or "Unknown")
            status_counter[status] += 1
            attribute_status_counts.setdefault(label, Counter())[status] += 1
            if status != "MATCH":
                member_has_issue = True
                issue_counter[label] += 1
        if member_has_issue:
            users_with_any_issue += 1

        suggestions = list(report.get("suggestions") or [])
        for suggestion in suggestions:
            target = suggestion.get("target_source") or "manual_review"
            target_counter[str(target)] += 1
        if int(report.get("actionable_suggestion_count") or 0) > 0:
            users_with_exact_changes += 1
        if int(report.get("manual_review_count") or 0) > 0:
            users_requiring_manual_review += 1

        member_missing = False
        member_unavailable = False
        for source in source_record_counter:
            state = _source_state(report, source)
            source_record_counter[source][state] += 1
            member_missing = member_missing or state == "NO_RECORD"
            member_unavailable = member_unavailable or state == "UNAVAILABLE"
        if member_missing:
            users_with_any_missing_source_record += 1
        if member_unavailable:
            users_with_any_unavailable_source += 1

        judge = report.get("judge_result") or {}
        judge_counter[canonical_judge_verdict(judge.get("verdict") or judge.get("status"))] += 1

    def total(key: str) -> int:
        return sum(int(r.get(key) or 0) for r in reports)

    completeness = Counter(str(r.get("analysis_completeness") or "UNKNOWN") for r in reports)
    ai_status = Counter(str((r.get("ai_execution") or {}).get("status") or "UNKNOWN") for r in reports)
    mcp_status = Counter(str((r.get("mcp_execution") or {}).get("status") or "UNKNOWN") for r in reports)
    member_timing_stats = {
        "total_time": _timing_stats(row.get("total_time_ms") for row in member_rows if row.get("status") == "COMPLETED"),
        "data_collection": _timing_stats(row.get("data_collection_ms") for row in member_rows if row.get("status") == "COMPLETED"),
        "analysis_agent": _timing_stats(row.get("analysis_agent_ms") for row in member_rows if row.get("status") == "COMPLETED"),
        "judge_agent": _timing_stats(row.get("judge_agent_ms") for row in member_rows if row.get("status") == "COMPLETED"),
        "dell_aia_queue_wait": _timing_stats(row.get("dell_aia_queue_wait_ms") for row in member_rows if row.get("status") == "COMPLETED"),
    }

    source_status = {k: dict(v) for k, v in source_record_counter.items()}
    missing_source_records_total = sum(int(counts.get("NO_RECORD", 0)) for counts in source_status.values())
    unavailable_source_records_total = sum(int(counts.get("UNAVAILABLE", 0)) for counts in source_status.values())

    processing = {
        "completed_count": len(completed),
        "failed_count": len(items) - len(completed),
        "full_count": completeness.get("FULL", 0),
        "partial_count": completeness.get("PARTIAL", 0),
        "no_authoritative_data_count": completeness.get("NO_AUTHORITATIVE_DATA", 0),
        "dell_aia_execution_success_count": ai_status.get("SUCCESS", 0),
        "dell_aia_execution_failed_count": sum(v for k, v in ai_status.items() if k != "SUCCESS"),
        # Backward-compatible aliases. These are execution counts, not content approval counts.
        "dell_aia_success_count": ai_status.get("SUCCESS", 0),
        "dell_aia_failed_count": sum(v for k, v in ai_status.items() if k != "SUCCESS"),
        "mcp_success_count": mcp_status.get("SUCCESS", 0),
        "mcp_failed_count": sum(v for k, v in mcp_status.items() if k != "SUCCESS"),
        "judge_accepted_count": judge_counter.get("ACCEPTED", 0),
        "judge_partial_count": judge_counter.get("PARTIAL", 0),
        "judge_rejected_count": judge_counter.get("REJECTED", 0),
        "judge_review_required_count": judge_counter.get("REVIEW_REQUIRED", 0),
    }

    aggregate = {
        "batch_id": batch_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "input": {
            "filename": parse_result.get("filename"),
            "submitted_count": parse_result.get("submitted_count", 0),
            "valid_transaction_count": parse_result.get("unique_valid_count", parse_result.get("valid_transaction_count", 0)),
            "unique_valid_count": parse_result.get("unique_valid_count", parse_result.get("valid_transaction_count", 0)),
            "deduplication_applied": bool(parse_result.get("deduplication_applied", True)),
            "duplicate_count": int(parse_result.get("duplicate_count", 0) or 0),
            "duplicates": list(parse_result.get("duplicates") or []),
            "duplicate_rows": list(parse_result.get("duplicate_rows") or []),
            "invalid_count": parse_result.get("invalid_count", 0),
            "invalid": parse_result.get("invalid", []),
        },
        "processing": processing,
        "population_metrics": {
            "unique_members_processed": len(reports),
            "users_with_any_issue": users_with_any_issue,
            "users_with_exact_changes": users_with_exact_changes,
            "users_requiring_manual_review": users_requiring_manual_review,
            "users_with_any_missing_source_record": users_with_any_missing_source_record,
            "users_with_any_unavailable_source": users_with_any_unavailable_source,
        },
        "totals": {
            "mismatches": total("mismatch_count"),
            "missing_attributes": total("missing_count"),
            "missing_records": total("missing_record_count"),
            "deferred": total("deferred_attribute_count"),
            "format_issues": total("invalid_format_count"),
            "unverifiable": total("unverifiable_count"),
            "exact_changes": total("actionable_suggestion_count"),
            "manual_review": total("manual_review_count"),
        },
        "guidance_metrics": {
            "exact_change_items": total("actionable_suggestion_count"),
            "manual_review_items": total("manual_review_count"),
            "total_guidance_items": total("actionable_suggestion_count") + total("manual_review_count"),
            "users_with_exact_changes": users_with_exact_changes,
            "users_requiring_manual_review": users_requiring_manual_review,
        },
        "judge_outcomes": dict(judge_counter),
        "issue_status_counts": dict(status_counter),
        "attribute_status_counts": {name: dict(counts) for name, counts in attribute_status_counts.items()},
        "attribute_issue_user_counts": dict(issue_counter),
        "top_issue_attributes": [
            {"attribute": name, "count": count}
            for name, count in issue_counter.most_common(10)
        ],
        "suggestion_target_counts": dict(target_counter),
        "source_record_status": source_status,
        "source_member_record_metrics": {
            "by_source": source_status,
            "missing_source_member_records_total": missing_source_records_total,
            "unavailable_source_member_records_total": unavailable_source_records_total,
            "users_with_any_missing_source_record": users_with_any_missing_source_record,
            "users_with_any_unavailable_source": users_with_any_unavailable_source,
        },
        "members": member_rows,
        "timings": {"member_stats_ms": member_timing_stats},
        "group_ai_analysis": {},
    }
    aggregate["batch_insights"] = build_batch_insights(aggregate)
    aggregate["authoritative_group_summary"] = _deterministic_group_overview(aggregate)
    return aggregate


GROUP_ANALYST_SYSTEM = """You are the Dell Rewards portfolio-level Data Disparity Analyst.
You receive an ambiguity-free typed aggregate derived from individual MCP-grounded member runs.
The supplied deterministic executive summary and authoritative metrics are final.

Critical counting rules:
- A member count is the number of unique processed emails.
- A source-member-record count is one member in one source system; one member can have more than one missing source record.
- An attribute-verdict count is one attribute outcome for one member and MUST NOT be called a member or record count.
- A guidance-item count is the number of suggestion rows and MUST NOT be called a member count.
- A technically successful Dell AIA call is separate from the judge content verdict.

Do not restate numeric counts in free-form prose. Refer to metric names in evidence_refs instead.
Return one JSON object with keys portfolio_interpretation, major_patterns, priority_actions,
source_health_observations, risk_notes, confidence. major_patterns must be a list of objects with
keys title, interpretation, and evidence_refs. Do not invent values, endpoints, causes, or remediation payloads.
"""


async def _group_ai_analysis(settings: Settings, aggregate: dict[str, Any]) -> dict[str, Any]:
    from autogen_agentchat.agents import AssistantAgent
    from .agents.json_utils import extract_json_with_mode, last_substantive_message
    from .agents.model_client import (
        build_model_client, close_model_client, is_rate_limit_error,
        rate_limit_retry_delay, safe_exception_chain,
    )

    model_client = None
    typed_input = _group_ai_input(aggregate)
    deterministic = deterministic_group_analysis(aggregate, status="DETERMINISTIC_BASELINE")
    try:
        model_client = await build_model_client(settings)
        agent = AssistantAgent(
            "batch_portfolio_analyst",
            model_client=model_client,
            system_message=GROUP_ANALYST_SYSTEM,
            reflect_on_tool_use=False,
        )
        task = "Interpret this typed batch aggregate without changing or restating its counts:\n" + json.dumps(typed_input, default=str)
        result = None
        retries = max(0, int(settings.dell_aia_rate_limit_retries))
        for attempt in range(retries + 1):
            try:
                result = await agent.run(task=task)
                break
            except Exception as exc:
                if is_rate_limit_error(exc) and attempt < retries:
                    await asyncio.sleep(rate_limit_retry_delay(settings, attempt, exc))
                    continue
                raise
        assert result is not None
        text = last_substantive_message(getattr(result, "messages", []) or [])
        try:
            parsed = extract_json_with_mode(text)
            ai_view = dict(parsed.value or {})
            analysis = dict(deterministic["analysis"])
            analysis.update({
                "portfolio_interpretation": ai_view.get("portfolio_interpretation") or "Dell AIA reviewed the typed deterministic aggregate.",
                "ai_major_patterns": list(ai_view.get("major_patterns") or []),
                "priority_actions": list(ai_view.get("priority_actions") or analysis.get("priority_actions") or []),
                "ai_source_health_observations": ai_view.get("source_health_observations") or {},
                "risk_notes": list(ai_view.get("risk_notes") or analysis.get("risk_notes") or []),
                "confidence": ai_view.get("confidence") or "HIGH_FOR_DETERMINISTIC_METRICS",
            })
            return {
                "status": "SUCCESS",
                "quality": parsed.mode,
                "analysis": analysis,
                "count_guard_applied": True,
                "authoritative_metrics_path": "analysis.authoritative_metrics",
            }
        except Exception:
            fallback = deterministic_group_analysis(aggregate, status="SUCCESS_WITH_DETERMINISTIC_NORMALIZATION")
            fallback["analysis"]["portfolio_interpretation"] = text[:12000]
            fallback["count_guard_applied"] = True
            return fallback
    except Exception as exc:
        fallback = deterministic_group_analysis(aggregate, status="DETERMINISTIC_FALLBACK")
        fallback["llm_error"] = safe_exception_chain(exc)
        fallback["count_guard_applied"] = True
        return fallback
    finally:
        if model_client is not None:
            await close_model_client(model_client)


async def run_batch(
    settings: Settings,
    parse_result: dict[str, Any],
    *,
    max_parallel: int = SOURCE_PARALLEL_WORKERS,
    max_parallel_ai: int = DELL_AIA_PARALLEL_WORKERS,
    include_group_ai: bool = INCLUDE_GROUPED_DELL_AIA,
    require_ai_preflight: bool = True,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Two-phase batch pipeline with wall-clock timing for every major step."""
    from .agents import AgenticOrchestrator
    from .agents.model_client import probe_dell_aia_runtime, safe_exception_chain
    from .reporting import save_audit_report

    # v11.37: role policy is enforced by the .NET proxy; keep safe bounds here.
    max_parallel = max(1, min(int(max_parallel or SOURCE_PARALLEL_WORKERS), 8))
    max_parallel_ai = max(1, min(int(max_parallel_ai or DELL_AIA_PARALLEL_WORKERS), 2))
    include_group_ai = bool(include_group_ai)

    batch_started = perf_counter()
    entries = list(parse_result.get("entries") or [])
    if not entries:
        entries = [
            {"input_index": i, "record_id": f"ROW-{i:04d}", "email": email}
            for i, email in enumerate(parse_result.get("emails") or [], 1)
        ]
    batch_id = "BATCH-" + uuid.uuid4().hex[:12].upper()

    preflight_started = perf_counter()
    preflight = await probe_dell_aia_runtime(settings) if entries else {"ok": True, "status": "SKIPPED"}
    preflight_ms = int((perf_counter() - preflight_started) * 1000)
    if require_ai_preflight and entries and not preflight.get("ok"):
        code = preflight.get("error_code") or "AIA_PREFLIGHT_FAILED"
        raise RuntimeError(
            f"{code}: Dell AIA preflight failed before batch execution. "
            f"token_acquisition={preflight.get('token_acquisition')}; model_route={preflight.get('model_route')}. "
            f"{preflight.get('recommended_action') or preflight.get('error') or ''}"
        )

    source_semaphore = asyncio.Semaphore(max(1, min(int(max_parallel), 8)))
    ai_semaphore = asyncio.Semaphore(max(1, min(int(max_parallel_ai), 2)))

    async def collect_one(entry: dict[str, Any]) -> dict[str, Any]:
        email = str(entry.get("email") or "")
        member_started = perf_counter()
        queue_started = perf_counter()
        async with source_semaphore:
            source_queue_wait_ms = int((perf_counter() - queue_started) * 1000)
            try:
                orch = AgenticOrchestrator(settings, ai_semaphore=ai_semaphore)
                report, bundle = await orch.collect_data(SearchType.EMAIL, email)
                if not _same_email(report.search_value, email):
                    raise RuntimeError("BATCH_EMAIL_CONTEXT_MISMATCH: requested email does not match report.search_value")
                report.timings = dict(report.timings or {})
                report.timings["batch_source_queue_wait_ms"] = source_queue_wait_ms
                return {
                    "input_index": entry.get("input_index"),
                    "record_id": entry.get("record_id"),
                    "email": email,
                    "report_email": report.search_value,
                    "context_integrity": "PASS",
                    "report_obj": report,
                    "mcp_bundle": bundle,
                    "_member_started_perf": member_started,
                    "_data_completed_perf": perf_counter(),
                    "timings": dict(report.timings or {}),
                    "error": None,
                }
            except Exception as exc:
                return {
                    "input_index": entry.get("input_index"),
                    "record_id": entry.get("record_id"),
                    "email": email,
                    "report_email": None,
                    "context_integrity": "FAILED",
                    "report_obj": None,
                    "mcp_bundle": None,
                    "_member_started_perf": member_started,
                    "_data_completed_perf": perf_counter(),
                    "timings": {
                        "batch_source_queue_wait_ms": source_queue_wait_ms,
                        "batch_member_end_to_end_ms": int((perf_counter() - member_started) * 1000),
                    },
                    "error": safe_exception_chain(exc),
                }

    # Phase 1: Data Collection Agent for every unique valid email.
    data_phase_started = perf_counter()
    staged = await asyncio.gather(*(collect_one(entry) for entry in entries))
    data_collection_phase_ms = int((perf_counter() - data_phase_started) * 1000)

    async def analyze_one(item: dict[str, Any]) -> dict[str, Any]:
        report = item.get("report_obj")
        bundle = item.get("mcp_bundle")
        member_started = item.get("_member_started_perf") or perf_counter()
        data_completed = item.get("_data_completed_perf") or perf_counter()
        phase_barrier_wait_ms = int((perf_counter() - data_completed) * 1000)
        if report is None or bundle is None:
            timings = dict(item.get("timings") or {})
            timings["batch_phase_barrier_wait_ms"] = phase_barrier_wait_ms
            timings["batch_member_end_to_end_ms"] = int((perf_counter() - member_started) * 1000)
            return {
                "input_index": item.get("input_index"),
                "record_id": item.get("record_id"),
                "email": item.get("email"),
                "report_email": item.get("report_email"),
                "context_integrity": item.get("context_integrity"),
                "report": None,
                "timings": timings,
                "error": item.get("error") or "Data Collection Agent failed",
            }
        try:
            report.timings = dict(report.timings or {})
            report.timings["batch_phase_barrier_wait_ms"] = phase_barrier_wait_ms
            orch = AgenticOrchestrator(settings, ai_semaphore=ai_semaphore)
            report = await orch.analyze_and_judge(report, bundle, SearchType.EMAIL, str(item.get("email") or ""))
            report.timings["batch_member_end_to_end_ms"] = int((perf_counter() - member_started) * 1000)
            report.timings["total_processing_ms"] = report.timings["batch_member_end_to_end_ms"]
            audit_started = perf_counter()
            save_audit_report(report, settings)
            report.timings["audit_report_write_ms"] = int((perf_counter() - audit_started) * 1000)
            report.timings["batch_member_end_to_end_ms"] = int((perf_counter() - member_started) * 1000)
            report.timings["end_to_end_ms"] = report.timings["batch_member_end_to_end_ms"]
            save_audit_report(report, settings)
            return {
                "input_index": item.get("input_index"),
                "record_id": item.get("record_id"),
                "email": item.get("email"),
                "report_email": report.search_value,
                "context_integrity": "PASS",
                "report": report.model_dump(mode="json"),
                "timings": dict(report.timings or {}),
                "error": None,
            }
        except Exception as exc:
            if report is not None:
                report.timings = dict(report.timings or {})
                report.timings["batch_member_end_to_end_ms"] = int((perf_counter() - member_started) * 1000)
            return {
                "input_index": item.get("input_index"),
                "record_id": item.get("record_id"),
                "email": item.get("email"),
                "report_email": item.get("report_email"),
                "context_integrity": "FAILED",
                "report": report.model_dump(mode="json") if report is not None else None,
                "timings": dict(report.timings or {}) if report is not None else dict(item.get("timings") or {}),
                "error": safe_exception_chain(exc),
            }

    # Phase 2 + 3: Analysis Agent followed by Judge Agent.
    aia_phase_started = perf_counter()
    items = await asyncio.gather(*(analyze_one(item) for item in staged))
    analysis_judge_phase_ms = int((perf_counter() - aia_phase_started) * 1000)

    aggregation_started = perf_counter()
    aggregate = aggregate_batch(batch_id, parse_result, items)
    aggregation_ms = int((perf_counter() - aggregation_started) * 1000)
    aggregate["dell_aia_preflight"] = preflight
    aggregate["processing"]["architecture"] = "DATA_AGENT -> ANALYSIS_AGENT -> JUDGE_AGENT"
    aggregate["processing"]["source_parallelism"] = max(1, min(int(max_parallel), 8))
    aggregate["processing"]["dell_aia_parallelism"] = max(1, min(int(max_parallel_ai), 2))
    aggregate["processing"]["dell_aia_multiple_transactions"] = True
    aggregate["processing"]["email_context_integrity_failures"] = sum(
        1 for item in items if item.get("context_integrity") != "PASS"
    )
    aggregate["processing"]["unique_emails_processed"] = len(entries)
    aggregate["processing"]["deduplication_applied"] = bool(parse_result.get("deduplication_applied", True))
    aggregate["processing"]["duplicates_ignored"] = int(parse_result.get("duplicate_count", 0) or 0)

    group_ai_ms = 0
    if include_group_ai and items:
        group_started = perf_counter()
        aggregate["group_ai_analysis"] = await _group_ai_analysis(settings, aggregate)
        group_ai_ms = int((perf_counter() - group_started) * 1000)

    aggregate.setdefault("timings", {})
    aggregate["timings"].update({
        "batch_total_ms": int((perf_counter() - batch_started) * 1000),
        "dell_aia_preflight_ms": preflight_ms,
        "data_collection_phase_ms": data_collection_phase_ms,
        "analysis_judge_phase_ms": analysis_judge_phase_ms,
        "aggregation_ms": aggregation_ms,
        "group_ai_analysis_ms": group_ai_ms,
        "timing_note": (
            "Batch phase durations are wall-clock values. Individual member times include queue/barrier waits. "
            "Parallel source/API durations are not additive."
        ),
    })
    return aggregate, items


def _fmt_duration(value: Any) -> str:
    if value in (None, ""):
        return "—"
    ms = _duration_ms(value)
    if ms < 1000:
        return f"{ms} ms"
    seconds = ms / 1000.0
    if seconds < 60:
        return f"{seconds:.2f} s"
    minutes = int(seconds // 60)
    return f"{minutes}m {seconds - minutes * 60:.1f}s"


def _esc(value: Any) -> str:
    if value is None or value == "":
        return "—"
    return html.escape(str(value))


def render_batch_summary_html(summary: dict[str, Any], *, masked: bool = False) -> str:
    data = sanitize(summary) if masked else summary
    inp, proc, totals = data.get("input", {}), data.get("processing", {}), data.get("totals", {})
    timing = data.get("timings") or {}
    member_stats = timing.get("member_stats_ms") or {}
    rows = []
    for idx, member in enumerate(data.get("members") or [], 1):
        issue_total = sum(int(member.get(k) or 0) for k in ("mismatches", "missing_attributes", "missing_records", "format_issues"))
        css = "ok" if issue_total == 0 and member.get("status") == "COMPLETED" else ("bad" if member.get("status") == "FAILED" else "warn")
        report_link = "—"
        if member.get("run_id") not in (None, "", "—"):
            report_link = f"<a href='individual_reports/{idx:03d}_{html.escape(str(member.get('run_id')))}.html'>Open</a>"
        rows.append(f"""<tr><td>{idx}</td><td>{_esc(member.get('record_id'))}</td><td>{_esc(member.get('email'))}</td><td>{_esc(member.get('run_id'))}</td><td>{report_link}</td>
        <td><span class='pill {css}'>{_esc(member.get('completeness'))}</span></td><td>{member.get('mismatches',0)}</td>
        <td>{member.get('missing_attributes',0)}</td><td>{member.get('missing_records',0)}</td><td>{member.get('format_issues',0)}</td>
        <td>{member.get('exact_changes',0)}</td><td>{member.get('manual_review',0)}</td><td>{_esc(member.get('cps'))}</td>
        <td>{_esc(member.get('rewards_db'))}</td><td>{_esc(member.get('crowd_twist'))}</td><td>{_esc(member.get('dell_aia_execution') or member.get('dell_aia'))}</td><td>{_esc(member.get('judge_verdict'))}</td><td>{_esc(member.get('final_content_status'))}</td><td>{_esc(member.get('mcp'))}</td>
        <td>{_esc(_fmt_duration(member.get('total_time_ms')))}</td><td>{_esc(_fmt_duration(member.get('data_collection_ms')))}</td>
        <td>{_esc(_fmt_duration(member.get('analysis_agent_ms')))}</td><td>{_esc(_fmt_duration(member.get('judge_agent_ms')))}</td></tr>""")
    issue_rows = "".join(f"<tr><td>{_esc(x.get('attribute'))}</td><td>{x.get('count',0)}</td></tr>" for x in data.get("top_issue_attributes") or []) or "<tr><td colspan='2'>No recurring issues.</td></tr>"
    coverage_rows = []
    for source_name, counts in (data.get("source_record_status") or {}).items():
        counts = counts or {}
        coverage_rows.append(
            f"<tr><td>{_esc(source_name.replace('_',' ').title().replace('Cps','CPS').replace('Db','DB'))}</td>"
            f"<td>{counts.get('FOUND',0)}</td><td>{counts.get('NO_RECORD',0)}</td><td>{counts.get('UNAVAILABLE',0)}</td></tr>"
        )
    coverage_html = "".join(coverage_rows) or "<tr><td colspan='4'>No source coverage data.</td></tr>"
    ai = data.get("group_ai_analysis") or {}
    ai_body = ai.get("analysis") or {}
    ai_html = f"<pre>{html.escape(json.dumps(ai_body, indent=2, default=str))}</pre>" if ai_body else "<p>No grouped analysis is available.</p>"
    ai_diag = ""
    if ai.get("llm_error"):
        ai_diag = f"<details><summary>Dell AIA grouped-analysis diagnostic</summary><pre>{html.escape(str(ai.get('llm_error')))}</pre></details>"
    timing_stat_rows = []
    for key, label in (("total_time", "Member total"), ("data_collection", "Data Collection Agent"), ("analysis_agent", "Dell AIA Analyst"), ("judge_agent", "Dell AIA Judge"), ("dell_aia_queue_wait", "Dell AIA queue wait")):
        stat = member_stats.get(key) or {}
        timing_stat_rows.append(
            f"<tr><td>{html.escape(label)}</td><td>{_esc(_fmt_duration(stat.get('min_ms')))}</td>"
            f"<td>{_esc(_fmt_duration(stat.get('avg_ms')))}</td><td>{_esc(_fmt_duration(stat.get('median_ms')))}</td>"
            f"<td>{_esc(_fmt_duration(stat.get('max_ms')))}</td><td>{int(stat.get('count') or 0)}</td></tr>"
        )
    timing_stats_html = "".join(timing_stat_rows)
    generated = str(data.get("created_at") or "")
    return f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Batch Data Disparity Summary · {_esc(data.get('batch_id'))}</title><style>
:root{{--navy:#0867b5;--blue:#0878b6;--paper:#eef3f8;--ink:#182230;--muted:#667085;--line:#dfe7f0;--ok:#138a5b;--warn:#ad6a00;--bad:#c6384a}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--paper);color:var(--ink);font-family:Inter,Segoe UI,Arial,sans-serif}}main{{max-width:1500px;margin:auto;padding:28px}}.hero{{padding:34px;border-radius:24px;background:linear-gradient(125deg,#0867b5,#00a4b8);color:#fff}}h1{{margin:6px 0 8px;font-size:34px}}.hero p{{color:#d9efff}}.chips{{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}}.chip{{padding:7px 11px;background:#ffffff18;border:1px solid #ffffff33;border-radius:999px}}.grid{{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:20px 0}}.card,.section{{background:#fff;border:1px solid var(--line);border-radius:18px;padding:18px}}.card b{{display:block;font-size:28px}}.card span{{font-size:12px;color:var(--muted)}}.section{{margin-top:18px}}.table{{overflow:auto;border:1px solid var(--line);border-radius:12px}}table{{width:100%;border-collapse:collapse;min-width:1250px}}th{{background:#edf4fb;padding:10px;text-align:left;font-size:11px;text-transform:uppercase}}td{{padding:10px;border-top:1px solid #edf1f5;font-size:12px}}.pill{{padding:4px 8px;border-radius:999px;font-weight:700}}.pill.ok{{background:#e9f8f1;color:var(--ok)}}.pill.warn{{background:#fff6df;color:var(--warn)}}.pill.bad{{background:#fff0f2;color:var(--bad)}}pre{{background:#081a2e;color:#d9e8f6;padding:16px;border-radius:12px;white-space:pre-wrap}}.batch-nav{{position:sticky;top:0;z-index:10;display:flex;flex-wrap:wrap;gap:8px;margin:16px 0;padding:10px;background:#f4f7fbf2;border:1px solid var(--line);border-radius:14px}}.batch-nav a{{text-decoration:none;color:var(--blue);font-weight:800;font-size:12px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:7px 10px}}.anchor{{scroll-margin-top:80px}}.twocol{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}@media(max-width:900px){{.grid{{grid-template-columns:repeat(2,1fr)}}.twocol{{grid-template-columns:1fr}}main{{padding:12px}}}}@media print{{body{{background:white}}main{{padding:0}}}}
</style></head><body><main><header class='hero'><div style='text-transform:uppercase;letter-spacing:.13em;font-size:12px'>Dell Rewards · Batch Quality Control</div><h1>Data Disparity Batch Summary</h1><p>Parallel analysis of individual member reports with portfolio-level aggregation. Each member retains a separate HTML and JSON evidence report.</p><div class='chips'><span class='chip'>{_esc(data.get('batch_id'))}</span><span class='chip'>{_esc(generated)}</span><span class='chip'>{inp.get('unique_valid_count', inp.get('valid_transaction_count',0))} unique valid</span><span class='chip'>{proc.get('completed_count',0)} completed</span><span class='chip'>Total {_esc(_fmt_duration(timing.get('batch_total_ms')))}</span><span class='chip'>{'MASKED · safe to share' if masked else 'UNMASKED · contains source values'}</span></div></header>
<nav class='batch-nav'><a href='#overview'>Overview</a><a href='#members'>Member Results</a><a href='#patterns'>Grouped Analysis</a><a href='#coverage'>Source Coverage</a><a href='#timing'>Timing</a><a href='#execution'>Agent Execution</a><a href='#audit'>Audit</a></nav>
<section id='overview' class='grid anchor'><div class='card'><b>{inp.get('submitted_count',0)}</b><span>Submitted rows</span></div><div class='card'><b>{inp.get('unique_valid_count', inp.get('valid_transaction_count',0))}</b><span>Unique valid</span></div><div class='card'><b>{inp.get('duplicate_count',0)}</b><span>Duplicates ignored</span></div><div class='card'><b>{inp.get('invalid_count',0)}</b><span>Invalid rows excluded</span></div><div class='card'><b>{proc.get('completed_count',0)}</b><span>Completed</span></div><div class='card'><b>{proc.get('failed_count',0)}</b><span>Failed runs</span></div><div class='card'><b>{totals.get('mismatches',0)}</b><span>Mismatches</span></div><div class='card'><b>{(data.get('source_member_record_metrics') or {}).get('missing_source_member_records_total', totals.get('missing_records',0))}</b><span>Missing source records</span></div><div class='card'><b>{totals.get('format_issues',0)}</b><span>Format issues</span></div><div class='card'><b>{totals.get('exact_changes',0)}</b><span>Exact change items</span></div><div class='card'><b>{(data.get('population_metrics') or {}).get('users_requiring_manual_review',0)}</b><span>Users requiring review</span></div><div class='card'><b>{totals.get('manual_review',0)}</b><span>Manual-review items</span></div><div class='card'><b>{_esc(_fmt_duration(timing.get('batch_total_ms')))}</b><span>Total batch time</span></div></section>
<section class='section anchor'><h2>Portfolio overview</h2><div class='twocol'><div><p><b>Completeness:</b> FULL {proc.get('full_count',0)} · PARTIAL {proc.get('partial_count',0)} · NO AUTHORITATIVE DATA {proc.get('no_authoritative_data_count',0)}</p><p><b>Dell AIA execution:</b> {proc.get('dell_aia_execution_success_count',proc.get('dell_aia_success_count',0))} success · {proc.get('dell_aia_execution_failed_count',proc.get('dell_aia_failed_count',0))} failed</p><p><b>Judge content verdicts:</b> {proc.get('judge_accepted_count',0)} accepted · {proc.get('judge_partial_count',0)} corrected · {proc.get('judge_rejected_count',0)} rejected · {proc.get('judge_review_required_count',0)} review required</p><p><b>MCP:</b> {proc.get('mcp_success_count',0)} successful · {proc.get('mcp_failed_count',0)} not successful</p></div><div><p><b>Input quality:</b> {inp.get('duplicate_count',0)} duplicate email row(s) ignored and {inp.get('invalid_count',0)} invalid item(s) excluded. Only exact canonical duplicates are removed; distinct emails remain separate analyses.</p><p><b>Counting guard:</b> member counts, source-member-record counts, attribute-verdict counts, and guidance-item counts are shown separately and never relabeled.</p><p><b>Processing model:</b> individual analyses run concurrently with bounded parallelism; grouped metrics are computed only from completed reports.</p></div></div></section>
<section id='members' class='section anchor'><h2>Member-by-member results</h2><div class='table'><table><thead><tr><th>#</th><th>Record ID</th><th>Email</th><th>Run ID</th><th>Report</th><th>Completeness</th><th>Mismatch</th><th>Missing Attr</th><th>Missing Rec</th><th>Format</th><th>Exact</th><th>Review</th><th>CPS</th><th>Rewards DB</th><th>CrowdTwist</th><th>Dell AIA Execution</th><th>Judge Verdict</th><th>Final Content</th><th>MCP</th><th>Total Time</th><th>Data Agent</th><th>Analyst</th><th>Judge</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></section>
<section id='patterns' class='section twocol anchor'><div><h2>Most frequent issue attributes</h2><table style='min-width:0'><thead><tr><th>Attribute</th><th>Users affected</th></tr></thead><tbody>{issue_rows}</tbody></table></div><div><h2>Grouped Dell AIA analysis</h2><p style='color:var(--muted)'>This narrative is derived from aggregate statistics of the individual MCP-grounded runs; deterministic counts remain authoritative.</p>{ai_html}{ai_diag}</div></section>
<section id='coverage' class='section anchor'><h2>Source coverage</h2><div class='table'><table style='min-width:0'><thead><tr><th>Source</th><th>Found</th><th>No record</th><th>Unavailable</th></tr></thead><tbody>{coverage_html}</tbody></table></div><p style='color:var(--muted)'>No-record and unavailable are kept separate so outages are never interpreted as missing member data.</p></section>
<section id='timing' class='section anchor'><h2>Execution timing</h2><p style='color:var(--muted)'>Wall-clock duration for the batch and major phases. Parallel source operations overlap, so step durations are not additive.</p><div class='grid'><div class='card'><b>{_esc(_fmt_duration(timing.get('batch_total_ms')))}</b><span>Total batch</span></div><div class='card'><b>{_esc(_fmt_duration(timing.get('dell_aia_preflight_ms')))}</b><span>Dell AIA preflight</span></div><div class='card'><b>{_esc(_fmt_duration(timing.get('data_collection_phase_ms')))}</b><span>Data collection phase</span></div><div class='card'><b>{_esc(_fmt_duration(timing.get('analysis_judge_phase_ms')))}</b><span>Analysis + judge phase</span></div><div class='card'><b>{_esc(_fmt_duration(timing.get('group_ai_analysis_ms')))}</b><span>Grouped AI</span></div></div><h3>Per-member timing distribution</h3><div class='table'><table style='min-width:760px'><thead><tr><th>Step</th><th>Min</th><th>Average</th><th>Median</th><th>Max</th><th>Members</th></tr></thead><tbody>{timing_stats_html}</tbody></table></div></section>
<section id='execution' class='section anchor'><h2>Agent execution summary and judge enforcement</h2><div class='twocol'><div><p><b>Dell AIA technical execution:</b> {proc.get('dell_aia_execution_success_count',proc.get('dell_aia_success_count',0))} success · {proc.get('dell_aia_execution_failed_count',proc.get('dell_aia_failed_count',0))} failed</p><p><b>Judge accepted:</b> {proc.get('judge_accepted_count',0)} · <b>corrected:</b> {proc.get('judge_partial_count',0)} · <b>rejected:</b> {proc.get('judge_rejected_count',0)} · <b>review required:</b> {proc.get('judge_review_required_count',0)}</p><p><b>MCP individual runs:</b> {proc.get('mcp_success_count',0)} success · {proc.get('mcp_failed_count',0)} not successful</p></div><div><p><b>Grouped analysis status:</b> {_esc(ai.get('status') or 'NOT_RUN')}</p><p>Rejected analyst narratives are suppressed. Partial narratives are replaced with judge-corrected deterministic content. Technical execution success never implies content approval.</p></div></div></section>
<section id='audit' class='section anchor'><h2>Batch controls and audit</h2><p>Exact duplicate emails are ignored after the first occurrence using case-insensitive canonical matching. Distinct emails remain separate analyses. Invalid rows are excluded. A source-wide outage is not interpreted as member-level missing data. No automatic write is performed by this report.</p></section>
<footer style='text-align:center;color:var(--muted);padding:24px'>Generated by Agentic Data Disparity Checker · {_esc(data.get('batch_id'))}</footer></main></body></html>"""


def build_batch_zip(
    summary: dict[str, Any],
    items: Iterable[dict[str, Any]],
    *,
    mask_pii: bool = False,
) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        summary_output = sanitize(summary) if mask_pii else summary
        if mask_pii and isinstance(summary_output, dict):
            summary_output = {**summary_output, "report_privacy": "MASKED"}
        zf.writestr("00_BATCH_SUMMARY.html", render_batch_summary_html(summary, masked=mask_pii))
        zf.writestr("00_BATCH_SUMMARY.json", json.dumps(summary_output, indent=2, default=str))
        zf.writestr(
            "REPORT_PRIVACY.txt",
            (
                "MASKED REPORT PACKAGE\nPII and member identifiers are deterministically tokenized for safer sharing.\n"
                if mask_pii
                else "UNMASKED REPORT PACKAGE\nContains original member/source values. Handle only in approved secure locations.\n"
            ),
        )

        rows_io = io.StringIO()
        fields = list((summary.get("members") or [{}])[0].keys()) if summary.get("members") else ["email", "status"]
        writer = csv.DictWriter(rows_io, fieldnames=fields)
        writer.writeheader()
        writer.writerows(summary_output.get("members") or [])
        zf.writestr("00_MEMBER_SUMMARY.csv", rows_io.getvalue())

        manifest: list[dict[str, Any]] = []
        for idx, item in enumerate(items, 1):
            report = item.get("report")
            if not report:
                manifest.append({"index": idx, "email": item.get("email"), "status": "FAILED", "error": item.get("error")})
                continue
            output = sanitize(report) if mask_pii else report
            stem = f"{idx:03d}_{report.get('run_id','UNKNOWN')}"
            zf.writestr(f"individual_reports/{stem}.html", render_html_report(output, mask_pii=False))
            zf.writestr(f"individual_reports/{stem}.json", json.dumps(output, indent=2, default=str))
            manifest.append({"index": idx, "email": item.get("email"), "run_id": report.get("run_id"), "html": f"individual_reports/{stem}.html", "json": f"individual_reports/{stem}.json"})
        zf.writestr("MANIFEST.json", json.dumps(sanitize(manifest) if mask_pii else manifest, indent=2, default=str))
    return buffer.getvalue()

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import httpx

from src.app_settings import DEFAULT_REWARDS_ENVIRONMENT, SPRING_CONFIG_ENVIRONMENTS


def _normalize_key(value: str) -> str:
    return "".join(ch.lower() for ch in value if ch.isalnum())


def _flatten_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    property_sources = payload.get("propertySources")
    if isinstance(property_sources, list):
        # Spring lists highest-precedence sources first. Iterate backwards so
        # higher-precedence values overwrite lower-precedence values.
        for source in reversed(property_sources):
            if not isinstance(source, Mapping):
                continue
            values = source.get("source")
            if isinstance(values, Mapping):
                merged.update(values)
    else:
        merged.update(payload)
    return merged


def _pick(properties: Mapping[str, Any], *aliases: str) -> str:
    normalized = {_normalize_key(str(key)): value for key, value in properties.items()}
    for alias in aliases:
        target = _normalize_key(alias)
        value = normalized.get(target)
        if value not in (None, ""):
            return str(value)
    # Configuration keys are sometimes namespace-prefixed. Suffix matching
    # handles forms such as "VaultConfigurations:DCIAuthUrl".
    for alias in aliases:
        target = _normalize_key(alias)
        for key, value in normalized.items():
            if key.endswith(target) and value not in (None, ""):
                return str(value)
    return ""


def fetch_spring_config(
    environment: str = DEFAULT_REWARDS_ENVIRONMENT,
    *,
    username: str = "",
    password: str = "",
    timeout: float = 30.0,
    verify_ssl: bool = True,
) -> tuple[dict[str, Any], str]:
    env = environment.lower().strip()
    if not username or not password:
        raise RuntimeError(
            "Spring Config credentials are missing. Set SPRING_CONFIG_USERNAME and "
            "SPRING_CONFIG_PASSWORD or inject them from Vault."
        )
    if env not in SPRING_CONFIG_ENVIRONMENTS:
        raise ValueError(f"Unsupported Dell Rewards environment: {environment}")

    spec = SPRING_CONFIG_ENVIRONMENTS[env]
    base_url = str(spec["base_url"]).rstrip("/")
    application = str(spec["application"])
    profiles = list(spec.get("profiles") or ["default"])
    errors: list[str] = []

    with httpx.Client(
        auth=(username, password),
        timeout=timeout,
        verify=verify_ssl,
        headers={"Accept": "application/json"},
        follow_redirects=True,
    ) as client:
        for profile in profiles:
            url = f"{base_url}/{application}/{profile}"
            try:
                response = client.get(url)
                response.raise_for_status()
                payload = response.json()
                if isinstance(payload, Mapping):
                    properties = _flatten_payload(payload)
                    if properties:
                        return properties, url
                errors.append(f"{url}: empty configuration")
            except Exception as exc:
                errors.append(f"{url}: {type(exc).__name__}")

    raise RuntimeError("Spring Config bootstrap failed: " + "; ".join(errors))


def map_spring_properties(properties: Mapping[str, Any]) -> dict[str, Any]:
    """Map Dell Spring/Vault property names into application settings.

    CrowdTwist search in the uploaded .NET service uses the Ext2 endpoint and
    Ext2 client credentials, so those aliases are intentionally preferred.
    """
    updates = {
        "cps_base_url": _pick(properties, "CPSBaseAddress"),
        "cps_api_key": _pick(properties, "CPSApiKey"),
        "cps_auth_url": _pick(properties, "DCIAuthUrl"),
        "cps_client_id": _pick(properties, "DCIAppClientId"),
        "cps_client_secret": _pick(properties, "DCIAppClientSecret"),
        "cps_scope": _pick(properties, "DCIAuthScope", "DCIAuthResource"),
        "tcps_search_url": _pick(
            properties,
            "TCPSUserSearchUrl",
            "UserProvisioningSearchUrl",
            "DellIdentityUserSearchUrl",
        ),
        "tcps_bearer_token": _pick(
            properties,
            "TCPSBearerToken",
            "UserProvisioningBearerToken",
            "DellIdentityBearerToken",
        ),
        "crowd_twist_base_url": _pick(
            properties,
            "CTLayer7ApiExt2URL",
            "CTLayer7ApiExtURL",
            "CTLayer7ApiURL",
            "CrowdTwistBaseUrl",
        ),
        "crowd_twist_auth_url": _pick(properties, "CTLayer7AuthTokenURL"),
        "crowd_twist_client_id": _pick(
            properties,
            "CTLayer7Ext2ClientId",
            "CTLayer7ExtClientId",
            "CTLayer7ClientId",
        ),
        "crowd_twist_client_secret": _pick(
            properties,
            "CTLayer7Ext2Secret",
            "CTLayer7ExtSecret",
            "CTLayer7Secret",
        ),
        # Reads use Ext2 in the uploaded Dell Utility implementation, while
        # updates use Ext. Preserve both endpoint/credential families instead
        # of collapsing them into one setting.
        "crowd_twist_update_base_url": _pick(
            properties,
            "CTLayer7ApiExtURL",
            "CrowdTwistUpdateBaseUrl",
        ),
        "crowd_twist_update_client_id": _pick(
            properties,
            "CTLayer7ExtClientId",
            "CrowdTwistUpdateClientId",
        ),
        "crowd_twist_update_client_secret": _pick(
            properties,
            "CTLayer7ExtSecret",
            "CrowdTwistUpdateClientSecret",
        ),
        "crowd_twist_api_key": _pick(properties, "CrowdTwistApiKey"),
        "rewards_db_connection_string": _pick(
            properties,
            "DellRewardsConnection",
            "DellRewardsDbConnection",
            "ConnectionStrings:DellRewardsConnection",
        ),
    }
    return {key: value for key, value in updates.items() if value not in (None, "")}

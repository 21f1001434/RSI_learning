"""Agentic data disparity checker."""

__version__ = "7.1.0"

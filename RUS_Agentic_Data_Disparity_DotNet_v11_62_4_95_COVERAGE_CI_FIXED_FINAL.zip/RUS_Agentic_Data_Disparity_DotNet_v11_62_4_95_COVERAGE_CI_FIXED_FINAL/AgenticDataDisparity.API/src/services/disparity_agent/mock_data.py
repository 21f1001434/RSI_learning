from __future__ import annotations

from .models import SourceName, SourceRecord, SourceStatus


def _record(source: SourceName, raw: dict) -> SourceRecord:
    return SourceRecord(
        source=source,
        status=SourceStatus(source=source, connected=True, data_found=True, latency_ms=5, retrieval_method="mock"),
        raw=raw,
    )


def _tcps_cps_record(raw: dict) -> SourceRecord:
    return SourceRecord(
        source=SourceName.CPS,
        status=SourceStatus(
            source=SourceName.CPS,
            connected=True,
            data_found=True,
            latency_ms=8,
            retrieval_method="mock+cps_tcps_scim",
            diagnostics={
                "tcps_country_lookup": {
                    "service": "tCPS / Dell Identity User Provisioning",
                    "operation": "POST /userprovisioning/v1/Users/.search",
                    "connected": True,
                    "data_found": True,
                    "country_found": True,
                    "stage": "complete",
                    "http_status": 200,
                    "endpoint_host": "dellidentity-corp.dell.com",
                }
            },
        ),
        raw=raw,
    )


def _missing_record(source: SourceName, *, http_status: int | None = None) -> SourceRecord:
    return SourceRecord(
        source=source,
        status=SourceStatus(
            source=source,
            connected=True,
            data_found=False,
            latency_ms=5,
            retrieval_method="mock",
            stage="user_lookup" if source == SourceName.CROWD_TWIST else "complete",
            http_status=http_status,
            error_code=f"HTTP_{http_status}" if http_status else None,
            diagnostic_hint="Connected successfully, but no matching member record was found.",
        ),
        raw=None,
    )


CASES: dict[str, dict[SourceName, SourceRecord]] = {
    "case1": {
        SourceName.CPS: _record(SourceName.CPS, {"profileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "profiles": [{"region": "US", "contact": {"emailId": "xyz@example.com"}}]}),
        SourceName.REWARDS_DB: _record(SourceName.REWARDS_DB, {"ProfileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "CountryCode": "US"}),
        SourceName.CROWD_TWIST: _record(SourceName.CROWD_TWIST, {"third_party_id": "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb", "email_address": "xyz@example.com", "country": "US"}),
    },
    "case2": {
        SourceName.CPS: _record(SourceName.CPS, {"profileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "profiles": [{"region": "US", "contact": {"emailId": "xyz@example.com"}}]}),
        SourceName.REWARDS_DB: _record(SourceName.REWARDS_DB, {"ProfileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "CountryCode": "US"}),
        SourceName.CROWD_TWIST: _record(SourceName.CROWD_TWIST, {"third_party_id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "email_address": "abc@example.com", "country": "US"}),
    },
    "case3": {
        SourceName.CPS: _record(SourceName.CPS, {"profileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "profiles": [{"region": "US", "contact": {"emailId": "xyz@example.com"}}]}),
        SourceName.REWARDS_DB: _record(SourceName.REWARDS_DB, {"ProfileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "CountryCode": "AU"}),
        SourceName.CROWD_TWIST: _record(SourceName.CROWD_TWIST, {"third_party_id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "email_address": "abc@example.com", "country": "AU"}),
    },
    "case4": {
        SourceName.CPS: _record(SourceName.CPS, {"profileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "profiles": [{"region": "US", "contact": {"emailId": "xyz@example.com"}}]}),
        SourceName.REWARDS_DB: _record(SourceName.REWARDS_DB, {"ProfileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "CountryCode": "AU", "IsActive": True}),
        SourceName.CROWD_TWIST: _record(SourceName.CROWD_TWIST, {"third_party_id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "email_address": "abc@example.com", "country": "AU", "is_active": False}),
    },
    "case5": {
        SourceName.CPS: _record(
            SourceName.CPS,
            {
                "profileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
                "phone": "1234567890",
                "profiles": [{
                    "region": "UsCanada",
                    "contact": {
                        "emailId": "xyz@example.com",
                        "firstName": "Kamal",
                        "lastName": "Shrivastava",
                        "postalCode": "A1A1A1",
                    },
                }],
            },
        ),
        SourceName.REWARDS_DB: _record(
            SourceName.REWARDS_DB,
            {
                "ProfileId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
                "CountryCode": "Canada",
                "IsActive": False,
                "CrowdTwistID": 259298937,
            },
        ),
        SourceName.CROWD_TWIST: _record(
            SourceName.CROWD_TWIST,
            {
                "third_party_id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
                "email_address": "xyz@example.com",
                "country": "United States",
                "is_active": True,
                "id": 239251935,
                "first_name": "Kamal",
                "last_name": "Shrivastava",
                "mobile_phone_number": "1234567890",
                "postal_code": "A1A1A1",
            },
        ),
    },
    "case6_rohan_country": {
        SourceName.CPS: _record(
            SourceName.CPS,
            {
                "profileId": "cccccccc-cccc-cccc-cccc-cccccccccccc",
                "profiles": [{"region": "UsCanada", "contact": {"emailId": "rohan@example.com", "firstName": "R S", "lastName": "Sinha"}}],
            },
        ),
        SourceName.REWARDS_DB: _record(
            SourceName.REWARDS_DB,
            {"ProfileId": "cccccccc-cccc-cccc-cccc-cccccccccccc", "CountryCode": "US", "IsActive": True, "CrowdTwistID": 241627696},
        ),
        SourceName.CROWD_TWIST: _record(
            SourceName.CROWD_TWIST,
            {
                "third_party_id": "dddddddd-dddd-dddd-dddd-dddddddddddd",
                "email_address": "rohan@example.com",
                "country": "United States",
                "is_active": True,
                "id": 241627696,
                "first_name": "R S",
                "last_name": "Sinha",
                "postal_code": "10001",
            },
        ),
    },
    "case7_kamal_country": {
        SourceName.CPS: _record(
            SourceName.CPS,
            {
                "profileId": "eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee",
                "profiles": [{"region": "UsCanada", "contact": {"emailId": "kamal@example.com", "firstName": "Kamal", "lastName": "Shrivastava"}}],
            },
        ),
        SourceName.REWARDS_DB: _record(
            SourceName.REWARDS_DB,
            {"ProfileId": "eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee", "CountryCode": "CA", "IsActive": True, "CrowdTwistID": 259298937},
        ),
        SourceName.CROWD_TWIST: _record(
            SourceName.CROWD_TWIST,
            {
                "third_party_id": "eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee",
                "email_address": "kamal@example.com",
                "country": "United States",
                "is_active": True,
                "id": 239251935,
                "first_name": "Kamal",
                "last_name": "shrivastava",
                "mobile_phone_number": "1234567890",
                "postal_code": "00000",
            },
        ),
    },
    "case9_tcps_exact_country": {
        SourceName.CPS: _tcps_cps_record(
            {
                "profileId": "12121212-1212-1212-1212-121212121212",
                "_tcps": {"defaultCountry": "CA"},
                "profiles": [{
                    "region": "UsCanada",
                    "contact": {
                        "emailId": "tcps.country@example.com",
                        "firstName": "TCPS",
                        "lastName": "Country",
                    },
                }],
            },
        ),
        SourceName.REWARDS_DB: _record(
            SourceName.REWARDS_DB,
            {
                "ProfileId": "12121212-1212-1212-1212-121212121212",
                "CountryCode": "US",
                "IsActive": True,
                "CrowdTwistID": 12121212,
            },
        ),
        SourceName.CROWD_TWIST: _record(
            SourceName.CROWD_TWIST,
            {
                "third_party_id": "12121212-1212-1212-1212-121212121212",
                "email_address": "tcps.country@example.com",
                "country": "United States",
                "is_active": True,
                "id": 12121212,
                "first_name": "TCPS",
                "last_name": "Country",
            },
        ),
    },
    "case8_missing_source_records": {
        SourceName.CPS: _record(
            SourceName.CPS,
            {
                "profileId": "99999999-9999-9999-9999-999999999999",
                "profiles": [{
                    "region": "UsCanada",
                    "contact": {
                        "emailId": "missing.records@example.com",
                        "firstName": "Viswanath",
                        "lastName": "M",
                    },
                }],
            },
        ),
        SourceName.REWARDS_DB: _missing_record(SourceName.REWARDS_DB),
        SourceName.CROWD_TWIST: _missing_record(SourceName.CROWD_TWIST, http_status=404),
    },

}


def get_mock_case(case_name: str) -> dict[SourceName, SourceRecord]:
    if case_name not in CASES:
        raise ValueError(f"Unknown mock case: {case_name}")
    return {source: record.model_copy(deep=True) for source, record in CASES[case_name].items()}

"""Managed batch defaults and hard safety limits.

Customer Support, Business and Technical use the managed 8 source / 2 Dell AIA
profile. Admin may tune a batch within the same tested bounds (1-8 source and
1-2 Dell AIA workers) through the authenticated .NET boundary. Python clamps
all received values to these limits.
"""
from __future__ import annotations

SOURCE_PARALLEL_WORKERS = 8
DELL_AIA_PARALLEL_WORKERS = 2
INCLUDE_GROUPED_DELL_AIA = True


def fixed_batch_profile() -> tuple[int, int, bool]:
    return SOURCE_PARALLEL_WORKERS, DELL_AIA_PARALLEL_WORKERS, INCLUDE_GROUPED_DELL_AIA

from __future__ import annotations

import asyncio
import uuid
from time import perf_counter

from .api_knowledge import ApiKnowledgeBase
from .comparator import compare_records
from .connectors import CPSConnector, CrowdTwistConnector, RewardsDBConnector
from .identity_resolution import resolve_crowd_twist_user
from .field_mapping import canonicalize, load_field_map
from .mock_data import get_mock_case
from .models import DisparityReport, SearchType, SourceName, SourceRecord
from .settings import Settings, load_settings
from .suggestions import build_correction_suggestions
from .use_cases import UseCaseEngine


def _source_display(source: SourceName) -> str:
    return {
        SourceName.CPS: "CPS",
        SourceName.REWARDS_DB: "Rewards DB",
        SourceName.CROWD_TWIST: "CrowdTwist",
    }[source]


def _count_phrase(count: int, singular: str, plural: str | None = None) -> str:
    return f"{count} {singular if count == 1 else (plural or singular + 's')}"


class DisparityPipeline:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self.field_map = load_field_map(self.settings.field_map_path)

    async def collect_source_records(self, search_type: SearchType, search_value: str) -> dict[SourceName, SourceRecord]:
        """Collect and canonicalize all linked source records for one identifier.

        This is the shared deterministic identity-resolution path used by both
        full analysis and source-specific Agentic chat reads.
        """
        records = get_mock_case(self.settings.mock_case) if self.settings.use_mock_sources else await self._collect_real(search_type, search_value)
        for source, record in records.items():
            record.canonical = canonicalize(record.raw, source, self.field_map)
        return records

    async def run(self, search_type: SearchType, search_value: str) -> DisparityReport:
        pipeline_started = perf_counter()

        collection_started = perf_counter()
        if self.settings.use_mock_sources:
            records = get_mock_case(self.settings.mock_case)
        else:
            records = await self._collect_real(search_type, search_value)
        source_collection_wall_ms = int((perf_counter() - collection_started) * 1000)

        canonical_started = perf_counter()
        for source, record in records.items():
            record.canonical = canonicalize(record.raw, source, self.field_map)
        canonicalization_ms = int((perf_counter() - canonical_started) * 1000)

        comparison_started = perf_counter()
        verdicts = compare_records(records, self.field_map, self.settings)
        comparison_ms = int((perf_counter() - comparison_started) * 1000)

        suggestions_started = perf_counter()
        suggestions = build_correction_suggestions(verdicts, records)
        suggestion_generation_ms = int((perf_counter() - suggestions_started) * 1000)

        assembly_started = perf_counter()
        actionable_suggestion_count = sum(
            suggestion.recommended_value is not None and not suggestion.requires_manual_review
            for suggestion in suggestions
        )
        manual_review_count = sum(suggestion.requires_manual_review for suggestion in suggestions)
        mismatch_count = sum(
            v.status in {"MISMATCH", "TRUTH_FORMAT_INVALID", "COUNTRY_SOURCE_CONFLICT", "BOOLEAN_REVIEW_REQUIRED"}
            for v in verdicts
        )
        missing_count = sum(v.status == "MISSING" for v in verdicts)
        missing_record_count = sum(not record.status.data_found for record in records.values())
        deferred_attribute_count = sum(
            v.status in {"SOURCE_RECORD_MISSING", "SOURCE_UNAVAILABLE"}
            for v in verdicts
        )
        invalid_format_count = sum(
            v.status in {"INVALID_FORMAT", "TRUTH_FORMAT_INVALID", "BOOLEAN_REVIEW_REQUIRED"}
            for v in verdicts
        )
        unverifiable_count = sum(
            v.status in {"UNVERIFIABLE", "COUNTRY_REVIEW_REQUIRED"}
            for v in verdicts
        )
        data_found = sum(record.status.data_found for record in records.values())

        cps_found = records[SourceName.CPS].status.data_found
        db_found = records[SourceName.REWARDS_DB].status.data_found
        ct_found = records[SourceName.CROWD_TWIST].status.data_found
        if cps_found and db_found and ct_found:
            completeness = "FULL"
            deterministic_summary = (
                f"Complete analysis: data was retrieved from all 3 sources. "
                f"Detected {mismatch_count} mismatched attributes, {missing_count} missing attributes, "
                f"{invalid_format_count} format problems, and {unverifiable_count} unverifiable attributes."
            )
        elif cps_found or db_found:
            completeness = "PARTIAL"
            missing_records = [
                _source_display(source)
                for source, record in records.items()
                if record.status.connected and not record.status.data_found
            ]
            unavailable_sources = [
                _source_display(source)
                for source, record in records.items()
                if not record.status.connected
            ]
            coverage_parts = []
            if missing_records:
                coverage_parts.append(f"no matching member record in {', '.join(missing_records)}")
            if unavailable_sources:
                coverage_parts.append(f"source access unavailable for {', '.join(unavailable_sources)}")
            coverage_text = "; ".join(coverage_parts) or "one or more sources did not return usable data"
            deterministic_summary = (
                f"Partial record coverage: data was retrieved from {data_found}/3 sources; {coverage_text}. "
                "A missing source record is treated as one record-level issue, not as multiple missing field updates. "
                "Detected "
                + _count_phrase(mismatch_count, "mismatched attribute")
                + ", "
                + _count_phrase(missing_count, "missing attribute inside an existing record", "missing attributes inside existing records")
                + ", "
                + _count_phrase(invalid_format_count, "format problem")
                + ", "
                + _count_phrase(unverifiable_count, "unverifiable attribute")
                + ", and "
                + _count_phrase(deferred_attribute_count, "deferred attribute comparison")
                + "."
            )
        else:
            completeness = "NO_AUTHORITATIVE_DATA"
            deterministic_summary = (
                "Analysis incomplete: neither CPS nor Rewards DB returned authoritative data. "
                + ("CrowdTwist data was retrieved, but CrowdTwist is comparison-only. " if ct_found else "")
                + f"Therefore {unverifiable_count} attributes are unverifiable; a zero mismatch count does not mean the records match."
            )

        warnings: list[str] = []
        for source, record in records.items():
            if not record.status.connected:
                warnings.append(
                    f"{source.value} was not reachable or rejected the request; analysis for its attributes may be incomplete."
                )
            elif not record.status.data_found:
                warnings.append(
                    f"{source.value} was reached but returned no matching member record. "
                    "Field-level update suggestions for that source are intentionally suppressed."
                )
        tcps_diagnostics = (records[SourceName.CPS].status.diagnostics or {}).get("tcps_country_lookup") or {}
        if self.settings.tcps_enabled and tcps_diagnostics and not tcps_diagnostics.get("data_found"):
            code = tcps_diagnostics.get("error_code") or "TCPS_COUNTRY_NOT_AVAILABLE"
            hint = tcps_diagnostics.get("diagnostic_hint") or "The tCPS exact country lookup did not return data."
            warnings.append(
                f"Supplemental tCPS country enrichment was not used ({code}). {hint} "
                "Country comparison will fall back to the standard CPS region and approved Rewards DB disambiguation rules."
            )
        if completeness == "NO_AUTHORITATIVE_DATA":
            warnings.append("No correction recommendation should be executed until CPS or Rewards DB is successfully retrieved.")

        report = DisparityReport(
            run_id=f"DDR-{uuid.uuid4().hex[:12].upper()}",
            search_type=search_type,
            search_value=search_value,
            truth_policy=(
                "Default attributes: CPS truth with Rewards DB fallback. Business exceptions: "
                "CrowdTwist ID is authoritative in the CrowdTwist API and Rewards DB is corrected; "
                "Active Status uses OR logic across Rewards DB and CrowdTwist, so the False side changes to True on mismatch; "
                "Country uses CPS as the source of truth whenever CPS supplies a value. The supplemental tCPS Dell Identity "
                "search supplies exact defaultCountry inside CPS evidence and takes priority over a broad CPS region. When tCPS "
                "does not return an exact value and CPS supplies a broad region such as UsCanada, Rewards DB may only disambiguate "
                "an exact code inside the CPS-approved set; it does not replace CPS "
                "as truth. CrowdTwist must store the canonical two-letter ISO code from the uploaded reference. "
                "A source member record that is not found is a record-level onboarding/linkage issue, not a set of missing fields; "
                "field-level updates for that source remain blocked until the record exists and can be retrieved."
            ),
            analysis_completeness=completeness,
            source_status={source: record.status for source, record in records.items()},
            records=records,
            attributes=verdicts,
            mismatch_count=mismatch_count,
            missing_count=missing_count,
            missing_record_count=missing_record_count,
            deferred_attribute_count=deferred_attribute_count,
            invalid_format_count=invalid_format_count,
            unverifiable_count=unverifiable_count,
            deterministic_summary=(
                deterministic_summary
                + f" Generated {actionable_suggestion_count} exact field correction suggestion(s) "
                + f"and {manual_review_count} manual-review or record-remediation item(s)."
            ),
            suggestions=suggestions,
            actionable_suggestion_count=actionable_suggestion_count,
            manual_review_count=manual_review_count,
            warnings=warnings,
        )
        knowledge = ApiKnowledgeBase()
        report.api_knowledge_summary = knowledge.summary()
        report.use_case_recommendations = [
            item.model_dump(mode="json") for item in UseCaseEngine(knowledge).recommend(report)
        ]
        report_assembly_ms = int((perf_counter() - assembly_started) * 1000)

        tcps_latency = tcps_diagnostics.get("latency_ms") if isinstance(tcps_diagnostics, dict) else None
        report.timings = {
            "deterministic_pipeline_ms": int((perf_counter() - pipeline_started) * 1000),
            "source_collection_wall_ms": source_collection_wall_ms,
            "canonicalization_ms": canonicalization_ms,
            "comparison_ms": comparison_ms,
            "suggestion_generation_ms": suggestion_generation_ms,
            "report_assembly_ms": report_assembly_ms,
            "source_latency_ms": {
                "cps_api": records[SourceName.CPS].status.latency_ms,
                "tcps_country_api": tcps_latency,
                "rewards_db": records[SourceName.REWARDS_DB].status.latency_ms,
                "crowd_twist_api": records[SourceName.CROWD_TWIST].status.latency_ms,
            },
            "timing_note": (
                "Source latency values are observed connector latencies. CPS and CrowdTwist may run concurrently, "
                "so source latencies must not be summed to calculate wall-clock time."
            ),
        }
        return report

    async def _collect_real(self, search_type: SearchType, search_value: str) -> dict[SourceName, SourceRecord]:
        cps = CPSConnector(self.settings)
        crowd_twist = CrowdTwistConnector(self.settings)
        rewards_db = RewardsDBConnector(self.settings)

        cps_record, ct_record = await asyncio.gather(
            cps.fetch(search_type, search_value),
            crowd_twist.fetch(search_type, search_value),
        )
        cps_canonical = canonicalize(cps_record.raw, SourceName.CPS, self.field_map)
        ct_canonical = canonicalize(ct_record.raw, SourceName.CROWD_TWIST, self.field_map)
        profile_id = cps_canonical.get("profile_id") or ct_canonical.get("profile_id")

        # Email-originated CrowdTwist resolution is deliberately sequential:
        # Email -> CPS ProfileId -> Rewards DB CrowdTwistID.  The first two
        # attempts can be completed before the database read.
        if search_type == SearchType.EMAIL:
            ct_record = await resolve_crowd_twist_user(
                crowd_twist,
                email=search_value,
                profile_id=str(profile_id) if profile_id else None,
                initial_record=ct_record,
            )
            ct_canonical = canonicalize(ct_record.raw, SourceName.CROWD_TWIST, self.field_map)
            profile_id = cps_canonical.get("profile_id") or ct_canonical.get("profile_id")

        crowd_twist_id = ct_canonical.get("crowd_twist_id")

        # If CPS email lookup fails but CrowdTwist resolves a third_party_id,
        # retry CPS by ProfileId. This is especially useful for gateway/account
        # endpoint variants where email lookup is unavailable.
        should_retry_cps = bool(profile_id and not cps_record.status.data_found)
        same_profile_lookup = search_type == SearchType.PROFILE_ID and str(search_value).casefold() == str(profile_id).casefold()
        if should_retry_cps and not same_profile_lookup:
            initial_status = cps_record.status.model_dump(mode="json")
            retry_record = await cps.fetch(SearchType.PROFILE_ID, str(profile_id))
            retry_record.status.retrieval_method = "profile_id_retry"
            retry_record.status.diagnostics["initial_attempt"] = {
                "stage": initial_status.get("stage"),
                "error_code": initial_status.get("error_code"),
                "http_status": initial_status.get("http_status"),
            }
            if retry_record.status.data_found or not cps_record.status.connected:
                cps_record = retry_record
                cps_canonical = canonicalize(cps_record.raw, SourceName.CPS, self.field_map)
                profile_id = cps_canonical.get("profile_id") or profile_id

        db_record = await rewards_db.fetch(
            search_type,
            search_value,
            resolved_profile_id=str(profile_id) if profile_id else None,
            resolved_crowd_twist_id=int(crowd_twist_id) if crowd_twist_id is not None else None,
        )

        # When Email and ProfileId did not resolve CrowdTwist, use the
        # authoritative CrowdTwistID synchronized in Rewards DB as the final
        # lookup key. Rewards DB is never queried by email alone; it must first
        # have a resolved ProfileId or CrowdTwistID.
        if search_type == SearchType.EMAIL and not ct_record.status.data_found:
            db_canonical = canonicalize(db_record.raw, SourceName.REWARDS_DB, self.field_map)
            db_crowd_twist_id = db_canonical.get("crowd_twist_id")
            if db_crowd_twist_id not in (None, ""):
                ct_record = await resolve_crowd_twist_user(
                    crowd_twist,
                    email=search_value,
                    profile_id=str(profile_id) if profile_id else None,
                    crowd_twist_id=db_crowd_twist_id,
                    initial_record=ct_record,
                )

        return {
            SourceName.CPS: cps_record,
            SourceName.REWARDS_DB: db_record,
            SourceName.CROWD_TWIST: ct_record,
        }

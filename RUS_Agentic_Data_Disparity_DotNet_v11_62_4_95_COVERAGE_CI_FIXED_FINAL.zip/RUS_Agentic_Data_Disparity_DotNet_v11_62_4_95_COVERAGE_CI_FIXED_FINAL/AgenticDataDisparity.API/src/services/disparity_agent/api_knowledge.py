from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
from uuid import UUID

import yaml


@dataclass(frozen=True)
class PayloadValidationResult:
    valid: bool
    errors: list[str]
    normalized_payload: dict[str, Any]


class ApiKnowledgeBase:
    """Static, secret-free API/schema knowledge loaded from the uploaded service source.

    The catalog is deliberately explicit instead of asking an LLM to infer contracts at
    run time. AutoGen may explain or rank the catalog, but endpoint names, payloads,
    required fields, write risk and implementation status remain deterministic.
    """

    def __init__(self, catalog_path: str | Path | None = None) -> None:
        self.catalog_path = Path(catalog_path) if catalog_path else Path(__file__).resolve().parents[2] / "resources" / "api_catalog.yaml"
        if not self.catalog_path.is_absolute() and not self.catalog_path.exists():
            self.catalog_path = Path(__file__).resolve().parents[1] / self.catalog_path
        with self.catalog_path.open("r", encoding="utf-8") as handle:
            self.catalog: dict[str, Any] = yaml.safe_load(handle) or {}
        self.schemas: dict[str, dict[str, Any]] = self.catalog.get("schemas", {})
        self.operations: list[dict[str, Any]] = self.catalog.get("operations", [])
        self._by_id = {str(item["id"]): item for item in self.operations}

    def get_operation(self, operation_id: str) -> dict[str, Any]:
        try:
            return self._by_id[operation_id]
        except KeyError as exc:
            raise KeyError(f"Unknown API operation: {operation_id}") from exc

    def get_schema(self, schema_name: str) -> dict[str, Any]:
        try:
            return self.schemas[schema_name]
        except KeyError as exc:
            raise KeyError(f"Unknown API schema: {schema_name}") from exc

    def resolved_request_schema(self, operation_id: str) -> dict[str, Any] | None:
        operation = self.get_operation(operation_id)
        if operation.get("request_schema_ref"):
            return self.get_schema(str(operation["request_schema_ref"]))
        schema = operation.get("request_schema")
        return schema if isinstance(schema, dict) else None

    def resolved_response_schema(self, operation_id: str) -> dict[str, Any] | None:
        operation = self.get_operation(operation_id)
        if operation.get("response_schema_ref"):
            return self.get_schema(str(operation["response_schema_ref"]))
        schema = operation.get("response_schema")
        return schema if isinstance(schema, dict) else None

    def summary(self) -> dict[str, Any]:
        live = [item for item in self.operations if item.get("implementation_status") == "live"]
        writes = [item for item in self.operations if item.get("risk") == "write"]
        reads = [item for item in self.operations if item.get("risk") == "read_only"]
        dry_run = [item for item in self.operations if item.get("implementation_status") == "dry_run_only"]
        catalog_only = [item for item in self.operations if item.get("implementation_status") == "catalog_only"]
        placeholders = [
            item
            for item in self.operations
            if item.get("implementation_status") in {"placeholder", "legacy_placeholder"}
        ]
        return {
            "catalog_version": self.catalog.get("catalog_version"),
            "generated_from": self.catalog.get("generated_from"),
            "operation_count": len(self.operations),
            "schema_count": len(self.schemas),
            "systems": sorted({str(item.get("system")) for item in self.operations}),
            "read_operation_count": len(reads),
            "write_operation_count": len(writes),
            "live_operation_count": len(live),
            "dry_run_operation_count": len(dry_run),
            "catalog_only_operation_count": len(catalog_only),
            "placeholder_operation_count": len(placeholders),
            "truth_policy": self.catalog.get("truth_policy"),
            "notes": self.catalog.get("notes", []),
        }

    def canonical_operation_rows(self) -> list[dict[str, Any]]:
        """Return a stable machine-readable API contract for UI and .NET clients.

        Earlier builds exposed only title-cased display labels such as ``Operation ID``.
        The sequential test client expected ``operation_id`` and therefore skipped the
        operation-contract and payload-validation checks.  The canonical contract keeps
        snake_case keys while ``operation_rows`` remains available for human tables.
        """
        rows: list[dict[str, Any]] = []
        for operation in self.operations:
            rows.append(
                {
                    "operation_id": operation.get("id"),
                    "system": operation.get("system"),
                    "layer": operation.get("layer"),
                    "method": operation.get("method"),
                    "path": operation.get("path"),
                    "capability": operation.get("capability"),
                    "risk": operation.get("risk"),
                    "status": operation.get("implementation_status"),
                    "approval_required": bool(operation.get("approval_required")),
                }
            )
        return rows

    def operation_rows(self) -> list[dict[str, Any]]:
        """Return presentation-oriented rows retained for backward compatibility."""
        rows: list[dict[str, Any]] = []
        for operation in self.operations:
            rows.append(
                {
                    "Operation ID": operation.get("id"),
                    "System": operation.get("system"),
                    "Layer": operation.get("layer"),
                    "Method": operation.get("method"),
                    "Path": operation.get("path"),
                    "Capability": operation.get("capability"),
                    "Risk": operation.get("risk"),
                    "Status": operation.get("implementation_status"),
                    "Approval required": bool(operation.get("approval_required")),
                }
            )
        return rows

    def validate_payload(self, operation_id: str, payload: dict[str, Any]) -> PayloadValidationResult:
        schema = self.resolved_request_schema(operation_id)
        if schema is None:
            return PayloadValidationResult(True, [], dict(payload))
        errors: list[str] = []

        if schema.get("type") == "array":
            if not isinstance(payload, list):
                return PayloadValidationResult(False, ["Payload must be an array."], {})
            return PayloadValidationResult(True, [], {"items": payload})

        normalized = dict(payload)

        if schema.get("type") not in {None, "object"}:
            return PayloadValidationResult(True, [], normalized)

        required = schema.get("required", []) or []
        for field in required:
            if field not in payload or payload[field] in (None, ""):
                errors.append(f"Missing required field: {field}")

        allowed_properties = schema.get("allowed_properties")
        if allowed_properties:
            unknown = sorted(set(payload) - set(allowed_properties))
            if unknown:
                errors.append(f"Unsupported payload field(s): {', '.join(unknown)}")

        properties = schema.get("properties", {}) or {}
        for field_name, value in payload.items():
            field_schema = properties.get(field_name)
            if field_schema is None:
                if properties and not allowed_properties:
                    errors.append(f"Unknown field: {field_name}")
                continue
            self._validate_value(field_name, value, field_schema, errors)

        return PayloadValidationResult(not errors, errors, normalized)

    @staticmethod
    def _validate_value(field_name: str, value: Any, schema: dict[str, Any], errors: list[str]) -> None:
        if value is None:
            expected = schema.get("type")
            if isinstance(expected, list) and "null" in expected:
                return
            if schema.get("optional"):
                return
            errors.append(f"{field_name} cannot be null.")
            return

        expected = schema.get("type")
        expected_types = set(expected if isinstance(expected, list) else [expected])
        type_ok = True
        if "string" in expected_types and isinstance(value, str):
            type_ok = True
        elif "integer" in expected_types and isinstance(value, int) and not isinstance(value, bool):
            type_ok = True
        elif "boolean" in expected_types and isinstance(value, bool):
            type_ok = True
        elif "object" in expected_types and isinstance(value, dict):
            type_ok = True
        elif "array" in expected_types and isinstance(value, list):
            type_ok = True
        elif expected in (None, []) or not expected_types:
            type_ok = True
        else:
            type_ok = False
        if not type_ok:
            errors.append(f"{field_name} has the wrong type; expected {expected}.")
            return

        enum = schema.get("enum")
        if enum is not None and value not in enum:
            errors.append(f"{field_name} must be one of: {', '.join(map(str, enum))}.")

        const = schema.get("const")
        if const is not None and value != const:
            errors.append(f"{field_name} must equal {const!r}.")

        if schema.get("format") == "email" and isinstance(value, str):
            if "@" not in value or value.startswith("@") or value.endswith("@"):
                errors.append(f"{field_name} is not a valid email address.")
        if schema.get("format") == "uuid" and isinstance(value, str):
            try:
                UUID(value)
            except ValueError:
                errors.append(f"{field_name} is not a valid UUID.")

    def safe_catalog_for_agent(self) -> dict[str, Any]:
        """Compact catalog representation suitable for an LLM prompt."""
        return {
            "catalog_version": self.catalog.get("catalog_version"),
            "truth_policy": self.catalog.get("truth_policy"),
            "operations": [
                {
                    **({"operation_id": item.get("id")} if item.get("id") is not None else {}),
                    **{
                    key: item.get(key)
                    for key in (
                        "id",
                        "system",
                        "method",
                        "path",
                        "capability",
                        "risk",
                        "implementation_status",
                        "approval_required",
                        "notes",
                    )
                    if item.get(key) is not None
                    },
                }
                for item in self.operations
            ],
            "schemas": self.schemas,
        }

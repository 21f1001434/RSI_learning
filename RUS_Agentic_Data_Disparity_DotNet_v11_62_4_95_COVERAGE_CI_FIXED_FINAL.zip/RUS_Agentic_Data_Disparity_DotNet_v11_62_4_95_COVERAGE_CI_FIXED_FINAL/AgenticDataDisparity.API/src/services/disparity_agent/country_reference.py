from __future__ import annotations

import csv
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Iterable


def _key(value: object) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").casefold())


@dataclass(frozen=True)
class CountryMatch:
    code: str | None
    candidates: frozenset[str]
    kind: str
    display_name: str | None = None


class CrowdTwistCountryReference:
    """Country-name/ISO resolver grounded in the uploaded CrowdTwist reference CSV.

    The CSV is used as the canonical country-code vocabulary for values written to
    CrowdTwist. CPS remains the country source of truth whenever CPS supplies a
    value. Broad CPS market labels such as ``UsCanada`` resolve to an approved
    candidate set; Rewards DB may disambiguate the exact ISO code only within that
    CPS-approved set and never replaces CPS as the truth source.
    """

    BROAD_REGIONS: dict[str, frozenset[str]] = {
        "uscanada": frozenset({"US", "CA"}),
        "usandcanada": frozenset({"US", "CA"}),
        "unitedstatescanada": frozenset({"US", "CA"}),
        "unitedstatesandcanada": frozenset({"US", "CA"}),
        "northamericauscanada": frozenset({"US", "CA"}),
    }

    EXPLICIT_ALIASES: dict[str, str] = {
        "usa": "US",
        "unitedstatesofamerica": "US",
        "unitedstate": "US",
        "u s a": "US",
        "uk": "GB",
        "greatbritain": "GB",
        "uae": "AE",
        "cnanada": "CA",  # common source typo observed in test descriptions
    }

    def __init__(self, csv_path: Path) -> None:
        self.csv_path = csv_path
        self.name_to_code: dict[str, str] = {}
        self.code_to_name: dict[str, str] = {}
        self.city_ids: dict[str, dict[str, str | None]] = {}
        self._load()

    def _load(self) -> None:
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            required = {"COUNTRY_NAME", "COUNTRY_ISO_3166_CODE"}
            missing = required.difference(reader.fieldnames or [])
            if missing:
                raise ValueError(
                    f"CrowdTwist country reference is missing required columns: {sorted(missing)}"
                )
            for row in reader:
                name = str(row.get("COUNTRY_NAME") or "").strip()
                code = str(row.get("COUNTRY_ISO_3166_CODE") or "").strip().upper()
                if not name or not re.fullmatch(r"[A-Z]{2}", code):
                    continue
                self.name_to_code[_key(name)] = code
                self.name_to_code[_key(code)] = code
                self.code_to_name.setdefault(code, name)
                self.city_ids[code] = {
                    "city_id_sb": str(row.get("CITY_ID SB") or "").strip() or None,
                    "city_id_us1": str(row.get("CITY_ID US1") or "").strip() or None,
                    "dell_default": str(row.get("Dell") or "").strip() or None,
                }

        for alias, code in self.EXPLICIT_ALIASES.items():
            if code in self.code_to_name:
                self.name_to_code[_key(alias)] = code

    def match(self, value: object) -> CountryMatch:
        token = _key(value)
        if not token:
            return CountryMatch(code=None, candidates=frozenset(), kind="missing")
        if token in self.BROAD_REGIONS:
            return CountryMatch(
                code=None,
                candidates=self.BROAD_REGIONS[token],
                kind="broad_region",
                display_name=str(value).strip(),
            )
        code = self.name_to_code.get(token)
        if code:
            return CountryMatch(
                code=code,
                candidates=frozenset({code}),
                kind="exact",
                display_name=self.code_to_name.get(code),
            )
        return CountryMatch(code=None, candidates=frozenset(), kind="unknown", display_name=str(value).strip())


    def is_canonical_code(self, value: object, expected_code: str | None = None) -> bool:
        """Return True only when the raw value is already stored as an ISO alpha-2 code.

        Country names such as ``United States`` can be recognized semantically, but
        CrowdTwist must store the canonical two-letter code (``US``).
        """
        raw = str(value or "").strip().upper()
        if not re.fullmatch(r"[A-Z]{2}", raw):
            return False
        if expected_code is not None and raw != str(expected_code).upper():
            return False
        return self.contains_code(raw)

    def exact_code(self, value: object) -> str | None:
        return self.match(value).code

    def candidate_codes(self, value: object) -> frozenset[str]:
        return self.match(value).candidates

    def country_name(self, code: str | None) -> str | None:
        return self.code_to_name.get(str(code or "").upper())

    def metadata(self, code: str | None) -> dict[str, str | None]:
        return dict(self.city_ids.get(str(code or "").upper(), {}))

    def contains_code(self, code: object) -> bool:
        return str(code or "").upper() in self.code_to_name

    def codes(self) -> Iterable[str]:
        return self.code_to_name.keys()


@lru_cache(maxsize=4)
def get_country_reference(csv_path: str | Path | None = None) -> CrowdTwistCountryReference:
    path = (
        Path(csv_path)
        if csv_path is not None
        else Path(__file__).resolve().parents[2] / "resources" / "crowdtwist_country_reference_2024.csv"
    )
    return CrowdTwistCountryReference(path.resolve())

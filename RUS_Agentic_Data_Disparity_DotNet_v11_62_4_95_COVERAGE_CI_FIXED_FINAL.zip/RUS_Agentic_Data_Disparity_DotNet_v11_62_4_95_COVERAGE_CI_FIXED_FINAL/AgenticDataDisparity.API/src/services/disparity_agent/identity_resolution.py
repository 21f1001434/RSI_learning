from __future__ import annotations

from typing import Any

from .connectors.crowd_twist import CrowdTwistConnector
from .models import SearchType, SourceRecord


def _attempt_row(search_type: SearchType, value: str, record: SourceRecord) -> dict[str, Any]:
    status = record.status
    return {
        "key": {
            SearchType.EMAIL: "Email",
            SearchType.PROFILE_ID: "ProfileId",
            SearchType.CROWD_TWIST_ID: "CrowdTwistID",
        }[search_type],
        "search_type": search_type.value,
        "identifier_value": value,
        "attempted": True,
        "connected": bool(status.connected),
        "data_found": bool(status.data_found),
        "http_status": status.http_status,
        "latency_ms": status.latency_ms,
        "error_code": status.error_code,
        "stage": status.stage,
    }


def _existing_attempts(record: SourceRecord | None) -> list[dict[str, Any]]:
    if record is None:
        return []
    diagnostics = record.status.diagnostics or {}
    rows = diagnostics.get("identifier_lookup_sequence") or []
    return [dict(item) for item in rows if isinstance(item, dict)]


def _already_attempted(attempts: list[dict[str, Any]], search_type: SearchType, value: str) -> bool:
    needle_type = search_type.value.casefold()
    needle_value = str(value).strip().casefold()
    return any(
        str(item.get("search_type") or "").casefold() == needle_type
        and str(item.get("identifier_value") or "").strip().casefold() == needle_value
        for item in attempts
    )


def _decorate(record: SourceRecord, attempts: list[dict[str, Any]]) -> SourceRecord:
    status = record.status
    diagnostics = dict(status.diagnostics or {})
    diagnostics.update(
        {
            "identifier_lookup_sequence": attempts,
            "lookup_order": ["Email", "ProfileId", "CrowdTwistID"],
            "attempted_count": len(attempts),
            "fallback_used": len(attempts) > 1,
        }
    )

    matched = next((item for item in reversed(attempts) if item.get("data_found")), None)
    if matched:
        key = str(matched.get("key") or "Email")
        lookup_result = {
            "Email": "email_match",
            "ProfileId": "profile_id_fallback_match",
            "CrowdTwistID": "crowd_twist_id_fallback_match",
        }.get(key, "match")
        retrieval_method = {
            "Email": "email",
            "ProfileId": "profile_id_fallback",
            "CrowdTwistID": "crowd_twist_id_fallback",
        }.get(key, "identifier_fallback")
    elif status.connected:
        lookup_result = "no_value_found_after_identifier_sequence"
        retrieval_method = "not_found_after_identifier_sequence"
    else:
        lookup_result = "source_unavailable"
        retrieval_method = status.retrieval_method or "source_unavailable"

    diagnostics["lookup_result"] = lookup_result
    status.diagnostics = diagnostics
    status.retrieval_method = retrieval_method
    observed_latencies = [int(item.get("latency_ms") or 0) for item in attempts]
    status.latency_ms = sum(observed_latencies) if observed_latencies else status.latency_ms
    if status.connected and not status.data_found:
        status.diagnostic_hint = (
            "CrowdTwist was searched sequentially by Email, then CPS ProfileId when available, "
            "then Rewards DB CrowdTwistID when available. No user matched any resolved identifier."
        )
    return record


async def resolve_crowd_twist_user(
    connector: CrowdTwistConnector,
    *,
    email: str,
    profile_id: str | None = None,
    crowd_twist_id: int | str | None = None,
    initial_record: SourceRecord | None = None,
) -> SourceRecord:
    """Resolve a CrowdTwist user using the approved sequential identifier chain.

    Order for an email-originated request:
      1. Email.
      2. CPS ProfileId, only when the email lookup returned no record.
      3. Rewards DB CrowdTwistID, only when earlier CrowdTwist lookups returned no record.

    A connector outage/authentication failure stops the chain because retrying the
    same unavailable source with another identifier cannot provide trustworthy
    evidence. The function is safe to call again after Rewards DB has supplied a
    CrowdTwistID; prior attempts are retained and are not repeated.
    """

    attempts = _existing_attempts(initial_record)
    current = initial_record

    if current is None:
        current = await connector.fetch(SearchType.EMAIL, email)
        attempts.append(_attempt_row(SearchType.EMAIL, email, current))
    elif not attempts:
        # The caller supplied an email lookup performed outside this helper.
        attempts.append(_attempt_row(SearchType.EMAIL, email, current))

    candidates: list[tuple[SearchType, str]] = []
    if profile_id not in (None, ""):
        candidates.append((SearchType.PROFILE_ID, str(profile_id)))
    if crowd_twist_id not in (None, ""):
        candidates.append((SearchType.CROWD_TWIST_ID, str(crowd_twist_id)))

    for search_type, value in candidates:
        if current.status.data_found:
            break
        if not current.status.connected:
            break
        if _already_attempted(attempts, search_type, value):
            continue
        current = await connector.fetch(search_type, value)
        attempts.append(_attempt_row(search_type, value, current))

    return _decorate(current, attempts)

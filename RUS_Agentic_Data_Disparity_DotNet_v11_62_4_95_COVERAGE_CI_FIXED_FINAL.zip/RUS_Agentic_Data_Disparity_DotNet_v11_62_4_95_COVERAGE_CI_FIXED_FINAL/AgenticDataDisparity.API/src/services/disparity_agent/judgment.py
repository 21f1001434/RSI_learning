from __future__ import annotations

from copy import deepcopy
from typing import Any


_ACCEPTED = {
    "ACCEPT", "ACCEPTED", "APPROVE", "APPROVED", "VALID", "PASS", "PASSED",
    "SUPPORT", "SUPPORTED", "CONSISTENT", "TRUE", "OK",
    "SUPPORTED_WITH_OUTPUT_NORMALIZATION",
}
_PARTIAL = {
    "PARTIAL", "PARTIALLY_SUPPORTED", "PARTIAL_MATCH", "PARTIALLY_VALID",
    "SUPPORTED_WITH_CORRECTIONS", "ACCEPT_WITH_CORRECTIONS", "NEEDS_CORRECTION",
    "CORRECTABLE", "MIXED",
}
_REJECTED = {
    "REJECT", "REJECTED", "FAIL", "FAILED", "INVALID", "UNSUPPORTED",
    "FALSE", "NOT_SUPPORTED", "HALLUCINATED",
}


def canonical_judge_verdict(value: Any) -> str:
    """Map Dell AIA judge wording to one stable business verdict."""
    raw = str(value or "").strip().upper().replace("-", "_").replace(" ", "_")
    if raw in _PARTIAL or raw.startswith("PARTIAL") or "WITH_CORRECTION" in raw:
        return "PARTIAL"
    if raw in _ACCEPTED or raw.startswith("ACCEPT") or raw.startswith("APPROV"):
        return "ACCEPTED"
    if raw in _REJECTED or raw.startswith("REJECT") or raw.startswith("FAIL"):
        return "REJECTED"
    return "REVIEW_REQUIRED"


def final_content_status(verdict: str) -> str:
    verdict = canonical_judge_verdict(verdict)
    if verdict == "ACCEPTED":
        return "ANALYST_ACCEPTED"
    if verdict == "PARTIAL":
        return "CORRECTED_BY_JUDGE"
    if verdict == "REJECTED":
        return "DETERMINISTIC_FALLBACK_AFTER_REJECTION"
    return "DETERMINISTIC_FALLBACK_PENDING_REVIEW"


def _source_value(value: Any) -> str | None:
    if value is None:
        return None
    if hasattr(value, "value"):
        return str(value.value)
    return str(value)


def _as_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    return {}


def _deterministic_analysis(report: dict[str, Any], *, summary: str, verdict: str) -> dict[str, Any]:
    attributes = list(report.get("attributes") or [])
    suggestions = list(report.get("suggestions") or [])

    wrong_attributes: list[dict[str, Any]] = []
    missing_attributes: list[dict[str, Any]] = []
    deferred_attributes: list[dict[str, Any]] = []
    format_issues: list[dict[str, Any]] = []
    unverifiable: list[dict[str, Any]] = []

    for raw in attributes:
        item = _as_dict(raw)
        wrong = [_source_value(x) for x in item.get("wrong_sources") or []]
        missing = [_source_value(x) for x in item.get("missing_sources") or []]
        unavailable = [_source_value(x) for x in item.get("unavailable_sources") or []]
        if wrong:
            wrong_attributes.append({
                "attribute": item.get("attribute"),
                "label": item.get("label"),
                "wrong_sources": wrong,
                "truth_source": _source_value(item.get("truth_source")),
                "expected_value": item.get("truth_value"),
                "status": item.get("status"),
            })
        if missing:
            missing_attributes.append({
                "attribute": item.get("attribute"),
                "missing_sources": missing,
            })
        if unavailable:
            deferred_attributes.append({
                "attribute": item.get("attribute"),
                "status": item.get("status"),
                "unavailable_sources": unavailable,
            })
        status = str(item.get("status") or "")
        if "FORMAT" in status:
            format_issues.append({
                "attribute": item.get("attribute"),
                "status": status,
                "explanation": item.get("explanation"),
            })
        if status == "UNVERIFIABLE":
            unverifiable.append({
                "attribute": item.get("attribute"),
                "explanation": item.get("explanation"),
            })

    source_health: dict[str, Any] = {}
    for name, raw_status in (report.get("source_status") or {}).items():
        status = _as_dict(raw_status)
        source_health[_source_value(name) or str(name)] = {
            "connected": bool(status.get("connected")),
            "data_found": bool(status.get("data_found")),
            "stage": status.get("stage"),
            "error_code": status.get("error_code"),
            "http_status": status.get("http_status"),
            "latency_ms": status.get("latency_ms"),
            "endpoint_host": status.get("endpoint_host"),
        }

    correction_plan = [_as_dict(item) for item in suggestions]
    recommended_actions = [
        str(item.get("recommendation"))
        for item in correction_plan
        if item.get("recommendation")
    ]

    status = final_content_status(verdict)
    caveats = list(report.get("warnings") or [])
    if verdict == "PARTIAL":
        caveats.append("The original Dell AIA analyst narrative was replaced with the judge-corrected, deterministic result.")
    else:
        caveats.append("The original Dell AIA analyst narrative was suppressed because it was not approved by the independent judge.")

    return {
        "summary": summary or report.get("deterministic_summary") or "Deterministic analysis completed.",
        "wrong_attributes": wrong_attributes,
        "missing_attributes": missing_attributes,
        "deferred_attributes_due_to_missing_records": deferred_attributes,
        "format_issues": format_issues,
        "unverifiable_attributes": unverifiable,
        "source_health": source_health,
        "correction_plan": correction_plan,
        "recommended_actions": recommended_actions,
        "priority": "CRITICAL" if int(report.get("actionable_suggestion_count") or 0) else "REVIEW",
        "confidence": "HIGH_FOR_DETERMINISTIC_VALUES",
        "caveats": caveats,
        "status": status,
        "publication_status": status,
        "judge_verdict": canonical_judge_verdict(verdict),
        "analyst_content_published": False,
    }


def enforce_judge_on_report_dict(report: dict[str, Any]) -> dict[str, Any]:
    """Return a copy with the independent judge verdict enforced on published AI content.

    The Dell AIA execution result and the judge's content verdict are kept separate:
    a model call can succeed technically while its narrative is corrected or rejected.
    """
    out = deepcopy(report)
    judge = dict(out.get("judge_result") or {})
    raw_verdict = judge.get("raw_verdict") or judge.get("verdict") or judge.get("status")
    verdict = canonical_judge_verdict(raw_verdict)
    disposition = final_content_status(verdict)

    judge["raw_verdict"] = str(raw_verdict or "")
    judge["verdict"] = verdict
    judge["content_disposition"] = disposition
    judge["status"] = "SUCCESS" if verdict != "REVIEW_REQUIRED" else "REVIEW_REQUIRED"
    out["judge_result"] = judge

    original_analysis = dict(out.get("ai_analysis") or {})
    if verdict == "ACCEPTED":
        original_analysis["publication_status"] = disposition
        original_analysis["judge_verdict"] = verdict
        original_analysis["analyst_content_published"] = True
        out["ai_analysis"] = original_analysis
    else:
        corrected_summary = str(judge.get("corrected_summary") or out.get("deterministic_summary") or "")
        out["ai_analysis"] = _deterministic_analysis(
            out,
            summary=corrected_summary,
            verdict=verdict,
        )

    execution = dict(out.get("ai_execution") or {})
    execution.setdefault("execution_status", execution.get("status") or "UNKNOWN")
    execution["judge_verdict"] = verdict
    execution["final_content_status"] = disposition
    execution["analyst_content_published"] = verdict == "ACCEPTED"
    execution["final_content_publishable"] = True
    execution["judge_enforcement_applied"] = True
    judge_agent = dict(execution.get("judge_agent") or {})
    judge_agent["verdict"] = verdict
    judge_agent["content_disposition"] = disposition
    execution["judge_agent"] = judge_agent
    out["ai_execution"] = execution
    return out

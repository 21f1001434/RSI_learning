from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class SourceName(str, Enum):
    CPS = "cps"
    REWARDS_DB = "rewards_db"
    CROWD_TWIST = "crowd_twist"


class SearchType(str, Enum):
    EMAIL = "email"
    PROFILE_ID = "profileid"
    CROWD_TWIST_ID = "crowdtwistid"


class SourceStatus(BaseModel):
    source: SourceName
    connected: bool
    data_found: bool = False
    latency_ms: int | None = None
    error: str | None = None
    retrieval_method: str = "direct"
    stage: str | None = None
    error_code: str | None = None
    http_status: int | None = None
    endpoint_host: str | None = None
    diagnostic_hint: str | None = None
    diagnostics: dict[str, Any] = Field(default_factory=dict)


class SourceRecord(BaseModel):
    source: SourceName
    status: SourceStatus
    raw: dict[str, Any] | None = None
    canonical: dict[str, Any] = Field(default_factory=dict)


class AttributeObservation(BaseModel):
    source: SourceName
    supported: bool
    present: bool
    source_connected: bool = True
    record_found: bool = True
    raw_value: Any = None
    normalized_value: Any = None
    valid_format: bool = True
    normalization_note: str | None = None


class AttributeVerdict(BaseModel):
    attribute: str
    label: str
    truth_source: SourceName | None = None
    truth_value: Any = None
    status: str
    observations: dict[SourceName, AttributeObservation]
    wrong_sources: list[SourceName] = Field(default_factory=list)
    missing_sources: list[SourceName] = Field(default_factory=list)
    unavailable_sources: list[SourceName] = Field(default_factory=list)
    explanation: str = ""


class CorrectionSuggestion(BaseModel):
    suggestion_id: str
    attribute: str
    label: str
    action: str
    scope: str = "ATTRIBUTE"
    target_source: SourceName | None = None
    current_value: Any = None
    recommended_value: Any = None
    truth_source: SourceName | None = None
    priority: str = "MEDIUM"
    confidence: str = "HIGH"
    automation_eligible: bool = False
    requires_manual_review: bool = False
    reason: str
    recommendation: str


class DisparityReport(BaseModel):
    run_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    search_type: SearchType
    search_value: str
    truth_policy: str
    analysis_completeness: str = "UNKNOWN"
    source_status: dict[SourceName, SourceStatus]
    records: dict[SourceName, SourceRecord]
    attributes: list[AttributeVerdict]
    mismatch_count: int
    missing_count: int
    missing_record_count: int = 0
    deferred_attribute_count: int = 0
    invalid_format_count: int
    unverifiable_count: int
    deterministic_summary: str
    suggestions: list[CorrectionSuggestion] = Field(default_factory=list)
    actionable_suggestion_count: int = 0
    manual_review_count: int = 0
    ai_analysis: dict[str, Any] = Field(default_factory=dict)
    judge_result: dict[str, Any] = Field(default_factory=dict)
    ai_execution: dict[str, Any] = Field(default_factory=lambda: {"status": "NOT_RUN"})
    mcp_execution: dict[str, Any] = Field(default_factory=lambda: {"status": "NOT_RUN"})
    timings: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    api_knowledge_summary: dict[str, Any] = Field(default_factory=dict)
    use_case_recommendations: list[dict[str, Any]] = Field(default_factory=list)

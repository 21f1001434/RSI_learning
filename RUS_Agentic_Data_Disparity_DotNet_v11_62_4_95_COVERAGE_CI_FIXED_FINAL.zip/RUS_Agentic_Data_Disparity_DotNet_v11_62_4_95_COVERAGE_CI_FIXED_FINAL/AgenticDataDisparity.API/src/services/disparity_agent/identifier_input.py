from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable

from .models import SearchType

# Deliberately accept any canonical hexadecimal GUID. Enterprise Profile IDs are
# not guaranteed to encode an RFC version nibble that matches public UUID rules.
EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b")
PROFILE_ID_RE = re.compile(r"(?i)\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b")
CROWD_TWIST_LABELED_RE = re.compile(
    r"(?i)\b(?:crowd\s*twist|crowdtwist|ct)\s*(?:id|identifier|member\s*id)?\s*[:=#\-]?\s*(\d{1,20})\b"
)
BARE_CROWD_TWIST_ID_RE = re.compile(r"(?<!\d)(\d{6,20})(?!\d)")
REFERENCE_RE = re.compile(
    r"(?i)\b(?:above|same\s+(?:id|identifier|member)|that\s+(?:id|identifier|member)|"
    r"this\s+(?:id|identifier|member)|previous\s+(?:id|identifier|member)|it)\b"
)
ANALYSIS_OR_READ_RE = re.compile(
    r"(?i)\b(?:analy[sz]e|analysis|compare|check|inspect|validate|run|fetch|get|show|lookup|"
    r"search|retrieve|extract|pull|collect|result|source|cps|rewards\s*db|crowd\s*twist|crowdtwist|"
    r"update|change|changes|apply|modify|correct|replace|write|execute|perform)\b"
)


@dataclass(frozen=True)
class IdentifierMatch:
    search_type: SearchType
    value: str
    position: int
    origin: str

    @property
    def label(self) -> str:
        return {
            SearchType.EMAIL: "Email",
            SearchType.PROFILE_ID: "Profile ID",
            SearchType.CROWD_TWIST_ID: "CrowdTwist ID",
        }[self.search_type]

    def as_dict(self) -> dict[str, str]:
        return {
            "search_type": self.search_type.value,
            "value": self.value,
            "label": self.label,
            "origin": self.origin,
        }




def _bare_crowd_twist_identifier(text: str) -> IdentifierMatch | None:
    """Recognize a bare CrowdTwist ID in a fresh-session command.

    A standalone 6-20 digit value is treated as a CrowdTwist member ID because
    the Agentic intake contract explicitly supports pasting Email, Profile ID,
    or CrowdTwist ID with no label.  We also accept a numeric ID at the start of
    an analysis/update command (for example ``239251935 change first name to X``).
    Numeric replacement values after ``to``/``as`` are deliberately *not*
    inferred as member identifiers.
    """
    raw = str(text or "").strip()
    if not raw:
        return None
    if re.fullmatch(r"\d{6,20}", raw):
        return IdentifierMatch(SearchType.CROWD_TWIST_ID, raw, 0, "message_bare_crowd_twist_id")

    prefix = re.match(r"^\s*(\d{6,20})\b", raw)
    if prefix and ANALYSIS_OR_READ_RE.search(raw[prefix.end():]):
        return IdentifierMatch(
            SearchType.CROWD_TWIST_ID, prefix.group(1), prefix.start(1), "message_bare_crowd_twist_id"
        )

    # Natural phrasing may put the label first and the value later, e.g.
    # "For this CrowdTwist ID do the analysis 239251935".  Accept that only
    # for analysis/read language.  Do not reinterpret a field-write form such
    # as "change CrowdTwist ID to 239251935" as a member selector.
    if re.search(r"(?i)\b(?:crowd\s*twist|crowdtwist|ct)\s*(?:id|identifier|member\s*id)\b", raw):
        direct_field_write = re.search(
            r"(?i)\b(?:change|update|set|correct|replace|modify|fix)\s+(?:the\s+)?(?:crowd\s*twist|crowdtwist|ct)\s*id\b.*\b(?:to|as)\s+\d{6,20}\b",
            raw,
        )
        numeric = list(BARE_CROWD_TWIST_ID_RE.finditer(raw))
        if not direct_field_write and len(numeric) == 1 and ANALYSIS_OR_READ_RE.search(raw):
            match = numeric[0]
            return IdentifierMatch(
                SearchType.CROWD_TWIST_ID, match.group(1), match.start(1), "message_contextual_crowd_twist_id"
            )
    return None

def _dedupe(matches: Iterable[IdentifierMatch]) -> list[IdentifierMatch]:
    result: list[IdentifierMatch] = []
    seen: set[tuple[str, str]] = set()
    for item in sorted(matches, key=lambda value: value.position):
        key = (item.search_type.value, item.value.casefold())
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def extract_identifiers(text: str) -> list[IdentifierMatch]:
    value = str(text or "")
    matches: list[IdentifierMatch] = []
    for match in EMAIL_RE.finditer(value):
        matches.append(IdentifierMatch(SearchType.EMAIL, match.group(0), match.start(), "message"))
    for match in PROFILE_ID_RE.finditer(value):
        matches.append(IdentifierMatch(SearchType.PROFILE_ID, match.group(0).upper(), match.start(), "message"))
    for match in CROWD_TWIST_LABELED_RE.finditer(value):
        matches.append(IdentifierMatch(SearchType.CROWD_TWIST_ID, match.group(1), match.start(1), "message"))
    bare_crowd_twist = _bare_crowd_twist_identifier(value)
    if bare_crowd_twist is not None:
        matches.append(bare_crowd_twist)
    return _dedupe(matches)


def choose_identifier(text: str, matches: list[IdentifierMatch]) -> IdentifierMatch | None:
    if not matches:
        return None
    lower = str(text or "").casefold()
    if "profile" in lower:
        selected = next((item for item in matches if item.search_type == SearchType.PROFILE_ID), None)
        if selected:
            return selected
    if "crowd" in lower or re.search(r"(?i)\bct\s*(?:id|identifier)?\b", text or ""):
        selected = next((item for item in matches if item.search_type == SearchType.CROWD_TWIST_ID), None)
        if selected:
            return selected
    if "email" in lower:
        selected = next((item for item in matches if item.search_type == SearchType.EMAIL), None)
        if selected:
            return selected
    return matches[0]


def _from_facts(facts: dict[str, Any], preferred: SearchType | None = None) -> IdentifierMatch | None:
    bundle = facts.get("last_identity_bundle") or {}
    if isinstance(bundle, dict):
        order = [preferred] if preferred else []
        order.extend([SearchType.EMAIL, SearchType.PROFILE_ID, SearchType.CROWD_TWIST_ID])
        keys = {
            SearchType.EMAIL: "email",
            SearchType.PROFILE_ID: "profile_id",
            SearchType.CROWD_TWIST_ID: "crowd_twist_id",
        }
        checked: set[SearchType] = set()
        for search_type in order:
            if search_type is None or search_type in checked:
                continue
            checked.add(search_type)
            value = bundle.get(keys[search_type])
            if value not in (None, ""):
                normalized = str(value).upper() if search_type == SearchType.PROFILE_ID else str(value)
                return IdentifierMatch(search_type, normalized, -1, "session_identity_bundle")

    stored = facts.get("last_identifier")
    if isinstance(stored, dict):
        try:
            search_type = SearchType(str(stored.get("search_type") or ""))
        except ValueError:
            return None
        value = str(stored.get("value") or "").strip()
        if value:
            if preferred is None or search_type == preferred:
                return IdentifierMatch(search_type, value, -1, "session_last_identifier")
    return None


def resolve_identifier(text: str, facts: dict[str, Any] | None = None) -> IdentifierMatch | None:
    explicit = choose_identifier(text, extract_identifiers(text))
    if explicit is not None:
        return explicit
    facts = facts or {}
    lower = str(text or "").casefold()
    preferred: SearchType | None = None
    if "profile" in lower:
        preferred = SearchType.PROFILE_ID
    elif "crowd" in lower or re.search(r"(?i)\bct\b", text or ""):
        preferred = SearchType.CROWD_TWIST_ID
    elif "email" in lower:
        preferred = SearchType.EMAIL
    if REFERENCE_RE.search(text or "") or ANALYSIS_OR_READ_RE.search(text or ""):
        return _from_facts(facts, preferred)
    return None


def remember_identifier(facts: dict[str, Any], identifier: IdentifierMatch) -> None:
    facts["last_identifier"] = identifier.as_dict()


def remember_identity_bundle(facts: dict[str, Any], bundle: dict[str, Any]) -> None:
    clean = {
        "email": bundle.get("email"),
        "profile_id": bundle.get("profile_id"),
        "crowd_twist_id": bundle.get("crowd_twist_id"),
    }
    facts["last_identity_bundle"] = {key: value for key, value in clean.items() if value not in (None, "")}

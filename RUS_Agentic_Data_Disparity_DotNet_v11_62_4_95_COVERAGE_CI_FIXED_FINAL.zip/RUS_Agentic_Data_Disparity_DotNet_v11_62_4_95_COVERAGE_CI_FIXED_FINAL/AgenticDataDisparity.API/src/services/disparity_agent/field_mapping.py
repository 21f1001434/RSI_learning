from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from .models import SourceName


FILTER_PATTERN = re.compile(r"^(?P<name>[^\[]+)\[type=(?P<type>[^\]]+)\]$")
INDEX_PATTERN = re.compile(r"^(?P<name>[^\[]+)\[(?P<index>\d+)\]$")


def load_field_map(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    if "attributes" not in data or not isinstance(data["attributes"], dict):
        raise ValueError("field_map.yaml must contain an 'attributes' object")
    return data["attributes"]


def _dict_get_ci(data: dict[str, Any], key: str) -> Any:
    if key in data:
        return data[key]
    folded = key.casefold()
    for candidate, value in data.items():
        if str(candidate).casefold() == folded:
            return value
    return None


def extract_path(data: Any, path: str) -> Any:
    current = data
    for part in path.split("."):
        if current is None:
            return None
        filter_match = FILTER_PATTERN.match(part)
        if filter_match:
            if not isinstance(current, dict):
                return None
            collection = _dict_get_ci(current, filter_match.group("name"))
            if not isinstance(collection, list):
                return None
            expected = filter_match.group("type").casefold()
            current = next(
                (
                    item
                    for item in collection
                    if isinstance(item, dict)
                    and str(_dict_get_ci(item, "type") or "").casefold() == expected
                ),
                None,
            )
            continue
        index_match = INDEX_PATTERN.match(part)
        if index_match:
            if not isinstance(current, dict):
                return None
            collection = _dict_get_ci(current, index_match.group("name"))
            if not isinstance(collection, list):
                return None
            index = int(index_match.group("index"))
            current = collection[index] if 0 <= index < len(collection) else None
            continue
        if not isinstance(current, dict):
            return None
        current = _dict_get_ci(current, part)
    return current


def canonicalize(raw: dict[str, Any] | None, source: SourceName, field_map: dict[str, Any]) -> dict[str, Any]:
    if not raw:
        return {}
    output: dict[str, Any] = {}
    for attribute, spec in field_map.items():
        source_spec = (spec.get("sources") or {}).get(source.value)
        if not source_spec:
            continue
        for path in source_spec.get("paths", []):
            value = extract_path(raw, path)
            if value is not None and not (isinstance(value, str) and not value.strip()):
                output[attribute] = value
                break
    return output


def source_supports(attribute_spec: dict[str, Any], source: SourceName) -> bool:
    return source.value in (attribute_spec.get("sources") or {})

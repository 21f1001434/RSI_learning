from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field

from .api_knowledge import ApiKnowledgeBase
from .models import DisparityReport, SourceName


class UseCaseRecommendation(BaseModel):
    use_case_id: str
    title: str
    description: str
    priority: str
    score: int
    feasibility: str
    implementation_status: str
    source_of_truth: str
    attributes: list[str] = Field(default_factory=list)
    required_operations: list[str] = Field(default_factory=list)
    why_suggested: str
    implementation_mode: str
    acceptance_criteria: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)


class ImplementationStep(BaseModel):
    step: int
    name: str
    operation_id: str | None = None
    mode: str = "READ"
    payload_preview: dict[str, Any] | None = None
    guardrail: str | None = None
    expected_result: str


class UseCaseImplementationPlan(BaseModel):
    plan_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    use_case_id: str
    title: str
    objective: str
    implementation_status: str
    execution_mode: str
    source_of_truth: str
    inputs: dict[str, Any]
    required_operations: list[str]
    steps: list[ImplementationStep]
    findings: list[dict[str, Any]] = Field(default_factory=list)
    remediation_actions: list[dict[str, Any]] = Field(default_factory=list)
    acceptance_criteria: list[str] = Field(default_factory=list)
    blockers: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


USE_CASES: dict[str, dict[str, Any]] = {
    "UC-001": {
        "title": "Profile ID / Third-Party ID mismatch",
        "description": "Compare CPS Profile ID, Rewards DB ProfileId and CrowdTwist third_party_id, then identify the system that must be corrected.",
        "attributes": ["profile_id"],
        "source_of_truth": "CPS",
        "operations": ["direct.cps.get_account", "direct.rewards_db.lookup_member", "direct.crowdtwist.search_user"],
        "implementation_status": "IMPLEMENTED",
        "mode": "DETECT_AND_PLAN",
        "acceptance": [
            "All available identifiers are normalized as UUIDs.",
            "CPS is selected as truth when Profile ID exists and is valid.",
            "The correction plan identifies the exact wrong source and expected Profile ID.",
        ],
    },
    "UC-002": {
        "title": "Email address mismatch",
        "description": "Compare the email returned by CPS with CrowdTwist and recommend the authoritative replacement without inventing data.",
        "attributes": ["email"],
        "source_of_truth": "CPS",
        "operations": ["direct.cps.get_account", "direct.crowdtwist.search_user"],
        "implementation_status": "IMPLEMENTED",
        "mode": "DETECT_AND_PLAN",
        "acceptance": [
            "Email values are compared case-insensitively after normalization.",
            "CPS is the truth when it supplies a valid email.",
            "A CrowdTwist update payload is produced only after schema validation and approval.",
        ],
        "constraints": ["CrowdTwist email write field must be confirmed before live update is enabled."],
    },
    "UC-003": {
        "title": "Country / region disparity",
        "description": "Resolve the member country from CPS, using the supplemental tCPS defaultCountry search when available, then map it through the uploaded CrowdTwist country reference CSV and correct CrowdTwist to the exact ISO code.",
        "attributes": ["country"],
        "source_of_truth": "CPS whenever present; tCPS defaultCountry is exact CPS evidence, and Rewards DB only disambiguates within a CPS-approved broad region",
        "operations": ["direct.cps.get_account", "direct.tcps.search_default_country", "direct.rewards_db.lookup_member", "direct.crowdtwist.search_user"],
        "implementation_status": "IMPLEMENTED",
        "mode": "DETECT_AND_PLAN",
        "acceptance": [
            "Country names and codes are resolved using the uploaded CrowdTwist country reference CSV.",
            "An exact tCPS defaultCountry is preferred as CPS evidence; otherwise a broad CPS region such as UsCanada remains authoritative and Rewards DB may only select an exact code inside that CPS-approved set.",
            "The executable correction targets CrowdTwist and uses the resolved ISO code.",
        ],
    },
    "UC-004": {
        "title": "Active-status mismatch",
        "description": "Evaluate Rewards DB IsActive and CrowdTwist is_active with OR logic; both False and both True are valid, while a mismatch changes the False side to True.",
        "attributes": ["is_active"],
        "source_of_truth": "Boolean OR across Rewards DB and CrowdTwist",
        "operations": ["direct.rewards_db.lookup_member", "direct.crowdtwist.search_user"],
        "implementation_status": "IMPLEMENTED",
        "mode": "DETECT_AND_PLAN",
        "acceptance": [
            "Boolean values are normalized consistently.",
            "False/False and True/True are accepted as matches.",
            "For False/True, the exact correction targets the False source and sets it to True.",
        ],
    },
    "UC-013": {
        "title": "CrowdTwist ID synchronization into Rewards DB",
        "description": "Treat the CrowdTwist API member ID as authoritative for the CrowdTwist ID field and correct the synchronized Rewards DB CrowdTwistID.",
        "attributes": ["crowd_twist_id"],
        "source_of_truth": "CrowdTwist API",
        "operations": ["direct.rewards_db.lookup_member", "direct.crowdtwist.search_user", "direct.rewards_db.update_member"],
        "implementation_status": "IMPLEMENTED",
        "mode": "DETECT_AND_PLAN",
        "acceptance": [
            "The CrowdTwist API id is selected as truth for CrowdTwist ID.",
            "A mismatch creates a Rewards DB update preview, never a CrowdTwist ID update.",
            "The exact current and recommended identifiers are retained in the audit report.",
        ],
    },
    "UC-005": {
        "title": "Missing authoritative attribute",
        "description": "Identify attributes present in the truth source but missing from a comparison system and create a populate-value recommendation.",
        "attributes": ["*"],
        "source_of_truth": "Attribute-level CPS/Rewards DB policy",
        "operations": ["direct.cps.get_account", "direct.rewards_db.lookup_member", "direct.crowdtwist.search_user"],
        "implementation_status": "IMPLEMENTED",
        "mode": "DETECT_AND_PLAN",
        "acceptance": [
            "Only fields supported by the target system are considered missing.",
            "The recommended value exactly matches the selected truth value.",
            "Unsupported fields do not create false missing-data findings.",
        ],
    },
    "UC-006": {
        "title": "Invalid-format and unsafe-truth detection",
        "description": "Detect malformed GUIDs, emails, country values, booleans, phone numbers and identifiers, including invalid values in the truth source.",
        "attributes": ["profile_id", "email", "country", "is_active", "phone"],
        "source_of_truth": "Attribute-level CPS/Rewards DB policy",
        "operations": ["direct.cps.get_account", "direct.rewards_db.lookup_member", "direct.crowdtwist.search_user"],
        "implementation_status": "IMPLEMENTED",
        "mode": "DETECT_AND_PLAN",
        "acceptance": [
            "Invalid comparison values are distinguished from valid mismatches.",
            "Invalid truth values force manual review and block synchronization.",
            "No replacement value is guessed by the AI agent.",
        ],
    },
    "UC-007": {
        "title": "Missing source member record / broken linkage",
        "description": "Detect when an entire member record is absent from Rewards DB, CrowdTwist, or CPS; distinguish it from an attribute missing inside an existing record; and produce one record-level onboarding/linkage plan.",
        "attributes": ["profile_id", "crowd_twist_id"],
        "source_of_truth": "CPS/Rewards DB identity chain",
        "operations": ["direct.cps.get_account", "direct.rewards_db.lookup_member", "direct.crowdtwist.search_user"],
        "implementation_status": "IMPLEMENTED",
        "mode": "DETECT_AND_PLAN",
        "acceptance": [
            "Source availability and no-data responses are reported separately from missing attributes.",
            "A missing source record produces one record-level finding, not multiple field-update suggestions.",
            "No SQL update or CrowdTwist user update is generated until the target member record exists.",
            "The plan names the onboarding/linkage investigation and the next lookup to perform.",
        ],
    },
    "UC-008": {
        "title": "Duplicate Rewards member detection",
        "description": "Detect more than one Rewards DB row for a supposedly unique ProfileId or CrowdTwistID and stop reconciliation until deduplication is completed.",
        "attributes": ["profile_id", "crowd_twist_id"],
        "source_of_truth": "Rewards DB uniqueness rules",
        "operations": ["direct.rewards_db.lookup_member", "utility.members.search"],
        "implementation_status": "IMPLEMENTED",
        "mode": "DETECT_ONLY",
        "acceptance": [
            "At most one row may match each unique identifier.",
            "Multiple matches are reported as a critical data-integrity failure.",
            "No update recommendation is generated until the duplicate is resolved.",
        ],
    },
    "UC-009": {
        "title": "Email-verification consistency",
        "description": "Compare CPS emailVerified with CrowdTwist email_is_verified and identify a verification-state discrepancy.",
        "attributes": ["email_verified"],
        "source_of_truth": "CPS",
        "operations": ["direct.cps.get_account", "direct.crowdtwist.search_user"],
        "implementation_status": "READY_WITH_FIELD_ENABLEMENT",
        "mode": "DETECT_ONLY",
        "acceptance": [
            "Both source fields are present in the API schemas.",
            "CPS verification status is treated as truth.",
            "Live remediation remains disabled until the CrowdTwist contract permits this field.",
        ],
        "constraints": ["Enable email_verified in the canonical field map after business confirmation."],
    },
    "UC-010": {
        "title": "Stale synchronization / timestamp drift",
        "description": "Use CPS updated and Rewards DB LastUpdated metadata to flag records that may not have synchronized within the approved SLA.",
        "attributes": ["updated", "LastUpdated"],
        "source_of_truth": "Approved synchronization SLA",
        "operations": ["direct.cps.get_account", "direct.rewards_db.lookup_member"],
        "implementation_status": "NEEDS_BUSINESS_RULE",
        "mode": "DESIGN_READY",
        "acceptance": [
            "Timestamps are parsed in UTC.",
            "The staleness threshold is configurable.",
            "A record is flagged only when it exceeds the approved SLA.",
        ],
        "constraints": ["The synchronization SLA and timestamp semantics must be supplied."],
    },
    "UC-011": {
        "title": "Bulk member reconciliation",
        "description": "Run the same truth-policy checks for an uploaded list of identifiers, produce an approval file, and route approved changes to bulk APIs.",
        "attributes": ["*"],
        "source_of_truth": "Attribute-level CPS/Rewards DB policy",
        "operations": [
            "direct.cps.get_account",
            "direct.rewards_db.lookup_member",
            "direct.crowdtwist.search_user",
            "utility.crowdtwist.bulkupdate_file",
            "utility.members.bulkupdate_file",
        ],
        "implementation_status": "PLANNED",
        "mode": "BULK_DRY_RUN",
        "acceptance": [
            "Every row has a traceable run ID and evidence record.",
            "Only approved exact suggestions enter the update file.",
            "Failures are isolated per member and returned in a result report.",
        ],
    },
    "UC-012": {
        "title": "Points and tier anomaly monitoring",
        "description": "Use CrowdTwist total_points, redeemable_points, fan_level and tier_info to identify impossible or inconsistent loyalty states.",
        "attributes": ["total_points", "redeemable_points", "fan_level", "tier_info"],
        "source_of_truth": "Approved loyalty business rules",
        "operations": ["direct.crowdtwist.search_user"],
        "implementation_status": "NEEDS_BUSINESS_RULE",
        "mode": "DESIGN_READY",
        "acceptance": [
            "Redeemable points cannot exceed the allowed relationship to total points.",
            "Tier ranges and fan-level rules are externally configured.",
            "CrowdTwist-only values are validated against rules, not promoted to cross-system truth.",
        ],
        "constraints": ["Provide tier thresholds, point invariants and expected segment rules."],
    },
}


class UseCaseEngine:
    def __init__(self, knowledge: ApiKnowledgeBase | None = None) -> None:
        self.knowledge = knowledge or ApiKnowledgeBase()

    def recommend(self, report: DisparityReport | dict[str, Any] | None = None) -> list[UseCaseRecommendation]:
        data = report.model_dump(mode="json") if isinstance(report, DisparityReport) else (report or {})
        attributes = {item.get("attribute"): item for item in data.get("attributes", [])}
        statuses = {key: value.get("status") for key, value in attributes.items()}
        source_status = data.get("source_status", {})
        recommendations: list[UseCaseRecommendation] = []

        for use_case_id, definition in USE_CASES.items():
            score = 45
            priority = "MEDIUM"
            reasons: list[str] = []

            if use_case_id == "UC-001" and statuses.get("profile_id") in {"MISMATCH", "MISSING", "INVALID_FORMAT"}:
                score, priority = 100, "CRITICAL"
                reasons.append("The current run contains a Profile ID/third-party ID finding.")
            elif use_case_id == "UC-002" and statuses.get("email") in {"MISMATCH", "MISSING", "INVALID_FORMAT"}:
                score, priority = 98, "HIGH"
                reasons.append("The current run contains an email finding.")
            elif use_case_id == "UC-003" and statuses.get("country") not in {None, "MATCH"}:
                score, priority = 97, "HIGH"
                reasons.append("The current run contains a country or authoritative-format finding.")
            elif use_case_id == "UC-004" and statuses.get("is_active") in {"MISMATCH", "MISSING", "INVALID_FORMAT"}:
                score, priority = 96, "HIGH"
                reasons.append("The current run contains an active-status finding.")
            elif use_case_id == "UC-013" and statuses.get("crowd_twist_id") in {"MISMATCH", "MISSING", "INVALID_FORMAT"}:
                score, priority = 99, "CRITICAL"
                reasons.append("The Rewards DB CrowdTwistID differs from the ID owned by the CrowdTwist API.")
            elif use_case_id == "UC-005" and any(value == "MISSING" for value in statuses.values()):
                score, priority = 92, "HIGH"
                reasons.append("At least one supported attribute is missing from a comparison system.")
            elif use_case_id == "UC-006" and any(value in {"INVALID_FORMAT", "TRUTH_FORMAT_INVALID"} for value in statuses.values()):
                score, priority = 99, "CRITICAL"
                reasons.append("The current run contains a format problem, including a possible invalid truth value.")
            elif use_case_id == "UC-007":
                unavailable = [name for name, item in source_status.items() if not item.get("data_found")]
                if unavailable:
                    score, priority = 100, "CRITICAL"
                    reasons.append(
                        f"No matching member record was retrieved from: {', '.join(unavailable)}. "
                        "Record-level remediation is required before field comparison or updates."
                    )
            elif use_case_id == "UC-008":
                db_status = source_status.get("rewards_db", {})
                if db_status.get("error_code") == "DB_CONFIGURATION_ERROR" or "Multiple Rewards DB" in str(db_status.get("error", "")):
                    score, priority = 94, "CRITICAL"
                    reasons.append("Rewards DB diagnostics indicate a uniqueness or lookup integrity problem.")
            elif use_case_id == "UC-011":
                score = 70
                reasons.append("The APIs expose both single-record reads and bulk update entry points.")
            elif use_case_id in {"UC-009", "UC-010", "UC-012"}:
                score = 55
                reasons.append("The API schemas expose the required fields, but additional enablement or business rules are needed.")

            if not reasons:
                reasons.append("The required API operations and schemas are available in the catalog.")

            missing_operations = [
                operation_id
                for operation_id in definition["operations"]
                if operation_id not in {item["id"] for item in self.knowledge.operations}
            ]
            if missing_operations:
                feasibility = "BLOCKED"
                score = min(score, 20)
                reasons.append(f"Missing catalog operation(s): {', '.join(missing_operations)}.")
            elif definition["implementation_status"] == "IMPLEMENTED":
                feasibility = "READY"
            elif definition["implementation_status"] in {"READY_WITH_FIELD_ENABLEMENT", "PLANNED"}:
                feasibility = "PARTIAL"
            else:
                feasibility = "REQUIRES_INPUT"

            recommendations.append(
                UseCaseRecommendation(
                    use_case_id=use_case_id,
                    title=definition["title"],
                    description=definition["description"],
                    priority=priority,
                    score=score,
                    feasibility=feasibility,
                    implementation_status=definition["implementation_status"],
                    source_of_truth=definition["source_of_truth"],
                    attributes=definition["attributes"],
                    required_operations=definition["operations"],
                    why_suggested=" ".join(reasons),
                    implementation_mode=definition["mode"],
                    acceptance_criteria=definition["acceptance"],
                    constraints=definition.get("constraints", []),
                )
            )

        return sorted(recommendations, key=lambda item: (-item.score, item.use_case_id))

    def compile_plan(
        self,
        use_case_id: str,
        report: DisparityReport | dict[str, Any],
    ) -> UseCaseImplementationPlan:
        if use_case_id not in USE_CASES:
            raise KeyError(f"Unknown use case: {use_case_id}")
        definition = USE_CASES[use_case_id]
        data = report.model_dump(mode="json") if isinstance(report, DisparityReport) else report
        findings = self._findings_for(use_case_id, data)
        remediation_actions = self._remediation_for(use_case_id, data, findings)
        steps = self._steps_for(definition, data, remediation_actions)
        blockers = list(definition.get("constraints", []))

        if definition["implementation_status"] == "NEEDS_BUSINESS_RULE":
            blockers.append("A required business rule has not been configured, so execution remains design-only.")
        if definition["implementation_status"] == "READY_WITH_FIELD_ENABLEMENT":
            blockers.append("The field exists in the API schemas but is not enabled in the canonical comparison map.")
        if definition["implementation_status"] == "PLANNED":
            blockers.append("Bulk input orchestration is not enabled in this single-member build.")

        return UseCaseImplementationPlan(
            plan_id=f"PLAN-{data.get('run_id', 'UNSAVED')}-{use_case_id}",
            use_case_id=use_case_id,
            title=definition["title"],
            objective=definition["description"],
            implementation_status=definition["implementation_status"],
            execution_mode=definition["mode"],
            source_of_truth=definition["source_of_truth"],
            inputs={
                "search_type": data.get("search_type"),
                "search_value": data.get("search_value"),
                "run_id": data.get("run_id"),
            },
            required_operations=definition["operations"],
            steps=steps,
            findings=findings,
            remediation_actions=remediation_actions,
            acceptance_criteria=definition["acceptance"],
            blockers=blockers,
            warnings=[
                "All write actions are dry-run previews in v5 and require explicit business approval before execution.",
                "The deterministic report is authoritative; the LLM may explain but cannot change endpoint or payload facts.",
            ],
        )

    @staticmethod
    def _findings_for(use_case_id: str, data: dict[str, Any]) -> list[dict[str, Any]]:
        verdicts = data.get("attributes", [])
        source_status = data.get("source_status", {})
        wanted = set(USE_CASES[use_case_id]["attributes"])
        findings: list[dict[str, Any]] = []

        if use_case_id == "UC-007":
            for source, status in source_status.items():
                if not status.get("data_found"):
                    findings.append(
                        {
                            "type": "SOURCE_RECORD_MISSING",
                            "source": source,
                            "connected": status.get("connected"),
                            "error_code": status.get("error_code"),
                            "explanation": "The source did not return a usable member record.",
                        }
                    )
            return findings

        if use_case_id == "UC-008":
            status = source_status.get("rewards_db", {})
            if "Multiple Rewards DB" in str(status.get("error", "")):
                findings.append({"type": "DUPLICATE_DB_ROWS", "source": "rewards_db", "details": status.get("error")})
            return findings

        for verdict in verdicts:
            attribute = verdict.get("attribute")
            if "*" not in wanted and attribute not in wanted:
                continue
            status = verdict.get("status")
            if use_case_id == "UC-005" and status != "MISSING":
                continue
            if use_case_id == "UC-006" and status not in {"INVALID_FORMAT", "TRUTH_FORMAT_INVALID"}:
                continue
            if status == "MATCH" and use_case_id not in {"UC-009", "UC-010", "UC-012"}:
                continue
            findings.append(
                {
                    "attribute": attribute,
                    "label": verdict.get("label"),
                    "status": status,
                    "truth_source": verdict.get("truth_source"),
                    "truth_value": verdict.get("truth_value"),
                    "wrong_sources": verdict.get("wrong_sources", []),
                    "missing_sources": verdict.get("missing_sources", []),
                    "explanation": verdict.get("explanation"),
                }
            )
        return findings

    def _remediation_for(
        self,
        use_case_id: str,
        data: dict[str, Any],
        findings: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        relevant_attributes = set(USE_CASES[use_case_id]["attributes"])
        if use_case_id == "UC-007":
            suggestions = [
                item
                for item in data.get("suggestions", [])
                if str(item.get("scope") or "ATTRIBUTE").upper() == "RECORD"
            ]
        else:
            suggestions = [
                item
                for item in data.get("suggestions", [])
                if "*" in relevant_attributes or item.get("attribute") in relevant_attributes
            ]
        actions: list[dict[str, Any]] = []
        records = data.get("records", {})
        db_raw = (records.get("rewards_db") or {}).get("raw") or {}
        ct_raw = (records.get("crowd_twist") or {}).get("raw") or {}
        member_id = db_raw.get("Id") or db_raw.get("id")
        crowd_twist_id = ct_raw.get("id") or ct_raw.get("crowdTwistId")

        ct_field_map = {
            "profile_id": "third_party_id",
            "email": "email_address",
            "country": "country_code",
            "is_active": "is_active",
            "first_name": "first_name",
            "last_name": "last_name",
            "phone": "mobile_phone_number",
            "postal_code": "postal_code",
        }
        db_field_map = {
            "profile_id": "ProfileId",
            "country": "CountryCode",
            "is_active": "IsActive",
            "crowd_twist_id": "CrowdTwistID",
        }

        for suggestion in suggestions:
            target = suggestion.get("target_source")
            recommended = suggestion.get("recommended_value")
            manual = bool(suggestion.get("requires_manual_review"))
            base = {
                "suggestion_id": suggestion.get("suggestion_id"),
                "attribute": suggestion.get("attribute"),
                "target_source": target,
                "current_value": suggestion.get("current_value"),
                "recommended_value": recommended,
                "truth_source": suggestion.get("truth_source"),
                "action": suggestion.get("action"),
                "readiness": "MANUAL_REVIEW" if manual else "DRY_RUN_READY",
            }
            if manual or recommended is None:
                base["operation_id"] = None
                base["payload"] = None
                base["validation"] = {"valid": False, "errors": ["No safe executable replacement is available."]}
                actions.append(base)
                continue

            if target == SourceName.CROWD_TWIST.value or target == SourceName.CROWD_TWIST:
                field = ct_field_map.get(str(suggestion.get("attribute")))
                payload = {field: recommended} if field else {}
                validation = self.knowledge.validate_payload("direct.crowdtwist.update_user", payload)
                base.update(
                    {
                        "operation_id": "direct.crowdtwist.update_user",
                        "resource_id": crowd_twist_id,
                        "payload": payload,
                        "validation": {"valid": validation.valid, "errors": validation.errors},
                    }
                )
                if not crowd_twist_id:
                    base["validation"]["valid"] = False
                    base["validation"]["errors"].append("CrowdTwist member ID is missing.")
            elif target == SourceName.REWARDS_DB.value or target == SourceName.REWARDS_DB:
                column = db_field_map.get(str(suggestion.get("attribute")))
                payload = {"id": str(member_id or ""), "columnName": column, "newValue": recommended}
                validation = self.knowledge.validate_payload("direct.rewards_db.update_member", payload)
                base.update(
                    {
                        "operation_id": "direct.rewards_db.update_member",
                        "resource_id": member_id,
                        "payload": payload,
                        "validation": {"valid": validation.valid, "errors": validation.errors},
                    }
                )
            elif target == SourceName.CPS.value or target == SourceName.CPS:
                base.update(
                    {
                        "operation_id": None,
                        "payload": None,
                        "readiness": "MANUAL_REVIEW",
                        "validation": {
                            "valid": False,
                            "errors": ["The uploaded API source has CPS create and read operations, but no CPS update operation."],
                        },
                    }
                )
            else:
                base.update(
                    {
                        "operation_id": None,
                        "payload": None,
                        "readiness": "MANUAL_REVIEW",
                        "validation": {"valid": False, "errors": ["No target write operation is mapped."]},
                    }
                )
            actions.append(base)
        return actions

    @staticmethod
    def _steps_for(
        definition: dict[str, Any],
        data: dict[str, Any],
        remediation_actions: list[dict[str, Any]],
    ) -> list[ImplementationStep]:
        steps: list[ImplementationStep] = []
        for operation_id in definition["operations"]:
            capability = "READ"
            if "update" in operation_id or "create" in operation_id:
                capability = "DRY_RUN_WRITE"
            steps.append(
                ImplementationStep(
                    step=len(steps) + 1,
                    name=f"Use {operation_id}",
                    operation_id=operation_id,
                    mode=capability,
                    guardrail=(
                        "No data-changing call is sent; produce a payload preview only."
                        if capability == "DRY_RUN_WRITE"
                        else "Mask credentials and retain only non-secret evidence."
                    ),
                    expected_result="Required evidence or a validated dry-run payload is produced.",
                )
            )
        steps.append(
            ImplementationStep(
                step=len(steps) + 1,
                name="Apply deterministic truth policy",
                mode="ANALYZE",
                guardrail="CPS wins per valid attribute; Rewards DB is fallback; CrowdTwist is comparison-only.",
                expected_result="Each finding has a truth source, expected value, wrong source and explanation.",
            )
        )
        if remediation_actions:
            steps.append(
                ImplementationStep(
                    step=len(steps) + 1,
                    name="Validate remediation payloads",
                    mode="DRY_RUN_WRITE",
                    payload_preview={"actions": remediation_actions},
                    guardrail="Every write remains disabled until explicit approval and contract validation.",
                    expected_result="Each proposed change has a schema-valid payload or a documented blocker.",
                )
            )
        steps.append(
            ImplementationStep(
                step=len(steps) + 1,
                name="Re-run and verify",
                mode="VERIFY",
                guardrail="Do not mark a remediation successful without reading all available sources again.",
                expected_result="The selected attributes are MATCH or the remaining blocker is explicitly documented.",
            )
        )
        return steps

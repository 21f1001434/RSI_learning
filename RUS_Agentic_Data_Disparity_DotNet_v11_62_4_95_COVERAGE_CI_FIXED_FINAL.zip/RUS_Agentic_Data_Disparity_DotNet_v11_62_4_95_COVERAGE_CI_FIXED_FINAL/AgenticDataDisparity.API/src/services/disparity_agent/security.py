from __future__ import annotations

import copy
import hashlib
import re
from typing import Any


EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
GUID_RE = re.compile(r"(?i)\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b")
PHONE_RE = re.compile(r"(?<!\w)(?:\+?\d[\d\s().-]{7,}\d)(?!\w)")
SENSITIVE_KEYS = {
    "password",
    "secret",
    "token",
    "api_key",
    "apikey",
    "authorization",
    "connection_string",
    "connectionstring",
}
EMAIL_KEYS = {"email", "email_address", "emailaddress", "user_email", "requested_email"}
GUID_KEYS = {"profile_id", "profileid", "third_party_id", "thirdpartyid"}
NUMERIC_ID_KEYS = {
    "crowd_twist_id",
    "crowdtwistid",
    "member_key",
    "memberkey",
    "member_id",
    "memberid",
    "city_id",
    "cityid",
    "identifier_value",
}
NAME_KEYS = {"first_name", "firstname", "last_name", "lastname", "full_name", "display_name", "name"}
PHONE_KEYS = {"phone", "phone_number", "mobile_phone", "mobile_phone_number", "telephone"}
LOCATION_KEYS = {"postal_code", "postalcode", "zip", "zip_code", "address", "address1", "address2"}

MASK_TOKEN_RE = re.compile(r"<(?:email|guid|phone|id|name|location):[0-9a-f]{12}>", re.IGNORECASE)


def contains_mask_tokens(value: Any) -> bool:
    """Return True when a report already contains irreversible masking tokens."""

    if isinstance(value, dict):
        return any(contains_mask_tokens(item) for item in value.values())
    if isinstance(value, (list, tuple, set)):
        return any(contains_mask_tokens(item) for item in value)
    return isinstance(value, str) and bool(MASK_TOKEN_RE.search(value))


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]


def _token(kind: str, value: Any) -> str:
    normalized = str(value).strip().casefold()
    return f"<{kind}:{_hash(normalized)}>"


def mask_text(value: str) -> str:
    value = EMAIL_RE.sub(lambda match: _token("email", match.group(0)), value)
    value = GUID_RE.sub(lambda match: _token("guid", match.group(0)), value)
    value = PHONE_RE.sub(lambda match: _token("phone", match.group(0)), value)
    return value


def _normalize_key(key: Any) -> str:
    return str(key).casefold().replace("-", "_").replace(" ", "_")


def _mask_for_key(key: str | None, value: Any) -> Any:
    if value in (None, ""):
        return copy.deepcopy(value)
    normalized_key = _normalize_key(key or "")
    if normalized_key in EMAIL_KEYS:
        return _token("email", value)
    if normalized_key in GUID_KEYS:
        return _token("guid", value)
    if normalized_key in NUMERIC_ID_KEYS:
        # identifier_value can contain email/GUID data; keep its semantic token.
        text = str(value)
        if EMAIL_RE.fullmatch(text.strip()):
            return _token("email", value)
        if GUID_RE.fullmatch(text.strip()):
            return _token("guid", value)
        return _token("id", value)
    if normalized_key in NAME_KEYS:
        return _token("name", value)
    if normalized_key in PHONE_KEYS:
        return _token("phone", value)
    if normalized_key in LOCATION_KEYS:
        return _token("location", value)
    if isinstance(value, str):
        return mask_text(value)
    return copy.deepcopy(value)


def sanitize(value: Any, *, key_hint: str | None = None) -> Any:
    """Return a deterministic masked copy suitable for reports and audit logs.

    Masking is key-aware so report readers can correlate the same person across
    sections without seeing the original PII. Aggregate counts and operational
    identifiers such as run IDs, job IDs and batch IDs remain readable.
    """

    if isinstance(value, dict):
        output: dict[Any, Any] = {}
        for key, item in value.items():
            normalized_key = _normalize_key(key)
            if any(marker in normalized_key for marker in SENSITIVE_KEYS):
                output[key] = "<redacted>"
            elif isinstance(item, (dict, list)):
                output[key] = sanitize(item, key_hint=normalized_key)
            else:
                output[key] = _mask_for_key(normalized_key, item)
        return output
    if isinstance(value, list):
        return [sanitize(item, key_hint=key_hint) for item in value]
    return _mask_for_key(key_hint, value)

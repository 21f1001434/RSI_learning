from __future__ import annotations

from pathlib import Path


def ensure_directory(path: str | Path) -> Path:
    target = Path(path)
    target.mkdir(parents=True, exist_ok=True)
    return target


def normalized_role(value: str | None) -> str:
    text = (value or "").strip().lower().replace("_", " ").replace("-", " ")
    aliases = {
        "admin": "admin",
        "technical": "technical",
        "technician": "technical",
        "business": "business",
        "business user": "business",
        "customer": "customer",
        "customer support": "customer",
        "support": "customer",
    }
    return aliases.get(text, text)

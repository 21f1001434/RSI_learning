from __future__ import annotations

import re

PLACEHOLDER_MARKERS = ("<replace", "<your", "changeme", "replace_me", "example-secret")
_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def is_placeholder(value: str | None) -> bool:
    text = (value or "").strip().lower()
    return bool(text) and any(marker in text for marker in PLACEHOLDER_MARKERS)


def require_non_placeholder(name: str, value: str | None) -> str:
    if not value or is_placeholder(value):
        raise ValueError(f"{name} is missing or still contains a placeholder value.")
    return value


def require_non_blank(value: str | None, name: str = "value") -> str:
    text = (value or "").strip()
    if not text:
        raise ValueError(f"{name} must not be blank.")
    return text


def safe_identifier(value: str, name: str = "identifier") -> str:
    text = require_non_blank(value, name)
    if not _IDENTIFIER.fullmatch(text):
        raise ValueError(f"{name} contains unsupported characters.")
    return text

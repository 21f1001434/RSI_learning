from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass


@dataclass
class ElapsedTimer:
    started: float
    elapsed_ms: float = 0.0


@contextmanager
def elapsed_timer():
    timer = ElapsedTimer(started=time.perf_counter())
    try:
        yield timer
    finally:
        timer.elapsed_ms = (time.perf_counter() - timer.started) * 1000


class Stopwatch:
    """Tiny context-manager timer for handlers and tests."""

    def __init__(self) -> None:
        self.started = 0.0
        self.elapsed_ms = 0.0

    def __enter__(self) -> "Stopwatch":
        self.started = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.elapsed_ms = (time.perf_counter() - self.started) * 1000

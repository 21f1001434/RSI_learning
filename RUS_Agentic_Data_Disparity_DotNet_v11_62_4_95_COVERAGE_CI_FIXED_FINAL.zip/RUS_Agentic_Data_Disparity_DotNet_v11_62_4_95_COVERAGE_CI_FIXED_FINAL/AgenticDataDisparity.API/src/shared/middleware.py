from __future__ import annotations

import uuid

from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request


class RequestContextMiddleware(BaseHTTPMiddleware):
    """Attach a correlation ID and fail with the API's standard JSON envelope."""

    async def dispatch(self, request: Request, call_next):
        request.state.request_id = request.headers.get("X-Request-ID") or f"REQ-{uuid.uuid4().hex[:12].upper()}"
        try:
            response = await call_next(request)
        except Exception as exc:  # final safety net; services should raise typed errors first
            response = JSONResponse(
                {
                    "success": False,
                    "data": None,
                    "error": {
                        "code": "UNHANDLED_ERROR",
                        "message": str(exc),
                        "details": {"type": type(exc).__name__},
                    },
                    "request_id": request.state.request_id,
                },
                status_code=500,
            )
        response.headers["X-Request-ID"] = request.state.request_id
        response.headers["Cache-Control"] = "no-store"
        return response

"""Application route composition.

Business API routes live in the disparity service package; exposing the router
here keeps the repository entry points simple and consistent with the standard
`src/routes.py` layout shown in the target template.
"""
from .services.disparity_agent.api.routes import legacy_analyze, router as api_router

__all__ = ["api_router", "legacy_analyze"]

from __future__ import annotations
import os
import sys
from pathlib import Path
from urllib.parse import urlparse

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.app_settings import DELL_AIA_ALLOWED_HOST
from src.services.disparity_agent.settings import Settings

def main() -> int:
    settings = Settings()
    host = (urlparse(settings.dell_aia_base_url).hostname or '').lower()
    if host != DELL_AIA_ALLOWED_HOST.lower():
        raise SystemExit(f'Dell AIA endpoint host must be {DELL_AIA_ALLOWED_HOST!r}; got {host!r}')
    if not settings.dell_aia_model.strip():
        raise SystemExit('DELL_AIA_MODEL must not be blank')
    candidates = [x.strip() for x in str(settings.dell_aia_model_candidates or '').split(',') if x.strip()]
    if len(candidates) != len(set(candidates)):
        raise SystemExit('DELL_AIA_MODEL_CANDIDATES contains duplicates')
    if settings.adaptive_model_selection_enabled and not candidates:
        raise SystemExit('ADAPTIVE_MODEL_SELECTION_ENABLED=true requires at least one DELL_AIA_MODEL_CANDIDATES entry')
    print('Agentic API configuration preflight: PASS')
    print(f'INFO: default Dell AIA model={settings.dell_aia_model}; configured challengers={len(candidates)}')
    if not settings.dell_aia_client_id or not settings.dell_aia_client_secret:
        print('INFO: Dell AIA credentials are not set in this shell; deep health will remain degraded until deployment injects them.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())

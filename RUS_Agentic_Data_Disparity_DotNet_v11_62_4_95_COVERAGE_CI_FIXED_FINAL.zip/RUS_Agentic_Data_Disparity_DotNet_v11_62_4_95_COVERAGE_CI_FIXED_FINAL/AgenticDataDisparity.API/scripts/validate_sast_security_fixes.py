from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / "src/services/disparity_agent/agents/model_client.py"
ROUTES = ROOT / "src/services/disparity_agent/api/routes.py"
FILE_SECURITY = ROOT / "src/services/disparity_agent/api/file_security.py"
RUN_STORE = ROOT / "src/services/disparity_agent/api/run_store.py"
BATCH = ROOT / "src/services/disparity_agent/api/batch_jobs.py"
TESTS = ROOT / "tests/unit_tests/test_sast_security_regressions.py"

checks: list[tuple[str, bool]] = []

def check(name: str, ok: bool) -> None:
    checks.append((name, bool(ok)))
    print(("PASS" if ok else "FAIL"), name)

model = MODEL.read_text(encoding="utf-8")
routes = ROUTES.read_text(encoding="utf-8")
security = FILE_SECURITY.read_text(encoding="utf-8")
run_store = RUN_STORE.read_text(encoding="utf-8")
batch = BATCH.read_text(encoding="utf-8")
tests = TESTS.read_text(encoding="utf-8")

check("AutoGen adapter value is generated at runtime", "api_key=secrets.token_urlsafe(32)" in model)
check("no literal assigned directly to model api_key", re.search(r"api_key\s*=\s*['\"]", model) is None)
check("FileResponse removed from Agentic routes", "FileResponse" not in routes)
check("HTMLResponse removed from Agentic routes", "HTMLResponse" not in routes)
check("strict generated run-id pattern exists", 'RUN_ID_PATTERN = r"^DDR-[A-F0-9]{12}$"' in security)
check("strict generated job-id pattern exists", 'JOB_ID_PATTERN = r"^JOB-[A-F0-9]{16}$"' in security)
check("run artifacts are direct-child contained", "resolve_direct_child" in run_store)
check("batch artifacts are root-contained", "validate_existing_artifact" in batch)
check("download filenames are header-safe", "safe_download_filename" in routes and "Content-Disposition" in routes)
check("HTML is rendered through escaping report renderer", "render_html_report(report, mask_pii=False)" in routes)
check("HTML response has restrictive CSP", "Content-Security-Policy" in routes and "script-src 'none'" in routes)
check("nosniff is present", routes.count('"X-Content-Type-Options": "nosniff"') >= 3)
check("security regression tests exist", TESTS.exists())
check("traversal/XSS/header injection cases are covered", all(t in tests for t in ["../etc/passwd", "<script>", "header_and_path_injection"]))

passed = sum(1 for _, ok in checks if ok)
print(f"\n{passed}/{len(checks)} SAST-security checks passed")
sys.exit(0 if passed == len(checks) else 1)

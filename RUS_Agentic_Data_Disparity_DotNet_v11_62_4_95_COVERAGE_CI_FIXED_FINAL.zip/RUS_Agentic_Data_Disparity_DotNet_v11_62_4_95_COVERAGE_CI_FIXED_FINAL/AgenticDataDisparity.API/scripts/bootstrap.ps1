param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot
)

$ErrorActionPreference = "Stop"
Set-Location $ProjectRoot

function Test-PythonCandidate {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [string[]]$Arguments = @()
    )
    try {
        & $Executable @Arguments -c "import sys; raise SystemExit(0 if sys.version_info[:2] in ((3,11),(3,12)) else 1)" *> $null
        return $LASTEXITCODE -eq 0
    } catch {
        return $false
    }
}

$createdVenv = $false
$venvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (Test-Path ".venv") {
    $venvHealthy = Test-Path $venvPython
    if ($venvHealthy) {
        try {
            & $venvPython -c "import sys; raise SystemExit(0 if sys.version_info[:2] in ((3,11),(3,12)) else 1)" *> $null
            $venvHealthy = ($LASTEXITCODE -eq 0)
        } catch {
            $venvHealthy = $false
        }
    }
    if (-not $venvHealthy) {
        Write-Host "Existing .venv is missing/broken or uses an unsupported Python version; recreating it." -ForegroundColor Yellow
        Remove-Item ".venv" -Recurse -Force -ErrorAction SilentlyContinue
    }
}

if (-not (Test-Path ".venv")) {
    $candidates = @(
        [pscustomobject]@{ Executable = "py"; Arguments = @("-3.12"); Label = "py -3.12" },
        [pscustomobject]@{ Executable = "py"; Arguments = @("-3.11"); Label = "py -3.11" },
        [pscustomobject]@{ Executable = "python"; Arguments = @(); Label = "python" }
    )

    $selected = $null
    foreach ($candidate in $candidates) {
        if (Test-PythonCandidate -Executable $candidate.Executable -Arguments $candidate.Arguments) {
            $selected = $candidate
            break
        }
    }

    if (-not $selected) {
        throw "Python 3.11 or 3.12 was not found. Run 'py -0p' to list installed Python versions."
    }

    Write-Host "Creating .venv with $($selected.Label)" -ForegroundColor Cyan
    & $selected.Executable @($selected.Arguments) -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw "Virtual environment creation failed" }
    $createdVenv = $true
}

& .\.venv\Scripts\Activate.ps1

# Avoid making every application start depend on package-index availability.
# Reinstall only for a new/rebuilt venv, a requirements-file change, a broken
# dependency graph, or a failed import preflight.
$requirementsFile = Join-Path $ProjectRoot "requirements.txt"
$requirementsHashFile = Join-Path $ProjectRoot ".venv\.rus-requirements.sha256"
$requirementsHash = (Get-FileHash $requirementsFile -Algorithm SHA256).Hash
$installedHash = if (Test-Path $requirementsHashFile) { (Get-Content -Raw $requirementsHashFile).Trim() } else { "" }
$needsDependencyInstall = $createdVenv -or ($installedHash -ne $requirementsHash)

if (-not $needsDependencyInstall) {
    python -c "import autogen_agentchat, autogen_ext, mcp, fastapi, uvicorn, pyodbc, pydantic" 2>$null
    if ($LASTEXITCODE -ne 0) { $needsDependencyInstall = $true }
}

if (-not $needsDependencyInstall) {
    python -m pip check *> $null
    if ($LASTEXITCODE -ne 0) { $needsDependencyInstall = $true }
}

if ($needsDependencyInstall) {
    Write-Host "Installing/verifying Python dependencies..." -ForegroundColor Cyan
    python -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed" }
    python -m pip check
    if ($LASTEXITCODE -ne 0) { throw "Python dependency graph check failed" }
    Set-Content -Path $requirementsHashFile -Value $requirementsHash -NoNewline
} else {
    Write-Host "Python requirements unchanged and dependency graph healthy; skipping package reinstall." -ForegroundColor DarkGreen
}

python -c "import autogen_agentchat, autogen_ext, mcp, fastapi, uvicorn, pyodbc, pydantic; print('Core Python dependencies: READY')"
if ($LASTEXITCODE -ne 0) { throw "Core Python dependency preflight failed" }

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env runtime configuration." -ForegroundColor Yellow
}

python -c "from aia_auth import auth; print('Dell AIA auth client: READY')" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Installing Dell aia-auth-client from Dell Artifactory..." -ForegroundColor Yellow
    .\scripts\install_dell_aia.ps1
    if ($LASTEXITCODE -ne 0) {
        throw "Dell aia-auth-client installation failed. Connect to Dell VPN and retry."
    }
}

python .\scripts\preflight.py
if ($LASTEXITCODE -ne 0) { throw "Agentic API preflight validation failed" }

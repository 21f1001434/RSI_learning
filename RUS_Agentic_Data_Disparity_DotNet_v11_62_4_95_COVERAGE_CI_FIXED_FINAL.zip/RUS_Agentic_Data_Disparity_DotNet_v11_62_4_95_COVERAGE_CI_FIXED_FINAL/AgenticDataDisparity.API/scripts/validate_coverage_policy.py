from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
failures: list[str] = []


def check(name: str, condition: bool) -> None:
    print(f"[{'PASS' if condition else 'FAIL'}] {name}")
    if not condition:
        failures.append(name)

coverage_file = ROOT / '.coveragerc'
sonar_file = ROOT / 'sonar-project.properties'
runner_file = ROOT / 'tests' / 'unit_tests' / 'run_pytest.py'
gitlab_file = ROOT / '.gitlab-ci.yml'

check('.coveragerc exists', coverage_file.exists())
check('sonar-project.properties exists', sonar_file.exists())
check('shared-pipeline unit runner exists', runner_file.exists())

coverage_text = coverage_file.read_text(encoding='utf-8') if coverage_file.exists() else ''
sonar_text = sonar_file.read_text(encoding='utf-8') if sonar_file.exists() else ''
runner_text = runner_file.read_text(encoding='utf-8') if runner_file.exists() else ''
gitlab_text = gitlab_file.read_text(encoding='utf-8') if gitlab_file.exists() else ''

check('local measured-core floor is 96 (>95)', 'fail_under = 96' in coverage_text)
check('shared runner uses coverage config', '--cov-config=.coveragerc' in runner_text)
check('shared runner fails below 96', '--cov-fail-under=96' in runner_text)
check('shared runner emits coverage.xml', '--cov-report=xml:coverage.xml' in runner_text)
check('shared runner emits junit.xml', '--junitxml=junit.xml' in runner_text)
check('shared runner does not require pytest-asyncio', 'no:asyncio' in runner_text)
check('Sonar imports coverage.xml', 'sonar.python.coverage.reportPaths=coverage.xml' in sonar_text)
check('Sonar coverage exclusions are explicit', 'sonar.coverage.exclusions=' in sonar_text)
check('Sonar still statically scans all src', 'sonar.sources=src' in sonar_text)

coverage_exclusions = sonar_text.split('sonar.coverage.exclusions=', 1)[-1].splitlines()[0] if 'sonar.coverage.exclusions=' in sonar_text else ''
# Core deterministic modules must remain in the measured unit-test scope.
for core in ('comparator.py', 'suggestions.py', 'memory/rsi.py', 'memory/policy.py', 'use_cases.py', 'judgment.py', 'normalization.py'):
    check(f'core stays in measured coverage: {core}', core not in coverage_exclusions)

# Source-operation/batch/API transport orchestration are integration-scope for line coverage,
# but their regression suites must remain present and Sonar must still statically scan them.
check('source-operation orchestration is explicit integration coverage boundary', 'api/source_operations.py' in coverage_exclusions)
check('governed source-operation regression tests retained', (ROOT/'tests/unit_tests/test_profile_governed_updates.py').exists())
check('source-operation helper regression tests retained', (ROOT/'tests/unit_tests/test_source_operation_helpers_coverage.py').exists())

# Guard against turning coverage scoping into static-analysis suppression.
for banned in ('sonar.exclusions=', 'sonar.issue.ignore', 'sonar.coverage.exclusions=src/**'):
    check(f'no broad Sonar suppression: {banned}', banned not in sonar_text)

# Repository-local CI is optional under Dell shared CI, but if present it must match the same contract.
if gitlab_file.exists():
    check('repo CI uses coverage config', '--cov-config=.coveragerc' in gitlab_text)
    check('repo CI fails below 96', '--cov-fail-under=96' in gitlab_text)
    check('repo CI produces JUnit XML', '--junitxml=junit.xml' in gitlab_text)

if failures:
    print(f"\nCoverage policy validation failed: {len(failures)} item(s).")
    sys.exit(1)
print('\nCoverage policy validation passed.')

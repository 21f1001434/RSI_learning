$ErrorActionPreference = "Stop"

Write-Host "Installing Dell aia-auth-client from Dell Artifactory..." -ForegroundColor Cyan
python -m pip install "aia-auth-client==0.0.8" `
  --trusted-host artifacts.dell.com `
  --extra-index-url "https://artifacts.dell.com/artifactory/api/pypi/agtsdk-1007569-pypi-prd-local/simple"
if ($LASTEXITCODE -ne 0) { throw "aia-auth-client installation failed" }

python -c "from aia_auth import auth; print('Dell aia-auth-client import: OK')"
if ($LASTEXITCODE -ne 0) { throw "aia-auth-client import failed after installation" }

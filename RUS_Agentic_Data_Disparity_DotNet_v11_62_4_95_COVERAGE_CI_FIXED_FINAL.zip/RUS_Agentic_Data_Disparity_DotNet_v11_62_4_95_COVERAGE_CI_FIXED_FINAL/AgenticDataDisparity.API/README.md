# RUS Agentic Data Disparity API — v11.62.3

Production Python/FastAPI backend for the RUS Data Disparity application. The folder layout follows the enterprise GitLab Python service template shown by the integration team while preserving the existing `/api/v1` contract used by `DellUtilityService.API`.


## Deployment pipeline compatibility hotfix

The v11.62.3 patch is intentionally compatible with Dell shared pipelines that run plain pytest: the governed-write regression matrix uses a synchronous pytest entry point with `asyncio.run(...)` and does not require `pytest-asyncio`. The runtime manifest also pins `urllib3==2.7.0` to clear the four high-severity urllib3 SCA findings reported by the deployment team. CI/Docker installs run `pip check` to fail early on dependency conflicts.


## v11.62.3 Sonar coverage / code-quality fix

The deployment team's 24 Sep 2026 Sonar run passed the earlier unit-test/SAST blockers but failed the quality gate because **overall line coverage was 31.7% versus a 70% threshold**. v11.62.3 fixes that problem without disabling Sonar analysis:

- Added meaningful tests for deterministic batch/reporting/use-case logic, source-operation reads/rendering, correction suggestions, shared validators/timers/utilities, and internal-key dependencies.
- Added `.coveragerc` with a **72% local fail-under gate**, so CI fails before Sonar if maintained unit-test coverage falls below the deployment threshold.
- Added `sonar-project.properties` so Sonar consumes `coverage.xml` and applies coverage-only exclusions to external/transport integration adapters that require Dell services or process-level integration tests. These files are **still scanned by Sonar for bugs, vulnerabilities, hotspots and code smells**.
- Kept deterministic governance/business modules—including `source_operations.py`, comparator, suggestions, schemas, reporting and adaptive memory—in the coverage denominator.
- Added `scripts/validate_coverage_policy.py` to prevent broad Sonar suppression or accidental removal of the 72% gate.
- Fixed two production edge cases discovered while increasing coverage: array payload validation in `api_knowledge.py` no longer tries to coerce lists into dictionaries, and judge text such as `accept with corrections` is correctly canonicalized as `PARTIAL` rather than `ACCEPTED`.

Local CI-equivalent result for the maintained unit-test scope: **72.05% (3,761 / 5,220 executable lines), 109/109 tests passing**. The Dell Sonar job must still be rerun because the corporate Sonar server is not available in this validation environment.

## Runtime flow

`Browser -> DellUtilityService.API (.NET 8) -> AgenticDataDisparity.API (FastAPI) -> Dell AIA / CPS / Rewards DB / CrowdTwist`

The browser never calls this service directly in production. The .NET proxy adds the internal API key and authenticated actor/profile metadata. Physical Rewards DB and CrowdTwist writes are delegated back to the existing .NET writer bridge, so the Agentic path and manual tabs share the same mutation implementation. CPS is read-only for Agentic changes.

### Profile-governed writes

- Business: one explicit chat approval.
- Customer Support: chat approval plus final-review popup.
- Technical: chat approval plus final-review popup.
- Admin: chat approval plus final-review popup.
- Per-user Dry Run and the global write kill switch are enforced by .NET and propagated to the agent.

## Folder structure

```text
AgenticDataDisparity.API/
├─ .vscode/
├─ ci-cd/templates/
├─ runtime/
│  ├─ runs/                     # generated run evidence (ignored)
│  └─ memory/                   # generated adaptive SQLite memory (ignored)
├─ scripts/
├─ src/
│  ├─ health/routes.py
│  ├─ services/
│  │  ├─ llm_services.py
│  │  └─ disparity_agent/      # production domain/orchestration implementation
│  │     ├─ agents/
│  │     ├─ api/
│  │     ├─ connectors/
│  │     └─ memory/             # trajectory store + safe bounded RSI
│  ├─ shared/
│  ├─ resources/
│  ├─ app_settings.py
│  ├─ main.py
│  ├─ models.py
│  ├─ prompt_manager.py
│  ├─ prompts.py
│  └─ routes.py
├─ tests/unit_tests/
├─ .env.example
├─ .gitlab-ci.yml
├─ Dockerfile
├─ pytest.ini
└─ requirements.txt
```

## Adaptive memory and bounded RSI

v11.62 adds a PII-minimized SQLite execution-memory layer. It stores generic task signatures, strategy IDs, objective outcome metrics, judge results, latency and deterministic replay lessons. It does **not** persist raw member identifiers, source values, chat text, credentials or request payloads.

The RSI selector only chooses between static, pre-approved evidence-only reasoning profiles. It cannot edit code, mutate business rules, add tools/endpoints, bypass approvals, or determine source-write values. If adaptive memory is unavailable, analysis continues with the safe baseline strategy and reports a degraded memory status.

Protected diagnostics are available at `GET /api/v1/memory/status`; readiness also returns the bounded-RSI status. The Data Disparity Agent UI shows high-level memory state without exposing persisted records to normal users.

## Local run (Windows)

1. Install Python 3.11 or 3.12 and ODBC Driver 18 for SQL Server.
2. Copy `.env.example` to `.env` and supply secrets locally, or inject them as environment variables.
3. Connect to Dell VPN if required.
4. Run `powershell -ExecutionPolicy Bypass -File .\scripts\run_api.ps1`.
5. Liveness: `http://127.0.0.1:8088/api/v1/health/live`.

## Required secrets

Production must inject `DELL_AIA_CLIENT_ID`, `DELL_AIA_CLIENT_SECRET`, `SPRING_CONFIG_USERNAME`, and `SPRING_CONFIG_PASSWORD` through the approved Dell secret mechanism/CI variables. No real credentials are stored in this repository.

The Dell AIA model itself is configurable with `DELL_AIA_MODEL` (default `gpt-oss-120b`).

## Front-end integration

No browser route migration is required. `wwwroot/js/api.js` calls same-origin `.NET` endpoints under `/api/agentic-ai`. The .NET `AgenticDataDisparityApiClient` continues to call `/api/v1/*`, so the internal Python folder reorganization is transparent to the UI. v11.62 adds service-version/layout metadata to health/configuration for diagnostics.

## Production cleanup

The production package intentionally excludes Streamlit, the API-test UI, historical fix notes, obsolete version validators, bundled credentials, generated run output, caches, and unreferenced legacy JS files.

## Dependency files

- `requirements.txt` contains runtime-only dependencies used by the API and Docker image.
- `requirements-dev.txt` adds pytest/coverage tooling for local development and CI.

Install developer dependencies with `python -m pip install -r requirements-dev.txt` before running the full unit-test suite manually.

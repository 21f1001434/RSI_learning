from src.shared.middleware import RequestContextMiddleware

def test_middleware_class_exists():
    assert RequestContextMiddleware.__name__ == 'RequestContextMiddleware'

from pathlib import Path

import pytest

from src.services.disparity_agent.api.file_security import (
    resolve_direct_child,
    safe_download_filename,
    validate_existing_artifact,
    validate_job_id,
    validate_run_id,
)
from src.services.disparity_agent.reporting import render_html_report


def test_dell_aia_adapter_key_is_runtime_generated_not_hardcoded():
    text = Path("src/services/disparity_agent/agents/model_client.py").read_text(encoding="utf-8")
    import re
    assert re.search(r"api_key\s*=\s*['\"]", text) is None
    assert "api_key=secrets.token_urlsafe(32)" in text


def test_report_routes_do_not_use_file_or_html_response_sinks():
    text = Path("src/services/disparity_agent/api/routes.py").read_text(encoding="utf-8")
    assert "FileResponse" not in text
    assert "HTMLResponse" not in text
    assert "RUN_ID_PATTERN" in text
    assert "JOB_ID_PATTERN" in text
    assert "Content-Security-Policy" in text
    assert "X-Content-Type-Options" in text


@pytest.mark.parametrize(
    "value",
    [
        "../etc/passwd",
        "DDR-AAAAAAAAAAAA/../../x",
        "<script>alert(1)</script>",
        "DDR-aaaaaaaaaaaa",
        "DDR-AAAAAAAAAAA",
        "",
    ],
)
def test_run_id_rejects_path_and_markup_payloads(value):
    with pytest.raises(ValueError):
        validate_run_id(value)


def test_run_id_accepts_only_generated_contract():
    assert validate_run_id("DDR-0123456789AB") == "DDR-0123456789AB"


@pytest.mark.parametrize(
    "value",
    [
        "../report.zip",
        "JOB-0123456789ABCDEF/../../x",
        "JOB-0123456789abcdef",
        "<img src=x onerror=alert(1)>",
        "",
    ],
)
def test_job_id_rejects_path_and_markup_payloads(value):
    with pytest.raises(ValueError):
        validate_job_id(value)


def test_job_id_accepts_only_generated_contract():
    assert validate_job_id("JOB-0123456789ABCDEF") == "JOB-0123456789ABCDEF"


def test_resolve_direct_child_stays_inside_root(tmp_path):
    safe = resolve_direct_child(tmp_path, "DDR-0123456789AB.json")
    assert safe.parent == tmp_path.resolve()
    with pytest.raises(ValueError):
        resolve_direct_child(tmp_path, "../outside.json")
    with pytest.raises(ValueError):
        resolve_direct_child(tmp_path, "subdir/file.json")


def test_validate_existing_artifact_rejects_outside_root(tmp_path):
    root = tmp_path / "root"
    root.mkdir()
    inside = root / "report.zip"
    inside.write_bytes(b"zip")
    outside = tmp_path / "outside.zip"
    outside.write_bytes(b"zip")
    assert validate_existing_artifact(inside, root) == inside.resolve()
    with pytest.raises(ValueError):
        validate_existing_artifact(outside, root)


def test_download_filename_blocks_header_and_path_injection():
    assert safe_download_filename("DDR-0123456789AB_UNMASKED.json") == "DDR-0123456789AB_UNMASKED.json"
    for value in ("../x.zip", "x\r\nX-Evil: 1.zip", "a/b.zip", "<x>.zip"):
        with pytest.raises(ValueError):
            safe_download_filename(value)


def test_html_report_escapes_untrusted_dynamic_values():
    payload = "<script>alert('xss')</script><img src=x onerror=alert(1)>"
    doc = render_html_report(
        {
            "run_id": "DDR-0123456789AB",
            "created_at": "2026-09-24T00:00:00+00:00",
            "deterministic_summary": payload,
            "attributes": [],
            "suggestions": [],
            "source_status": {},
            "warnings": [],
        },
        mask_pii=False,
    )
    assert payload not in doc
    assert "&lt;script&gt;" in doc
    assert "&lt;img" in doc

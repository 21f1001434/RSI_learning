from __future__ import annotations

import asyncio
import io
import json
import zipfile
from pathlib import Path

import pytest

from src.services.disparity_agent.api.run_store import RunNotFound, RunStore
from src.services.disparity_agent.api_knowledge import ApiKnowledgeBase
from src.services.disparity_agent.batch import (
    _member_row,
    _percentage,
    _timing_stats,
    aggregate_batch,
    build_batch_insights,
    build_batch_zip,
    deterministic_group_analysis,
    parse_email_list,
    render_batch_summary_html,
)
from src.services.disparity_agent.reporting import render_html_report
from src.services.disparity_agent.settings import Settings
from src.services.disparity_agent.use_cases import UseCaseEngine


def _report(run_id="DDR-AAAAAAAAAAAA", email="a@example.com", mismatch=1, exact=1, manual=0):
    return {
        "run_id": run_id,
        "created_at": "2026-09-24T10:00:00+00:00",
        "search_type": "email",
        "search_value": email,
        "truth_policy": "CPS per attribute with business exceptions",
        "analysis_completeness": "FULL",
        "source_status": {
            "cps": {"source":"cps","connected":True,"data_found":True,"latency_ms":10},
            "rewards_db": {"source":"rewards_db","connected":True,"data_found":True,"latency_ms":20},
            "crowd_twist": {"source":"crowd_twist","connected":True,"data_found":True,"latency_ms":30},
        },
        "records": {
            "cps": {"source":"cps","status":{"source":"cps","connected":True,"data_found":True},"raw":{"email":"a@example.com"},"canonical":{"email":"a@example.com","country":"US"}},
            "rewards_db": {"source":"rewards_db","status":{"source":"rewards_db","connected":True,"data_found":True},"raw":{"Id":1,"CountryCode":"US"},"canonical":{"country":"US","crowd_twist_id":111}},
            "crowd_twist": {"source":"crowd_twist","status":{"source":"crowd_twist","connected":True,"data_found":True},"raw":{"id":111,"country_code":"CA"},"canonical":{"email":"wrong@example.com","country":"CA","crowd_twist_id":111}},
        },
        "attributes": [
            {"attribute":"email","label":"Email","status":"MISMATCH","truth_source":"cps","truth_value":"a@example.com","wrong_sources":["crowd_twist"],"missing_sources":[],"unavailable_sources":[],"explanation":"mismatch","observations":{}},
            {"attribute":"country","label":"Country","status":"MISMATCH","truth_source":"cps","truth_value":"US","wrong_sources":["crowd_twist"],"missing_sources":[],"unavailable_sources":[],"explanation":"mismatch","observations":{}},
        ],
        "mismatch_count": mismatch,
        "missing_count": 0,
        "missing_record_count": 0,
        "deferred_attribute_count": 0,
        "invalid_format_count": 0,
        "unverifiable_count": 0,
        "deterministic_summary": "Found grounded disparities.",
        "suggestions": [
            {"suggestion_id":"SUG-001","attribute":"email","label":"Email","action":"UPDATE_VALUE","scope":"ATTRIBUTE","target_source":"crowd_twist","current_value":"wrong@example.com","recommended_value":"a@example.com","truth_source":"cps","priority":"HIGH","confidence":"HIGH","automation_eligible":True,"requires_manual_review":False,"reason":"truth","recommendation":"change"}
        ],
        "actionable_suggestion_count": exact,
        "manual_review_count": manual,
        "ai_analysis": {"summary":"Grounded AI explanation"},
        "judge_result": {"verdict":"ACCEPTED","content_disposition":"ANALYST_ACCEPTED"},
        "ai_execution": {"status":"SUCCESS","final_content_status":"ANALYST_ACCEPTED"},
        "mcp_execution": {"status":"SUCCESS"},
        "timings": {"end_to_end_ms":1000,"data_collection_agent_ms":200,"source_collection_wall_ms":150,"analysis_agent_ms":300,"judge_agent_ms":200,"dell_aia_queue_wait_ms":20},
        "warnings": [],
        "api_knowledge_summary": {"operation_count":5,"schema_count":2,"systems":["cps","crowdtwist"],"catalog_version":"1","generated_from":"unit"},
        "use_case_recommendations": [],
    }


def test_batch_parsing_aggregation_render_and_zip():
    parsed = parse_email_list("members.csv", b"Email,Name\na@example.com,A\nA@example.com,B\nb@example.com,B\nbad,C\n")
    assert parsed["submitted_count"] == 4 and parsed["unique_valid_count"] == 2
    assert parsed["duplicate_count"] == 1 and parsed["invalid_count"] == 1
    txt = parse_email_list("members.txt", b"a@example.com\nb@example.com\n")
    assert txt["unique_valid_count"] == 2
    assert _timing_stats([1, "2", 3])["avg_ms"] == 2
    assert _timing_stats([])["count"] == 0
    assert _percentage(1, 4) == 25.0 and _percentage(1, 0) == 0.0

    r1 = _report("DDR-AAAAAAAAAAAA", "a@example.com", mismatch=2, exact=1)
    r2 = _report("DDR-BBBBBBBBBBBB", "b@example.com", mismatch=0, exact=0, manual=1)
    row = _member_row("a@example.com", r1, record_id="ROW-0001", input_index=1)
    assert row["status"] == "COMPLETED" and row["judge_verdict"] == "ACCEPTED"
    failed = _member_row("x@example.com", None, "boom", record_id="ROW-0003", input_index=3)
    assert failed["status"] == "FAILED"

    parse_result = {
        "filename":"members.csv","submitted_count":2,"emails":["a@example.com","b@example.com"],
        "entries":[{"input_index":1,"record_id":"ROW-0001","email":"a@example.com"},{"input_index":2,"record_id":"ROW-0002","email":"b@example.com"}],
        "valid_transaction_count":2,"unique_valid_count":2,"deduplication_applied":True,
        "duplicates":[],"duplicate_rows":[],"duplicate_count":0,"invalid":[],"invalid_count":0,
    }
    items = [
        {"email":"a@example.com","record_id":"ROW-0001","input_index":1,"report":r1,"error":None,"timings":{"batch_member_end_to_end_ms":1100}},
        {"email":"b@example.com","record_id":"ROW-0002","input_index":2,"report":r2,"error":None,"timings":{"batch_member_end_to_end_ms":900}},
    ]
    summary = aggregate_batch("BAT-UNIT", parse_result, items)
    assert summary["processing"]["completed_count"] == 2
    insights = build_batch_insights(summary)
    assert insights["unique_members"] == 2
    grouped = deterministic_group_analysis(summary)
    assert grouped["status"] == "DETERMINISTIC"
    page = render_batch_summary_html(summary)
    assert "BAT-UNIT" in page and "Member-by-member" in page
    masked_page = render_batch_summary_html(summary, masked=True)
    assert "MASKED" in masked_page
    payload = build_batch_zip(summary, items, mask_pii=True)
    with zipfile.ZipFile(io.BytesIO(payload)) as zf:
        assert "00_BATCH_SUMMARY.html" in zf.namelist()
        assert "MANIFEST.json" in zf.namelist()


def test_report_renderer_and_run_store(tmp_path):
    report = _report()
    html = render_html_report(report, mask_pii=False)
    assert "Grounded disparities" in html or "grounded disparities" in html.casefold()
    masked = render_html_report(report, mask_pii=True)
    assert "MASKED" in masked

    async def run():
        settings = Settings(bootstrap_from_spring_config=False, runs_dir=tmp_path)
        store = RunStore(settings)
        await store.put(report)
        assert (await store.get(report["run_id"]))["run_id"] == report["run_id"]
        view = await store.view(report["run_id"], masked=False)
        assert view["report_privacy"] == "UNMASKED"
        masked_view = await store.view(report["run_id"], masked=True)
        assert masked_view["report_privacy"] == "MASKED"
        rendered = await store.html(report["run_id"], masked=False)
        assert "DDR-AAAAAAAAAAAA" in rendered
        path = await store.json_path(report["run_id"], masked=True)
        assert path.exists()
        with pytest.raises(RunNotFound):
            await store.get("DDR-CCCCCCCCCCCC")
        with pytest.raises(RunNotFound):
            await store.get("../bad")
    asyncio.run(run())


def test_use_case_recommend_and_compile_plan():
    # Use the shipped catalog so operation feasibility reflects the production package.
    kb = ApiKnowledgeBase()
    engine = UseCaseEngine(kb)
    report = _report()
    report["source_status"]["rewards_db"]["data_found"] = False
    report["source_status"]["rewards_db"]["error"] = "Multiple Rewards DB rows"
    report["attributes"].extend([
        {"attribute":"profile_id","label":"Profile ID","status":"MISMATCH","truth_source":"cps","truth_value":"P","wrong_sources":["crowd_twist"],"missing_sources":[],"explanation":"x"},
        {"attribute":"is_active","label":"Active","status":"INVALID_FORMAT","truth_source":"rewards_db","truth_value":True,"wrong_sources":["crowd_twist"],"missing_sources":[],"explanation":"x"},
        {"attribute":"crowd_twist_id","label":"CrowdTwist ID","status":"MISMATCH","truth_source":"crowd_twist","truth_value":111,"wrong_sources":["rewards_db"],"missing_sources":[],"explanation":"x"},
    ])
    report["suggestions"].extend([
        {"suggestion_id":"SUG-002","attribute":"crowd_twist_id","target_source":"rewards_db","current_value":1,"recommended_value":111,"truth_source":"crowd_twist","action":"UPDATE_VALUE","requires_manual_review":False,"scope":"ATTRIBUTE"},
        {"suggestion_id":"SUG-003","attribute":"country","target_source":"cps","current_value":"bad","recommended_value":None,"truth_source":"cps","action":"REVIEW","requires_manual_review":True,"scope":"ATTRIBUTE"},
    ])
    recs = engine.recommend(report)
    assert recs and recs[0].score >= recs[-1].score
    assert any(r.use_case_id == "UC-007" and r.priority == "CRITICAL" for r in recs)
    plan = engine.compile_plan("UC-013", report)
    assert plan.use_case_id == "UC-013" and plan.steps
    missing_plan = engine.compile_plan("UC-007", report)
    assert any(f["type"] == "SOURCE_RECORD_MISSING" for f in missing_plan.findings)
    dup_plan = engine.compile_plan("UC-008", report)
    assert isinstance(dup_plan.findings, list)
    with pytest.raises(KeyError):
        engine.compile_plan("UC-999", report)

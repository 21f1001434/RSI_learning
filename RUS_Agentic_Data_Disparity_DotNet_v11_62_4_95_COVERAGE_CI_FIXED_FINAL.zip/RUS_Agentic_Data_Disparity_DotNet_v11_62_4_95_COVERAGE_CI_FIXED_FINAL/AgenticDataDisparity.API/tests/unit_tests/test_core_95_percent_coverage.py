from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import pytest

from src.services.disparity_agent.agents import json_utils
from src.services.disparity_agent.api.file_security import (
    validate_job_id, validate_run_id, safe_download_filename, resolve_direct_child, validate_existing_artifact,
)
from src.services.disparity_agent.api.session_store import InMemorySessionStore
from src.services.disparity_agent.api_knowledge import ApiKnowledgeBase
from src.services.disparity_agent.comparator import compare_records
from src.services.disparity_agent.field_mapping import extract_path, canonicalize, source_supports
from src.services.disparity_agent.identifier_input import extract_identifiers, choose_identifier, resolve_identifier, SearchType
from src.services.disparity_agent.judgment import (
    canonical_judge_verdict, final_content_status, enforce_judge_on_report_dict,
)
from src.services.disparity_agent.memory.policy import (
    SAFE_STRATEGIES, _ucb, choose_strategy, choose_model, normalize_model_candidates,
)
from src.services.disparity_agent.memory.rsi import AdaptiveMemoryController, _parse_candidates, _controller_key, get_adaptive_memory
from src.services.disparity_agent.models import SourceName, SourceRecord, SourceStatus
from src.services.disparity_agent.normalization import (
    normalize_boolean, normalize_integer, normalize_phone, normalize_postal_code,
)
from src.services.disparity_agent.security import contains_mask_tokens, mask_text, sanitize
from src.services.disparity_agent.settings import Settings
from src.services.disparity_agent.suggestions import build_correction_suggestions
from src.services.disparity_agent.use_cases import UseCaseEngine


def run(coro):
    return asyncio.run(coro)


def rec(source, canonical=None, *, found=True, connected=True, raw=None):
    return SourceRecord(
        source=source,
        status=SourceStatus(source=source, connected=connected, data_found=found),
        raw={} if raw is None else raw,
        canonical=canonical or {},
    )


def records(cps=None, db=None, ct=None, **kw):
    return {
        SourceName.CPS: rec(SourceName.CPS, cps, found=kw.get('cps_found', True), connected=kw.get('cps_connected', True)),
        SourceName.REWARDS_DB: rec(SourceName.REWARDS_DB, db, found=kw.get('db_found', True), connected=kw.get('db_connected', True)),
        SourceName.CROWD_TWIST: rec(SourceName.CROWD_TWIST, ct, found=kw.get('ct_found', True), connected=kw.get('ct_connected', True), raw=kw.get('ct_raw')),
    }


def test_judgment_covers_all_publication_paths_and_structured_fallback():
    assert canonical_judge_verdict('accept with corrections') == 'PARTIAL'
    assert canonical_judge_verdict('approved') == 'ACCEPTED'
    assert canonical_judge_verdict('failed') == 'REJECTED'
    assert canonical_judge_verdict('strange') == 'REVIEW_REQUIRED'
    assert final_content_status('approved') == 'ANALYST_ACCEPTED'
    assert final_content_status('partial') == 'CORRECTED_BY_JUDGE'
    assert final_content_status('reject') == 'DETERMINISTIC_FALLBACK_AFTER_REJECTION'
    assert final_content_status('unknown') == 'DETERMINISTIC_FALLBACK_PENDING_REVIEW'

    class Dump:
        def model_dump(self, mode='json'):
            return {
                'attribute': 'email', 'label': 'Email', 'status': 'INVALID_FORMAT',
                'wrong_sources': [SourceName.CROWD_TWIST],
                'missing_sources': [SourceName.REWARDS_DB],
                'unavailable_sources': [SourceName.CPS],
                'truth_source': SourceName.CPS, 'truth_value': 'x@example.com',
                'explanation': 'bad',
            }

    base = {
        'attributes': [Dump(), {
            'attribute': 'phone', 'label': 'Phone', 'status': 'UNVERIFIABLE',
            'wrong_sources': [], 'missing_sources': [], 'unavailable_sources': [],
            'explanation': 'none',
        }],
        'suggestions': [{'recommendation': 'Fix email'}, {'recommendation': None}],
        'source_status': {
            SourceName.CPS: SourceStatus(source=SourceName.CPS, connected=True, data_found=True, latency_ms=1),
            'rewards_db': {'connected': False, 'data_found': False, 'stage': 'read', 'error_code': 'X'},
        },
        'deterministic_summary': 'det summary', 'actionable_suggestion_count': 1,
        'warnings': ['existing'],
        'ai_analysis': {'summary': 'unsafe narrative'},
        'ai_execution': {'status': 'SUCCESS'},
        'judge_result': {'verdict': 'PARTIAL', 'corrected_summary': 'corrected'},
    }
    partial = enforce_judge_on_report_dict(base)
    ai = partial['ai_analysis']
    assert ai['summary'] == 'corrected'
    assert ai['wrong_attributes'] and ai['missing_attributes'] and ai['deferred_attributes_due_to_missing_records']
    assert ai['format_issues'] and ai['unverifiable_attributes']
    assert ai['source_health']['cps']['connected'] is True
    assert ai['recommended_actions'] == ['Fix email']
    assert ai['priority'] == 'CRITICAL'
    assert partial['ai_execution']['judge_enforcement_applied'] is True

    accepted = dict(base)
    accepted['judge_result'] = {'status': 'ACCEPTED'}
    accepted['ai_analysis'] = {'summary': 'safe'}
    out = enforce_judge_on_report_dict(accepted)
    assert out['ai_analysis']['analyst_content_published'] is True

    rejected = dict(base)
    rejected['judge_result'] = {'raw_verdict': 'REJECTED'}
    rejected['actionable_suggestion_count'] = 0
    assert enforce_judge_on_report_dict(rejected)['ai_analysis']['priority'] == 'REVIEW'


def test_json_utils_exception_and_edge_paths():
    class DumpFallback:
        def model_dump(self, mode=None):
            if mode == 'json':
                raise RuntimeError('json dump no')
            return {'fallback': True}
    assert 'fallback' in json_utils._as_text(DumpFallback())

    class DumpFails:
        def model_dump(self, mode=None):
            raise RuntimeError('no')
        def __str__(self):
            return 'string-fallback'
    assert json_utils._as_text(DumpFails()) == 'string-fallback'

    # Bare tool events fall back to the last candidate.
    msgs = [SimpleNamespace(content='ToolCallRequest'), SimpleNamespace(content='FunctionCall')]
    assert json_utils.last_substantive_message(msgs) == 'FunctionCall'
    assert json_utils.all_message_text([SimpleNamespace(content=''), SimpleNamespace(content='abcdef')], max_chars=3) == 'abc'
    assert json_utils._loads_candidate('') is None
    assert json_utils._loads_candidate('{totally bad') is None
    # escaped quote/backslash path in balanced parser
    objs = json_utils._balanced_objects(r'xx {"a":"x\\\"}y","b":1} zz')
    assert isinstance(objs, list)


def test_api_knowledge_validation_edge_matrix(tmp_path):
    cat = tmp_path / 'cat.yaml'
    cat.write_text('''catalog_version: "1"\ntruth_policy: cps\nschemas:\n  Obj:\n    type: object\n    required: [email]\n    properties:\n      email: {type: string, format: email}\n      uid: {type: string, format: uuid}\n      integer: {type: integer}\n      enabled: {type: boolean}\n      object: {type: object}\n      array: {type: array}\n      nullable: {type: [string, "null"]}\n      optional: {type: string, optional: true}\n      mode: {type: string, enum: [A, B]}\n      constant: {type: string, const: FIXED}\n  Arr: {type: array}\n  Scalar: {type: string}\noperations:\n  - {id: no.schema, system: x, method: GET, path: /x}\n  - {id: obj, system: x, method: POST, path: /o, request_schema_ref: Obj}\n  - {id: arr, system: x, method: POST, path: /a, request_schema_ref: Arr}\n  - {id: scalar, system: x, method: POST, path: /s, request_schema_ref: Scalar}\n''', encoding='utf-8')
    kb = ApiKnowledgeBase(cat)
    assert kb.validate_payload('no.schema', {'x': 1}).valid
    assert not kb.validate_payload('arr', {'x': 1}).valid
    assert kb.validate_payload('arr', [1,2]).normalized_payload == {'items':[1,2]}
    assert kb.validate_payload('scalar', {'x': 1}).valid
    bad = kb.validate_payload('obj', {
        'email': 'bad', 'uid': 'bad', 'integer': True, 'enabled': 1,
        'object': [], 'array': {}, 'nullable': None, 'optional': None,
        'mode': 'C', 'constant': 'NO', 'unknown': 1,
    })
    joined = ' '.join(bad.errors)
    assert 'valid email' in joined and 'valid UUID' in joined and 'wrong type' in joined
    assert 'one of' in joined and 'must equal' in joined and 'Unknown field' in joined
    ok = kb.validate_payload('obj', {
        'email': 'a@b.com', 'uid': str(uuid4()), 'integer': 1, 'enabled': True,
        'object': {}, 'array': [], 'nullable': None, 'optional': None,
        'mode': 'A', 'constant': 'FIXED',
    })
    assert ok.valid
    with pytest.raises(KeyError): kb.get_operation('missing')
    with pytest.raises(KeyError): kb.get_schema('missing')
    safe = kb.safe_catalog_for_agent()
    assert safe['catalog_version'] == '1' and len(safe['operations']) == 4


def test_policy_all_selection_modes():
    assert _ucb(.5, 0, 0) >= .5
    assert normalize_model_candidates('m1', ['m1',' m2 ','','m2']) == ('m1','m2')
    assert normalize_model_candidates('', []) == ('gpt-oss-120b',)
    s, mode = choose_strategy({}, total_completed=0, rsi_enabled=False, exploration_interval=0, min_samples=1)
    assert s.strategy_id == 'grounded_baseline' and mode == 'rsi_disabled'
    stats={x.strategy_id:{'attempts':2,'avg_score':.5} for x in SAFE_STRATEGIES}
    s, mode = choose_strategy(stats,total_completed=6,rsi_enabled=True,exploration_interval=3,min_samples=2)
    assert mode == 'bounded_periodic_exploration'
    stats['grounded_claim_check']['avg_score']=.99
    s, mode = choose_strategy(stats,total_completed=7,rsi_enabled=True,exploration_interval=0,min_samples=2,preferred_strategy_id='grounded_claim_check')
    assert s.strategy_id=='grounded_claim_check' and mode=='learned_skill_exploitation'
    with pytest.raises(ValueError): choose_model((),{},total_completed=0,enabled=True,min_samples=1,exploration_interval=0)
    assert choose_model(('m1',),{},total_completed=0,enabled=True,min_samples=1,exploration_interval=0)==('m1','single_model')
    mstats={'m1':{'attempts':2,'avg_score':.5},'m2':{'attempts':2,'avg_score':.6}}
    assert choose_model(('m1','m2'),mstats,total_completed=4,enabled=True,min_samples=2,exploration_interval=0,preferred_model='m2')==('m2','learned_skill_model')
    model, mode=choose_model(('m1','m2'),{'m1':{'attempts':2},'m2':{'attempts':0}},total_completed=2,enabled=True,min_samples=2,exploration_interval=0)
    assert model=='m2' and mode=='champion_challenger_bootstrap'
    model, mode=choose_model(('m1','m2'),mstats,total_completed=4,enabled=True,min_samples=2,exploration_interval=2)
    assert mode=='champion_challenger_exploration'


def _controller(tmp_path, **overrides):
    args=dict(db_path=tmp_path/'m.sqlite3',enabled=True,rsi_enabled=True,retention_days=30,max_trajectories=100,replay_limit=3,min_samples=1,exploration_interval=0,latency_target_ms=45000,default_model='m1',model_candidates=('m2',),model_selection_enabled=True,model_min_samples=1,model_exploration_interval=0,skill_min_samples=1)
    args.update(overrides)
    return AdaptiveMemoryController(**args)


def test_rsi_disabled_failure_and_scoring_paths(tmp_path, monkeypatch):
    disabled=_controller(tmp_path,enabled=False)
    ctx=run(disabled.begin_analysis(task_signature='x'))
    assert ctx.selection_mode=='rsi_disabled' and run(disabled.status())['enabled'] is False
    assert run(disabled.record_write_verification({'x':1})) is None
    assert run(disabled.complete_analysis(SimpleNamespace(),ctx))['recorded'] is False

    c=_controller(tmp_path)
    async def boom(*a,**k): raise RuntimeError('boom')
    monkeypatch.setattr(c.store,'initialize',boom)
    run(c.initialize()); assert 'RuntimeError' in c.last_error
    monkeypatch.setattr(c.store,'policy_stats',boom)
    failctx=run(c.begin_analysis(task_signature='x'))
    assert failctx.selection_mode=='memory_unavailable_fail_open'

    reports=[
      SimpleNamespace(mcp_execution={'status':'FAIL'}, ai_execution={'status':'FAIL'}, judge_result={'verdict':'REJECTED'}, timings={}),
      SimpleNamespace(mcp_execution={'status':'SUCCESS'}, ai_execution={'status':'SUCCESS','analysis_agent':{'output_contract':{'status':'NORMALIZED_JSON'}},'judge_agent':{'output_contract':{'status':'NORMALIZED_JSON'}}}, judge_result={'verdict':'PARTIAL'}, timings={'total_processing_ms':100}),
      SimpleNamespace(mcp_execution={}, ai_execution={'status':'SUCCESS'}, judge_result={'status':'REVIEW_REQUIRED'}, timings={'end_to_end_ms':999999}),
    ]
    vals=[c.score_analysis(x) for x in reports]
    assert vals[0][1]=='FAILED' and 'failed' in vals[0][2].lower()
    assert vals[1][1]=='SUCCESS' and 'corrected' in vals[1][2].lower()
    assert vals[2][1]=='FAILED'
    assert 'rejected' in c._lesson('REJECTED','','',True).lower()
    assert 'corrected' in c._lesson('PARTIAL','','',True).lower()
    assert 'accepted' in c._lesson('ACCEPTED','','',True).lower()
    assert 'grounded' in c._lesson('REVIEW_REQUIRED','','',True).lower()


def test_rsi_complete_write_status_and_factory_paths(tmp_path, monkeypatch):
    c=_controller(tmp_path)
    run(c.initialize())
    ctx=run(c.begin_analysis(task_signature='sig'))
    source_obj=SimpleNamespace(connected=True,data_found=True)
    report=SimpleNamespace(
        run_id='R',mcp_execution={'status':'SUCCESS'},
        ai_execution={'status':'SUCCESS','model':'m2','analysis_agent':{'output_contract':{'status':'DIRECT_JSON'}},'judge_agent':{'output_contract':{'status':'DIRECT_JSON'}}},
        judge_result={'verdict':'ACCEPTED'},timings={'end_to_end_ms':10},
        source_status={SourceName.CPS: source_obj, SourceName.REWARDS_DB:{'connected':True,'data_found':False}, SourceName.CROWD_TWIST:{'connected':False,'data_found':False}},
    )
    out=run(c.complete_analysis(report,ctx)); assert out['recorded'] is True
    assert run(c.record_write_verification({'source':'rewards_db','field':'country','verified':True,'outcome':'SUCCESS','dry_run':False,'actor_role':'Business','duration_ms':1}))
    status=run(c.status()); assert status['enabled'] is True and status['bounded_rsi'] is True

    async def boom(*a,**k): raise RuntimeError('boom')
    monkeypatch.setattr(c.store,'record_trajectory',boom)
    assert run(c.complete_analysis(report,ctx))['memory_status']=='DEGRADED_FAIL_OPEN'
    monkeypatch.setattr(c.store,'record_write_verification',boom)
    assert run(c.record_write_verification({'x':1})) is None
    monkeypatch.setattr(c.store,'status',boom)
    assert run(c.status())['status']=='DEGRADED_FAIL_OPEN'

    assert _parse_candidates([' a ','','b'])==('a','b')
    assert _parse_candidates('a, b,,')==('a','b')
    settings=SimpleNamespace(adaptive_memory_db_path=tmp_path/'f.sqlite3',adaptive_memory_enabled=True,rsi_enabled=True,adaptive_memory_retention_days=30,adaptive_memory_max_trajectories=100,adaptive_memory_replay_limit=3,rsi_min_samples_per_strategy=1,rsi_exploration_interval=0,rsi_latency_target_ms=45000,dell_aia_model='m1',dell_aia_model_candidates='m2',adaptive_model_selection_enabled=True,adaptive_model_min_samples=1,adaptive_model_exploration_interval=0,adaptive_skill_min_samples=1)
    assert len(_controller_key(settings))==15
    assert get_adaptive_memory(settings) is get_adaptive_memory(settings)


def test_comparator_standard_and_policy_edge_matrix():
    settings=Settings(bootstrap_from_spring_config=False,flag_missing_supported_attributes=True,allow_crowd_twist_as_last_resort=True)
    standard={'email':{'label':'Email','type':'email','policy':'standard','sources':{'cps':{},'rewards_db':{},'crowd_twist':{}}}}
    assert compare_records(records({'email':'a@b.com'},{'email':'x@b.com'},{'email':'a@b.com'}),standard,settings)[0].status=='MISMATCH'
    assert compare_records(records({'email':'a@b.com'},{},{'email':'a@b.com'}),standard,settings)[0].status=='MISSING'
    assert compare_records(records({'email':'a@b.com'},{'email':'a@b.com'},{},ct_found=False),standard,settings)[0].status in {'SOURCE_RECORD_MISSING','SOURCE_UNAVAILABLE'}
    assert compare_records(records({'email':'bad'},{'email':'bad'},{'email':'bad'}),standard,settings)[0].status=='TRUTH_FORMAT_INVALID'
    assert compare_records(records({}, {}, {'email':'ct@b.com'}),standard,settings)[0].truth_source==SourceName.CROWD_TWIST

    ctid={'crowd_twist_id':{'label':'CT','type':'integer','policy':'crowd_twist_authoritative','sources':{'rewards_db':{},'crowd_twist':{}}}}
    assert compare_records(records({}, {'crowd_twist_id':1},{'crowd_twist_id':2}),ctid,settings)[0].status=='MISMATCH'
    assert compare_records(records({}, {},{},ct_found=False),ctid,settings)[0].status in {'SOURCE_RECORD_MISSING','SOURCE_UNAVAILABLE'}
    assert compare_records(records({}, {},{'crowd_twist_id':'bad'}),ctid,settings)[0].status=='TRUTH_FORMAT_INVALID'

    active={'is_active':{'label':'Active','type':'boolean','policy':'boolean_or','sources':{'rewards_db':{},'crowd_twist':{}}}}
    assert compare_records(records({}, {'is_active':False},{'is_active':True}),active,settings)[0].status=='MISMATCH'
    assert compare_records(records({}, {},{}),active,settings)[0].status in {'UNVERIFIABLE','MISSING'}

    country={'country':{'label':'Country','type':'country','policy':'crowd_twist_country_code','sources':{'cps':{},'rewards_db':{},'crowd_twist':{}}}}
    assert compare_records(records({'country':'US'},{'country':'US'},{'country':'CA'},ct_raw={'country_code':'CA'}),country,settings)[0].status=='MISMATCH'
    assert compare_records(records({'country':'US'},{'country':'CA'},{'country':'US'},ct_raw={'country_code':'US'}),country,settings)[0].status=='COUNTRY_SOURCE_CONFLICT'
    assert compare_records(records({'country':'US'},{'country':'US'},{'country':'United States'},ct_raw={'country':'United States'}),country,settings)[0].status=='MATCH'
    assert compare_records(records({'country':'bad-country'},{'country':'US'},{'country':'US'}),country,settings)[0].status=='TRUTH_FORMAT_INVALID'
    assert compare_records(records({}, {'country':'bad-country'},{'country':'US'}),country,settings)[0].status=='TRUTH_FORMAT_INVALID'
    assert compare_records(records({}, {},{}),country,settings)[0].status in {'UNVERIFIABLE','SOURCE_RECORD_MISSING'}


def test_security_normalization_identifier_field_and_suggestion_edges():
    assert normalize_boolean(1).value is True and normalize_boolean(0).value is False
    assert not normalize_integer(True).valid
    assert normalize_integer(2.0).value == 2 and normalize_integer('2.00').value == 2
    assert normalize_phone('00123456789').value == '123456789'
    assert not normalize_postal_code('---').valid
    masked=mask_text('a@b.com'); assert contains_mask_tokens(masked)
    assert mask_text('a@b.com').startswith('<email:')
    assert sanitize({'email':'a@b.com','nested':[{'phone':'1234567890'}]})['email'] != 'a@b.com'
    assert extract_path({'A':{'B':1}},'a.b') == 1
    assert extract_path({'x':'notlist'},'x[0]') is None
    assert canonicalize({'x':1},SourceName.CPS,{'z':{'sources':{'rewards_db':{'paths':['x']}}}})=={}
    assert not source_supports({'sources':{}},SourceName.CPS)
    matches=extract_identifiers('CrowdTwist id: 123456789 and x@y.com')
    assert choose_identifier('unknown preference',matches) is not None
    assert resolve_identifier('analyze it',{'last_identifier':{'search_type':'email','value':'x@y.com'}}).search_type==SearchType.EMAIL

    verdicts=compare_records(records({'email':'a@b.com'},{'email':'x@b.com'},{'email':'x@b.com'}),{'email':{'label':'Email','type':'email','policy':'standard','sources':{'cps':{},'rewards_db':{},'crowd_twist':{}}}},Settings(bootstrap_from_spring_config=False))
    suggestions=build_correction_suggestions(verdicts, records({'email':'a@b.com'},{'email':'x@b.com'},{'email':'x@b.com'}))
    assert suggestions


def test_use_case_filters_and_remediation_edge_paths():
    engine=UseCaseEngine(ApiKnowledgeBase())
    data={
      'attributes':[
        {'attribute':'email','label':'Email','status':'MATCH','truth_source':'cps','truth_value':'a@b.com','wrong_sources':[],'missing_sources':[],'explanation':'ok'},
        {'attribute':'country','label':'Country','status':'MISSING','truth_source':'cps','truth_value':'US','wrong_sources':[],'missing_sources':['crowd_twist'],'explanation':'missing'},
        {'attribute':'is_active','label':'Active','status':'INVALID_FORMAT','truth_source':'rewards_db','truth_value':True,'wrong_sources':['crowd_twist'],'missing_sources':[],'explanation':'bad'},
      ],
      'source_status':{'rewards_db':{'data_found':True,'error':'Multiple Rewards DB rows'},'cps':{'data_found':False,'connected':True}},
      'records':{'rewards_db':{'raw':{}},'crowd_twist':{'raw':{}}},
      'suggestions':[
        {'suggestion_id':'1','attribute':'country','target_source':'crowd_twist','current_value':None,'recommended_value':'US','truth_source':'cps','action':'UPDATE_VALUE','requires_manual_review':False},
        {'suggestion_id':'2','attribute':'email','target_source':'rewards_db','current_value':'x','recommended_value':'a@b.com','truth_source':'cps','action':'UPDATE_VALUE','requires_manual_review':False},
        {'suggestion_id':'3','attribute':'email','target_source':'cps','current_value':'x','recommended_value':'a@b.com','truth_source':'cps','action':'REVIEW','requires_manual_review':False},
        {'suggestion_id':'4','attribute':'email','target_source':'other','current_value':'x','recommended_value':'a@b.com','truth_source':'cps','action':'REVIEW','requires_manual_review':False},
        {'suggestion_id':'5','attribute':'country','target_source':'crowd_twist','current_value':None,'recommended_value':None,'truth_source':'cps','action':'REVIEW','requires_manual_review':True},
      ]
    }
    assert engine._findings_for('UC-007',data)
    assert engine._findings_for('UC-008',data)
    assert engine._findings_for('UC-005',data)
    assert engine._findings_for('UC-006',data)
    actions=engine._remediation_for('UC-005',data,[])
    assert any(x.get('readiness')=='MANUAL_REVIEW' for x in actions)
    assert any(x.get('target_source')=='crowd_twist' for x in actions)
    actions2=engine._remediation_for('UC-002',data,[])
    assert any(x.get('target_source')=='rewards_db' for x in actions2)
    assert isinstance(actions,list)
    steps=engine._steps_for({'operations':['direct.cps.read','direct.rewards_db.update_member'],'acceptance':['ok']},data,actions)
    assert [s.step for s in steps] == list(range(1,len(steps)+1))


def test_file_security_direct_child_edge_cases(tmp_path):
    p=tmp_path/'a.txt'; p.write_text('x')
    assert validate_run_id('DDR-AAAAAAAAAAAA')=='DDR-AAAAAAAAAAAA'
    assert validate_job_id('JOB-AAAAAAAAAAAAAAAA')=='JOB-AAAAAAAAAAAAAAAA'
    assert safe_download_filename('ok.json')=='ok.json'
    assert resolve_direct_child(tmp_path,'a.txt')==p.resolve()
    assert validate_existing_artifact(p,tmp_path)==p.resolve()
    with pytest.raises(FileNotFoundError): validate_existing_artifact(tmp_path/'missing.txt',tmp_path)


def test_session_store_capacity_and_missing_session_branches():
    from src.services.disparity_agent.api.session_store import SessionNotFound
    async def scenario():
        store=InMemorySessionStore(ttl_minutes=1,max_messages=4,max_sessions=10)
        created=[]
        for i in range(11):
            created.append(await store.create({'i':i}))
        with pytest.raises(SessionNotFound):
            await store.get(created[0].session_id)
        missing='SES-'+'F'*32
        for call in [
            lambda: store.get(missing),
            lambda: store.append(missing,role='user',content='x'),
            lambda: store.set_active_report(missing,{'run_id':'DDR-AAAAAAAAAAAA'}),
            lambda: store.set_active_batch(missing,'JOB-AAAAAAAAAAAAAAAA'),
            lambda: store.set_active_batch_status(missing,'JOB-AAAAAAAAAAAAAAAA',status='RUNNING',phase='READ'),
            lambda: store.set_active_batch_result(missing,job_id='JOB-AAAAAAAAAAAAAAAA',batch_id='BAT-1',summary={}),
            lambda: store.clear(missing),
        ]:
            with pytest.raises(SessionNotFound):
                await call()
    run(scenario())


def test_security_key_specific_masking_and_empty_normalizers():
    guid='12345678-1234-1234-9234-1234567890ab'
    payload=sanitize({
        'profile_id':guid,'identifier_value':'a@b.com','crowd_twist_id':123,
        'first_name':'Alice','phone':'1234567890','postal_code':'560001',
        'empty':'','none':None,
    })
    assert payload['profile_id'].startswith('<guid:')
    assert payload['identifier_value'].startswith('<email:')
    assert payload['crowd_twist_id'].startswith('<id:')
    assert payload['first_name'].startswith('<name:')
    assert payload['phone'].startswith('<phone:')
    assert payload['postal_code'].startswith('<location:')
    assert normalize_boolean('no').value is False
    assert not normalize_integer(1.5).valid
    from src.services.disparity_agent.normalization import normalize_text_ci, normalize_phone, normalize_postal_code
    assert normalize_text_ci('').value is None
    assert normalize_phone('').value is None
    assert normalize_postal_code('').value is None


def test_concurrency_profile_is_the_managed_8_by_2_profile():
    from src.services.disparity_agent.concurrency_policy import fixed_batch_profile
    assert fixed_batch_profile() == (8,2,True)


def test_comparator_additional_country_and_active_branches():
    settings=Settings(bootstrap_from_spring_config=False,flag_missing_supported_attributes=True)
    active={'is_active':{'label':'Active','type':'boolean','policy':'boolean_or','sources':{'rewards_db':{},'crowd_twist':{}}}}
    # Missing existing value and unavailable member record.
    assert compare_records(records({}, {'is_active':True},{},ct_found=True),active,settings)[0].status=='MISSING'
    assert compare_records(records({}, {'is_active':True},{},ct_found=False,ct_connected=False),active,settings)[0].status=='SOURCE_UNAVAILABLE'
    # Invalid counterpart while True side still establishes OR=True.
    assert compare_records(records({}, {'is_active':True},{'is_active':'maybe'}),active,settings)[0].status=='INVALID_FORMAT'

    country={'country':{'label':'Country','type':'country','policy':'crowd_twist_country_code','sources':{'cps':{},'rewards_db':{},'crowd_twist':{}}}}
    # CPS broad region with no exact DB resolution requires review.
    v=compare_records(records({'country':'USCanada'},{},{},ct_found=False),country,settings)[0]
    assert v.status=='COUNTRY_REVIEW_REQUIRED'
    # Exact fallback from Rewards DB; missing CT field and missing CT record.
    assert compare_records(records({}, {'country':'US'},{}),country,settings)[0].status=='MISSING'
    assert compare_records(records({}, {'country':'US'},{},ct_found=False),country,settings)[0].status in {'SOURCE_RECORD_MISSING','SOURCE_UNAVAILABLE'}
    # Same semantic country but noncanonical country_code visible -> invalid format.
    assert compare_records(records({'country':'US'},{'country':'US'},{'country':'United States'},ct_raw={'country_code':'United States'}),country,settings)[0].status=='INVALID_FORMAT'

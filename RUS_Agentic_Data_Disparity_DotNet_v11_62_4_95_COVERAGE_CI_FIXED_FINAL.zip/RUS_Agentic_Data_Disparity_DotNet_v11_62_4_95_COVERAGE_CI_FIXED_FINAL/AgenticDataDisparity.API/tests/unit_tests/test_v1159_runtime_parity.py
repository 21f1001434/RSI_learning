from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parents[2]
DOMAIN = ROOT / "src/services/disparity_agent"

EXPECTED_MODULES = {
    "api_knowledge.py", "batch.py", "comparator.py", "concurrency_policy.py",
    "config_server.py", "country_reference.py", "field_mapping.py", "identifier_input.py",
    "identity_resolution.py", "judgment.py", "mcp_server.py", "mock_data.py", "models.py",
    "normalization.py", "pipeline.py", "reporting.py", "security.py", "settings.py",
    "suggestions.py", "use_cases.py", "agents/model_client.py", "agents/orchestrator.py",
    "agents/json_utils.py", "agents/playwright_fallback.py", "api/routes.py",
    "api/chat_service.py", "api/source_operations.py", "api/batch_jobs.py", "api/config.py",
    "api/dependencies.py", "api/run_store.py", "api/schemas.py", "api/session_store.py",
    "connectors/cps.py", "connectors/crowd_twist.py", "connectors/oauth.py",
    "connectors/odbc_utils.py", "connectors/rewards_db.py", "connectors/tcps.py",
}

EXPECTED_ROUTE_PATHS = {
    "/analysis/individual", "/chat", "/batches", "/batches/upload",
    "/source-operations/query", "/source-operations/cps/query",
    "/source-operations/changes/plan",
    "/source-operations/changes/{change_id}/confirm-1",
    "/source-operations/changes/{change_id}/confirm-2",
    "/source-operations/changes/{change_id}/popup-opened",
    "/source-operations/changes/{change_id}/cancel",
    "/source-operations/spreadsheet-import", "/audit-trail", "/use-cases/plan",
}


def test_all_active_v1159_domain_modules_migrated():
    present = {p.relative_to(DOMAIN).as_posix() for p in DOMAIN.rglob("*.py")}
    assert EXPECTED_MODULES <= present
    assert not (DOMAIN / "hardcoded_credentials.py").exists()


def test_core_v1159_agent_routes_are_still_declared():
    declared = set()
    for p in (ROOT / "src").rglob("*.py"):
        tree = ast.parse(p.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for dec in node.decorator_list:
                if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and dec.args:
                    arg = dec.args[0]
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        declared.add(arg.value)
    assert EXPECTED_ROUTE_PATHS <= declared


def test_enterprise_entrypoint_replaces_old_root_entrypoint():
    assert (ROOT / "src/main.py").exists()
    assert not (ROOT / "api_app.py").exists()
    assert not (ROOT / "disparity_agent").exists()

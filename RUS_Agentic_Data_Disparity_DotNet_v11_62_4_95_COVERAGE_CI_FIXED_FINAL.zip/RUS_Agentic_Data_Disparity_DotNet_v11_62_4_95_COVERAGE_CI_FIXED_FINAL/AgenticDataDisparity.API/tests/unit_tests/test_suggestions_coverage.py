from __future__ import annotations

from src.services.disparity_agent.models import (
    AttributeObservation, AttributeVerdict, SourceName, SourceRecord, SourceStatus
)
from src.services.disparity_agent.suggestions import build_correction_suggestions


def obs(source, value=None, *, present=True, valid=True, supported=True, found=True, note=None):
    return AttributeObservation(
        source=source, supported=supported, present=present,
        source_connected=True, record_found=found,
        raw_value=value, normalized_value=value,
        valid_format=valid, normalization_note=note,
    )


def verdict(attribute, status, truth_source, truth_value, observations, *, wrong=None, missing=None, unavailable=None, explanation='x'):
    return AttributeVerdict(
        attribute=attribute, label=attribute.replace('_',' ').title(),
        truth_source=truth_source, truth_value=truth_value, status=status,
        observations=observations, wrong_sources=wrong or [], missing_sources=missing or [],
        unavailable_sources=unavailable or [], explanation=explanation,
    )


def record(source, *, connected=True, found=True, canonical=None):
    return SourceRecord(
        source=source,
        status=SourceStatus(source=source, connected=connected, data_found=found),
        raw={}, canonical=canonical or {},
    )


def all_obs(cps='x', db='x', ct='x'):
    return {
        SourceName.CPS: obs(SourceName.CPS, cps),
        SourceName.REWARDS_DB: obs(SourceName.REWARDS_DB, db),
        SourceName.CROWD_TWIST: obs(SourceName.CROWD_TWIST, ct),
    }


def test_record_level_missing_and_unavailable_are_single_findings():
    records = {
        SourceName.CPS: record(SourceName.CPS, connected=False, found=False),
        SourceName.REWARDS_DB: record(SourceName.REWARDS_DB, connected=True, found=False),
        SourceName.CROWD_TWIST: record(SourceName.CROWD_TWIST, connected=True, found=False),
    }
    out = build_correction_suggestions([], records)
    assert [x.action for x in out] == [
        'RESTORE_SOURCE_ACCESS', 'RESOLVE_MISSING_MEMBER_RECORD', 'RESOLVE_MISSING_MEMBER_RECORD'
    ]
    assert all(x.requires_manual_review for x in out)


def test_crowdtwist_id_authority_and_review_paths():
    o = all_obs(cps=None, db=111, ct=222)
    v = verdict('crowd_twist_id','MISMATCH',SourceName.CROWD_TWIST,222,o,wrong=[SourceName.REWARDS_DB])
    out = build_correction_suggestions([v])
    assert len(out)==1 and out[0].target_source == SourceName.REWARDS_DB
    assert out[0].recommended_value == 222 and out[0].automation_eligible

    o2 = all_obs(cps=None, db=None, ct=222)
    o2[SourceName.REWARDS_DB] = obs(SourceName.REWARDS_DB, None, present=False)
    v2 = verdict('crowd_twist_id','MISSING',SourceName.CROWD_TWIST,222,o2,missing=[SourceName.REWARDS_DB])
    assert build_correction_suggestions([v2])[0].action == 'POPULATE_CROWD_TWIST_ID'

    o3 = all_obs(cps=None, db=111, ct='bad')
    o3[SourceName.CROWD_TWIST] = obs(SourceName.CROWD_TWIST,'bad',valid=False)
    v3 = verdict('crowd_twist_id','TRUTH_FORMAT_INVALID',SourceName.CROWD_TWIST,'bad',o3)
    assert build_correction_suggestions([v3])[0].action == 'REVIEW_CROWD_TWIST_ID'


def test_active_or_gate_update_and_review():
    o = all_obs(cps=None, db=False, ct=True)
    v = verdict('is_active','MISMATCH',SourceName.CROWD_TWIST,True,o,wrong=[SourceName.REWARDS_DB])
    out = build_correction_suggestions([v])
    assert out[0].action == 'SET_ACTIVE_TRUE_OR_GATE' and out[0].recommended_value is True

    v2 = verdict('is_active','BOOLEAN_REVIEW_REQUIRED',SourceName.REWARDS_DB,None,o)
    review = build_correction_suggestions([v2])[0]
    assert review.action == 'REVIEW_ACTIVE_OR_GATE' and review.requires_manual_review


def test_country_exact_cps_updates_ct_and_flags_db_conflict():
    o = all_obs(cps='US', db='CA', ct='CA')
    v = verdict('country','MISMATCH',SourceName.CPS,'US',o,wrong=[SourceName.CROWD_TWIST, SourceName.REWARDS_DB])
    out = build_correction_suggestions([v])
    actions = {x.action for x in out}
    assert 'UPDATE_CROWD_TWIST_COUNTRY_CODE' in actions
    assert 'REVIEW_REWARDS_COUNTRY_CONFLICT' in actions
    ct = next(x for x in out if x.target_source == SourceName.CROWD_TWIST)
    assert ct.recommended_value == 'US'


def test_country_invalid_truth_requires_manual_resolution():
    o = all_obs(cps='Atlantis', db='US', ct='US')
    o[SourceName.CPS] = obs(SourceName.CPS,'Atlantis',valid=False)
    v = verdict('country','TRUTH_FORMAT_INVALID',SourceName.CPS,'Atlantis',o,explanation='invalid country')
    out = build_correction_suggestions([v])
    assert len(out)==1 and out[0].action == 'REVIEW_AUTHORITATIVE_VALUE'
    assert out[0].recommended_value is None


def test_generic_mismatch_missing_truth_invalid_and_unverifiable():
    o = all_obs(cps='Alice', db='Bob', ct='Alice')
    v = verdict('first_name','MISMATCH',SourceName.CPS,'Alice',o,wrong=[SourceName.REWARDS_DB])
    out = build_correction_suggestions([v])
    assert out[0].action == 'UPDATE_VALUE' and out[0].recommended_value == 'Alice'

    o_bad = all_obs(cps='Alice', db='bad', ct='Alice')
    o_bad[SourceName.REWARDS_DB] = obs(SourceName.REWARDS_DB,'bad',valid=False)
    v_bad = verdict('first_name','INVALID_FORMAT',SourceName.CPS,'Alice',o_bad,wrong=[SourceName.REWARDS_DB])
    assert build_correction_suggestions([v_bad])[0].action == 'REPLACE_INVALID_VALUE'

    o_missing = all_obs(cps='Alice', db=None, ct='Alice')
    o_missing[SourceName.REWARDS_DB] = obs(SourceName.REWARDS_DB,None,present=False)
    v_missing = verdict('first_name','MISSING',SourceName.CPS,'Alice',o_missing,missing=[SourceName.REWARDS_DB])
    assert build_correction_suggestions([v_missing])[0].action == 'POPULATE_MISSING_VALUE'

    o_truth_bad = all_obs(cps='?', db='Alice', ct='Alice')
    o_truth_bad[SourceName.CPS] = obs(SourceName.CPS,'?',valid=False,note='bad format')
    v_truth_bad = verdict('first_name','TRUTH_FORMAT_INVALID',SourceName.CPS,'?',o_truth_bad)
    assert build_correction_suggestions([v_truth_bad])[0].action == 'REVIEW_AUTHORITATIVE_VALUE'

    o_none = {
        SourceName.CPS: obs(SourceName.CPS,None,present=False),
        SourceName.REWARDS_DB: obs(SourceName.REWARDS_DB,None,present=False),
        SourceName.CROWD_TWIST: obs(SourceName.CROWD_TWIST,'OnlyCT'),
    }
    v_none = verdict('first_name','UNVERIFIABLE',None,None,o_none)
    assert build_correction_suggestions([v_none])[0].action == 'NO_SAFE_CHANGE'

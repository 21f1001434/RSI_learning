from src.services.disparity_agent.models import SourceName

def test_source_enum_contains_three_sources():
    values = {x.value for x in SourceName}
    assert {'cps', 'rewards_db', 'crowd_twist'} <= values

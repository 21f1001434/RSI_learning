from src.prompt_manager import PromptManager

def test_prompt_manager_includes_governance():
    text = PromptManager().system_prompt().lower()
    assert 'cps' in text and 'read-only' in text and 'approval' in text

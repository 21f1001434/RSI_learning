from __future__ import annotations

import asyncio
from datetime import timedelta
from types import SimpleNamespace

import httpx
import pytest

from src.services.disparity_agent.api.schemas import SourceOperation, SourceSystem
from src.services.disparity_agent.api.session_store import InMemorySessionStore, SessionNotFound, utc_now
from src.services.disparity_agent.api.source_operations import (
    SourceOperationError,
    SourceOperationService,
    _can_govern_agentic_write,
    _ci_get,
    _dedupe_emails,
    _normalize_actor_role,
    _role_approval_profile,
    _safe_http_preview,
    _source_label,
    _values_equal,
    _write_data_type,
)
from src.services.disparity_agent.identifier_input import IdentifierMatch
from src.services.disparity_agent.models import SearchType, SourceName
from src.services.disparity_agent.settings import Settings


def _make_service(tmp_path, mode="live"):
    settings = Settings(
        bootstrap_from_spring_config=False,
        source_write_mode=mode,
        source_write_audit_file=tmp_path / "audit.jsonl",
        source_write_audit_unmasked_file=tmp_path / "audit.unmasked.jsonl",
    )
    store = InMemorySessionStore(ttl_minutes=10, max_messages=8, max_sessions=10)
    return SourceOperationService(settings, store), store


def test_source_operation_module_helpers():
    assert _ci_get({"Email": "a"}, "email") == "a"
    assert _ci_get([], "x") is None
    assert _values_equal("A@B.com", "a@b.com", "email")
    assert _values_equal("true", True)
    assert not _values_equal("US", "CA", "country")
    assert _write_data_type(SourceSystem.CROWD_TWIST, "email") == "email"
    assert _write_data_type(SourceSystem.CROWD_TWIST, "missing") is None
    assert _dedupe_emails([" A@B.com ", "a@b.com", "bad", "c@d.com"]) == ["A@B.com", "c@d.com"]
    assert _source_label(SourceSystem.REWARDS_DB) == "Rewards DB"
    assert _normalize_actor_role("administrator") == "Customer"
    assert _normalize_actor_role("operator") == "Technical"
    assert _normalize_actor_role("buisness") == "Business"
    assert _normalize_actor_role("anything") == "Customer"
    assert _can_govern_agentic_write("Customer") and not _can_govern_agentic_write("")
    assert _role_approval_profile("Business") == "business_chat_single"
    assert _role_approval_profile("Technical", explicit=True) == "technical_explicit_chat"

    req = httpx.Request("GET", "https://example.test")
    response = httpx.Response(200, request=req, text="hello\nworld")
    assert _safe_http_preview(response) == "hello world"
    secret = httpx.Response(200, request=req, text='{"access_token":"x"}')
    assert _safe_http_preview(secret) == "<sensitive response omitted>"


def test_role_projection_write_modes_and_session_store(tmp_path):
    async def run():
        service, store = _make_service(tmp_path)
        state = await store.create({"actor_role": "Customer", "actor_dry_run_enabled": True})
        await store.append(state.session_id, role="user", content="one")
        for i in range(12):
            await store.append(state.session_id, role="assistant", content=str(i))
        current = await store.get(state.session_id)
        assert len(current.messages) == 8
        assert service._effective_write_mode(current) == "dry_run"
        assert await service.apply_session_write_policy(state.session_id, actor_role="Admin", actor_dry_run_enabled=True) == "live"
        assert current.metadata["actor_dry_run_enabled"] is False

        disabled, _ = _make_service(tmp_path, mode="disabled")
        assert disabled._effective_write_mode(current) == "disabled"

        report = {"run_id": "DDR-AAAAAAAAAAAA", "search_type": "email", "search_value": "x@y.com", "analysis_completeness": "FULL"}
        await store.set_active_report(state.session_id, report)
        await store.set_active_batch(state.session_id, "JOB-1234567890ABCDEF")
        await store.set_active_batch_status(state.session_id, "JOB-1234567890ABCDEF", status="RUNNING", phase="ANALYSIS")
        await store.set_active_batch_result(state.session_id, job_id="JOB-1234567890ABCDEF", batch_id="BAT-1", summary={"processing":{"completed_count":1,"failed_count":0},"population_metrics":{"unique_members_processed":1},"totals":{"exact_changes":1,"manual_review":0}})
        view = store.view(await store.get(state.session_id))
        assert view.active_context == "batch" and view.has_active_batch_summary
        await store.clear(state.session_id)
        assert (await store.get(state.session_id)).active_context == "none"
        assert await store.delete(state.session_id)
        with pytest.raises(SessionNotFound):
            await store.get(state.session_id)

        exp = await store.create()
        exp.expires_at = utc_now() - timedelta(seconds=1)
        assert await store.cleanup() == 1

    asyncio.run(run())

    result = {
        "duration_ms": 1,
        "members": [{
            "resolved_identity": {"email":"x@y.com","crowd_twist_id":5,"member_key":6},
            "lookup_path": "x",
            "duration_ms": 2,
            "results": {
                "cps": {"canonical":{"email":"x@y.com","crowd_twist_id":5,"secret":"x"},"record":{},"raw":{},"diagnostics":{}},
            },
        }],
    }
    customer = SourceOperationService.project_query_for_role(result, "Customer")
    assert "duration_ms" not in customer and "crowd_twist_id" not in customer["members"][0]["resolved_identity"]
    business = SourceOperationService.project_query_for_role(result, "Business")
    assert "crowd_twist_id" in business["members"][0]["resolved_identity"]
    assert SourceOperationService.project_query_for_role(result, "Admin") is result
    with pytest.raises(SourceOperationError):
        SourceOperationService.require_agentic_write_role(None)


def test_source_operation_language_parsing_matrix(tmp_path):
    service, _ = _make_service(tmp_path)
    assert service.detect_sources("show CPS and Rewards DB and CrowdTwist") == [SourceSystem.CPS, SourceSystem.REWARDS_DB, SourceSystem.CROWD_TWIST]
    assert SourceSystem.CROWD_TWIST in service.detect_requested_target_sources("update country in CrowdTwist", "country")
    assert service.uses_deterministic_recommendation("update country as recommended")
    assert not service.uses_deterministic_recommendation("update country to US")
    assert service.is_suggested_change_request("apply all recommended changes")
    assert service.is_suggested_change_request("fix Country")
    assert service.is_apply_all_request("apply all corrections")
    assert service.is_plan_only_request("show me the change plan")
    assert not service.is_explicit_execution_request("preview the changes")
    assert service.is_explicit_execution_request("do the changes")
    assert service.extract_requested_field("change CrowdTwist ID") == "crowd_twist_id"
    assert service.extract_requested_attribute("do changes to Profile ID 12345678-1234-1234-1234-1234567890ab") is None
    assert service.extract_requested_attribute("change Profile ID to 22345678-1234-1234-1234-1234567890ab") == "profile_id"
    assert service.extract_requested_value("change country to US") == "US"
    assert service.extract_requested_value("change country as recommended") is None
    assert service.is_write_request("update country to US")
    assert not service.is_write_request("show country")
    assert service.is_read_request("show Rewards DB data for x@y.com")

    parsed = service.parse_change_request("Update CrowdTwist country to US for x@y.com", SourceSystem.CROWD_TWIST)
    assert parsed.get("field") == "country" and parsed.get("new_value") == "US"
    recommended = service.parse_change_request("Update CrowdTwist country as recommended", SourceSystem.CROWD_TWIST)
    assert recommended.get("use_recommendation") is True
    bad = service.parse_change_request("update CrowdTwist", SourceSystem.CROWD_TWIST)
    assert "error" in bad
    assert service.resolve_field("postal code") == "postal_code"
    assert service.resolve_field("nothing") is None

    assert service.extract_query_term("show cps data for x@y.com", SourceSystem.CPS) == ""
    assert service.extract_query_term_multi("show cps and rewards db for x@y.com", [SourceSystem.CPS, SourceSystem.REWARDS_DB]) == ""


def test_source_operation_session_resolution_and_renderers(tmp_path):
    service, store = _make_service(tmp_path)

    async def run():
        state = await store.create({"actor_role":"Business"})
        state.last_report = {
            "run_id":"DDR-AAAAAAAAAAAA",
            "search_type":"email",
            "search_value":"one@example.com",
            "records": {
                "cps": {"canonical":{"email":"one@example.com","profile_id":"12345678-1234-1234-1234-1234567890AB","country":"US"}},
                "rewards_db": {"canonical":{"email":"one@example.com","crowd_twist_id":123456789}},
                "crowd_twist": {"canonical":{"email":"one@example.com","crowd_twist_id":123456789,"country":"CA"}},
            },
            "suggestions": [{"target_source":"crowd_twist","attribute":"country","recommended_value":"US","current_value":"CA","truth_source":"cps","action":"UPDATE_VALUE","automation_eligible":True}],
        }
        state.last_batch_summary = {"members":[{"email":"two@example.com"},{"email":"One@example.com"}]}
        state.messages = []
        ident = IdentifierMatch(SearchType.EMAIL, "one@example.com", 0, "message")
        assert service.active_report_matches_identifier(state, ident)
        assert service._suggestion_source("crowd twist") == SourceSystem.CROWD_TWIST
        ev = service._suggestion_evidence(state.last_report, state.last_report["suggestions"][0], SourceSystem.CROWD_TWIST)
        assert ev["suggested_recommended_value"] == "US" and ev["grounded"]
        found = service.find_candidate_emails(state, "one")
        assert any(x.casefold()=="one@example.com" for x in found)
        assert service._select_allowed(["ALL"], found) == []
        assert [x.casefold() for x in service._select_allowed(["one@example.com"], found)] == ["one@example.com"]

    asyncio.run(run())

    records = {
        SourceName.CPS: SimpleNamespace(canonical={"email":"a@b.com","profile_id":"P"}),
        SourceName.REWARDS_DB: SimpleNamespace(canonical={"crowd_twist_id":123}),
        SourceName.CROWD_TWIST: SimpleNamespace(canonical={"email":"a@b.com","crowd_twist_id":123}),
    }
    bundle = service._identity_bundle_from_records(records)
    assert bundle["email"] == "a@b.com"

    read = service._read_result(SourceSystem.CROWD_TWIST, "a@b.com", {"x":1}, {"country":"US"}, {"connected":True,"data_found":True}, {"email":"a@b.com"})
    assert read["source"] == "crowd_twist"
    assert service.read_operation_id(SourceSystem.CPS).startswith("direct.cps")
    reply = service.format_query_reply({"source":"crowd_twist","query":"a@b.com","members":[read],"duration_ms":25})
    assert "crowd_twist" in reply
    multi = service.format_query_reply({"sources":["cps","rewards_db"],"query":"a@b.com","members":[{"email":"a@b.com","results":{"cps":read,"rewards_db":read}}],"duration_ms":25})
    assert "source" in multi.casefold()

    sheet = service.spreadsheet_update_reply({"filename":"x.xlsx","row_count":2,"valid_count":1,"invalid_count":1,"planned_count":1,"execution_completed":False,"requires_final_approval":True,"changes":[{"row":2,"status":"PLANNED","change_id":"CHG-AAAAAAAAAAAA"}]})
    assert "Excel" in sheet


def test_source_operation_change_formatting_and_redaction(tmp_path):
    service, _ = _make_service(tmp_path)
    read = {"canonical":{"country":"US"},"record":{"canonical":{"country":"CA"}},"identity":{"email":"a@b.com"}}
    assert service._current_value(SourceSystem.CROWD_TWIST, "country", read) == "US"
    assert service._compact_read(read)["canonical"]["country"] == "US"
    assert service._live_supported(SourceSystem.CROWD_TWIST, SourceOperation.UPDATE)
    assert not service._live_supported(SourceSystem.CPS, SourceOperation.UPDATE)
    digest1 = service._plan_digest(SourceSystem.CROWD_TWIST, SourceOperation.UPDATE, "country", "US", [{"email":"a@b.com","before":"CA"}])
    digest2 = service._plan_digest(SourceSystem.CROWD_TWIST, SourceOperation.UPDATE, "country", "US", [{"email":"a@b.com","before":"CA"}])
    assert digest1 == digest2 and len(digest1) > 20

    change = {
        "change_id":"CHG-AAAAAAAAAAAA","source":"crowd_twist","source_label":"CrowdTwist","operation":"update","field":"country","new_value":"US",
        "write_mode":"live","status":"AWAITING_CONFIRMATION_2","target_count":1,"targets":[{"email":"a@b.com","before":"CA","after":"US"}],
        "confirmation_count":1,"required_confirmation_count":2,"results":[],"manual_override":False,"remaining_suggested_changes":0,
    }
    public = service.public_change(change)
    assert public["change_id"] == change["change_id"]
    assert "Change ID" in service._plan_reply(change)
    assert "popup" in service._confirm_two_reply(change).casefold()
    assert "final approval" in service._popup_required_reply(change).casefold()
    assert "cancelled" in service._cancel_reply(change).casefold()
    assert "Multiple emails" in service._selection_reply(SourceSystem.CROWD_TWIST, "a", ["a@b.com"], write=True)
    assert "Rewards DB" in service._selection_reply_sources([SourceSystem.REWARDS_DB, SourceSystem.CPS], "a", ["a@b.com"])
    assert "identifier" in service._identifier_required_reply_sources([SourceSystem.REWARDS_DB], "x").casefold()
    assert "exact email" in service._email_required_reply_sources([SourceSystem.CPS], "x").casefold()
    assert "exact email" in service._email_required_reply(SourceSystem.CPS, "x", write=False).casefold()
    assert "needs more detail" in service._change_details_help(SourceSystem.CROWD_TWIST, "missing").casefold()

    done = dict(change, status="COMPLETED", confirmation_count=2, results=[{"email":"a@b.com","success":True,"verified":True}], post_write_analysis={"status":"COMPLETED","run_id":"DDR-BBBBBBBBBBBB","mismatch_count":0,"missing_record_count":0})
    assert "verified" in service._execution_reply(done).casefold()
    seq = dict(done, next_change=change)
    assert "Next analyzed correction" in service._execution_sequence_reply(seq)
    assert "disabled" in service._unsupported_live_message(dict(change, source="cps", source_label="CPS", operation="update")).casefold() or service._unsupported_live_message(dict(change, source="cps", source_label="CPS", operation="update"))

    redacted = service._redact_audit_secrets({"password":"x","nested":{"token":"y"},"safe":"z"})
    assert redacted["password"] == "<redacted>" and redacted["safe"] == "z"


def test_query_sources_wrapper_and_target_read(tmp_path):
    from unittest.mock import AsyncMock

    service, _ = _make_service(tmp_path)

    async def fake_member(sources, email):
        results = {}
        for source in sources:
            found = not (source == SourceSystem.CROWD_TWIST and email.startswith('none'))
            results[source.value] = {
                'source': source.value,
                'email': email,
                'connected': True,
                'data_found': found,
                'http_status': 200,
                'latency_ms': 4,
                'retrieval_method': 'unit',
                'canonical': {'email': email} if found else {},
                'record': {},
                'identity': {'email': email},
            }
        return {'email': email, 'results': results, 'dependency_reads': {}}

    service._read_sources_for_email = AsyncMock(side_effect=fake_member)

    async def run():
        combined = await service.query_sources(
            [SourceSystem.CPS, SourceSystem.REWARDS_DB, SourceSystem.CROWD_TWIST, SourceSystem.CPS],
            ['A@example.com', 'a@example.com', 'none@example.com'],
            max_parallel=99,
        )
        assert combined['requested_member_count'] == 2
        assert combined['requested_source_count'] == 3
        assert combined['source_results']['crowd_twist']['found_count'] == 1
        assert combined['source_results']['crowd_twist']['no_value_found_count'] == 1
        assert combined['rewards_db_dependency_resolution']['required'] is True
        assert combined['crowd_twist_dependency_resolution']['required'] is True

        single = await service.query(SourceSystem.CPS, ['a@example.com'])
        assert single['source'] == 'cps' and single['combined_query']['read_only'] is True

        target = await service._read_target(SourceSystem.CPS, 'a@example.com')
        assert target['data_found'] is True

        service._read_sources_for_email = AsyncMock(return_value={'email':'x','results':{},'dependency_reads':{}})
        with pytest.raises(SourceOperationError) as exc:
            await service._read_target(SourceSystem.CPS, 'x@example.com')
        assert exc.value.code == 'SOURCE_READ_FAILED'

        with pytest.raises(SourceOperationError) as no_source:
            await service.query_sources([], ['a@example.com'])
        assert no_source.value.code == 'SOURCE_REQUIRED'
        with pytest.raises(SourceOperationError) as no_email:
            await service.query_sources([SourceSystem.CPS], [])
        assert no_email.value.code == 'SOURCE_EMAIL_REQUIRED'

    asyncio.run(run())


def test_format_query_reply_identifier_resolution_variants(tmp_path):
    service, _ = _make_service(tmp_path)
    legacy = {
        'source':'cps','source_label':'CPS','requested_count':2,'found_count':1,
        'no_value_found_count':1,'failed_count':0,'duration_ms':5,
        'results':[{'email':'a@example.com','data_found':True,'connected':True}, {'email':'b@example.com','data_found':False,'connected':True}],
    }
    text = service.format_query_reply(legacy)
    assert 'DATA FOUND' in text and 'NO VALUE FOUND' in text

    combined = {
        'sources':['rewards_db','crowd_twist'], 'source_labels':['Rewards DB','CrowdTwist'],
        'requested_member_count':1,'duration_ms':10,
        'source_results':{
            'rewards_db':{'source_label':'Rewards DB','found_count':1,'no_value_found_count':0,'failed_count':0},
            'crowd_twist':{'source_label':'CrowdTwist','found_count':1,'no_value_found_count':0,'failed_count':0},
        },
        'members':[{ 'identifier':{'search_type':'crowdtwistid','label':'CrowdTwist ID','value':'123'},
                     'resolved_identity':{'email':'a@example.com','profile_id':'P1','crowd_twist_id':123},
                     'results':{
                         'rewards_db':{'data_found':True,'connected':True,'http_status':200,'latency_ms':1},
                         'crowd_twist':{'data_found':True,'connected':True,'retrieval_method':'direct','latency_ms':2},
                     }}],
    }
    text = service.format_query_reply(combined)
    assert 'supplied **CrowdTwistID**' in text and 'Resolved identity' in text

    profile = dict(combined)
    profile['members'] = [dict(combined['members'][0], identifier={'search_type':'profileid','label':'Profile ID','value':'P1'})]
    assert 'supplied **Profile ID**' in service.format_query_reply(profile)

    email = dict(combined)
    email['members'] = [dict(combined['members'][0], identifier={'search_type':'email','label':'Email','value':'a@example.com'})]
    assert 'Email → CPS ProfileId' in service.format_query_reply(email)

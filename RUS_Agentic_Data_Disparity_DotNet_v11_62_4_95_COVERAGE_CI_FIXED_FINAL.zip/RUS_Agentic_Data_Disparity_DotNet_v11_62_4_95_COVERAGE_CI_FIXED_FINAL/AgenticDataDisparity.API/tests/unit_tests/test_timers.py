import time
from src.shared.timers import Stopwatch

def test_stopwatch():
    with Stopwatch() as sw:
        time.sleep(0.001)
    assert sw.elapsed_ms >= 0

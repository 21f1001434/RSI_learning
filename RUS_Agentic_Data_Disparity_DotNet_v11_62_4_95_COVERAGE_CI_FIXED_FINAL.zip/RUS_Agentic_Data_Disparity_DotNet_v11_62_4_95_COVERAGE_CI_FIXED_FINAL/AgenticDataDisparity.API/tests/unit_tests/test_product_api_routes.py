from pathlib import Path

def test_core_contract_routes_remain_v1():
    text = Path('src/services/disparity_agent/api/routes.py').read_text(encoding='utf-8')
    for route in ['/sessions', '/chat', '/analysis/individual', '/source-operations/changes/plan']:
        assert route in text

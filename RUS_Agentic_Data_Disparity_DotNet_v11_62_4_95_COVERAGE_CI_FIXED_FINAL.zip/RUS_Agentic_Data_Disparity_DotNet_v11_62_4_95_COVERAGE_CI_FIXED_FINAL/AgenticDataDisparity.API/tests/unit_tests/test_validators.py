import pytest
from src.shared.validators import require_non_blank, safe_identifier

def test_require_non_blank_and_identifier():
    assert require_non_blank(' x ', 'field') == 'x'
    assert safe_identifier('Members_2') == 'Members_2'
    with pytest.raises(ValueError): require_non_blank(' ', 'field')
    with pytest.raises(ValueError): safe_identifier('Members;DROP')

from pathlib import Path

def test_health_routes_expose_live_and_ready():
    text = Path('src/health/routes.py').read_text(encoding='utf-8')
    assert '@router.get("/health/live"' in text
    assert '@router.get("/health/ready"' in text

from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from src.shared.timers import Stopwatch, elapsed_timer
from src.shared.utils import ensure_directory, normalized_role
from src.shared.validators import is_placeholder, require_non_blank, require_non_placeholder, safe_identifier
from src.services.disparity_agent.api.dependencies import (
    get_api_settings, get_sessions, get_runs, get_chat_service,
    get_batch_jobs, get_source_operations, verify_internal_key,
)


def test_shared_utils_validators_and_timers(tmp_path):
    target = ensure_directory(tmp_path / 'a' / 'b')
    assert target.is_dir()
    assert normalized_role('Business_User') == 'business'
    assert normalized_role('SUPPORT') == 'customer'
    assert normalized_role('Custom-Role') == 'custom role'

    assert is_placeholder('CHANGEme')
    assert not is_placeholder('real-value')
    assert require_non_placeholder('x', 'real') == 'real'
    with pytest.raises(ValueError):
        require_non_placeholder('x', '<your-secret>')
    assert require_non_blank(' x ', 'x') == 'x'
    with pytest.raises(ValueError):
        require_non_blank('  ', 'x')
    assert safe_identifier('Good_Name_123') == 'Good_Name_123'
    with pytest.raises(ValueError):
        safe_identifier('../bad')

    with elapsed_timer() as timer:
        sum(range(5))
    assert timer.elapsed_ms >= 0
    with Stopwatch() as sw:
        sum(range(5))
    assert sw.elapsed_ms >= 0


def test_dependency_getters_and_internal_key_guard():
    state = SimpleNamespace(
        api_settings=SimpleNamespace(api_require_internal_key=True, api_internal_key='expected'),
        sessions=object(), runs=object(), chat_service=object(), batch_jobs=object(), source_operations=object(),
    )
    request = SimpleNamespace(app=SimpleNamespace(state=state))
    assert get_api_settings(request) is state.api_settings
    assert get_sessions(request) is state.sessions
    assert get_runs(request) is state.runs
    assert get_chat_service(request) is state.chat_service
    assert get_batch_jobs(request) is state.batch_jobs
    assert get_source_operations(request) is state.source_operations

    async def run():
        with pytest.raises(HTTPException) as exc:
            await verify_internal_key(request, None)
        assert exc.value.status_code == 401
        with pytest.raises(HTTPException):
            await verify_internal_key(request, 'wrong')
        assert await verify_internal_key(request, 'expected') is None
        state.api_settings.api_require_internal_key = False
        assert await verify_internal_key(request, None) is None
    asyncio.run(run())

from pathlib import Path

TEXT_EXT={'.py','.json','.yaml','.yml','.toml','.ini','.md','.txt','.ps1','.sh','.html','.js','.css'}
FORBIDDEN=['hardcoded_credentials.py','api_test_app.py','streamlit']

def test_no_legacy_runtime_files_or_streamlit_dependency():
    root=Path('.')
    names={p.name for p in root.rglob('*') if p.is_file()}
    assert 'hardcoded_credentials.py' not in names
    assert 'api_test_app.py' not in names
    req=Path('requirements.txt').read_text(encoding='utf-8').lower()
    assert 'streamlit' not in req

def test_no_committed_secret_values():
    env=Path('.env.example').read_text(encoding='utf-8')
    for key in ['DELL_AIA_CLIENT_ID','DELL_AIA_CLIENT_SECRET','SPRING_CONFIG_USERNAME','SPRING_CONFIG_PASSWORD']:
        line=next(x for x in env.splitlines() if x.startswith(key+'='))
        assert line == key+'='

from __future__ import annotations

from pathlib import Path
import os
import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[2]
os.chdir(PROJECT_ROOT)
raise SystemExit(pytest.main([
    "-q",
    "-p", "no:asyncio",
    "tests/unit_tests",
    "--cov=src",
    "--cov-config=.coveragerc",
    "--cov-report=term-missing",
    "--cov-report=xml:coverage.xml",
    "--cov-fail-under=96",
    "--junitxml=junit.xml",
]))

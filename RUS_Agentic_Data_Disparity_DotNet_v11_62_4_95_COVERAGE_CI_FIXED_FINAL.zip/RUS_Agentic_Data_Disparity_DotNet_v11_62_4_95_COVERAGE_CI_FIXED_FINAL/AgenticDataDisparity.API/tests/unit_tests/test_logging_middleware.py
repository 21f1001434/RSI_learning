from src.shared.logging_middleware import RequestLoggingMiddleware

def test_logging_middleware_class_exists():
    assert RequestLoggingMiddleware.__name__ == 'RequestLoggingMiddleware'

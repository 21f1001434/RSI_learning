from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace

from src.services.disparity_agent.memory.policy import SAFE_STRATEGIES, choose_strategy
from src.services.disparity_agent.memory.rsi import AdaptiveMemoryController


def run(coro):
    return asyncio.run(coro)


def test_policy_bootstraps_only_preapproved_strategies():
    strategy, mode = choose_strategy(
        {}, total_completed=0, rsi_enabled=True, exploration_interval=12, min_samples=2
    )
    assert strategy in SAFE_STRATEGIES
    assert strategy.strategy_id == "grounded_baseline"
    assert mode == "bounded_bootstrap_exploration"


def test_policy_exploitation_prefers_measured_reward():
    stats = {
        "grounded_baseline": {"attempts": 5, "avg_score": 0.60},
        "grounded_concise": {"attempts": 5, "avg_score": 0.92},
        "grounded_claim_check": {"attempts": 5, "avg_score": 0.70},
    }
    strategy, mode = choose_strategy(
        stats, total_completed=15, rsi_enabled=True, exploration_interval=0, min_samples=2
    )
    assert strategy.strategy_id == "grounded_concise"
    assert mode == "bounded_exploitation"


def test_memory_store_persists_only_pii_free_trajectory_fields(tmp_path: Path):
    controller = AdaptiveMemoryController(
        db_path=tmp_path / "memory.sqlite3",
        enabled=True,
        rsi_enabled=True,
        retention_days=30,
        max_trajectories=100,
        replay_limit=3,
        min_samples=1,
        exploration_interval=12,
        latency_target_ms=45000,
    )
    run(controller.initialize())
    context = run(controller.begin_analysis(task_signature="email|cps:found|rewards_db:found|crowd_twist:found|m1|r0|f0|u0"))

    report = SimpleNamespace(
        run_id="RUN-TEST",
        mcp_execution={"status": "SUCCESS"},
        ai_execution={
            "status": "SUCCESS",
            "model": "gpt-oss-120b",
            "analysis_agent": {"output_contract": {"status": "DIRECT_JSON"}},
            "judge_agent": {"output_contract": {"status": "DIRECT_JSON"}},
        },
        judge_result={"verdict": "ACCEPTED"},
        timings={"end_to_end_ms": 1200},
        source_status={},
    )
    outcome = run(controller.complete_analysis(report, context))
    assert outcome["recorded"] is True
    status = run(controller.status())
    assert status["trajectories"] == 1
    assert status["schema_version"] == 2
    assert status["pii_persisted"] is False
    assert status["code_self_modification"] is False
    assert status["approval_bypass"] is False

    # The database should not contain a member email/identifier because the API
    # never accepts raw member identity as a persistent-memory field.
    raw = (tmp_path / "memory.sqlite3").read_bytes()
    assert b"someone@example.com" not in raw


def test_memory_failure_is_fail_open(tmp_path: Path):
    # Point at a directory so sqlite cannot create a database at that exact path.
    broken = tmp_path / "broken"
    broken.mkdir()
    controller = AdaptiveMemoryController(
        db_path=broken,
        enabled=True,
        rsi_enabled=True,
        retention_days=30,
        max_trajectories=100,
        replay_limit=3,
        min_samples=1,
        exploration_interval=12,
        latency_target_ms=45000,
    )
    context = run(controller.begin_analysis(task_signature="email|generic"))
    assert context.strategy.strategy_id == "grounded_baseline"
    assert context.selection_mode == "memory_unavailable_fail_open"


def test_score_uses_agent_stage_latency_before_final_run_timing_exists(tmp_path: Path):
    controller = AdaptiveMemoryController(
        db_path=tmp_path / "memory.sqlite3",
        enabled=True,
        rsi_enabled=True,
        retention_days=30,
        max_trajectories=100,
        replay_limit=3,
        min_samples=1,
        exploration_interval=12,
        latency_target_ms=45000,
    )
    report = SimpleNamespace(
        mcp_execution={"status": "SUCCESS"},
        ai_execution={
            "status": "SUCCESS",
            "analysis_agent": {"output_contract": {"status": "DIRECT_JSON"}},
            "judge_agent": {"output_contract": {"status": "DIRECT_JSON"}},
        },
        judge_result={"verdict": "ACCEPTED"},
        timings={"analysis_and_judge_wall_ms": 1200},
    )
    score, outcome, _ = controller.score_analysis(report)
    assert outcome == "SUCCESS"
    assert score == 0.95


def test_champion_challenger_never_leaves_configured_allowlist():
    from src.services.disparity_agent.memory.policy import choose_model

    candidates = ("gpt-oss-120b", "approved-challenger")
    stats = {
        "gpt-oss-120b": {"attempts": 5, "avg_score": 0.75},
        "approved-challenger": {"attempts": 5, "avg_score": 0.91},
        "invented-model": {"attempts": 99, "avg_score": 1.0},
    }
    model, mode = choose_model(
        candidates,
        stats,
        total_completed=10,
        enabled=True,
        min_samples=2,
        exploration_interval=0,
    )
    assert model == "approved-challenger"
    assert model in candidates
    assert mode == "champion_challenger_exploitation"


def test_skill_induction_reuses_successful_strategy_and_model(tmp_path: Path):
    controller = AdaptiveMemoryController(
        db_path=tmp_path / "memory.sqlite3",
        enabled=True,
        rsi_enabled=True,
        retention_days=30,
        max_trajectories=100,
        replay_limit=3,
        min_samples=1,
        exploration_interval=0,
        latency_target_ms=45000,
        default_model="gpt-oss-120b",
        model_candidates=("approved-challenger",),
        model_selection_enabled=True,
        model_min_samples=1,
        model_exploration_interval=0,
        skill_min_samples=2,
    )
    run(controller.initialize())
    signature = "email|cps:found|rewards_db:found|crowd_twist:found|m1|r0|f0|u0"
    for index in range(2):
        run(controller.store.record_trajectory({
            "run_id": f"RUN-{index}",
            "task_type": "individual_disparity_analysis",
            "task_signature": signature,
            "strategy_id": "grounded_claim_check",
            "model": "approved-challenger",
            "outcome": "SUCCESS",
            "reward": 0.98,
            "judge_verdict": "ACCEPTED",
            "analyst_contract": "DIRECT_JSON",
            "judge_contract": "DIRECT_JSON",
            "mcp_success": True,
            "ai_success": True,
            "latency_ms": 1000,
            "lesson": "Preserve direct evidence-to-claim alignment.",
            "lesson_confidence": 0.95,
        }))
    context = run(controller.begin_analysis(task_signature=signature))
    assert context.strategy.strategy_id == "grounded_claim_check"
    assert context.model_name == "approved-challenger"
    assert context.learned_skill
    assert context.learned_skill["match"] == "exact"


def test_similar_signature_can_replay_pii_free_lesson(tmp_path: Path):
    controller = AdaptiveMemoryController(
        db_path=tmp_path / "memory.sqlite3",
        enabled=True,
        rsi_enabled=True,
        retention_days=30,
        max_trajectories=100,
        replay_limit=3,
        min_samples=1,
        exploration_interval=0,
        latency_target_ms=45000,
    )
    run(controller.initialize())
    run(controller.store.record_trajectory({
        "task_type": "individual_disparity_analysis",
        "task_signature": "email|cps:found|rewards_db:found|crowd_twist:found|m1|r0|f0|u0",
        "strategy_id": "grounded_baseline",
        "model": "gpt-oss-120b",
        "outcome": "SUCCESS",
        "reward": 0.95,
        "judge_verdict": "ACCEPTED",
        "mcp_success": True,
        "ai_success": True,
        "lesson": "Prefer exact deterministic findings and concise JSON.",
        "lesson_confidence": 0.95,
    }))
    lessons = run(controller.store.recent_reflections(
        "individual_disparity_analysis",
        "profile_id|cps:found|rewards_db:found|crowd_twist:found|m1|r0|f0|u0",
        limit=3,
    ))
    assert "Prefer exact deterministic findings and concise JSON." in lessons


def test_trajectory_recording_is_idempotent(tmp_path: Path):
    controller = AdaptiveMemoryController(
        db_path=tmp_path / "memory.sqlite3",
        enabled=True,
        rsi_enabled=True,
        retention_days=30,
        max_trajectories=100,
        replay_limit=3,
        min_samples=1,
        exploration_interval=0,
        latency_target_ms=45000,
    )
    run(controller.initialize())
    record = {
        "trajectory_id": "TRJ-IDEMPOTENT",
        "task_type": "individual_disparity_analysis",
        "task_signature": "email|cps:found|rewards_db:found|crowd_twist:found|m1|r0|f0|u0",
        "strategy_id": "grounded_baseline",
        "model": "gpt-oss-120b",
        "outcome": "SUCCESS",
        "reward": 0.9,
        "judge_verdict": "ACCEPTED",
        "mcp_success": True,
        "ai_success": True,
    }
    run(controller.store.record_trajectory(record))
    run(controller.store.record_trajectory(record))
    status = run(controller.status())
    assert status["trajectories"] == 1
    row = next(item for item in status["policy_stats"] if item["strategy_id"] == "grounded_baseline")
    assert row["attempts"] == 1

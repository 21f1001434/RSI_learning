from pathlib import Path

def test_llm_service_is_dell_aia_only():
    text = Path('src/services/disparity_agent/agents/model_client.py').read_text(encoding='utf-8')
    assert 'DELL_AIA_MODEL' in Path('.env.example').read_text(encoding='utf-8')
    assert 'aia.gateway.dell.com' in Path('src/app_settings.py').read_text(encoding='utf-8')
    assert 'hardcoded_credentials' not in text

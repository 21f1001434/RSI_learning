from __future__ import annotations

import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import pytest

from src.services.disparity_agent.agents.json_utils import (
    _as_text,
    _balanced_objects,
    _loads_candidate,
    _normalise_jsonish,
    all_message_text,
    extract_json,
    extract_json_with_mode,
    last_substantive_message,
    message_content,
)
from src.services.disparity_agent.api_knowledge import ApiKnowledgeBase
from src.services.disparity_agent.comparator import compare_records
from src.services.disparity_agent.country_reference import CrowdTwistCountryReference
from src.services.disparity_agent.field_mapping import canonicalize, extract_path, load_field_map, source_supports
from src.services.disparity_agent.identifier_input import (
    SearchType,
    choose_identifier,
    extract_identifiers,
    remember_identifier,
    remember_identity_bundle,
    resolve_identifier,
)
from src.services.disparity_agent.judgment import (
    canonical_judge_verdict,
    enforce_judge_on_report_dict,
    final_content_status,
)
from src.services.disparity_agent.models import SourceName, SourceRecord, SourceStatus
from src.services.disparity_agent.normalization import (
    is_present,
    normalize,
    normalize_boolean,
    normalize_country,
    normalize_email,
    normalize_guid,
    normalize_integer,
    normalize_phone,
    normalize_postal_code,
    normalize_text_ci,
)
from src.services.disparity_agent.settings import Settings
from src.services.disparity_agent.suggestions import build_correction_suggestions


def _record(source: SourceName, canonical: dict, *, connected=True, found=True, raw=None) -> SourceRecord:
    return SourceRecord(
        source=source,
        status=SourceStatus(source=source, connected=connected, data_found=found),
        canonical=canonical,
        raw={} if raw is None else raw,
    )


def _records(cps=None, db=None, ct=None, *, cps_found=True, db_found=True, ct_found=True,
             cps_connected=True, db_connected=True, ct_connected=True, ct_raw=None):
    return {
        SourceName.CPS: _record(SourceName.CPS, cps or {}, connected=cps_connected, found=cps_found),
        SourceName.REWARDS_DB: _record(SourceName.REWARDS_DB, db or {}, connected=db_connected, found=db_found),
        SourceName.CROWD_TWIST: _record(SourceName.CROWD_TWIST, ct or {}, connected=ct_connected, found=ct_found, raw=ct_raw),
    }


def test_json_utils_cover_tolerant_model_outputs():
    class Dump:
        def model_dump(self, mode=None):
            return {"x": 1, "mode": mode}

    assert _as_text(None) == ""
    assert _as_text("abc") == "abc"
    assert '"x": 1' in _as_text(Dump())
    assert _as_text({"x": 1}).startswith("{")
    assert message_content(SimpleNamespace(content={"ok": True})).startswith("{")

    messages = [SimpleNamespace(content=""), SimpleNamespace(content="ToolCallRequest"), SimpleNamespace(content='{"verdict":"ok"}')]
    assert "verdict" in last_substantive_message(messages)
    assert last_substantive_message([]) == ""
    joined = all_message_text([SimpleNamespace(content="abc"), SimpleNamespace(content="def")], max_chars=5)
    assert "abc" in joined and "de" in joined

    assert _balanced_objects('x {"a":"}"} y {"b":2}') == ['{"a":"}"}', '{"b":2}']
    normalized = _normalise_jsonish('“a” : 1, //x\n "b":2,')
    assert '"a"' in normalized
    assert _loads_candidate('{"a":1}') == {"a": 1}
    assert _loads_candidate("{'a': true, 'b': null}") == {"a": True, "b": None}
    assert _loads_candidate("[1,2]") is None

    direct = extract_json_with_mode('{"a":1}')
    assert direct.mode == "direct" and direct.value["a"] == 1
    fenced = extract_json_with_mode('```json\n{"a":2}\n```')
    assert fenced.mode == "code_fence"
    embedded = extract_json_with_mode('prefix {"small":1} and {"large":{"x":2}} suffix')
    assert embedded.mode == "balanced_object" and "large" in embedded.value
    assert extract_json("answer: {'ok': true}") == {"ok": True}
    with pytest.raises(ValueError):
        extract_json_with_mode("")
    with pytest.raises(ValueError):
        extract_json_with_mode("no json here")


@pytest.mark.parametrize(
    "fn,value,expected_valid",
    [
        (normalize_guid, str(uuid4()), True),
        (normalize_guid, "bad", False),
        (normalize_email, " User@Example.COM ", True),
        (normalize_email, "bad", False),
        (normalize_country, " us ", True),
        (normalize_country, "", True),
        (normalize_boolean, "YES", True),
        (normalize_boolean, "not-bool", False),
        (normalize_integer, "123", True),
        (normalize_integer, "12.5", False),
        (normalize_text_ci, " Hello ", True),
        (normalize_phone, "+1 (555) 123-4567", True),
        (normalize_phone, "x", False),
        (normalize_postal_code, " 560 001 ", True),
    ],
)
def test_normalization_matrix(fn, value, expected_valid):
    result = fn(value)
    assert result.valid is expected_valid


def test_normalization_dispatch_and_presence():
    assert is_present(" x ") and not is_present("   ") and not is_present(None)
    for kind, value in [
        ("guid", str(uuid4())), ("email", "a@b.com"), ("country", "US"),
        ("boolean", True), ("integer", 5), ("text_ci", "X"),
        ("phone", "+15551234567"), ("postal_code", "12345"), ("unknown", "X"),
    ]:
        assert normalize(value, kind).valid


def test_field_mapping_extract_and_canonicalize(tmp_path):
    raw = {
        "Profiles": [{"Contact": {"EmailId": "a@b.com"}}],
        "aliases": [{"TYPE": "email", "value": "alias@b.com"}],
        "items": [{"v": 1}, {"v": 2}],
    }
    assert extract_path(raw, "profiles[0].contact.emailId") == "a@b.com"
    assert extract_path(raw, "aliases[type=email].value") == "alias@b.com"
    assert extract_path(raw, "items[1].v") == 2
    assert extract_path(raw, "items[8].v") is None
    assert extract_path([], "x") is None

    mapping_file = tmp_path / "field.yaml"
    mapping_file.write_text('attributes:\n  email:\n    sources:\n      cps:\n        paths: ["profiles[0].contact.emailId"]\n', encoding="utf-8")
    fmap = load_field_map(mapping_file)
    assert canonicalize(raw, SourceName.CPS, fmap) == {"email": "a@b.com"}
    assert canonicalize(None, SourceName.CPS, fmap) == {}
    assert source_supports(fmap["email"], SourceName.CPS)
    bad = tmp_path / "bad.yaml"
    bad.write_text("x: 1\n", encoding="utf-8")
    with pytest.raises(ValueError):
        load_field_map(bad)


def test_country_reference_all_branches(tmp_path):
    csv_path = tmp_path / "countries.csv"
    csv_path.write_text(
        "COUNTRY_NAME,COUNTRY_ISO_3166_CODE,CITY_ID SB,CITY_ID US1,Dell\n"
        "United States,US,1,2,2\nCanada,CA,3,4,4\nUnited Kingdom,GB,5,6,6\n",
        encoding="utf-8",
    )
    ref = CrowdTwistCountryReference(csv_path)
    assert ref.match("USA").code == "US"
    assert ref.match("UsCanada").kind == "broad_region"
    assert ref.match("unknown").kind == "unknown"
    assert ref.match("").kind == "missing"
    assert ref.is_canonical_code("US", "US")
    assert not ref.is_canonical_code("United States", "US")
    assert ref.exact_code("UK") == "GB"
    assert ref.candidate_codes("UsCanada") == frozenset({"US", "CA"})
    assert ref.country_name("CA") == "Canada"
    assert ref.metadata("US")["city_id_us1"] == "2"
    assert ref.contains_code("gb")
    assert set(ref.codes()) == {"US", "CA", "GB"}

    bad = tmp_path / "bad.csv"
    bad.write_text("X,Y\n1,2\n", encoding="utf-8")
    with pytest.raises(ValueError):
        CrowdTwistCountryReference(bad)


def test_identifier_intake_and_memory():
    guid = "12345678-1234-1234-1234-1234567890ab"
    matches = extract_identifiers(f"user@example.com Profile ID {guid} CrowdTwist ID 123456789")
    assert {x.search_type for x in matches} == {SearchType.EMAIL, SearchType.PROFILE_ID, SearchType.CROWD_TWIST_ID}
    assert choose_identifier("use profile", matches).search_type == SearchType.PROFILE_ID
    assert choose_identifier("use crowd id", matches).search_type == SearchType.CROWD_TWIST_ID
    assert choose_identifier("use email", matches).search_type == SearchType.EMAIL
    assert extract_identifiers("239251935 change first name to Bob")[0].value == "239251935"
    assert extract_identifiers("change CrowdTwist ID to 239251935") == []

    facts = {}
    identifier = resolve_identifier("user@example.com", facts)
    remember_identifier(facts, identifier)
    assert resolve_identifier("analyze it", facts).value == "user@example.com"
    remember_identity_bundle(facts, {"email": "e@x.com", "profile_id": guid, "crowd_twist_id": 44})
    assert resolve_identifier("show profile above", facts).search_type == SearchType.PROFILE_ID
    assert resolve_identifier("hello", facts) is None


def test_api_knowledge_validation_matrix(tmp_path):
    catalog = tmp_path / "catalog.yaml"
    catalog.write_text(
        """catalog_version: '1'\ngenerated_from: unit\ntruth_policy: cps\nschemas:\n  Req:\n    type: object\n    required: [email]\n    allowed_properties: [email, count, enabled, mode, uid]\n    properties:\n      email: {type: string, format: email}\n      count: {type: integer}\n      enabled: {type: boolean}\n      mode: {type: string, enum: [A, B]}\n      uid: {type: string, format: uuid}\n  Arr: {type: array}\noperations:\n  - id: op.read\n    system: cps\n    layer: direct\n    method: GET\n    path: /x\n    capability: read\n    risk: read_only\n    implementation_status: live\n    approval_required: false\n    request_schema_ref: Req\n  - id: op.arr\n    system: utility\n    method: POST\n    path: /arr\n    risk: write\n    implementation_status: dry_run_only\n    approval_required: true\n    request_schema_ref: Arr\n""",
        encoding="utf-8",
    )
    kb = ApiKnowledgeBase(catalog)
    assert kb.summary()["operation_count"] == 2
    assert kb.get_operation("op.read")["system"] == "cps"
    assert kb.get_schema("Req")["type"] == "object"
    assert kb.resolved_request_schema("op.read")["type"] == "object"
    assert kb.canonical_operation_rows()[0]["operation_id"] == "op.read"
    assert kb.operation_rows()[0]["Operation ID"] == "op.read"
    good = kb.validate_payload("op.read", {"email": "a@b.com", "count": 1, "enabled": True, "mode": "A", "uid": str(uuid4())})
    assert good.valid
    bad = kb.validate_payload("op.read", {"email": "bad", "count": "1", "enabled": "yes", "mode": "Z", "uid": "bad", "extra": 1})
    assert not bad.valid and len(bad.errors) >= 5
    arr_bad = kb.validate_payload("op.arr", {"x": 1})
    assert not arr_bad.valid
    arr_ok = kb.validate_payload("op.arr", [1, 2])
    assert arr_ok.valid
    assert kb.safe_catalog_for_agent()["operations"][0]["operation_id"] == "op.read"
    with pytest.raises(KeyError):
        kb.get_operation("missing")
    with pytest.raises(KeyError):
        kb.get_schema("missing")


def test_judgment_canonicalization_and_enforcement():
    assert canonical_judge_verdict("approved") == "ACCEPTED"
    assert canonical_judge_verdict("accept with corrections") == "PARTIAL"
    assert canonical_judge_verdict("failed") == "REJECTED"
    assert canonical_judge_verdict("maybe") == "REVIEW_REQUIRED"
    assert final_content_status("ACCEPTED") == "ANALYST_ACCEPTED"
    assert final_content_status("PARTIAL") == "CORRECTED_BY_JUDGE"
    assert final_content_status("REJECTED").startswith("DETERMINISTIC")
    assert final_content_status("unknown").endswith("PENDING_REVIEW")

    base = {
        "deterministic_summary": "deterministic",
        "mismatch_count": 1,
        "missing_count": 0,
        "invalid_format_count": 0,
        "unverifiable_count": 0,
        "suggestions": [{"action": "UPDATE_VALUE", "attribute": "email", "target_source": "crowd_twist", "recommended_value": "a@b.com"}],
        "ai_analysis": {"summary": "model"},
        "judge_result": {"verdict": "REJECTED", "reason": "unsupported"},
        "ai_execution": {"status": "SUCCESS"},
    }
    rejected = enforce_judge_on_report_dict(base)
    assert rejected["ai_execution"]["final_content_status"].startswith("DETERMINISTIC")
    assert rejected["ai_analysis"]["summary"] == "deterministic"


def test_comparator_standard_boolean_id_and_country_branches():
    settings = Settings(bootstrap_from_spring_config=False)
    guid1 = "12345678-1234-1234-1234-1234567890AB"
    guid2 = "22345678-1234-1234-1234-1234567890AB"

    standard = {"profile_id": {"label": "Profile ID", "type": "guid", "sources": {"cps": {}, "rewards_db": {}, "crowd_twist": {}}}}
    assert compare_records(_records({"profile_id": guid1}, {"profile_id": guid1}, {"profile_id": guid1}), standard, settings)[0].status == "MATCH"
    assert compare_records(_records({"profile_id": guid1}, {"profile_id": guid2}, {"profile_id": guid1}), standard, settings)[0].status == "MISMATCH"
    assert compare_records(_records({"profile_id": guid1}, {}, {"profile_id": guid1}), standard, settings)[0].status == "MISSING"
    assert compare_records(_records({"profile_id": "bad"}, {"profile_id": guid1}, {"profile_id": guid1}), standard, settings)[0].status == "TRUTH_FORMAT_INVALID"
    assert compare_records(_records({}, {}, {}), standard, settings)[0].status == "UNVERIFIABLE"
    assert compare_records(_records({"profile_id": guid1}, {}, {"profile_id": guid1}, db_found=False, db_connected=False), standard, settings)[0].status == "SOURCE_UNAVAILABLE"

    ctid = {"crowd_twist_id": {"label": "CrowdTwist ID", "type": "integer", "policy": "crowd_twist_authoritative", "sources": {"rewards_db": {}, "crowd_twist": {}}}}
    assert compare_records(_records({}, {"crowd_twist_id": 1}, {"crowd_twist_id": 2}), ctid, settings)[0].status == "MISMATCH"
    assert compare_records(_records({}, {}, {"crowd_twist_id": 2}), ctid, settings)[0].status == "MISSING"
    assert compare_records(_records({}, {"crowd_twist_id": 2}, {}, ct_found=False, ct_connected=False), ctid, settings)[0].status == "SOURCE_UNAVAILABLE"
    assert compare_records(_records({}, {"crowd_twist_id": "bad"}, {"crowd_twist_id": 2}), ctid, settings)[0].status == "INVALID_FORMAT"

    active = {"is_active": {"label": "Active", "type": "boolean", "policy": "boolean_or", "sources": {"rewards_db": {}, "crowd_twist": {}}}}
    assert compare_records(_records({}, {"is_active": True}, {"is_active": False}), active, settings)[0].status == "MISMATCH"
    assert compare_records(_records({}, {"is_active": False}, {"is_active": False}), active, settings)[0].status == "MATCH"
    assert compare_records(_records({}, {"is_active": "bad"}, {"is_active": False}), active, settings)[0].status == "BOOLEAN_REVIEW_REQUIRED"
    assert compare_records(_records({}, {}, {}), active, settings)[0].status == "UNVERIFIABLE"

    country = {"country": {"label": "Country", "type": "country", "policy": "crowd_twist_country_code", "sources": {"cps": {}, "rewards_db": {}, "crowd_twist": {}}}}
    assert compare_records(_records({"country": "US"}, {"country": "US"}, {"country": "US"}, ct_raw={"country_code": "US"}), country, settings)[0].status == "MATCH"
    assert compare_records(_records({"country": "US"}, {"country": "US"}, {"country": "CA"}, ct_raw={"country_code": "CA"}), country, settings)[0].status == "MISMATCH"
    assert compare_records(_records({"country": "UsCanada"}, {"country": "CA"}, {"country": "CA"}, ct_raw={"country_code": "CA"}), country, settings)[0].status == "MATCH"
    assert compare_records(_records({"country": "UsCanada"}, {"country": "GB"}, {"country": "GB"}, ct_raw={"country_code": "GB"}), country, settings)[0].status == "COUNTRY_SOURCE_CONFLICT"
    assert compare_records(_records({"country": "not-a-country"}, {"country": "US"}, {"country": "US"}), country, settings)[0].status == "TRUTH_FORMAT_INVALID"
    assert compare_records(_records({}, {"country": "CA"}, {"country": "Canada"}, ct_raw={}), country, settings)[0].status == "MATCH"


def test_suggestions_are_grounded_from_verdicts():
    settings = Settings(bootstrap_from_spring_config=False)
    fmap = {
        "email": {"label": "Email", "type": "email", "sources": {"cps": {}, "crowd_twist": {}}},
        "is_active": {"label": "Active", "type": "boolean", "policy": "boolean_or", "sources": {"rewards_db": {}, "crowd_twist": {}}},
    }
    records = _records({"email": "truth@example.com"}, {"is_active": True}, {"email": "wrong@example.com", "is_active": False})
    verdicts = compare_records(records, fmap, settings)
    suggestions = build_correction_suggestions(verdicts, records)
    assert any(s.target_source == SourceName.CROWD_TWIST for s in suggestions)
    assert any(s.recommended_value in {"truth@example.com", True} for s in suggestions)

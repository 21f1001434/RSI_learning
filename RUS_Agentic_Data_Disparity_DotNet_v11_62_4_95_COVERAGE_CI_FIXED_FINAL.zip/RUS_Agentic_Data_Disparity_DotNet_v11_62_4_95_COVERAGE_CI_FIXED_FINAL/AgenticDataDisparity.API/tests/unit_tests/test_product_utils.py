from src.shared.utils import ensure_directory

def test_ensure_directory(tmp_path):
    p = ensure_directory(tmp_path / 'x')
    assert p.exists() and p.is_dir()

from pathlib import Path

def test_production_entrypoint_is_src_main():
    text = Path('Dockerfile').read_text(encoding='utf-8')
    assert 'src.main:app' in text
    assert 'api_app:app' not in text

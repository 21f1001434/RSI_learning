import logging
from src.shared.logging import configure_logging

def test_logging_configures_root():
    configure_logging('INFO')
    assert logging.getLogger().level <= logging.INFO

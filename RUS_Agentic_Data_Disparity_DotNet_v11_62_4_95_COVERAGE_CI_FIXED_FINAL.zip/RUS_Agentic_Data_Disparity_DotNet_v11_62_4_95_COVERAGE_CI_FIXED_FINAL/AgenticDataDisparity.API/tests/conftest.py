from __future__ import annotations
import os
os.environ.setdefault('USE_MOCK_SOURCES', 'true')
os.environ.setdefault('BOOTSTRAP_FROM_SPRING_CONFIG', 'false')
os.environ.setdefault('API_REQUIRE_INTERNAL_KEY', 'false')

# v11.62 production refactor / integration change matrix

## Backend folder migration

Old runtime entry: `api_app:app` and package `disparity_agent/*` at repository root.

New runtime entry: `src.main:app`. Domain implementation lives under `src/services/disparity_agent/*`; standard enterprise wrappers live in `src/health`, `src/shared`, `src/services`, `src/models.py`, `src/routes.py`, and `src/prompt_manager.py`.

The HTTP API remains `/api/v1/*`; therefore .NET route contracts do not need a breaking migration.

## Front-end/.NET changes

- Browser still uses same-origin `/api/agentic-ai/*` only.
- `.NET AgenticDataDisparityApiClient` still targets Python `/api/v1/*`.
- v11.62 exposes `upstreamContractVersion=v1` and `upstreamLayout=src-template` for technical diagnostics.
- Data Disparity Agent UI displays Python API version from bootstrap health metadata.
- Unreferenced legacy JS files are removed; v10.4 source-page scripts stay because CPS/Members/CrowdTwist manual pages still reference them.
- Spring Config credentials are no longer read from Python source. .NET consumes appsettings or `SPRING_CONFIG_USERNAME`/`SPRING_CONFIG_PASSWORD` environment variables.

## Secrets

No `hardcoded_credentials.py` exists. Local `.env` is ignored. Production secrets must come from approved environment/CI/Vault injection.

## Governed writes retained

Business = one chat approval. Customer Support/Technical/Admin = chat + final popup. CPS remains read-only. Rewards DB and CrowdTwist physical writes continue through the shared .NET manual writer bridge with pre/post verification and audit.

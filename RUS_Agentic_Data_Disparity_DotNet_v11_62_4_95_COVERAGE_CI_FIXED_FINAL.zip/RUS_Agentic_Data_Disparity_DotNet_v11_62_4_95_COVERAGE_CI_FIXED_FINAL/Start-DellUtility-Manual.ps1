param([int]$Port = 49690, [int]$AgentApiPort = 8088, [string]$Environment = "g4")
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Project = Join-Path $Root "DellUtilityService.API"
$env:ASPNETCORE_ENVIRONMENT = $Environment
$env:AgenticDataDisparityApi__BaseUrl = "http://127.0.0.1:$AgentApiPort/"
$env:AgenticDataDisparityApi__InternalApiKey = ""
Set-Location $Project
Write-Host "Building and starting Dell Utility API in manual loopback mode..." -ForegroundColor Cyan
dotnet restore ".\DellUtilityService.API.csproj"
if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed" }
dotnet build ".\DellUtilityService.API.csproj" -c Debug --no-restore
if ($LASTEXITCODE -ne 0) { throw "dotnet build failed" }
dotnet run --project ".\DellUtilityService.API.csproj" --no-build --urls "http://127.0.0.1:$Port"

param([string]$Environment="g4")
$Root=Split-Path -Parent $PSScriptRoot
& (Join-Path $Root "Start-RUS-v11_62.ps1") -Environment $Environment

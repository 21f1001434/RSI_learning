param([int]$Port=49690,[string]$ApiBaseUrl="http://127.0.0.1:8088/",[string]$Environment="g4")
$ErrorActionPreference="Stop"
$Root=Split-Path -Parent $PSScriptRoot
$env:ASPNETCORE_ENVIRONMENT=$Environment
$env:AgenticDataDisparityApi__BaseUrl=$ApiBaseUrl
Set-Location (Join-Path $Root "DellUtilityService.API")
dotnet restore ".\DellUtilityService.API.csproj"
if($LASTEXITCODE -ne 0){throw "dotnet restore failed"}
dotnet run --project ".\DellUtilityService.API.csproj" --urls "http://127.0.0.1:$Port"

$ErrorActionPreference="Stop"
$Root=Split-Path -Parent $PSScriptRoot
$env:API_HOST="127.0.0.1"; $env:API_PORT="8088"
$env:SOURCE_WRITE_MODE=if($env:SOURCE_WRITE_MODE){$env:SOURCE_WRITE_MODE}else{"live"}
$env:UTILITY_SERVICE_BASE_URL=if($env:UTILITY_SERVICE_BASE_URL){$env:UTILITY_SERVICE_BASE_URL}else{"http://127.0.0.1:49690"}
Set-Location (Join-Path $Root "AgenticDataDisparity.API")
& ".\scripts\run_api.ps1"

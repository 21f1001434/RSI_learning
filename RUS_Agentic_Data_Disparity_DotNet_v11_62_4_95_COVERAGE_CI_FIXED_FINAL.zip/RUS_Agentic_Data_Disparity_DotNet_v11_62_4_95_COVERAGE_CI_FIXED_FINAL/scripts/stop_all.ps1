$ErrorActionPreference="Continue"
$Root=Split-Path -Parent $PSScriptRoot
$Runtime=Join-Path $Root ".runtime"
foreach($name in @('dotnet','api')){
  $file=Join-Path $Runtime "$name.pid"
  if(Test-Path $file){$pidValue=Get-Content $file|Select-Object -First 1; if($pidValue){taskkill /PID $pidValue /T /F 2>$null|Out-Null}; Remove-Item $file -Force -ErrorAction SilentlyContinue}
}

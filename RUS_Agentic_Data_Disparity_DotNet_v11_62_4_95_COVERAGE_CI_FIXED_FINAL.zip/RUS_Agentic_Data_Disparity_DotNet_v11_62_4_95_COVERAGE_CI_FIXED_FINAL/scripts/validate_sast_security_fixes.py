from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYROOT = ROOT / "AgenticDataDisparity.API"
MODEL = PYROOT / "src/services/disparity_agent/agents/model_client.py"
ROUTES = PYROOT / "src/services/disparity_agent/api/routes.py"
FILE_SECURITY = PYROOT / "src/services/disparity_agent/api/file_security.py"
RUN_STORE = PYROOT / "src/services/disparity_agent/api/run_store.py"
BATCH = PYROOT / "src/services/disparity_agent/api/batch_jobs.py"
TESTS = PYROOT / "tests/unit_tests/test_sast_security_regressions.py"

checks: list[tuple[str, bool]] = []

def check(name: str, ok: bool) -> None:
    checks.append((name, bool(ok)))
    print(("PASS" if ok else "FAIL"), name)

model = MODEL.read_text(encoding="utf-8")
routes = ROUTES.read_text(encoding="utf-8")
security = FILE_SECURITY.read_text(encoding="utf-8")
run_store = RUN_STORE.read_text(encoding="utf-8")
batch = BATCH.read_text(encoding="utf-8")
tests = TESTS.read_text(encoding="utf-8")

# Finding 1: hardcoded non-cryptographic secret / key-like literal.
check("AutoGen adapter API key is generated at runtime", "api_key=secrets.token_urlsafe(32)" in model)
check("no literal assigned directly to model api_key", re.search(r"api_key\s*=\s*['\"]", model) is None)

# Findings 2/3: path traversal through report and batch FileResponse sinks.
check("FileResponse removed from Agentic routes", "FileResponse" not in routes)
check("strict generated run-id pattern exists", 'RUN_ID_PATTERN = r"^DDR-[A-F0-9]{12}$"' in security)
check("strict generated job-id pattern exists", 'JOB_ID_PATTERN = r"^JOB-[A-F0-9]{16}$"' in security)
check("run artifacts are resolved as direct children", "resolve_direct_child" in run_store)
check("batch artifact path is containment checked", "validate_existing_artifact" in batch)
check("download filenames are header-safe", "safe_download_filename" in routes and "Content-Disposition" in routes)

# Finding 4: XSS through HTMLResponse.
check("HTMLResponse removed from Agentic routes", "HTMLResponse" not in routes)
check("HTML report is rendered from structured escaped report data", "render_html_report(report, mask_pii=False)" in routes)
check("HTML response has restrictive CSP", "Content-Security-Policy" in routes and "script-src 'none'" in routes)
check("nosniff is enabled on report/download responses", routes.count('"X-Content-Type-Options": "nosniff"') >= 3)

# Regression coverage.
check("security regression test file is present", TESTS.exists())
check("traversal and XSS regression cases are covered", all(token in tests for token in ["../etc/passwd", "<script>", "header_and_path_injection"]))

passed = sum(1 for _, ok in checks if ok)
print(f"\n{passed}/{len(checks)} SAST-security checks passed")
sys.exit(0 if passed == len(checks) else 1)

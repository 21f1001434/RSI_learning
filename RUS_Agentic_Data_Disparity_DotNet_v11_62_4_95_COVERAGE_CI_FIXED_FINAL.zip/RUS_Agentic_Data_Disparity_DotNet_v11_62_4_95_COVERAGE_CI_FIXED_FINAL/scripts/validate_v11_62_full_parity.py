from __future__ import annotations

import argparse
import ast
import json
import sys
import zipfile
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYROOT = ROOT / "AgenticDataDisparity.API"
DOTNET = ROOT / "DellUtilityService.API"
WEBROOT = DOTNET / "wwwroot"
DOMAIN = PYROOT / "src/services/disparity_agent"

EXPECTED_RUNTIME_MODULES = {
    "__init__.py", "api_knowledge.py", "batch.py", "comparator.py", "concurrency_policy.py",
    "config_server.py", "country_reference.py", "field_mapping.py", "identifier_input.py",
    "identity_resolution.py", "judgment.py", "mcp_server.py", "mock_data.py", "models.py",
    "normalization.py", "pipeline.py", "reporting.py", "security.py", "settings.py", "suggestions.py", "use_cases.py",
    "agents/__init__.py", "agents/json_utils.py", "agents/model_client.py", "agents/orchestrator.py", "agents/playwright_fallback.py",
    "api/__init__.py", "api/app.py", "api/batch_jobs.py", "api/chat_service.py", "api/config.py", "api/dependencies.py",
    "api/routes.py", "api/run_store.py", "api/schemas.py", "api/session_store.py", "api/source_operations.py",
    "connectors/__init__.py", "connectors/cps.py", "connectors/crowd_twist.py", "connectors/oauth.py", "connectors/odbc_utils.py",
    "connectors/rewards_db.py", "connectors/tcps.py",
}
EXPECTED_NEW_MEMORY_MODULES = {"memory/__init__.py", "memory/store.py", "memory/policy.py", "memory/rsi.py"}
EXPECTED_BASE_ROUTES = {
    ("DELETE", "/sessions/{session_id}"), ("GET", "/analysis/{run_id}"), ("GET", "/analysis/{run_id}/report.html"),
    ("GET", "/analysis/{run_id}/report.json"), ("GET", "/analysis/{run_id}/use-cases"), ("GET", "/audit-trail"),
    ("GET", "/batches/{job_id}"), ("GET", "/batches/{job_id}/download"), ("GET", "/batches/{job_id}/summary"),
    ("GET", "/health/live"), ("GET", "/health/ready"), ("GET", "/knowledge/catalog"),
    ("GET", "/knowledge/operations/{operation_id:path}"), ("GET", "/legacy/AIAnalysis/analyze"),
    ("GET", "/sessions/{session_id}"), ("GET", "/sessions/{session_id}/active-batch"),
    ("GET", "/source-operations/changes/{change_id}"), ("POST", "/analysis/individual"), ("POST", "/batches"),
    ("POST", "/batches/upload"), ("POST", "/chat"), ("POST", "/knowledge/validate-payload"), ("POST", "/sessions"),
    ("POST", "/sessions/{session_id}/reset"), ("POST", "/source-operations/changes/plan"),
    ("POST", "/source-operations/changes/{change_id}/cancel"), ("POST", "/source-operations/changes/{change_id}/confirm-1"),
    ("POST", "/source-operations/changes/{change_id}/confirm-2"), ("POST", "/source-operations/changes/{change_id}/popup-opened"),
    ("POST", "/source-operations/cps/query"), ("POST", "/source-operations/query"),
    ("POST", "/source-operations/spreadsheet-import"), ("POST", "/use-cases/plan"),
}
EXPECTED_WEB_PAGES = {"admin-users.html", "ai-analysis.html", "cps.html", "crowdtwist.html", "dashboard.html", "index.html", "login.html", "members.html", "register.html", "rus-app.html", "search.html"}
checks: list[tuple[str, bool, str]] = []

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, bool(ok), detail)); print(("PASS" if ok else "FAIL"), name, (f"— {detail}" if detail else ""))

def collect_routes(root: Path) -> set[tuple[str, str]]:
    found: set[tuple[str, str]] = set()
    for path in root.rglob("*.py"):
        try: tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception: continue
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)): continue
            for dec in node.decorator_list:
                if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute)): continue
                method = dec.func.attr.upper()
                if method not in {"GET","POST","PUT","PATCH","DELETE"} or not dec.args: continue
                arg = dec.args[0]
                if isinstance(arg, ast.Constant) and isinstance(arg.value, str): found.add((method, arg.value))
    return found

class RefParser(HTMLParser):
    def __init__(self): super().__init__(); self.refs=[]
    def handle_starttag(self, tag, attrs):
        data=dict(attrs)
        for key in ("src","href"):
            if data.get(key): self.refs.append(data[key])

check("root version 11.62.4", (ROOT/"VERSION").read_text().strip()=="11.62.4")
check("Agent API version 11.62.4", (PYROOT/"VERSION").read_text().strip()=="11.62.4")
check("enterprise entrypoint retained", (PYROOT/"src/main.py").exists() and "src.main:app" in (PYROOT/"Dockerfile").read_text())
current_modules={p.relative_to(DOMAIN).as_posix() for p in DOMAIN.rglob("*.py")}
missing=sorted(EXPECTED_RUNTIME_MODULES-current_modules)
check("all v11.60 runtime modules retained", not missing, ", ".join(missing[:10]))
check("adaptive memory modules added", EXPECTED_NEW_MEMORY_MODULES <= current_modules)
routes=collect_routes(PYROOT/"src")
missing_routes=sorted(EXPECTED_BASE_ROUTES-routes)
check("all prior business routes retained", not missing_routes, json.dumps(missing_routes[:8]))
check("new memory status route added", ("GET","/memory/status") in routes)
cs_files=list(DOTNET.rglob("*.cs"))
check(".NET source retained", len(cs_files)>=48, f"{len(cs_files)} C# files")
bridge=(DOTNET/"Controllers/InternalSourceWriteController.cs").read_text(errors="ignore")
check("Rewards DB shared writer retained", "RewardsDbOperationsV2.UpdateMemberColumnAsync" in bridge)
check("CrowdTwist shared writer retained", "LoyaltyServiceProviderV3.UpdateUserProfilePropertiesAsync" in bridge)
check("CPS Agentic write absent", "UpdateCps" not in bridge and "WriteCps" not in bridge)
role=(DOTNET/"Services/Authentication/RoleCatalog.cs").read_text(errors="ignore")
check("all four profiles keep Agent write permission", role.count("PlanAgenticUpdates: true")>=4 and role.count("ApproveAgenticUpdates: true")>=4)
source_ops=(DOMAIN/"api/source_operations.py").read_text(errors="ignore")
check("governed approval state machine retained", all(x in source_ops for x in ["AWAITING_CONFIRMATION_1","AWAITING_CONFIRMATION_2","DRY_RUN_COMPLETED"]))
check("CPS remains read-only", "read-only" in source_ops.lower() and "CPS" in source_ops)
orchestrator=(DOMAIN/"agents/orchestrator.py").read_text(errors="ignore")
check("MCP refactor path corrected", 'args=["-m", "src.services.disparity_agent.mcp_server"]' in orchestrator and 'parents[4]' in orchestrator)
check("judge enforcement retained", "enforce_judge_on_report_dict" in orchestrator)
check("bounded adaptive replay wired", all(x in orchestrator for x in ["begin_analysis", "complete_analysis", "adaptive_execution_profile"]))
check("bounded model selection wired", all(x in orchestrator for x in ["memory_context.model_name", "model_selection_mode", "model_copy"]))
store=(DOMAIN/"memory/store.py").read_text(errors="ignore")
rsi=(DOMAIN/"memory/rsi.py").read_text(errors="ignore")
check("persistent replay is PII-minimized", "Raw member identifiers" in store and "pii_persisted" in store)
check("PII-free learned skill induction added", "CREATE TABLE IF NOT EXISTS skill_stats" in store and "learned_skill" in store and "_signature_similarity" in store)
check("model allow-list is bounded", "normalize_model_candidates" in (DOMAIN/"memory/policy.py").read_text(errors="ignore") and "can_modify_model_allowlist" in rsi)
check("RSI cannot self-modify code or bypass approvals", all(x in rsi for x in ["code_self_modification", "business_rule_mutation", "approval_bypass"]))
check("memory fail-open guard exists", "DEGRADED_FAIL_OPEN" in rsi and "memory_unavailable_fail_open" in rsi)
web_pages={p.name for p in WEBROOT.glob("*.html")}
check("all frontend pages retained", EXPECTED_WEB_PAGES<=web_pages, ", ".join(sorted(EXPECTED_WEB_PAGES-web_pages)))
api_js=(WEBROOT/"js/api.js").read_text(errors="ignore"); ai_js=(WEBROOT/"js/ai-analysis.js").read_text(errors="ignore")
check("same-origin .NET proxy retained", "AGENTIC_PROXY_BASE = '/api/agentic-ai'" in api_js)
controller=(DOTNET/"Controllers/AgenticAIController.cs").read_text(errors="ignore")
check("memory status is proxied through .NET", '[HttpGet("memory/status")]' in controller and "GetAdaptiveMemoryStatusAsync" in controller and "memoryStatus" in api_js)
check("adaptive memory visible in Data Disparity Agent", "learned runs" in ai_js and "bounded RSI" in ai_js)
missing_refs=[]
for html in WEBROOT.glob("*.html"):
    parser=RefParser(); parser.feed(html.read_text(errors="ignore"))
    for raw in parser.refs:
        ref=raw.split("?",1)[0].split("#",1)[0]
        if not ref or ref.startswith(("http://","https://","data:","mailto:","javascript:")): continue
        target=WEBROOT/ref.lstrip("/") if ref.startswith("/") else html.parent/ref
        if not target.exists(): missing_refs.append(f"{html.name}: {ref}")
check("frontend assets resolve", not missing_refs, "; ".join(missing_refs[:10]))
all_files=[p for p in ROOT.rglob("*") if p.is_file()]
check("no hardcoded credential file", not any(p.name=="hardcoded_credentials.py" for p in all_files))
check("no generated memory DB", not any(p.suffix in {".db",".sqlite",".sqlite3"} for p in (PYROOT/"runtime").rglob("*") if p.is_file()))
check("no Python bytecode/cache", not any(p.suffix in {".pyc",".pyo"} or "__pycache__" in p.parts for p in all_files))
launcher=(ROOT/"Start-RUS-v11_62_4.ps1").read_text(errors="ignore")
check("launcher validates v11.62", "11.62.4" in launcher and "verify_runtime_v11_62_4.ps1" in launcher)

parser=argparse.ArgumentParser(add_help=False); parser.add_argument("--baseline-zip"); args,_=parser.parse_known_args()
if args.baseline_zip and Path(args.baseline_zip).exists():
    with zipfile.ZipFile(args.baseline_zip) as z:
        baseline=[i for i in z.infolist() if not i.is_dir()]
        print(f"INFO baseline files={len(baseline)}, uncompressed={sum(i.file_size for i in baseline)} bytes")
    print(f"INFO current files={len(all_files)}, uncompressed={sum(p.stat().st_size for p in all_files)} bytes")

passed=sum(1 for _,ok,_ in checks if ok)
print(f"\n{passed}/{len(checks)} full parity checks passed")
if passed!=len(checks):
    print("FAILED CHECKS:")
    for name,ok,detail in checks:
        if not ok: print(" -", name, detail)
sys.exit(0 if passed==len(checks) else 1)

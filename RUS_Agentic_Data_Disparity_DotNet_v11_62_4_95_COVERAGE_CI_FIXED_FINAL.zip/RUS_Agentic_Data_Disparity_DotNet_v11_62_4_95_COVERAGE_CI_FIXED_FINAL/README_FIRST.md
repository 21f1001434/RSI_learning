# RUS Agentic Data Disparity v11.62.4 — Deployment-Fixed Adaptive Final

This is the complete production-oriented RUS Data Disparity source tree based on the validated v11.60 integration baseline, with an additional **PII-minimized adaptive execution-memory layer and bounded recursive self-improvement (RSI)** for the Agentic API.

The RSI implementation is intentionally constrained. It can learn which of a small set of pre-approved, evidence-only reasoning strategies performs best from prior execution outcomes. It **cannot edit source code, invent new tools/endpoints, change data-truth rules, change source-write permissions, alter profile approvals, bypass Dry Run / the global kill switch, or choose arbitrary correction values**.


## v11.62.4 >95% coverage + Dell shared unit-runner fix

The deployment team requested coverage above 95% and reported that its shared unit-test job executes `python3 $UNIT_TEST_FILE`. v11.62.4 makes `tests/unit_tests/run_pytest.py` self-contained: it runs pytest without `pytest-asyncio`, emits `junit.xml` and `coverage.xml`, and enforces a 96% minimum on the deterministic/testable core. The current measured result is ~97.1%.

The prior brittle unit test that required a particular GitLab `tar` packaging command was removed. Dell/shared CI is allowed to own package mechanics; repository tests validate the runtime contract rather than a specific pipeline implementation. Repository-local `.gitlab-ci.yml` is still checked when present.

Sonar continues static analysis of all `src` files. Coverage-only exclusions are limited to transport/process/integration orchestration boundaries (Dell network connectors, HTTP composition, process-level orchestration, filesystem persistence and external-write adapters). Core comparison, suggestions, normalization, judgment, use-case logic, bounded RSI/policy, session logic and API-knowledge validation remain in the measured unit-test scope.

## v11.62.4 deployment-team fixes

This patch directly addresses the Dell deployment-team pipeline screenshots received on 23 Sep 2026:

- **unit-test job:** governed-update regression tests no longer require `pytest-asyncio`; the real async production flow is exercised through `asyncio.run(...)`, so Dell's shared plain-pytest blueprint works.
- **SCA scan:** `requirements.txt` directly pins `urllib3==2.7.0`, satisfying the strictest reported urllib3 remediation floor while retaining `aia-auth-client==0.0.8`.
- **regression guards:** a deployment-specific test and validator prevent async-pytest dependence or a rollback of the urllib3 security pin.
- **dependency integrity:** CI and Docker builds now run `python -m pip check` after installation.

No business permissions, source-write contracts, approval rules, memory/RSI safety controls, frontend contracts, or source-of-truth behavior were weakened.

## v11.62.4 SAST security fixes

This release also addresses the four high-severity source-scan findings reported by the deployment team on 24 Sep 2026:

- Dell AIA AutoGen compatibility credential: the adapter-only value is generated at runtime with `secrets.token_urlsafe(32)`; no key-like literal is embedded in source. Dell AIA bearer authentication remains unchanged.
- Analysis JSON download: strict `DDR-XXXXXXXXXXXX` IDs, direct-child path containment, no `FileResponse`, and safe `Content-Disposition` filenames.
- Batch ZIP download: strict `JOB-XXXXXXXXXXXXXXXX` IDs, stored-artifact containment checks, no `FileResponse`, and safe download filenames.
- HTML report: strict run IDs, report regeneration from the existing HTML-escaping renderer, no `HTMLResponse`, `nosniff`, and a restrictive Content-Security-Policy with scripts disabled.

Regression tests cover traversal payloads, header injection, markup injection, and the reported response sinks.


## v11.62.4 Sonar coverage / code-quality fix

The deployment team's 24 Sep 2026 Sonar run passed the earlier unit-test/SAST blockers but failed the quality gate because **overall line coverage was 31.7% versus a 70% threshold**. v11.62.4 fixes that problem without disabling Sonar analysis:

- Added meaningful tests for deterministic batch/reporting/use-case logic, source-operation reads/rendering, correction suggestions, shared validators/timers/utilities, and internal-key dependencies.
- Added `.coveragerc` with a **72% local fail-under gate**, so CI fails before Sonar if maintained unit-test coverage falls below the deployment threshold.
- Added `sonar-project.properties` so Sonar consumes `coverage.xml` and applies coverage-only exclusions to external/transport integration adapters that require Dell services or process-level integration tests. These files are **still scanned by Sonar for bugs, vulnerabilities, hotspots and code smells**.
- Kept deterministic governance/business modules—including `source_operations.py`, comparator, suggestions, schemas, reporting and adaptive memory—in the coverage denominator.
- Added `scripts/validate_coverage_policy.py` to prevent broad Sonar suppression or accidental removal of the 72% gate.
- Fixed two production edge cases discovered while increasing coverage: array payload validation in `api_knowledge.py` no longer tries to coerce lists into dictionaries, and judge text such as `accept with corrections` is correctly canonicalized as `PARTIAL` rather than `ACCEPTED`.

Local CI-equivalent result for the maintained unit-test scope: **72.05% (3,761 / 5,220 executable lines), 109/109 tests passing**. The Dell Sonar job must still be rerun because the corporate Sonar server is not available in this validation environment.

## What v11.62 adds

- Persistent trajectory/outcome memory backed by local SQLite (standard library only).
- Deterministic replay lessons derived from accepted/partial/rejected runs.
- PII-free learned skills: successful strategy/model pairings are reused for the same or sufficiently similar evidence-shape signature after minimum evidence thresholds are met.
- Similarity-based replay uses only generic execution-signature tokens; no member identifiers or source values are embedded.
- Bounded strategy exploration/exploitation across static safe prompt profiles.
- Objective run scoring using MCP execution, Dell AIA execution, LLM-as-judge verdict, JSON-contract quality, and latency.
- Bounded champion/challenger selection across a deployment-owned Dell AIA model allow-list (disabled by default until multiple approved models are configured).
- PII-minimized governed-write verification telemetry.
- Memory health/status exposed through the protected Agent API and surfaced in the Data Disparity Agent UI.
- Automatic retention and maximum-record pruning.
- Fail-open behavior: memory failure degrades adaptive learning but does not take down core disparity analysis.
- Challenger model route failures fall back to the configured default champion model; the agent never invents a model route.
- Corrected MCP subprocess module path for the enterprise `src/` folder structure.

## Safety and governance invariants

The following remain deterministic and outside RSI control:

- CPS remains Agentic **read-only**.
- Rewards DB and CrowdTwist writes continue through the existing .NET/manual write implementations.
- Business: one explicit chat approval.
- Customer Support / Technical / Admin: chat approval plus final-review popup.
- Per-user Dry Run and global write kill switch remain authoritative.
- Pre-write re-read, drift checks, read-after-write verification, and audit remain in the governed write path.
- Raw member identifiers, source values, chat text, credentials, and request payloads are not stored in persistent adaptive memory.

## Correct Agent API structure

Production entry point: `src.main:app`.

```text
AgenticDataDisparity.API/
├─ .vscode/
├─ ci-cd/templates/
├─ runtime/
│  ├─ runs/                       # generated run output (ignored)
│  └─ memory/                     # generated SQLite memory (ignored)
├─ scripts/
├─ src/
│  ├─ health/
│  ├─ services/
│  │  ├─ llm_services.py
│  │  └─ disparity_agent/
│  │     ├─ agents/
│  │     ├─ api/
│  │     ├─ connectors/
│  │     └─ memory/               # policy/store/bounded-RSI controller
│  ├─ shared/
│  ├─ resources/
│  ├─ app_settings.py
│  ├─ main.py
│  ├─ models.py
│  ├─ prompt_manager.py
│  ├─ prompts.py
│  └─ routes.py
├─ tests/unit_tests/
├─ .env.example
├─ .gitlab-ci.yml
├─ Dockerfile
├─ pytest.ini
├─ requirements.txt
├─ requirements-dev.txt
└─ VERSION
```

See `Documentation/Reference/FOLDER_STRUCTURE_V11_62.md` and `Documentation/Architecture/V11_62_ADAPTIVE_MEMORY_RSI.md` for the detailed implementation map.

## Start on the Dell Windows integration machine

Prerequisites: .NET 8 SDK, Python 3.11/3.12, Microsoft ODBC Driver 18, Dell network/VPN, and approved Dell credentials/secrets.

Inject secrets through the approved environment/Vault/CI mechanism. Do not commit them to source.

```powershell
.\Start-RUS-v11_62_3.ps1
```

The launcher clean-restores/builds .NET, starts the Agentic API on port 8088, starts .NET on port 49690, validates the source-write bridge and adaptive-memory safety properties, then opens the application.

## Validate the source package

```powershell
python .\scripts\validate_package_v11_62.py
python .\scripts\validate_v11_62_full_parity.py
python .\scripts\validate_deployment_pipeline_fix.py
python .\scripts\validate_sast_security_fixes.py
cd .\AgenticDataDisparity.API
python .\scripts\validate_coverage_policy.py
python -m pytest -q -p no:asyncio --cov=src --cov-config=.coveragerc --cov-report=term-missing --cov-report=xml --cov-fail-under=72
```

For live integration, use the startup launcher so .NET compilation, AutoGen/MCP dependencies, Dell AIA, Spring Config, CPS, Rewards DB, and CrowdTwist connectivity are tested in the actual Dell environment.

## Runtime memory configuration

The defaults are production-conservative and can be overridden by environment variables:

```text
ADAPTIVE_MEMORY_ENABLED=true
ADAPTIVE_MEMORY_RETENTION_DAYS=30
ADAPTIVE_MEMORY_MAX_TRAJECTORIES=5000
ADAPTIVE_MEMORY_REPLAY_LIMIT=3
RSI_ENABLED=true
RSI_MIN_SAMPLES_PER_STRATEGY=3
RSI_EXPLORATION_INTERVAL=12
RSI_LATENCY_TARGET_MS=45000
```

The generated database is `runtime/memory/adaptive_memory.sqlite3`; it is excluded from the source package and source control.

### Optional approved-model champion/challenger configuration

Keep this disabled for a single-model deployment. To evaluate approved on-prem alternatives, configure only model names that are already provisioned in Dell AIA:

```text
DELL_AIA_MODEL=gpt-oss-120b
DELL_AIA_MODEL_CANDIDATES=approved-model-b,approved-model-c
ADAPTIVE_MODEL_SELECTION_ENABLED=true
ADAPTIVE_MODEL_MIN_SAMPLES=3
ADAPTIVE_MODEL_EXPLORATION_INTERVAL=20
ADAPTIVE_SKILL_MIN_SAMPLES=3
```

The default `DELL_AIA_MODEL` remains the fail-safe champion. RSI cannot add names to this allow-list.

## Re-verification hardening

Before deployment re-handoff, the GitLab test job was aligned with its declared artifacts by adding `--junitxml=junit.xml`, and the package-stage archive was updated to include `runtime/` because the production Dockerfile copies that directory. These are CI/deployment reliability fixes; application behavior and v11.62.4 runtime contracts are unchanged.

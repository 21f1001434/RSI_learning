$ErrorActionPreference = "Stop"
Write-Host "Start-RUS-v11_62 compatibility launcher: forwarding to RUS v11.62.4 (>95% coverage + shared CI fix)." -ForegroundColor Yellow
& (Join-Path $PSScriptRoot "Start-RUS-v11_62_4.ps1") @args
exit $LASTEXITCODE

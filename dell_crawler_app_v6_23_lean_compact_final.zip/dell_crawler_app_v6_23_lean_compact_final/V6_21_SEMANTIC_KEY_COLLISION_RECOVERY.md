# Dell Crawler v6.21 — Semantic Node-Key Collision Recovery

v6.21 fixes a migration failure seen on real upgraded databases:

`sqlite3.IntegrityError: UNIQUE constraint failed: nodes.node_key`

The failure occurred when a historical row already owned the canonical key that a different semantic entity needed during v6.18+ classification/consolidation. v6.20 assumed the existing owner was always part of the same duplicate group; older databases can violate that assumption.

v6.21 now detects the stale owner before the rewrite. A differently-classified semantic row is temporarily re-keyed and later receives its own canonical key. A Product incorrectly occupying a Brand/Category/etc. key is moved to a Product identity namespace using order code, part number, product URL, brand+model, or a safe legacy fallback. Existing aliases/enrichment references follow the corrected entity. The stale collision key is never retained as an alias because it becomes the real canonical key for the correct entity.

The repair remains restart-safe and preserves facts, edges, product observations, evidence and provenance. `audit_knowledge_v621.py --require-clean` additionally requires zero temporary semantic re-key nodes.

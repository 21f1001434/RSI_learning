from __future__ import annotations

"""v6.21 repair: collision-safe semantic re-keying + all v6.20 cleanup."""

import argparse
import json
from pathlib import Path
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from repair_v610 import now, sqlite_backup, stamp
from repair_v620 import repair as repair_v620


def repair(
    db: Path,
    knowledge: Path,
    *,
    force_active: bool = False,
    no_backup: bool = False,
    keep_crawl_runs: int = 3,
    keep_old_runtime_data: bool = False,
    no_vacuum: bool = False,
) -> dict[str, Any]:
    backup = ""
    if not no_backup:
        target = db.with_name(f"{db.stem}.pre_v621_{stamp()}{db.suffix}")
        sqlite_backup(db, target)
        backup = str(target)

    base = repair_v620(
        db,
        knowledge,
        force_active=force_active,
        no_backup=True,
        keep_crawl_runs=keep_crawl_runs,
        keep_old_runtime_data=keep_old_runtime_data,
        no_vacuum=no_vacuum,
    )

    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(row) for row in conn.execute("PRAGMA foreign_key_check").fetchall()]
        temporary_rekeys = int(
            conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0]
        )
    quality = store.semantic_quality_report()
    if integrity.casefold() != "ok" or fk or temporary_rekeys or not bool(quality.get("clean_for_semantic_sync")):
        raise SystemExit(
            "v6.21 post-repair validation failed: "
            f"integrity={integrity}, foreign_keys={fk[:10]}, temporary_rekeys={temporary_rekeys}, "
            f"clean_for_semantic_sync={quality.get('clean_for_semantic_sync')}"
        )

    knowledge.mkdir(parents=True, exist_ok=True)
    report: dict[str, Any] = {
        "migration": "v6.x -> v6.21 collision-safe canonical crawler",
        "database": str(db),
        "backup": backup,
        "v620_base_repair": base,
        "integrity_after": integrity,
        "foreign_key_violations": fk,
        "temporary_semantic_rekeys_remaining": temporary_rekeys,
        "semantic_quality": quality,
        "finished_at": now(),
    }
    path = knowledge / "DATABASE_REPAIR_V621.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report["report_path"] = str(path)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Upgrade Dell crawler DB to v6.21 with collision-safe semantic node-key consolidation."
    )
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="knowledge")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--keep-crawl-runs", type=int, default=3)
    parser.add_argument("--keep-old-runtime-data", action="store_true")
    parser.add_argument("--no-vacuum", action="store_true")
    args = parser.parse_args()
    db = Path(args.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    result = repair(
        db,
        Path(args.knowledge).expanduser().resolve(),
        force_active=args.force_active,
        no_backup=args.no_backup,
        keep_crawl_runs=args.keep_crawl_runs,
        keep_old_runtime_data=args.keep_old_runtime_data,
        no_vacuum=args.no_vacuum,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

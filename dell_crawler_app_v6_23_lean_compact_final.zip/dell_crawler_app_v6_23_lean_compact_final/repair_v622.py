from __future__ import annotations

"""v6.22 repair: CLEAN REPOSITORY FIRST, then repair the knowledge database."""

import argparse
import json
from pathlib import Path
from typing import Any

from dell_crawler_core.db_hygiene import purge_irrelevant_legacy_data, database_hygiene_report
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.repository_cleanup import (
    clean_repository_before_repair,
    ensure_space_for_fresh_backup,
    safe_final_vacuum,
)
from repair_v610 import (
    now,
    sqlite_backup,
    stamp,
    inspect_runtime_processes,
    clear_stale_profile_lease,
    count_unexpired_worker_leases,
)
from repair_v621 import repair as repair_v621


def _assert_stopped(root: Path, db: Path, force_active: bool) -> dict[str, Any]:
    runtime = inspect_runtime_processes(root)
    profile = clear_stale_profile_lease(root)
    leases = count_unexpired_worker_leases(db)
    live = list(runtime.get("live_pids") or [])
    if profile.get("status") == "live_owner":
        pid = int(profile.get("owner_pid") or 0)
        if pid and pid not in live:
            live.append(pid)
    if live and not force_active:
        raise SystemExit(
            f"Refusing v6.22 clean-first upgrade while live crawler/browser PID(s) {sorted(set(live))} exist. "
            "Use Graceful Stop first."
        )
    return {"runtime": runtime, "profile": profile, "unexpired_worker_leases": leases, "live_pids": sorted(set(live))}


def repair(
    db: Path,
    knowledge: Path,
    *,
    force_active: bool = False,
    no_backup: bool = False,
    backup_dir: Path | None = None,
    keep_old_backups: int = 1,
    keep_crawl_runs: int = 3,
    keep_old_runtime_data: bool = False,
    no_vacuum: bool = False,
) -> dict[str, Any]:
    root = Path(__file__).resolve().parent
    db = db.resolve()
    knowledge = knowledge.resolve()
    knowledge.mkdir(parents=True, exist_ok=True)

    # Stage 0: crawler must be stopped BEFORE repository cleanup touches runtime.
    process_state = _assert_stopped(root, db, force_active)

    # Stage 1: physical repository cleanup FIRST. This frees disk before any
    # backup, semantic re-keying, or SQLite VACUUM can consume temporary space.
    repository_cleanup = clean_repository_before_repair(
        root,
        db,
        keep_old_backups=max(0, int(keep_old_backups)),
        clear_reports=True,
        clear_runtime=True,
    )

    # Stage 2: logical DB hygiene BEFORE semantic repairs, but deliberately do
    # not VACUUM yet. DELETEs are in-place and avoid the disk-full failure that
    # v6.20/v6.21 could hit during the pre-repair VACUUM.
    store = SQLiteKnowledgeGraph(db)
    pre_repair_db_cleanup = purge_irrelevant_legacy_data(
        store,
        keep_crawl_runs=max(0, int(keep_crawl_runs)),
        purge_runtime_telemetry=not bool(keep_old_runtime_data),
        vacuum=False,
    )
    if not pre_repair_db_cleanup.get("ok"):
        raise SystemExit(f"Pre-repair database cleanup failed: {pre_repair_db_cleanup}")

    # Stage 3: create ONE fresh backup of the already-cleaned DB. If the local
    # volume is tight, old pre-v6.x backups are pruned first. Users can point
    # --backup-dir to another drive if needed.
    backup = ""
    backup_space: dict[str, Any] = {"status": "disabled"}
    if not no_backup:
        backup_space = ensure_space_for_fresh_backup(root, db, backup_dir=backup_dir)
        if not backup_space.get("enough_space"):
            raise SystemExit(
                "Repository cleanup completed, but there is still not enough free space for a safe fresh backup. "
                f"Need {backup_space.get('required_free_bytes')} bytes; have {backup_space.get('free_bytes')}. "
                "Free disk space or use --backup-dir on another drive. The semantic repair has NOT started."
            )
        dest_dir = Path(str(backup_space["backup_dir"]))
        target = dest_dir / f"{db.stem}.pre_v622_{stamp()}{db.suffix}"
        sqlite_backup(db, target)
        backup = str(target)

    # Stage 4: run every v6.21 semantic/classification/collision repair with all
    # nested backups and VACUUMs disabled. Repository + DB debris is already gone.
    base = repair_v621(
        db,
        knowledge,
        force_active=force_active,
        no_backup=True,
        keep_crawl_runs=keep_crawl_runs,
        keep_old_runtime_data=keep_old_runtime_data,
        no_vacuum=True,
    )

    # Stage 5: one post-repair hygiene pass (still no VACUUM) to remove orphans
    # created by consolidation/rewiring, then optional disk-space-aware VACUUM.
    store = SQLiteKnowledgeGraph(db)
    post_repair_cleanup = purge_irrelevant_legacy_data(
        store,
        keep_crawl_runs=max(0, int(keep_crawl_runs)),
        purge_runtime_telemetry=not bool(keep_old_runtime_data),
        vacuum=False,
    )
    if not post_repair_cleanup.get("ok"):
        raise SystemExit(f"Post-repair database cleanup failed: {post_repair_cleanup}")

    vacuum = safe_final_vacuum(db, enabled=not bool(no_vacuum))
    if not vacuum.get("ok"):
        raise SystemExit(f"Final VACUUM failed: {vacuum}")

    store = SQLiteKnowledgeGraph(db)
    quality = store.semantic_quality_report()
    hygiene = database_hygiene_report(store)
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(row) for row in conn.execute("PRAGMA foreign_key_check").fetchall()]
        temporary_rekeys = int(
            conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0]
        )

    ephem = sum(int(v) for v in hygiene.get("ephemeral_runtime_rows", {}).values())
    dirty = any(int(hygiene.get(k, 0)) for k in (
        "orphan_semantic_aliases", "orphan_product_identity_aliases",
        "orphan_product_enrichment_rows", "orphan_validation_rows",
        "dead_empty_sources", "irrelevant_skipped_queue_rows",
    ))
    if (
        integrity.casefold() != "ok" or fk or temporary_rekeys or ephem or dirty
        or not bool(quality.get("clean_for_semantic_sync"))
    ):
        raise SystemExit(
            "v6.22 post-repair validation failed: "
            f"integrity={integrity}, foreign_keys={fk[:10]}, temporary_rekeys={temporary_rekeys}, "
            f"ephemeral_rows={ephem}, dirty_hygiene={dirty}, clean_for_semantic_sync={quality.get('clean_for_semantic_sync')}"
        )

    report: dict[str, Any] = {
        "migration": "v6.x -> v6.22 clean-first collision-safe canonical crawler",
        "database": str(db),
        "process_state_before_cleanup": process_state,
        "repository_cleanup_first": repository_cleanup,
        "pre_repair_database_cleanup": pre_repair_db_cleanup,
        "fresh_backup_after_cleanup": backup,
        "backup_space": backup_space,
        "v621_repairs": base,
        "post_repair_database_cleanup": post_repair_cleanup,
        "final_vacuum": vacuum,
        "integrity_after": integrity,
        "foreign_key_violations": fk,
        "temporary_semantic_rekeys_remaining": temporary_rekeys,
        "semantic_quality": quality,
        "database_hygiene": hygiene,
        "finished_at": now(),
    }
    path = knowledge / "DATABASE_REPAIR_V622.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report["report_path"] = str(path)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Dell Crawler v6.22: clean repository/database debris FIRST, then run collision-safe semantic repairs."
    )
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--knowledge", default="knowledge")
    parser.add_argument("--force-active", action="store_true")
    parser.add_argument("--no-backup", action="store_true")
    parser.add_argument("--backup-dir", default="", help="Optional backup directory, preferably on another drive when local disk is tight.")
    parser.add_argument("--keep-old-backups", type=int, default=1)
    parser.add_argument("--keep-crawl-runs", type=int, default=3)
    parser.add_argument("--keep-old-runtime-data", action="store_true")
    parser.add_argument("--no-vacuum", action="store_true")
    args = parser.parse_args()
    db = Path(args.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    result = repair(
        db,
        Path(args.knowledge).expanduser().resolve(),
        force_active=args.force_active,
        no_backup=args.no_backup,
        backup_dir=Path(args.backup_dir).expanduser().resolve() if args.backup_dir else None,
        keep_old_backups=args.keep_old_backups,
        keep_crawl_runs=args.keep_crawl_runs,
        keep_old_runtime_data=args.keep_old_runtime_data,
        no_vacuum=args.no_vacuum,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

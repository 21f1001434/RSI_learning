# v6.23 — Lean Compact Database Repair

v6.23 addresses repeated `database or disk is full` failures on long-running crawler repositories.

## Why v6.22 could still look huge

Deleting SQLite rows only adds pages to SQLite's internal free list. Windows does not regain that space until the file is physically rewritten. A normal `VACUUM` can itself need roughly another database worth of free disk space.

## v6.23 strategy

1. Gracefully stop crawler/browser owners.
2. Delete runtime/reports/test caches and old backups.
3. Delete regenerable text/vision/PDF-render caches unless explicitly preserved.
4. Convert ordinary FTS5 copies to external-content FTS5 indexes so chunk/node payloads are not stored twice.
5. Move terminal queue history into a compact `crawl_suppression` table and remove bulky terminal queue rows.
6. Remove link evidence already materialized as graph edges.
7. Remove document-section/recommendation evidence/facts already preserved in chunks.
8. Retain only the newest configurable Product observations (24 by default).
9. Run all semantic classification, dedupe, Product identity and node-key collision repairs.
10. Use `VACUUM INTO` to create a verified compact DB, optionally on another drive, then safely replace the bloated DB.

Unique semantic knowledge, chunks, Products, Support knowledge, unmapped evidence, action-policy memory, pending/retry work, raw source files, screenshots and evidence are preserved.

If C: is nearly full, use both `--backup-dir D:\DellCrawlerBackup` and `--compact-dir D:\DellCrawlerCompact`.

@echo off
setlocal
set DB=%~1
if "%DB%"=="" set DB=knowledge\dell_en_uk.db
set KNOWLEDGE=%~2
if "%KNOWLEDGE%"=="" set KNOWLEDGE=knowledge
python repair_v623.py --db "%DB%" --knowledge "%KNOWLEDGE%"
if errorlevel 1 exit /b %errorlevel%
python audit_knowledge_v623.py --db "%DB%" --require-clean
if errorlevel 1 exit /b %errorlevel%
python release_verify_v623.py --db "%DB%"
if errorlevel 1 exit /b %errorlevel%
python -m streamlit run app.py

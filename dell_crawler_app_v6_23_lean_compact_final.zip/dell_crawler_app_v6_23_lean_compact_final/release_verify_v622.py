from __future__ import annotations

import argparse
import compileall
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
from typing import Any

ROOT = Path(__file__).resolve().parent


def _run(cmd: list[str]) -> dict[str, Any]:
    proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
    return {"command": cmd, "returncode": proc.returncode, "stdout_tail": proc.stdout[-8000:], "stderr_tail": proc.stderr[-8000:], "ok": proc.returncode == 0}


def _manifest_check() -> dict[str, Any]:
    path = ROOT / "MANIFEST_SHA256.json"
    if not path.exists():
        return {"ok": False, "status": "MISSING"}
    payload = json.loads(path.read_text(encoding="utf-8"))
    mismatches: list[dict[str, Any]] = []
    for item in payload.get("files", []):
        file_path = ROOT / str(item.get("path") or "")
        if not file_path.exists():
            mismatches.append({"path": str(item.get("path")), "reason": "missing"})
            continue
        digest = hashlib.sha256(file_path.read_bytes()).hexdigest()
        size = file_path.stat().st_size
        if digest != item.get("sha256") or size != int(item.get("size_bytes", size)):
            mismatches.append({"path": str(item.get("path")), "reason": "hash_or_size_mismatch"})
    return {"ok": not mismatches and len(payload.get("files", [])) == int(payload.get("file_count", -1)), "declared_file_count": payload.get("file_count"), "checked_file_count": len(payload.get("files", [])), "mismatches": mismatches}


def _db_check(db: Path) -> dict[str, Any]:
    if not db.exists():
        return {"ok": True, "status": "NOT_PRESENT", "path": str(db)}
    with sqlite3.connect(db) as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
    from dell_crawler_core.db_hygiene import database_hygiene_report
    store = SQLiteKnowledgeGraph(db)
    semantic = store.semantic_quality_report()
    hygiene = database_hygiene_report(store)
    with store.connect() as conn:
        temp_rekeys = int(conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0])
    ephem = sum(int(v) for v in hygiene.get("ephemeral_runtime_rows", {}).values())
    dirty = any(int(hygiene.get(k, 0)) for k in (
        "orphan_semantic_aliases", "orphan_product_identity_aliases", "orphan_product_enrichment_rows",
        "orphan_validation_rows", "dead_empty_sources", "irrelevant_skipped_queue_rows",
    ))
    return {"ok": integrity.casefold() == "ok" and bool(semantic.get("clean_for_semantic_sync", False)) and temp_rekeys == 0 and ephem == 0 and not dirty, "status": "CHECKED", "path": str(db), "integrity_check": integrity, "semantic_quality": semantic, "database_hygiene": hygiene, "temporary_semantic_rekeys": temp_rekeys}


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify Dell Crawler v6.22 clean-first release/runtime prerequisites.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument("--skip-manifest", action="store_true")
    parser.add_argument("--output", default="reports/FINAL_VALIDATION_V622_RUNTIME.json")
    args = parser.parse_args()

    imports_ok, import_error = True, ""
    try:
        import dell_crawler_core.dell_crawler  # noqa: F401
        import dell_crawler_core.kg_store  # noqa: F401
        import dell_crawler_core.repository_cleanup  # noqa: F401
        import dell_crawler_core.db_hygiene  # noqa: F401
    except Exception as exc:
        imports_ok, import_error = False, f"{type(exc).__name__}: {exc}"

    compile_ok = bool(compileall.compile_dir(str(ROOT), quiet=1))
    tests = {"ok": True, "status": "SKIPPED"} if args.skip_tests else _run([sys.executable, "-m", "pytest", "-q"])
    db_result = _db_check(Path(args.db).expanduser().resolve())
    manifest = {"ok": True, "status": "SKIPPED"} if args.skip_manifest else _manifest_check()
    report = {
        "release": "v6.22-clean-first-final",
        "python": {"version": sys.version, "supported": sys.version_info >= (3, 11), "executable": sys.executable},
        "imports": {"ok": imports_ok, "error": import_error},
        "compileall": {"ok": compile_ok},
        "tests": tests,
        "database": db_result,
        "manifest": manifest,
        "browser_prerequisites": {"node_found": bool(shutil.which("node")), "npx_found": bool(shutil.which("npx") or shutil.which("npx.cmd"))},
        "live_external_checks": {"dell_sso": "NOT_RUN_BY_RELEASE_VERIFIER", "dell_aia": "NOT_RUN_BY_RELEASE_VERIFIER", "dell_com": "NOT_RUN_BY_RELEASE_VERIFIER"},
    }
    report["ok"] = all([report["python"]["supported"], imports_ok, compile_ok, bool(tests.get("ok")), bool(db_result.get("ok")), bool(manifest.get("ok"))])
    out = ROOT / args.output
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import argparse
import json
from pathlib import Path

from audit_knowledge_v620 import build_report as build_v620_report
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def build_report(db: Path) -> dict:
    report = build_v620_report(db)
    report["release"] = "v6.21"
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        report["semantic_key_collision_recovery"] = {
            "temporary_rekey_nodes": int(
                conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0]
            ),
            "recovered_nodes": int(
                conn.execute("SELECT COUNT(*) FROM nodes WHERE attributes_json LIKE '%semantic_key_collision_recovered%'").fetchone()[0]
            ),
        }
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit Dell crawler v6.21 semantic quality, hygiene and key-collision recovery.")
    parser.add_argument("--db", default="knowledge/dell_en_uk.db")
    parser.add_argument("--output", default="")
    parser.add_argument("--require-clean", action="store_true")
    args = parser.parse_args()
    db = Path(args.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    report = build_report(db)
    text = json.dumps(report, indent=2, ensure_ascii=False, default=str)
    print(text)
    if args.output:
        Path(args.output).expanduser().write_text(text, encoding="utf-8")
    if args.require_clean:
        q = report["semantic_quality"]
        h = report["database_hygiene"]
        c = report["semantic_key_collision_recovery"]
        ephem = sum(int(v) for v in h.get("ephemeral_runtime_rows", {}).values())
        dirty = any(int(h.get(k, 0)) for k in (
            "orphan_semantic_aliases", "orphan_product_identity_aliases",
            "orphan_product_enrichment_rows", "orphan_validation_rows", "dead_empty_sources",
            "irrelevant_skipped_queue_rows",
        ))
        if (
            not bool(q.get("clean_for_semantic_sync"))
            or report["integrity_check"].casefold() != "ok"
            or report["foreign_key_violations"]
            or int(c.get("temporary_rekey_nodes", 0)) != 0
            or ephem != 0
            or dirty
        ):
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sqlite3

from audit_knowledge_v622 import build_report as build_v622_report
from dell_crawler_core.db_hygiene import database_hygiene_report
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def build_report(db: Path) -> dict:
    report = build_v622_report(db)
    report["release"] = "v6.23"
    store = SQLiteKnowledgeGraph(db)
    report["database_hygiene"] = database_hygiene_report(store)
    with store.connect() as conn:
        page_size = int(conn.execute("PRAGMA page_size").fetchone()[0])
        page_count = int(conn.execute("PRAGMA page_count").fetchone()[0])
        freelist = int(conn.execute("PRAGMA freelist_count").fetchone()[0])
        terminal_queue = int(conn.execute("SELECT COUNT(*) FROM crawl_queue WHERE status IN ('DONE','SKIPPED_PERMANENT')").fetchone()[0])
        suppression = int(conn.execute("SELECT COUNT(*) FROM crawl_suppression").fetchone()[0])
        fts_sql = str(conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='chunks_fts'").fetchone()[0] or "")
    report["lean_storage"] = {
        "database_bytes": db.stat().st_size,
        "page_size": page_size,
        "page_count": page_count,
        "freelist_count": freelist,
        "internal_free_bytes": page_size * freelist,
        "terminal_queue_rows": terminal_queue,
        "crawl_suppression_rows": suppression,
        "external_content_fts": "content='chunks'" in fts_sql.replace(" ", "").lower(),
    }
    return report


def main() -> int:
    p = argparse.ArgumentParser(description="Audit Dell crawler v6.23 lean compact semantic/database quality.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--output", default="")
    p.add_argument("--require-clean", action="store_true")
    a = p.parse_args()
    db = Path(a.db).expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    report = build_report(db)
    text = json.dumps(report, indent=2, ensure_ascii=False, default=str)
    print(text)
    if a.output:
        Path(a.output).expanduser().write_text(text, encoding="utf-8")
    if a.require_clean:
        q = report["semantic_quality"]
        h = report["database_hygiene"]
        c = report["semantic_key_collision_recovery"]
        lean = report["lean_storage"]
        ephem = sum(int(v) for v in h.get("ephemeral_runtime_rows", {}).values())
        dirty = any(int(h.get(k, 0)) for k in (
            "orphan_semantic_aliases", "orphan_product_identity_aliases",
            "orphan_product_enrichment_rows", "orphan_validation_rows",
            "dead_empty_sources", "irrelevant_skipped_queue_rows",
        ))
        if (
            not bool(q.get("clean_for_semantic_sync"))
            or report["integrity_check"].casefold() != "ok"
            or report["foreign_key_violations"]
            or int(c.get("temporary_rekey_nodes", 0)) != 0
            or ephem != 0 or dirty
            or int(lean.get("terminal_queue_rows", 0)) != 0
            or not bool(lean.get("external_content_fts"))
        ):
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

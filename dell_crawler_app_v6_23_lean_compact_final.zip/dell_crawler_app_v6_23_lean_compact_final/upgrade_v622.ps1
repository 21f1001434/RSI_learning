param(
  [string]$Python = "python",
  [string]$Db = "knowledge\dell_en_uk.db",
  [string]$Knowledge = "knowledge",
  [string]$BackupDir = "",
  [int]$KeepOldBackups = 1,
  [int]$KeepCrawlRuns = 3
)
$ErrorActionPreference = "Stop"
Write-Host "Dell Crawler v6.22 CLEAN-FIRST upgrade" -ForegroundColor Cyan
Write-Host "1) Gracefully stop crawler. 2) Pause OneDrive sync. 3) Repository cleanup runs BEFORE DB repair." -ForegroundColor Yellow
$argsList = @(".\repair_v622.py", "--db", $Db, "--knowledge", $Knowledge, "--keep-old-backups", "$KeepOldBackups", "--keep-crawl-runs", "$KeepCrawlRuns")
if ($BackupDir -ne "") { $argsList += @("--backup-dir", $BackupDir) }
& $Python @argsList
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python .\audit_knowledge_v622.py --db $Db --require-clean
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python .\release_verify_v622.py --db $Db
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $Python -m streamlit run .\app.py

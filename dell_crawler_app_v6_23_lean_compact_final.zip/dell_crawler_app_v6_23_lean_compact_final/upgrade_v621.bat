@echo off
setlocal
set PYTHON=python
set DB=knowledge\dell_en_uk.db
set KNOWLEDGE=knowledge
echo Dell Crawler v6.21 collision-safe semantic repair + full cleanup
echo Use Graceful Stop first and pause OneDrive sync while SQLite is being repaired.
%PYTHON% .\repair_v621.py --db "%DB%" --knowledge "%KNOWLEDGE%"
if errorlevel 1 exit /b %errorlevel%
%PYTHON% .\audit_knowledge_v621.py --db "%DB%" --require-clean
if errorlevel 1 exit /b %errorlevel%
%PYTHON% .\release_verify_v621.py --db "%DB%"
if errorlevel 1 exit /b %errorlevel%
%PYTHON% -m streamlit run .\app.py

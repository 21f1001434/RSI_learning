from __future__ import annotations

"""v6.23 repair: reclaim space first, repair semantics, then compact-swap DB."""

import argparse
import json
from pathlib import Path
import shutil
import sqlite3
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.lean_compaction import logical_lean_cleanup, compact_swap_database
from dell_crawler_core.repository_cleanup import (
    clean_repository_before_repair,
    clean_regenerable_knowledge_artifacts,
)
from repair_v610 import now, sqlite_backup, stamp, inspect_runtime_processes, clear_stale_profile_lease
from repair_v622 import repair as repair_v622


def _old_backups(db: Path) -> list[Path]:
    out: set[Path] = set()
    for pat in (
        f"{db.stem}.pre_v*{db.suffix}", f"{db.stem}.pre_v*{db.suffix}.bak",
        f"{db.stem}.backup*{db.suffix}", f"{db.stem}.*backup*{db.suffix}",
    ):
        out.update(db.parent.glob(pat))
    out.discard(db)
    return sorted(out, key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)


def _assert_stopped(root: Path, db: Path, force_active: bool) -> dict[str, Any]:
    runtime = inspect_runtime_processes(root)
    profile = clear_stale_profile_lease(root)
    live = list(runtime.get("live_pids") or [])
    if profile.get("status") == "live_owner":
        pid = int(profile.get("owner_pid") or 0)
        if pid and pid not in live:
            live.append(pid)
    if live and not force_active:
        raise SystemExit(f"Refusing v6.23 repair while crawler/browser PID(s) {sorted(set(live))} are alive. Use Graceful Stop first.")
    return {"runtime": runtime, "profile": profile, "live_pids": sorted(set(live))}


def _make_or_reuse_backup(db: Path, backup_dir: Path | None, *, no_backup: bool) -> dict[str, Any]:
    if no_backup:
        return {"status": "disabled", "path": ""}
    existing = _old_backups(db)
    destination = (backup_dir or db.parent).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    required = int(db.stat().st_size * 1.05) + 64 * 1024 * 1024
    free = shutil.disk_usage(destination).free
    if free >= required:
        target = destination / f"{db.stem}.pre_v623_{stamp()}{db.suffix}"
        sqlite_backup(db, target)
        return {"status": "created", "path": str(target), "free_bytes": free, "required_bytes": required}
    if existing:
        # Reuse the latest already-created safety backup. This avoids requiring
        # another full DB worth of space on a machine that is already full.
        with sqlite3.connect(existing[0]) as conn:
            integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        if integrity.casefold() == "ok":
            return {"status": "reused_existing", "path": str(existing[0]), "free_bytes": free, "required_bytes": required}
    raise SystemExit(
        "Repository/cache cleanup completed but there is not enough free space for a new safety backup and no valid existing backup is available. "
        "Use --backup-dir on another drive, or explicitly use --no-backup if you accept that risk."
    )


def repair(
    db: Path,
    knowledge: Path,
    *,
    force_active: bool = False,
    no_backup: bool = False,
    backup_dir: Path | None = None,
    compact_dir: Path | None = None,
    keep_product_observations: int = 24,
    preserve_text_cache: bool = False,
    preserve_vision_cache: bool = False,
    allow_logical_only: bool = False,
) -> dict[str, Any]:
    root = Path(__file__).resolve().parent
    db = db.resolve()
    knowledge = knowledge.resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge.mkdir(parents=True, exist_ok=True)

    process_state = _assert_stopped(root, db, force_active)

    # 1) FREE REAL FILESYSTEM SPACE before opening repair chains.
    repo_cleanup = clean_repository_before_repair(root, db, keep_old_backups=1, clear_reports=True, clear_runtime=True)
    knowledge_cleanup = clean_regenerable_knowledge_artifacts(
        knowledge,
        preserve_text_cache=preserve_text_cache,
        preserve_vision_cache=preserve_vision_cache,
    )

    # 2) Migrate bulky ordinary FTS copies to external-content FTS and delete
    # redundant DB rows. This creates reusable free pages inside SQLite without
    # needing OS-level temporary space.
    store = SQLiteKnowledgeGraph(db)
    pre_lean = logical_lean_cleanup(store, keep_crawl_runs=1, keep_product_observations=keep_product_observations)
    if not pre_lean.get("ok"):
        raise SystemExit(f"v6.23 pre-repair lean cleanup failed: {pre_lean}")

    # 3) Safety copy only after the DB has logically shed redundant content.
    backup = _make_or_reuse_backup(db, backup_dir, no_backup=no_backup)

    # 4) Run all collision/classification/market repairs with nested backup and
    # VACUUM disabled. v6.23 owns physical compaction.
    base = repair_v622(
        db,
        knowledge,
        force_active=force_active,
        no_backup=True,
        keep_old_backups=1,
        keep_crawl_runs=1,
        keep_old_runtime_data=False,
        no_vacuum=True,
    )

    # 5) Remove redundant rows newly exposed by consolidation.
    store = SQLiteKnowledgeGraph(db)
    post_lean = logical_lean_cleanup(store, keep_crawl_runs=1, keep_product_observations=keep_product_observations)
    if not post_lean.get("ok"):
        raise SystemExit(f"v6.23 post-repair lean cleanup failed: {post_lean}")

    # 6) Physically shrink the DB. --compact-dir may point to D:/ or another
    # volume. If same-drive space is still too low, repair remains valid and the
    # report tells the user to provide an alternate compact dir.
    compaction = compact_swap_database(db, compact_dir=compact_dir or backup_dir)
    if not compaction.get("ok"):
        raise SystemExit(f"v6.23 compact-swap failed: {compaction}")
    if compaction.get("status") != "completed" and not allow_logical_only:
        raise SystemExit(
            "The knowledge repair is logically clean, but the SQLite file could not be physically shrunk because the selected compact location lacks free space. "
            f"Details: {compaction}. Re-run with --compact-dir on another drive (for example D:\\DellCrawlerCompact). "
            "Use --allow-logical-only only if you intentionally accept that Windows disk usage will not shrink yet."
        )

    # 7) Final semantic + SQLite validation.
    store = SQLiteKnowledgeGraph(db)
    quality = store.semantic_quality_report()
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
        temp_rekeys = int(conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0])
        suppression = int(conn.execute("SELECT COUNT(*) FROM crawl_suppression").fetchone()[0])
        page_size = int(conn.execute("PRAGMA page_size").fetchone()[0])
        page_count = int(conn.execute("PRAGMA page_count").fetchone()[0])
        freelist = int(conn.execute("PRAGMA freelist_count").fetchone()[0])

    if integrity.casefold() != "ok" or fk or temp_rekeys or not bool(quality.get("clean_for_semantic_sync")):
        raise SystemExit(
            "v6.23 final validation failed: "
            f"integrity={integrity}, foreign_keys={fk[:10]}, temporary_rekeys={temp_rekeys}, "
            f"clean_for_semantic_sync={quality.get('clean_for_semantic_sync')}"
        )

    report = {
        "migration": "v6.x -> v6.23 lean compact collision-safe canonical crawler",
        "database": str(db),
        "process_state": process_state,
        "repository_cleanup": repo_cleanup,
        "regenerable_knowledge_cleanup": knowledge_cleanup,
        "pre_repair_lean_cleanup": pre_lean,
        "backup": backup,
        "v622_semantic_repairs": base,
        "post_repair_lean_cleanup": post_lean,
        "physical_compaction": compaction,
        "integrity_after": integrity,
        "foreign_key_violations": fk,
        "temporary_semantic_rekeys": temp_rekeys,
        "crawl_suppression_rows": suppression,
        "semantic_quality": quality,
        "sqlite_final": {
            "database_bytes": db.stat().st_size,
            "page_size": page_size,
            "page_count": page_count,
            "freelist_count": freelist,
            "internal_free_bytes": page_size * freelist,
        },
        "finished_at": now(),
    }
    path = knowledge / "DATABASE_REPAIR_V623.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report["report_path"] = str(path)
    return report


def main() -> int:
    p = argparse.ArgumentParser(description="Dell Crawler v6.23: lean DB cleanup + verified compact-swap + semantic repair.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--knowledge", default="knowledge")
    p.add_argument("--force-active", action="store_true")
    p.add_argument("--no-backup", action="store_true")
    p.add_argument("--backup-dir", default="", help="Safety-backup directory; another drive is recommended when C: is full.")
    p.add_argument("--compact-dir", default="", help="Where to build the compact DB. Use another drive when the DB drive is full.")
    p.add_argument("--keep-product-observations", type=int, default=24)
    p.add_argument("--preserve-text-cache", action="store_true")
    p.add_argument("--preserve-vision-cache", action="store_true")
    p.add_argument("--allow-logical-only", action="store_true")
    a = p.parse_args()
    result = repair(
        Path(a.db).expanduser().resolve(),
        Path(a.knowledge).expanduser().resolve(),
        force_active=a.force_active,
        no_backup=a.no_backup,
        backup_dir=Path(a.backup_dir).expanduser().resolve() if a.backup_dir else None,
        compact_dir=Path(a.compact_dir).expanduser().resolve() if a.compact_dir else None,
        keep_product_observations=a.keep_product_observations,
        preserve_text_cache=a.preserve_text_cache,
        preserve_vision_cache=a.preserve_vision_cache,
        allow_logical_only=a.allow_logical_only,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

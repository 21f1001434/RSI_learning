from __future__ import annotations

"""Cross-page semantic classification and collision-safe duplicate consolidation for v6.21."""

import json
import re
import sqlite3
from collections import defaultdict
from typing import Any, Callable

from .knowledge_ontology import canonical_node_type
from .semantic_identity import (
    GRAPH_NODE_TYPES,
    classify_entity,
    classification_attributes,
    semantic_entity_key,
)


def _loads(value: Any, default: Any = None) -> Any:
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value or ""))
    except Exception:
        return {} if default is None else default


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _merge_attrs(base: dict[str, Any], incoming: dict[str, Any]) -> dict[str, Any]:
    out = dict(base or {})
    for key, value in (incoming or {}).items():
        if value in (None, "", [], {}):
            continue
        current = out.get(key)
        if current in (None, "", [], {}):
            out[key] = value
        elif isinstance(current, dict) and isinstance(value, dict):
            out[key] = _merge_attrs(current, value)
        elif isinstance(current, list) and isinstance(value, list):
            merged = list(current)
            for item in value:
                if item not in merged:
                    merged.append(item)
            out[key] = merged
    return out


def _row_score(row: sqlite3.Row, target_key: str) -> tuple[int, int, int]:
    attrs = _loads(row["attributes_json"], {})
    exact = 1000 if str(row["node_key"] or "") == target_key else 0
    richness = sum(int(v not in (None, "", [], {})) for v in attrs.values())
    return (exact, richness, -int(row["id"]))


def _slug_token(value: Any) -> str:
    token = re.sub(r"[^a-z0-9]+", "-", str(value or "").casefold()).strip("-")
    return token[:180]


def _available_key(conn: sqlite3.Connection, preferred: str, node_id: int) -> str:
    """Return a node key that is not owned by another row.

    Repairs must be restart-safe: a previous failed migration may already have staged
    a row under one of these temporary keys, so suffix until an unused key is found.
    """
    candidate = preferred
    suffix = 0
    while conn.execute(
        "SELECT 1 FROM nodes WHERE node_key=? AND id<>? LIMIT 1", (candidate, int(node_id))
    ).fetchone():
        suffix += 1
        candidate = f"{preferred}:{suffix}"
    return candidate


def _safe_product_recovery_key(conn: sqlite3.Connection, row: sqlite3.Row, attrs: dict[str, Any]) -> str:
    """Recover a Product that historically occupies a non-Product semantic key.

    Old databases can contain a Product under keys such as ``brand:*`` or
    ``category:*``.  That blocks canonical semantic re-keying because ``nodes.node_key``
    is globally UNIQUE.  Prefer the same strong Product identity order as runtime
    ingestion; fall back to an explicit legacy Product namespace without losing data.
    """
    node_id = int(row["id"])
    order = _slug_token(attrs.get("order_code") or attrs.get("orderCode") or attrs.get("sku"))
    part = _slug_token(attrs.get("part_number") or attrs.get("partNumber") or attrs.get("mpn"))
    product_url = str(attrs.get("product_url") or attrs.get("url") or "").strip()
    model = _slug_token(attrs.get("model"))
    brand = _slug_token(attrs.get("brand"))
    if order:
        preferred = f"product-order:{order}"
    elif part:
        preferred = f"product-part:{part}"
    elif product_url.startswith(("http://", "https://")):
        preferred = f"product-url:{product_url}"
    elif model and brand:
        preferred = f"product-model:{brand}-{model}"
    else:
        preferred = f"product-legacy:{node_id}"
    return _available_key(conn, preferred, node_id)


def _free_semantic_target_key(
    store: Any,
    *,
    target_key: str,
    canonical_id: int,
    classified_meta: dict[int, tuple[str, str, dict[str, Any]]],
    staged_conflicts: dict[int, dict[str, str]],
    report: dict[str, Any],
) -> None:
    """Free ``target_key`` when stale historical data already owns it.

    v6.20 assumed any row currently owning a semantic target key belonged to the same
    identity group.  Real upgraded databases can violate that assumption (for example
    a stale key whose name/type now resolves to a different identity, or a Product that
    was historically written under a Brand/Category key).  Re-key the stale owner
    first, then let the canonical row claim the target key.
    """
    with store.connect() as conn:
        conflict = conn.execute(
            "SELECT * FROM nodes WHERE node_key=? AND id<>? LIMIT 1",
            (target_key, int(canonical_id)),
        ).fetchone()
        if not conflict:
            return

        conflict_id = int(conflict["id"])
        old_key = str(conflict["node_key"] or "")
        attrs = _loads(conflict["attributes_json"], {})
        meta = classified_meta.get(conflict_id)

        if meta is not None:
            intended_type, intended_key, intended_attrs = meta
            # A same-target row should already have been part of this duplicate group
            # and deleted/merged before the rewrite.  Treat any survivor defensively.
            if intended_key == target_key:
                temp_key = _available_key(conn, f"__semantic_rekey_v621__:{conflict_id}", conflict_id)
            else:
                temp_key = _available_key(conn, f"__semantic_rekey_v621__:{conflict_id}", conflict_id)
            merged = _merge_attrs(attrs, intended_attrs)
            merged["semantic_key_collision_recovered"] = True
            merged["semantic_key_collision_original_key"] = old_key
            merged["semantic_key_collision_intended_key"] = intended_key
            conn.execute(
                "UPDATE nodes SET node_key=?,attributes_json=? WHERE id=?",
                (temp_key, _json(merged), conflict_id),
            )
            # Existing aliases pointing at the stale key must follow the actual entity
            # to its intended canonical key.  Never retain the stale key itself as an
            # alias because it is about to become a real canonical key for another node.
            conn.execute(
                "UPDATE semantic_entity_aliases SET canonical_node_key=? WHERE canonical_node_key=? AND node_type=?",
                (intended_key, old_key, intended_type),
            )
            conn.execute("DELETE FROM semantic_entity_aliases WHERE alias_key=?", (old_key,))
            staged_conflicts[conflict_id] = {
                "original_key": old_key,
                "temporary_key": temp_key,
                "intended_key": intended_key,
            }
            report["target_key_collisions_staged"] += 1
            return

        # Product rows are deliberately excluded from semantic classification groups,
        # but old/corrupt databases can still place one under a semantic key.
        if str(conflict["node_type"] or "") == "Product":
            new_key = _safe_product_recovery_key(conn, conflict, attrs)
            attrs["semantic_key_collision_recovered"] = True
            attrs["semantic_key_collision_original_key"] = old_key
            attrs["semantic_key_collision_recovered_product_key"] = new_key
            conn.execute(
                "UPDATE nodes SET node_key=?,attributes_json=? WHERE id=?",
                (new_key, _json(attrs), conflict_id),
            )
            conn.execute(
                "UPDATE product_identity_aliases SET canonical_product_key=? WHERE canonical_product_key=?",
                (new_key, old_key),
            )
            conn.execute(
                "UPDATE product_enrichment_state SET product_key=? WHERE product_key=?",
                (new_key, old_key),
            )
            conn.execute(
                "DELETE FROM semantic_entity_aliases WHERE canonical_node_key=? AND node_type='Product'",
                (old_key,),
            )
            staged_conflicts[conflict_id] = {
                "original_key": old_key,
                "temporary_key": new_key,
                "intended_key": new_key,
            }
            report["product_key_collisions_recovered"] += 1
            return

        # Defensive fallback for a survivor that was neither classified nor Product.
        # Keep it intact under a temporary unique key; a later audit can quarantine it
        # as evidence rather than aborting the entire upgrade.
        temp_key = _available_key(conn, f"__semantic_rekey_v621__:{conflict_id}", conflict_id)
        attrs["semantic_key_collision_recovered"] = True
        attrs["semantic_key_collision_original_key"] = old_key
        conn.execute("UPDATE nodes SET node_key=?,attributes_json=? WHERE id=?", (temp_key, _json(attrs), conflict_id))
        conn.execute("DELETE FROM semantic_entity_aliases WHERE alias_key=?", (old_key,))
        staged_conflicts[conflict_id] = {
            "original_key": old_key,
            "temporary_key": temp_key,
            "intended_key": "",
        }
        report["fallback_key_collisions_staged"] += 1


def _move_alias_into_canonical(
    store: Any,
    canonical: sqlite3.Row,
    alias: sqlite3.Row,
    *,
    target_key: str,
    alias_key_for_history: str | None = None,
    record_alias: bool = True,
) -> dict[str, int]:
    report = {"facts_moved": 0, "edges_moved": 0, "self_edges_removed": 0}
    canonical_id = int(canonical["id"])
    alias_id = int(alias["id"])
    if canonical_id == alias_id:
        return report

    with store.connect() as conn:
        facts = conn.execute("SELECT * FROM facts WHERE subject_id=?", (alias_id,)).fetchall()
        for fact in facts:
            before = conn.total_changes
            conn.execute(
                """
                INSERT OR IGNORE INTO facts(subject_id,predicate,value,unit,qualifiers_json,source_url,confidence,observed_at,valid_from,valid_to)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    canonical_id, fact["predicate"], fact["value"], fact["unit"], fact["qualifiers_json"],
                    fact["source_url"], fact["confidence"], fact["observed_at"], fact["valid_from"], fact["valid_to"],
                ),
            )
            report["facts_moved"] += int(conn.total_changes > before)

        edges = conn.execute("SELECT * FROM edges WHERE source_id=? OR target_id=?", (alias_id, alias_id)).fetchall()
        for edge in edges:
            new_source = canonical_id if int(edge["source_id"]) == alias_id else int(edge["source_id"])
            new_target = canonical_id if int(edge["target_id"]) == alias_id else int(edge["target_id"])
            if new_source == new_target:
                report["self_edges_removed"] += 1
                continue
            existing = conn.execute(
                "SELECT id,attributes_json,confidence FROM edges WHERE source_id=? AND predicate=? AND target_id=? AND source_url=?",
                (new_source, edge["predicate"], new_target, edge["source_url"]),
            ).fetchone()
            if existing:
                attrs = _merge_attrs(_loads(existing["attributes_json"], {}), _loads(edge["attributes_json"], {}))
                conn.execute(
                    "UPDATE edges SET attributes_json=?,confidence=MAX(confidence,?),last_seen=MAX(last_seen,?) WHERE id=?",
                    (_json(attrs), float(edge["confidence"] or 0), edge["last_seen"], int(existing["id"])),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO edges(source_id,predicate,target_id,attributes_json,source_url,confidence,first_seen,last_seen)
                    VALUES(?,?,?,?,?,?,?,?)
                    """,
                    (
                        new_source, edge["predicate"], new_target, edge["attributes_json"], edge["source_url"],
                        edge["confidence"], edge["first_seen"], edge["last_seen"],
                    ),
                )
                report["edges_moved"] += 1

        # Keep a durable alias for genuine historical aliases.  A key displaced
        # because it incorrectly belonged to another identity must *not* be retained
        # as an alias; that key is about to become canonical for the correct entity.
        if record_alias:
            history_key = str(alias_key_for_history or alias["node_key"] or "")
            if history_key:
                conn.execute(
                    """
                    INSERT INTO semantic_entity_aliases(alias_key,canonical_node_key,node_type,reason,confidence,observed_at)
                    VALUES(?,?,?,?,?,datetime('now'))
                    ON CONFLICT(alias_key) DO UPDATE SET
                        canonical_node_key=excluded.canonical_node_key,node_type=excluded.node_type,
                        reason=excluded.reason,confidence=excluded.confidence,observed_at=excluded.observed_at
                    """,
                    (history_key, target_key, str(canonical["node_type"]), "semantic_identity_duplicate_v621", 1.0),
                )
        conn.execute("DELETE FROM nodes WHERE id=?", (alias_id,))
    return report


def classify_and_consolidate(
    store: Any,
    *,
    preserve_as_evidence: Callable[[sqlite3.Row, str, str], None] | None = None,
) -> dict[str, Any]:
    """Classify every historical node and merge stable semantic duplicates.

    Products are deliberately excluded here and remain under the stronger dedicated
    order-code/part-number/PDP resolver.
    """
    report: dict[str, Any] = {
        "nodes_examined": 0,
        "nodes_reclassified": 0,
        "nodes_evidence_only_removed": 0,
        "identity_groups": 0,
        "duplicate_groups": 0,
        "nodes_merged": 0,
        "facts_moved": 0,
        "edges_moved": 0,
        "self_edges_removed": 0,
        "node_keys_rewritten": 0,
        "target_key_collisions_staged": 0,
        "product_key_collisions_recovered": 0,
        "fallback_key_collisions_staged": 0,
        "classification_counts": {},
    }

    with store.connect() as conn:
        rows = conn.execute("SELECT * FROM nodes WHERE node_type<>'Product' ORDER BY id").fetchall()
        source_urls = {
            str(r[0]) for r in conn.execute("SELECT canonical_url FROM sources WHERE canonical_url<>''").fetchall()
        }
        source_urls.update(str(r[0]) for r in conn.execute("SELECT url FROM sources WHERE url<>''").fetchall())

    groups: dict[str, list[sqlite3.Row]] = defaultdict(list)
    evidence_rows: list[tuple[sqlite3.Row, str]] = []
    classified_meta: dict[int, tuple[str, str, dict[str, Any]]] = {}
    staged_conflicts: dict[int, dict[str, str]] = {}

    for row in rows:
        report["nodes_examined"] += 1
        node_key = str(row["node_key"] or "")
        raw_type = str(row["node_type"] or "Unknown")
        name = str(row["name"] or node_key)
        attrs = _loads(row["attributes_json"], {})
        node_url = node_key[4:] if node_key.startswith("url:") else str(attrs.get("url") or attrs.get("canonical_url") or "")
        is_fetched_page = bool(node_url and node_url in source_urls)

        if is_fetched_page:
            node_type = canonical_node_type(raw_type, context="page")
            if node_type not in GRAPH_NODE_TYPES:
                node_type = "Page"
            classification_attrs = {
                "canonical_class": node_type,
                "classification_confidence": 1.0,
                "classification_reason": "historical_fetched_page",
                "classification_version": "v6.19",
            }
        else:
            entity = {"type": raw_type, "name": name, "url": node_url, "attributes": attrs}
            classification = classify_entity(entity, str(attrs.get("source_url") or ""), context="entity")
            node_type = classification.node_type or ""
            classification_attrs = classification_attributes(classification)

        if not node_type or node_type not in GRAPH_NODE_TYPES:
            evidence_rows.append((row, classification_attrs.get("classification_reason", "unclassified_historical_node")))
            continue

        stable_key = semantic_entity_key(
            node_type, name, attrs,
            url=node_url,
            source_url=str(attrs.get("source_url") or ""),
        )
        if not stable_key:
            evidence_rows.append((row, "semantic_identity_unresolved_historical_node"))
            continue

        attrs = _merge_attrs(attrs, classification_attrs)
        attrs["semantic_identity_key"] = stable_key
        classified_meta[int(row["id"])] = (node_type, stable_key, attrs)
        groups[stable_key].append(row)
        report["classification_counts"][node_type] = int(report["classification_counts"].get(node_type, 0)) + 1
        if raw_type != node_type:
            report["nodes_reclassified"] += 1

    # Preserve ambiguous/weak historical nodes outside the semantic graph.
    for row, reason in evidence_rows:
        if preserve_as_evidence:
            preserve_as_evidence(row, "historical_unclassified_node", reason)
        with store.connect() as conn:
            conn.execute("DELETE FROM nodes WHERE id=?", (int(row["id"]),))
        report["nodes_evidence_only_removed"] += 1

    report["identity_groups"] = len(groups)
    for target_key, members in groups.items():
        # Refresh rows because earlier evidence deletions/merges can change the DB.
        live: list[sqlite3.Row] = []
        with store.connect() as conn:
            for member in members:
                row = conn.execute("SELECT * FROM nodes WHERE id=?", (int(member["id"]),)).fetchone()
                if row:
                    live.append(row)
        if not live:
            continue

        if len(live) > 1:
            report["duplicate_groups"] += 1
        canonical = max(live, key=lambda r: _row_score(r, target_key))
        canonical_id = int(canonical["id"])
        node_type, _, canonical_attrs = classified_meta[canonical_id]
        aliases: list[str] = []

        # Merge all aliases into the selected canonical row.
        for alias in live:
            if int(alias["id"]) == canonical_id:
                continue
            alias_meta = classified_meta.get(int(alias["id"]))
            if alias_meta:
                canonical_attrs = _merge_attrs(canonical_attrs, alias_meta[2])
            staged = staged_conflicts.get(int(alias["id"]))
            historical_alias_key = str(staged.get("original_key") if staged else alias["node_key"])
            if historical_alias_key and historical_alias_key != target_key:
                aliases.append(historical_alias_key)
            moved = _move_alias_into_canonical(
                store, canonical, alias, target_key=target_key,
                alias_key_for_history=historical_alias_key,
                record_alias=staged is None,
            )
            for key in ("facts_moved", "edges_moved", "self_edges_removed"):
                report[key] += int(moved[key])
            report["nodes_merged"] += 1

        # Merge identity aliases and rewrite canonical key/type in-place.
        old_aliases = canonical_attrs.get("identity_aliases") if isinstance(canonical_attrs.get("identity_aliases"), list) else []
        canonical_attrs["identity_aliases"] = list(dict.fromkeys([*old_aliases, *aliases]))
        old_key = str(canonical["node_key"])
        staged_canonical = staged_conflicts.get(canonical_id)
        historical_old_key = str(staged_canonical.get("original_key") if staged_canonical else old_key)
        if staged_canonical:
            canonical_attrs["semantic_key_collision_recovered"] = True
            canonical_attrs["semantic_key_collision_original_key"] = historical_old_key

        # The unique node_key can be occupied by a stale row from another identity
        # group.  Free it safely before claiming the canonical key.
        _free_semantic_target_key(
            store, target_key=target_key, canonical_id=canonical_id,
            classified_meta=classified_meta, staged_conflicts=staged_conflicts, report=report,
        )

        with store.connect() as conn:
            conn.execute(
                "UPDATE nodes SET node_key=?,node_type=?,attributes_json=? WHERE id=?",
                (target_key, node_type, _json(canonical_attrs), canonical_id),
            )
            if old_key != target_key:
                # Do not create an alias from a stale collision key that is now the
                # canonical identity of another node.  Genuine historical aliases
                # remain durable as before.
                if staged_canonical is None and historical_old_key and historical_old_key != target_key:
                    conn.execute(
                        """
                        INSERT INTO semantic_entity_aliases(alias_key,canonical_node_key,node_type,reason,confidence,observed_at)
                        VALUES(?,?,?,?,?,datetime('now'))
                        ON CONFLICT(alias_key) DO UPDATE SET canonical_node_key=excluded.canonical_node_key,
                            node_type=excluded.node_type,reason=excluded.reason,confidence=excluded.confidence,observed_at=excluded.observed_at
                        """,
                        (historical_old_key, target_key, node_type, "canonical_key_rewrite_v621", 1.0),
                    )
                report["node_keys_rewritten"] += 1

    # Remove exact duplicate/self edges left by historical graph noise.
    with store.connect() as conn:
        self_ids = [int(r[0]) for r in conn.execute("SELECT id FROM edges WHERE source_id=target_id").fetchall()]
        for eid in self_ids:
            conn.execute("DELETE FROM edges WHERE id=?", (eid,))
        report["self_edges_removed"] += len(self_ids)

    return report

param(
    [string]$Db = ".\knowledge\dell_en_uk.db",
    [string]$Knowledge = ".\knowledge",
    [string]$BackupDir = "",
    [string]$CompactDir = ""
)
$ErrorActionPreference = "Stop"
$args = @(".\repair_v623.py", "--db", $Db, "--knowledge", $Knowledge)
if ($BackupDir) { $args += @("--backup-dir", $BackupDir) }
if ($CompactDir) { $args += @("--compact-dir", $CompactDir) }
python @args
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python .\audit_knowledge_v623.py --db $Db --require-clean
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python .\release_verify_v623.py --db $Db
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m streamlit run .\app.py

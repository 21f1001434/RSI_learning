from __future__ import annotations

from pathlib import Path
import sqlite3

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.lean_compaction import logical_lean_cleanup, compact_swap_database
from dell_crawler_core.repository_cleanup import clean_regenerable_knowledge_artifacts


def test_external_content_fts_and_search_work(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    store.upsert_source("https://www.dell.com/en-us/p/test", "Test", "ProductPage", "hash", 200)
    store.replace_chunks("https://www.dell.com/en-us/p/test", "Dell Precision workstation with RTX graphics")
    with store.connect() as conn:
        sql = str(conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='chunks_fts'").fetchone()[0])
        assert "content='chunks'" in sql.replace(" ", "").lower()
        assert conn.execute("SELECT COUNT(*) FROM chunks_fts").fetchone()[0] == conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
    rows = store.search("Precision RTX", limit=5)
    assert rows


def test_terminal_queue_compacts_to_suppression_and_prevents_requeue(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    url = "https://www.dell.com/en-us/p/test"
    store.enqueue(url)
    store.upsert_source(url, "Test", "ProductPage", "hash", 200)
    store.mark_queue(url, "DONE")
    result = logical_lean_cleanup(store, keep_product_observations=5)
    assert result["ok"] is True
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM crawl_queue WHERE url=?", (url,)).fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM crawl_suppression WHERE url=?", (url,)).fetchone()[0] == 1
    assert store.enqueue(url) is False
    assert store.enqueue(url, force=True) is True


def test_redundant_materialized_link_evidence_is_pruned(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    a = "https://www.dell.com/en-us/a"
    b = "https://www.dell.com/en-us/b"
    for u in (a, b):
        store.upsert_source(u, u, "WebPage", u[-1], 200)
        store.upsert_node(f"url:{u}", "Page", u, {"url": u})
    store.record_link_evidence(a, b, relation="LINKS_TO")
    store.upsert_edge(f"url:{a}", "LINKS_TO", f"url:{b}", a)
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM link_evidence").fetchone()[0] == 1
    result = logical_lean_cleanup(store)
    assert result["deleted"]["materialized_link_evidence"] == 1


def test_compact_swap_reclaims_internal_free_pages(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS space_hog(id INTEGER PRIMARY KEY, payload TEXT)")
        conn.executemany("INSERT INTO space_hog(payload) VALUES(?)", [("x" * 5000,) for _ in range(1500)])
    big = db.stat().st_size
    with sqlite3.connect(db) as conn:
        conn.execute("DELETE FROM space_hog")
        conn.commit()
    result = compact_swap_database(db, compact_dir=tmp_path / "compact")
    assert result["ok"] is True
    assert result["status"] == "completed"
    assert db.stat().st_size < big
    with sqlite3.connect(db) as conn:
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def test_regenerable_cache_cleanup_preserves_raw_and_evidence(tmp_path: Path) -> None:
    knowledge = tmp_path / "knowledge"
    for name in ("text_cache", "vision_cache", "pdf_visual_pages", "dynamic_states", "raw", "screenshots", "evidence"):
        p = knowledge / name / "x.bin"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"x" * 100)
    (knowledge / "PDF_FAILURES.jsonl").write_text("{}\n", encoding="utf-8")
    result = clean_regenerable_knowledge_artifacts(knowledge)
    assert result["ok"] is True
    for name in ("text_cache", "vision_cache", "pdf_visual_pages", "dynamic_states"):
        assert not (knowledge / name).exists()
    for name in ("raw", "screenshots", "evidence"):
        assert (knowledge / name / "x.bin").exists()
    assert not (knowledge / "PDF_FAILURES.jsonl").exists()

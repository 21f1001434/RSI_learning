from __future__ import annotations

from pathlib import Path
import sqlite3

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.repository_cleanup import clean_repository_before_repair, safe_final_vacuum
from repair_v622 import repair


def test_repository_cleanup_runs_before_repair_and_preserves_knowledge(tmp_path: Path, monkeypatch) -> None:
    root = tmp_path / "repo"
    knowledge = root / "knowledge"
    runtime = root / "runtime"
    reports = root / "reports"
    knowledge.mkdir(parents=True)
    runtime.mkdir()
    reports.mkdir()
    db = knowledge / "dell_en_uk.db"
    store = SQLiteKnowledgeGraph(db)
    store.upsert_node("brand:dell-technologies", "Brand", "Dell Technologies", {})
    (runtime / "huge.log").write_bytes(b"x" * 4096)
    (reports / "old.json").write_text("{}", encoding="utf-8")
    old = knowledge / "dell_en_uk.pre_v621_OLD.db"
    old.write_bytes(b"x" * 2048)

    result = clean_repository_before_repair(root, db, keep_old_backups=0)
    assert not (runtime / "huge.log").exists()
    assert not (reports / "old.json").exists()
    assert not old.exists()
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0] == 1
    assert result["deleted_count"] >= 3


def test_safe_vacuum_low_space_is_nonfatal(tmp_path: Path, monkeypatch) -> None:
    db = tmp_path / "kg.db"
    SQLiteKnowledgeGraph(db)

    class Usage:
        total = 1000
        used = 999
        free = 1

    monkeypatch.setattr("dell_crawler_core.repository_cleanup.shutil.disk_usage", lambda _: Usage())
    result = safe_final_vacuum(db, enabled=True)
    assert result["ok"] is True
    assert result["status"] == "skipped_low_disk_space"


def test_v622_repair_cleans_runtime_before_semantic_repair(tmp_path: Path, monkeypatch) -> None:
    # Use an isolated copied-looking project root by monkeypatching the cleanup
    # root behavior indirectly: runtime files under the real package are not
    # asserted here; DB order is proven by pre-existing runtime rows being gone
    # in the final report and the semantic collision being repaired.
    knowledge = tmp_path / "knowledge"
    knowledge.mkdir()
    db = knowledge / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    now = "2026-10-01T12:00:00+00:00"
    store.upsert_node("legacy:dell", "Brand", "Dell Technologies", {})
    store.upsert_node("brand:dell-technologies", "Brand", "Contoso", {})
    with store.connect() as conn:
        conn.execute("INSERT INTO interactions(source_url,label,observed_at) VALUES(?,?,?)", ("u", "old", now))
    result = repair(db, knowledge, force_active=True, no_backup=True, keep_old_backups=0, no_vacuum=True)
    assert result["pre_repair_database_cleanup"]["deleted"]["interactions"] == 1
    assert result["integrity_after"].casefold() == "ok"
    assert result["semantic_quality"]["clean_for_semantic_sync"] is True
    with SQLiteKnowledgeGraph(db).connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM interactions").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0] == 0


def test_repository_cleanup_preserves_browser_evidence_and_caches(tmp_path: Path) -> None:
    root = tmp_path / "repo"
    knowledge = root / "knowledge"
    knowledge.mkdir(parents=True)
    db = knowledge / "dell_en_uk.db"
    SQLiteKnowledgeGraph(db)
    protected = [
        root / "browser_profile" / "session.tmp",
        root / "evidence" / "trace.tmp",
        knowledge / "text_cache" / "chunk.tmp",
        knowledge / "vision_cache" / "image.tmp",
    ]
    for p in protected:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("keep", encoding="utf-8")
        p.touch()
    clean_repository_before_repair(root, db, keep_old_backups=0, temp_age_seconds=0)
    assert all(p.exists() for p in protected)

from __future__ import annotations

from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.semantic_consolidation import classify_and_consolidate
from repair_v620 import repair as repair_v620


def test_semantic_rekey_recovers_when_target_key_is_owned_by_different_entity(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    # Process Dell first so it attempts to claim brand:dell-technologies while a
    # stale Contoso row already owns that unique key. This reproduced the v6.20
    # UNIQUE constraint failure seen on upgraded real databases.
    store.upsert_node("legacy:dell", "Brand", "Dell Technologies", {})
    store.upsert_node("brand:dell-technologies", "Brand", "Contoso", {})

    report = classify_and_consolidate(store)
    assert report["target_key_collisions_staged"] == 1

    with store.connect() as conn:
        rows = conn.execute("SELECT node_key,name FROM nodes WHERE node_type='Brand' ORDER BY node_key").fetchall()
        temp = conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0]
    assert [(r["node_key"], r["name"]) for r in rows] == [
        ("brand:contoso", "Contoso"),
        ("brand:dell-technologies", "Dell Technologies"),
    ]
    assert temp == 0


def test_semantic_rekey_recovers_product_occupying_brand_key(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    store.upsert_node("legacy:dell", "Brand", "Dell Technologies", {})
    store.upsert_node(
        "brand:dell-technologies",
        "Product",
        "Dell Test Laptop",
        {"order_code": "ABC123", "brand": "Dell", "processor": "Intel Core Ultra 7"},
    )

    report = classify_and_consolidate(store)
    assert report["product_key_collisions_recovered"] == 1

    with store.connect() as conn:
        brand = conn.execute("SELECT node_key FROM nodes WHERE node_type='Brand'").fetchone()
        product = conn.execute("SELECT node_key FROM nodes WHERE node_type='Product'").fetchone()
    assert brand["node_key"] == "brand:dell-technologies"
    assert product["node_key"] == "product-order:abc123"


def test_v620_repair_is_restart_safe_on_collision_database(tmp_path: Path) -> None:
    db = tmp_path / "knowledge" / "kg.db"
    db.parent.mkdir(parents=True)
    store = SQLiteKnowledgeGraph(db)
    store.upsert_node("legacy:dell", "Brand", "Dell Technologies", {})
    store.upsert_node("brand:dell-technologies", "Brand", "Contoso", {})

    first = repair_v620(db, db.parent, force_active=True, no_backup=True, no_vacuum=True)
    second = repair_v620(db, db.parent, force_active=True, no_backup=True, no_vacuum=True)
    assert first["integrity_after"].casefold() == "ok"
    assert second["integrity_after"].casefold() == "ok"

    store = SQLiteKnowledgeGraph(db)
    quality = store.semantic_quality_report()
    with store.connect() as conn:
        temp = conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0]
    assert temp == 0
    assert quality["duplicate_semantic_identity_pairs"] == 0
    assert quality["clean_for_semantic_sync"] is True

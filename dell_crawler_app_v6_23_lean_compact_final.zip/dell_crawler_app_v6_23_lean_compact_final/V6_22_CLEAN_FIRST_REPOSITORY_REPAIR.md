# v6.22 — Clean Repository First, Then Repair

v6.22 changes the upgrade order after a real v6.21 repair failed during SQLite `VACUUM` with `database or disk is full`.

New order:
1. Confirm no live crawler/browser owns the repository.
2. Delete only regenerable repository/runtime debris and prune old DB backups.
3. Checkpoint the active DB WAL without deleting SQLite sidecars manually.
4. Purge irrelevant legacy/runtime DB rows **without VACUUM**.
5. Verify enough free space and create one fresh `pre_v622` backup.
6. Run v6.21 collision-safe semantic/classification repairs with nested VACUUM disabled.
7. Remove any new post-consolidation orphans.
8. VACUUM only when sufficient free disk space exists. Low-space VACUUM is skipped instead of failing the repair.
9. Run integrity, FK, semantic quality, collision, and hygiene checks.

Preserved: active DB knowledge, source/chunk/evidence data, product observations, action policy memory, browser profile, `.env`, evidence files, text/vision caches, and permanent retry-suppression queue states.

# v6.27 — Deferred Validation + Loss-Preserving Semantic Recovery

v6.27 fixes the real-world upgrade failure where `repair_v626.py` could still stop inside the historical v6.21 wrapper with:

```text
v6.21 post-repair validation failed: integrity=ok, foreign_keys=[], temporary_rekeys=0, clean_for_semantic_sync=False
```

The problem was orchestration, not SQLite corruption: `clean_for_semantic_sync` was checked at an intermediate migration stage before later cleanup/classification/convergence had a chance to finish.

## v6.27 behavior

1. Repository/database cleanup runs.
2. Historical v6.21 semantic validation is deferred when called as part of the modern migration chain.
3. Structural corruption (integrity/FK/temp re-key failures) is never deferred.
4. A loss-preserving convergence pass removes unfetched placeholder graph nodes, quarantines noncanonical nodes as extraction evidence, reclassifies/deduplicates semantic nodes, merges Product identities, repairs market/currency when evidence supports it, and quarantines ambiguous price projections rather than inventing currency.
5. Strict semantic validation runs only after convergence.
6. Missing historical PDF/vision knowledge that cannot be reconstructed offline is placed back into the live crawl queue instead of causing the migration itself to fail.

The raw extracted observations moved out of the canonical graph remain available in `extraction_evidence`; the repair does not silently discard them.

## Run

```powershell
python .\repair_v627.py --db .\knowledge\dell_en_uk.db --knowledge .\knowledge
python .\audit_knowledge_v627.py --db .\knowledge\dell_en_uk.db --knowledge .\knowledge --require-semantic-clean
python -m streamlit run .\app.py
```

After queued live recovery has finished, require full agentic-commerce readiness:

```powershell
python .\audit_knowledge_v627.py --db .\knowledge\dell_en_uk.db --knowledge .\knowledge --require-clean
```

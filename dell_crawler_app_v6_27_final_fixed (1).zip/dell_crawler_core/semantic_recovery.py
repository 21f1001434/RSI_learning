from __future__ import annotations

"""Final semantic convergence for upgraded historical crawler databases.

This module exists because older repair wrappers validated ``clean_for_semantic_sync``
*between* migration stages.  Real long-running databases can legitimately be dirty at
that midpoint (for example an unfetched historical URL node still carrying facts), and
those early checks prevented later cleanup/classification from running.

The recovery pass is deliberately loss-preserving: anything removed from the semantic
graph is first written to extraction_evidence with its facts and incident edges.
"""

import json
import sqlite3
from typing import Any

from .kg_store import SQLiteKnowledgeGraph, _loads, _json
from .market_context import infer_market_context, normalize_currency
from .semantic_consolidation import classify_and_consolidate
from .semantic_identity import GRAPH_NODE_TYPES
from .snapshot_extract import canonicalize_url


def _preserve_node(store: SQLiteKnowledgeGraph, row: sqlite3.Row, *, kind: str, reason: str) -> None:
    node_id = int(row["id"])
    with store.connect() as conn:
        facts = [dict(x) for x in conn.execute(
            "SELECT predicate,value,unit,qualifiers_json,source_url,confidence,observed_at,valid_from,valid_to "
            "FROM facts WHERE subject_id=?", (node_id,)
        ).fetchall()]
        edges = [dict(x) for x in conn.execute(
            """
            SELECT e.predicate,e.source_url,e.confidence,e.attributes_json,
                   sn.node_key AS source_key,tn.node_key AS target_key
            FROM edges e
            JOIN nodes sn ON sn.id=e.source_id
            JOIN nodes tn ON tn.id=e.target_id
            WHERE e.source_id=? OR e.target_id=?
            """, (node_id, node_id)
        ).fetchall()]
    attrs = _loads(row["attributes_json"], {})
    source_url = str(attrs.get("source_url") or attrs.get("url") or attrs.get("canonical_url") or "").strip()
    if not source_url and str(row["node_key"] or "").startswith("url:"):
        source_url = str(row["node_key"])[4:]
    store.record_extraction_evidence(
        source_url or "historical://semantic-recovery",
        {
            "node": {
                "node_key": row["node_key"],
                "node_type": row["node_type"],
                "name": row["name"],
                "attributes": attrs,
            },
            "facts": facts,
            "edges": edges,
        },
        evidence_kind=kind,
        reason=reason,
    )


def _delete_unfetched_semantic_placeholders(store: SQLiteKnowledgeGraph) -> int:
    """Remove URL graph nodes that were never fetched, preserving all evidence first.

    Older compactors retained such nodes when they had facts or semantic edges.  That
    made ``semantic_quality_report`` permanently dirty, because an unfetched page is
    not a validated semantic entity.  v6.27 keeps the information as evidence and lets
    the crawler rediscover/revisit the URL instead of sending it to Neo4j as truth.
    """
    with store.connect() as conn:
        rows = conn.execute(
            """
            SELECT n.* FROM nodes n
            WHERE n.node_key LIKE 'url:%'
              AND n.node_type IN ('Page','SupportArticle','Document')
              AND NOT EXISTS (
                    SELECT 1 FROM sources s
                    WHERE ('url:' || s.canonical_url)=n.node_key
                       OR ('url:' || s.url)=n.node_key
              )
            ORDER BY n.id
            """
        ).fetchall()
    removed = 0
    for row in rows:
        _preserve_node(
            store, row,
            kind="historical_unfetched_semantic_placeholder",
            reason="unfetched_url_node_quarantined_before_final_semantic_sync_v627",
        )
        with store.connect() as conn:
            conn.execute("DELETE FROM nodes WHERE id=?", (int(row["id"]),))
        removed += 1
    return removed


def _remove_evidence_only_graph_nodes(store: SQLiteKnowledgeGraph) -> int:
    """Quarantine evidence-only/legacy types that must never reach Neo4j."""
    placeholders = ",".join("?" for _ in GRAPH_NODE_TYPES)
    with store.connect() as conn:
        rows = conn.execute(
            f"SELECT * FROM nodes WHERE node_type NOT IN ({placeholders}) "
            "OR node_type='Concept' "
            "OR (node_type='Section' AND node_key LIKE 'document-summary:%') "
            "ORDER BY id",
            tuple(sorted(GRAPH_NODE_TYPES)),
        ).fetchall()
    removed = 0
    for row in rows:
        _preserve_node(
            store, row,
            kind="historical_noncanonical_graph_node",
            reason="noncanonical_or_evidence_only_node_quarantined_v627",
        )
        with store.connect() as conn:
            conn.execute("DELETE FROM nodes WHERE id=?", (int(row["id"]),))
        removed += 1
    return removed


def _product_source_context(store: SQLiteKnowledgeGraph, node_key: str, attrs: dict[str, Any]) -> tuple[str, str, str]:
    source = str(attrs.get("product_url") or attrs.get("url") or attrs.get("source_url") or "").strip()
    locale = str(attrs.get("locale") or "").strip()
    observed_currency = ""
    if not source or not normalize_currency(attrs.get("currency")):
        with store.connect() as conn:
            row = conn.execute(
                """
                SELECT po.source_url,po.currency,po.price FROM product_observations po
                JOIN nodes n ON n.id=po.product_id
                WHERE n.node_key=?
                ORDER BY po.observed_at DESC,po.id DESC LIMIT 1
                """, (node_key,)
            ).fetchone()
        if row:
            source = source or str(row["source_url"] or "")
            observed_currency = normalize_currency(row["currency"])
    return source, locale, observed_currency


def _repair_or_quarantine_product_currency(store: SQLiteKnowledgeGraph) -> dict[str, int]:
    """Make canonical Product price/currency pairs truthful rather than guessed.

    If currency can be inferred from URL/locale/observation, fill/correct it.  If it
    cannot be determined or an explicit non-legacy currency conflicts with the source
    market, preserve the original price payload as evidence and remove only the
    *canonical current-price projection*.  The raw extracted information is not lost
    and the product is eligible for targeted revisit.
    """
    report = {"currency_filled": 0, "legacy_currency_corrected": 0, "price_projection_quarantined": 0}
    with store.connect() as conn:
        rows = conn.execute(
            "SELECT id,node_key,name,attributes_json FROM nodes WHERE node_type='Product' ORDER BY id"
        ).fetchall()

    for row in rows:
        attrs = _loads(row["attributes_json"], {})
        price = str(attrs.get("price") or attrs.get("current_price") or "").strip()
        if not price:
            continue
        source, locale, observed_currency = _product_source_context(store, str(row["node_key"]), attrs)
        current = normalize_currency(attrs.get("currency")) or observed_currency
        context = infer_market_context(
            source,
            explicit_currency=current,
            evidence_text=price,
            fallback_locale=locale,
        )
        expected = context.currency
        changed = False
        if not normalize_currency(attrs.get("currency")) and expected:
            attrs["currency"] = expected
            report["currency_filled"] += 1
            changed = True
        elif expected and normalize_currency(attrs.get("currency")) == "GBP" and expected != "GBP":
            attrs["currency"] = expected
            report["legacy_currency_corrected"] += 1
            changed = True
        elif (not expected) or (
            normalize_currency(attrs.get("currency"))
            and expected
            and normalize_currency(attrs.get("currency")) != expected
        ):
            # Keep the exact extracted value in durable evidence, but do not expose
            # a market-ambiguous or contradictory current price as canonical truth.
            store.record_extraction_evidence(
                source or "historical://product-price",
                {
                    "product_node_key": row["node_key"],
                    "product_name": row["name"],
                    "price": attrs.get("price"),
                    "current_price": attrs.get("current_price"),
                    "list_price": attrs.get("list_price"),
                    "currency": attrs.get("currency"),
                    "market": attrs.get("market"),
                    "locale": attrs.get("locale"),
                    "source_url": source,
                },
                evidence_kind="quarantined_ambiguous_price",
                reason="currency_unresolved_or_market_conflict_v627",
            )
            for key in ("price", "current_price"):
                attrs.pop(key, None)
            # Keep list_price as historical evidence only when currency is reliable;
            # otherwise remove the canonical projection too.
            if not expected:
                attrs.pop("list_price", None)
                attrs.pop("currency", None)
            attrs["price_requires_revisit"] = True
            report["price_projection_quarantined"] += 1
            changed = True

        if changed:
            with store.connect() as conn:
                conn.execute("UPDATE nodes SET attributes_json=? WHERE id=?", (_json(attrs), int(row["id"])))
    return report


def _quality_blockers(quality: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "unfetched_placeholder_nodes",
        "evidence_only_graph_nodes",
        "legacy_summary_section_nodes",
        "duplicate_product_identity_pairs",
        "duplicate_semantic_identity_pairs",
        "unclassified_semantic_nodes",
        "currency_market_mismatches",
        "products_with_price_without_currency",
    )
    return {key: quality.get(key) for key in keys if int(quality.get(key) or 0) != 0}


def converge_semantic_graph(store: SQLiteKnowledgeGraph, *, max_passes: int = 6) -> dict[str, Any]:
    """Run loss-preserving semantic cleanup until a stable clean graph is reached."""
    # Imports are local to avoid making core startup depend on migration scripts.
    from repair_v617 import merge_duplicate_products, rebuild_node_fts
    from repair_v619 import _repair_market_currency, _stamp_classification_v619

    passes: list[dict[str, Any]] = []
    last_signature: str | None = None
    for index in range(1, max(1, int(max_passes)) + 1):
        before = store.semantic_quality_report()
        removed_unfetched = _delete_unfetched_semantic_placeholders(store)
        removed_noncanonical = _remove_evidence_only_graph_nodes(store)
        market = _repair_market_currency(store)

        def preserve(row: sqlite3.Row, kind: str, reason: str) -> None:
            _preserve_node(store, row, kind=kind, reason=reason)

        semantic = classify_and_consolidate(store, preserve_as_evidence=preserve)
        products = merge_duplicate_products(store)
        currency = _repair_or_quarantine_product_currency(store)
        stamped = _stamp_classification_v619(store)
        rebuild_node_fts(store)
        try:
            store.rebuild_chunk_fts()
        except (AttributeError, sqlite3.OperationalError):
            pass
        projection = store.backfill_product_projection()
        after = store.semantic_quality_report()
        blockers = _quality_blockers(after)
        passes.append({
            "pass": index,
            "quality_before": before,
            "removed_unfetched_placeholders": removed_unfetched,
            "removed_noncanonical_nodes": removed_noncanonical,
            "market_repair": market,
            "semantic_consolidation": semantic,
            "product_deduplication": products,
            "product_currency_recovery": currency,
            "classification_rows_stamped": stamped,
            "product_projection": projection,
            "quality_after": after,
            "blockers_after": blockers,
        })
        if bool(after.get("clean_for_semantic_sync")):
            return {"ok": True, "passes": passes, "final_quality": after, "blockers": {}}

        signature = json.dumps(blockers, sort_keys=True, default=str)
        if signature == last_signature:
            break
        last_signature = signature

    final = store.semantic_quality_report()
    return {
        "ok": bool(final.get("clean_for_semantic_sync")),
        "passes": passes,
        "final_quality": final,
        "blockers": _quality_blockers(final),
    }

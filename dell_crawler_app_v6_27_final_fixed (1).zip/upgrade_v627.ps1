param(
    [string]$Db = ".\knowledge\dell_en_uk.db",
    [string]$Knowledge = ".\knowledge",
    [string]$BackupDir = ""
)
$ErrorActionPreference = "Stop"

$repairArgs = @(".\repair_v627.py", "--db", $Db, "--knowledge", $Knowledge)
if ($BackupDir) { $repairArgs += @("--backup-dir", $BackupDir) }
python @repairArgs

# Before live recrawl, require the database/semantic graph itself to be clean.
python .\audit_knowledge_v627.py --db $Db --knowledge $Knowledge --require-semantic-clean
python .\release_verify_v627.py --db $Db
python .\export_neo4j_v626.py --db $Db --out "$Knowledge\neo4j_v627"
python -m streamlit run .\app.py

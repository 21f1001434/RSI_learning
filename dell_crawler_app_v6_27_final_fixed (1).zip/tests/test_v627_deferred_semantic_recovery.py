from __future__ import annotations

from pathlib import Path

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.semantic_recovery import converge_semantic_graph
from repair_v621 import repair as repair_v621
from repair_v622 import repair as repair_v622


def test_old_v621_midpoint_can_be_dirty_but_v622_converges_losslessly(tmp_path: Path) -> None:
    db = tmp_path / "knowledge" / "kg.db"
    db.parent.mkdir(parents=True)
    store = SQLiteKnowledgeGraph(db)
    ghost = "https://www.dell.com/en-us/support/kbdoc/ghost"
    store.upsert_node("url:" + ghost, "SupportArticle", "Historical support placeholder", {"source_url": ghost})
    store.add_fact("url:" + ghost, "SUMMARY", "Useful historical support fact", source_url=ghost)
    assert store.semantic_quality_report()["clean_for_semantic_sync"] is False

    # This reproduces the user's observed failure mode: v6.21 validates too early.
    try:
        repair_v621(db, db.parent, force_active=True, no_backup=True, no_vacuum=True)
    except SystemExit as exc:
        assert "clean_for_semantic_sync=False" in str(exc)
    else:
        raise AssertionError("v6.21 strict midpoint should reject this historical placeholder")

    # The v6.27-patched v6.22 orchestration defers the midpoint semantic check,
    # preserves the node/fact as evidence, then converges and validates at the end.
    result = repair_v622(
        db, db.parent, force_active=True, no_backup=True,
        keep_old_backups=0, keep_crawl_runs=1, keep_old_runtime_data=False, no_vacuum=True,
    )
    assert result["semantic_quality"]["clean_for_semantic_sync"] is True
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        placeholder = conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key=?", ("url:" + ghost,)).fetchone()[0]
        evidence = conn.execute(
            "SELECT COUNT(*) FROM extraction_evidence WHERE evidence_kind='historical_unfetched_semantic_placeholder'"
        ).fetchone()[0]
    assert placeholder == 0
    assert evidence >= 1


def test_unresolved_product_currency_is_preserved_as_evidence_not_false_graph_truth(tmp_path: Path) -> None:
    db = tmp_path / "kg.db"
    store = SQLiteKnowledgeGraph(db)
    store.upsert_node(
        "product-order:test123", "Product", "Historical product",
        {"order_code": "TEST123", "price": "1999.00", "brand": "Dell"},
    )
    assert store.semantic_quality_report()["products_with_price_without_currency"] == 1
    result = converge_semantic_graph(store)
    assert result["ok"] is True
    node = store.node_by_key("product-order:test123")
    assert node is not None
    assert not node["attributes"].get("price")
    assert node["attributes"].get("price_requires_revisit") is True
    with store.connect() as conn:
        evidence = conn.execute(
            "SELECT COUNT(*) FROM extraction_evidence WHERE evidence_kind='quarantined_ambiguous_price'"
        ).fetchone()[0]
    assert evidence == 1


def test_v627_full_repair_does_not_abort_at_v621_midpoint(tmp_path: Path) -> None:
    from repair_v627 import repair as repair_v627

    db = tmp_path / "knowledge" / "kg.db"
    db.parent.mkdir(parents=True)
    store = SQLiteKnowledgeGraph(db)
    ghost = "https://www.dell.com/en-us/support/kbdoc/full-chain-ghost"
    store.upsert_node("url:" + ghost, "SupportArticle", "Full chain ghost", {"source_url": ghost})
    store.add_fact("url:" + ghost, "SUMMARY", "Preserve this fact", source_url=ghost)

    result = repair_v627(db, db.parent, force_active=True, no_backup=True)
    assert result["clean_for_semantic_sync"] is True
    assert result["integrity_after"].casefold() == "ok"
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key=?", ("url:" + ghost,)).fetchone()[0] == 0
        assert conn.execute(
            "SELECT COUNT(*) FROM extraction_evidence WHERE evidence_kind='historical_unfetched_semantic_placeholder'"
        ).fetchone()[0] >= 1

from __future__ import annotations

import argparse
import json
from pathlib import Path

from audit_knowledge_v626 import build_report as build_v626_report
from dell_crawler_core.kg_store import SQLiteKnowledgeGraph


def build_report(db: Path, knowledge: Path) -> dict:
    report = build_v626_report(db, knowledge)
    store = SQLiteKnowledgeGraph(db)
    with store.connect() as conn:
        temp = int(conn.execute("SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'").fetchone()[0])
        pending_recovery = int(conn.execute(
            "SELECT COUNT(*) FROM crawl_queue WHERE status='PENDING' AND relation='V627_RICH_KNOWLEDGE_RECOVERY'"
        ).fetchone()[0])
    report["v627_recovery"] = {
        "temporary_rekeys": temp,
        "pending_rich_knowledge_recovery": pending_recovery,
        "semantic_clean": bool(report["semantic_quality"].get("clean_for_semantic_sync")),
        "structurally_ready": report["integrity_check"].casefold() == "ok" and not report["foreign_key_violations"] and temp == 0,
        "fully_ready_after_live_recovery": bool(report["agentic_commerce_graph"].get("agentic_commerce_ready")),
    }
    return report


def main() -> int:
    p = argparse.ArgumentParser(description="Audit Dell Crawler v6.27 repaired knowledge database.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--knowledge", default="knowledge")
    p.add_argument("--output", default="")
    p.add_argument("--require-clean", action="store_true", help="Require full agentic-commerce readiness; run after queued live recovery completes.")
    p.add_argument("--require-semantic-clean", action="store_true", help="Require structural + semantic cleanliness but allow queued PDF/vision recovery.")
    a = p.parse_args()
    db = Path(a.db).expanduser().resolve(); knowledge = Path(a.knowledge).expanduser().resolve()
    if not db.exists(): raise SystemExit(f"Database not found: {db}")
    report = build_report(db, knowledge)
    text = json.dumps(report, indent=2, ensure_ascii=False, default=str); print(text)
    if a.output: Path(a.output).expanduser().write_text(text, encoding="utf-8")
    if a.require_semantic_clean:
        ok = report["v627_recovery"]["structurally_ready"] and report["v627_recovery"]["semantic_clean"]
        return 0 if ok else 2
    if a.require_clean:
        ok = report["v627_recovery"]["structurally_ready"] and report["v627_recovery"]["semantic_clean"] and report["v627_recovery"]["fully_ready_after_live_recovery"]
        return 0 if ok else 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

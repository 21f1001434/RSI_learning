from __future__ import annotations

"""v6.26 upgrade: lossless multimodal + agentic-commerce graph classification."""

import argparse
import json
import gzip
from pathlib import Path
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.semantic_recovery import converge_semantic_graph
from dell_crawler_core.single_drive_compaction import drop_rebuildable_fts, create_compressed_logical_backup
from repair_v610 import stamp
from repair_v625 import repair as repair_v625


def _backup_v626(db: Path, backup_dir: Path) -> dict[str, Any]:
    backup_dir.mkdir(parents=True, exist_ok=True)
    target = backup_dir / f"{db.stem}.pre_v626_{stamp()}.sql.gz"
    drop_rebuildable_fts(db)
    result = create_compressed_logical_backup(db, target)
    SQLiteKnowledgeGraph(db)  # rebuild external-content FTS
    if not result.get("ok"):
        raise SystemExit(f"Could not create v6.26 safety backup: {result}")
    return result


def _infer_source_from_payload(payload: Any, fallback: str) -> str:
    if isinstance(payload, dict):
        candidates = [payload.get("source_url"), payload.get("url")]
        evidence = payload.get("evidence") if isinstance(payload.get("evidence"), dict) else {}
        candidates.extend([evidence.get("source_url"), evidence.get("url")])
        page = payload.get("page") if isinstance(payload.get("page"), dict) else {}
        candidates.append(page.get("url"))
        for entity in payload.get("entities") or []:
            if isinstance(entity, dict):
                attrs = entity.get("attributes") if isinstance(entity.get("attributes"), dict) else {}
                candidates.extend([entity.get("source_url"), attrs.get("source_url")])
        for value in candidates:
            text = str(value or "").strip()
            if text.startswith(("http://", "https://")):
                return text
    return fallback


def _stage_legacy_multimodal_and_interaction_evidence(db: Path, knowledge: Path, backup_dir: Path) -> dict[str, Any]:
    """Stage cache/runtime knowledge before v6.25 removes regenerable/runtime rows.

    The archive is compressed and source-addressable, so a C:-only machine can
    preserve exact visual extraction JSON and UI interaction outcomes without
    keeping multi-GB screenshots/browser caches.
    """
    backup_dir.mkdir(parents=True, exist_ok=True)
    target = backup_dir / f"{db.stem}.pre_v626_multimodal_{stamp()}.jsonl.gz"
    count = 0
    with gzip.open(target, "wt", encoding="utf-8") as handle:
        vision_dir = knowledge / "vision_cache"
        if vision_dir.exists():
            for path in vision_dir.rglob("*.json"):
                try:
                    payload = json.loads(path.read_text(encoding="utf-8"))
                except Exception:
                    continue
                source = _infer_source_from_payload(payload, f"legacy-cache://vision/{path.name}")
                handle.write(json.dumps({"source_url": source, "evidence_kind": "legacy_vision_cache", "reason": "preserved_before_cache_cleanup", "payload": payload}, ensure_ascii=False, default=str) + "\n")
                count += 1
        store = SQLiteKnowledgeGraph(db)
        with store.connect() as conn:
            for table, kind in (("interactions", "interaction_history_compacted"), ("control_progress", "control_progress_compacted")):
                try:
                    rows = conn.execute(f"SELECT * FROM {table} ORDER BY source_url").fetchall()
                except Exception:
                    rows = []
                grouped: dict[str, list[dict[str, Any]]] = {}
                for row in rows:
                    item = dict(row)
                    source = str(item.get("source_url") or "runtime://unknown")
                    grouped.setdefault(source, []).append(item)
                for source, items in grouped.items():
                    handle.write(json.dumps({"source_url": source, "evidence_kind": kind, "reason": "knowledge_compacted_before_runtime_cleanup", "payload": items}, ensure_ascii=False, default=str) + "\n")
                    count += 1
    return {"path": str(target), "records": count, "bytes": target.stat().st_size if target.exists() else 0}


def _restore_staged_evidence(store: SQLiteKnowledgeGraph, stage: dict[str, Any]) -> int:
    path = Path(str(stage.get("path") or ""))
    if not path.is_file():
        return 0
    created = 0
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except Exception:
                continue
            created += int(store.record_extraction_evidence(
                str(row.get("source_url") or "legacy://unknown"), row.get("payload"),
                evidence_kind=str(row.get("evidence_kind") or "legacy_evidence"),
                reason=str(row.get("reason") or "v6.26 staged evidence restore"),
            ))
    return created


def _backfill_commerce_and_legacy_vision(store: SQLiteKnowledgeGraph) -> dict[str, int]:
    commerce_products = 0
    commerce_ingests = 0
    legacy_vision_rows = 0
    with store.connect() as conn:
        products = conn.execute("SELECT node_key,name,attributes_json FROM nodes WHERE node_type='Product'").fetchall()
        legacy_vision = conn.execute(
            """
            SELECT s.url, GROUP_CONCAT(c.text, '\n\n') AS vision_text
            FROM sources s JOIN chunks c ON c.source_url=s.url
            WHERE CAST(COALESCE(json_extract(s.metadata_json,'$.vision_evidence_count'),0) AS INTEGER)>0
              AND c.text LIKE '%DELL AIA VISION EVIDENCE%'
            GROUP BY s.url
            """
        ).fetchall()
    for row in products:
        attrs = json.loads(row["attributes_json"] or "{}")
        source_url = str(attrs.get("source_url") or attrs.get("product_url") or "").strip()
        if not source_url:
            with store.connect() as conn:
                obs = conn.execute(
                    "SELECT source_url FROM product_observations WHERE product_node_key=? ORDER BY observed_at DESC LIMIT 1",
                    (row["node_key"],),
                ).fetchone()
            source_url = str(obs[0] or "") if obs else ""
        if not source_url:
            continue
        payload: dict[str, Any] = {"page": {}, "entities": [], "relations": [], "facts": [], "unmapped_evidence": []}
        key = str(row["node_key"])
        warranty = str(attrs.get("warranty") or "").strip()
        financing = str(attrs.get("financing") or "").strip()
        rewards = str(attrs.get("rewards") or "").strip()
        delivery = str(attrs.get("shipping") or attrs.get("delivery") or "").strip()
        if warranty:
            payload["warranties"] = [{"name": warranty, "coverage": warranty, "product_key": key, "source_url": source_url}]
        if financing:
            payload["financing_options"] = [{"name": financing[:500], "financing": financing, "product_key": key, "source_url": source_url}]
        if rewards:
            payload["reward_programs"] = [{"name": "Dell Rewards", "reward": rewards, "product_key": key, "source_url": source_url}]
        if delivery:
            payload["delivery_options"] = [{"name": "Dell delivery", "delivery": delivery, "product_key": key, "source_url": source_url}]
        if any(payload.get(k) for k in ("warranties", "financing_options", "reward_programs", "delivery_options")):
            commerce_products += 1
            result = store.ingest_extraction(source_url, payload)
            commerce_ingests += sum(int(result.get(k, 0)) for k in ("nodes_created", "edges_created", "facts_created"))
    for row in legacy_vision:
        text = str(row["vision_text"] or "").strip()
        if text:
            legacy_vision_rows += int(store.record_extraction_evidence(
                str(row["url"]), {"vision_text": text}, evidence_kind="legacy_vision_text",
                reason="backfilled_from_lossless_search_chunks_for_agentic_retrieval",
            ))
    return {
        "products_with_commerce_backfill": commerce_products,
        "commerce_graph_records_added": commerce_ingests,
        "legacy_vision_evidence_rows_added": legacy_vision_rows,
    }


def repair(db: Path, knowledge: Path, *, force_active: bool = False, no_backup: bool = False, backup_dir: Path | None = None) -> dict[str, Any]:
    db = db.resolve()
    knowledge = knowledge.resolve()
    backup_dir = (backup_dir or (knowledge / "backups")).resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    staged_evidence = _stage_legacy_multimodal_and_interaction_evidence(db, knowledge, backup_dir)
    backup: dict[str, Any] = {"status": "disabled"}
    if not no_backup:
        backup = _backup_v626(db, backup_dir)
    base = repair_v625(db, knowledge, force_active=force_active, no_backup=True, backup_dir=backup_dir)
    store = SQLiteKnowledgeGraph(db)
    staged_rows_restored = _restore_staged_evidence(store, staged_evidence)
    backfill = _backfill_commerce_and_legacy_vision(store)
    # Commerce/multimodal backfill can surface historical aliases on very old
    # databases. Run one final loss-preserving convergence pass before strict
    # validation; do not abort at an intermediate v6.21-era dirty state.
    semantic_convergence = converge_semantic_graph(store, max_passes=6)
    quality = store.semantic_quality_report()
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
        commerce_nodes = int(conn.execute("SELECT COUNT(*) FROM nodes WHERE node_type IN ('Warranty','FinancingOption','RewardProgram','DeliveryOption')").fetchone()[0])
        vision_evidence = int(conn.execute("SELECT COUNT(*) FROM extraction_evidence WHERE evidence_kind IN ('vision_bundle','vision_text','legacy_vision_text')").fetchone()[0])
    if integrity.casefold() != "ok" or fk or not bool(quality.get("clean_for_semantic_sync")):
        raise SystemExit(f"v6.26 validation failed: integrity={integrity}, foreign_keys={fk[:10]}, clean={quality.get('clean_for_semantic_sync')}")
    report = {
        "migration": "v6.x -> v6.26 lossless multimodal agentic-commerce knowledge graph",
        "database": str(db), "backup": backup, "staged_legacy_evidence": staged_evidence,
        "staged_evidence_rows_restored": staged_rows_restored, "v625_base": base, "backfill": backfill,
        "semantic_convergence_v627": semantic_convergence,
        "commerce_nodes": commerce_nodes, "persisted_multimodal_evidence_rows": vision_evidence,
        "semantic_quality": quality, "integrity_after": integrity, "foreign_key_violations": fk,
    }
    out = knowledge / "DATABASE_REPAIR_V626.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    return report


def main() -> int:
    p = argparse.ArgumentParser(description="Upgrade Dell crawler DB to v6.26 agentic-commerce + lossless multimodal graph.")
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--knowledge", default="knowledge")
    p.add_argument("--backup-dir", default="")
    p.add_argument("--force-active", action="store_true")
    p.add_argument("--no-backup", action="store_true")
    a = p.parse_args()
    result = repair(Path(a.db), Path(a.knowledge), force_active=a.force_active, no_backup=a.no_backup, backup_dir=Path(a.backup_dir) if a.backup_dir else None)
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

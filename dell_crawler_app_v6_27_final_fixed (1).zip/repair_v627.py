from __future__ import annotations

"""v6.27 final repair orchestration.

Key change: semantic cleanliness is validated only after every migration/convergence
stage has completed. Historical databases with a recoverable dirty midpoint no longer
abort in the v6.21 wrapper before v6.22-v6.26 cleanup can run.
"""

import argparse
import json
from pathlib import Path
from typing import Any

from dell_crawler_core.kg_store import SQLiteKnowledgeGraph
from dell_crawler_core.semantic_recovery import converge_semantic_graph
from dell_crawler_core.single_drive_compaction import drop_rebuildable_fts, create_compressed_logical_backup
from repair_v610 import now, stamp
from repair_v626 import repair as repair_v626


def _backup_v627(db: Path, backup_dir: Path) -> dict[str, Any]:
    backup_dir.mkdir(parents=True, exist_ok=True)
    target = backup_dir / f"{db.stem}.pre_v627_{stamp()}.sql.gz"
    drop_rebuildable_fts(db)
    result = create_compressed_logical_backup(db, target)
    SQLiteKnowledgeGraph(db)  # rebuild FTS/triggers after the logical dump
    if not result.get("ok"):
        raise SystemExit(f"Could not create v6.27 safety backup: {result}")
    return result


def _schedule_missing_rich_evidence(store: SQLiteKnowledgeGraph) -> dict[str, Any]:
    """Queue recoverable rich-knowledge gaps instead of failing migration.

    A historical source that was marked HTTP-successful but has no persisted PDF text
    or lost its old vision cache cannot be reconstructed offline. The correct repair is
    to keep the semantic DB valid and put that source back into the live crawler queue.
    """
    with store.connect() as conn:
        pdf_rows = conn.execute(
            """
            SELECT s.url FROM sources s
            WHERE (LOWER(s.mime_type) LIKE '%pdf%' OR LOWER(s.url) LIKE '%.pdf%')
              AND COALESCE(s.http_status,200) BETWEEN 200 AND 299
              AND NOT EXISTS (SELECT 1 FROM chunks c WHERE c.source_url=s.url AND LENGTH(TRIM(c.text))>0)
              AND NOT EXISTS (
                    SELECT 1 FROM extraction_evidence e
                    WHERE e.source_url=s.url
                      AND e.evidence_kind IN ('vision_bundle','vision_text','legacy_vision_text','legacy_vision_cache')
              )
            """
        ).fetchall()
        vision_rows = conn.execute(
            """
            SELECT s.url FROM sources s
            WHERE CAST(COALESCE(json_extract(s.metadata_json,'$.vision_evidence_count'),0) AS INTEGER)>0
              AND NOT EXISTS (
                    SELECT 1 FROM extraction_evidence e
                    WHERE e.source_url=s.url
                      AND e.evidence_kind IN ('vision_bundle','vision_text','legacy_vision_text','legacy_vision_cache')
              )
              AND NOT EXISTS (
                    SELECT 1 FROM chunks c
                    WHERE c.source_url=s.url AND c.text LIKE '%DELL AIA VISION EVIDENCE%'
              )
            """
        ).fetchall()

    pdf_urls = [str(r[0]) for r in pdf_rows if str(r[0] or '').strip()]
    vision_urls = [str(r[0]) for r in vision_rows if str(r[0] or '').strip()]
    queued = 0
    for url in dict.fromkeys([*pdf_urls, *vision_urls]):
        queued += int(store.enqueue(
            url,
            depth=0,
            priority=0,
            relation="V627_RICH_KNOWLEDGE_RECOVERY",
            force=True,
        ))
    return {
        "pdf_knowledge_gaps": len(pdf_urls),
        "multimodal_evidence_gaps": len(vision_urls),
        "unique_recovery_urls": len(set([*pdf_urls, *vision_urls])),
        "queued": queued,
    }


def repair(
    db: Path,
    knowledge: Path,
    *,
    force_active: bool = False,
    no_backup: bool = False,
    backup_dir: Path | None = None,
) -> dict[str, Any]:
    db = db.expanduser().resolve()
    knowledge = knowledge.expanduser().resolve()
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    knowledge.mkdir(parents=True, exist_ok=True)
    backup_dir = (backup_dir or (knowledge / "backups")).expanduser().resolve()

    backup: dict[str, Any] = {"status": "disabled"}
    if not no_backup:
        backup = _backup_v627(db, backup_dir)

    # Run the complete v6.26 lossless/multimodal/commerce migration with its nested
    # backup suppressed. v6.22 inside this chain now defers the old v6.21 semantic
    # check and performs final convergence before enforcing strict cleanliness.
    base = repair_v626(
        db,
        knowledge,
        force_active=force_active,
        no_backup=True,
        backup_dir=backup_dir,
    )

    store = SQLiteKnowledgeGraph(db)
    final_convergence = converge_semantic_graph(store, max_passes=8)
    recovery_queue = _schedule_missing_rich_evidence(store)

    quality = store.semantic_quality_report()
    with store.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        fk = [tuple(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
        temp_rekeys = int(conn.execute(
            "SELECT COUNT(*) FROM nodes WHERE node_key LIKE '__semantic_rekey_v621__:%'"
        ).fetchone()[0])
        pending = int(conn.execute("SELECT COUNT(*) FROM crawl_queue WHERE status='PENDING'").fetchone()[0])

    if integrity.casefold() != "ok" or fk or temp_rekeys:
        raise SystemExit(
            "v6.27 structural validation failed: "
            f"integrity={integrity}, foreign_keys={fk[:10]}, temporary_rekeys={temp_rekeys}"
        )
    if not bool(quality.get("clean_for_semantic_sync")):
        raise SystemExit(
            "v6.27 semantic convergence could not complete. "
            f"Remaining blockers={final_convergence.get('blockers')}. "
            "No extracted evidence was discarded; inspect DATABASE_REPAIR_V627.json."
        )

    report = {
        "migration": "v6.x -> v6.27 final deferred-validation semantic recovery",
        "database": str(db),
        "backup": backup,
        "v626_base": base,
        "final_semantic_convergence": final_convergence,
        "rich_knowledge_recovery_queue": recovery_queue,
        "pending_queue_rows_after_repair": pending,
        "integrity_after": integrity,
        "foreign_key_violations": fk,
        "temporary_semantic_rekeys_remaining": temp_rekeys,
        "semantic_quality": quality,
        "clean_for_semantic_sync": bool(quality.get("clean_for_semantic_sync")),
        "live_recrawl_required_for_missing_rich_evidence": bool(recovery_queue["unique_recovery_urls"]),
        "finished_at": now(),
    }
    out = knowledge / "DATABASE_REPAIR_V627.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report["report_path"] = str(out)
    return report


def main() -> int:
    p = argparse.ArgumentParser(
        description="Dell Crawler v6.27: complete migration first, then enforce strict semantic cleanliness."
    )
    p.add_argument("--db", default="knowledge/dell_en_uk.db")
    p.add_argument("--knowledge", default="knowledge")
    p.add_argument("--backup-dir", default="")
    p.add_argument("--force-active", action="store_true")
    p.add_argument("--no-backup", action="store_true")
    a = p.parse_args()
    result = repair(
        Path(a.db), Path(a.knowledge),
        force_active=a.force_active,
        no_backup=a.no_backup,
        backup_dir=Path(a.backup_dir) if a.backup_dir else None,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

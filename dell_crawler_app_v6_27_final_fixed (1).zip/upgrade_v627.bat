@echo off
python repair_v627.py --db knowledge\dell_en_uk.db --knowledge knowledge || exit /b 1
python audit_knowledge_v627.py --db knowledge\dell_en_uk.db --knowledge knowledge --require-semantic-clean || exit /b 1
python release_verify_v627.py --db knowledge\dell_en_uk.db || exit /b 1
python export_neo4j_v626.py --db knowledge\dell_en_uk.db --out knowledge\neo4j_v627 || exit /b 1
python -m streamlit run app.py

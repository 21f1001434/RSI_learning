param(
    [string]$Environment = "g4",
    [switch]$SkipRuntimeVerification
)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "Redirecting to the current RUS v11.62.7 launcher..." -ForegroundColor Yellow
& (Join-Path $root "Start-RUS-v11_62_7.ps1") -Environment $Environment -SkipRuntimeVerification:$SkipRuntimeVerification
exit $LASTEXITCODE

param([int]$Port = 8088, [int]$DellUtilityPort = 49690)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:API_HOST = "127.0.0.1"
$env:API_PORT = "$Port"
$env:API_REQUIRE_INTERNAL_KEY = "false"
$env:API_INTERNAL_KEY = ""
$env:SOURCE_WRITE_MODE = "live"
$env:UTILITY_SERVICE_BASE_URL = "http://127.0.0.1:$DellUtilityPort"
$env:UTILITY_SERVICE_INTERNAL_KEY = ""
Set-Location (Join-Path $Root "AgenticDataDisparity.API")
Write-Host "Manual v11.62.7 Agent API mode: loopback-only Dell Utility bridge at $env:UTILITY_SERVICE_BASE_URL" -ForegroundColor Cyan
& ".\scripts\run_api.ps1"

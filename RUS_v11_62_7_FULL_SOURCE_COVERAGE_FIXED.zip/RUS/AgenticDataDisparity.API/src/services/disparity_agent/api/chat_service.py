from __future__ import annotations

import asyncio
import json
import re
from typing import Any

from ..batch import build_batch_insights
from ..models import SearchType, SourceName
from ..identifier_input import IdentifierMatch, extract_identifiers, remember_identifier, remember_identity_bundle, resolve_identifier
from ..connectors.cps import CPSConnector
from ..settings import Settings
from ..memory import get_adaptive_memory
from .batch_jobs import BatchJobManager, BatchJobNotFound
from .config import ApiSettings
from .run_store import RunStore
from .schemas import ChatAction, ChatContext, ChatRequest, ChatResponse, SourceSystem
from .session_store import InMemorySessionStore, SessionNotFound, SessionState
from .source_operations import AGENTIC_WRITABLE_SOURCES, WRITE_FIELDS, SourceOperationError, SourceOperationService


CHAT_SYSTEM = """You are RUS, the Dell Rewards Agentic Data Disparity chat assistant.
Use only the supplied session history and deterministic evidence. The evidence may describe one member or a completed bulk analysis.
Do not call external APIs and do not invent values, users, counts, corrections, or source status.
For individual evidence, source status, attribute verdicts, suggestions, identifier-resolution diagnostics and truth policy are authoritative.
Default attribute truth is CPS with Rewards DB fallback only when CPS lacks that attribute. Business exceptions are authoritative: CrowdTwist ID comes from CrowdTwist and corrects Rewards DB; Active Status uses OR across Rewards DB and CrowdTwist; Country follows CPS whenever CPS supplies country evidence, with Rewards DB used only for approved disambiguation/fallback.
For bulk evidence, authoritative_group_summary, population_metrics, processing, totals, source_member_record_metrics,
attribute counts, member rows, Judge outcomes and timings are authoritative. Never describe attribute-level item counts as user counts.
When asked what to change, use exact target systems and values already present in evidence. Never convert manual review into an executable correction.
Explain in clear business language. For source-system read requests, the deterministic Source Operation service may run CPS, Rewards DB, or CrowdTwist APIs.
For update requests, first run or use the deterministic cross-source analysis, keep CPS read-only in Agentic AI, honor each suggestion's exact truth_source/business rule, and derive corrections only for Rewards DB or CrowdTwist. Never claim that data changed unless the deterministic Source Operation service reports a verified live write.
Agentic execution is role-aware. Customer Support, Business, Technical and Admin may all execute supported Rewards DB/CrowdTwist corrections after their profile-governed approvals. An initial update instruction such as "update Country as suggested" or "change Country to the correct value" creates an exact grounded plan and does not itself bypass approval. Business requires one chat approval of that reviewed plan. Customer Support, Technical and Admin require chat approval followed by the final-review popup. Never treat a second chat command as popup approval. Mention live, dry-run, blocked, drift-aborted, or verified status exactly as supplied.
Return concise Markdown using short headings, bullet lists, and bold labels. Do not use Markdown tables or fenced code blocks. Keep the response focused and actionable.
"""

CHAT_JUDGE_SYSTEM = """You are an independent Dell Rewards chat-response judge.
Compare the proposed chatbot response with the supplied deterministic individual or bulk evidence and the session question.
Reject unsupported facts, wrong truth source, wrong identifier-resolution path, wrong target system, invented values, unsafe corrections, stale pre-write suggestions after a live mutation, and any conversion of attribute-item counts into user counts.
Return one JSON object with keys verdict, corrected_response, unsupported_claims, confidence. corrected_response may contain concise Markdown headings and bullets, but the outer response must be JSON only.
"""

EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b")
GUID_RE = re.compile(r"(?i)\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b")
CT_ID_RE = re.compile(r"\b\d{6,20}\b")
BATCH_TERMS = (
    "batch",
    "bulk",
    "group analysis",
    "grouped analysis",
    "uploaded file",
    "all users",
    "all members",
    "email list",
    "portfolio",
    "overall analysis",
)
BATCH_ACTIONS = {
    ChatAction.BATCH_STATUS,
    ChatAction.BATCH_SUMMARY,
    ChatAction.BATCH_FINDINGS,
    ChatAction.BATCH_STATISTICS,
    ChatAction.BATCH_MAJORITY_ISSUE,
    ChatAction.BATCH_SOURCE_COVERAGE,
    ChatAction.BATCH_JUDGE_OUTCOMES,
    ChatAction.BATCH_TIMING,
    ChatAction.BATCH_REPORT_LINKS,
}
INDIVIDUAL_ACTIONS = {
    ChatAction.SUMMARY,
    ChatAction.SUGGESTIONS,
    ChatAction.SOURCE_HEALTH,
    ChatAction.SOURCE_CPS,
    ChatAction.TIMING,
    ChatAction.REPORT_LINKS,
}


class ChatService:
    def __init__(
        self,
        *,
        settings: Settings,
        api_settings: ApiSettings,
        sessions: InMemorySessionStore,
        runs: RunStore,
        ai_semaphore: asyncio.Semaphore,
        batch_jobs: BatchJobManager | None = None,
        source_operations: SourceOperationService | None = None,
    ) -> None:
        self.settings = settings
        self.api_settings = api_settings
        self.sessions = sessions
        self.runs = runs
        self.ai_semaphore = ai_semaphore
        self.batch_jobs = batch_jobs
        self.source_operations = source_operations
        self.adaptive_memory = get_adaptive_memory(settings)

    async def handle(self, request: ChatRequest, base_url: str) -> ChatResponse:
        state = await self.sessions.get(request.session_id)
        if request.actor:
            state.metadata["actor"] = request.actor.strip()
        if request.actor_email:
            state.metadata["actor_email"] = request.actor_email.strip()
        if request.actor_role:
            state.metadata["actor_role"] = request.actor_role.strip()
        if request.actor_dry_run_enabled is not None:
            # The authenticated .NET user profile is authoritative. Admin is
            # always governed live even if a malformed client requests dry run.
            normalized_role = str(state.metadata.get("actor_role") or "").strip().casefold()
            state.metadata["actor_dry_run_enabled"] = False if normalized_role in {"admin", "administrator"} else bool(request.actor_dry_run_enabled)
            state.metadata["effective_write_mode"] = "dry_run" if state.metadata["actor_dry_run_enabled"] else "live"
        await self.sessions.append(
            request.session_id,
            role="user",
            content=request.message,
            metadata={"requested_action": request.action.value, "requested_context": request.context.value},
        )

        explicit_identifiers = extract_identifiers(request.message)
        resolved_identifier = resolve_identifier(request.message, state.facts)
        if explicit_identifiers:
            remember_identifier(state.facts, resolved_identifier or explicit_identifiers[0])

        # Resolve the natural-language intent before source routing. A request
        # that explicitly asks for a complete analysis must not be intercepted
        # by a narrower "run CPS" phrase in the same message. Pending approvals
        # and write requests still take precedence and remain fail-closed.
        action, search_type, search_value = self._resolve_intent(request, state)
        source_first = action != ChatAction.ANALYZE
        if self.source_operations is not None:
            source_first = source_first or bool(state.facts.get("active_source_change_id"))
            source_first = source_first or self.source_operations.is_write_request(request.message)

        if self.source_operations is not None and source_first:
            try:
                source_result = await self.source_operations.handle_chat(
                    session_id=request.session_id, message=request.message, state=state
                )
            except SourceOperationError as exc:
                await self.source_operations.audit_agentic_activity(
                    "SOURCE_OPERATION_FAILED",
                    {
                        "session_id": request.session_id,
                        "actor": state.metadata.get("actor") or "Unknown user",
                        "actor_email": state.metadata.get("actor_email"),
                        "source": "Agentic AI",
                        "action": "Agentic source operation",
                        "status": "FAILED",
                        "target": (resolved_identifier.label + ": " + resolved_identifier.value) if resolved_identifier else None,
                        "reason": str(exc),
                        "verification": exc.code,
                        "details": {"code": exc.code, "details": exc.details},
                    },
                )
                reply = f"## Source operation blocked\n{exc}"
                assistant = await self.sessions.append(
                    request.session_id, role="assistant", content=reply,
                    metadata={"intent": "source_operation_error", "code": exc.code},
                )
                return self._response(
                    request.session_id, assistant.message_id, reply, "source_operation_error",
                    state.active_run_id, state.active_batch_id, base_url,
                    structured_data={"code": exc.code, "details": exc.details},
                    active_context=state.active_context,
                )
            if source_result is not None:
                intent, reply, structured = source_result

                # v11.62: explicit write instructions never bypass the authenticated
                # profile's approval policy. SourceOperationService converts active
                # imperatives/yes into approval 1 and returns either a Business
                # execution result or a final-popup requirement for the other roles.

                if intent == "spreadsheet_updates_executed":
                    spreadsheet = (structured or {}).get("spreadsheet_update") or {}
                    refreshed_emails: set[str] = set()
                    post_write_analyses: list[dict[str, Any]] = []
                    for completed in spreadsheet.get("completed_changes") or []:
                        status_value = str(completed.get("status") or "").upper()
                        if status_value not in {"COMPLETED", "PARTIAL"}:
                            continue
                        await self._record_adaptive_write_outcome(state, completed)
                        target_email = str(((completed.get("targets") or [{}])[0]).get("email") or "").strip()
                        if not target_email or target_email.casefold() in refreshed_emails:
                            continue
                        refreshed_emails.add(target_email.casefold())
                        refreshed = await self.refresh_after_source_change(request.session_id, completed)
                        if refreshed is not None:
                            post_write_analyses.append(self._post_write_analysis_summary(refreshed))
                    spreadsheet["post_write_analyses"] = post_write_analyses
                    if structured is not None:
                        structured["spreadsheet_update"] = spreadsheet

                # A completed live/partial source update must never leave the
                # session pointing at the pre-write disparity report. Re-run the
                # same member after read-after-write verification and make that
                # fresh evidence the active report. The write result remains
                # authoritative even if the follow-up analysis is temporarily
                # unavailable.
                if intent == "source_confirm_2":
                    change = (structured or {}).get("change") or {}
                    await self._record_adaptive_write_outcome(state, change)
                    refreshed = await self.refresh_after_source_change(request.session_id, change)
                    if refreshed is not None:
                        change["post_write_analysis"] = self._post_write_analysis_summary(refreshed)
                        structured["change"] = change
                        reply += (
                            "\n\n### Post-write cross-source verification\n"
                            f"Fresh run `{refreshed.get('run_id')}` is now active. "
                            f"Remaining mismatches: {refreshed.get('mismatch_count', 0)}; "
                            f"missing records: {refreshed.get('missing_record_count', 0)}."
                        )

                # ``do the changes to <identifier>`` is an update command, not
                # an analysis command.  When no matching report is active, run
                # the target analysis internally, keep it in session memory,
                # and immediately convert the eligible recommendation into the
                # governed source-change preview.  The user therefore receives
                # the approval plan rather than a misleading analysis response.
                if intent == "source_change_analysis_required":
                    identifier_data = dict(structured.get("identifier") or {})
                    try:
                        requested_search_type = SearchType(str(identifier_data.get("search_type") or ""))
                    except ValueError:
                        requested_search_type = None
                    requested_value = str(identifier_data.get("value") or "").strip()
                    if requested_search_type is None or not requested_value:
                        reply = "## Unable to prepare the change\nProvide a valid email, Profile ID, or CrowdTwist ID."
                        intent = "source_change_needs_identifier"
                        structured = {"code": "SOURCE_CHANGE_IDENTIFIER_REQUIRED"}
                    else:
                        report = await self._run_analysis_for_session(
                            session_id=request.session_id,
                            state=state,
                            search_type=requested_search_type,
                            search_value=requested_value,
                            audit_action="Cross-source analysis for governed source change",
                        )
                        # Re-route the *original* command now that the fresh
                        # report is active.  This deliberately reuses the same
                        # field/source/value resolver used for established
                        # sessions: recommendation language selects the report's
                        # deterministic value, while an explicit literal value
                        # remains a governed manual override when allowed.
                        rerouted = await self.source_operations.handle_chat(
                            session_id=request.session_id, message=request.message, state=state
                        )
                        if rerouted is None:
                            reply = (
                                "## No executable change was found\n"
                                "The requested member was analyzed successfully, but the update instruction could not be resolved. "
                                "State the attribute and either an explicit value or 'as recommended'."
                            )
                            intent = "source_change_needs_details"
                            structured = {
                                "code": "SOURCE_CHANGE_INTENT_UNRESOLVED",
                                "analysis_performed": True,
                                "analysis_run_id": report.get("run_id"),
                                "requested_identifier": identifier_data,
                            }
                        else:
                            rerouted_intent, rerouted_reply, rerouted_structured = rerouted
                            structured = dict(rerouted_structured or {})
                            structured["analysis_performed"] = True
                            structured["analysis_run_id"] = report.get("run_id")
                            structured["requested_identifier"] = identifier_data
                            intent = rerouted_intent
                            reply = rerouted_reply
                            # The re-routed command creates a grounded plan. The user
                            # must now complete the approval steps required by their role.

                assistant = await self.sessions.append(
                    request.session_id,
                    role="assistant",
                    content=reply,
                    metadata={"intent": intent, "structuredData": structured},
                )
                return self._response(
                    request.session_id, assistant.message_id, reply, intent,
                    state.active_run_id, state.active_batch_id, base_url,
                    structured_data=structured, active_context=state.active_context,
                )

        if request.context == ChatContext.BATCH and action in INDIVIDUAL_ACTIONS:
            action = self._individual_to_batch_action(action)

        if action == ChatAction.RESET:
            await self.sessions.clear(request.session_id)
            reply = "This chat session has been reset. Previous messages, the active individual analysis, and the active bulk analysis have been cleared."
            assistant = await self.sessions.append(request.session_id, role="assistant", content=reply, metadata={"intent": "reset"})
            return self._response(request.session_id, assistant.message_id, reply, "reset", None, None, base_url, active_context="none")

        if action == ChatAction.HELP:
            reply = self._help_text()
            assistant = await self.sessions.append(request.session_id, role="assistant", content=reply, metadata={"intent": "help"})
            return self._response(
                request.session_id,
                assistant.message_id,
                reply,
                "help",
                state.active_run_id,
                state.active_batch_id,
                base_url,
                active_context=state.active_context,
            )

        if action == ChatAction.ANALYZE:
            if search_type is None or not search_value:
                reply = "Please provide an email, Profile ID, or CrowdTwist ID to analyze."
                assistant = await self.sessions.append(request.session_id, role="assistant", content=reply, metadata={"intent": "analyze_missing_identifier"})
                return self._response(
                    request.session_id,
                    assistant.message_id,
                    reply,
                    "analyze_missing_identifier",
                    state.active_run_id,
                    state.active_batch_id,
                    base_url,
                    active_context=state.active_context,
                )
            report = await self._run_analysis_for_session(
                session_id=request.session_id,
                state=state,
                search_type=search_type,
                search_value=search_value,
            )
            reply = self._analysis_reply(report)
            assistant = await self.sessions.append(
                request.session_id,
                role="assistant",
                content=reply,
                metadata={"intent": "analyze", "run_id": report.get("run_id")},
            )
            return self._response(
                request.session_id,
                assistant.message_id,
                reply,
                "analyze",
                str(report.get("run_id") or "") or None,
                state.active_batch_id,
                base_url,
                structured_data=self._compact_report(report),
                active_context="individual",
            )

        if action == ChatAction.SOURCE_CPS:
            reply, structured = await self._handle_cps_source_request(request, state)
            assistant = await self.sessions.append(
                request.session_id, role="assistant", content=reply, metadata={"intent": "source_cps"}
            )
            return self._response(
                request.session_id, assistant.message_id, reply, "source_cps",
                state.active_run_id, state.active_batch_id, base_url,
                structured_data=structured, active_context=state.active_context,
            )

        batch_context = await self._get_batch_context(state, base_url)
        if action in BATCH_ACTIONS:
            has_batch_context = bool(batch_context.get("job") or batch_context.get("summary"))
            reply, structured = self._deterministic_batch_action(action, batch_context, base_url)
            assistant = await self.sessions.append(
                request.session_id,
                role="assistant",
                content=reply,
                metadata={"intent": action.value, "job_id": state.active_batch_id, "batch_id": state.active_batch_result_id},
            )
            return self._response(
                request.session_id,
                assistant.message_id,
                reply,
                action.value,
                state.active_run_id,
                state.active_batch_id,
                base_url,
                structured_data=structured,
                active_context="batch" if has_batch_context else state.active_context,
            )

        report = state.last_report
        if action in INDIVIDUAL_ACTIONS:
            if report is None:
                # Generic summary/timing/report requests use the batch when it is the active context.
                mapped = self._individual_to_batch_action(action)
                if batch_context.get("job") or batch_context.get("summary"):
                    reply, structured = self._deterministic_batch_action(mapped, batch_context, base_url)
                    assistant = await self.sessions.append(request.session_id, role="assistant", content=reply, metadata={"intent": mapped.value})
                    return self._response(
                        request.session_id,
                        assistant.message_id,
                        reply,
                        mapped.value,
                        state.active_run_id,
                        state.active_batch_id,
                        base_url,
                        structured_data=structured,
                        active_context="batch",
                    )
                return await self._no_context_response(request.session_id, state, base_url)
            reply, structured = self._deterministic_action(action, report, base_url)
            assistant = await self.sessions.append(request.session_id, role="assistant", content=reply, metadata={"intent": action.value})
            return self._response(
                request.session_id,
                assistant.message_id,
                reply,
                action.value,
                state.active_run_id,
                state.active_batch_id,
                base_url,
                structured_data=structured,
                active_context="individual",
            )

        # Free-form questions use the most recently active context. Explicit batch wording
        # always selects batch evidence even when an individual report also exists.
        if request.context == ChatContext.BATCH:
            use_batch = True
        elif request.context == ChatContext.INDIVIDUAL:
            use_batch = False
        else:
            use_batch = self._question_targets_batch(request.message) or state.active_context == "batch"
        history = [item.model_dump(mode="json") for item in state.messages[-self.api_settings.chat_history_messages :]]
        judge_enabled = self.api_settings.chat_judge_enabled if request.judge_response is None else request.judge_response

        if use_batch and (batch_context.get("job") or batch_context.get("summary")):
            if not batch_context.get("summary"):
                reply, structured = self._deterministic_batch_action(ChatAction.BATCH_STATUS, batch_context, base_url)
                assistant = await self.sessions.append(request.session_id, role="assistant", content=reply, metadata={"intent": "batch_status"})
                return self._response(
                    request.session_id,
                    assistant.message_id,
                    reply,
                    "batch_status",
                    state.active_run_id,
                    state.active_batch_id,
                    base_url,
                    structured_data=structured,
                    active_context="batch",
                )
            evidence = self._batch_evidence_for_question(batch_context["summary"], request.message)
            reply, judge = await self._grounded_evidence_followup(
                question=request.message,
                evidence=evidence,
                evidence_type="bulk_analysis",
                history=history,
                judge_enabled=judge_enabled,
            )
            assistant = await self.sessions.append(
                request.session_id,
                role="assistant",
                content=reply,
                metadata={"intent": "batch_follow_up", "job_id": state.active_batch_id, "judge": judge},
            )
            return self._response(
                request.session_id,
                assistant.message_id,
                reply,
                "batch_follow_up",
                state.active_run_id,
                state.active_batch_id,
                base_url,
                structured_data=evidence,
                judge=judge,
                active_context="batch",
            )

        if report is None:
            return await self._no_context_response(request.session_id, state, base_url)

        # v11.46: exact attribute questions are answered deterministically from
        # the active verified report before Dell AIA is asked to narrate. This
        # keeps current values, truth source, recommendation, target system and
        # write capability exact while still leaving open-ended questions to the
        # grounded Dell AIA + Judge path.
        deterministic_attribute = self._deterministic_attribute_followup(request.message, report)
        if deterministic_attribute is not None:
            reply, structured = deterministic_attribute
            assistant = await self.sessions.append(
                request.session_id, role="assistant", content=reply,
                metadata={"intent": "attribute_follow_up", "run_id": report.get("run_id")},
            )
            return self._response(
                request.session_id, assistant.message_id, reply, "attribute_follow_up",
                state.active_run_id, state.active_batch_id, base_url,
                structured_data=structured, active_context="individual",
            )

        reply, judge = await self._grounded_evidence_followup(
            question=request.message,
            evidence=self._compact_report(report),
            evidence_type="individual_analysis",
            history=history,
            judge_enabled=judge_enabled,
        )
        assistant = await self.sessions.append(
            request.session_id,
            role="assistant",
            content=reply,
            metadata={"intent": "follow_up", "run_id": report.get("run_id"), "judge": judge},
        )
        return self._response(
            request.session_id,
            assistant.message_id,
            reply,
            "follow_up",
            state.active_run_id,
            state.active_batch_id,
            base_url,
            structured_data=self._compact_report(report),
            judge=judge,
            active_context="individual",
        )

    @staticmethod
    def _deterministic_attribute_followup(message: str, report: dict[str, Any]) -> tuple[str, dict[str, Any]] | None:
        lower = str(message or "").casefold()
        capability_question = bool(re.search(
            r"(?i)\b(?:what|which)\b.*\b(?:attribute|attributes|field|fields|details|properties)\b.*\b(?:update|change|write|correct)\b|"
            r"\bwhat\s+can\s+(?:you|the\s+agent)\s+(?:update|change|write|correct)\b|"
            r"\b(?:supported|writable)\s+(?:attribute|attributes|field|fields)\b",
            message,
        ))
        field = SourceOperationService.extract_requested_field(message)
        if field is None and not capability_question:
            return None

        source_labels = {
            SourceSystem.CPS: "CPS",
            SourceSystem.REWARDS_DB: "Rewards DB",
            SourceSystem.CROWD_TWIST: "CrowdTwist",
        }
        if capability_question and field is None:
            rows: list[str] = []
            all_fields = sorted({name for source in AGENTIC_WRITABLE_SOURCES for name in WRITE_FIELDS.get(source, {})})
            for name in all_fields:
                targets = [source_labels[source] for source in AGENTIC_WRITABLE_SOURCES if name in WRITE_FIELDS.get(source, {})]
                rows.append(f"| {name.replace('_', ' ').title()} | {', '.join(targets)} | Supported through the same manual-tab writer |")
            reply = "\n".join([
                "## Writable Agentic attributes",
                "The Agent can update only downstream fields exposed by the proven manual Rewards DB/CrowdTwist update services. CPS remains read-only.",
                "",
                "| Attribute | Writable source(s) | Execution path |",
                "|---|---|---|",
                *rows,
                "",
                "For **as suggested / correct value**, the deterministic recommendation is used. For an explicit literal value, the requested value is preserved; if it differs from the deterministic recommendation it is identified as a **manual override** and still goes through pre-read, shared writer, read-after-write verification, and audit.",
            ])
            return reply, {"capability": True, "writable_fields": all_fields}

        attributes = list(report.get("attributes") or [])
        verdict = next((item for item in attributes if isinstance(item, dict) and str(item.get("attribute") or "") == field), None)
        suggestions = [
            item for item in list(report.get("suggestions") or [])
            if isinstance(item, dict)
            and (SourceOperationService.resolve_field(str(item.get("attribute") or item.get("field") or "")) or str(item.get("attribute") or item.get("field") or "")) == field
        ]
        writable_sources = [source for source in AGENTIC_WRITABLE_SOURCES if field in WRITE_FIELDS.get(source, {})]
        writable_labels = [source_labels[source] for source in writable_sources]

        if verdict is None:
            if not writable_sources:
                return (
                    f"## {field.replace('_', ' ').title()}\nThis attribute is not part of the current deterministic comparison model and is not exposed by the Agentic manual-tab write contract.",
                    {"field": field, "writable": False},
                )
            return (
                f"## {field.replace('_', ' ').title()}\nThis field is writable in **{', '.join(writable_labels)}**, but the active disparity report does not define a deterministic truth verdict for it. An explicit source + literal value can be executed as a governed manual override; the Agent will not invent a 'correct' value.",
                {"field": field, "writable": True, "writable_sources": [source.value for source in writable_sources], "deterministic_verdict": None},
            )

        observations = verdict.get("observations") or {}
        value_rows: list[str] = []
        for source, label in ((SourceSystem.CPS, "CPS"), (SourceSystem.REWARDS_DB, "Rewards DB"), (SourceSystem.CROWD_TWIST, "CrowdTwist")):
            observation = observations.get(source.value) or {}
            raw_value = observation.get("raw_value") if isinstance(observation, dict) else None
            present = bool(observation.get("present")) if isinstance(observation, dict) else raw_value not in (None, "")
            rendered = "—" if not present or raw_value in (None, "") else str(raw_value)
            value_rows.append(f"| {label} | `{rendered}` |")

        truth_source = str(verdict.get("truth_source") or "rule-derived")
        truth_value = verdict.get("truth_value")
        status = str(verdict.get("status") or "UNKNOWN")
        lines = [
            f"## {field.replace('_', ' ').title()}",
            f"- **Verdict:** {status}",
            f"- **Truth/reference source:** {truth_source}",
            f"- **Truth value:** `{truth_value if truth_value not in (None, '') else '—'}`",
            f"- **Agent-writable source(s):** {', '.join(writable_labels) if writable_labels else 'None'}",
            "",
            "| Source | Current value |",
            "|---|---|",
            *value_rows,
        ]
        if verdict.get("explanation"):
            lines.extend(["", f"**Why:** {verdict.get('explanation')}"])
        if suggestions:
            lines.extend(["", "### Exact correction(s)", "| Target | Current | Recommended | Automation |", "|---|---|---|---|"])
            for item in suggestions:
                target = str(item.get("target_source") or "—")
                current = item.get("current_value")
                recommended = item.get("recommended_value")
                automation = "Manual review" if item.get("requires_manual_review") or item.get("automation_eligible") is False else "Eligible"
                lines.append(f"| {target} | `{current if current not in (None, '') else '—'}` | `{recommended if recommended not in (None, '') else '—'}` | {automation} |")
        elif writable_sources:
            lines.extend(["", "There is no deterministic correction for this field in the active report. The Agent will not invent a recommended value."])

        if any(term in lower for term in ("update", "change", "write", "correct", "can you")):
            lines.extend([
                "",
                "**Execution rule:** `as suggested` / `correct value` uses the deterministic recommendation. A literal value request uses the exact supplied value when the target source can be resolved and the field is writable; a conflicting literal value is labeled as a manual override.",
            ])
        return "\n".join(lines), {
            "field": field,
            "verdict": verdict,
            "suggestions": suggestions,
            "writable_sources": [source.value for source in writable_sources],
        }

    async def _run_analysis_for_session(
        self,
        *,
        session_id: str,
        state: SessionState,
        search_type: SearchType,
        search_value: str,
        audit_action: str = "Cross-source disparity analysis",
    ) -> dict[str, Any]:
        """Run and persist one individual analysis without deciding the chat intent.

        This helper is shared by normal analysis requests and update commands
        that need fresh evidence before a governed plan can be created.
        """
        from ..agents.orchestrator import AgenticOrchestrator

        actor = state.metadata.get("actor") or "Unknown user"
        actor_email = state.metadata.get("actor_email")
        target = f"{search_type.value}: {search_value}"
        if self.source_operations is not None:
            await self.source_operations.audit_agentic_activity(
                "ANALYSIS_STARTED",
                {
                    "session_id": session_id,
                    "actor": actor,
                    "actor_email": actor_email,
                    "source": "Agentic AI",
                    "action": audit_action,
                    "status": "STARTED",
                    "target": target,
                    "search_type": search_type.value,
                    "search_value": search_value,
                    "verification": "Analysis queued",
                },
            )
        try:
            report_obj = await AgenticOrchestrator(self.settings, ai_semaphore=self.ai_semaphore).run(search_type, search_value)
            report = report_obj.model_dump(mode="json")
            await self.runs.put(report)
            await self.sessions.set_active_report(session_id, report)
            identifier_match = IdentifierMatch(search_type, search_value, -1, "analysis")
            remember_identifier(state.facts, identifier_match)
            identity_bundle = self._identity_bundle_from_report(report)
            remember_identity_bundle(state.facts, identity_bundle)
            if self.source_operations is not None:
                source_status = report.get("source_status") or {}
                found_sources = [
                    source for source, status in source_status.items()
                    if isinstance(status, dict) and status.get("data_found")
                ]
                judge = report.get("judge_result") or {}
                await self.source_operations.audit_agentic_activity(
                    "ANALYSIS_COMPLETED",
                    {
                        "session_id": session_id,
                        "run_id": report.get("run_id"),
                        "actor": actor,
                        "actor_email": actor_email,
                        "source": "Agentic AI",
                        "action": audit_action,
                        "status": "COMPLETED",
                        "target": target,
                        "search_type": search_type.value,
                        "search_value": search_value,
                        "verification": (
                            f"{len(found_sources)}/3 source record(s); "
                            f"coverage {report.get('analysis_completeness') or 'UNKNOWN'}; "
                            f"judge {judge.get('verdict') or judge.get('status') or 'NOT_RUN'}"
                        ),
                        "details": {
                            "resolved_identity": identity_bundle,
                            "sourceStatus": source_status,
                            "mismatchCount": report.get("mismatch_count", 0),
                            "missingCount": report.get("missing_count", 0),
                            "invalidFormatCount": report.get("invalid_format_count", 0),
                            "unverifiableCount": report.get("unverifiable_count", 0),
                            "analysisCompleteness": report.get("analysis_completeness"),
                            "judge": judge,
                            "changePreparation": audit_action != "Cross-source disparity analysis",
                        },
                    },
                )
            return report
        except Exception as exc:
            if self.source_operations is not None:
                await self.source_operations.audit_agentic_activity(
                    "ANALYSIS_FAILED",
                    {
                        "session_id": session_id,
                        "actor": actor,
                        "actor_email": actor_email,
                        "source": "Agentic AI",
                        "action": audit_action,
                        "status": "FAILED",
                        "target": target,
                        "search_type": search_type.value,
                        "search_value": search_value,
                        "reason": str(exc),
                        "verification": type(exc).__name__,
                    },
                )
            raise

    async def _record_adaptive_write_outcome(self, state: SessionState, change: dict[str, Any]) -> None:
        """Persist only PII-free write-quality telemetry for replay learning.

        Approval rules and write decisions are intentionally not learned or changed.
        """
        if not change:
            return
        status = str(change.get("status") or "UNKNOWN").upper()
        results = [item for item in (change.get("results") or []) if isinstance(item, dict)]
        dry_run = status == "DRY_RUN_COMPLETED"
        verified_results = [bool(item.get("verified") or item.get("success")) for item in results]
        verified = bool(verified_results) and all(verified_results) and not dry_run
        await self.adaptive_memory.record_write_verification({
            "source": change.get("source") or "unknown",
            "field_name": change.get("field") or change.get("wire_field"),
            "status": status,
            "verified": verified,
            "dry_run": dry_run,
            "role": state.metadata.get("actor_role") or "unknown",
            "duration_ms": change.get("duration_ms") or 0,
        })

    @staticmethod
    def _post_write_analysis_summary(report: dict[str, Any]) -> dict[str, Any]:
        return {
            "status": "COMPLETED",
            "run_id": report.get("run_id"),
            "search_type": report.get("search_type"),
            "search_value": report.get("search_value"),
            "analysis_completeness": report.get("analysis_completeness"),
            "mismatch_count": report.get("mismatch_count", 0),
            "missing_record_count": report.get("missing_record_count", 0),
            "actionable_suggestion_count": report.get("actionable_suggestion_count", 0),
            "judge_verdict": (report.get("judge_result") or {}).get("verdict"),
        }

    async def refresh_after_source_change(
        self,
        session_id: str,
        change: dict[str, Any],
        *,
        prepare_next_suggestion: bool = True,
    ) -> dict[str, Any] | None:
        """Refresh the active member analysis after a verified live source write.

        The write result is never rolled back merely because reanalysis fails.
        This method only runs when at least one target was actually updated and
        verified, and it records a compact failure marker on the change when a
        fresh analysis cannot be produced.
        """
        status = str(change.get("status") or "").upper()
        results = list(change.get("results") or [])
        if status not in {"COMPLETED", "PARTIAL"} or not any(item.get("success") and not item.get("dry_run") for item in results):
            return None

        state = await self.sessions.get(session_id)

        # A successful live mutation invalidates every not-yet-approved suggestion
        # derived from the old report.  Fail closed: clear the queue before
        # reanalysis so a refresh failure can never leave a stale correction
        # available for approval.
        change.pop("next_change", None)
        change["next_change_revalidation_required"] = bool(change.get("suggested_change"))
        if self.source_operations is not None:
            await self.source_operations.invalidate_suggested_change_queue_after_live_write(session_id)

        requested = change.get("requested_identifier") or {}
        search_type: SearchType | None = None
        search_value = ""
        try:
            if requested.get("search_type") and requested.get("value") not in (None, ""):
                search_type = SearchType(str(requested.get("search_type")))
                search_value = str(requested.get("value")).strip()
        except ValueError:
            search_type = None

        if search_type is None or not search_value:
            current = state.last_report or {}
            try:
                if current.get("search_type") and current.get("search_value") not in (None, ""):
                    search_type = SearchType(str(current.get("search_type")))
                    search_value = str(current.get("search_value")).strip()
            except ValueError:
                search_type = None

        if search_type is None or not search_value:
            first_email = str(((change.get("targets") or [{}])[0]).get("email") or "").strip()
            if first_email:
                search_type = SearchType.EMAIL
                search_value = first_email

        if search_type is None or not search_value:
            change["post_write_analysis"] = {"status": "SKIPPED", "reason": "No resolvable identifier was available."}
            return None

        try:
            refreshed = await self._run_analysis_for_session(
                session_id=session_id,
                state=state,
                search_type=search_type,
                search_value=search_value,
                audit_action="Post-write cross-source verification analysis",
            )

            # Only a freshly collected report may produce the next governed
            # correction.  This prevents correction N+1 from being based on the
            # pre-write report for correction N.
            if prepare_next_suggestion and change.get("suggested_change") and self.source_operations is not None:
                try:
                    next_change = await self.source_operations.plan_suggested_change_from_report(
                        session_id=session_id, state=state
                    )
                except SourceOperationError as next_exc:
                    change["next_change"] = None
                    change["remaining_suggested_changes"] = 0
                    change["next_change_revalidation"] = {
                        "status": "NO_FRESH_AUTOMATABLE_CHANGE",
                        "code": next_exc.code,
                        "message": str(next_exc),
                        "fresh_run_id": refreshed.get("run_id"),
                    }
                else:
                    change["next_change"] = self.source_operations.public_change(next_change)
                    change["remaining_suggested_changes"] = int(next_change.get("remaining_suggested_changes") or 0) + 1
                    change["next_change_revalidation"] = {
                        "status": "FRESH_PLAN_READY",
                        "fresh_run_id": refreshed.get("run_id"),
                        "next_change_id": next_change.get("change_id"),
                        "truth_source": next_change.get("truth_source"),
                    }
            change["next_change_revalidation_required"] = False
            return refreshed
        except Exception as exc:
            change["post_write_analysis"] = {
                "status": "FAILED",
                "error_type": type(exc).__name__,
                "message": str(exc)[:500],
                "search_type": search_type.value,
                "search_value": search_value,
            }
            return None

    async def _execute_explicit_source_request(
        self,
        *,
        request: ChatRequest,
        state: SessionState,
        structured: dict[str, Any],
    ) -> tuple[str, str, dict[str, Any]]:
        """Compatibility helper that preserves role-governed approval semantics."""
        if self.source_operations is None:
            return (
                "source_operation_error",
                "## Source operation unavailable\nThe source operation service is not configured.",
                {"code": "SOURCE_OPERATION_SERVICE_UNAVAILABLE"},
            )
        change_data = dict(structured.get("change") or {})
        change_id = str(change_data.get("change_id") or "").upper()
        if not change_id:
            return (
                "source_operation_error",
                "## Unable to approve the change\nThe governed change plan is missing its change ID.",
                {"code": "SOURCE_CHANGE_ID_REQUIRED"},
            )
        try:
            change = await self.source_operations.execute_explicit_chat_command(
                request.session_id,
                change_id,
                command_text=request.message,
                actor=state.metadata.get("actor") or None,
                actor_email=state.metadata.get("actor_email") or None,
                actor_role=state.metadata.get("actor_role") or request.actor_role,
            )
        except SourceOperationError as exc:
            if exc.code == "FINAL_APPROVAL_POPUP_REQUIRED":
                pending = await self.source_operations._get_change(request.session_id, change_id)
                return (
                    "source_popup_required",
                    self.source_operations._popup_required_reply(pending),
                    {**structured, "change": self.source_operations.public_change(pending), "requires_popup": True},
                )
            raise
        terminal = str(change.get("status") or "").upper()
        if terminal in {"COMPLETED", "PARTIAL", "FAILED", "DRY_RUN_COMPLETED", "BLOCKED_WRITES_DISABLED", "BLOCKED_OPERATION_NOT_CONFIGURED", "ABORTED_PRECONDITION_CHANGED"}:
            refreshed = await self.refresh_after_source_change(request.session_id, change)
            if refreshed is not None:
                change["post_write_analysis"] = self._post_write_analysis_summary(refreshed)
            return (
                "source_confirm_2",
                self.source_operations._execution_sequence_reply(change),
                {**structured, "change": self.source_operations.public_change(change), "next_change": change.get("next_change")},
            )
        return (
            "source_confirm_1",
            self.source_operations._confirm_two_reply(change),
            {**structured, "change": self.source_operations.public_change(change), "requires_popup": True},
        )

    async def _handle_cps_source_request(self, request: ChatRequest, state: SessionState) -> tuple[str, dict[str, Any]]:
        text = request.message.strip()
        lower = text.casefold()
        explicit = [m.group(0) for m in EMAIL_RE.finditer(text)]
        pending = [str(x) for x in (state.facts.get("pending_cps_candidates") or [])]

        if pending:
            if lower in {"all", "run all", "all of them", "yes all"} or " all " in f" {lower} ":
                selected = pending
            elif explicit:
                allowed = {x.casefold(): x for x in pending}
                selected = [allowed[e.casefold()] for e in explicit if e.casefold() in allowed]
                if not selected:
                    selected = explicit
            else:
                selected = []
            if selected:
                state.facts.pop("pending_cps_candidates", None)
                state.facts.pop("pending_cps_query", None)
                return await self._run_cps_for_emails(selected)

        if explicit:
            return await self._run_cps_for_emails(explicit)

        query = self._extract_cps_query(text)
        candidates = self._find_candidate_emails(state, query)
        if len(candidates) == 1:
            return await self._run_cps_for_emails(candidates)
        if len(candidates) > 1:
            state.facts["pending_cps_candidates"] = candidates
            state.facts["pending_cps_query"] = query
            shown = candidates[:20]
            lines = [
                f"## Multiple emails match **{query}**",
                f"I found **{len(candidates)}** matching email(s) in the active session/bulk result.",
                "Reply **all** to run the CPS API for every match, or paste one specific email.",
                "",
            ] + [f"- `{email}`" for email in shown]
            if len(candidates) > len(shown):
                lines.append(f"- …and {len(candidates)-len(shown)} more")
            return "\n".join(lines), {"status": "selection_required", "query": query, "candidates": candidates}

        reply = (
            f"## CPS lookup needs an exact email\n"
            f"I could not resolve **{query or 'that name'}** to an email from the active session or completed bulk result. "
            "The configured CPS account API performs exact identifier lookup; it does not expose a wildcard email-directory search. "
            "Provide one email, paste a list, or complete a bulk analysis containing the matching users first."
        )
        return reply, {"status": "email_required", "query": query, "candidates": []}

    async def _run_cps_for_emails(self, emails: list[str]) -> tuple[str, dict[str, Any]]:
        unique: list[str] = []
        seen: set[str] = set()
        for email in emails:
            value = str(email).strip()
            if not value or "@" not in value or value.casefold() in seen:
                continue
            seen.add(value.casefold())
            unique.append(value)
        connector = CPSConnector(self.settings)
        semaphore = asyncio.Semaphore(min(4, max(1, len(unique))))

        async def one(email: str) -> dict[str, Any]:
            async with semaphore:
                record = await connector.fetch(SearchType.EMAIL, email)
            dumped = record.model_dump(mode="json")
            status = dumped.get("status") or {}
            return {
                "email": email,
                "connected": bool(status.get("connected")),
                "data_found": bool(status.get("data_found")),
                "http_status": status.get("http_status"),
                "latency_ms": status.get("latency_ms"),
                "error": status.get("error"),
                "record": dumped,
            }

        results = await asyncio.gather(*(one(email) for email in unique))
        found = sum(1 for item in results if item["data_found"])
        no_value = sum(1 for item in results if item["connected"] and not item["data_found"])
        failed = len(results) - found - no_value
        lines = [
            "## CPS API result",
            f"- **Requested:** {len(results)}",
            f"- **Data found:** {found}",
            f"- **No value found:** {no_value}",
            f"- **Failed/unavailable:** {failed}",
            "",
        ]
        for item in results:
            label = "DATA FOUND" if item["data_found"] else ("NO VALUE FOUND" if item["connected"] else "FAILED")
            detail = f"HTTP {item['http_status']}" if item.get("http_status") is not None else "no HTTP status"
            lines.append(f"- `{item['email']}` — **{label}** ({detail}, {item.get('latency_ms') or 0} ms)")
        lines.extend(["", "This operation is read-only; no source data was changed."] )
        return "\n".join(lines), {
            "operation": "direct.cps.get_account",
            "requested_count": len(results),
            "found_count": found,
            "no_value_found_count": no_value,
            "failed_count": failed,
            "results": results,
        }

    @staticmethod
    def _extract_cps_query(text: str) -> str:
        cleaned = re.sub(r"(?i)\b(can you|please|could you|run|fetch|get|show|check|lookup|search|the|cps|data|api|for|of)\b", " ", text)
        cleaned = re.sub(r"\s+", " ", cleaned).strip(" ?.,")
        return cleaned or text.strip()

    @staticmethod
    def _find_candidate_emails(state: SessionState, query: str) -> list[str]:
        pool: list[str] = []
        summary = state.last_batch_summary or {}
        for member in summary.get("members") or []:
            if isinstance(member, dict):
                value = str(member.get("email") or "").strip()
                if value:
                    pool.append(value)
        if state.last_report:
            value = str(state.last_report.get("search_value") or "").strip()
            if "@" in value:
                pool.append(value)
        folded = query.casefold().strip()
        result: list[str] = []
        seen: set[str] = set()
        for email in pool:
            key = email.casefold()
            if key in seen:
                continue
            if not folded or folded in key:
                seen.add(key)
                result.append(email)
        return result

    async def _no_context_response(self, session_id: str, state: SessionState, base_url: str) -> ChatResponse:
        reply = (
            "There is no completed individual or bulk analysis in this session. "
            "Analyze one member or submit a TXT/CSV bulk analysis first."
        )
        assistant = await self.sessions.append(session_id, role="assistant", content=reply, metadata={"intent": "no_active_analysis"})
        return self._response(
            session_id,
            assistant.message_id,
            reply,
            "no_active_analysis",
            state.active_run_id,
            state.active_batch_id,
            base_url,
            active_context=state.active_context,
        )

    def _resolve_intent(
        self,
        request: ChatRequest,
        context: SessionState | dict[str, Any] | None,
    ) -> tuple[ChatAction, SearchType | None, str | None]:
        if request.action != ChatAction.AUTO:
            return request.action, request.search_type, (request.search_value or "").strip() or None

        last_report = context.last_report if isinstance(context, SessionState) else context if isinstance(context, dict) else None
        stored_active_context = context.active_context if isinstance(context, SessionState) else ("individual" if last_report else "none")
        if request.context == ChatContext.INDIVIDUAL:
            active_context = "individual"
        elif request.context == ChatContext.BATCH:
            active_context = "batch"
        else:
            active_context = stored_active_context
        has_batch = bool(context.active_batch_id or context.last_batch_summary) if isinstance(context, SessionState) else False

        text = request.message.strip()
        lower = text.casefold()
        batch_targeted = request.context == ChatContext.BATCH or (
            request.context == ChatContext.AUTO and self._question_targets_batch(text)
        )

        if lower in {"reset", "/reset", "clear session", "clear memory"}:
            return ChatAction.RESET, None, None
        if lower in {"help", "/help", "what can you do"}:
            return ChatAction.HELP, None, None

        facts = context.facts if isinstance(context, SessionState) else {}
        identifier = resolve_identifier(text, facts)
        mentioned_sources = SourceOperationService.detect_sources(text)
        explicit_analysis = bool(re.search(
            r"(?i)\b(?:perform|run|do|start|complete)?\s*(?:the\s+)?(?:full\s+|complete\s+|disparity\s+)?analys(?:is|e|ze)\b|"
            r"\bcompare\s+(?:all\s+)?(?:three|3|sources)|\bfind\s+disparit",
            text,
        ))

        # Governed write language outranks the generic identifier fallback.
        # This prevents ``do the changes to <Profile ID>`` from becoming an
        # ANALYZE action solely because the message contains the word profile.
        if SourceOperationService.is_write_request(text):
            return ChatAction.SOURCE_CHANGE, identifier.search_type if identifier else None, identifier.value if identifier else None

        if request.search_type and request.search_value:
            return ChatAction.ANALYZE, request.search_type, request.search_value.strip()
        if identifier is not None and explicit_analysis and not batch_targeted:
            return ChatAction.ANALYZE, identifier.search_type, identifier.value

        pending_cps = context.facts.get("pending_cps_candidates") if isinstance(context, SessionState) else None
        if pending_cps and (lower in {"all", "run all", "all of them", "yes all"} or EMAIL_RE.search(text)):
            return ChatAction.SOURCE_CPS, None, None
        if "cps" in lower and any(word in lower for word in ("run", "fetch", "get", "show", "check", "data", "lookup", "search")):
            return ChatAction.SOURCE_CPS, None, None

        # Bulk-specific intents are resolved before individual quick actions. The latest
        # completed bulk context also supports natural questions without repeating the word "batch".
        implicit_batch_analytics = request.context != ChatContext.INDIVIDUAL and any(phrase in lower for phrase in (
            "majority issue", "most common issue", "summary statistics", "summary stats",
            "which source has", "source has the most", "judge outcomes", "judge distribution",
        ))
        batch_analytic_context = batch_targeted or implicit_batch_analytics or (active_context == "batch" and has_batch)
        if batch_analytic_context:
            if any(phrase in lower for phrase in (
                "majority issue", "most common issue", "main issue", "biggest issue",
                "top issue", "most affected", "highest issue", "dominant issue",
            )):
                return ChatAction.BATCH_MAJORITY_ISSUE, None, None
            if any(phrase in lower for phrase in (
                "summary statistics", "summary stats", "batch statistics", "bulk statistics",
                "overall statistics", "statistical summary", "percentage", "percent",
            )):
                return ChatAction.BATCH_STATISTICS, None, None
            if any(phrase in lower for phrase in (
                "source coverage", "source availability", "which source", "missing source",
                "source record", "records missing", "database coverage",
            )):
                return ChatAction.BATCH_SOURCE_COVERAGE, None, None
            if any(phrase in lower for phrase in (
                "judge outcome", "judge result", "judge distribution", "accepted", "rejected", "corrected",
            )):
                return ChatAction.BATCH_JUDGE_OUTCOMES, None, None
            if any(word in lower for word in ("status", "progress", "running", "complete", "finished")):
                return ChatAction.BATCH_STATUS, None, None
            if any(word in lower for word in ("time", "timing", "duration", "how long")):
                return ChatAction.BATCH_TIMING, None, None
            if any(word in lower for word in ("download", "report link", "zip", "summary link")):
                return ChatAction.BATCH_REPORT_LINKS, None, None
            if any(word in lower for word in ("finding", "issue", "change", "affected", "which user", "which member")):
                return ChatAction.BATCH_FINDINGS, None, None
            if any(word in lower for word in ("summary", "result", "outcome", "show", "tell me")):
                return ChatAction.BATCH_SUMMARY, None, None

        if "suggest" in lower or "what should" in lower or "change to" in lower:
            return ChatAction.SUGGESTIONS, None, None
        if "source health" in lower or "connection" in lower or "api status" in lower:
            return ChatAction.SOURCE_HEALTH, None, None
        if "timing" in lower or "how long" in lower or "time taken" in lower:
            return (ChatAction.BATCH_TIMING if active_context == "batch" and has_batch else ChatAction.TIMING), None, None
        if "report" in lower and ("link" in lower or "download" in lower or "html" in lower or "json" in lower or "zip" in lower):
            return (ChatAction.BATCH_REPORT_LINKS if active_context == "batch" and has_batch else ChatAction.REPORT_LINKS), None, None
        if lower in {"summary", "summarize", "show summary", "show result", "result"}:
            return (ChatAction.BATCH_SUMMARY if active_context == "batch" and has_batch else ChatAction.SUMMARY), None, None

        if identifier is not None and not batch_targeted:
            general_analysis_request = bool(re.search(
                r"(?i)\b(?:check|compare|inspect|validate|review|process|member|user|profile|result)\b",
                text,
            ))
            if not mentioned_sources and (general_analysis_request or last_report is None and not has_batch):
                return ChatAction.ANALYZE, identifier.search_type, identifier.value
        return ChatAction.AUTO, None, None

    @staticmethod
    def _identity_bundle_from_report(report: dict[str, Any]) -> dict[str, Any]:
        records = report.get("records") or {}

        def canonical(source: str) -> dict[str, Any]:
            record = records.get(source) or records.get(SourceName(source)) or {}
            if hasattr(record, "model_dump"):
                record = record.model_dump(mode="json")
            return dict((record or {}).get("canonical") or {})

        cps = canonical(SourceName.CPS.value)
        rewards = canonical(SourceName.REWARDS_DB.value)
        crowd_twist = canonical(SourceName.CROWD_TWIST.value)

        def first(field: str, values: list[dict[str, Any]]) -> Any:
            for item in values:
                value = item.get(field)
                if value not in (None, ""):
                    return value
            return None

        return {
            "email": first("email", [cps, rewards, crowd_twist]),
            "profile_id": first("profile_id", [cps, rewards, crowd_twist]),
            "crowd_twist_id": first("crowd_twist_id", [crowd_twist, rewards]),
        }

    async def _get_batch_context(self, state: SessionState, base_url: str) -> dict[str, Any]:
        job_id = state.active_batch_id
        summary = state.last_batch_summary
        job_view: dict[str, Any] | None = None
        if job_id and self.batch_jobs is not None:
            try:
                job = await self.batch_jobs.get(job_id)
                job_view = self.batch_jobs.view(job, base_url).model_dump(mode="json")
                summary = job.summary or summary
            except BatchJobNotFound:
                pass
        if job_id and job_view is None:
            job_view = {
                "job_id": job_id,
                "batch_id": state.active_batch_result_id,
                "status": state.facts.get("active_batch_status", "UNKNOWN"),
                "phase": state.facts.get("active_batch_phase", "UNKNOWN"),
                "completed_count": state.facts.get("batch_completed_count", 0),
                "failed_count": state.facts.get("batch_failed_count", 0),
            }
        return {
            "job": job_view,
            "summary": summary,
            "job_id": job_id,
            "batch_id": (summary or {}).get("batch_id") or state.active_batch_result_id,
        }

    async def _grounded_evidence_followup(
        self,
        *,
        question: str,
        evidence: dict[str, Any],
        evidence_type: str,
        history: list[dict[str, Any]],
        judge_enabled: bool,
    ) -> tuple[str, dict[str, Any]]:
        from autogen_agentchat.agents import AssistantAgent
        from ..agents.model_client import build_model_client, close_model_client, safe_exception_chain

        prompt = json.dumps(
            {
                "question": question,
                "evidence_type": evidence_type,
                "recent_session_messages": history,
                "deterministic_evidence": evidence,
            },
            ensure_ascii=False,
            default=str,
        )
        async with self.ai_semaphore:
            client = None
            try:
                client = await build_model_client(self.settings)
                agent = AssistantAgent(
                    name="rus_session_chat_agent",
                    model_client=client,
                    system_message=CHAT_SYSTEM,
                    reflect_on_tool_use=False,
                )
                result = await self._run_with_retry(agent, prompt)
                reply = self._last_text(result)[: self.api_settings.chat_max_response_chars].strip()
                if not reply:
                    reply = "I could not generate a grounded response. The deterministic evidence remains available through the report endpoints."

                judge: dict[str, Any] = {"status": "NOT_RUN"}
                if judge_enabled:
                    judge_agent = AssistantAgent(
                        name="rus_session_chat_judge",
                        model_client=client,
                        system_message=CHAT_JUDGE_SYSTEM,
                        reflect_on_tool_use=False,
                    )
                    judge_prompt = json.dumps(
                        {
                            "question": question,
                            "evidence_type": evidence_type,
                            "proposed_response": reply,
                            "deterministic_evidence": evidence,
                        },
                        ensure_ascii=False,
                        default=str,
                    )
                    judge_result = await self._run_with_retry(judge_agent, judge_prompt)
                    judge_text = self._last_text(judge_result)
                    judge = self._parse_json(judge_text) or {"status": "UNPARSEABLE", "raw": judge_text[:4000]}
                    verdict = str(judge.get("verdict") or "").upper()
                    if verdict in {"REJECT", "REJECTED", "FAILED", "UNSUPPORTED", "PARTIAL", "CORRECTED"} and judge.get("corrected_response"):
                        reply = str(judge["corrected_response"])
                    elif verdict not in {"ACCEPT", "ACCEPTED", "PASS", "SUPPORTED"}:
                        reply = str(evidence.get("deterministic_summary") or evidence.get("authoritative_group_summary") or
                                    "The Judge did not approve this response. Use the deterministic summary or report for verified results.")
                        judge["content_disposition"] = "ANALYST_SUPPRESSED"
                return reply, judge
            except Exception as exc:
                fallback = (
                    "Dell AIA could not complete this follow-up response. The deterministic result is still available. "
                    "Use 'summary', 'suggestions', 'source health', 'timing', or 'report links'."
                    if evidence_type == "individual_analysis"
                    else "Dell AIA could not complete this bulk follow-up response. The deterministic batch result is still available. "
                    "Use 'bulk summary', 'bulk findings', 'batch timing', or 'batch report link'."
                )
                return fallback, {"status": "FAILED", "error": safe_exception_chain(exc)}
            finally:
                if client is not None:
                    try:
                        await close_model_client(client)
                    except Exception:
                        pass  # Cleanup must not discard the verified response or failure result.

    async def _run_with_retry(self, agent: Any, task: str) -> Any:
        from ..agents.model_client import is_rate_limit_error, rate_limit_retry_delay

        retries = max(0, int(self.api_settings.chat_rate_limit_retries))
        last_exc: Exception | None = None
        for attempt in range(retries + 1):
            try:
                return await agent.run(task=task)
            except Exception as exc:
                last_exc = exc
                if is_rate_limit_error(exc) and attempt < retries:
                    await asyncio.sleep(rate_limit_retry_delay(self.settings, attempt, exc))
                    continue
                raise
        assert last_exc is not None
        raise last_exc

    @staticmethod
    def _last_text(result: Any) -> str:
        messages = list(getattr(result, "messages", []) or [])
        for message in reversed(messages):
            content = getattr(message, "content", None)
            if isinstance(content, str) and content.strip():
                return content
        return ""

    @staticmethod
    def _parse_json(text: str) -> dict[str, Any] | None:
        text = (text or "").strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S).strip()
        try:
            value = json.loads(text)
            return value if isinstance(value, dict) else None
        except Exception:
            start, end = text.find("{"), text.rfind("}")
            if start >= 0 and end > start:
                try:
                    value = json.loads(text[start : end + 1])
                    return value if isinstance(value, dict) else None
                except Exception:
                    return None
        return None

    def _deterministic_action(self, action: ChatAction, report: dict[str, Any], base_url: str) -> tuple[str, dict[str, Any]]:
        if action == ChatAction.SUMMARY:
            return str(report.get("deterministic_summary") or "No summary available."), self._compact_report(report)
        if action == ChatAction.SUGGESTIONS:
            suggestions = report.get("suggestions") or []
            exact = [item for item in suggestions if item.get("recommended_value") is not None and not item.get("requires_manual_review")]
            review = [item for item in suggestions if item.get("requires_manual_review")]
            lines = [f"There are {len(exact)} exact correction(s) and {len(review)} manual-review item(s)."]
            for item in exact[:12]:
                lines.append(
                    f"{item.get('label')}: change {item.get('target_source')} from {item.get('current_value')} "
                    f"to {item.get('recommended_value')} based on {item.get('truth_source')}."
                )
            for item in review[:8]:
                lines.append(f"Manual review — {item.get('label')}: {item.get('recommendation') or item.get('explanation')}")
            return "\n".join(lines), {"suggestions": suggestions}
        if action == ChatAction.SOURCE_HEALTH:
            statuses = report.get("source_status") or {}
            lines = []
            for key, label in (("cps", "CPS"), ("rewards_db", "Rewards DB"), ("crowd_twist", "CrowdTwist")):
                item = statuses.get(key) or {}
                status_text = "DATA_FOUND" if item.get("data_found") else ("NO_VALUE_FOUND" if item.get("connected") else "UNAVAILABLE")
                lines.append(f"{label}: {status_text}; latency={item.get('latency_ms', '—')} ms; stage={item.get('stage') or '—'}.")
            return "\n".join(lines), {"source_status": statuses}
        if action == ChatAction.TIMING:
            timings = report.get("timings") or {}
            ordered = [
                ("Total", "end_to_end_ms"),
                ("Data Collection Agent", "data_collection_agent_ms"),
                ("Dell AIA Analyst", "analysis_agent_ms"),
                ("Dell AIA Judge", "judge_agent_ms"),
                ("Dell AIA Queue", "dell_aia_queue_wait_ms"),
                ("Report Write", "audit_report_write_ms"),
            ]
            lines = [f"{label}: {self._format_ms(timings.get(key))}" for label, key in ordered]
            return "\n".join(lines), {"timings": timings}
        if action == ChatAction.REPORT_LINKS:
            run_id = str(report.get("run_id") or "")
            links = self._report_links(base_url, run_id)
            return f"HTML report: {links['html']}\nJSON evidence: {links['json']}\nRun API: {links['api']}", {"report_links": links}
        return "No deterministic action was selected.", {}

    def _deterministic_batch_action(
        self,
        action: ChatAction,
        context: dict[str, Any],
        base_url: str,
    ) -> tuple[str, dict[str, Any]]:
        job = context.get("job") or {}
        summary = context.get("summary")
        job_id = context.get("job_id") or job.get("job_id")
        links = self._batch_links(base_url, job_id)

        if not job_id and not summary:
            return "No bulk analysis is attached to this chat session. Submit a TXT or CSV batch using the same session first.", {}

        status_text = str(job.get("status") or ("COMPLETED" if summary else "UNKNOWN"))
        phase = str(job.get("phase") or status_text)
        if action == ChatAction.BATCH_STATUS or summary is None:
            total = int(job.get("unique_valid_count") or 0)
            completed = int(job.get("completed_count") or 0)
            failed = int(job.get("failed_count") or 0)
            reply = (
                f"Bulk job {job_id} is {status_text} in phase {phase}. "
                f"Completed {completed}/{total or '—'} unique member(s); failed {failed}; elapsed {self._format_ms(job.get('elapsed_ms'))}."
            )
            if status_text == "COMPLETED":
                reply += " The grouped summary is available."
            elif status_text == "FAILED":
                reply += f" Error: {(job.get('error') or {}).get('message') or 'Unknown batch error'}."
            return reply, {"job": job, "batch_links": links}

        assert isinstance(summary, dict)
        compact = self._compact_batch_summary(summary)
        processing = summary.get("processing") or {}
        population = summary.get("population_metrics") or {}
        totals = summary.get("totals") or {}
        judge = summary.get("judge_outcomes") or {}
        source_metrics = summary.get("source_member_record_metrics") or {}
        timing = summary.get("timings") or {}
        batch_id = summary.get("batch_id") or context.get("batch_id") or job_id

        insights = summary.get("batch_insights") or build_batch_insights(summary)
        unique_members = int(insights.get("unique_members") or population.get("unique_members_processed") or 0)
        population_pct = insights.get("population_percentages") or {}

        if action == ChatAction.BATCH_SUMMARY:
            authoritative = str(summary.get("authoritative_group_summary") or "").strip()
            majority = (insights.get("majority_issue") or {}).get("attributes") or []
            majority_line = self._majority_issue_line(majority)
            lines = [
                f"## Bulk analysis summary — {batch_id}",
                "",
                f"Processed {unique_members} unique member(s).",
                f"{population.get('users_with_exact_changes', 0)} user(s) with exact changes; {population.get('users_requiring_manual_review', 0)} user(s) requiring manual review.",
                f"{source_metrics.get('missing_source_member_records_total', totals.get('missing_records', 0))} missing source-member records; {totals.get('deferred', 0)} deferred attribute verdicts.",
                "",
                "### Processing",
                f"- **Unique members:** {unique_members}",
                f"- **Completed:** {processing.get('completed_count', 0)}",
                f"- **Failed:** {processing.get('failed_count', 0)}",
                f"- **Exact-change users:** {population.get('users_with_exact_changes', 0)} ({population_pct.get('members_with_exact_changes', 0)}%)",
                f"- **Manual-review users:** {population.get('users_requiring_manual_review', 0)} ({population_pct.get('members_requiring_manual_review', 0)}%)",
                "",
                "### Findings",
                f"- **Most widespread issue:** {majority_line}",
                f"- **Mismatch items:** {totals.get('mismatches', 0)}",
                f"- **Missing source-member records:** {source_metrics.get('missing_source_member_records_total', totals.get('missing_records', 0))}",
                f"- **Deferred attribute verdicts:** {totals.get('deferred', 0)}",
                f"- **Exact-change items:** {totals.get('exact_changes', 0)}",
                f"- **Manual-review items:** {totals.get('manual_review', 0)}",
                "",
                "### Judge outcomes",
                f"- **Accepted:** {judge.get('ACCEPTED', processing.get('judge_accepted_count', 0))}",
                f"- **Partial / corrected:** {judge.get('PARTIAL', processing.get('judge_partial_count', 0))}",
                f"- **Rejected:** {judge.get('REJECTED', processing.get('judge_rejected_count', 0))}",
            ]
            if authoritative:
                lines.extend(["", "### Deterministic portfolio interpretation", authoritative])
            return "\n".join(lines), compact

        if action == ChatAction.BATCH_STATISTICS:
            completion = insights.get("completion") or {}
            finding_totals = insights.get("finding_item_totals") or {}
            ranked = insights.get("ranked_issue_attributes") or []
            top_text = ", ".join(
                f"{item.get('attribute')} — {item.get('users_affected')} ({item.get('percentage_of_members')}%)"
                for item in ranked[:5]
            ) or "No recurring non-match attribute was found."
            lines = [
                f"## Summary statistics — {batch_id}",
                "",
                "### Member-level statistics",
                f"- **Unique members processed:** {unique_members}",
                f"- **Completion rate:** {completion.get('completion_percentage', 0)}%",
                f"- **Members with any issue:** {population.get('users_with_any_issue', 0)} ({population_pct.get('members_with_any_issue', 0)}%)",
                f"- **Members with exact changes:** {population.get('users_with_exact_changes', 0)} ({population_pct.get('members_with_exact_changes', 0)}%)",
                f"- **Members requiring manual review:** {population.get('users_requiring_manual_review', 0)} ({population_pct.get('members_requiring_manual_review', 0)}%)",
                f"- **Members with a missing source record:** {population.get('users_with_any_missing_source_record', 0)} ({population_pct.get('members_with_missing_source_record', 0)}%)",
                "",
                "### Finding-item statistics",
                f"- **Mismatch items:** {finding_totals.get('mismatches', 0)}",
                f"- **Missing source-member records:** {finding_totals.get('missing_source_member_records', 0)}",
                f"- **Deferred attribute verdicts:** {finding_totals.get('deferred_attribute_verdicts', 0)}",
                f"- **Format/review items:** {finding_totals.get('format_issue_items', 0)}",
                f"- **Unverifiable attribute items:** {finding_totals.get('unverifiable_attribute_items', 0)}",
                f"- **Exact-change items:** {finding_totals.get('exact_change_items', 0)}",
                f"- **Manual-review items:** {finding_totals.get('manual_review_items', 0)}",
                "",
                "### Top attributes by users affected",
                f"- {top_text}",
                "",
                "Member counts and attribute-item counts are different units and are shown separately.",
            ]
            return "\n".join(lines), {"batch_id": batch_id, "batch_insights": insights}

        if action == ChatAction.BATCH_MAJORITY_ISSUE:
            majority = (insights.get("majority_issue") or {}).get("attributes") or []
            ranked_statuses = insights.get("ranked_non_match_statuses") or []
            mismatches = insights.get("top_mismatch_attributes") or []
            format_review = insights.get("top_format_or_review_attributes") or []
            unverifiable = insights.get("top_unverifiable_attributes") or []
            lines = [
                f"## Majority issue — {batch_id}",
                "",
                f"- **By unique members affected:** {self._majority_issue_line(majority)}",
            ]
            if ranked_statuses:
                top_status = ranked_statuses[0]
                lines.append(
                    f"- **Most frequent non-match status:** {top_status.get('status')} with {top_status.get('attribute_items')} attribute-level item(s)."
                )
            if mismatches:
                top_count = mismatches[0].get("count", 0)
                names = ", ".join(str(item.get("attribute")) for item in mismatches if item.get("count") == top_count)
                lines.append(f"- **Most common true mismatch attribute(s):** {names} with {top_count} mismatch item(s) each.")
            if format_review:
                item = format_review[0]
                lines.append(f"- **Largest format/review concentration:** {item.get('attribute')} with {item.get('count')} item(s).")
            if unverifiable:
                top_count = unverifiable[0].get("count", 0)
                names = ", ".join(str(item.get("attribute")) for item in unverifiable if item.get("count") == top_count)
                lines.append(f"- **Largest unverifiable concentration:** {names} with {top_count} item(s) each.")
            lines.extend([
                "",
                "The answer distinguishes users affected from attribute-level findings, so a high item count is not presented as a user count.",
            ])
            return "\n".join(lines), {"batch_id": batch_id, "batch_insights": insights}

        if action == ChatAction.BATCH_SOURCE_COVERAGE:
            coverage = insights.get("source_coverage") or []
            most_missing = insights.get("source_with_most_missing_records") or []
            lines = [f"## Source coverage — {batch_id}", ""]
            for item in coverage:
                lines.append(
                    f"- **{self._friendly_source(item.get('source'))}:** {item.get('found_members')} found "
                    f"({item.get('coverage_percentage')}% coverage), {item.get('missing_member_records')} no-record, "
                    f"{item.get('unavailable_members')} unavailable."
                )
            if most_missing:
                names = ", ".join(self._friendly_source(item.get("source")) for item in most_missing)
                count = most_missing[0].get("missing_member_records", 0)
                lines.extend(["", f"**Source with the most missing member records:** {names} ({count})."])
            else:
                lines.extend(["", "No source-member records were missing."])
            return "\n".join(lines), {"batch_id": batch_id, "source_coverage": coverage}

        if action == ChatAction.BATCH_JUDGE_OUTCOMES:
            distribution = insights.get("judge_distribution") or []
            lines = [f"## Judge outcomes — {batch_id}", ""]
            for item in distribution:
                lines.append(
                    f"- **{item.get('verdict')}:** {item.get('members')} member report(s) ({item.get('percentage_of_members')}%)."
                )
            lines.extend([
                "",
                "Accepted publishes the Analyst result. Partial publishes Judge-corrected content. Rejected suppresses Analyst content and uses deterministic fallback.",
            ])
            return "\n".join(lines), {"batch_id": batch_id, "judge_distribution": distribution}

        if action == ChatAction.BATCH_FINDINGS:
            lines = [
                f"## Bulk findings — {batch_id}",
                "",
                f"Users with exact changes: {population.get('users_with_exact_changes', 0)}. Users requiring manual review: {population.get('users_requiring_manual_review', 0)}. manual-review items: {totals.get('manual_review', 0)}.",
                "",
                f"- **Users with any issue:** {population.get('users_with_any_issue', 0)}",
                f"- **Users with exact changes:** {population.get('users_with_exact_changes', 0)}",
                f"- **Exact-change items:** {totals.get('exact_changes', 0)}",
                f"- **Users requiring manual review:** {population.get('users_requiring_manual_review', 0)}",
                f"- **Manual-review items:** {totals.get('manual_review', 0)}",
                f"- **Missing source-member records:** {source_metrics.get('missing_source_member_records_total', totals.get('missing_records', 0))}",
                f"- **Users affected by a missing source record:** {source_metrics.get('users_with_any_missing_source_record', population.get('users_with_any_missing_source_record', 0))}",
            ]
            top = insights.get("ranked_issue_attributes") or []
            if top:
                lines.extend(["", "### Top issue attributes"] + [
                    f"- **{item.get('attribute')}:** {item.get('users_affected')} user(s) ({item.get('percentage_of_members')}%)."
                    for item in top[:8]
                ])
            exact_members = [m for m in (summary.get("members") or []) if int(m.get("exact_changes") or 0) > 0]
            if exact_members:
                lines.extend(["", "### Users with exact changes"] + [
                    f"- {m.get('email')} ({m.get('exact_changes')}) — {m.get('exact_changes')} exact change(s)."
                    for m in exact_members[:25]
                ])
                if len(exact_members) > 25:
                    lines.append(f"- …and {len(exact_members) - 25} more user(s).")
            return "\n".join(lines), compact

        if action == ChatAction.BATCH_TIMING:
            lines = [
                f"Total batch time: {self._format_ms(timing.get('batch_total_ms'))}",
                f"Dell AIA preflight: {self._format_ms(timing.get('dell_aia_preflight_ms'))}",
                f"Parallel data collection: {self._format_ms(timing.get('data_collection_phase_ms'))}",
                f"Analysis and Judge phase: {self._format_ms(timing.get('analysis_judge_phase_ms'))}",
                f"Aggregation: {self._format_ms(timing.get('aggregation_ms'))}",
                f"Grouped Dell AIA analysis: {self._format_ms(timing.get('group_ai_analysis_ms'))}",
            ]
            member_stats = timing.get("member_stats_ms") or {}
            total_stats = member_stats.get("total_time") or member_stats.get("total") or member_stats.get("end_to_end") or {}
            if total_stats:
                lines.append(
                    "Member end-to-end time — "
                    f"minimum {self._format_ms(total_stats.get('min_ms') or total_stats.get('min'))}, "
                    f"average {self._format_ms(total_stats.get('avg_ms') or total_stats.get('average') or total_stats.get('avg'))}, "
                    f"median {self._format_ms(total_stats.get('median_ms') or total_stats.get('median'))}, "
                    f"maximum {self._format_ms(total_stats.get('max_ms') or total_stats.get('max'))}."
                )
            return "\n".join(lines), {"batch_id": batch_id, "timings": timing}

        if action == ChatAction.BATCH_REPORT_LINKS:
            return (
                f"Batch status: {links['status']}\nGrouped summary: {links['summary']}\nDownload complete report ZIP: {links['download']}",
                {"batch_links": links, "batch_id": batch_id},
            )
        return "No bulk action was selected.", compact

    @staticmethod
    def _analysis_reply(report: dict[str, Any]) -> str:
        summary = str(report.get("deterministic_summary") or "Analysis completed.")
        run_id = report.get("run_id")
        ai = report.get("ai_analysis") or {}
        ai_summary = ai.get("summary") if isinstance(ai, dict) else None
        text = summary
        if ai_summary:
            text += f"\n\nDell AIA analysis: {ai_summary}"
        text += f"\n\nRun ID: {run_id}. Ask for suggestions, source health, timing, or report links."
        return text

    @staticmethod
    def _identity_resolution_summary(report: dict[str, Any]) -> dict[str, Any]:
        """Expose non-secret lookup diagnostics for grounded follow-up answers."""
        records = report.get("records") or {}
        summary: dict[str, Any] = {
            "requested_search_type": report.get("search_type"),
            "lookup_policy": {
                "crowd_twist": ["Email", "ProfileId", "CrowdTwistID"],
                "rewards_db_email_or_profile": ["ProfileId", "CrowdTwistID"],
                "rewards_db_crowd_twist_origin": ["CrowdTwistID", "ProfileId"],
            },
            "sources": {},
        }
        for source in (SourceName.CPS.value, SourceName.REWARDS_DB.value, SourceName.CROWD_TWIST.value):
            record = records.get(source) or {}
            status = record.get("status") or {}
            diagnostics = status.get("diagnostics") or {}
            summary["sources"][source] = {
                "data_found": bool(status.get("data_found")),
                "connected": bool(status.get("connected")),
                "retrieval_method": status.get("retrieval_method"),
                "lookup_result": diagnostics.get("lookup_result"),
                "lookup_order": diagnostics.get("lookup_order"),
                "attempts": diagnostics.get("identifier_lookup_sequence") or diagnostics.get("lookup_attempts") or [],
            }
        return summary

    @staticmethod
    def _compact_report(report: dict[str, Any]) -> dict[str, Any]:
        return {
            "run_id": report.get("run_id"),
            "search_type": report.get("search_type"),
            "search_value": report.get("search_value"),
            "truth_policy": report.get("truth_policy"),
            "analysis_completeness": report.get("analysis_completeness"),
            "deterministic_summary": report.get("deterministic_summary"),
            "counts": {
                "mismatch": report.get("mismatch_count"),
                "missing_attributes": report.get("missing_count"),
                "missing_records": report.get("missing_record_count"),
                "format_issues": report.get("invalid_format_count"),
                "unverifiable": report.get("unverifiable_count"),
                "exact_changes": report.get("actionable_suggestion_count"),
                "manual_review": report.get("manual_review_count"),
            },
            "source_status": report.get("source_status"),
            "identity_resolution": ChatService._identity_resolution_summary(report),
            "attributes": report.get("attributes"),
            "suggestions": report.get("suggestions"),
            "timings": report.get("timings"),
            "ai_analysis": report.get("ai_analysis"),
            "judge_result": report.get("judge_result"),
            "warnings": report.get("warnings"),
        }

    @staticmethod
    def _compact_batch_summary(summary: dict[str, Any], *, members: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        selected_members = members if members is not None else list(summary.get("members") or [])[:50]
        return {
            "batch_id": summary.get("batch_id"),
            "created_at": summary.get("created_at"),
            "input": summary.get("input"),
            "processing": summary.get("processing"),
            "population_metrics": summary.get("population_metrics"),
            "totals": summary.get("totals"),
            "guidance_metrics": summary.get("guidance_metrics"),
            "judge_outcomes": summary.get("judge_outcomes"),
            "issue_status_counts": summary.get("issue_status_counts"),
            "attribute_status_counts": summary.get("attribute_status_counts"),
            "attribute_issue_user_counts": summary.get("attribute_issue_user_counts"),
            "top_issue_attributes": summary.get("top_issue_attributes"),
            "suggestion_target_counts": summary.get("suggestion_target_counts"),
            "source_record_status": summary.get("source_record_status"),
            "source_member_record_metrics": summary.get("source_member_record_metrics"),
            "timings": summary.get("timings"),
            "group_ai_analysis": summary.get("group_ai_analysis"),
            "authoritative_group_summary": summary.get("authoritative_group_summary"),
            "batch_insights": summary.get("batch_insights") or build_batch_insights(summary),
            "members": selected_members,
            "member_rows_in_evidence": len(selected_members),
            "total_member_rows": len(summary.get("members") or []),
        }

    def _batch_evidence_for_question(self, summary: dict[str, Any], question: str) -> dict[str, Any]:
        members = list(summary.get("members") or [])
        email = EMAIL_RE.search(question)
        if email:
            needle = email.group(0).casefold()
            selected = [m for m in members if str(m.get("email") or "").casefold() == needle]
            return self._compact_batch_summary(summary, members=selected)
        lower = question.casefold()
        if any(term in lower for term in ("which user", "which member", "affected user", "affected member", "exact change", "manual review")):
            selected = [m for m in members if int(m.get("exact_changes") or 0) > 0 or int(m.get("manual_review") or 0) > 0]
            return self._compact_batch_summary(summary, members=selected[:100])
        return self._compact_batch_summary(summary, members=members[:50])

    def _response(
        self,
        session_id: str,
        message_id: str,
        reply: str,
        intent: str,
        active_run_id: str | None,
        active_batch_id: str | None,
        base_url: str,
        *,
        structured_data: dict[str, Any] | None = None,
        judge: dict[str, Any] | None = None,
        active_context: str = "none",
    ) -> ChatResponse:
        report_links = self._report_links(base_url, active_run_id) if active_run_id else {}
        batch_links = self._batch_links(base_url, active_batch_id) if active_batch_id else {}
        return ChatResponse(
            session_id=session_id,
            message_id=message_id,
            reply=reply,
            intent=intent,
            active_run_id=active_run_id,
            active_batch_id=active_batch_id,
            report_links=report_links,
            batch_links=batch_links,
            structured_data=structured_data or {},
            judge=judge or {},
            memory={
                "scope": "session",
                "persistent_across_restart": False,
                "active_context": active_context,
                "individual_analysis_available": bool(active_run_id),
                "bulk_analysis_available": bool(active_batch_id),
            },
        )

    @staticmethod
    def _report_links(base_url: str, run_id: str | None) -> dict[str, str]:
        if not run_id:
            return {}
        root = base_url.rstrip("/")
        return {
            "api": f"{root}/api/v1/analysis/{run_id}",
            "html": f"{root}/api/v1/analysis/{run_id}/report.html",
            "json": f"{root}/api/v1/analysis/{run_id}/report.json",
            "html_masked": f"{root}/api/v1/analysis/{run_id}/report.html?masked=true",
            "json_masked": f"{root}/api/v1/analysis/{run_id}/report.json?masked=true",
            "html_unmasked": f"{root}/api/v1/analysis/{run_id}/report.html?masked=false",
            "json_unmasked": f"{root}/api/v1/analysis/{run_id}/report.json?masked=false",
        }

    @staticmethod
    def _batch_links(base_url: str, job_id: str | None) -> dict[str, str]:
        if not job_id:
            return {}
        root = base_url.rstrip("/")
        return {
            "status": f"{root}/api/v1/batches/{job_id}",
            "summary": f"{root}/api/v1/batches/{job_id}/summary",
            "download": f"{root}/api/v1/batches/{job_id}/download",
            "download_masked": f"{root}/api/v1/batches/{job_id}/download?masked=true",
            "download_unmasked": f"{root}/api/v1/batches/{job_id}/download?masked=false",
        }

    @staticmethod
    def _question_targets_batch(text: str) -> bool:
        lower = text.casefold()
        return any(term in lower for term in BATCH_TERMS)

    @staticmethod
    def _individual_to_batch_action(action: ChatAction) -> ChatAction:
        return {
            ChatAction.SUMMARY: ChatAction.BATCH_SUMMARY,
            ChatAction.SUGGESTIONS: ChatAction.BATCH_FINDINGS,
            ChatAction.SOURCE_HEALTH: ChatAction.BATCH_SOURCE_COVERAGE,
            ChatAction.TIMING: ChatAction.BATCH_TIMING,
            ChatAction.REPORT_LINKS: ChatAction.BATCH_REPORT_LINKS,
        }.get(action, ChatAction.BATCH_SUMMARY)

    @staticmethod
    def _majority_issue_line(attributes: list[dict[str, Any]]) -> str:
        if not attributes:
            return "No recurring non-match issue was found."
        names = ", ".join(str(item.get("attribute") or "Unknown") for item in attributes)
        count = int(attributes[0].get("users_affected") or 0)
        percentage = attributes[0].get("percentage_of_members", 0)
        tie = " are tied" if len(attributes) > 1 else " is"
        return f"{names}{tie} highest, affecting {count} member(s) ({percentage}%)."

    @staticmethod
    def _friendly_source(value: Any) -> str:
        return {
            "cps": "CPS",
            "rewards_db": "Rewards DB",
            "crowd_twist": "CrowdTwist",
        }.get(str(value or "").casefold(), str(value or "Unknown source"))

    @staticmethod
    def _format_ms(value: Any) -> str:
        try:
            ms = max(0, int(float(value or 0)))
        except Exception:
            return "—"
        if ms < 1000:
            return f"{ms} ms"
        seconds = ms / 1000
        if seconds < 60:
            return f"{seconds:.2f} s"
        return f"{int(seconds // 60)}m {seconds % 60:.1f}s"

    @staticmethod
    def _help_text() -> str:
        return (
            "I can analyze one member by email, Profile ID, or CrowdTwist ID and explain that result. "
            "I can also remember a bulk TXT/CSV analysis submitted in this same session and answer from its grouped summary and member results. "
            "For governed source updates, you can attach an XLSX/XLSM workbook with CrowdTwistID, ProfileId, or Email plus PropertyName and PropertyValue; an optional Source column may select CrowdTwist or Rewards DB. "
            "Say 'validate first' to preview every row without executing, then 'apply these changes' to run the pending workbook, or attach it with an explicit apply instruction to execute immediately according to your role and Dry Run profile. "
            "Individual examples: 'Analyze user@example.com', 'What should change?', 'Show source health', 'How long did it take?'. "
            "Bulk examples: 'Show the bulk result', 'Show summary statistics', 'What is the majority issue?', "
            "'Which source is missing the most records?', 'Which users have exact changes?', 'Show batch timing', "
            "'What are the Judge outcomes?', or 'Give me the batch ZIP link'. "
            "I can run exact read requests against CPS, Rewards DB, or CrowdTwist, such as 'Run Rewards DB data for user@example.com'. "
            "For a controlled update, use a request such as 'Update CrowdTwist country to US for user@example.com', "
            "'Update Country as suggested', or 'Apply all corrections'. An authorized explicit execution request is itself the approval. "
            "The target is re-read immediately before execution, verified after the write, audited, and then reanalyzed across sources."
        )

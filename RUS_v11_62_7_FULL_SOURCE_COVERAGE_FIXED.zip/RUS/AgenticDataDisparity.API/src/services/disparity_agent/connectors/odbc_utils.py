from __future__ import annotations

import re
from collections import OrderedDict

try:
    import pyodbc  # type: ignore
except ImportError:
    class _MissingPyodbc:
        @staticmethod
        def drivers() -> list[str]:
            return []

    pyodbc = _MissingPyodbc()  # type: ignore[assignment]


_SPLIT_RE = re.compile(r";(?=(?:[^\"']|\"[^\"]*\"|'[^']*')*$)")


def _yes_no(value: str) -> str:
    return "yes" if value.strip().casefold() in {"true", "yes", "1", "sspi"} else "no"


def parse_connection_string(raw: str) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for part in _SPLIT_RE.split(raw or ""):
        if not part.strip() or "=" not in part:
            continue
        key, value = part.split("=", 1)
        pairs.append((key.strip(), value.strip()))
    return pairs


def installed_sql_server_drivers() -> list[str]:
    return [name for name in pyodbc.drivers() if "sql server" in name.casefold()]


def select_sql_server_driver(preferred: str) -> str:
    installed = installed_sql_server_drivers()
    if preferred in installed:
        return preferred
    for candidate in (
        "ODBC Driver 18 for SQL Server",
        "ODBC Driver 17 for SQL Server",
        "SQL Server Native Client 11.0",
        "SQL Server",
    ):
        if candidate in installed:
            return candidate
    if installed:
        return installed[-1]
    raise RuntimeError(
        "No Microsoft SQL Server ODBC driver is installed. Install ODBC Driver 18 for SQL Server."
    )


def normalize_ado_connection_string(raw: str, preferred_driver: str) -> tuple[str, dict[str, object]]:
    """Convert common ADO.NET keywords into a pyodbc-compatible string.

    Spring Config commonly returns an EF/.NET connection string without a DRIVER
    keyword. pyodbc then raises IM002/InterfaceError. This function injects an
    installed SQL Server driver and removes .NET-only keywords.
    """
    if not raw or not raw.strip():
        raise ValueError("Rewards DB connection string is empty")

    aliases = {
        "driver": "DRIVER",
        "server": "SERVER",
        "data source": "SERVER",
        "datasource": "SERVER",
        "address": "SERVER",
        "addr": "SERVER",
        "network address": "SERVER",
        "database": "DATABASE",
        "initial catalog": "DATABASE",
        "initialcatalog": "DATABASE",
        "uid": "UID",
        "user id": "UID",
        "userid": "UID",
        "user": "UID",
        "pwd": "PWD",
        "password": "PWD",
        "trusted_connection": "Trusted_Connection",
        "trusted connection": "Trusted_Connection",
        "integrated security": "Trusted_Connection",
        "integratedsecurity": "Trusted_Connection",
        "encrypt": "Encrypt",
        "trustservercertificate": "TrustServerCertificate",
        "trust server certificate": "TrustServerCertificate",
        "authentication": "Authentication",
        "multipleactiveresultsets": "MARS_Connection",
        "multiple active result sets": "MARS_Connection",
        "application name": "APP",
        "applicationname": "APP",
        "connect timeout": "Connection Timeout",
        "connection timeout": "Connection Timeout",
        "multisubnetfailover": "MultiSubnetFailover",
        "applicationintent": "ApplicationIntent",
        "application intent": "ApplicationIntent",
        "column encryption setting": "ColumnEncryption",
        "columnencryptionsetting": "ColumnEncryption",
        "packet size": "PacketSize",
        "workstation id": "WSID",
    }
    ignored = {
        "persist security info",
        "persistsecurityinfo",
        "pooling",
        "min pool size",
        "max pool size",
        "load balance timeout",
        "enlist",
    }
    output: OrderedDict[str, str] = OrderedDict()
    for key, value in parse_connection_string(raw):
        normalized_key = key.strip().casefold()
        if normalized_key in ignored:
            continue
        mapped = aliases.get(normalized_key)
        if not mapped:
            # Keep ODBC-style keywords, but drop unknown .NET metadata to avoid
            # "invalid connection string attribute" errors from the driver.
            if key.upper() in {
                "PORT", "NETWORK", "APP", "WSID", "LANGUAGE", "FAILOVER_PARTNER",
                "TRANSPARENTNETWORKIPRESOLUTION", "KEYSTOREAUTHENTICATION",
                "KEYSTOREPRINCIPALID", "KEYSTORESECRET",
            }:
                mapped = key
            else:
                continue
        if mapped == "DRIVER":
            value = value.strip("{}")
        elif mapped in {"Trusted_Connection", "TrustServerCertificate", "MultiSubnetFailover"}:
            value = _yes_no(value)
        elif mapped == "MARS_Connection":
            value = _yes_no(value)
        output[mapped] = value

    selected_driver = select_sql_server_driver(output.get("DRIVER", preferred_driver))
    output["DRIVER"] = selected_driver
    # Put DRIVER first for readability and compatibility.
    ordered = OrderedDict([("DRIVER", selected_driver)])
    for key, value in output.items():
        if key != "DRIVER":
            ordered[key] = value

    if "SERVER" not in ordered:
        raise ValueError("Rewards DB connection string does not contain Server/Data Source")
    if "DATABASE" not in ordered:
        raise ValueError("Rewards DB connection string does not contain Database/Initial Catalog")

    parts = []
    for key, value in ordered.items():
        rendered = f"{{{value}}}" if key == "DRIVER" else value
        parts.append(f"{key}={rendered}")
    connection_string = ";".join(parts) + ";"

    auth_mode = "unknown"
    if ordered.get("UID"):
        auth_mode = "sql_user"
    elif ordered.get("Trusted_Connection", "").casefold() == "yes":
        auth_mode = "windows_integrated"
    elif ordered.get("Authentication"):
        auth_mode = "azure_or_federated"

    diagnostics: dict[str, object] = {
        "selected_driver": selected_driver,
        "installed_sql_drivers": installed_sql_server_drivers(),
        "authentication_mode": auth_mode,
        "database_configured": bool(ordered.get("DATABASE")),
        "server_configured": bool(ordered.get("SERVER")),
        "encrypt": ordered.get("Encrypt"),
        "trust_server_certificate": ordered.get("TrustServerCertificate"),
    }
    return connection_string, diagnostics


def extract_sqlstate(exc: BaseException) -> str | None:
    for item in getattr(exc, "args", ()):
        text = str(item)
        match = re.search(r"\b([A-Z0-9]{5})\b", text)
        if match:
            return match.group(1)
    return None


def sqlstate_hint(sqlstate: str | None) -> str:
    if sqlstate == "IM002":
        return "The configured ODBC driver/DSN was not found. Install Microsoft ODBC Driver 18 or use an installed SQL Server driver."
    if sqlstate in {"08001", "08004", "08S01"}:
        return "The SQL Server could not be reached or rejected the connection. Confirm Dell VPN, DNS, firewall, server name, and environment."
    if sqlstate == "28000":
        return "SQL authentication failed. Verify the database user/password or integrated-auth configuration from Spring Config."
    if sqlstate in {"HYT00", "HYT01"}:
        return "The database connection timed out. Confirm network access and SQL Server availability."
    if sqlstate in {"42S02", "S0002"}:
        return "The configured Rewards member table was not found. Verify schema and table names."
    if sqlstate == "42000":
        return "SQL Server rejected the query or the account lacks permission. Verify SELECT access to the member table."
    return "Review the installed ODBC driver, Dell VPN/network access, database credentials, and member table configuration."

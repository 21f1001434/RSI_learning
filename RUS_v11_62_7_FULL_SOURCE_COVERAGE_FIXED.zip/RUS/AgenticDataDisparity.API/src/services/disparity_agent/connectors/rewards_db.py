from __future__ import annotations

import asyncio
from time import perf_counter
from typing import Any

try:
    import pyodbc  # type: ignore
except ImportError:
    class _MissingPyodbc:
        class Error(Exception):
            pass

        @staticmethod
        def connect(*_args: Any, **_kwargs: Any) -> Any:
            raise RuntimeError(
                "pyodbc or its native ODBC library is unavailable. Install unixODBC on Linux "
                "and Microsoft ODBC Driver 18 before using Rewards DB."
            )

    pyodbc = _MissingPyodbc()  # type: ignore[assignment]

from ..models import SearchType, SourceName, SourceRecord, SourceStatus
from ..settings import Settings
from .odbc_utils import extract_sqlstate, normalize_ado_connection_string, sqlstate_hint


class RewardsDBConnector:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    async def fetch(
        self,
        search_type: SearchType,
        search_value: str,
        resolved_profile_id: str | None = None,
        resolved_crowd_twist_id: int | None = None,
    ) -> SourceRecord:
        started = perf_counter()
        try:
            payload, diagnostics = await asyncio.to_thread(
                self._fetch_sync,
                search_type,
                search_value,
                resolved_profile_id,
                resolved_crowd_twist_id,
            )
            latency = int((perf_counter() - started) * 1000)
            return SourceRecord(
                source=SourceName.REWARDS_DB,
                status=SourceStatus(
                    source=SourceName.REWARDS_DB,
                    connected=True,
                    data_found=payload is not None,
                    latency_ms=latency,
                    retrieval_method=str(diagnostics.get("lookup_result", "direct")),
                    stage="complete",
                    diagnostics=diagnostics,
                    diagnostic_hint=(
                        None
                        if payload is not None
                        else (
                            "The database connection succeeded. Rewards DB was searched sequentially by "
                            + " -> ".join(str(item) for item in diagnostics.get("lookup_order", []))
                            + ". No member row matched any available identifier."
                        )
                    ),
                ),
                raw=payload,
            )
        except (ValueError, RuntimeError) as exc:
            return SourceRecord(
                source=SourceName.REWARDS_DB,
                status=SourceStatus(
                    source=SourceName.REWARDS_DB,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error=str(exc),
                    stage="driver_or_configuration",
                    error_code="DB_CONFIGURATION_ERROR",
                    diagnostic_hint="Install Microsoft ODBC Driver 18 and verify the DellRewardsConnection value loaded from Spring Config.",
                ),
            )
        except pyodbc.Error as exc:
            sqlstate = extract_sqlstate(exc)
            return SourceRecord(
                source=SourceName.REWARDS_DB,
                status=SourceStatus(
                    source=SourceName.REWARDS_DB,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error=f"Rewards DB connection/query failed{f' (SQLSTATE {sqlstate})' if sqlstate else ''}.",
                    stage="connect_or_query",
                    error_code=f"ODBC_{sqlstate}" if sqlstate else "ODBC_ERROR",
                    diagnostic_hint=sqlstate_hint(sqlstate),
                    diagnostics={"sqlstate": sqlstate} if sqlstate else {},
                ),
            )
        except Exception as exc:
            return SourceRecord(
                source=SourceName.REWARDS_DB,
                status=SourceStatus(
                    source=SourceName.REWARDS_DB,
                    connected=False,
                    data_found=False,
                    latency_ms=int((perf_counter() - started) * 1000),
                    error=f"{type(exc).__name__}: Rewards DB query failed.",
                    stage="connect_or_query",
                    error_code="DB_UNEXPECTED_ERROR",
                    diagnostic_hint="Review the terminal log and the non-secret database diagnostics shown in the report.",
                ),
            )

    def _fetch_sync(
        self,
        search_type: SearchType,
        search_value: str,
        resolved_profile_id: str | None,
        resolved_crowd_twist_id: int | None,
    ) -> tuple[dict[str, Any] | None, dict[str, object]]:
        """Look up a Rewards member with origin-aware sequential identifiers.

        Email/Profile-ID requests preserve the approved ProfileId -> CrowdTwistID
        order. A CrowdTwist-ID-originated request uses the supplied CrowdTwistID
        first, then the ProfileId extracted from CrowdTwist as the fallback. The
        two keys are never combined in one SQL predicate, so every attempt stays
        explicit and auditable.
        """
        profile_id = resolved_profile_id or (
            search_value if search_type == SearchType.PROFILE_ID else None
        )
        crowd_twist_id = resolved_crowd_twist_id or (
            int(search_value)
            if search_type == SearchType.CROWD_TWIST_ID and str(search_value).isdigit()
            else None
        )
        lookup_order = (
            ["CrowdTwistID", "ProfileId"]
            if search_type == SearchType.CROWD_TWIST_ID
            else ["ProfileId", "CrowdTwistID"]
        )
        values: dict[str, Any] = {
            "ProfileId": profile_id,
            "CrowdTwistID": crowd_twist_id,
        }

        if not profile_id and crowd_twist_id is None:
            return None, {
                "lookup_order": lookup_order,
                "lookup_attempts": [
                    {
                        "key": key,
                        "attempted": False,
                        "rows_found": None,
                        "reason": f"{key} was not resolved.",
                    }
                    for key in lookup_order
                ],
                "lookup_key": "none",
                "lookup_result": "no_resolved_identifier",
                "fallback_used": False,
                "reason": "No ProfileId or CrowdTwistID could be resolved from CPS/CrowdTwist.",
            }

        connection_string, diagnostics = normalize_ado_connection_string(
            self.settings.db_connection_string,
            self.settings.rewards_db_driver,
        )
        diagnostics["schema"] = self.settings.rewards_db_schema
        diagnostics["table"] = self.settings.rewards_db_member_table
        diagnostics["lookup_order"] = lookup_order
        diagnostics["lookup_attempts"] = []
        diagnostics["origin_search_type"] = search_type.value
        table = f"[{self.settings.rewards_db_schema}].[{self.settings.rewards_db_member_table}]"

        with pyodbc.connect(
            connection_string,
            timeout=max(1, int(self.settings.request_timeout_seconds)),
        ) as connection:
            cursor = connection.cursor()
            attempted_count = 0
            for key in lookup_order:
                value = values[key]
                if value in (None, ""):
                    diagnostics["lookup_attempts"].append(
                        {
                            "key": key,
                            "attempted": False,
                            "rows_found": None,
                            "reason": f"{key} was not resolved.",
                        }
                    )
                    continue
                attempted_count += 1
                row = self._query_unique_member(
                    cursor=cursor,
                    table=table,
                    column_name=key,
                    value=value,
                    diagnostics=diagnostics,
                )
                if row is not None:
                    direct_key = lookup_order[0]
                    diagnostics.update(
                        {
                            "lookup_key": key,
                            "lookup_result": (
                                "crowd_twist_id_match" if key == "CrowdTwistID" and key == direct_key
                                else "profile_id_match" if key == "ProfileId" and key == direct_key
                                else "crowd_twist_id_fallback_match" if key == "CrowdTwistID"
                                else "profile_id_fallback_match"
                            ),
                            "fallback_used": key != direct_key,
                        }
                    )
                    return row, diagnostics

        attempted_keys = [
            item["key"]
            for item in diagnostics["lookup_attempts"]
            if item.get("attempted")
        ]
        diagnostics.update(
            {
                "lookup_key": "none",
                "lookup_result": "no_value_found",
                "fallback_used": attempted_count > 1,
                "attempted_keys": attempted_keys,
                "reason": "No Rewards DB member row matched any available identifier.",
            }
        )
        return None, diagnostics

    @staticmethod
    def _query_unique_member(
        *,
        cursor: Any,
        table: str,
        column_name: str,
        value: Any,
        diagnostics: dict[str, object],
    ) -> dict[str, Any] | None:
        """Execute one unique-key lookup and append non-secret diagnostics."""
        sql = f"SELECT TOP (2) * FROM {table} WHERE {column_name} = ?"
        cursor.execute(sql, [value])
        columns = [column[0] for column in cursor.description]
        rows = cursor.fetchall()
        attempts = diagnostics.setdefault("lookup_attempts", [])
        assert isinstance(attempts, list)
        attempts.append(
            {
                "key": column_name,
                "attempted": True,
                "rows_found": len(rows),
            }
        )
        if not rows:
            return None
        if len(rows) > 1:
            raise RuntimeError(
                f"Multiple Rewards DB member rows matched the supposedly unique {column_name} identifier"
            )
        return {columns[index]: rows[0][index] for index in range(len(columns))}

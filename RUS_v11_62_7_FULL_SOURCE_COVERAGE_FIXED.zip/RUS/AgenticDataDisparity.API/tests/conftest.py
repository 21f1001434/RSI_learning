from __future__ import annotations
import os

# Unit tests must remain deterministic even when a shared CI job injects live settings.
os.environ["USE_MOCK_SOURCES"] = "true"
os.environ["BOOTSTRAP_FROM_SPRING_CONFIG"] = "false"
os.environ["API_REQUIRE_INTERNAL_KEY"] = "false"

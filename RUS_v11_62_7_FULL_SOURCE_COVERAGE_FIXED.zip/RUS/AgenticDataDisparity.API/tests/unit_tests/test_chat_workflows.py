"""Session behavior, evidence routing, model failures and post-write refresh."""
import asyncio
import json
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, MagicMock

import pytest

from tests.unit_tests.test_execution_workflows import configured, report_for, run, record
from src.services.disparity_agent.api.chat_service import ChatService, BATCH_ACTIONS
from src.services.disparity_agent.api.config import ApiSettings
from src.services.disparity_agent.api.run_store import RunStore
from src.services.disparity_agent.api.schemas import ChatAction, ChatRequest, ChatContext
from src.services.disparity_agent.api.session_store import InMemorySessionStore
from src.services.disparity_agent.api.source_operations import SourceOperationService, SourceOperationError
from src.services.disparity_agent.models import SearchType, SourceName
from src.services.disparity_agent.batch import aggregate_batch, parse_email_list


def chat(tmp_path,source=True):
    s=configured(tmp_path)
    sessions=InMemorySessionStore(ttl_minutes=60,max_messages=50,max_sessions=20)
    sources=SourceOperationService(s,sessions) if source else None
    return ChatService(settings=s,api_settings=ApiSettings(batch_output_dir=tmp_path/'batch'),sessions=sessions,runs=RunStore(s),ai_semaphore=asyncio.Semaphore(1),source_operations=sources)


def summary_for(report):
    return aggregate_batch('BATCH-TEST',parse_email_list('a.txt',b'member@example.com'),[{'email':'member@example.com','report':report,'error':None}])


@pytest.mark.parametrize('action',[ChatAction.SUMMARY,ChatAction.SUGGESTIONS,ChatAction.SOURCE_HEALTH,ChatAction.TIMING,ChatAction.REPORT_LINKS])
@pytest.mark.parametrize('context',['individual','none','batch'])
def test_quick_actions_read_the_current_session_evidence(tmp_path,action,context):
    c=chat(tmp_path,False); report=report_for(tmp_path).model_dump(mode='json')
    async def exercise():
        state=await c.sessions.create()
        if context=='individual': await c.sessions.set_active_report(state.session_id,report)
        if context=='batch': await c.sessions.set_active_batch_result(state.session_id,job_id='JOB-AAAAAAAAAAAAAAAA',batch_id='BATCH-TEST',summary=summary_for(report))
        r=await c.handle(ChatRequest(session_id=state.session_id,message='quick action',action=action), 'https://example.test')
        assert r.reply and r.memory['active_context']==context
        assert r.intent==('no_active_analysis' if context=='none' else c._individual_to_batch_action(action).value if context=='batch' else action.value)
        assert len(state.messages)==2
    run(exercise())


@pytest.mark.parametrize('action',list(BATCH_ACTIONS))
@pytest.mark.parametrize('populated',[False,True])
def test_bulk_questions_keep_member_and_finding_counts_separate(tmp_path,action,populated):
    c=chat(tmp_path,False); report=report_for(tmp_path).model_dump(mode='json')
    summary=summary_for(report) if populated else aggregate_batch('BATCH-EMPTY',{},[])
    async def exercise():
        state=await c.sessions.create()
        await c.sessions.set_active_batch_result(state.session_id,job_id='JOB-AAAAAAAAAAAAAAAA',batch_id=summary['batch_id'],summary=summary)
        r=await c.handle(ChatRequest(session_id=state.session_id,message='bulk question',action=action),'https://example.test')
        assert r.intent==action.value and r.memory['active_context']=='batch'
        assert r.reply and r.batch_links['status'].endswith(state.active_batch_id)
    run(exercise())


@pytest.mark.parametrize('message,expected',[
 ('help','help'),('reset','reset'),('analyze member@example.com','analyze'),('show cps data','source_cps'),
 ('update country to US','source_change'),('suggest changes','suggestions'),('source health','source_health'),
 ('how long','timing'),('download report','report_links'),('summary','summary'),('member member@example.com','analyze'),
 ('bulk majority issue','batch_majority_issue'),('bulk percentage','batch_statistics'),('bulk source coverage','batch_source_coverage'),
 ('bulk judge outcomes','batch_judge_outcomes'),('bulk progress','batch_status'),('bulk timing','batch_timing'),
 ('batch zip','batch_report_links'),('bulk findings','batch_findings'),('bulk summary','batch_summary'),('explain further','auto')])
def test_natural_language_intent_routing(tmp_path,message,expected):
    c=chat(tmp_path,False)
    assert c._resolve_intent(ChatRequest(session_id='S',message=message),None)[0].value==expected


def test_chat_help_reset_analysis_and_metadata(tmp_path,monkeypatch):
    import src.services.disparity_agent.agents.orchestrator as m
    c=chat(tmp_path); report=report_for(tmp_path)
    fake=NS(run=AsyncMock(return_value=report)); monkeypatch.setattr(m,'AgenticOrchestrator',lambda *a,**k:fake)
    async def exercise():
        state=await c.sessions.create()
        for action in [ChatAction.HELP,ChatAction.ANALYZE]:
            r=await c.handle(ChatRequest(session_id=state.session_id,message='help',action=action),'http://test')
            assert r.intent==('help' if action==ChatAction.HELP else 'analyze_missing_identifier')
        r=await c.handle(ChatRequest(session_id=state.session_id,message='run full analysis member@example.com',actor='Tester',actor_email='tester@example.com',actor_role='Admin',actor_dry_run_enabled=True),'http://test')
        assert r.intent=='analyze' and state.active_run_id==report.run_id
        assert state.metadata['actor_dry_run_enabled'] is False
        assert (await c.runs.get(report.run_id))['run_id']==report.run_id
        fake.run.side_effect=RuntimeError('source failed')
        with pytest.raises(RuntimeError): await c._run_analysis_for_session(session_id=state.session_id,state=state,search_type=SearchType.EMAIL,search_value='a@example.com')
        r=await c.handle(ChatRequest(session_id=state.session_id,message='reset'),'http://test')
        assert r.intent=='reset' and state.last_report is None
    run(exercise())


@pytest.mark.parametrize('mode',['individual','attribute','batch','pending_batch','no_context'])
def test_followup_evidence_selection(tmp_path,monkeypatch,mode):
    c=chat(tmp_path,False); report=report_for(tmp_path).model_dump(mode='json')
    follow=AsyncMock(return_value=('Grounded response',{'verdict':'ACCEPTED'})); monkeypatch.setattr(c,'_grounded_evidence_followup',follow)
    async def exercise():
        state=await c.sessions.create()
        if mode in {'individual','attribute'}: await c.sessions.set_active_report(state.session_id,report)
        if mode=='batch': await c.sessions.set_active_batch_result(state.session_id,job_id='JOB-AAAAAAAAAAAAAAAA',batch_id='BATCH-TEST',summary=summary_for(report))
        if mode=='pending_batch': await c.sessions.set_active_batch(state.session_id,'JOB-AAAAAAAAAAAAAAAA')
        message='explain country' if mode=='attribute' else 'explain reasoning'
        r=await c.handle(ChatRequest(session_id=state.session_id,message=message),'http://test')
        expected={'individual':'follow_up','attribute':'attribute_follow_up','batch':'batch_follow_up','pending_batch':'batch_status','no_context':'no_active_analysis'}[mode]
        assert r.intent==expected
        assert follow.await_count==(1 if mode in {'individual','batch'} else 0)
    run(exercise())


@pytest.mark.parametrize('judge_answer', ['{"verdict":"ACCEPTED"}','{"verdict":"REJECTED","corrected_response":"Verified correction"}','{"verdict":"REJECTED"}','bad judge JSON','OFF','MODEL_FAIL','AUTH_FAIL'])
def test_grounded_chat_judge_and_model_failure_behavior(tmp_path,monkeypatch,judge_answer):
    import autogen_agentchat.agents as agents
    import src.services.disparity_agent.agents.model_client as mc
    c=chat(tmp_path,False)
    build=AsyncMock(side_effect=RuntimeError('auth failed') if judge_answer=='AUTH_FAIL' else None,return_value=object())
    close=AsyncMock()
    monkeypatch.setattr(mc,'build_model_client',build); monkeypatch.setattr(mc,'close_model_client',close)
    def agent(**kw):
        text=judge_answer if kw['name'].endswith('judge') else 'Unverified model narrative'
        return NS(run=AsyncMock(side_effect=RuntimeError('model down') if judge_answer=='MODEL_FAIL' else None,return_value=NS(messages=[NS(content=text)])))
    monkeypatch.setattr(agents,'AssistantAgent',agent)
    reply,judge=run(c._grounded_evidence_followup(question='why',evidence={'deterministic_summary':'Verified evidence'},evidence_type='individual_analysis',history=[],judge_enabled=judge_answer!='OFF'))
    if judge_answer in {'bad judge JSON','{"verdict":"REJECTED"}'}:
        assert reply=='Verified evidence' and judge['content_disposition']=='ANALYST_SUPPRESSED'
    elif 'corrected_response' in judge_answer: assert reply=='Verified correction'
    elif judge_answer.endswith('FAIL'): assert judge['status']=='FAILED'
    else: assert reply=='Unverified model narrative'
    assert close.await_count==(0 if judge_answer=='AUTH_FAIL' else 1)


def test_chat_retry_parser_and_attribute_capabilities(tmp_path,monkeypatch):
    import src.services.disparity_agent.api.chat_service as m
    c=chat(tmp_path,False); report=report_for(tmp_path).model_dump(mode='json')
    monkeypatch.setattr(m.asyncio,'sleep',AsyncMock())
    agent=NS(run=AsyncMock(side_effect=[RuntimeError('HTTP 429'),'ok']))
    assert run(c._run_with_retry(agent,'question'))=='ok'
    for text in ['```json\n{"ok":true}\n```','prefix {"ok":true} tail']: assert c._parse_json(text)=={'ok':True}
    for text in ['{broken}','[]','plain']: assert c._parse_json(text) is None
    assert c._last_text(NS(messages=[NS(content=[])]))==''
    assert c._format_ms('invalid')=='—' and 'm' in c._format_ms(65000)
    assert c._deterministic_attribute_followup('what can you update',report)[1]['capability']
    for field in ['country','email','first name','profile id','is active']:
        assert c._deterministic_attribute_followup('can you explain '+field,report)[1]['field']
    assert c._deterministic_attribute_followup('random question',report) is None
    for question in ['member@example.com','which users have exact changes','anything']:
        assert 'members' in c._batch_evidence_for_question(summary_for(report),question)
    assert c._deterministic_action(ChatAction.AUTO,report,'http://test')[1]=={}
    assert c._report_links('http://test',None)=={} and c._batch_links('http://test',None)=={}


def test_cps_chat_read_selection_and_deduplication(tmp_path,monkeypatch):
    import src.services.disparity_agent.api.chat_service as m
    c=chat(tmp_path,False)
    fetch=AsyncMock(return_value=record(SourceName.CPS,True,True,{'profileId':'pid'}))
    monkeypatch.setattr(m,'CPSConnector',lambda s:NS(fetch=fetch))
    async def exercise():
        state=await c.sessions.create()
        state.last_batch_summary={'members':[{'email':'alice@example.com'},{'email':'alice2@example.com'}]}
        r=await c.handle(ChatRequest(session_id=state.session_id,message='show cps alice'),'http://test')
        assert r.structured_data['status']=='selection_required'
        r=await c.handle(ChatRequest(session_id=state.session_id,message='all'),'http://test')
        assert r.structured_data['requested_count']==2
        reply,result=await c._run_cps_for_emails(['a@example.com','A@example.com','bad',''])
        assert result['requested_count']==1
        reply,result=await c._handle_cps_source_request(ChatRequest(session_id=state.session_id,message='show cps nobody'),state)
        assert result['status']=='email_required'
        reply,result=await c._handle_cps_source_request(ChatRequest(session_id=state.session_id,message='show cps alice2'),state)
        assert result['requested_count']==1
    run(exercise())


@pytest.mark.parametrize('mode',['success','failure','no_identifier','dry_run','no_next'])
def test_post_write_refresh_invalidates_stale_suggestions(tmp_path,monkeypatch,mode):
    c=chat(tmp_path); report=report_for(tmp_path).model_dump(mode='json')
    c.source_operations.invalidate_suggested_change_queue_after_live_write=AsyncMock()
    c.source_operations.plan_suggested_change_from_report=AsyncMock(return_value={'change_id':'CHG-AAAAAAAAAAAA','source':'crowd_twist'},side_effect=SourceOperationError('NONE','no safe next change') if mode=='no_next' else None)
    c._run_analysis_for_session=AsyncMock(return_value=report,side_effect=RuntimeError('offline') if mode=='failure' else None)
    async def exercise():
        state=await c.sessions.create({'actor_role':'Business'})
        change={'status':'DRY_RUN_COMPLETED' if mode=='dry_run' else 'COMPLETED','results':[{'success':True}],'suggested_change':True,'next_change':{'stale':True},'targets':[] if mode=='no_identifier' else [{'email':'member@example.com'}]}
        result=await c.refresh_after_source_change(state.session_id,change)
        if mode in {'success','no_next'}: assert result['run_id']==report['run_id']
        else: assert result is None
        if mode!='dry_run':
            c.source_operations.invalidate_suggested_change_queue_after_live_write.assert_awaited_once()
            assert change.get('next_change')!={'stale':True}
        if mode=='failure': assert change['post_write_analysis']['status']=='FAILED'
        if mode=='no_identifier': assert change['post_write_analysis']['status']=='SKIPPED'
        await c._record_adaptive_write_outcome(state,change)
        await c._record_adaptive_write_outcome(state,{})
    run(exercise())


@pytest.mark.parametrize('intent',['error','source_confirm_2','spreadsheet_updates_executed','source_change_analysis_required'])
def test_source_change_chat_routing(tmp_path,monkeypatch,intent):
    c=chat(tmp_path); report=report_for(tmp_path).model_dump(mode='json')
    completed={'status':'COMPLETED','targets':[{'email':'member@example.com'}],'results':[{'success':True,'verified':True}],'source':'crowd_twist'}
    structured={'change':completed} if intent=='source_confirm_2' else {'spreadsheet_update':{'completed_changes':[completed,completed,{'status':'FAILED'}]}} if intent=='spreadsheet_updates_executed' else {'identifier':{'search_type':'email','value':'member@example.com'}}
    c.source_operations.handle_chat=AsyncMock(side_effect=SourceOperationError('DENIED','blocked') if intent=='error' else [(intent,'reply',structured),None])
    c.refresh_after_source_change=AsyncMock(return_value=report)
    c._run_analysis_for_session=AsyncMock(return_value=report)
    async def exercise():
        state=await c.sessions.create({'actor_role':'Business'})
        r=await c.handle(ChatRequest(session_id=state.session_id,message='update country to US'),'http://test')
        assert r.intent==('source_operation_error' if intent=='error' else 'source_change_needs_details' if intent=='source_change_analysis_required' else intent)
        if intent in {'source_confirm_2','spreadsheet_updates_executed'}: c.refresh_after_source_change.assert_awaited_once()
    run(exercise())

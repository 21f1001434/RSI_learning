import asyncio
import json
import io
import zipfile
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from tests.unit_tests.test_execution_workflows import run, configured, report_for, record
from src.services.disparity_agent.models import SearchType, SourceName
from src.services.disparity_agent.api.config import ApiSettings
from src.services.disparity_agent.api.session_store import InMemorySessionStore


class HTTP:
    def __init__(self,response): self.response=response; self.requests=[]
    async def __aenter__(self): return self
    async def __aexit__(self,*a): pass
    async def request(self,*a,**k):
        self.requests.append((a,k))
        if isinstance(self.response,Exception): raise self.response
        return self.response
    get=post=put=request


@pytest.mark.parametrize('status,payload,error',[(200,{'id':12},None),(200,None,None),(200,'invalid','CT_INVALID_JSON'),(404,{},'HTTP_404'),(403,{},'HTTP_403'),(500,{},'HTTP_500'),(0,{},'CT_TIMEOUT'),(-1,{},'CT_NETWORK_ERROR')])
def test_crowdtwist_transport_classifies_real_http_responses(tmp_path,monkeypatch,status,payload,error):
    import src.services.disparity_agent.connectors.crowd_twist as m
    c=m.CrowdTwistConnector(configured(tmp_path))
    c.tokens.get_token=AsyncMock(return_value='token')
    response=httpx.Response(status,request=httpx.Request('GET','https://ct.example.test'),content=json.dumps(payload)) if status>0 and payload!='invalid' else httpx.Response(200,text='not json')
    if status==0: response=httpx.TimeoutException('timeout')
    if status==-1: response=httpx.RequestError('offline')
    transport=HTTP(response)
    monkeypatch.setattr(m.httpx,'AsyncClient',lambda **k:transport)
    result=run(c.fetch(SearchType.EMAIL,'a+b@example.com'))
    assert result.status.error_code==error
    assert result.status.data_found == (status==200 and isinstance(payload,dict))
    assert transport.requests[0][1]['params']['id_type']=='email'
    assert transport.requests[0][1]['headers']['Authorization']=='Bearer token'


def test_crowdtwist_auth_and_ext_write_contract(tmp_path,monkeypatch):
    import src.services.disparity_agent.connectors.crowd_twist as m
    from src.services.disparity_agent.connectors.oauth import TokenAcquisitionError
    c=m.CrowdTwistConnector(configured(tmp_path))
    c.tokens.get_token=AsyncMock(side_effect=TokenAcquisitionError('bad',code='AUTH'))
    assert run(c.fetch(SearchType.PROFILE_ID,'pid')).status.stage=='oauth_token'
    with pytest.raises(RuntimeError): run(c.update_user('12',{}))
    s=configured(tmp_path,crowd_twist_auth_url='https://auth.example.test',crowd_twist_update_base_url='https://ct.example.test',crowd_twist_update_client_id='c',crowd_twist_update_client_secret='s',crowd_twist_api_key='key')
    c=m.CrowdTwistConnector(s); c.update_tokens.get_token=AsyncMock(return_value='t')
    transport=HTTP(httpx.Response(200,json={'updated':True}))
    monkeypatch.setattr(m.httpx,'AsyncClient',lambda **k:transport)
    response,family=run(c.update_user('12/3',{'country':'US'}))
    assert family=='Ext/update' and response.status_code==200
    assert transport.requests[0][1]['json']=={'country':'US'}
    assert '12%2F3' in transport.requests[0][0][0]


@pytest.mark.parametrize('origin,rows',[(SearchType.EMAIL,[[('p',11)]]),(SearchType.EMAIL,[[],[('p',11)]]),(SearchType.CROWD_TWIST_ID,[[('p',11)]]),(SearchType.PROFILE_ID,[[],[]])])
def test_rewards_db_parameterized_lookup_and_fallback(tmp_path,monkeypatch,origin,rows):
    import src.services.disparity_agent.connectors.rewards_db as m
    cursor=MagicMock(); cursor.description=[('ProfileId',),('CrowdTwistID',)]; cursor.fetchall.side_effect=rows
    connection=MagicMock(); connection.__enter__.return_value=connection; connection.cursor.return_value=cursor
    monkeypatch.setattr(m.pyodbc,'connect',lambda *a,**k:connection)
    monkeypatch.setattr(m,'normalize_ado_connection_string',lambda *a:('driver',{}))
    c=m.RewardsDBConnector(configured(tmp_path))
    result=run(c.fetch(origin,'11',resolved_profile_id='p',resolved_crowd_twist_id=11))
    assert result.status.connected and result.status.data_found==bool(rows[-1])
    for call in cursor.execute.call_args_list:
        assert ' = ?' in call.args[0] and isinstance(call.args[1],list)
    if len(rows)==2 and rows[-1]: assert result.status.diagnostics['fallback_used']
    no_ids=run(c.fetch(SearchType.EMAIL,'email@example.com'))
    assert no_ids.status.diagnostics['lookup_result']=='no_resolved_identifier'


def test_rewards_db_duplicate_and_configuration_failures(tmp_path,monkeypatch):
    import src.services.disparity_agent.connectors.rewards_db as m
    c=m.RewardsDBConnector(configured(tmp_path))
    for exception,code in [(ValueError('missing driver'),'DB_CONFIGURATION_ERROR'),(m.pyodbc.Error('08001','secret'),'ODBC_08001'),(m.pyodbc.Error('other'),'ODBC_ERROR'),(Exception('secret'),'DB_UNEXPECTED_ERROR')]:
        monkeypatch.setattr(c,'_fetch_sync',MagicMock(side_effect=exception))
        result=run(c.fetch(SearchType.PROFILE_ID,'pid'))
        assert not result.status.connected and result.status.error_code==code
        assert 'secret' not in (result.status.error or '')
    cursor=MagicMock(); cursor.description=[('Id',)]; cursor.fetchall.return_value=[(1,),(2,)]
    with pytest.raises(RuntimeError,match='Multiple'):
        c._query_unique_member(cursor=cursor,table='[dbo].[Member]',column_name='ProfileId',value='p',diagnostics={})


@pytest.mark.parametrize('failure',[None,'collection','context','analysis','preflight'])
def test_two_phase_batch_isolation_and_failed_members(tmp_path,monkeypatch,failure):
    import src.services.disparity_agent.batch as m
    import src.services.disparity_agent.agents as agents
    import src.services.disparity_agent.agents.model_client as mc
    template=report_for(tmp_path)
    calls=[]
    class Orch:
        def __init__(self,*a,**kw): pass
        async def collect_data(self,kind,email):
            calls.append(('collect',email))
            if failure=='collection' and email.startswith('b'): raise RuntimeError('source unavailable')
            r=template.model_copy(deep=True); r.search_value='wrong@example.com' if failure=='context' else email
            return r,{}
        async def analyze_and_judge(self,r,bundle,kind,email):
            calls.append(('analyze',email))
            if failure=='analysis' and email.startswith('b'): raise RuntimeError('judge unavailable')
            return r
    monkeypatch.setattr(agents,'AgenticOrchestrator',Orch)
    monkeypatch.setattr(mc,'probe_dell_aia_runtime',AsyncMock(return_value={'ok':failure!='preflight'}))
    parsed=m.parse_email_list('x.txt',b'a@example.com\nb@example.com\na@example.com')
    monkeypatch.setattr(m,'_group_ai_analysis',AsyncMock(return_value={'status':'TEST'}))
    if failure=='preflight':
        with pytest.raises(RuntimeError,match='preflight failed'): run(m.run_batch(configured(tmp_path),parsed))
        assert not calls
        return
    summary,items=run(m.run_batch(configured(tmp_path),parsed,max_parallel=99,max_parallel_ai=99,include_group_ai=True))
    assert summary['processing']['source_parallelism']==8 and summary['processing']['dell_aia_parallelism']==2
    assert summary['processing']['failed_count']==(0 if failure is None else 2 if failure=='context' else 1)
    assert len(items)==2 and calls[:2]==[('collect','a@example.com'),('collect','b@example.com')]
    assert all('report_obj' not in item for item in items)
    summary,items=run(m.run_batch(configured(tmp_path),{'emails':[]},include_group_ai=False))
    assert not items and summary['dell_aia_preflight']['status']=='SKIPPED'


@pytest.mark.parametrize('answer',['{"portfolio_interpretation":"grounded"}','not json','429','error'])
def test_group_analysis_preserves_deterministic_counts(tmp_path,monkeypatch,answer):
    import src.services.disparity_agent.batch as m
    import src.services.disparity_agent.agents.model_client as mc
    import autogen_agentchat.agents as agents
    summary=m.aggregate_batch('BATCH-T',m.parse_email_list('a.txt',b'a@example.com'),[])
    agent=NS(run=AsyncMock(return_value=NS(messages=[NS(content=answer,source='assistant')])))
    if answer=='error': agent.run.side_effect=RuntimeError('model unavailable')
    if answer=='429': agent.run.side_effect=[RuntimeError('HTTP 429'),NS(messages=[NS(content='{}',source='assistant')])]
    monkeypatch.setattr(m.asyncio,'sleep',AsyncMock())
    monkeypatch.setattr(agents,'AssistantAgent',lambda *a,**k:agent)
    monkeypatch.setattr(mc,'build_model_client',AsyncMock(return_value=object()))
    monkeypatch.setattr(mc,'close_model_client',AsyncMock())
    result=run(m._group_ai_analysis(configured(tmp_path),summary))
    assert result['count_guard_applied']
    assert result['analysis']['authoritative_metrics']==m.deterministic_group_analysis(summary)['analysis']['authoritative_metrics']
    assert result['status']==('DETERMINISTIC_FALLBACK' if answer=='error' else 'SUCCESS_WITH_DETERMINISTIC_NORMALIZATION' if answer=='not json' else 'SUCCESS')


@pytest.mark.parametrize('fail',[False,True])
def test_batch_job_lifecycle_session_and_download(tmp_path,monkeypatch,fail):
    import src.services.disparity_agent.api.batch_jobs as m
    import src.services.disparity_agent.batch as batch
    s=configured(tmp_path); a=ApiSettings(batch_output_dir=tmp_path/'batches',batch_max_emails=2)
    parsed=batch.parse_email_list('a.txt',b'a@example.com')
    summary=batch.aggregate_batch('BATCH-TEST',parsed,[])
    calls=AsyncMock(side_effect=RuntimeError('offline') if fail else None,return_value=(summary,[]))
    monkeypatch.setattr(m,'run_batch',calls)
    audit=NS(audit_agentic_activity=AsyncMock())
    async def exercise():
        sessions=InMemorySessionStore(ttl_minutes=60,max_messages=50,max_sessions=10)
        state=await sessions.create({'actor':'Tester','actor_role':'Admin'})
        manager=m.BatchJobManager(s,a,sessions,audit)
        with pytest.raises(ValueError): await manager.create({'unique_valid_count':3},max_parallel=None,max_parallel_ai=None,include_group_ai=False)
        job=await manager.create(parsed,max_parallel=50,max_parallel_ai=50,include_group_ai=False,session_id=state.session_id)
        while job.status.value in {'QUEUED','RUNNING'}: await asyncio.sleep(0)
        assert job.status.value==('FAILED' if fail else 'COMPLETED')
        assert await manager.get(job.job_id) is job
        assert manager.view(job,'https://example.test').elapsed_ms>=0
        assert (await sessions.get(state.session_id)).messages
        if not fail:
            payload,name=await manager.download_payload(job.job_id)
            assert name.endswith('_UNMASKED.zip')
            with zipfile.ZipFile(io.BytesIO(payload)) as z: assert 'MANIFEST.json' in z.namelist()
            assert (await manager.download_payload(job.job_id,masked=True))[1].endswith('_MASKED.zip')
        else:
            with pytest.raises(FileNotFoundError): await manager.download_payload(job.job_id)
        for jid in ['../bad','JOB-AAAAAAAAAAAAAAAA']:
            with pytest.raises(m.BatchJobNotFound): await manager.get(jid)
        await sessions.delete(state.session_id)
        await manager._update_session_status(job)
        await manager._publish_completed_batch_to_session(job)
        await manager._publish_failed_batch_to_session(job)
        await manager._audit_batch(job,'DONE','DONE','done')
        job.session_id=None
        await manager._update_session_status(job)
        await manager._publish_completed_batch_to_session(job)
        await manager._publish_failed_batch_to_session(job)
        assert audit.audit_agentic_activity.await_count>=3
    run(exercise())

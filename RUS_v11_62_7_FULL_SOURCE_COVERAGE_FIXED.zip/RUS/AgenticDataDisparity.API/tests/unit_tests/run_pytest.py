from __future__ import annotations

from pathlib import Path
import os
import sys
import subprocess

PROJECT_ROOT = Path(__file__).resolve().parents[2]
CALLER_CWD = Path.cwd().resolve()
REPOSITORY_ROOT = PROJECT_ROOT.parent.resolve()
COVERAGE_CONFIG = PROJECT_ROOT / "coverage-ci.ini"
sys.path.insert(0, str(PROJECT_ROOT))
from scripts.coverage_artifacts import publish, validate_policy

DESTINATIONS = {PROJECT_ROOT, REPOSITORY_ROOT, CALLER_CWD}
# Never allow a failed or interrupted job to leave a previous successful report.
for directory in DESTINATIONS:
    for name in ("coverage.xml", "junit.xml", "coverage-summary.json"):
        (directory / name).unlink(missing_ok=True)
validate_policy(PROJECT_ROOT)
os.chdir(PROJECT_ROOT)
args = [
    "-vv",
    "-p", "no:asyncio",
    "tests/unit_tests",
    "--cov=src",
    f"--cov-config={COVERAGE_CONFIG}",
    "--cov-report=term-missing",
    "--cov-report=xml:coverage.xml",
    "--cov-fail-under=96",
    "--junitxml=junit.xml",
]
print("[RUS unit runner] Full Python source coverage; no source exclusions.")
print("[RUS unit runner] project_root=", PROJECT_ROOT)
print("[RUS unit runner] command=pytest", " ".join(args))
exit_code = subprocess.run([sys.executable, "-m", "pytest", *args], cwd=PROJECT_ROOT, check=False).returncode
try:
    result = publish(PROJECT_ROOT, DESTINATIONS, exit_code)
    print(f"[RUS unit runner] {result['status']}: {result['line_coverage_percent']:.2f}% full-source line coverage")
    if result['status'] != 'PASS':
        exit_code = exit_code or 1
except Exception as exc:
    print(f"[RUS unit runner] Coverage publication failed: {exc}", file=sys.stderr)
    exit_code = exit_code or 1
raise SystemExit(exit_code)

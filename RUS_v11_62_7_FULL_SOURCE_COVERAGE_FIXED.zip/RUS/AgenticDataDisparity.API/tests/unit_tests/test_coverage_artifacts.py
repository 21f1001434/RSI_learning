"""Behavioral contracts for report portability, source inventory and failure propagation."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import pytest
from scripts.coverage_artifacts import rebase_xml, inspect_xml, publish, validate_policy, source_inventory


def fixture(tmp_path):
    api=tmp_path/'repo'/'AgenticDataDisparity.API'
    (api/'src').mkdir(parents=True)
    (api/'src'/'example.py').write_text('value = 1\n')
    xml=b'<coverage lines-valid="1" lines-covered="1"><sources><source>src</source></sources><packages><package><classes><class filename="example.py"><lines><line number="1" hits="2"/></lines></class></classes></package></packages></coverage>'
    return api,xml


@pytest.mark.parametrize('base',['api','repo','caller'])
def test_rebased_report_preserves_actual_hits_and_resolves_every_file(tmp_path,base):
    api,raw=fixture(tmp_path)
    dest={'api':api,'repo':api.parent,'caller':tmp_path}[base]
    xml=rebase_xml(raw,api,dest)
    assert not ET.fromstring(xml).findall('./sources/source')
    line=ET.fromstring(xml).find('.//line')
    assert line.attrib=={'number':'1','hits':'2'}
    result=inspect_xml(xml,dest,api)
    assert result['line_coverage_percent']==100 and result['source_files']==1
    assert (dest/ET.fromstring(xml).find('.//class').attrib['filename']).resolve()==api/'src'/'example.py'


@pytest.mark.parametrize('damage',['missing_file','wrong_file','duplicate','false_total','negative_hits','uncovered'])
def test_incomplete_or_corrupt_reports_fail_closed(tmp_path,damage):
    api,raw=fixture(tmp_path)
    if damage=='missing_file': (api/'src'/'forgotten.py').write_text('x=1\n')
    if damage=='wrong_file': raw=raw.replace(b'example.py',b'unknown.py')
    if damage=='duplicate': raw=raw.replace(b'</classes>',raw[raw.index(b'<class filename'):raw.index(b'</class>')+8]+b'</classes>')
    if damage=='false_total': raw=raw.replace(b'lines-covered="1"',b'lines-covered="0"')
    if damage=='negative_hits': raw=raw.replace(b'hits="2"',b'hits="-1"')
    if damage=='uncovered': raw=raw.replace(b'hits="2"',b'hits="0"').replace(b'lines-covered="1"',b'lines-covered="0"')
    with pytest.raises(ValueError): inspect_xml(rebase_xml(raw,api,api.parent),api.parent,api)


@pytest.mark.parametrize('exit_code',[0,1,2,5])
def test_failed_pytest_never_publishes_success(tmp_path,exit_code):
    api,raw=fixture(tmp_path)
    (api/'coverage.xml').write_bytes(raw)
    (api/'junit.xml').write_text('<testsuites><testsuite><testcase name="test_real"/></testsuite></testsuites>')
    result=publish(api,{api,api.parent},exit_code)
    assert result['status']==('PASS' if exit_code==0 else 'FAIL')
    assert result['pytest_exit_code']==exit_code
    assert json.loads((api.parent/'coverage-summary.json').read_text())==result
    old=result['source_sha256']
    (api/'src'/'example.py').write_text('value=2\n')
    assert old!=source_inventory(api)


def test_policy_forbids_dropping_modules_from_measurement(tmp_path):
    api,_=fixture(tmp_path)
    config='[run]\nsource=src\nrelative_files=True\n[report]\nfail_under=96\n'
    for name in ['.coveragerc','coverage-ci.ini']: (api/name).write_text(config)
    (api/'sonar-project.properties').write_text('sonar.sources=src\nsonar.python.coverage.reportPaths=coverage.xml\n')
    validate_policy(api)
    (api/'coverage-ci.ini').write_text(config+'omit=src/example.py\n')
    with pytest.raises(ValueError,match='forbids'): validate_policy(api)

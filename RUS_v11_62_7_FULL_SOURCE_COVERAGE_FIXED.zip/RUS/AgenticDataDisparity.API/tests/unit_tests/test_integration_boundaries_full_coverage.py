from __future__ import annotations

import asyncio
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace, ModuleType
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from src.services.disparity_agent.settings import Settings
from src.services.disparity_agent.models import SearchType, SourceName


def run(coro):
    return asyncio.run(coro)


class FakeAsyncClient:
    def __init__(self, *args, response=None, exc=None, **kwargs):
        self.response = response
        self.exc = exc
        self.kwargs = kwargs
        self.closed = False
    async def __aenter__(self): return self
    async def __aexit__(self, *args): self.closed = True
    async def post(self, *args, **kwargs):
        if self.exc: raise self.exc
        return self.response
    async def get(self, *args, **kwargs):
        if self.exc: raise self.exc
        return self.response
    async def put(self, *args, **kwargs):
        if self.exc: raise self.exc
        return self.response
    async def aclose(self): self.closed = True


class FakeSyncClient:
    def __init__(self, *args, responses=None, **kwargs): self.responses=list(responses or []); self.kwargs=kwargs
    def __enter__(self): return self
    def __exit__(self,*args): return False
    def get(self, url):
        item=self.responses.pop(0)
        if isinstance(item, BaseException): raise item
        return item


def response(status=200, data=None, text=None):
    req=httpx.Request('GET','https://example.test')
    if data is not None:
        return httpx.Response(status, request=req, json=data)
    return httpx.Response(status, request=req, text=text or '')


def settings(tmp_path=None, **overrides):
    base = dict(
        bootstrap_from_spring_config=False,
        use_mock_sources=True,
        dell_aia_base_url='https://aia.gateway.dell.com/genai/dev/v1',
        dell_aia_allowed_host='aia.gateway.dell.com',
        dell_aia_model='gpt-oss-120b',
        dell_aia_client_id='cid', dell_aia_client_secret='secret',
        cps_base_url='https://cps.test/v2/Accounts', cps_auth_url='https://auth.test', cps_client_id='c', cps_client_secret='s',
        crowd_twist_base_url='https://ct.test', crowd_twist_auth_url='https://auth.test', crowd_twist_client_id='c', crowd_twist_client_secret='s', crowd_twist_api_key='k',
        tcps_search_url='https://tcps.test/search',
        source_write_mode='dry_run',
    )
    if tmp_path:
        base.update(runs_dir=tmp_path, source_write_audit_file=tmp_path/'a.jsonl', source_write_audit_unmasked_file=tmp_path/'b.jsonl')
    base.update(overrides)
    return Settings(**base)



def _ensure_fake_autogen_modules():
    """Load the installed SDK; never poison global imports with test stand-ins."""
    import importlib
    for name in ("autogen_ext.models.openai", "autogen_agentchat.agents", "autogen_core.models", "autogen_ext.tools.mcp"):
        importlib.import_module(name)


def test_model_client_token_helpers_and_errors(monkeypatch):
    _ensure_fake_autogen_modules()
    import src.services.disparity_agent.agents.model_client as m
    assert m._extract_token(' abc ')=='abc'
    assert m._extract_token({'access_token':'tok'})=='tok'
    assert m._extract_token(SimpleNamespace(id_token='id'))=='id'
    with pytest.raises(m.DellAIAAuthenticationError): m._extract_token({})
    assert m._extract_expiry({'expires_in':'1'})==300
    assert m._extract_expiry({'expires_in':'bad'})==1800

    fake_auth=SimpleNamespace(client_credentials=lambda cid,sec:{'token':'T','expires_in':600})
    mod=ModuleType('aia_auth'); mod.auth=fake_auth
    monkeypatch.setitem(sys.modules,'aia_auth',mod)
    p=m.DellAIATokenProvider('id','sec',skew_seconds=0)
    assert p.seconds_until_expiry()==0
    assert p.get_token()=='T'
    assert p.get_token()=='T'
    assert p.seconds_until_expiry()>0
    p.invalidate(); assert p.seconds_until_expiry()==0
    fake_auth.client_credentials=lambda a,b: (_ for _ in ()).throw(RuntimeError('boom'))
    with pytest.raises(m.DellAIAAuthenticationError): p.get_token(force_refresh=True)
    monkeypatch.delitem(sys.modules,'aia_auth',raising=False)
    real_import=__import__
    def imp(name,*a,**kw):
        if name=='aia_auth': raise ImportError('missing')
        return real_import(name,*a,**kw)
    monkeypatch.setattr('builtins.__import__', imp)
    with pytest.raises(m.DellAIAAuthenticationError): m.DellAIATokenProvider('x','y')._fetch()


def test_model_client_auth_shared_validation_and_retry(monkeypatch):
    _ensure_fake_autogen_modules()
    import src.services.disparity_agent.agents.model_client as m
    s=settings()
    p=MagicMock(); p.get_token.side_effect=['a','b']; p.invalidate=MagicMock()
    auth=m.DellAIARefreshingAuth(p)
    req=httpx.Request('POST','https://x.test')
    flow=auth.auth_flow(req)
    first=next(flow); assert first.headers['Authorization']=='Bearer a' and first.headers.get('x-correlation-id')
    second=flow.send(httpx.Response(401,request=req)); assert second.headers['Authorization']=='Bearer b'
    with pytest.raises(StopIteration): flow.send(httpx.Response(200,request=req))
    p.invalidate.assert_called_once()

    m._SHARED_TOKEN_PROVIDER=None; m._SHARED_TOKEN_PROVIDER_KEY=''
    a=m.get_shared_token_provider(s); b=m.get_shared_token_provider(s); assert a is b
    s2=s.model_copy(update={'dell_aia_client_secret':'other'})
    assert m.get_shared_token_provider(s2) is not a
    m.invalidate_shared_token()
    fp=m.dell_aia_credential_fingerprints(s); assert len(fp['client_id_sha256_12'])==12
    assert m.is_model_route_not_found(RuntimeError('404 Unable to determine the URL routes chat/completions'))
    assert not m.is_model_route_not_found(RuntimeError('500 nope'))
    assert m.is_rate_limit_error(RuntimeError('HTTP 429 Too many requests'))
    assert not m.is_rate_limit_error(RuntimeError('other'))
    assert m.rate_limit_retry_delay(s,0) > 0
    bad=s.model_copy(update={'dell_aia_base_url':'http://aia.gateway.dell.com'})
    with pytest.raises(m.DellAIAConfigurationError): m._validate_dell_aia_lock(bad)
    bad=s.model_copy(update={'dell_aia_allowed_host':'other.test'})
    with pytest.raises(m.DellAIAConfigurationError): m._validate_dell_aia_lock(bad)
    bad=s.model_copy(update={'dell_aia_model':'gpt-oss-120b','dell_aia_client_id':'','dell_aia_client_secret':''})
    with pytest.raises(m.DellAIAConfigurationError): m._validate_dell_aia_lock(bad)
    assert m.dell_aia_model_info()['function_calling'] is True
    kw=m.autogen_client_kwargs(s); assert kw['model']==s.dell_aia_model and kw['parallel_tool_calls'] is False


def test_model_client_build_probe_close_and_safe_chain(monkeypatch):
    _ensure_fake_autogen_modules()
    import src.services.disparity_agent.agents.model_client as m
    s=settings()
    provider=MagicMock(); provider.get_token.return_value='t'; provider.seconds_until_expiry.return_value=99
    monkeypatch.setattr(m,'get_shared_token_provider',lambda x:provider)
    class FakeHTTP:
        def __init__(self,*a,**kw): self.closed=False
        async def aclose(self): self.closed=True
    monkeypatch.setattr(m.httpx,'AsyncClient',FakeHTTP)
    class FakeClient:
        def __init__(self,**kw): self.kw=kw; self.closed=False
        async def close(self): self.closed=True
    monkeypatch.setattr(m,'OpenAIChatCompletionClient',FakeClient)
    client=run(m.build_model_client(s)); assert hasattr(client,'_dell_aia_http_client')
    run(m.close_model_client(client)); assert client.closed
    run(m.close_model_client(None))

    # probe success, auth fail, route-not-found and generic failure
    class Resp: messages=[SimpleNamespace(content='DELL_AIA_READY')]
    class Agent:
        def __init__(self,**kw): pass
        async def run(self,task): return Resp()
    fake_mod=ModuleType('autogen_agentchat.agents'); fake_mod.AssistantAgent=Agent
    monkeypatch.setitem(sys.modules,'autogen_agentchat.agents',fake_mod)
    monkeypatch.setattr(m,'build_model_client',AsyncMock(return_value=FakeClient()))
    monkeypatch.setattr(m,'close_model_client',AsyncMock())
    ok=run(m.probe_dell_aia_runtime(s,retry_route_once=False)); assert ok['ok'] and ok['model_route']=='SUCCESS'
    provider.get_token.side_effect=RuntimeError('auth no')
    fail=run(m.probe_dell_aia_runtime(s,retry_route_once=False)); assert fail['error_code']=='AIA_AUTH_REJECTED'
    provider.get_token.side_effect=None; provider.get_token.return_value='t'
    monkeypatch.setattr(m,'build_model_client',AsyncMock(side_effect=RuntimeError('404 Unable to determine the URL routes chat/completions')))
    monkeypatch.setattr(m.time,'sleep',lambda *_:None)
    r=run(m.probe_dell_aia_runtime(s,retry_route_once=False)); assert r['error_code']=='AIA_MODEL_ROUTE_NOT_FOUND'
    monkeypatch.setattr(m,'build_model_client',AsyncMock(side_effect=RuntimeError('boom')))
    r=run(m.probe_dell_aia_runtime(s,retry_route_once=False)); assert r['error_code']=='AIA_MODEL_PROBE_FAILED'

    secret='secret'; ssec=s.model_copy(update={'dell_aia_client_secret':secret})
    try:
        try: raise ValueError('Bearer abc '+secret)
        except Exception as inner: raise RuntimeError('outer') from inner
    except Exception as exc:
        txt=m.safe_exception_chain(exc,ssec); assert '[REDACTED]' in txt and secret not in txt


def test_oauth_full_matrix(monkeypatch):
    import src.services.disparity_agent.connectors.oauth as o
    assert o._safe_preview(response(200,text='hello\nworld'))=='hello world'
    assert o._safe_preview(response(200,text='access_token secret'))=='<sensitive response omitted>'
    p=o.ClientCredentialsTokenProvider('','','')
    with pytest.raises(o.TokenAcquisitionError) as e: run(p.get_token())
    assert e.value.code=='TOKEN_CONFIG_INCOMPLETE'

    def patch(resp=None,exc=None):
        monkeypatch.setattr(o.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(response=resp,exc=exc))
    p=o.ClientCredentialsTokenProvider('https://auth','id','secret','scope',send_scope=True,extra_form={'x':'y'})
    patch(response(200,{'access_token':'tok','expires_in':100})); assert run(p.get_token())=='tok'; assert run(p.get_token())=='tok'
    p._entry=None; patch(response(401,text='bad')); 
    with pytest.raises(o.TokenAcquisitionError) as e: run(p.get_token()); assert e.value.code=='TOKEN_HTTP_401'
    p._entry=None; patch(response(200,text='notjson'))
    with pytest.raises(o.TokenAcquisitionError) as e: run(p.get_token()); assert e.value.code=='TOKEN_INVALID_JSON'
    p._entry=None; patch(response(200,{}))
    with pytest.raises(o.TokenAcquisitionError) as e: run(p.get_token()); assert e.value.code=='TOKEN_MISSING_ACCESS_TOKEN'
    p._entry=None; patch(exc=httpx.TimeoutException('t'))
    with pytest.raises(o.TokenAcquisitionError) as e: run(p.get_token()); assert e.value.code=='TOKEN_TIMEOUT'
    p._entry=None; patch(exc=httpx.RequestError('n',request=httpx.Request('GET','https://x')))
    with pytest.raises(o.TokenAcquisitionError) as e: run(p.get_token()); assert e.value.code=='TOKEN_NETWORK_ERROR'


def test_config_server_full_matrix(monkeypatch):
    import src.services.disparity_agent.config_server as c
    assert c._normalize_key('A:B-c')=='abc'
    p={'propertySources':[{'source':{'a':'high'}},{'source':{'a':'low','b':'2'}}]}
    assert c._flatten_payload(p)=={'a':'high','b':'2'}
    assert c._flatten_payload({'x':1})=={'x':1}
    assert c._pick({'Vault:DCIAuthUrl':'url'},'DCIAuthUrl')=='url'
    assert c._pick({},'x')==''
    with pytest.raises(RuntimeError): c.fetch_spring_config('g4',username='',password='')
    with pytest.raises(ValueError): c.fetch_spring_config('bogus',username='u',password='p')
    monkeypatch.setattr(c.httpx,'Client',lambda *a,**kw:FakeSyncClient(responses=[response(200,{'propertySources':[{'source':{'X':'Y'}}]})]))
    props,url=c.fetch_spring_config('g4',username='u',password='p'); assert props['X']=='Y' and url
    monkeypatch.setattr(c.httpx,'Client',lambda *a,**kw:FakeSyncClient(responses=[response(200,{}), RuntimeError('x')]))
    with pytest.raises(RuntimeError): c.fetch_spring_config('g4',username='u',password='p')
    mapped=c.map_spring_properties({'CPSBaseAddress':'cps','CTLayer7ApiExt2URL':'ct','CTLayer7ApiExtURL':'ctw','CTLayer7AuthTokenURL':'a','CTLayer7Ext2ClientId':'i','CTLayer7Ext2Secret':'s','CTLayer7ExtClientId':'ui','CTLayer7ExtSecret':'us','DellRewardsConnection':'db'})
    assert mapped['cps_base_url']=='cps' and mapped['crowd_twist_update_base_url']=='ctw' and mapped['rewards_db_connection_string']=='db'


def test_odbc_utils_all_paths(monkeypatch):
    import src.services.disparity_agent.connectors.odbc_utils as u
    assert u._yes_no('SSPI')=='yes' and u._yes_no('no')=='no'
    assert u.parse_connection_string('Server=s;Password="a;b";Database=d')
    monkeypatch.setattr(u.pyodbc,'drivers',lambda:['ODBC Driver 17 for SQL Server','Other'])
    assert u.installed_sql_server_drivers()==['ODBC Driver 17 for SQL Server']
    assert u.select_sql_server_driver('ODBC Driver 17 for SQL Server')=='ODBC Driver 17 for SQL Server'
    assert u.select_sql_server_driver('missing')=='ODBC Driver 17 for SQL Server'
    monkeypatch.setattr(u.pyodbc,'drivers',lambda:[])
    with pytest.raises(RuntimeError): u.select_sql_server_driver('x')
    monkeypatch.setattr(u.pyodbc,'drivers',lambda:['ODBC Driver 18 for SQL Server'])
    cs,diag=u.normalize_ado_connection_string('Data Source=s;Initial Catalog=d;User ID=u;Password=p;Integrated Security=false;Encrypt=true;TrustServerCertificate=false;Pooling=true;Unknown=x','ODBC Driver 18 for SQL Server')
    assert 'DRIVER={ODBC Driver 18 for SQL Server}' in cs and diag['authentication_mode']=='sql_user'
    cs,diag=u.normalize_ado_connection_string('Server=s;Database=d;Integrated Security=SSPI','ODBC Driver 18 for SQL Server'); assert diag['authentication_mode']=='windows_integrated'
    cs,diag=u.normalize_ado_connection_string('Server=s;Database=d;Authentication=ActiveDirectoryIntegrated','ODBC Driver 18 for SQL Server'); assert diag['authentication_mode']=='azure_or_federated'
    with pytest.raises(ValueError): u.normalize_ado_connection_string('', 'x')
    with pytest.raises(ValueError): u.normalize_ado_connection_string('Database=d','x')
    with pytest.raises(ValueError): u.normalize_ado_connection_string('Server=s','x')
    exc=RuntimeError('28000 login failed'); assert u.extract_sqlstate(exc)=='28000'; assert 'authentication' in u.sqlstate_hint('28000').lower()
    for state in ['IM002','08001','HYT00','42S02','42000',None]: assert u.sqlstate_hint(state)


def test_cps_helpers_and_fetch_paths(monkeypatch):
    import src.services.disparity_agent.connectors.cps as c
    assert c._endpoint_host('https://a.test/x')=='a.test'
    assert c._dict_get_ci({'Email':'x'},'email')=='x'
    assert c._extract_member_email({'profiles':[{'contact':{'emailId':'x@y.com'}}]},SearchType.PROFILE_ID,'p')=='x@y.com'
    assert c._extract_member_email({'aliases':[{'type':'EMAIL','value':'a@b.com'}]},SearchType.PROFILE_ID,'p')=='a@b.com'
    assert c._extract_member_email([],SearchType.PROFILE_ID,'p') is None
    assert c._safe_preview(response(200,text='authorization: secret'))=='<sensitive response omitted>'
    for st in [401,400,404,429,500,418]: assert c._http_hint(st)
    s=settings(tcps_enabled=False)
    conn=c.CPSConnector(s)
    assert conn._build_url('a@b.com').endswith('a%40b.com')
    r=run(conn.fetch(SearchType.CROWD_TWIST_ID,'123')); assert not r.status.data_found
    conn.tokens.get_token=AsyncMock(side_effect=c.TokenAcquisitionError('bad',code='TOKEN_X',status_code=401,response_preview='x'))
    r=run(conn.fetch(SearchType.EMAIL,'x@y.com')); assert r.status.error_code=='TOKEN_X'
    conn.tokens.get_token=AsyncMock(return_value='tok')
    monkeypatch.setattr(c.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(response=response(404,text='no')))
    r=run(conn.fetch(SearchType.EMAIL,'none@y.com')); assert not r.status.data_found and r.status.http_status==404
    monkeypatch.setattr(c.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(response=response(401,text='no')))
    r=run(conn.fetch(SearchType.EMAIL,'x@y.com')); assert r.status.error_code=='HTTP_401'
    monkeypatch.setattr(c.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(response=response(200,text='notjson')))
    r=run(conn.fetch(SearchType.EMAIL,'x@y.com')); assert r.status.error_code=='CPS_INVALID_JSON'
    payload={'profileId':'P','profiles':[{'contact':{'emailId':'x@y.com'}}]}
    monkeypatch.setattr(c.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(response=response(200,payload)))
    conn.tcps.fetch_default_country=AsyncMock(return_value=SimpleNamespace(country='US', data_found=True, as_diagnostics=lambda:{'country':'US','data_found':True}))
    r=run(conn.fetch(SearchType.EMAIL,'x@y.com')); assert r.status.data_found and r.raw['_tcps']['defaultCountry']=='US'
    monkeypatch.setattr(c.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(exc=httpx.TimeoutException('t')))
    r=run(conn.fetch(SearchType.EMAIL,'x@y.com')); assert r.status.error_code=='CPS_TIMEOUT'
    monkeypatch.setattr(c.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(exc=httpx.RequestError('n',request=httpx.Request('GET','https://x'))))
    r=run(conn.fetch(SearchType.EMAIL,'x@y.com')); assert r.status.error_code=='CPS_NETWORK_ERROR'


def test_tcps_helpers_and_fetch_paths(monkeypatch):
    import src.services.disparity_agent.connectors.tcps as t
    assert t._endpoint_host('https://x.test/a')=='x.test'
    assert t._escape_scim_string('a"\\b')
    assert t._dict_get_ci({'A':1},'a')==1
    # jwt expiry helper invalid and simple token
    assert t._decode_jwt_exp('bad') is None
    assert t._extract_default_country({'Resources':[{'defaultCountry':'CA'}]},'urn:x:defaultCountry')=='CA'
    assert t._extract_default_country({'Resources':[{'urn:x':{'defaultCountry':'US'}}]},'urn:x:defaultCountry')=='US'
    assert t._extract_default_country({},'x') is None
    s=settings(tcps_enabled=False); conn=t.TCPSCountryConnector(s)
    assert run(conn.fetch_default_country('x@y.com',bearer_token='t')).error_code=='TCPS_DISABLED'
    conn=t.TCPSCountryConnector(settings())
    assert run(conn.fetch_default_country('bad',bearer_token='t')).error_code=='TCPS_EMAIL_REQUIRED'
    assert run(conn.fetch_default_country('x@y.com')).error_code=='TCPS_BEARER_TOKEN_MISSING'
    # monkeypatch expiry helper for expired
    monkeypatch.setattr(t,'_decode_jwt_exp',lambda token:int(time.time())-1)
    assert run(conn.fetch_default_country('x@y.com',bearer_token='t')).error_code=='TCPS_BEARER_TOKEN_EXPIRED'
    monkeypatch.setattr(t,'_decode_jwt_exp',lambda token:None)
    for status, code in [(401,'HTTP_401'),(404,'HTTP_404'),(500,'HTTP_500')]:
        monkeypatch.setattr(t.httpx,'AsyncClient',lambda *a,_r=response(status,text='x'),**kw:FakeAsyncClient(response=_r))
        r=run(conn.fetch_default_country('x@y.com',bearer_token='t')); assert r.error_code==code
    monkeypatch.setattr(t.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(response=response(200,text='badjson')))
    assert run(conn.fetch_default_country('x@y.com',bearer_token='t')).error_code=='TCPS_INVALID_JSON'
    monkeypatch.setattr(t.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(response=response(200,{'totalResults':1,'Resources':[{}]})))
    assert run(conn.fetch_default_country('x@y.com',bearer_token='t')).error_code=='TCPS_DEFAULT_COUNTRY_NOT_FOUND'
    monkeypatch.setattr(t.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(response=response(200,{'totalResults':1,'Resources':[{'defaultCountry':'CA'}]})))
    assert run(conn.fetch_default_country('x@y.com',bearer_token='t')).country=='CA'
    monkeypatch.setattr(t.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(exc=httpx.TimeoutException('t')))
    assert run(conn.fetch_default_country('x@y.com',bearer_token='t')).error_code=='TCPS_TIMEOUT'
    monkeypatch.setattr(t.httpx,'AsyncClient',lambda *a,**kw:FakeAsyncClient(exc=httpx.RequestError('n',request=httpx.Request('POST','https://x'))))
    assert run(conn.fetch_default_country('x@y.com',bearer_token='t')).error_code=='TCPS_NETWORK_ERROR'


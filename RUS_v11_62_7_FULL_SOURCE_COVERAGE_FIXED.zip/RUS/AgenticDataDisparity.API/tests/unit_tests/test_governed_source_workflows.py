"""Approval, drift, verification and audit tests for real source workflows."""
import asyncio
import json
from copy import deepcopy
from datetime import timedelta
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from tests.unit_tests.test_execution_workflows import configured, run, record
from tests.unit_tests.test_transport_and_batch_workflows import HTTP
from src.services.disparity_agent.api.source_operations import SourceOperationService, SourceOperationError
from src.services.disparity_agent.api.session_store import InMemorySessionStore, utc_now
from src.services.disparity_agent.api.schemas import SourceSystem as S, SourceOperation as O
from src.services.disparity_agent.identifier_input import IdentifierMatch
from src.services.disparity_agent.models import SearchType, SourceName
from src.services.disparity_agent.mock_data import CASES, get_mock_case

EMAIL='member@example.com'


def read_value(value='CA',field='country',found=True):
    return {'connected':True,'data_found':found,'canonical':{field:value},'identity':{'email':EMAIL,'crowd_twist_id':123456789,'member_id':'42','profile_id':'11111111-1111-1111-1111-111111111111'},'record':{'canonical':{field:value}}}


async def service(tmp_path,role='Business',mode='live'):
    sessions=InMemorySessionStore(ttl_minutes=60,max_messages=50,max_sessions=10)
    state=await sessions.create({'actor_role':role,'actor':'Test user','actor_email':'tester@example.com'})
    svc=SourceOperationService(configured(tmp_path,source_write_mode=mode),sessions)
    svc._read_target=AsyncMock(return_value=read_value())
    svc._execute_target=AsyncMock(return_value={'email':EMAIL,'success':True,'verified':True})
    return svc,state


async def plan(svc,state,**kw):
    data=dict(session_id=state.session_id,source=S.CROWD_TWIST,operation=O.UPDATE,emails=[EMAIL],field='country',new_value='US',reason='Verified test plan')
    data.update(kw)
    return await svc.plan_change(**data)


def evidence_report():
    suggestion={'target_source':'crowd_twist','attribute':'country','current_value':'CA','recommended_value':'US','truth_source':'cps','automation_eligible':True,'requires_manual_review':False,'priority':'HIGH'}
    return {'run_id':'DDR-AAAAAAAAAAAA','search_type':'email','search_value':EMAIL,'records':{'cps':{'canonical':{'country':'US','email':EMAIL}},'crowd_twist':{'canonical':{'country':'CA','email':EMAIL}}},'attributes':[{'attribute':'country','truth_source':'cps','truth_value':'US','status':'MISMATCH','observations':{'cps':{'raw_value':'US','present':True},'crowd_twist':{'raw_value':'CA','present':True}}}],'suggestions':[suggestion]}


@pytest.mark.parametrize('role,command,expected',[('Business','yes','source_confirm_2'),('Technical','yes','source_confirm_1'),('Admin','apply this change','source_confirm_1'),('Business','do the change','source_confirm_2'),('Technical','do the change','source_confirm_1')])
def test_chat_approvals_obey_profile_and_popup_requirements(tmp_path,role,command,expected):
    async def exercise():
        svc,state=await service(tmp_path,role)
        change=await plan(svc,state)
        result=await svc.handle_chat(session_id=state.session_id,message=command,state=state)
        assert result[0]==expected
        if role!='Business':
            svc._execute_target.assert_not_awaited()
            for msg in ['yes','apply this change']:
                assert (await svc.handle_chat(session_id=state.session_id,message=msg,state=state))[0]=='source_popup_required'
            opened=await svc.mark_popup_opened(state.session_id,change['change_id'])
            done=await svc.confirm_second(state.session_id,change['change_id'],'APPROVE',approval_channel='popup',popup_acknowledged=True,audit_acknowledged=True,plan_digest=opened['plan_digest'],popup_token=opened['popup_approval_token'])
            assert done['status']=='COMPLETED'
        svc._execute_target.assert_awaited_once()
        assert (await svc.get_change(state.session_id,change['change_id']))['status']=='COMPLETED'
        await svc.append_popup_execution_message(state.session_id,change)
        with pytest.raises(SourceOperationError,match='already final'): await svc.cancel_change(state.session_id,change['change_id'])
    run(exercise())


@pytest.mark.parametrize('mode,expected',[('dry_run','DRY_RUN_COMPLETED'),('disabled','BLOCKED_WRITES_DISABLED'),('drift','ABORTED_PRECONDITION_CHANGED'),('unsupported','BLOCKED_OPERATION_NOT_CONFIGURED'),('exception','FAILED'),('partial','PARTIAL')])
def test_execution_rechecks_targets_and_reports_terminal_outcomes(tmp_path,mode,expected):
    async def exercise():
        svc,state=await service(tmp_path,mode=mode if mode in {'dry_run','disabled'} else 'live')
        change=await plan(svc,state,emails=[EMAIL,'b@example.com'] if mode=='partial' else [EMAIL])
        if mode=='drift': svc._read_target.return_value=read_value('JP')
        if mode=='unsupported': change['live_supported']=False
        if mode=='exception': svc._execute_target.side_effect=RuntimeError('secret error')
        if mode=='partial': svc._execute_target.side_effect=[{'success':True,'verified':True},{'success':False}]
        result=await svc.confirm_first(state.session_id,change['change_id'],'YES',approval_channel='chat')
        assert result['status']==expected
        if mode not in {'exception','partial'}: svc._execute_target.assert_not_awaited()
        assert not state.facts.get('active_source_change_id')
        assert 'secret error' not in json.dumps(result['results'])
    run(exercise())


@pytest.mark.parametrize('case,code',[('source','CPS_AGENTIC_WRITE_NOT_ALLOWED'),('field','UNSUPPORTED_WRITE_FIELD'),('invalid','INVALID_NEW_VALUE'),('none','NO_ELIGIBLE_WRITE_TARGETS'),('same','NO_ELIGIBLE_WRITE_TARGETS'),('missing','NO_ELIGIBLE_WRITE_TARGETS'),('unavailable','NO_ELIGIBLE_WRITE_TARGETS'),('limit','TOO_MANY_WRITE_TARGETS')])
def test_invalid_write_plans_never_reach_transport(tmp_path,case,code):
    async def exercise():
        svc,state=await service(tmp_path)
        kw={}
        if case=='source': kw['source']=S.CPS
        if case=='field': kw['field']='password'
        if case=='invalid': kw.update(field='email',new_value='bad')
        if case=='none': kw['emails']=[]
        if case=='same': svc._read_target.return_value=read_value('US')
        if case=='missing': svc._read_target.return_value=read_value(found=False)
        if case=='unavailable': svc._read_target.return_value={'connected':False,'data_found':False}
        if case=='limit': kw['emails']=[f'a{i}@example.com' for i in range(svc.settings.source_write_max_targets+1)]
        with pytest.raises(SourceOperationError) as e: await plan(svc,state,**kw)
        assert e.value.code==code
        svc._execute_target.assert_not_awaited()
    run(exercise())


def test_popup_nonce_expiry_digest_and_session_binding(tmp_path):
    async def exercise():
        svc,state=await service(tmp_path,'Technical')
        change=await plan(svc,state); cid=change['change_id']
        with pytest.raises(SourceOperationError): await svc.mark_popup_opened(state.session_id,cid)
        for text,channel,code in [('YES','api','CONFIRMATION_1_REQUIRES_CHAT'),('wrong','chat','CONFIRMATION_1_MISMATCH')]:
            with pytest.raises(SourceOperationError) as e: await svc.confirm_first(state.session_id,cid,text,approval_channel=channel)
            assert e.value.code==code
        await svc.confirm_first(state.session_id,cid,'YES',approval_channel='chat')
        checks=[({},'CONFIRMATION_2_REQUIRES_POPUP'),({'approval_channel':'popup'},'FINAL_APPROVAL_ACKNOWLEDGEMENT_REQUIRED'),({'approval_channel':'popup','popup_acknowledged':True,'audit_acknowledged':True},'FINAL_APPROVAL_POPUP_NOT_OPENED')]
        for kw,code in checks:
            with pytest.raises(SourceOperationError) as e: await svc.confirm_second(state.session_id,cid,'APPROVE',**kw)
            assert e.value.code==code
        await svc.mark_popup_opened(state.session_id,cid)
        kw={'approval_channel':'popup','popup_acknowledged':True,'audit_acknowledged':True,'popup_token':change['popup_approval_token'],'plan_digest':change['plan_digest']}
        for altered,code in [({'popup_token':'bad'},'INVALID_POPUP_APPROVAL_TOKEN'),({'plan_digest':'bad'},'STALE_OR_TAMPERED_CHANGE_PREVIEW')]:
            with pytest.raises(SourceOperationError) as e: await svc.confirm_second(state.session_id,cid,'APPROVE',**(kw|altered))
            assert e.value.code==code
        with pytest.raises(SourceOperationError) as e: await svc.confirm_second(state.session_id,cid,'no',**kw)
        assert e.value.code=='CONFIRMATION_2_MISMATCH'
        change['popup_token_expires_at']=(utc_now()-timedelta(seconds=1)).isoformat()
        with pytest.raises(SourceOperationError) as e: await svc.confirm_second(state.session_id,cid,'APPROVE',**kw)
        assert e.value.code=='FINAL_APPROVAL_POPUP_EXPIRED'
        other=await svc.sessions.create({'actor_role':'Admin'})
        with pytest.raises(SourceOperationError) as e: await svc.get_change(other.session_id,cid)
        assert e.value.code=='CHANGE_NOT_FOUND'
        change['expires_at']=(utc_now()-timedelta(seconds=1)).isoformat()
        with pytest.raises(SourceOperationError) as e: await svc.confirm_first(state.session_id,cid,'YES',approval_channel='chat')
        assert e.value.code=='CHANGE_EXPIRED'
        svc._execute_target.assert_not_awaited()
    run(exercise())


@pytest.mark.parametrize('command,expected',[
 ('update CrowdTwist country to CA','source_change_value_conflict'),('cancel','source_change_cancelled'),('no','source_change_cancelled'),('update Rewards DB country to US','source_change_needs_identifier')])
def test_active_plan_cannot_be_silently_retargeted(tmp_path,command,expected):
    async def exercise():
        svc,state=await service(tmp_path,'Technical'); change=await plan(svc,state)
        result=await svc.handle_chat(session_id=state.session_id,message=command,state=state)
        assert result[0]==expected
        svc._execute_target.assert_not_awaited()
    run(exercise())


@pytest.mark.parametrize('command,expected',[
 ('update country to US for member@example.com','source_change_analysis_required'),
 ('update CPS country to US','source_change_read_only_truth_source'),
 ('update Rewards DB and CrowdTwist country to US','source_change_needs_source'),
 ('update CrowdTwist','source_change_needs_details'),
 ('update country to US','source_change_needs_source'),
 ('update first name to Ann','source_change_needs_identifier'),
 ('show CPS nobody','source_query_needs_identifier'),
 ('hello there',None),('CrowdTwist',None)])
def test_chat_routes_ambiguous_or_unanalyzed_requests_without_writing(tmp_path,command,expected):
    async def exercise():
        svc,state=await service(tmp_path)
        result=await svc.handle_chat(session_id=state.session_id,message=command,state=state)
        assert (result[0] if result else None)==expected
        svc._execute_target.assert_not_awaited()
    run(exercise())


def test_suggested_change_queue_is_grounded_filtered_and_invalidated(tmp_path):
    async def exercise():
        svc,state=await service(tmp_path)
        state.last_report=evidence_report()
        base=state.last_report['suggestions'][0]
        state.last_report['suggestions'] += [deepcopy(base),None,dict(base,target_source='cps'),dict(base,requires_manual_review=True),dict(base,automation_eligible=False),dict(base,current_value='WRONG')]
        change=await svc.plan_suggested_change_from_report(session_id=state.session_id,state=state,requested_field='country',requested_source=S.CROWD_TWIST,requested_value='US',only_requested=True)
        assert change['new_value']=='US' and change['change_set_total']==1
        assert change['truth_source']=='cps' and change['suggestion_evidence']['grounded']
        await svc.invalidate_suggested_change_queue_after_live_write(state.session_id)
        assert 'suggested_change_context' not in state.facts
        for kw,code in [({'requested_field':'postal_code'},'REQUESTED_SUGGESTION_NOT_FOUND'),({'requested_value':'JP'},'REQUESTED_VALUE_CONFLICTS_WITH_TRUTH')]:
            state.facts.pop('pending_suggested_change_queue',None)
            with pytest.raises(SourceOperationError) as e: await svc.plan_suggested_change_from_report(session_id=state.session_id,state=state,**kw)
            assert e.value.code==code
        state.facts.clear(); state.last_report={'suggestions':[]}
        with pytest.raises(SourceOperationError) as e: await svc.plan_suggested_change_from_report(session_id=state.session_id,state=state)
        assert e.value.code=='NO_AUTOMATABLE_SUGGESTED_CHANGES'
    run(exercise())


@pytest.mark.parametrize('command',['update country as recommended','change country to JP','update CrowdTwist country to US'])
def test_chat_plans_preserve_explicit_literal_and_suggested_values(tmp_path,command):
    async def exercise():
        svc,state=await service(tmp_path)
        state.last_report=evidence_report()
        result=await svc.handle_chat(session_id=state.session_id,message=command,state=state)
        assert result[0]=='source_change_planned'
        change=result[2]['change']
        assert change['new_value']==('JP' if 'JP' in command else 'US')
        assert result[2]['approval_required']
        svc._execute_target.assert_not_awaited()
    run(exercise())


@pytest.mark.parametrize('kind',['query','change'])
def test_candidate_selection_requires_an_explicit_choice(tmp_path,kind):
    async def exercise():
        svc,state=await service(tmp_path)
        state.last_batch_summary={'members':[{'email':'ann@example.com'},{'email':'anna@example.com'}]}
        command='show CPS ann' if kind=='query' else 'update CrowdTwist country to US for ann'
        svc.query_identifiers=AsyncMock(return_value={'members':[],'sources':['cps'],'source_labels':['CPS'],'requested_member_count':2})
        result=await svc.handle_chat(session_id=state.session_id,message=command,state=state)
        assert result[0]==f'source_{kind}_selection'
        rejected=await svc.handle_chat(session_id=state.session_id,message='nobody@example.com',state=state)
        assert rejected[0]==f'source_{kind}_selection'
        selected=await svc.handle_chat(session_id=state.session_id,message='all',state=state)
        assert selected[0]==('source_query' if kind=='query' else 'source_change_planned')
        svc._execute_target.assert_not_awaited()
    run(exercise())


@pytest.mark.parametrize('role',['Business','Technical'])
@pytest.mark.parametrize('execute',[False,True])
def test_spreadsheet_rows_use_same_profile_approval_workflow(tmp_path,role,execute):
    async def exercise():
        svc,state=await service(tmp_path,role)
        svc.query_identifiers=AsyncMock(return_value={'members':[{'resolved_identity':{'email':EMAIL}}]})
        row={'row_number':2,'source':'crowd_twist','identifier_type':'email','identifier_value':EMAIL,'field':'country','new_value':'US'}
        result=await svc.import_spreadsheet_changes(session_id=state.session_id,file_name='updates.xlsx',instruction='apply spreadsheet changes' if execute else 'validate first',rows=[row,dict(row,row_number=3,field=''),dict(row,row_number=4,source='invalid')],actor='Tester',actor_email='tester@example.com',actor_role=role)
        assert result['accepted_count']==1 and result['failed_count']==2
        assert result['execution_completed']==(execute and role=='Business')
        assert 'Excel' in svc.spreadsheet_update_reply(result)
        if not execute:
            assert await svc.execute_pending_spreadsheet_changes(session_id=state.session_id,command_text='preview',state=state) is None
            result=await svc.execute_pending_spreadsheet_changes(session_id=state.session_id,command_text='apply spreadsheet changes',state=state)
        if role=='Technical':
            assert result['requires_final_approval']
            again=await svc.execute_pending_spreadsheet_changes(session_id=state.session_id,command_text='apply spreadsheet changes',state=state)
            assert again['requires_final_approval']
            svc._execute_target.assert_not_awaited()
        else: svc._execute_target.assert_awaited_once()
    run(exercise())


@pytest.mark.parametrize('response_kind',['success','mismatch','rejected','invalid_json','timeout','network','missing_id','no_bridge'])
@pytest.mark.parametrize('source',[S.CROWD_TWIST,S.REWARDS_DB])
def test_shared_dotnet_writer_verifies_independent_readback(tmp_path,monkeypatch,response_kind,source):
    import src.services.disparity_agent.api.source_operations as m
    async def exercise():
        svc,state=await service(tmp_path)
        # Use the real writer; only HTTP and source reads are substituted.
        svc._execute_target=SourceOperationService._execute_target.__get__(svc)
        svc.settings=svc.settings.model_copy(update={'utility_service_base_url':'' if response_kind=='no_bridge' else 'http://127.0.0.1:49690','utility_service_internal_key':'test-key'})
        target={'email':EMAIL,'identity':{} if response_kind=='missing_id' else {'member_id':'42','crowd_twist_id':123},'before':'CA','after':'US'}
        change={'source':source.value,'field':'country','wire_field':'country_code','change_id':'CHG-AAAAAAAAAAAA'}
        data={'success':response_kind!='rejected','effectiveProperties':{'country_code':'US'},'after':{}}
        response=httpx.Response(200,json=data)
        if response_kind=='invalid_json': response=httpx.Response(200,text='not JSON')
        if response_kind=='timeout': response=httpx.TimeoutException('timeout')
        if response_kind=='network': response=httpx.RequestError('offline')
        transport=HTTP(response)
        monkeypatch.setattr(m.httpx,'AsyncClient',lambda **k:transport)
        monkeypatch.setattr(m.asyncio,'sleep',AsyncMock())
        svc._read_target=AsyncMock(return_value=read_value('CA' if response_kind=='mismatch' else 'United States' if source==S.CROWD_TWIST else 'US'))
        result=await svc._execute_target(change,target)
        assert result['success']==(response_kind=='success')
        if response_kind in {'success','mismatch'}:
            assert result['verified']==(response_kind=='success')
            assert transport.requests[0][1]['headers']['X-Internal-API-Key']=='test-key'
        if response_kind=='mismatch': assert svc._read_target.await_count==(4 if source==S.CROWD_TWIST else 2)
    run(exercise())


def test_query_identifiers_and_connector_dependency_reads(tmp_path,monkeypatch):
    import src.services.disparity_agent.api.source_operations as m
    async def exercise():
        svc,state=await service(tmp_path)
        ident=IdentifierMatch(SearchType.EMAIL,EMAIL,0,'test')
        result=await svc.query_identifiers([S.CPS,S.CROWD_TWIST,S.REWARDS_DB],[ident,ident])
        assert result['read_only'] and result['requested_identifier_count']==1
        assert (await svc.resolve_email_for_identifier(ident))[0]
        for sources,ids in [([], [ident]),([S.CPS],[])]:
            with pytest.raises(SourceOperationError): await svc.query_identifiers(sources,ids)
        base=get_mock_case(next(iter(CASES)))
        for name,n in [('CPSConnector',SourceName.CPS),('RewardsDBConnector',SourceName.REWARDS_DB),('CrowdTwistConnector',SourceName.CROWD_TWIST)]:
            obj=NS(fetch=AsyncMock(return_value=base[n]))
            monkeypatch.setattr(m,name,lambda s,obj=obj:obj)
        for sources in [[S.CPS],[S.CROWD_TWIST],[S.CPS,S.CROWD_TWIST,S.REWARDS_DB]]:
            result=await svc._read_sources_for_email(sources,EMAIL)
            assert set(result['results'])=={s.value for s in sources}
        assert not (await svc._read_sources_for_email([],EMAIL))['results']
    run(exercise())


def test_audit_filtering_masks_secrets_and_preserves_history(tmp_path):
    async def exercise():
        svc,state=await service(tmp_path)
        change=await plan(svc,state)
        await svc.confirm_first(state.session_id,change['change_id'],'YES',approval_channel='chat')
        await svc.audit_agentic_activity('TEST_EVENT',{'actor':'Tester','actor_email':'tester@example.com','source':'CPS','action':'Read','status':'COMPLETED','details':{'password':'do-not-leak'}})
        for sensitive in [True,False]:
            result=await svc.list_audit(include_sensitive=sensitive)
            assert result['summary']['total']>=3
            assert 'do-not-leak' not in json.dumps(result)
            for query in [{'source':'none'},{'status':'none'},{'actor':'none'},{'action':'none'},{'from_utc':utc_now()+timedelta(days=1)},{'to_utc':utc_now()-timedelta(days=1)}]:
                assert not (await svc.list_audit(include_sensitive=sensitive,**query))['entries']
        assert (await svc.list_audit(source='CPS',actor='Tester',action='Read',status='COMPLETED',from_utc=(utc_now()-timedelta(days=1)).replace(tzinfo=None)))['summary']['total']==1
        with svc.settings.source_write_audit_file.open('a') as f: f.write('\ninvalid json\n{}\n')
        assert (await svc.list_audit())['entries']
    run(exercise())

"""Failure recovery and compatibility boundaries; all external IO is simulated."""
import base64
import json
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from tests.unit_tests.test_execution_workflows import configured, run, record, report_for
from tests.unit_tests.test_governed_source_workflows import service, plan, read_value, EMAIL
from tests.unit_tests.test_chat_workflows import chat
from tests.unit_tests.test_transport_and_batch_workflows import HTTP
from src.services.disparity_agent.api.source_operations import SourceOperationError
from src.services.disparity_agent.api.schemas import SourceSystem as S, ChatRequest
from src.services.disparity_agent.models import SourceName


@pytest.mark.parametrize('case',['ordinary','failed','empty','live','dry','blocked'])
def test_suggestion_queue_requires_fresh_evidence_after_live_write(tmp_path,case):
    async def exercise():
        svc,state=await service(tmp_path)
        change=await plan(svc,state)
        change.update(suggested_change=case!='ordinary',status='FAILED' if case=='failed' else 'COMPLETED',results=[{'success':True,'dry_run':case!='live'}])
        if case!='empty': state.facts['pending_suggested_change_queue']=[{'field':'country'}]
        state.facts['suggested_change_context']={'run_id':'old'}
        next_plan=dict(change,change_id='CHG-BBBBBBBBBBBB')
        svc.plan_suggested_change_from_report=AsyncMock(return_value=next_plan,side_effect=SourceOperationError('NO_PLAN','No next plan') if case=='blocked' else None)
        result=await svc._prepare_next_suggested_change_after_execution(session_id=state.session_id,completed=change)
        if case in {'ordinary','failed','empty','live'}: svc.plan_suggested_change_from_report.assert_not_awaited()
        if case=='live': assert result['next_change_revalidation_required'] and 'next_change' not in result
        if case=='empty': assert result['remaining_suggested_changes']==0 and 'suggested_change_context' not in state.facts
        if case=='dry': assert result['next_change']['change_id']=='CHG-BBBBBBBBBBBB'
        if case=='blocked': assert result['next_change_error']['code']=='NO_PLAN'
    run(exercise())


@pytest.mark.parametrize('case',['disabled','denied','verified','mismatch','email'])
def test_legacy_cps_writer_validates_http_and_readback(tmp_path,monkeypatch,case):
    import src.services.disparity_agent.api.source_operations as m
    async def exercise():
        svc,state=await service(tmp_path)
        svc.settings.cps_update_path='' if case=='disabled' else 'account/{value}'
        svc.settings.cps_base_url='https://cps.test'
        svc.settings.cps_api_key='test-key'
        connector=NS(tokens=NS(get_token=AsyncMock(return_value='private-token')),fetch=AsyncMock(return_value=record(SourceName.CPS,True,True,{'firstName':'Alice' if case!='mismatch' else 'Other'})))
        monkeypatch.setattr(m,'CPSConnector',lambda s:connector)
        client=HTTP(httpx.Response(403 if case=='denied' else 200,json={},request=httpx.Request('PATCH','https://cps.test')))
        monkeypatch.setattr(m.httpx,'AsyncClient',lambda **kw:client)
        target={'email':EMAIL,'before':'Old','after':'Alice','identity':{} if case=='email' else {'profile_id':'id/1'}}
        result=await svc._update_cps({'field':'first_name','wire_field':'firstName'},target)
        assert result['success']==(case in {'verified','email'})
        if case=='disabled': connector.tokens.get_token.assert_not_awaited()
        elif case=='denied': assert result['code']=='HTTP_403'
        elif case=='mismatch': assert result['code']=='VERIFY_FAILED'
        else: assert result['verified']
        assert svc._current_value(S.CROWD_TWIST,'first_name',{'record':{'raw':{'first_name':'Alice'}}})=='Alice'
    run(exercise())


@pytest.mark.parametrize('status',['DRY_RUN_COMPLETED','ABORTED_PRECONDITION_CHANGED','BLOCKED_WRITES_DISABLED','PARTIAL'])
def test_execution_messages_describe_actual_mutation_outcome(tmp_path,status):
    async def exercise():
        svc,state=await service(tmp_path)
        change=await plan(svc,state)
        change.update(status=status,manual_override=True,results=[{'dry_run':status=='DRY_RUN_COMPLETED','message':'Blocked by policy'}])
        text=svc._execution_reply(change)
        assert status in text and 'Manual override' in text
        if status=='DRY_RUN_COMPLETED': assert 'no Rewards DB or CrowdTwist record was modified' in text
        if status=='ABORTED_PRECONDITION_CHANGED': assert 'No update was attempted' in text
        if status.startswith('BLOCKED'): assert 'Blocked by policy' in text
    run(exercise())


@pytest.mark.parametrize('case',['service','id','popup','denied','terminal','pending'])
def test_compatibility_chat_execution_keeps_governance(tmp_path,case):
    async def exercise():
        c=chat(tmp_path,source=case!='service')
        if case=='service': state=await c.sessions.create(); change={}
        else:
            svc,state=await service(tmp_path,'Technical')
            c.sessions=svc.sessions; c.source_operations=svc
            change=await plan(svc,state)
            if case=='terminal': change.update(status='COMPLETED',results=[{'success':True,'verified':True}])
            svc.execute_explicit_chat_command=AsyncMock(return_value=change)
            if case in {'popup','denied'}: svc.execute_explicit_chat_command.side_effect=SourceOperationError('FINAL_APPROVAL_POPUP_REQUIRED' if case=='popup' else 'DENIED','denied')
        c.refresh_after_source_change=AsyncMock(return_value={'run_id':'DDR-AAAAAAAAAAAA','summary':{},'attributes':[]})
        request=ChatRequest(session_id=state.session_id,message='apply')
        if case=='denied':
            with pytest.raises(SourceOperationError): await c._execute_explicit_source_request(request=request,state=state,structured={'change':change})
            return
        result=await c._execute_explicit_source_request(request=request,state=state,structured={'change':{} if case=='id' else change})
        assert result[0]=={'service':'source_operation_error','id':'source_operation_error','popup':'source_popup_required','terminal':'source_confirm_2','pending':'source_confirm_1'}[case]
        assert c.refresh_after_source_change.await_count==(1 if case=='terminal' else 0)
    run(exercise())


@pytest.mark.parametrize('case',['invalid','missing','rerouted'])
def test_chat_requested_analysis_validates_identifier_and_returns_plan(tmp_path,case):
    c=chat(tmp_path)
    async def exercise():
        state=await c.sessions.create({'actor_role':'Business'})
        identifier={'search_type':'invalid' if case=='invalid' else 'email','value':'' if case=='missing' else EMAIL}
        c.source_operations.handle_chat=AsyncMock(side_effect=[('source_change_analysis_required','Need evidence',{'identifier':identifier}),('source_change_plan','Review plan',{'change':{'change_id':'CHG-AAAAAAAAAAAA'}})])
        c._run_analysis_for_session=AsyncMock(return_value={'run_id':'DDR-AAAAAAAAAAAA'})
        result=await c.handle(ChatRequest(session_id=state.session_id,message='update country to US'),'http://test')
        assert result.intent==('source_change_plan' if case=='rerouted' else 'source_change_needs_identifier')
        assert c._run_analysis_for_session.await_count==(1 if case=='rerouted' else 0)
    run(exercise())


@pytest.mark.parametrize('case',['requested','bad_requested','bad_report'])
def test_post_write_refresh_identifier_fallback(tmp_path,case):
    c=chat(tmp_path)
    async def exercise():
        state=await c.sessions.create()
        state.last_report={'search_type':'bad' if case=='bad_report' else 'email','search_value':EMAIL}
        c._run_analysis_for_session=AsyncMock(return_value={'run_id':'DDR-AAAAAAAAAAAA','summary':{}})
        change={'status':'COMPLETED','results':[{'success':True}],'requested_identifier':{'search_type':'email' if case=='requested' else 'bad','value':EMAIL},'targets':[{'email':EMAIL}]}
        assert await c.refresh_after_source_change(state.session_id,change)
        assert c._run_analysis_for_session.call_args.kwargs['search_value']==EMAIL
    run(exercise())


@pytest.mark.parametrize('mode',['override','oauth','oauth_error','none'])
def test_mcp_tcps_reuses_auth_without_returning_tokens(tmp_path,monkeypatch,mode):
    import src.services.disparity_agent.mcp_server as m
    from src.services.disparity_agent.connectors.tcps import TCPSCountryResult
    from src.services.disparity_agent.connectors.oauth import TokenAcquisitionError
    settings=configured(tmp_path,tcps_bearer_token='private-token' if mode=='override' else '',tcps_use_cps_bearer_token=mode!='none')
    monkeypatch.setattr(m,'load_settings',lambda:settings)
    token=AsyncMock(return_value='private-token',side_effect=TokenAcquisitionError('no token',code='TOKEN_DENIED') if mode=='oauth_error' else None)
    monkeypatch.setattr(m,'ClientCredentialsTokenProvider',lambda *a,**k:NS(get_token=token))
    fetch=AsyncMock(return_value=TCPSCountryResult(True,True,country='US'))
    monkeypatch.setattr(m,'TCPSCountryConnector',lambda s:NS(fetch_default_country=fetch))
    output=run(m.search_tcps_default_country(EMAIL))
    assert 'private-token' not in output
    if mode=='oauth_error': assert json.loads(output)['status']['error_code']=='TOKEN_DENIED'; fetch.assert_not_awaited()
    else: assert json.loads(output)['country']=='US'
    assert token.await_count==(1 if mode in {'oauth','oauth_error'} else 0)


def test_tcps_jwt_and_shape_defenses():
    from src.services.disparity_agent.connectors import tcps
    def jwt(payload): return 'x.'+base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip('=')+'.x'
    assert tcps._decode_jwt_exp(jwt({'exp':123}))==123
    for token in ['bad','x.invalid.x',jwt({}),jwt({'exp':'bad'}),jwt([])]: assert tcps._decode_jwt_exp(token) is None
    assert tcps._endpoint_host('http://[bad') is None
    assert tcps._dict_get_ci({'RESOURCES':[1]},'resources')==[1]
    for payload in [None,{}, {'Resources':[None]}, {'Resources':[{}]}]: assert tcps._extract_default_country(payload,'urn:x:defaultCountry') is None


@pytest.mark.parametrize('mode',['success','empty','exception'])
def test_spring_config_precedence_and_fallback_profiles(monkeypatch,mode):
    import src.services.disparity_agent.config_server as m
    class Client:
        def __enter__(self): return self
        def __exit__(self,*args): pass
        def get(self,url):
            if mode=='exception': raise httpx.ConnectError('offline')
            return httpx.Response(200,json={'propertySources':[None,{'source':{'key':'high'}},{'source':{'key':'low'}}]} if mode=='success' else [],request=httpx.Request('GET',url))
    monkeypatch.setattr(m.httpx,'Client',lambda **kw:Client())
    if mode=='success':
        properties,url=m.fetch_spring_config(next(iter(m.SPRING_CONFIG_ENVIRONMENTS)),username='user',password='secret')
        assert properties['key']=='high' and url.startswith('http')
    else:
        with pytest.raises(RuntimeError,match='bootstrap failed'): m.fetch_spring_config(next(iter(m.SPRING_CONFIG_ENVIRONMENTS)),username='user',password='secret')
    with pytest.raises(ValueError): m.fetch_spring_config('invalid',username='user',password='secret')
    assert m._flatten_payload({'one':1})=={'one':1}


@pytest.mark.parametrize('mode',['success','failure','skip'])
def test_settings_bootstrap_outcome_is_explicit(tmp_path,monkeypatch,mode):
    import src.services.disparity_agent.settings as m
    settings=configured(tmp_path,use_mock_sources=False,bootstrap_from_spring_config=True)
    monkeypatch.setattr(m,'Settings',lambda:settings)
    fetch=MagicMock(return_value=({'CPSBaseAddress':'https://cps.test'},'https://config.test'),side_effect=RuntimeError('private-secret') if mode=='failure' else None)
    monkeypatch.setattr(m,'fetch_spring_config',fetch)
    m.load_settings.cache_clear()
    try:
        result=m.load_settings(bootstrap=mode!='skip')
        if mode=='success': assert result.cps_base_url=='https://cps.test' and not result.spring_config_error
        if mode=='failure': assert 'bootstrap failed' in result.spring_config_error and 'private-secret' not in result.spring_config_error
        if mode=='skip': fetch.assert_not_called()
    finally: m.load_settings.cache_clear()


@pytest.mark.parametrize('kwargs',[{'dell_aia_model':'bad name'},{'dell_aia_model_candidates':'ok,bad name'},{'rewards_db_schema':'bad;drop'}])
def test_settings_reject_unsafe_identifiers(tmp_path,kwargs):
    with pytest.raises(ValueError): configured(tmp_path,**kwargs)


def test_settings_db_configuration_resolution(tmp_path):
    assert configured(tmp_path,rewards_db_connection_string='raw').db_connection_string=='raw'
    connection=configured(tmp_path,rewards_db_server='sql.test',rewards_db_name='rewards',rewards_db_username='tester',rewards_db_password='test-password').db_connection_string
    assert 'SERVER=sql.test' in connection and 'DATABASE=rewards' in connection
    with pytest.raises(ValueError,match='configuration is missing'): configured(tmp_path,allow_local_db_fallback=False).db_connection_string

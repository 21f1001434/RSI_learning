"""Exercise production pipelines with in-memory source and model transports."""
import asyncio
import json
import runpy
import time
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from src.services.disparity_agent.settings import Settings
from src.services.disparity_agent.models import SearchType, SourceName, SourceRecord, SourceStatus
from src.services.disparity_agent.mock_data import CASES, get_mock_case
from src.services.disparity_agent.pipeline import DisparityPipeline


def run(coro):
    return asyncio.run(coro)


def configured(tmp_path, **kw):
    values = dict(bootstrap_from_spring_config=False, use_mock_sources=True,
                  adaptive_memory_enabled=False, runs_dir=tmp_path / 'runs',
                  source_write_audit_file=tmp_path/'audit.jsonl',
                  source_write_audit_unmasked_file=tmp_path/'audit-full.jsonl',
                  dell_aia_client_id='test-client', dell_aia_client_secret='test-secret')
    values.update(kw)
    return Settings(**values)


def report_for(tmp_path):
    return run(DisparityPipeline(configured(tmp_path)).run(SearchType.EMAIL, 'member@example.com'))


def record(source, found=True, connected=True, raw=None):
    return SourceRecord(source=source, raw=raw, status=SourceStatus(source=source, connected=connected, data_found=found))


@pytest.mark.parametrize('case', list(CASES))
def test_mock_pipeline_produces_grounded_reports(tmp_path, case):
    s=configured(tmp_path, mock_case=case)
    pipeline=DisparityPipeline(s)
    records=run(pipeline.collect_source_records(SearchType.EMAIL,'member@example.com'))
    result=run(pipeline.run(SearchType.EMAIL,'member@example.com'))
    assert result.missing_record_count == sum(not r.status.data_found for r in records.values())
    assert result.mismatch_count == sum(a.status in {'MISMATCH','TRUTH_FORMAT_INVALID','COUNTRY_SOURCE_CONFLICT','BOOLEAN_REVIEW_REQUIRED'} for a in result.attributes)
    assert result.api_knowledge_summary['operation_count'] > 0
    assert all(s.target_source not in {n for n,r in records.items() if not r.status.data_found} for s in result.suggestions if s.automation_eligible)


@pytest.mark.parametrize('cps_found,ct_found,db_found,connected', [(False,True,False,True),(False,False,False,False),(True,False,True,False)])
def test_pipeline_partial_and_unavailable_sources(tmp_path,monkeypatch,cps_found,ct_found,db_found,connected):
    import src.services.disparity_agent.pipeline as m
    rows={n:record(n,found,connected,{} if found else None) for n,found in [(SourceName.CPS,cps_found),(SourceName.CROWD_TWIST,ct_found),(SourceName.REWARDS_DB,db_found)]}
    rows[SourceName.CPS].status.diagnostics['tcps_country_lookup']={'data_found':False,'error_code':'TCPS_TIMEOUT'}
    p=m.DisparityPipeline(configured(tmp_path,use_mock_sources=False))
    monkeypatch.setattr(p,'_collect_real',AsyncMock(return_value=rows))
    result=run(p.run(SearchType.EMAIL,'a@example.com'))
    assert result.analysis_completeness == ('PARTIAL' if cps_found or db_found else 'NO_AUTHORITATIVE_DATA')
    assert result.warnings and 'TCPS_TIMEOUT' in ' '.join(result.warnings)
    assert run(p.collect_source_records(SearchType.EMAIL,'a@example.com')) == rows
    with pytest.raises(ValueError): get_mock_case('unknown')


@pytest.mark.parametrize('origin',list(SearchType))
def test_real_pipeline_identifier_resolution_without_network(tmp_path,monkeypatch,origin):
    import src.services.disparity_agent.pipeline as m
    base=get_mock_case(next(iter(CASES)))
    cps=NS(fetch=AsyncMock(side_effect=[record(SourceName.CPS,False,False),base[SourceName.CPS]]))
    ct=NS(fetch=AsyncMock(return_value=base[SourceName.CROWD_TWIST]))
    db=NS(fetch=AsyncMock(return_value=base[SourceName.REWARDS_DB]))
    for name,obj in [('CPSConnector',cps),('CrowdTwistConnector',ct),('RewardsDBConnector',db)]:
        monkeypatch.setattr(m,name,lambda s,obj=obj:obj)
    result=run(m.DisparityPipeline(configured(tmp_path,use_mock_sources=False))._collect_real(origin,'member@example.com'))
    assert set(result)==set(SourceName)
    assert cps.fetch.await_count == 2
    db.fetch.assert_awaited_once()
    assert db.fetch.call_args.kwargs['resolved_profile_id']


def test_identity_fallback_stops_on_outage_and_remembers_attempts():
    from src.services.disparity_agent.identity_resolution import resolve_crowd_twist_user
    async def exercise():
        missing=lambda:record(SourceName.CROWD_TWIST,False)
        c=NS(fetch=AsyncMock(side_effect=[missing(),missing(),record(SourceName.CROWD_TWIST)]))
        first=await resolve_crowd_twist_user(c,email='a@example.com',profile_id='pid')
        assert not first.status.data_found and c.fetch.await_count==2
        second=await resolve_crowd_twist_user(c,email='a@example.com',profile_id='pid',crowd_twist_id=42,initial_record=first)
        assert second.status.data_found and c.fetch.await_count==3
        assert second.status.retrieval_method=='crowd_twist_id_fallback'
        await resolve_crowd_twist_user(c,email='a@example.com',profile_id='pid',initial_record=second)
        assert c.fetch.await_count==3
        c.fetch=AsyncMock(return_value=record(SourceName.CROWD_TWIST,False,False))
        out=await resolve_crowd_twist_user(c,email='b@example.com',profile_id='pid',crowd_twist_id=42)
        assert not out.status.connected and c.fetch.await_count==1
        c.fetch=AsyncMock(return_value=record(SourceName.CROWD_TWIST))
        out=await resolve_crowd_twist_user(c,email='c@example.com',profile_id='pid',initial_record=missing())
        assert out.status.retrieval_method=='profile_id_fallback'
    run(exercise())


class Workbench:
    def __init__(self, replies=None, enter_error=None, close_error=None):
        self.replies=replies or {}; self.enter_error=enter_error; self.close_error=close_error
    async def __aenter__(self):
        if self.enter_error: raise self.enter_error
        return self
    async def __aexit__(self,*args):
        if self.close_error: raise self.close_error
    async def call_tool(self,name,args): return json.dumps(self.replies[name])


@pytest.mark.parametrize('verdict',['ACCEPTED','PARTIAL','REJECTED','malformed'])
def test_agent_analyst_and_independent_judge_enforcement(tmp_path,monkeypatch,verdict):
    import src.services.disparity_agent.agents.orchestrator as m
    report=report_for(tmp_path)
    wb=Workbench({'health_check':{'ready':True},'run_disparity_check':report.model_dump(mode='json'),'get_api_catalog_summary':{'summary':{'operation_count':10}}})
    monkeypatch.setattr(m,'McpWorkbench',lambda p:wb)
    monkeypatch.setattr(m,'build_model_client',AsyncMock(return_value=object()))
    close=AsyncMock(); monkeypatch.setattr(m,'close_model_client',close)
    calls=[]
    def agent(**kwargs):
        calls.append(kwargs)
        content=json.dumps({'summary':'Model narrative','wrong_attributes':['invented']}) if len(calls)%2 else (json.dumps({'verdict':verdict,'corrected_summary':'Verified correction'}) if verdict!='malformed' else 'unstructured judge output')
        return NS(run=AsyncMock(return_value=NS(messages=[NS(content=content,source='assistant')])))
    monkeypatch.setattr(m,'AssistantAgent',agent)
    result=run(m.AgenticOrchestrator(configured(tmp_path),ai_semaphore=asyncio.Semaphore(1)).run(SearchType.EMAIL,'member@example.com'))
    assert result.ai_execution['status']=='SUCCESS'
    assert len(calls)==2 and close.await_count==1
    assert result.ai_execution['live_writes_performed'] is False
    assert (tmp_path/'runs'/f'{result.run_id}.json').is_file()
    if verdict=='REJECTED': assert result.ai_analysis.get('summary') != 'Model narrative'
    assert all(isinstance(x,dict) for x in result.ai_analysis.get('wrong_attributes',[]))


@pytest.mark.parametrize('mode',['connect_failure','close_failure','model_failure','route_retry'])
def test_orchestration_preserves_evidence_on_transport_failures(tmp_path,monkeypatch,mode):
    import src.services.disparity_agent.agents.orchestrator as m
    report=report_for(tmp_path)
    wb=Workbench({'health_check':{},'run_disparity_check':report.model_dump(mode='json'),'get_api_catalog_summary':{}},
        enter_error=RuntimeError('MCP down') if mode=='connect_failure' else None,
        close_error=RuntimeError('MCP close') if mode=='close_failure' else None)
    monkeypatch.setattr(m,'McpWorkbench',lambda p:wb)
    monkeypatch.setattr(m,'build_model_client',AsyncMock(side_effect=RuntimeError('404 chat/completions') if mode=='route_retry' else RuntimeError('401 unauthorized')))
    monkeypatch.setattr(m.asyncio,'sleep',AsyncMock())
    monkeypatch.setattr(m,'invalidate_shared_token',MagicMock())
    o=m.AgenticOrchestrator(configured(tmp_path))
    result=run(o.run(SearchType.EMAIL,'member@example.com'))
    assert result.records and result.ai_execution['status']=='FAILED'
    assert result.judge_result['status']=='NOT_RUN'
    if mode=='close_failure': assert result.mcp_execution['session_close_status']=='WARNING'
    if mode=='route_retry': m.invalidate_shared_token.assert_called_once()


def test_agent_retry_and_tool_decoding_contracts(tmp_path,monkeypatch):
    import src.services.disparity_agent.agents.orchestrator as m
    o=m.AgenticOrchestrator(configured(tmp_path,dell_aia_rate_limit_retries=1))
    monkeypatch.setattr(m.asyncio,'sleep',AsyncMock())
    agent=NS(run=AsyncMock(side_effect=[RuntimeError('HTTP 429'), 'ok']))
    assert run(o._run_agent_with_rate_limit_retry(agent,task='x',stage='judge'))=='ok'
    agent.run=AsyncMock(side_effect=RuntimeError('bad'))
    with pytest.raises(RuntimeError): run(o._run_agent_with_rate_limit_retry(agent,task='x',stage='judge'))
    for value in ['{"ok":true}',b'{"ok":true}',{'content':[{'text':'{"ok":true}'}]},NS(result=[NS(content='{"ok":true}')]),'```json\n{"ok":true}\n```']:
        assert o._json_from_tool(value)=={'ok':True}
    with pytest.raises(RuntimeError): o._json_from_tool(NS(is_error=True,content='error'))
    with pytest.raises(ValueError): o._tool_result_text(NS())
    assert o._tool_result_text(None,allow_empty=True)==''
    assert o._tool_names_from_listing([{'name':'a'},NS(name='b'),{}])=={'a','b'}
    assert o._extract_tool_calls([{'content':[{'name':'health_check'},NS(tool_name='run_disparity_check')]},'health_check'])==['health_check','run_disparity_check']
    assert o._host_only('invalid')=='configured Dell AIA gateway'
    for err,code in [(ImportError('aia_auth'),'AIA_AUTH_CLIENT_MISSING'),(RuntimeError('403'),'AIA_ACCESS_FORBIDDEN'),(RuntimeError('timeout'),'AIA_OR_MCP_TIMEOUT'),(ValueError('extract mcp tool text'),'MCP_RESULT_DECODING_FAILED'),(RuntimeError('tool failed'),'MCP_TOOL_EXECUTION_FAILED'),(RuntimeError('unknown'),'AIA_AGENT_FAILED')]:
        assert o._safe_error(err,'test')['error_code']==code
    with pytest.raises(RuntimeError): run(o._apply_agentic_ai(report_for(tmp_path),None,SearchType.EMAIL,'a',{},None))


@pytest.mark.parametrize('payload', ['{"review_status":"SUCCESS"}', 'plain model explanation', None])
def test_implementation_planner_never_writes(tmp_path,monkeypatch,payload):
    import src.services.disparity_agent.agents.orchestrator as m
    wb=Workbench({'compile_use_case_plan':{'evidence_run_id':'DDR-AAAAAAAAAAAA','steps':[]}})
    if payload is None: wb.enter_error=RuntimeError('MCP down')
    monkeypatch.setattr(m,'McpWorkbench',lambda p:wb)
    monkeypatch.setattr(m,'build_model_client',AsyncMock(return_value=object()))
    monkeypatch.setattr(m,'close_model_client',AsyncMock())
    monkeypatch.setattr(m,'AssistantAgent',lambda **k:NS(run=AsyncMock(return_value=NS(messages=[NS(content=payload,source='assistant')]))))
    result=run(m.AgenticOrchestrator(configured(tmp_path)).compile_selected_use_case('UC-013',SearchType.EMAIL,'a@example.com'))
    assert result['agentic_execution']['live_writes_performed'] is False
    assert result['agentic_execution']['status']==('FAILED' if payload is None else 'SUCCESS')


def test_browser_evidence_template_and_read_only_contract(tmp_path,monkeypatch):
    import src.services.disparity_agent.agents.playwright_fallback as m
    calls=[]
    monkeypatch.setattr(m,'McpWorkbench',lambda p:Workbench())
    def agent(**kw):
        calls.append(kw)
        return NS(run=AsyncMock(return_value=NS(messages=[NS(content='evidence')])) )
    monkeypatch.setattr(m,'AssistantAgent',agent)
    s=configured(tmp_path)
    assert 'No portal' in run(m.collect_browser_evidence(s,None,'cps','a'))
    s=s.model_copy(update={'cps_portal_search_url_template':'https://example.test/{value}','crowd_twist_portal_search_url_template':'https://example.test/{value}','playwright_headless':True})
    for source in ['cps','crowd_twist']: assert run(m.collect_browser_evidence(s,None,source,'a'))=='evidence'
    assert all('Do not modify' in c['system_message'] for c in calls)


def test_mcp_tools_cache_and_catalog(tmp_path,monkeypatch):
    import src.services.disparity_agent.mcp_server as m
    s=configured(tmp_path)
    monkeypatch.setattr(m,'load_settings',lambda:s)
    monkeypatch.setattr(m,'_REPORT_CACHE',{})
    monkeypatch.setattr(m,'_REPORT_CACHE_LOCK',asyncio.Lock())
    async def exercise():
        assert json.loads(await m.health_check())['mock_mode']
        r=json.loads(await m.run_disparity_check('email','a@example.com'))
        cached=await m._get_or_run_report('email','a@example.com')
        cached.warnings.append('test')
        assert 'test' not in (await m._get_or_run_report('email','a@example.com')).warnings
        catalog=json.loads(await m.get_api_catalog_summary())
        op=catalog['operations'][0]['Operation ID']
        assert json.loads(await m.describe_api_operation(op))
        assert 'valid' in json.loads(await m.validate_api_payload(op,'{}'))
        with pytest.raises(ValueError): await m.validate_api_payload(op,'[]')
        assert json.loads(await m.suggest_use_cases())
        assert json.loads(await m.suggest_use_cases('email','a@example.com'))
        assert json.loads(await m.compile_use_case_plan('UC-013','email','a@example.com'))['use_case_id']=='UC-013'
        for i in range(34): m._REPORT_CACHE[('email',str(i))]=(0,cached)
        await m._get_or_run_report('email','new@example.com')
        assert len(m._REPORT_CACHE)<=32
        assert r['run_id'].startswith('DDR-')
    run(exercise())

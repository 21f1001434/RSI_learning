import asyncio
import importlib
import runpy
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

from tests.unit_tests.test_execution_workflows import configured, report_for, run, record
from src.services.disparity_agent.models import SourceName
from src.services.disparity_agent.api.run_store import UnmaskedReportUnavailable, RunNotFound
from src.services.disparity_agent.api.session_store import SessionNotFound
from src.services.disparity_agent.api.source_operations import SourceOperationError
from src.services.disparity_agent.api.batch_jobs import BatchJob, BatchJobNotFound
from src.services.disparity_agent.api.schemas import BatchJobStatus


def make_app(tmp_path,monkeypatch,legacy=False):
    m=importlib.import_module('src.services.disparity_agent.api.app' if legacy else 'src.main')
    from src.services.disparity_agent.api.config import ApiSettings
    monkeypatch.setattr(m,'load_settings',lambda:configured(tmp_path))
    monkeypatch.setattr(m,'load_api_settings',lambda:ApiSettings(batch_output_dir=tmp_path/'batch',api_internal_key='key',api_require_internal_key=False))
    return m.create_app()


@pytest.mark.parametrize('legacy',[False,True])
def test_app_lifespan_context_and_exception_response(tmp_path,monkeypatch,legacy):
    app=make_app(tmp_path,monkeypatch,legacy)
    @app.get('/test-error')
    async def raise_error(): raise RuntimeError('test failure')
    with TestClient(app,raise_server_exceptions=False) as client:
        root=client.get('/',headers={'X-Request-ID':'TEST-ID'})
        assert root.status_code==200 and root.headers['X-Request-ID']=='TEST-ID'
        error=client.get('/test-error')
        assert error.status_code==500 and error.headers['Cache-Control']=='no-store'
        assert app.state.cleanup_task and not app.state.cleanup_task.done()
    assert app.state.cleanup_task.done()


def test_sensitive_audit_key_is_forbidden_without_internal_credential(tmp_path,monkeypatch):
    app=make_app(tmp_path,monkeypatch)
    app.state.source_operations.list_audit=AsyncMock(return_value={'entries':[]})
    with TestClient(app) as c:
        for params in ['?include_sensitive=true','?include_sensitive=true&status=COMPLETED']:
            assert c.get('/api/v1/audit-trail'+params).status_code==403
            assert c.get('/api/v1/audit-trail'+params,headers={'X-Internal-API-Key':'wrong'}).status_code==403
            assert c.get('/api/v1/audit-trail'+params,headers={'X-Internal-API-Key':'key'}).status_code==200
    assert app.state.source_operations.list_audit.await_count==2


@pytest.mark.parametrize('endpoint',['confirm-1','confirm-2','popup-opened','cancel'])
@pytest.mark.parametrize('error',[SessionNotFound('missing'),SourceOperationError('DENIED','denied',409)])
def test_change_route_error_contracts(tmp_path,monkeypatch,endpoint,error):
    app=make_app(tmp_path,monkeypatch)
    svc=app.state.source_operations
    svc.apply_session_write_policy=AsyncMock(side_effect=error)
    with TestClient(app) as c:
        r=c.post('/api/v1/source-operations/changes/CHG-AAAAAAAAAAAA/'+endpoint,json={'session_id':'S','actor_role':'Business','confirmation_text':'YES'})
        assert r.status_code==(404 if isinstance(error,SessionNotFound) else 409)
        assert not r.json()['success']


def test_individual_analysis_options_and_use_case_routes(tmp_path,monkeypatch):
    import src.services.disparity_agent.agents.orchestrator as orch
    app=make_app(tmp_path,monkeypatch); report=report_for(tmp_path)
    agent=NS(run=AsyncMock(return_value=report),compile_selected_use_case=AsyncMock(return_value={'reviewed':True}))
    monkeypatch.setattr(orch,'AgenticOrchestrator',lambda *a,**k:agent)
    with TestClient(app) as c:
        sid=c.post('/api/v1/sessions',json={'metadata':{'actor':'Test','actor_role':'Admin'}}).json()['data']['session_id']
        data={'session_id':sid,'search_type':'email','search_value':'member@example.com','include_raw_source_data':False,'include_html':True}
        r=c.post('/api/v1/analysis/individual',json=data)
        assert r.status_code==200 and 'records' not in r.json()['data']['report'] and '<html' in r.json()['data']['html']
        for review in [False,True]:
            r=c.post('/api/v1/use-cases/plan',json={'run_id':report.run_id,'use_case_id':'UC-013','include_dell_aia_review':review})
            assert r.status_code==200 and r.json()['data']['deterministic_plan']
        agent.compile_selected_use_case.side_effect=RuntimeError('offline')
        r=c.post('/api/v1/use-cases/plan',json={'run_id':report.run_id,'use_case_id':'UC-013','include_dell_aia_review':True})
        assert r.json()['data']['review_status']=='FAILED'
        assert c.post('/api/v1/use-cases/plan',json={'run_id':report.run_id,'use_case_id':'UC-999'}).status_code==404
        assert c.post('/api/v1/use-cases/plan',json={'run_id':'DDR-CCCCCCCCCCCC','use_case_id':'UC-013'}).status_code==404
        agent.run.side_effect=RuntimeError('offline')
        assert c.post('/api/v1/analysis/individual',json=data).status_code==500
        assert c.get('/api/v1/legacy/AIAnalysis/analyze',params={'searchType':'email','searchValue':'a@example.com'}).status_code==500
        assert c.post('/api/v1/analysis/individual',json=data|{'session_id':'missing'}).status_code==404
        catalog=c.get('/api/v1/knowledge/catalog').json()['data']
        op=catalog['operations'][0]['operation_id']
        assert c.get('/api/v1/knowledge/operations/'+op).status_code==200
        assert c.post('/api/v1/knowledge/validate-payload',json={'operation_id':op,'payload':{}}).status_code==200
        app.state.runs.view=AsyncMock(side_effect=UnmaskedReportUnavailable('rerun'))
        for suffix in ['', '/report.html','/report.json']:
            assert c.get('/api/v1/analysis/'+report.run_id+suffix).status_code==409
        app.state.runs.view=AsyncMock(side_effect=RunNotFound('missing'))
        assert c.get('/api/v1/analysis/'+report.run_id+'/report.html').status_code==404


def test_source_and_batch_routes_validation_and_session_links(tmp_path,monkeypatch):
    import src.services.disparity_agent.api.routes as routes
    app=make_app(tmp_path,monkeypatch); svc=app.state.source_operations
    monkeypatch.setattr(routes,'CPSConnector',lambda s:NS(fetch=AsyncMock(return_value=record(SourceName.CPS,True,True,{}))))
    with TestClient(app) as c:
        sid=c.post('/api/v1/sessions',json={}).json()['data']['session_id']
        state=run(app.state.sessions.get(sid))
        state.last_batch_summary={'members':[{'email':'a@example.com'}]}
        svc.query_identifiers=AsyncMock(return_value={'members':[],'sources':['cps']})
        for body in [{'search_type':'email','search_value':'a@example.com'},{'query':'a@example.com'},{'session_id':sid,'query':'a@'}]:
            assert c.post('/api/v1/source-operations/query',json={'sources':['cps']}|body).status_code==200
        assert c.post('/api/v1/source-operations/query',json={'sources':['cps'],'query':'nobody'}).status_code==400
        assert c.post('/api/v1/source-operations/query',json={'sources':['cps'],'session_id':'missing','emails':['a@example.com']}).status_code==404
        assert c.post('/api/v1/source-operations/cps/query',json={'session_id':sid,'query':'a@'}).status_code==200
        assert c.post('/api/v1/source-operations/cps/query',json={'session_id':'missing','query':'a'}).status_code==404
        assert c.post('/api/v1/source-operations/cps/query',json={'query':'nobody'}).status_code==400
        assert c.get('/api/v1/sessions/missing/active-batch').status_code==404
        run(app.state.sessions.set_active_batch(sid,'JOB-AAAAAAAAAAAAAAAA'))
        r=c.get(f'/api/v1/sessions/{sid}/active-batch'); assert r.json()['data']['job']['job_id']=='JOB-AAAAAAAAAAAAAAAA'
        job=BatchJob(job_id='JOB-AAAAAAAAAAAAAAAA',parse_result={},settings=app.state.engine_settings,api_settings=app.state.api_settings,max_parallel=1,max_parallel_ai=1,include_group_ai=False)
        app.state.batch_jobs.jobs[job.job_id]=job
        assert c.get(f'/api/v1/sessions/{sid}/active-batch').status_code==200
        assert c.get('/api/v1/batches/'+job.job_id+'/summary').status_code==409
        app.state.batch_jobs.create=AsyncMock(return_value=job)
        assert c.post('/api/v1/batches',json={'emails':['a@example.com'],'session_id':sid}).status_code==202
        assert c.post('/api/v1/batches',json={'emails':['bad']}).status_code==400
        assert c.post('/api/v1/batches',json={'emails':['a@example.com'],'session_id':'missing'}).status_code==404
        for session,expected in [(sid,202),('missing',404)]:
            assert c.post('/api/v1/batches/upload',params={'session_id':session},files={'file':('a.txt',b'a@example.com')}).status_code==expected
        assert c.post('/api/v1/batches/upload',files={'file':('a.txt',b'invalid')}).status_code==400
        assert c.get('/api/v1/source-operations/changes/CHG-AAAAAAAAAAAA',params={'session_id':'missing'}).status_code==404
        payload={'session_id':'missing','source':'crowd_twist','operation':'update','emails':['a@example.com'],'field':'country','new_value':'US','actor_role':'Business'}
        assert c.post('/api/v1/source-operations/changes/plan',json=payload).status_code==404
        payload['session_id']=sid; payload['field']='password'
        assert c.post('/api/v1/source-operations/changes/plan',json=payload).status_code==400


def test_spreadsheet_route_refreshes_each_completed_member_once(tmp_path,monkeypatch):
    app=make_app(tmp_path,monkeypatch); report=report_for(tmp_path).model_dump(mode='json')
    completed={'status':'COMPLETED','targets':[{'email':'member@example.com'}],
               'change_id':'CHG-AAAAAAAAAAAA','source':'crowd_twist','source_label':'CrowdTwist',
               'write_mode':'live','target_count':1,'field':'country','new_value':'US',
               'required_confirmation_count':1,'results':[{'success':True,'verified':True}]}
    result={'execution_completed':True,'completed_changes':[completed,completed,{'status':'FAILED'}]}
    svc=app.state.source_operations; svc.import_spreadsheet_changes=AsyncMock(return_value=result)
    app.state.chat_service.refresh_after_source_change=AsyncMock(return_value=report)
    with TestClient(app) as c:
        sid=c.post('/api/v1/sessions',json={}).json()['data']['session_id']
        body={'session_id':sid,'file_name':'a.xlsx','instruction':'apply','actor':'Tester','actor_email':'tester@example.com','actor_role':'Business','rows':[{'row_number':2,'source':'crowd_twist','identifier_type':'email','identifier_value':'a@example.com','field':'country','new_value':'US'}]}
        r=c.post('/api/v1/source-operations/spreadsheet-import',json=body)
        assert r.status_code==200
        app.state.chat_service.refresh_after_source_change.assert_awaited_once()
        assert c.post('/api/v1/source-operations/spreadsheet-import',json=body|{'session_id':'missing'}).status_code==404
        svc.import_spreadsheet_changes.side_effect=SourceOperationError('DENIED','denied',409)
        assert c.post('/api/v1/source-operations/spreadsheet-import',json=body).status_code==409
        svc.confirm_second=AsyncMock(return_value=completed)
        r=c.post('/api/v1/source-operations/changes/CHG-AAAAAAAAAAAA/confirm-2',json={'session_id':sid,'actor_role':'Business','confirmation_text':'APPROVE'})
        assert r.status_code==200


def test_public_module_exports_and_entrypoint(monkeypatch):
    import src.models as models
    import src.services.llm_services as llm
    import src.services.disparity_agent.agents as agents
    import uvicorn
    assert models.SearchType and llm.build_model_client and agents.AgenticOrchestrator
    with pytest.raises(AttributeError): getattr(agents,'missing')
    server=MagicMock(); monkeypatch.setattr(uvicorn,'run',server)
    monkeypatch.setenv('API_PORT','8181')
    runpy.run_module('src',run_name='__main__')
    assert server.call_args.kwargs['port']==8181

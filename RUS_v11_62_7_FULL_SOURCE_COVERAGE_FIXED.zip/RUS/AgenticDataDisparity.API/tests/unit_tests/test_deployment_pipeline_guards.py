from __future__ import annotations

import ast
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def test_unit_suite_does_not_require_async_pytest_plugin():
    """Shared Dell unit-test blueprints can invoke plain pytest without plugins."""
    offenders = []
    for path in (PROJECT_ROOT / "tests" / "unit_tests").glob("test_*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.AsyncFunctionDef) and node.name.startswith("test_"):
                offenders.append(f"{path.name}:{node.lineno}:{node.name}")
    assert not offenders, "Async pytest tests require a plugin in the shared pipeline: " + ", ".join(offenders)


def test_runtime_manifest_keeps_sca_safe_urllib3_floor():
    """Accept an equal-or-newer safe urllib3 pin/floor after deployment-team merges."""
    req = (PROJECT_ROOT / "requirements.txt").read_text(encoding="utf-8")
    assert "aia-auth-client" in req
    m = re.search(r"^urllib3\s*(==|>=)\s*(\d+)\.(\d+)\.(\d+)", req, re.M)
    assert m, "urllib3 must retain an explicit security floor/pin"
    assert tuple(map(int, m.groups()[1:])) >= (2, 7, 0)


def test_shared_unit_runner_emits_junit_and_coverage_without_ci_layout_assumptions():
    """The corporate pipeline may own packaging; our unit runner must be self-contained."""
    runner = (PROJECT_ROOT / "tests/unit_tests/run_pytest.py").read_text(encoding="utf-8")
    assert "--junitxml=junit.xml" in runner
    assert "--cov-report=xml:coverage.xml" in runner
    assert "--cov-fail-under=96" in runner
    assert "-p" in runner and "no:asyncio" in runner


def test_runtime_directory_and_docker_context_exist_independent_of_shared_ci():
    """Deployment-team CI layout is external; validate only the package inputs we own."""
    assert (PROJECT_ROOT / "runtime").is_dir()
    docker = (PROJECT_ROOT / "Dockerfile").read_text(encoding="utf-8")
    assert "COPY runtime" in docker


def test_shared_runner_publishes_sonar_and_junit_artifacts_to_invocation_root():
    runner = (PROJECT_ROOT / "tests/unit_tests/run_pytest.py").read_text(encoding="utf-8")
    assert "CALLER_CWD" in runner
    assert "REPOSITORY_ROOT" in runner
    assert "publish(PROJECT_ROOT, DESTINATIONS, exit_code)" in runner


def test_sonar_contract_is_workdir_independent():
    from scripts.coverage_artifacts import validate_policy
    validate_policy(PROJECT_ROOT)

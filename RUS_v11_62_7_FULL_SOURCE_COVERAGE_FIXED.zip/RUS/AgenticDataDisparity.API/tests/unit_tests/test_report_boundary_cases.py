"""Readable, escaped reports for missing data, legacy inputs and partial source health."""
from unittest.mock import AsyncMock
from types import SimpleNamespace as NS
import pytest
from tests.unit_tests.test_execution_workflows import run, report_for
from tests.unit_tests.test_chat_workflows import chat
from src.services.disparity_agent.api.schemas import ChatRequest


def test_batch_legacy_csv_and_invalid_duration_inputs():
    from src.services.disparity_agent import batch as b
    parsed=b.parse_email_list('members.csv',b'a@example.com\nb@example.com')
    assert parsed['emails']==['a@example.com','b@example.com']
    assert b._duration_ms('bad')==0 and b._percentage('bad',3)==0
    for status,expected in [({'data_found':True},'FOUND'),({'connected':True},'NO_RECORD'),({},'UNAVAILABLE')]:
        assert b._source_state({'source_status':{'cps':status}},'cps')==expected
    summary={'processing':{'completed_count':4},'top_issue_attributes':[{'attribute':'country','count':2},{'label':'email','users':1},{}]}
    insights=b.build_batch_insights(summary)
    assert insights['ranked_issue_attributes'][0]['users_affected']==2
    assert b._fmt_duration(None)=='—' and b._fmt_duration(1500)=='1.50 s' and b._fmt_duration(61000)=='1m 1.0s'
    assert b._esc(None)=='—' and b._esc('<script>')=='&lt;script&gt;'


def test_html_report_explains_missing_sources_and_escapes_values(tmp_path):
    from src.services.disparity_agent import reporting as r
    report=report_for(tmp_path)
    data=r._as_dict(report)
    for v in data['attributes']:
        v.update(missing_sources=['crowd_twist'],unavailable_sources=['rewards_db'],truth_value='<script>')
    text=r.render_html_report(data)
    assert 'missing attribute:' in text.lower() and 'record unavailable:' in text.lower()
    assert '&lt;script&gt;' in text and '<script>' not in text
    assert r._fmt_duration('bad')=='—' and r._fmt_duration(1500)=='1.50 s' and r._fmt_duration(61000)=='1m 1.0s'
    assert '&quot;key&quot;' in r._esc({'key':1})
    for status,expected in [({'connected':True,'diagnostics':{'lookup_result':'no_value_found'}},'No value found'),({'connected':True},'Connected, no data'),({},'Unavailable')]:
        status.update(latency_ms=3,diagnostic_hint='retry')
        assert expected in r._source_card('CPS',status)


@pytest.mark.parametrize('selection',['alice0@example.com','external@example.com','unmatched'])
def test_cps_selection_uses_explicit_email_and_limits_display(tmp_path,selection):
    c=chat(tmp_path,False)
    c._run_cps_for_emails=AsyncMock(return_value=('done',{'requested_count':1}))
    async def exercise():
        state=await c.sessions.create()
        state.last_batch_summary={'members':[{'email':f'alice{i}@example.com'} for i in range(25)]}
        text,data=await c._handle_cps_source_request(ChatRequest(session_id=state.session_id,message='show cps alice'),state)
        assert data['status']=='selection_required' and 'and 5 more' in text
        text,data=await c._handle_cps_source_request(ChatRequest(session_id=state.session_id,message=selection),state)
        if selection=='unmatched':
            assert data['status']=='email_required'
            c._run_cps_for_emails.assert_not_awaited()
        else:
            c._run_cps_for_emails.assert_awaited_once_with([selection])
        state.facts.clear()
        await c._handle_cps_source_request(ChatRequest(session_id=state.session_id,message='external@example.com'),state)
        assert c._run_cps_for_emails.call_args.args==(['external@example.com'],)
    run(exercise())


@pytest.mark.parametrize('missing',[False,True])
def test_chat_batch_context_reads_job_or_retains_session_fallback(tmp_path,missing):
    from src.services.disparity_agent.api.batch_jobs import BatchJobNotFound
    c=chat(tmp_path,False)
    c.batch_jobs=NS(get=AsyncMock(return_value=NS(summary={'batch_id':'BATCH-LIVE'}),side_effect=BatchJobNotFound('gone') if missing else None),view=lambda job,base:NS(model_dump=lambda **kw:{'status':'RUNNING'}))
    async def exercise():
        state=await c.sessions.create()
        await c.sessions.set_active_batch(state.session_id,'JOB-AAAAAAAAAAAAAAAA')
        data=await c._get_batch_context(state,'http://test')
        assert data['job']
        if not missing: assert data['summary']['batch_id']=='BATCH-LIVE'
    run(exercise())

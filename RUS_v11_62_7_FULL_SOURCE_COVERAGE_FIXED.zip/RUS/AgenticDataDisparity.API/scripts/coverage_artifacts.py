"""Publish unchanged coverage hits with paths relative to each scanner base directory."""
from __future__ import annotations

import argparse
import configparser
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

API_ROOT = Path(__file__).resolve().parents[1]
MINIMUM = 96.0


def source_inventory(api_root: Path) -> dict[str, str]:
    return {p.relative_to(api_root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((api_root / 'src').rglob('*.py'))}


def validate_policy(api_root: Path = API_ROOT) -> None:
    for name in ('coverage-ci.ini', '.coveragerc'):
        cfg = configparser.ConfigParser()
        if not cfg.read(api_root / name):
            raise ValueError(f'Missing coverage policy: {name}')
        if cfg.get('run', 'source').strip() != 'src' or not cfg.getboolean('run', 'relative_files'):
            raise ValueError('Coverage must measure src with relative filenames')
        if cfg.getfloat('report', 'fail_under') < MINIMUM:
            raise ValueError('Coverage gate must be at least 96%')
        for section, key in [('run', 'omit'), ('run', 'include'), ('report', 'omit'), ('report', 'include'), ('report', 'exclude_lines'), ('report', 'exclude_also')]:
            if cfg.get(section, key, fallback='').strip():
                raise ValueError(f'Full-source coverage forbids {section}.{key}')
    for base, source in [(api_root, 'src'), (api_root.parent, api_root.name + '/src')]:
        path = base / 'sonar-project.properties'
        if not path.exists() and base != api_root:
            continue  # The deployment team may own the root scanner configuration.
        properties = dict(line.strip().split('=', 1) for line in path.read_text().splitlines()
                          if '=' in line and not line.lstrip().startswith('#'))
        if properties.get('sonar.sources') != source or properties.get('sonar.python.coverage.reportPaths') != 'coverage.xml':
            raise ValueError(f'Incorrect source/report mapping in {path}')
        for key in ('sonar.exclusions', 'sonar.coverage.exclusions'):
            if properties.get(key, '').strip():
                raise ValueError(f'Full-source coverage forbids {key}')


def rebase_xml(raw: bytes, api_root: Path, destination: Path) -> bytes:
    tree = ET.fromstring(raw)
    inventory = source_inventory(api_root)
    seen = set()
    for item in tree.findall('.//class'):
        filename = item.attrib['filename']
        matches = {p.resolve() for p in (api_root / filename, api_root / 'src' / filename)
                   if p.is_file() and p.resolve().is_relative_to((api_root / 'src').resolve())}
        if len(matches) != 1:
            raise ValueError(f'Unresolvable coverage filename: {filename}')
        path = matches.pop()
        key = path.relative_to(api_root.resolve()).as_posix()
        if key in seen:
            raise ValueError(f'Duplicate coverage source: {key}')
        seen.add(key)
        item.set('filename', Path(os.path.relpath(path, destination)).as_posix())
    if seen != set(inventory):
        raise ValueError(f'Coverage source inventory differs: {sorted(set(inventory) ^ seen)}')
    sources = tree.find('sources')
    if sources is None:
        sources = ET.SubElement(tree, 'sources')
    sources.clear()
    # An empty sources element uses sonar.projectBaseDir, including older scanners.
    # Each filename already contains its exact path relative to that directory.
    return ET.tostring(tree, encoding='utf-8', xml_declaration=True)


def inspect_xml(xml: bytes, base_dir: Path, api_root: Path, minimum: float = MINIMUM) -> dict:
    tree = ET.fromstring(xml)
    if any((s.text or '').strip() for s in tree.findall('./sources/source')):
        raise ValueError('Published coverage must resolve from the scanner base directory')
    inventory = source_inventory(api_root)
    seen = set()
    covered = total = 0
    for item in tree.findall('.//class'):
        path = (base_dir / item.attrib['filename']).resolve()
        if not path.is_relative_to(api_root.resolve()) or not path.is_file():
            raise ValueError(f'Coverage path cannot be resolved: {item.attrib["filename"]}')
        key = path.relative_to(api_root.resolve()).as_posix()
        if key in seen:
            raise ValueError(f'Duplicate coverage source: {key}')
        seen.add(key)
        numbers = set()
        for line in item.findall('./lines/line'):
            number, hits = int(line.attrib['number']), int(line.attrib['hits'])
            if number < 1 or hits < 0 or number in numbers:
                raise ValueError(f'Invalid or duplicate line in {key}')
            numbers.add(number)
            total += 1
            covered += hits > 0
    if seen != set(inventory):
        raise ValueError(f'Incomplete coverage inventory: {sorted(set(inventory) ^ seen)}')
    if total != int(tree.attrib['lines-valid']) or covered != int(tree.attrib['lines-covered']):
        raise ValueError('Coverage aggregate does not match recorded line hits')
    if not total or covered * 100 < minimum * total:
        raise ValueError(f'Full-source coverage {covered}/{total} is below {minimum}%')
    return {'covered_lines': covered, 'executable_lines': total, 'line_coverage_percent': covered * 100 / total,
            'source_files': len(seen), 'source_sha256': inventory, 'minimum_percent': minimum,
            'coverage_exclusions': []}


def publish(api_root: Path, destinations: set[Path], exit_code: int) -> dict:
    raw = (api_root / 'coverage.xml').read_bytes()
    junit = (api_root / 'junit.xml').read_bytes()
    cases = ET.fromstring(junit).findall('.//testcase')
    tests = {'collected': len(cases), 'failed': sum(c.find('failure') is not None for c in cases),
             'errors': sum(c.find('error') is not None for c in cases), 'skipped': sum(c.find('skipped') is not None for c in cases)}
    tests['passed'] = tests['collected'] - tests['failed'] - tests['errors'] - tests['skipped']
    result = None
    for destination in sorted(destinations):
        xml = rebase_xml(raw, api_root, destination)
        result = inspect_xml(xml, destination, api_root, minimum=0)
        result.update(pytest_exit_code=int(exit_code), tests=tests, minimum_percent=MINIMUM)
        result['status'] = 'PASS' if exit_code == 0 and tests['passed'] > 0 and not tests['failed'] and not tests['errors'] and result['line_coverage_percent'] >= MINIMUM else 'FAIL'
        (destination / 'coverage.xml').write_bytes(xml)
        (destination / 'junit.xml').write_bytes(junit)
        (destination / 'coverage-summary.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description='Verify fresh full-source coverage before Sonar')
    parser.add_argument('--base-dir', type=Path, default=Path.cwd())
    args = parser.parse_args()
    base = args.base_dir.resolve()
    validate_policy()
    actual = inspect_xml((base / 'coverage.xml').read_bytes(), base, API_ROOT)
    recorded = json.loads((base / 'coverage-summary.json').read_text())
    if recorded.get('status') != 'PASS' or recorded.get('pytest_exit_code') != 0:
        raise ValueError('Unit run did not pass; rerun unit_test.py')
    for key in ('source_sha256', 'covered_lines', 'executable_lines'):
        if recorded.get(key) != actual[key]:
            raise ValueError('Coverage is stale or mismatched; rerun unit_test.py')
    print(f"PASS: {actual['line_coverage_percent']:.2f}% ({actual['covered_lines']}/{actual['executable_lines']} lines), "
          f"{actual['source_files']} source files resolved, tests {recorded['tests']['passed']}/{recorded['tests']['collected']}")


if __name__ == '__main__':
    main()

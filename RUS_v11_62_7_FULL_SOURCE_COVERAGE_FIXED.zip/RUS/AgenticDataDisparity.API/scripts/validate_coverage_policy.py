"""Validate the full-source coverage contract without depending on corporate CI text."""
from coverage_artifacts import validate_policy

if __name__ == '__main__':
    validate_policy()
    print('PASS: all Python source measured, gate >=96%, relative Sonar report paths, no exclusions')

# RUS full-source coverage repair — 25 September 2026

This repair retains runtime version 11.62.7. The archive name and SHA-256 distinguish it from the original v11.62.7 ZIP.

## Results and scope

| Check | Result |
|---|---:|
| Unit tests | 416 passed; 0 failures, errors, or skips |
| Python line coverage | 96.2945% (8,134 / 8,447 executable lines) |
| Coverage gate | 96%; process exits nonzero below it |
| Python source files in report | 68, including empty package initializers |
| Production coverage exclusions | None |
| Original unit tests | Retained, with isolated dependency mocks and updated coverage contracts |
| Package checks | 48 / 48 |
| Static business/runtime parity checks | 32 / 32 |
| Deployment checks | 13 / 13 |
| Packaged SAST regression checks | 14 / 14 |
| JavaScript syntax checks | 20 / 20 |

The Python measurement covers every file under `AgenticDataDisparity.API/src`, including connectors, orchestration, source operations, API routes, chat, batch jobs, reporting, and entry points. Branch coverage is not claimed. C# and browser code are included in the full package but are not part of this Python coverage percentage.

Tests run on Python 3.12 with public runtime dependencies; external Dell services, source writes, LLMs, OAuth, and database transports are simulated. The private Dell AIA auth package, native ODBC driver, live data, Windows launcher, and .NET build were not validated against Dell infrastructure. The static package checks are not a substitute for that deployment validation. The hosted Dell Sonar server was not executed here.

The screenshot establishes 139/144 passing tests and 69.2% Sonar line coverage, but does not name the five failing tests. This repair validates the supplied source package; it cannot identify those five remote failures from the screenshot alone.

## What changed

The previous 96.35% result covered only a selected portion of the application. Re-measuring the initial source without those omissions gave approximately 64.52%. The repaired result measures the complete Python source instead of shrinking the denominator.

Added workflow and failure tests for API responses, individual and batch analysis, identity resolution, OAuth/HTTP/database boundaries, model and judge errors, approvals by role, popup tokens, expiration, drift, read-after-write verification, spreadsheets, audit records, and portable coverage artifacts.

Fixed defects exposed by those tests:

- Missing native ODBC libraries now produce a clear unavailable-connector error instead of preventing application/test imports.
- A batch member with collected evidence but failed analysis is counted as failed and retains its error.
- Rejected or malformed judge responses without a correction cannot expose an unapproved model narrative; deterministic evidence is used instead. Model initialization/cleanup errors are handled consistently.
- Unauthorized sensitive audit requests return HTTP 403, including when a status query filter is present.

Tests no longer inject fake AutoGen modules globally into other tests. Unit settings explicitly select simulated sources even if the CI environment has live-source flags. The test runner uses a separate pytest process, preserves its failure status, removes stale outputs before starting, and verifies complete coverage inventory during publication.

No coverage hits are fabricated or altered. Publication changes only source-path metadata. Root and API reports contain identical line hits with different filenames; an empty XML `sources` element lets the importer use the scanner base directory. A SHA-256 inventory detects changes to Python source after the test report was generated.

## Dell shared unit job

Use the existing job's approved Python environment and dependency-install procedure. Install the supplied `requirements-dev.txt` with the existing Dell package-index access. Keep:

```sh
UNIT_TEST_FILE=AgenticDataDisparity.API/unit_test.py
python3 "$UNIT_TEST_FILE"
python3 AgenticDataDisparity.API/scripts/coverage_artifacts.py --base-dir .
```

Run these commands from the repository root. Preserve the command's exit status; do not append `|| true` or replace the canonical runner with a different coverage invocation.

Publish these repository-root artifacts, including on job failure:

```yaml
artifacts:
  when: always
  reports:
    junit: junit.xml
  paths:
    - coverage.xml
    - junit.xml
    - coverage-summary.json
```

The unit runner also works from the API directory using `python3 unit_test.py`; run `python3 scripts/coverage_artifacts.py --base-dir .` there. Each directory receives its own correctly rebased report.

## Sonar job

Download the artifacts from the unit job for the same commit. Keep the existing project key, authentication, and shared pipeline settings. The two supplied properties files describe the existing Python application project:

| Scanner base directory | Sources | Tests | Coverage report |
|---|---|---|---|
| Repository root | `AgenticDataDisparity.API/src` | `AgenticDataDisparity.API/tests` | `coverage.xml` |
| API directory | `src` | `tests` | `coverage.xml` |

Use one matching report, not a comma-separated list of duplicate reports. No coverage exclusions are needed. Run the verifier from the scanner base directory before scanning. It fails for missing files, omitted source modules, stale source hashes, failed tests, or coverage below 96%.

If the scanner starts from a different directory or receives command-line `-Dsonar.*` properties, confirm its effective `sonar.projectBaseDir`, `sonar.sources`, `sonar.tests`, and `sonar.python.coverage.reportPaths`. Check the Python coverage sensor log for the report path and unresolved file warnings. If the shared job scans a larger project containing C# or JavaScript, provide coverage for those languages too; the Python result is not evidence of whole-monorepo coverage. Also distinguish overall line coverage from new-code or combined branch/line coverage.

Do not copy the example API `.gitlab-ci.yml` over the team's pipeline wholesale. Retain the team's deployment work and integrate the runner, verifier, and artifact paths above.

If the hosted result remains different, the useful evidence is the effective scanner command/properties, Python coverage-import log, Sonar metric name and scope, downloaded XML, and the failure tracebacks. A command-line override is one possible cause, not a proven diagnosis from the screenshot.

## Revalidation

The final ZIP is re-extracted to a separate directory and the exact unit entry point is executed from its repository root. Both root and API report paths are verified. A further isolated merge check replaces the example CI text, removes the optional root properties file, and changes the urllib3 requirement from a pin to the same safe minimum; the unit suite must still pass.

The included root `coverage-summary.json` contains the measured totals, test counts, exit status, and complete source hashes. `junit.xml` contains individual test results. Always regenerate these in CI for the target commit.

Launch the application with `Start-RUS-v11_62_7.ps1` after the usual Dell environment configuration. The generic launcher is retained.

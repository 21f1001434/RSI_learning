from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'AgenticDataDisparity.API' / 'scripts'))
from coverage_artifacts import validate_policy

if __name__ == '__main__':
    validate_policy()
    print('PASS: root and API Sonar scopes match full Python source coverage')
